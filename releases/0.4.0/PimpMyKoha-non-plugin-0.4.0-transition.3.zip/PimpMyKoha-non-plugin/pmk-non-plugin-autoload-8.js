/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
/* PimpMyKoha — 136 Assistant XSLT — v0.4.0-preplugin
 * Import manuel (fichier ou collage), édition visuelle, XSLT complet à copier.
 * Aperçu automatique sur une notice Koha, historique local et compatibilité des projets.
 * Les références xsl:include/import sont conservées ; aucun XSLT distant n'est récupéré.
 * Aperçu : str:encode-uri dans xsl:value-of est évalué sans extension navigateur,
 * puis encodé en JavaScript ; le XSLT source et le code final ne sont pas modifiés.
 */
(function (window, document) {
    "use strict";

    if (window.__PMK136_XSLT_ASSISTANT__) return;
    window.__PMK136_XSLT_ASSISTANT__ = true;

    const MODULE_ID = "xslt-assistant";
    const MODULE_VERSION = "0.4.0-preplugin";
    const PAGE_PARAM = "xslt-assistant";
    const PAGE_URL = "/cgi-bin/koha/mainpage.pl?pmk_page=" + encodeURIComponent(PAGE_PARAM);
    const STORAGE_PREFIX = "pmk-xslt-assistant-v1:";
    const INDEX_KEY = STORAGE_PREFIX + "projects";
    const XSL_NS = "http://www.w3.org/1999/XSL/Transform";
    const MARC_NS = "http://www.loc.gov/MARC21/slim";
    const XMLNS_NS = "http://www.w3.org/2000/xmlns/";

    const KNOWN_PREFS = [
        { id: "XSLTDetailsDisplay", label: "Pro — Détail notice", scope: "staff", kind: "biblio" },
        { id: "XSLTResultsDisplay", label: "Pro — Résultats de recherche", scope: "staff", kind: "biblio" },
        { id: "XSLTListsDisplay", label: "Pro — Listes", scope: "staff", kind: "biblio" },
        { id: "OPACXSLTDetailsDisplay", label: "OPAC — Détail notice", scope: "opac", kind: "biblio" },
        { id: "OPACXSLTResultsDisplay", label: "OPAC — Résultats de recherche", scope: "opac", kind: "biblio" },
        { id: "OPACXSLTListsDisplay", label: "OPAC — Listes", scope: "opac", kind: "biblio" },
        { id: "AuthorityXSLTDetailsDisplay", label: "Pro — Détail autorité", scope: "staff", kind: "authority" },
        { id: "AuthorityXSLTResultsDisplay", label: "Pro — Résultats autorités", scope: "staff", kind: "authority" },
        { id: "AuthorityXSLTOpacDetailsDisplay", label: "OPAC — Détail autorité", scope: "opac", kind: "authority" },
        { id: "AuthorityXSLTOpacResultsDisplay", label: "OPAC — Résultats autorités", scope: "opac", kind: "authority" }
    ];

    const DEFAULT_CONFIG = {enabled:true,marcApiBase:"/api/v1",previewTimeoutMs:15000,defaultPreviewBiblio:"",defaultPreviewAuthority:""};

    let app = null;
    let pageContext = null;
    let styleNode = null;
    let currentProject = null;
    let workingDoc = null;
    let selectedNodeId = null;
    let draggedNodeId = null;
    let pointerDrag = null;
    let dragJustFinishedUntil = 0;
    let autoPreviewTimer = null;
    let autoPreviewRequest = 0;
    const marcPreviewCache = new Map();
    let projectEpoch = 0;
    let activeWorkspaceStep = "source";
    let structureFilterText = "";
    let structureFilterMode = "all";
    const collapsedTemplates = new Set();
    let suppressHistory = false;
    const projectHistories = new Map();
    const unsavedProjects=new Set();
    let moduleConfig={enabled:true};
    let previousOverflow="";

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function uid(prefix) {
        return (prefix || "id") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    }

    function esc(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function isSuperlibrarian() {
        try {
            if (window.PMKPages && typeof window.PMKPages.isSuperlibrarian === "function") {
                return window.PMKPages.isSuperlibrarian() === true;
            }
            if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === "function") {
                if (window.PMKConfig.isKohaSuperlibrarian() === true) return true;
            }
        } catch (_) {}
        try {
            const user = document.querySelector(
                '#logged-in-info-full .loggedinusername[data-loggedinusername], ' +
                '.loggedinusername[data-loggedinusername], ' +
                '.loggedinusername[data-is-superlibrarian], ' +
                '.loggedinusername.is_superlibrarian'
            );
            if (!user) return false;
            if (user.classList && user.classList.contains('is_superlibrarian')) return true;
            const raw = String(
                (user.dataset && user.dataset.isSuperlibrarian) ||
                user.getAttribute('data-is-superlibrarian') || ''
            ).trim().toLowerCase();
            return ['is_superlibrarian','superlibrarian','1','true','yes'].includes(raw);
        } catch (_) { return false; }
    }

    function currentPreferenceMeta(project) {
        project = project || currentProject;
        const id = project && project.syspref ? project.syspref : "";
        return KNOWN_PREFS.find(function (pref) { return pref.id === id; }) || null;
    }

    function currentRecordKind() {
        const meta = currentPreferenceMeta();
        return meta && meta.kind === "authority" ? "authority" : "biblio";
    }

    function currentUiMode() {
        return currentProject && currentProject.uiMode === "advanced" ? "advanced" : "simple";
    }

    function normalizeProjectState(project) {
        if (!project) return project;
        if (project.uiMode !== "advanced") project.uiMode = "simple";
        if (project.activeStep === "test") project.activeStep = "build";
        if (!["source", "build", "publish"].includes(project.activeStep)) project.activeStep = project.workingXml ? "build" : "source";
        if (!Array.isArray(project.previewRecords)) project.previewRecords = [];
        if (!Object.prototype.hasOwnProperty.call(project, "previewBiblionumber")) project.previewBiblionumber = "";
        if (!Object.prototype.hasOwnProperty.call(project, "previewAuthorityId")) project.previewAuthorityId = "";
        if (!project.previewSearchIndex) project.previewSearchIndex = "kw";
        if (!Object.prototype.hasOwnProperty.call(project,"autoPreview")) project.autoPreview=true;
        if (!Object.prototype.hasOwnProperty.call(project, "autoPreviewCompare")) project.autoPreviewCompare = false;
        if (!project.lastValidation || typeof project.lastValidation !== "object") project.lastValidation = null;
        return project;
    }

    function stringHash(value) {
        let hash = 5381;
        const text = String(value == null ? "" : value);
        for (let i = 0; i < text.length; i += 1) hash = ((hash << 5) + hash) ^ text.charCodeAt(i);
        return (hash >>> 0).toString(16).padStart(8, "0");
    }

    function projectContentFingerprint() {
        if (!currentProject) return "";
        const main = workingDoc ? serializeDoc(workingDoc, true) : clean(currentProject.workingXml || "");
        const deps = normalizeDependenciesProject().filter(function (dep) { return dep.custom; }).map(function (dep) {
            return [dep.id || "", dep.customFilename || "", dep.customXml || ""].join("\n");
        }).join("\n---DEP---\n");
        const context = [currentProject.syspref || "", currentProject.sourceUrl || "", currentRecordKind()].join("\n");
        return stringHash(context + "\n---MAIN---\n" + main + "\n---CUSTOM-DEPS---\n" + deps);
    }

    function validationRecordIds(kind) {
        const selected = kind === "authority" ? currentProject.previewAuthorityId : currentProject.previewBiblionumber;
        const records = Array.isArray(currentProject.previewRecords) ? currentProject.previewRecords : [];
        return [...new Set([selected, ...records.filter(r => r && (r.kind || "biblio") === kind).map(r => r.id)]
            .map(clean).filter(id => /^\d+$/.test(id)))];
    }

    function validationFingerprint() {
        if (!currentProject) return "";
        const kind = currentRecordKind();
        return stringHash(projectContentFingerprint() + "\n---TEST---\n" + kind + "\n" + validationRecordIds(kind).join(","));
    }

    function historyState(projectId) {
        if (!projectHistories.has(projectId)) projectHistories.set(projectId, { undo: [], redo: [] });
        return projectHistories.get(projectId);
    }

    function recordUndoSnapshot(previousXml) {
        if (suppressHistory || !currentProject || !clean(previousXml)) return;
        const h = historyState(currentProject.id);
        if (h.undo[h.undo.length - 1] !== previousXml) h.undo.push(previousXml);
        if (h.undo.length > 40) h.undo.shift();
        h.redo = [];
    }

    function restoreHistoryXml(xml) {
        if (!currentProject || !clean(xml)) return;
        suppressHistory = true;
        try {
            const doc = parseXml(xml);
            ensureNamespaces(doc);
            restorePmkMetadataComments(doc);
            annotate(doc);
            workingDoc = doc;
            recognizeVisualDocument(doc);
            currentProject.workingXml = serializeDoc(doc, false);
            currentProject.updatedAt = new Date().toISOString();
            saveProject(currentProject);
            if (!findNode(selectedNodeId)) selectedNodeId = getLiteralNodes()[0]?.getAttribute("data-pmk-xslt-node") || null;
        } finally { suppressHistory = false; }
        renderAll();
    }

    function undoWorking() {
        if (!currentProject || !workingDoc) return;
        const h = historyState(currentProject.id);
        const xml = h.undo.pop();
        if (!xml) return toast("Aucune modification à annuler.", "info");
        h.redo.push(serializeDoc(workingDoc, false));
        restoreHistoryXml(xml);
        toast("Modification annulée.", "success");
    }

    function redoWorking() {
        if (!currentProject || !workingDoc) return;
        const h = historyState(currentProject.id);
        const xml = h.redo.pop();
        if (!xml) return toast("Aucune modification à rétablir.", "info");
        h.undo.push(serializeDoc(workingDoc, false));
        restoreHistoryXml(xml);
        toast("Modification rétablie.", "success");
    }

    function isAssistantPage() {
        try {
            const url = new URL(window.location.href);
            return url.pathname.endsWith("/cgi-bin/koha/mainpage.pl") &&
                url.searchParams.get("pmk_page") === PAGE_PARAM;
        } catch (_) {
            return false;
        }
    }

    function openAssistantPage() {
        if (!isSuperlibrarian()) {
            toast("Accès réservé aux superlibrarians Koha.", "danger");
            return;
        }
        if (isAssistantPage() && !window.PMKPages) {
            openAssistant();
            return;
        }
        window.location.href = PAGE_URL;
    }

    function toast(message, type) {
        if (!app) return;
        let node = app.querySelector(".pmk135-toast");
        if (!node) {
            node = document.createElement("div");
            node.className = "pmk135-toast";
            app.appendChild(node);
        }
        node.className = "pmk135-toast is-visible " + (type || "info");
        node.textContent = message;
        window.clearTimeout(node.__hideTimer);
        node.__hideTimer = window.setTimeout(function () {
            node.classList.remove("is-visible");
        }, 3200);
    }

    function addStyles() {
        if (styleNode) return;
        styleNode = document.createElement("style");
        styleNode.id = "pmk135-xslt-assistant-style";
        styleNode.textContent = `
            .pmk135-topbar { flex-wrap:wrap; }
            .pmk136-navigation{background:#fff;border-bottom:1px solid #dfe3e7;padding:.35rem .85rem}
            .pmk136-navigation .pmk136-stepbar{margin:0}
            .pmk136-navigation button[aria-current=step]{font-weight:700}
            .pmk135-card:focus-visible{outline:3px solid #408540;outline-offset:2px}
            .pmk136-focus-step .pmk135-main { display:block; overflow:auto; }
            .pmk136-focus-step .pmk135-pane-workspace { max-width:1050px; margin:auto; min-height:100%; }
            .pmk136-focus-step .pmk135-pane-structure, .pmk136-focus-step .pmk135-pane-inspector { display:none; }
            .pmk135-card-title strong { font-size:.93rem; overflow-wrap:anywhere; }
            .pmk135-pane-structure .pmk135-pane-head { flex-wrap:wrap; }
            .pmk135-pane-structure .pmk135-pane-head strong { flex-basis:100%; }
            .pmk136-add-options { display:grid; gap:.6rem; }
            .pmk136-add-options button { text-align:left; padding:.85rem; white-space:normal; }
            .pmk136-add-options small { display:block; margin-top:.3rem; color:#5c6870; }
            .pmk135-launch { display:flex; flex-wrap:wrap; align-items:center; gap:.6rem; padding:.75rem; border:1px solid #d8dee4; border-radius:.65rem; background:#fff; }
            .pmk135-launch p { margin:0; color:#5d6771; flex:1 1 28rem; }
            .pmk135-overlay { position:fixed; inset:0; z-index:1095; background:#f5f7f9; color:#20262d; display:flex; flex-direction:column; }
            .pmk135-topbar { min-height:58px; display:flex; align-items:center; gap:.6rem; padding:.6rem .85rem; background:#fff; border-bottom:1px solid #dfe3e7; box-shadow:0 1px 3px rgba(0,0,0,.04); }
            .pmk135-brand { display:flex; align-items:center; gap:.55rem; font-weight:700; margin-right:.35rem; white-space:nowrap; }
            .pmk135-brand i { font-size:1.1rem; }
            .pmk135-topbar select, .pmk135-topbar input { min-width:180px; }
            .pmk135-spacer { flex:1; }
            .pmk135-main { min-height:0; flex:1; display:grid; grid-template-columns:minmax(280px, 22%) minmax(520px, 1fr) minmax(320px, 28%); gap:0; }
            .pmk135-pane { min-width:0; min-height:0; overflow:auto; background:#fff; }
            .pmk135-pane + .pmk135-pane { border-left:1px solid #dfe3e7; }
            .pmk135-pane-head { position:sticky; top:0; z-index:2; display:flex; align-items:center; gap:.45rem; padding:.7rem .75rem; border-bottom:1px solid #e6eaee; background:rgba(255,255,255,.97); }
            .pmk135-pane-head strong { flex:1; }
            .pmk135-structure { padding:.6rem; }
            .pmk135-card { border:1px solid #dce2e7; border-radius:.55rem; background:#fff; padding:.55rem .6rem; margin:.36rem 0; cursor:pointer; transition:border-color .12s, box-shadow .12s, transform .12s; }
            .pmk135-card:hover { border-color:#adb5bd; box-shadow:0 2px 8px rgba(0,0,0,.05); }
            .pmk135-card.is-selected { border-color:#6c757d; box-shadow:0 0 0 2px rgba(108,117,125,.13); }
            .pmk135-card.is-dragging { opacity:.30; }
            .pmk135-card.is-drop-target { border-style:dashed; }
            .pmk135-card.is-drop-before { box-shadow:0 -4px 0 #6f8f32, 0 0 0 1px rgba(111,143,50,.18); }
            .pmk135-card.is-drop-after { box-shadow:0 4px 0 #6f8f32, 0 0 0 1px rgba(111,143,50,.18); }
            .pmk135-card.is-drop-inside { border:2px solid #6f8f32; background:#f5f9ef; }
            .pmk135-card-title { display:flex; align-items:center; gap:.4rem; font-weight:600; }
            .pmk135-drag { cursor:grab; color:#6f7d88; padding:.2rem .28rem; margin:-.2rem 0 -.2rem -.2rem; border-radius:.3rem; touch-action:none; user-select:none; }
            .pmk135-drag:hover { background:#eef2e8; color:#526d22; }
            .pmk135-drag:active { cursor:grabbing; }
            .pmk136-drag-ghost { position:fixed; z-index:1200; pointer-events:none; max-width:360px; padding:.55rem .7rem; border:1px solid #8aa252; border-radius:.5rem; background:#fff; box-shadow:0 10px 35px rgba(0,0,0,.2); font-weight:600; opacity:.96; }
            .pmk136-drag-hint { position:fixed; z-index:1201; pointer-events:none; padding:.22rem .45rem; border-radius:999px; background:#526d22; color:#fff; font-size:.75rem; font-weight:700; box-shadow:0 4px 14px rgba(0,0,0,.18); }
            .pmk135-node-meta { margin-top:.25rem; color:#6b747d; font-size:.82rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
            .pmk135-depth { display:inline-block; }
            .pmk135-workspace { padding:.8rem; }
            .pmk135-empty { padding:2.4rem 1.1rem; text-align:center; color:#68727c; }
            .pmk135-empty i { display:block; font-size:2rem; margin-bottom:.6rem; color:#9aa3ab; }
            .pmk135-preview { border:1px solid #dfe4e8; border-radius:.65rem; background:#fbfcfd; min-height:220px; padding:.9rem; }
            .pmk135-preview-node { border:1px dashed #c8d0d7; border-radius:.45rem; padding:.65rem; background:#fff; }
            .pmk135-preview-node .badge { margin-right:.3rem; }
            .pmk135-code { width:100%; min-height:360px; font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; white-space:pre; tab-size:2; }
            .pmk135-import-grid { display:grid; grid-template-columns:1fr auto; gap:.5rem; align-items:end; }
            .pmk135-tabs { display:flex; gap:.25rem; flex-wrap:wrap; border-bottom:1px solid #e2e6ea; padding:.55rem .65rem 0; }
            .pmk135-tabs button { border:0; background:transparent; padding:.55rem .7rem; border-radius:.4rem .4rem 0 0; color:#59636c; }
            .pmk135-tabs button.is-active { background:#f3f5f7; color:#212529; font-weight:600; }
            .pmk135-inspector { padding:.75rem; }
            .pmk135-section { border:1px solid #e0e5e9; border-radius:.55rem; padding:.7rem; margin-bottom:.65rem; }
            .pmk135-section > h4 { font-size:1rem; margin:0 0 .65rem; }
            .pmk135-field { margin-bottom:.62rem; }
            .pmk135-field:last-child { margin-bottom:0; }
            .pmk135-field label { display:block; font-size:.84rem; font-weight:600; margin-bottom:.22rem; color:#424b54; }
            .pmk135-field small { display:block; margin-top:.2rem; color:#6c757d; }
            .pmk135-grid2 { display:grid; grid-template-columns:1fr 1fr; gap:.55rem; }
            .pmk135-condition-row { display:grid; grid-template-columns:84px 72px 62px 1fr; gap:.35rem; align-items:end; padding:.48rem; margin:.4rem 0; background:#f7f8fa; border-radius:.45rem; }
            .pmk135-condition-row .pmk135-remove-cond { align-self:center; justify-self:end; }
            .pmk135-status { font-size:.82rem; padding:.24rem .5rem; border-radius:999px; background:#eef1f3; color:#53606b; white-space:nowrap; }
            .pmk135-status.ok { background:#e8f5ec; color:#23643a; }
            .pmk135-status.warn { background:#fff4df; color:#7a5413; }
            .pmk135-status.err { background:#fbe8e8; color:#8b2c2c; }
            .pmk135-sourcebar { display:flex; align-items:center; gap:.45rem; margin-bottom:.65rem; flex-wrap:wrap; }
            .pmk135-sourcebar code { max-width:100%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
            .pmk135-toolbar { display:flex; flex-wrap:wrap; gap:.4rem; }
            .pmk135-toast { position:fixed; z-index:1110; right:1rem; bottom:1rem; max-width:min(420px, calc(100vw - 2rem)); padding:.7rem .9rem; background:#343a40; color:#fff; border-radius:.55rem; box-shadow:0 7px 28px rgba(0,0,0,.2); opacity:0; transform:translateY(8px); pointer-events:none; transition:.18s; }
            .pmk135-toast.is-visible { opacity:1; transform:translateY(0); }
            .pmk135-toast.success { background:#25633c; }
            .pmk135-toast.danger { background:#8b2c2c; }
            .pmk135-dialog-backdrop { position:fixed; inset:0; z-index:1105; background:rgba(19,25,30,.48); display:flex; align-items:center; justify-content:center; padding:1rem; }
            .pmk135-dialog { width:min(760px, 100%); max-height:90vh; overflow:auto; background:#fff; border-radius:.7rem; box-shadow:0 15px 60px rgba(0,0,0,.25); }
            .pmk135-dialog-head, .pmk135-dialog-foot { padding:.75rem .9rem; display:flex; align-items:center; gap:.5rem; }
            .pmk135-dialog-head { border-bottom:1px solid #e3e7ea; }
            .pmk135-dialog-head strong { flex:1; }
            .pmk135-dialog-body { padding:.9rem; }
            .pmk135-dialog-foot { border-top:1px solid #e3e7ea; justify-content:flex-end; }
            .pmk135-segment-list { display:flex; flex-direction:column; gap:.5rem; margin:.65rem 0; }
            .pmk135-segment-row { border:1px solid #e1e5e8; background:#fafbfc; border-radius:.5rem; padding:.55rem; }
            .pmk135-segment-head { display:flex; align-items:center; gap:.4rem; margin-bottom:.45rem; }
            .pmk135-segment-head strong { flex:1; }
            .pmk135-toggle-line { display:flex; align-items:center; gap:.45rem; margin:.45rem 0; }
            .pmk135-preview-controls { display:flex; flex-wrap:wrap; gap:.45rem; align-items:end; margin-bottom:.65rem; }
            .pmk135-preview-controls .pmk135-field { margin:0; min-width:140px; flex:1 1 150px; }
            .pmk135-real-preview { border:1px solid #dfe4e8; border-radius:.55rem; background:#fff; min-height:180px; padding:.75rem; overflow:auto; }
            .pmk136-live-preview-section { border-color:#c9d7ad; box-shadow:0 2px 9px rgba(82,109,34,.08); }
            .pmk136-live-preview-head { display:flex; align-items:center; gap:.55rem; margin-bottom:.55rem; }
            .pmk136-live-preview-head h4 { margin:0; flex:1; }
            .pmk136-live-preview-status { font-size:.78rem; color:#697680; white-space:nowrap; }
            .pmk136-live-preview { min-height:380px; max-height:58vh; padding:1rem; background:#fff; box-shadow:inset 0 0 0 1px rgba(0,0,0,.015); }
            .pmk136-live-preview [data-pmk-preview-node] { cursor:pointer; transition:outline-color .12s, box-shadow .12s, background-color .12s; }
            .pmk136-live-preview [data-pmk-preview-node]:hover { outline:2px dashed rgba(111,143,50,.65); outline-offset:2px; }
            .pmk136-live-preview [data-pmk-preview-selected="1"],
            .pmk136-live-preview .pmk136-preview-picked { outline:3px solid #6f8f32 !important; outline-offset:3px; box-shadow:0 0 0 6px rgba(111,143,50,.12); }
            .pmk136-live-preview-empty { min-height:300px; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; color:#697680; }
            .pmk136-live-preview-empty i { font-size:2.2rem; color:#91a567; margin-bottom:.65rem; }
            .pmk136-live-controls { display:grid; grid-template-columns:minmax(150px,220px) auto auto auto; gap:.45rem; align-items:end; margin-bottom:.65rem; }
            .pmk136-live-controls .pmk135-field { margin:0; }
            .pmk135-preview-compare { display:grid; grid-template-columns:1fr 1fr; gap:.65rem; }
            .pmk135-preview-column { min-width:0; border:1px solid #e1e5e8; border-radius:.5rem; background:#fff; padding:.55rem; }
            .pmk135-preview-column > strong { display:block; margin-bottom:.45rem; }
            .pmk135-result-list { margin-top:.55rem; display:flex; flex-direction:column; gap:.35rem; }
            .pmk135-result { display:flex; align-items:center; gap:.45rem; border:1px solid #e3e7ea; border-radius:.45rem; padding:.4rem .5rem; background:#fff; }
            .pmk135-result span { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
            .pmk135-style-buttons { display:flex; flex-wrap:wrap; gap:.35rem; }
            .pmk135-color { min-height:31px; padding:.12rem .2rem; }
            .pmk135-link-example { padding:.55rem; background:#f7f8fa; border-radius:.45rem; font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:.8rem; overflow-wrap:anywhere; }
            .pmk135-muted { color:#6c757d; }
            .pmk136-stepbar { display:flex; gap:.4rem; flex-wrap:wrap; padding:.65rem .75rem; border-bottom:1px solid #e1e6ea; background:#f8fafb; }
            .pmk136-stepbar button { border:1px solid #cfd7dd; background:#fff; border-radius:999px; padding:.38rem .7rem; color:#52606b; }
            .pmk136-stepbar button.is-active { background:#526d22; border-color:#526d22; color:#fff; font-weight:600; }
            .pmk136-stepbar button.is-done:not(.is-active) { border-color:#8aa252; color:#526d22; }
            .pmk136-validation { display:flex; flex-direction:column; gap:.45rem; }
            .pmk136-check { display:grid; grid-template-columns:24px 1fr; gap:.45rem; align-items:start; padding:.48rem .55rem; border:1px solid #e2e6e9; border-radius:.45rem; background:#fff; }
            .pmk136-check.ok i { color:#2f7d44; }
            .pmk136-check.warn i { color:#a66b00; }
            .pmk136-check.error i { color:#a52b2b; }
            .pmk136-check small { display:block; color:#697680; margin-top:.14rem; }
            .pmk136-project-status { font-size:.78rem; color:#6c757d; white-space:nowrap; }
            .pmk136-structure-controls { display:grid; grid-template-columns:1fr auto; gap:.4rem; margin-bottom:.55rem; }
            .pmk136-template-title { margin:.75rem 0 .35rem; padding:.28rem .4rem; border-left:3px solid #8aa252; color:#4d5d2c; font-size:.82rem; font-weight:700; background:#f6f9f0; cursor:pointer; user-select:none; }
            .pmk136-mode-simple .pmk136-advanced-only { display:none !important; }
            .pmk136-source-summary { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:.45rem; }
            .pmk136-source-summary > div { border:1px solid #e1e5e8; border-radius:.45rem; padding:.55rem; background:#fafbfc; }
            .pmk136-source-summary strong { display:block; font-size:.78rem; color:#6a747d; margin-bottom:.15rem; }
            @media (max-width: 1100px) {
                .pmk135-main { grid-template-columns:280px 1fr; }
                .pmk135-pane-inspector { grid-column:1 / -1; border-left:0 !important; border-top:1px solid #dfe3e7; max-height:44vh; }
            }
            @media (max-width: 760px) {
                .pmk135-topbar { flex-wrap:wrap; }
            .pmk136-navigation{background:#fff;border-bottom:1px solid #dfe3e7;padding:.35rem .85rem}
            .pmk136-navigation .pmk136-stepbar{margin:0}
            .pmk136-navigation button[aria-current=step]{font-weight:700}
            .pmk135-card:focus-visible{outline:3px solid #408540;outline-offset:2px}
                .pmk135-topbar .pmk135-spacer { display:none; }
                .pmk135-main { display:flex; flex-direction:column; overflow:auto; }
                .pmk135-pane { overflow:visible; }
                .pmk135-pane + .pmk135-pane { border-left:0; border-top:1px solid #dfe3e7; }
                .pmk135-pane-structure { max-height:42vh; }
                .pmk135-grid2, .pmk135-import-grid, .pmk135-preview-compare, .pmk136-live-controls { grid-template-columns:1fr; }
                .pmk135-condition-row { grid-template-columns:1fr 1fr; }
            }
        `;
        document.head.appendChild(styleNode);
    }

    function loadIndex() {
        try {
            const raw = localStorage.getItem(INDEX_KEY);
            const parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (_) {
            return [];
        }
    }

    function saveIndex(index) {
        localStorage.setItem(INDEX_KEY, JSON.stringify(index));
    }

    function saveProject(project) {
        if(!project || !project.id)return false;
        const key=STORAGE_PREFIX+project.id;
        const index=loadIndex();
        const now=new Date().toISOString();
        const meta={id:project.id,name:project.name || 'Projet XSLT',syspref:project.syspref || '',sourceUrl:project.sourceUrl || '',updatedAt:now};
        const position=index.findIndex(item=>item.id===project.id);
        if(position>=0)index[position]={...index[position],...meta};else index.push(meta);
        try {
            project.updatedAt=now;
            localStorage.setItem(key,JSON.stringify(project));
            saveIndex(index);unsavedProjects.delete(project.id);return true;
        } catch(error) {
            const first=!unsavedProjects.has(project.id);unsavedProjects.add(project.id);
            if(first)toast('Le navigateur ne peut pas enregistrer ce projet. Vos modifications restent ouvertes ; téléchargez une sauvegarde du projet.','warning');
            updateTopbarStatus();return false;
        }
    }

    function loadProject(id) {
        try {
            const raw = localStorage.getItem(STORAGE_PREFIX + id);
            return raw ? JSON.parse(raw) : null;
        } catch (_) {
            return null;
        }
    }

    function deleteProject(id) {
        localStorage.removeItem(STORAGE_PREFIX + id);
        saveIndex(loadIndex().filter(function (x) { return x.id !== id; }));
    }

    function defaultProject() {
        return {
            id: uid("project"),
            name: "Nouveau XSLT",
            syspref: "",
            sourceUrl: "",
            sourceXml: "",
            workingXml: "",
            dependencies: [],
            uiMode: "simple",
            activeStep: "source",
            previewRecords: [],
            previewBiblionumber: moduleConfig.defaultPreviewBiblio||"",
            previewAuthorityId: moduleConfig.defaultPreviewAuthority||"",
            previewSearchIndex: "kw",
            autoPreview: true,
            autoPreviewCompare: false,
            lastValidation: null,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
    }

    function parserError(doc) {
        if (!doc) return "Document XML absent.";
        const err = doc.getElementsByTagName("parsererror")[0];
        return err ? clean(err.textContent).slice(0, 500) : "";
    }

    function parseXml(xml) {
        const doc = new DOMParser().parseFromString(String(xml || ""), "application/xml");
        const error = parserError(doc);
        if (error) throw new Error("XML/XSLT invalide : " + error);
        if (!doc.documentElement) throw new Error("Document XML vide.");
        return doc;
    }

    function ensureNamespaces(doc) {
        if (!doc || !doc.documentElement) return;
        // Namespace declarations are namespace nodes, not ordinary attributes.
        // Repair declarations created by previous versions without XMLNS_NS.
        Array.from(doc.getElementsByTagName("*")).forEach(function (el) {
            Array.from(el.attributes || []).forEach(function (attr) {
                if ((attr.name === "xmlns" || attr.name.indexOf("xmlns:") === 0) && attr.namespaceURI !== XMLNS_NS) {
                    const name = attr.name, value = attr.value;
                    el.removeAttributeNode(attr);
                    el.setAttributeNS(XMLNS_NS, name, value);
                }
            });
        });
        const root = doc.documentElement;
        if (!root.lookupNamespaceURI("xsl")) root.setAttributeNS(XMLNS_NS, "xmlns:xsl", XSL_NS);
        if (!root.lookupNamespaceURI("marc")) root.setAttributeNS(XMLNS_NS, "xmlns:marc", MARC_NS);
    }

    function annotate(doc) {
        if (!doc) return;
        let n = 0;
        Array.from(doc.getElementsByTagName("*")).forEach(function (el) {
            if (el.namespaceURI === XSL_NS) return;
            if (!el.getAttribute("data-pmk-xslt-node")) {
                n += 1;
                el.setAttribute("data-pmk-xslt-node", "node-" + n + "-" + Math.random().toString(36).slice(2, 5));
            }
        });
    }

    function marcRefFromXPath(select) {
        const raw = String(select || "");
        const tagMatch = raw.match(/(?:marc:)?datafield\s*\[\s*@tag\s*=\s*['\"]([^'\"]+)['\"]\s*\]/i);
        const subMatch = raw.match(/(?:marc:)?subfield\s*\[\s*@code\s*=\s*['\"]([^'\"]+)['\"]\s*\]/i);
        if (!tagMatch) return null;
        return { tag: tagMatch[1], subfield: subMatch ? subMatch[1] : "", select: raw };
    }

    function directMarcRefs(node) {
        if (!node) return [];
        const refs = [];
        Array.from(node.childNodes || []).forEach(function (child) {
            if (child.nodeType !== 1 || child.namespaceURI !== XSL_NS) return;
            if (child.localName === "value-of" || child.localName === "copy-of" || child.localName === "for-each") {
                const ref = marcRefFromXPath(child.getAttribute("select"));
                if (ref) refs.push({ element: child, tag: ref.tag, subfield: ref.subfield, select: ref.select });
            }
        });
        return refs;
    }

    function descendantMarcRefs(node) {
        if (!node) return [];
        const refs = [];
        ["value-of", "copy-of", "for-each"].forEach(function (name) {
            Array.from(node.getElementsByTagNameNS(XSL_NS, name)).forEach(function (el) {
                const ref = marcRefFromXPath(el.getAttribute("select"));
                if (ref) refs.push({ element: el, tag: ref.tag, subfield: ref.subfield, select: ref.select });
            });
        });
        return refs;
    }

    function directStaticText(node) {
        if (!node) return "";
        return Array.from(node.childNodes || []).filter(function (child) {
            return child.nodeType === 3;
        }).map(function (child) { return child.nodeValue || ""; }).join("");
    }

    function directLiteralChildren(node) {
        return Array.from(node && node.children || []).filter(function (child) { return child.namespaceURI !== XSL_NS; });
    }

    function importedConditionFor(node) {
        if (!node || !node.parentElement) return null;
        const p = node.parentElement;
        if (p.namespaceURI !== XSL_NS || p.localName !== "if") return null;
        const literalDirect = Array.from(p.children || []).filter(function (child) { return child.namespaceURI !== XSL_NS; });
        return literalDirect.length === 1 && literalDirect[0] === node ? p : null;
    }

    function inferHrefTemplate(anchor) {
        if (!anchor) return "";
        const literal = anchor.getAttribute("href");
        if (literal) return literal;
        const attr = Array.from(anchor.children || []).find(function (child) {
            return child.namespaceURI === XSL_NS && child.localName === "attribute" && child.getAttribute("name") === "href";
        });
        if (!attr) return "";
        let out = "";
        Array.from(attr.childNodes || []).forEach(function (child) {
            if (child.nodeType === 3) out += child.nodeValue || "";
            else if (child.nodeType === 1 && child.namespaceURI === XSL_NS && child.localName === "value-of") {
                const ref = marcRefFromXPath(child.getAttribute("select"));
                out += ref ? "{" + ref.tag + "$" + ref.subfield + "}" : "{XPath:" + (child.getAttribute("select") || "") + "}";
            } else if (child.nodeType === 1 && child.namespaceURI === XSL_NS && child.localName === "text") {
                out += child.textContent || "";
            }
        });
        return out;
    }

    function inferAnchorMeta(anchor) {
        const href = inferHrefTemplate(anchor);
        const meta = {
            enabled: true, mode: "fixed", index: "kw", queryType: "contains", valueTemplate: "{200$a}",
            externalTemplate: "", fixedUrl: href, target: anchor && anchor.getAttribute("target") === "_blank" ? "new" : "same",
            missingBehavior: "plain", conditionXPath: "", searchBase: "/cgi-bin/koha/catalogue/search.pl", queryPrefix: "", querySuffix: ""
        };
        if (!href) return meta;
        const koha = href.match(/^(.*\/catalogue\/search\.pl)\?[^#]*\bidx=([^&]+)&q=(.*)$/i);
        if (koha) {
            meta.mode = "koha";
            meta.searchBase = koha[1];
            meta.index = decodeURIComponent(koha[2]);
            meta.valueTemplate = decodeURIComponent(koha[3]).replace(/^%22|%22$/g, '"').replace(/^"|"$/g, "");
            meta.queryType = /%22|^"/.test(koha[3]) ? "exact" : (/\*$/.test(meta.valueTemplate) ? "starts" : "contains");
            meta.valueTemplate = meta.valueTemplate.replace(/\*$/, "");
        } else if (/\{[0-9A-Za-z]{3}\$[0-9A-Za-z]\}/.test(href)) {
            meta.mode = "external";
            meta.externalTemplate = href;
        }
        return meta;
    }

    function recognitionTitle(node) {
        if (!node) return "Élément";
        const customName = clean(node.getAttribute("data-pmk-xslt-display-name"));
        if (customName) return customName;
        const kind = node.getAttribute("data-pmk-xslt-kind") || "advanced";
        const text = clean(directStaticText(node)) || clean(Array.from(node.children || []).filter(function (el) { return el.namespaceURI === XSL_NS && el.localName === "text"; }).map(function (el) { return el.textContent; }).join(" "));
        const textLabel = text.replace(/[:;\s]+$/, "").slice(0, 65);
        const tag = (node.localName || "").toLowerCase();
        if (kind === "button") return "Bouton" + (textLabel ? " — " + textLabel : " d’action");
        if (kind === "link") return "Lien" + (textLabel ? " — " + textLabel : " cliquable");
        if (kind === "image") return "Image" + (node.getAttribute("alt") ? " — " + node.getAttribute("alt") : "");
        if (textLabel) return textLabel;
        const tokens = ((node.getAttribute("class") || "") + " " + (node.getAttribute("id") || "")).toLowerCase().split(/[\s_-]+/);
        const names = { title: "Titre", titre: "Titre", author: "Auteurs", authors: "Auteurs", auteur: "Auteurs", publisher: "Éditeur", publication: "Publication", series: "Collection", collection: "Collection", abstract: "Résumé", summary: "Résumé", notes: "Notes", subjects: "Sujets", subject: "Sujets", holdings: "Exemplaires", items: "Exemplaires", isbn: "ISBN", issn: "ISSN" };
        for (const token of tokens) if (names[token]) return names[token];
        const refs = descendantMarcRefs(node);
        const tags = Array.from(new Set(refs.map(function (r) { return r.tag; })));
        const marcNames = { "200": "Titre", "210": "Publication", "214": "Publication", "215": "Description matérielle", "225": "Collection", "330": "Résumé", "461": "Ensemble", "700": "Auteur", "701": "Auteurs", "702": "Autres responsabilités", "710": "Collectivité", "711": "Collectivités", "712": "Autres collectivités", "010": "ISBN", "011": "ISSN" };
        if (tags.length === 1 && marcNames[tags[0]]) return marcNames[tags[0]];
        if (tags.length && tags.every(function (t) { return ["700", "701", "702"].includes(t); })) return "Auteurs et responsabilités";
        if (kind === "field" && refs.length) return "Donnée MARC " + refs[0].tag + (refs[0].subfield ? "$" + refs[0].subfield : "");
        const types = { composite: "Plusieurs données regroupées", custom: "Encadré de texte", group: "Titre de section", "group-label": "Titre de section", spacer: "Espace vertical", text: "Texte", separator: "Ligne de séparation", container: "Groupe d’éléments", icon: "Icône", advanced: "Élément à réglages techniques" };
        return types[kind] || (tag === "div" ? "Section de l’affichage" : "Élément de l’affichage");
    }

    function recognizeLiteralNode(node) {
        if (!node || node.namespaceURI === XSL_NS) return;
        let kind = "advanced";
        let confidence = "advanced";
        const tag = String(node.localName || "").toLowerCase();
        const directRefs = directMarcRefs(node);
        const allRefs = descendantMarcRefs(node);
        const literalKids = directLiteralChildren(node);
        const hasXslt = Array.from(node.getElementsByTagNameNS(XSL_NS, "*")).length > 0;
        const staticText = clean(directStaticText(node));

        if (node.getAttribute("data-pmk-xslt-generic") === "custom-block") { kind = "custom"; confidence = "recognized"; }
        else if (node.getAttribute("data-pmk-xslt-composite")) { kind = "composite"; confidence = "recognized"; }
        else if (node.getAttribute("data-pmk-xslt-segment")) { kind = directRefs.length ? "field" : "text"; confidence = "recognized"; }
        else if (node.getAttribute("data-pmk-xslt-generic")) { kind = node.getAttribute("data-pmk-xslt-generic") || "container"; confidence = "recognized"; }
        else if (tag === "img") { kind = "image"; confidence = "recognized"; }
        else if (tag === "hr") { kind = "separator"; confidence = "recognized"; }
        else if (tag === "button" || (tag === "input" && /button|submit/i.test(node.getAttribute("type") || ""))) { kind = "button"; confidence = "recognized"; }
        else if (tag === "i" && /(?:^|\s)(?:fa|fas|far|fab)(?:\s|$)/.test(node.getAttribute("class") || "")) { kind = "icon"; confidence = "recognized"; }
        else if (tag === "a") { kind = "link"; confidence = "recognized"; if (!node.getAttribute("data-pmk-xslt-link-meta")) setJsonAttr(node, "data-pmk-xslt-link-meta", inferAnchorMeta(node)); }
        else if (/^h[1-6]$/.test(tag) || tag === "legend") { kind = "group"; confidence = allRefs.length <= 1 ? "recognized" : "partial"; }
        else if (directRefs.length === 1 && literalKids.length === 0) { kind = "field"; confidence = "recognized"; }
        else if (directRefs.length > 1 && literalKids.length === 0) { kind = "composite"; confidence = "recognized"; }
        else if (allRefs.length > 1) { kind = "composite"; confidence = literalKids.length <= 2 ? "partial" : "advanced"; }
        else if (allRefs.length === 1) { kind = "field"; confidence = literalKids.length === 0 ? "recognized" : "partial"; }
        else if (!hasXslt && literalKids.length === 0 && staticText) { kind = "text"; confidence = "recognized"; }
        else if (literalKids.length > 0) { kind = "container"; confidence = hasXslt ? "partial" : "recognized"; }
        else if (!hasXslt) { kind = "container"; confidence = "recognized"; }

        node.setAttribute("data-pmk-xslt-kind", kind);
        node.setAttribute("data-pmk-xslt-recognition", confidence);
        const importedIf = importedConditionFor(node);
        if (importedIf && !importedIf.getAttribute("data-pmk-xslt-condition-for")) {
            importedIf.setAttribute("data-pmk-xslt-condition-for", node.getAttribute("data-pmk-xslt-node"));
            importedIf.setAttribute("data-pmk-xslt-imported-condition", "1");
        }
        if (kind === "field" && directRefs[0]) {
            setJsonAttr(node, "data-pmk-xslt-imported-field", { tag: directRefs[0].tag, subfield: directRefs[0].subfield, select: directRefs[0].select });
        }
    }

    function recognizeVisualDocument(doc) {
        if (!doc) return { recognized: 0, partial: 0, advanced: 0, total: 0 };
        annotate(doc);
        const nodes = Array.from(doc.getElementsByTagName("*")).filter(function (el) { return el.namespaceURI !== XSL_NS && el.hasAttribute("data-pmk-xslt-node"); });
        nodes.forEach(recognizeLiteralNode);
        const stats = { recognized: 0, partial: 0, advanced: 0, total: nodes.length };
        nodes.forEach(function (node) {
            const state = node.getAttribute("data-pmk-xslt-recognition") || "advanced";
            if (state === "recognized") stats.recognized += 1;
            else if (state === "partial") stats.partial += 1;
            else stats.advanced += 1;
        });
        if (currentProject) {
            currentProject.visualRecognition = stats;
            currentProject.visualAnalyzedAt = new Date().toISOString();
        }
        return stats;
    }

    function restorePmkMetadataComments(doc) {
        if (!doc) return;
        const walker = doc.createTreeWalker(doc, NodeFilter.SHOW_COMMENT);
        const comments = [];
        let c;
        while ((c = walker.nextNode())) comments.push(c);
        comments.forEach(function (comment) {
            const text = String(comment.nodeValue || "").trim();
            if (text.indexOf("PMK135:") !== 0) return;
            let meta = null;
            try { meta = JSON.parse(decodeURIComponent(text.slice(7))); } catch (_) { return; }
            let target = comment.nextSibling;
            while (target && target.nodeType !== 1) target = target.nextSibling;
            if (!target || target.namespaceURI === XSL_NS) return;
            Object.keys(meta || {}).forEach(function (key) {
                if (key.indexOf("data-pmk-xslt-") === 0 && key !== "data-pmk-xslt-node") target.setAttribute(key, meta[key]);
            });
            comment.remove();
        });
    }

    function addPmkMetadataComments(doc) {
        const copy = doc.cloneNode(true);
        Array.from(copy.getElementsByTagName("*")).forEach(function (el) {
            if (el.namespaceURI === XSL_NS || !el.parentNode) return;
            const meta = {};
            Array.from(el.attributes || []).forEach(function (attr) {
                if (/^data-pmk-xslt-/.test(attr.name) && attr.name !== "data-pmk-xslt-node" && !/^data-pmk-xslt-recognition$/.test(attr.name) && !/^data-pmk-xslt-kind$/.test(attr.name)) meta[attr.name] = attr.value;
            });
            if (!Object.keys(meta).length) return;
            el.parentNode.insertBefore(copy.createComment("PMK135:" + encodeURIComponent(JSON.stringify(meta))), el);
        });
        return copy;
    }

    function stripInternal(doc) {
        const copy = doc.cloneNode(true);
        Array.from(copy.getElementsByTagName("*")).forEach(function (el) {
            Array.from(el.attributes || []).forEach(function (attr) {
                if (/^data-pmk-xslt-/i.test(attr.name)) el.removeAttribute(attr.name);
            });
        });
        const walker = copy.createTreeWalker(copy, NodeFilter.SHOW_COMMENT);
        const comments = [];
        while (walker.nextNode()) if (/^PMK(?:135|136):/.test(walker.currentNode.nodeValue || "")) comments.push(walker.currentNode);
        comments.forEach(function (comment) { comment.remove(); });
        return copy;
    }

    function serializeDoc(doc, cleanOutput) {
        const target = cleanOutput ? stripInternal(doc) : doc;
        let xml = new XMLSerializer().serializeToString(target);
        if (!/^\s*<\?xml\b/.test(xml)) xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml;
        return xml;
    }

    function getLiteralNodes() {
        if (!workingDoc) return [];
        return Array.from(workingDoc.getElementsByTagName("*")).filter(function (el) {
            return el.namespaceURI !== XSL_NS && el.hasAttribute("data-pmk-xslt-node");
        });
    }

    function findNode(id) {
        if (!workingDoc || !id) return null;
        return getLiteralNodes().find(function (el) { return el.getAttribute("data-pmk-xslt-node") === id; }) || null;
    }

    function literalDepth(node) {
        let depth = 0;
        let p = node.parentElement;
        while (p) {
            if (p.namespaceURI !== XSL_NS) depth += 1;
            p = p.parentElement;
        }
        return depth;
    }

    function nodeSummary(node) {
        const refs = descendantMarcRefs(node);
        const fields = Array.from(new Set(refs.map(function (r) { return r.tag + (r.subfield ? "$" + r.subfield : ""); })));
        const parts = [];
        if (fields.length) parts.push("Données : " + fields.slice(0, 5).join(", ") + (fields.length > 5 ? "…" : ""));
        const text = clean(directStaticText(node));
        if (text) parts.push('Texte : « ' + text.slice(0, 65) + ' »');
        if (!parts.length) {
            const count = directLiteralChildren(node).length;
            if (count) parts.push(count + " élément(s) regroupé(s)");
            else if (node.localName === "img") parts.push(node.getAttribute("alt") || "Image de l’affichage");
            else parts.push("Cliquez pour modifier cet élément");
        }
        return parts.join(" · ");
    }

    function conditionWrapperFor(node) {
        if (!node || !node.parentElement) return null;
        const p = node.parentElement;
        if (p.namespaceURI === XSL_NS && p.localName === "if" && p.getAttribute("data-pmk-xslt-condition-for") === node.getAttribute("data-pmk-xslt-node")) return p;
        return null;
    }

    function movableUnit(node) {
        return conditionWrapperFor(node) || node;
    }

    function movableParent(node) {
        const unit = movableUnit(node);
        return unit ? unit.parentNode : null;
    }

    function getConditionMeta(node) {
        const wrapper = conditionWrapperFor(node);
        if (!wrapper) return { enabled: false, join: "and", rules: [] };
        try {
            const raw = wrapper.getAttribute("data-pmk-xslt-condition-meta");
            if (raw) return JSON.parse(decodeURIComponent(raw));
        } catch (_) {}
        return { enabled: true, join: "and", rules: [{ source: "xpath", xpath: wrapper.getAttribute("test") || "", operator: "custom", value: "" }] };
    }

    function fieldXPath(tag, subfield) {
        tag = clean(tag).replace(/[^0-9A-Za-z]/g, "");
        subfield = clean(subfield).replace(/[^0-9A-Za-z]/g, "");
        if (!tag) return "";
        let path = "(ancestor-or-self::marc:record[1] | descendant::marc:record[1])[1]/marc:datafield[@tag='" + tag + "']";
        if (subfield) path += "/marc:subfield[@code='" + subfield + "']";
        return path;
    }

    function retargetMarcXPath(expression,tag,subfield) {
        const field=/((?:[A-Za-z_][\w.-]*:)?datafield\s*\[\s*@tag\s*=\s*)(['"])([^'"]*)\2(\s*\])/;
        const code=/((?:[A-Za-z_][\w.-]*:)?subfield\s*\[\s*@code\s*=\s*)(['"])([^'"]*)\2(\s*\])/;
        const original=String(expression || '');
        if(!field.test(original))return original;
        let result=original.replace(field,(_,prefix,quote,old,suffix)=>prefix+quote+tag+quote+suffix);
        if(subfield && code.test(result))result=result.replace(code,(_,prefix,quote,old,suffix)=>prefix+quote+subfield+quote+suffix);
        else if(subfield)result=result.replace(field,match=>match+"/marc:subfield[@code='"+subfield+"']");
        else result=result.replace(/\/(?:[A-Za-z_][\w.-]*:)?subfield\s*\[\s*@code\s*=\s*(['"])[^'"]*\1\s*\]/,'');
        return result;
    }

    function quoteXPathLiteral(value) {
        value = String(value == null ? "" : value);
        if (value.indexOf("'") === -1) return "'" + value + "'";
        if (value.indexOf('"') === -1) return '"' + value + '"';
        return "concat('" + value.split("'").join("',\"'\",'") + "')";
    }

    function conditionRuleToXPath(rule) {
        const source = rule.source === "xpath" ? clean(rule.xpath) : fieldXPath(rule.tag, rule.subfield);
        if (!source) return "";
        const op = rule.operator || "not-empty";
        const value = quoteXPathLiteral(rule.value || "");
        switch (op) {
            case "empty": return "not(normalize-space(string(" + source + ")))";
            case "equals": return "normalize-space(string(" + source + ")) = " + value;
            case "not-equals": return "normalize-space(string(" + source + ")) != " + value;
            case "contains": return "contains(normalize-space(string(" + source + ")), " + value + ")";
            case "starts-with": return "starts-with(normalize-space(string(" + source + ")), " + value + ")";
            case "exists": return "boolean(" + source + ")";
            case "custom": return source;
            case "not-empty":
            default: return "normalize-space(string(" + source + ")) != ''";
        }
    }

    function applyCondition(node, meta) {
        if (!node) return;
        let wrapper = conditionWrapperFor(node);
        if (!meta || !meta.enabled || !Array.isArray(meta.rules) || !meta.rules.length) {
            if (wrapper && wrapper.parentNode) {
                wrapper.parentNode.insertBefore(node, wrapper);
                wrapper.remove();
            }
            return;
        }
        const expressions = meta.rules.map(conditionRuleToXPath).filter(Boolean);
        if (!expressions.length) {
            if (wrapper && wrapper.parentNode) {
                wrapper.parentNode.insertBefore(node, wrapper);
                wrapper.remove();
            }
            return;
        }
        const join = meta.join === "or" ? " or " : " and ";
        const test = expressions.map(function (x) { return "(" + x + ")"; }).join(join);
        if (!wrapper) {
            wrapper = workingDoc.createElementNS(XSL_NS, "xsl:if");
            wrapper.setAttribute("data-pmk-xslt-condition-for", node.getAttribute("data-pmk-xslt-node"));
            const parent = node.parentNode;
            parent.insertBefore(wrapper, node);
            wrapper.appendChild(node);
        }
        wrapper.setAttribute("test", test);
        wrapper.setAttribute("data-pmk-xslt-condition-meta", encodeURIComponent(JSON.stringify(meta)));
    }

    function parseStyle(styleText) {
        const out = {};
        String(styleText || "").split(";").forEach(function (part) {
            const idx = part.indexOf(":");
            if (idx < 0) return;
            const key = clean(part.slice(0, idx)).toLowerCase();
            const value = clean(part.slice(idx + 1));
            if (key && value) out[key] = value;
        });
        return out;
    }

    function writeStyle(node, map) {
        const text = Object.keys(map || {}).filter(function (key) { return clean(map[key]); }).map(function (key) {
            return key + ": " + clean(map[key]);
        }).join("; ");
        if (text) node.setAttribute("style", text + ";");
        else node.removeAttribute("style");
    }

    function setStyleValue(node, key, value) {
        const map = parseStyle(node.getAttribute("style") || "");
        if (clean(value)) map[key] = clean(value); else delete map[key];
        writeStyle(node, map);
    }

    function getStyleValue(node, key) {
        return parseStyle(node.getAttribute("style") || "")[key] || "";
    }

    function getJsonAttr(node, name, fallback) {
        try {
            const raw = node && node.getAttribute(name);
            return raw ? JSON.parse(decodeURIComponent(raw)) : clone(fallback);
        } catch (_) {
            return clone(fallback);
        }
    }

    function setJsonAttr(node, name, value) {
        if (!node) return;
        if (value == null) node.removeAttribute(name);
        else node.setAttribute(name, encodeURIComponent(JSON.stringify(value)));
    }

    function templateParts(template) {
        const parts = [];
        const rx = /\{([0-9A-Za-z]{3})\$([0-9A-Za-z])\}/g;
        let last = 0;
        let match;
        while ((match = rx.exec(String(template || "")))) {
            if (match.index > last) parts.push({ type: "text", value: template.slice(last, match.index) });
            parts.push({ type: "field", tag: match[1], subfield: match[2], xpath: fieldXPath(match[1], match[2]) + "[1]" });
            last = rx.lastIndex;
        }
        if (last < String(template || "").length) parts.push({ type: "text", value: String(template || "").slice(last) });
        return parts;
    }

    function linkConditionFromTemplate(template) {
        const fields = templateParts(template).filter(function (p) { return p.type === "field"; });
        if (!fields.length) return "true()";
        return fields.map(function (p) { return "normalize-space(string(" + p.xpath + ")) != ''"; }).join(" and ");
    }

    function appendTemplateTo(node, template) {
        templateParts(template).forEach(function (part) {
            if (part.type === "text") node.appendChild(workingDoc.createTextNode(part.value));
            else {
                const value = workingDoc.createElementNS(XSL_NS, "xsl:value-of");
                value.setAttribute("select", part.xpath);
                node.appendChild(value);
            }
        });
    }

    function directLinkWrapper(node) {
        if (!node) return null;
        return Array.from(node.childNodes || []).find(function (child) {
            return child.nodeType === 1 && child.namespaceURI !== XSL_NS && child.localName === "a" && child.getAttribute("data-pmk-xslt-link-wrap") === "1";
        }) || null;
    }

    function unwrapLink(node) {
        const link = directLinkWrapper(node);
        if (!link) return;
        Array.from(link.childNodes).forEach(function (child) {
            if (child.nodeType === 1 && child.getAttribute && child.getAttribute("data-pmk-xslt-link-generated") === "1") child.remove();
            else node.insertBefore(child, link);
        });
        link.remove();
    }

    function getLinkMeta(node) {
        if (node && node.localName === "a" && node.namespaceURI !== XSL_NS && !node.getAttribute("data-pmk-xslt-link-meta")) {
            return inferAnchorMeta(node);
        }
        return getJsonAttr(node, "data-pmk-xslt-link-meta", {
            enabled: false,
            mode: "koha",
            index: "kw",
            queryType: "contains",
            valueTemplate: "{200$a}",
            externalTemplate: "https://example.org/?q={200$a}",
            fixedUrl: "",
            target: "same",
            missingBehavior: "plain",
            conditionXPath: "",
            searchBase: "/cgi-bin/koha/catalogue/search.pl",
            queryPrefix: "",
            querySuffix: ""
        });
    }

    function buildHrefTemplate(meta) {
        if (meta.mode === "fixed") return clean(meta.fixedUrl);
        if (meta.mode === "external") return String(meta.externalTemplate || "");
        const index = clean(meta.index) || "kw";
        const q = String(meta.valueTemplate || "{200$a}");
        let before = clean(meta.searchBase) || "/cgi-bin/koha/catalogue/search.pl";
        before += "?idx=" + index + "&q=";
        let after = "";
        if (meta.queryType === "exact") { before += "%22"; after = "%22"; }
        else if (meta.queryType === "starts") after = "*";
        else if (meta.queryType === "custom") { before += String(meta.queryPrefix || ""); after = String(meta.querySuffix || ""); }
        return before + q + after;
    }

    function applyLink(node, meta) {
        if (!node) return;
        if (node.localName === "a" && node.namespaceURI !== XSL_NS && !node.getAttribute("data-pmk-xslt-link-wrap")) {
            Array.from(node.children || []).filter(function (child) {
                return child.namespaceURI === XSL_NS && child.localName === "attribute" && child.getAttribute("name") === "href";
            }).forEach(function (child) { child.remove(); });
            node.removeAttribute("href");
            if (!meta || !meta.enabled) { node.removeAttribute("data-pmk-xslt-link-meta"); saveWorking(); return; }
            if (meta.target === "new") { node.setAttribute("target", "_blank"); node.setAttribute("rel", "noopener noreferrer"); }
            else { node.removeAttribute("target"); node.removeAttribute("rel"); }
            const template = buildHrefTemplate(meta);
            const hasDynamic = /\{[0-9A-Za-z]{3}\$[0-9A-Za-z]\}/.test(template);
            if (hasDynamic) {
                const attr = workingDoc.createElementNS(XSL_NS, "xsl:attribute"); attr.setAttribute("name", "href"); appendTemplateTo(attr, template); node.insertBefore(attr, node.firstChild);
            } else if (clean(template)) node.setAttribute("href", clean(template));
            setJsonAttr(node, "data-pmk-xslt-link-meta", meta);
            return;
        }
        unwrapLink(node);
        node.removeAttribute("data-pmk-xslt-link-meta");
        if (!meta || !meta.enabled) return;

        const content = Array.from(node.childNodes);
        const anchor = workingDoc.createElement("a");
        anchor.setAttribute("data-pmk-xslt-link-wrap", "1");
        if (meta.target === "new") {
            anchor.setAttribute("target", "_blank");
            anchor.setAttribute("rel", "noopener noreferrer");
        }
        content.forEach(function (child) { anchor.appendChild(child); });
        node.appendChild(anchor);

        const template = buildHrefTemplate(meta);
        const hasDynamic = /\{[0-9A-Za-z]{3}\$[0-9A-Za-z]\}/.test(template);
        if (!hasDynamic) {
            if (clean(template)) anchor.setAttribute("href", clean(template));
        } else {
            let cond = linkConditionFromTemplate(template);
            if (clean(meta.conditionXPath)) cond = "(" + cond + ") and (" + clean(meta.conditionXPath) + ")";
            const conditional = workingDoc.createElementNS(XSL_NS, "xsl:if");
            conditional.setAttribute("test", cond);
            conditional.setAttribute("data-pmk-xslt-link-generated", "1");
            const attr = workingDoc.createElementNS(XSL_NS, "xsl:attribute");
            attr.setAttribute("name", "href");
            appendTemplateTo(attr, template);
            conditional.appendChild(attr);
            anchor.insertBefore(conditional, anchor.firstChild);
            if (meta.missingBehavior === "hide") {
                const hideIf = workingDoc.createElementNS(XSL_NS, "xsl:if");
                hideIf.setAttribute("test", "not(" + cond + ")");
                hideIf.setAttribute("data-pmk-xslt-link-generated", "1");
                const styleAttr = workingDoc.createElementNS(XSL_NS, "xsl:attribute");
                styleAttr.setAttribute("name", "style");
                styleAttr.appendChild(workingDoc.createTextNode("display:none"));
                hideIf.appendChild(styleAttr);
                anchor.insertBefore(hideIf, anchor.firstChild);
            }
        }
        setJsonAttr(node, "data-pmk-xslt-link-meta", meta);
    }

    function getIconMeta(node) {
        return getJsonAttr(node, "data-pmk-xslt-icon-meta", { type: "none", value: "", position: "before", size: "" });
    }

    function clearDecorations(node) {
        Array.from(node.querySelectorAll('[data-pmk-xslt-decoration="1"]')).forEach(function (el) { el.remove(); });
    }

    function applyIcon(node, meta) {
        clearDecorations(node);
        node.removeAttribute("data-pmk-xslt-icon-meta");
        if (!meta || meta.type === "none" || !clean(meta.value)) return;
        let el;
        if (meta.type === "image") {
            el = workingDoc.createElement("img");
            el.setAttribute("src", clean(meta.value));
            el.setAttribute("alt", "");
            if (clean(meta.size)) {
                el.setAttribute("width", clean(meta.size));
                el.setAttribute("height", clean(meta.size));
            }
        } else {
            el = workingDoc.createElement("i");
            el.setAttribute("class", clean(meta.value));
            el.setAttribute("aria-hidden", "true");
            if (clean(meta.size)) el.setAttribute("style", "font-size:" + clean(meta.size) + "px;");
        }
        el.setAttribute("data-pmk-xslt-decoration", "1");
        if (meta.position === "after") node.appendChild(el);
        else node.insertBefore(el, node.firstChild);
        setJsonAttr(node, "data-pmk-xslt-icon-meta", meta);
    }

    function normalizePreviewProject() {
        if (!currentProject) return;
        normalizeProjectState(currentProject);
    }

    function currentPageRecordId(kind) {
        try {
            const params = new URL(window.location.href).searchParams;
            return kind === "authority" ? (params.get("authid") || params.get("authority_id") || "") : (params.get("biblionumber") || "");
        } catch (_) { return ""; }
    }

    async function fetchMarcXml(recordId, kind) {
        kind = kind === "authority" ? "authority" : "biblio";
        const id = clean(recordId).replace(/\D/g, "");
        if (!id) throw new Error(kind === "authority" ? "Numéro d’autorité invalide." : "Numéro de notice invalide.");
        const urls = kind === "authority"
            ? [(moduleConfig.marcApiBase||"/api/v1")+"/authorities/"+id]
            : [(moduleConfig.marcApiBase||"/api/v1")+"/biblios/"+id,(moduleConfig.marcApiBase||"/api/v1")+"/public/biblios/"+id];
        let lastError = "";
        for (const url of urls) {
            try {
                const controller=new AbortController();
                const timeout=setTimeout(()=>controller.abort(),Math.max(1000,Math.min(180000,Number(moduleConfig.previewTimeoutMs)||15000)));
                try {
                const response = await fetch(url, {
                    signal:controller.signal,
                    credentials: "same-origin",
                    cache: "no-store",
                    headers: { "Accept": "application/marcxml+xml" }
                });
                if (!response.ok) { lastError = "HTTP " + response.status; continue; }
                const text = await response.text();
                const doc = parseXml(text);
                if (doc.documentElement) return doc;
                } finally {clearTimeout(timeout);}
            } catch (e) { lastError = e.name==='AbortError'?'Délai de réponse dépassé':e.message; }
        }
        throw new Error("Impossible de récupérer le MARCXML " + (kind === "authority" ? "de l’autorité " : "de la notice ") + id + (lastError ? " : " + lastError : ""));
    }

    function fetchMarcXmlCached(recordId,kind,force) {
        kind=kind==='authority'?'authority':'biblio';
        const id=clean(recordId).replace(/\D/g,'');const key=kind+':'+id;
        if(!force && marcPreviewCache.has(key))return marcPreviewCache.get(key);
        const request=fetchMarcXml(id,kind);marcPreviewCache.set(key,request);
        request.catch(()=>{if(marcPreviewCache.get(key)===request)marcPreviewCache.delete(key);});
        return request;
    }

    function parsePreviewUriCall(expression, node) {
        const text = clean(expression);
        const match = text.match(/^([A-Za-z_][\w.-]*):encode-uri\s*\(/);
        if (!match || node.lookupNamespaceURI(match[1]) !== "http://exslt.org/strings") return null;
        const args = []; let start = match[0].length, depth = 0, quote = "";
        for (let i = start; i < text.length; i += 1) {
            const c = text[i];
            if (quote) { if (c === quote) quote = ""; continue; }
            if (c === "'" || c === '"') { quote = c; continue; }
            if (c === "(") { depth += 1; continue; }
            if (c === ")") {
                if (depth) { depth -= 1; continue; }
                if (clean(text.slice(i + 1))) return null;
                args.push(clean(text.slice(start, i)));
                return args;
            }
            if (c === "," && depth === 0) { args.push(clean(text.slice(start, i))); start = i + 1; }
        }
        return null;
    }

    function adaptUriEncodingForPreview(doc) {
        const markers = [];
        Array.from(doc.getElementsByTagNameNS(XSL_NS, "value-of")).forEach(function (node) {
            const args = parsePreviewUriCall(node.getAttribute("select") || "", node);
            if (!args) return;
            if (args.length < 2 || args.length > 3 || args.some(function (arg) { return !arg; })) throw new Error("Appel str:encode-uri non reconnu pour l’aperçu.");
            if (args.length === 3 && !/^(['"])utf-8\1$/i.test(args[2])) throw new Error("L’aperçu de str:encode-uri prend en charge l’encodage UTF-8. Le XSLT final conserve sa fonction d’origine.");
            const token = uid("pmk136uri");
            const start = "__" + token + "_start__", end = "__" + token + "_end__";
            // The browser evaluates the original XPath in the original context.
            // JS applies URI encoding to the result, after transformation only.
            // boolean(arg2) also preserves old Koha calls using 'UTF-8' as arg2.
            node.setAttribute("select", "concat('" + start + "', substring('01', 1 + number(boolean(" + args[1] + ")), 1), '_', string(" + args[0] + "), '" + end + "')");
            markers.push({ start: start, end: end });
        });
        return markers;
    }

    function finishUriEncodingPreview(fragment, markers) {
        if (!fragment || !markers || !markers.length) return fragment;
        function finish(value) {
            let result = String(value || "");
            markers.forEach(function (marker) {
                let position = 0;
                while (position < result.length) {
                    const begin = result.indexOf(marker.start, position);
                    if (begin < 0) break;
                    const content = begin + marker.start.length;
                    const end = result.indexOf(marker.end, content + 2);
                    if (end < 0) break;
                    const flag = result.slice(content, content + 2);
                    if (flag !== "0_" && flag !== "1_") { position = content; continue; }
                    const value = result.slice(content + 2, end);
                    const encoded = flag === "1_" ? encodeURIComponent(value) : encodeURI(value);
                    result = result.slice(0, begin) + encoded + result.slice(end + marker.end.length);
                    position = begin + encoded.length;
                }
            });
            return result;
        }
        const walker = document.createTreeWalker(fragment, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
            const node = walker.currentNode;
            if (node.nodeType === 3) node.nodeValue = finish(node.nodeValue);
            else Array.from(node.attributes || []).forEach(function (attr) { const value = finish(attr.value); if (value !== attr.value) attr.value = value; });
        }
        return fragment;
    }

    function prepareXsltForBrowser(xsltDoc, options) {
        options = options || {};
        const annotated = xsltDoc.cloneNode(true);
        ensureNamespaces(annotated);
        if (options.interactive) {
            Array.from(annotated.getElementsByTagName("*")).forEach(function (el) {
                if (el.namespaceURI === XSL_NS) return;
                const nodeId = el.getAttribute("data-pmk-xslt-node");
                if (!nodeId) return;
                el.setAttribute("data-pmk-preview-node", nodeId);
                if (nodeId === selectedNodeId) el.setAttribute("data-pmk-preview-selected", "1");
            });
        }
        const copy = stripInternal(annotated);
        const base = resolveSourceUrl(currentProject && currentProject.sourceUrl || "") || window.location.href;
        inlineKnownDependenciesForPreview(copy, base, 0);
        const missing = Array.from(copy.getElementsByTagNameNS(XSL_NS, "include")).concat(Array.from(copy.getElementsByTagNameNS(XSL_NS, "import")));
        if (missing.length) throw new Error("Ce XSLT utilise un fichier complémentaire : " + missing.map(function (el) { return el.getAttribute("href"); }).join(", ") + ". Ajoutez son contenu manuellement dans « Importer mon XSLT » pour l’aperçu. Les références restent conservées dans le XSLT final.");
        ensureNamespaces(copy);
        const uriMarkers = adaptUriEncodingForPreview(copy);
        // Reparse the preview copy so XPath prefixes and namespace nodes have
        // the same bindings as in a stylesheet loaded from an XML file.
        const prepared = parseXml(new XMLSerializer().serializeToString(copy));
        prepared.__pmk136UriMarkers = uriMarkers;
        return prepared;
    }

    function preparePreviewFragment(fragment) {
        fragment.querySelectorAll?.('script,iframe,object,embed,base,meta[http-equiv]').forEach(node=>node.remove());
        fragment.querySelectorAll?.('*').forEach(node=>{
            for(const attr of Array.from(node.attributes || [])) {
                if(/^on/i.test(attr.name) || attr.name==='srcdoc' || (/^(href|src|action|formaction|xlink:href)$/i.test(attr.name) && /^\s*(javascript|vbscript|data:text\/html):/i.test(attr.value)))node.removeAttribute(attr.name);
            }
        });
        return fragment;
    }

    function transformRecord(xsltDoc, marcDoc, options) {
        if (typeof XSLTProcessor === "undefined") throw new Error("Ce navigateur ne fournit pas XSLTProcessor.");
        let stage = "préparation du XSLT";
        try {
            const prepared = prepareXsltForBrowser(xsltDoc, options);
            const source = parseXml(new XMLSerializer().serializeToString(marcDoc));
            const proc = new XSLTProcessor();
            stage = "compilation du XSLT";
            proc.importStylesheet(prepared);
            stage = "création de l’aperçu";
            try {
                const fragment = proc.transformToFragment(source, document);
                if (!fragment) throw new Error("Le navigateur n’a pas pu produire l’aperçu de ce XSLT.");
                return preparePreviewFragment(finishUriEncodingPreview(fragment, prepared.__pmk136UriMarkers));
            } catch (e) {
                // Some Firefox transformations cannot create namespaced output
                // directly in the HTML owner document. Render in a separate
                // document and parse only the resulting markup for the preview.
                const namespaceError = e && (e.name === "NamespaceError" || e.code === 14 || /namespace/i.test(e.message || ""));
                if (!namespaceError || typeof proc.transformToDocument !== "function") throw e;
                stage = "création de l’aperçu dans un document séparé";
                const outputDoc = proc.transformToDocument(source);
                if (!outputDoc || !outputDoc.documentElement) throw new Error("Le navigateur n’a pas pu produire un document d’aperçu.");
                const output = Array.from(prepared.getElementsByTagNameNS(XSL_NS, "output")).pop();
                if (output && output.getAttribute("method") === "text") {
                    const fragment = document.createDocumentFragment();
                    fragment.appendChild(document.createTextNode(outputDoc.documentElement.textContent || ""));
                    return preparePreviewFragment(finishUriEncodingPreview(fragment, prepared.__pmk136UriMarkers));
                }
                const template = document.createElement("template");
                template.innerHTML = new XMLSerializer().serializeToString(outputDoc);
                return preparePreviewFragment(finishUriEncodingPreview(template.content, prepared.__pmk136UriMarkers));
            }
        } catch (e) {
            throw new Error("Échec pendant la " + stage + " : " + (e && e.message || String(e)));
        }
    }

    function updateLivePreviewSelection(target, nodeId) {
        if (!target) return;
        Array.from(target.querySelectorAll(".pmk136-preview-picked")).forEach(function (el) { el.classList.remove("pmk136-preview-picked"); });
        if (!nodeId) return;
        try {
            Array.from(target.querySelectorAll('[data-pmk-preview-node="' + CSS.escape(nodeId) + '"]')).forEach(function (el) { el.classList.add("pmk136-preview-picked"); });
        } catch (_) {}
    }

    function bindLivePreviewInteractions(target) {
        if (!target || target.__pmk136InteractiveBound) return;
        target.__pmk136InteractiveBound = true;
        target.addEventListener("click", function (event) {
            const hit = event.target && event.target.closest ? event.target.closest("[data-pmk-preview-node]") : null;
            if(event.target.closest?.("a,button,input,select,textarea"))event.preventDefault();
            if (!hit || !target.contains(hit)) return;
            const nodeId = hit.getAttribute("data-pmk-preview-node");
            if (!nodeId || !findNode(nodeId)) return;
            event.preventDefault();
            event.stopPropagation();
            selectedNodeId = nodeId;
            updateLivePreviewSelection(target, nodeId);
            renderStructure();
            renderInspector();
            toast("Élément sélectionné depuis l’aperçu.", "success");
        }, true);
        target.addEventListener("submit",event=>event.preventDefault(),true);
    }

    async function searchPreviewRecords(term, index) {
        term = clean(term);
        if (!term) return [];
        if (currentRecordKind() === "authority") return [];
        const url = "/cgi-bin/koha/catalogue/search.pl?idx=" + encodeURIComponent(clean(index) || "kw") + "&q=" + encodeURIComponent(term);
        const response = await fetch(url, { credentials: "same-origin", cache: "no-store" });
        if (!response.ok) throw new Error("Recherche Koha impossible (HTTP " + response.status + ").");
        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        const out = [];
        const seen = new Set();
        Array.from(doc.querySelectorAll('a[href*="catalogue/detail.pl?biblionumber="]')).forEach(function (a) {
            try {
                const u = new URL(a.href, window.location.origin);
                const id = u.searchParams.get("biblionumber");
                if (!id || seen.has(id)) return;
                seen.add(id);
                out.push({ id: id, label: clean(a.textContent) || ("Notice " + id) });
            } catch (_) {}
        });
        return out.slice(0, 12);
    }

    async function renderRecordPreview(target, recordId, compare, options) {
        if (!target) return;
        options = options || {};
        const kind = currentRecordKind();
        const requestProjectId = currentProject && currentProject.id;
        const requestEpoch = projectEpoch;
        const requestFingerprint = projectContentFingerprint();
        const requestToken = {}; target.__pmkPreviewRequest = requestToken;
        const isCurrent = function () { return target.isConnected && target.__pmkPreviewRequest === requestToken && currentProject && currentProject.id === requestProjectId && projectEpoch === requestEpoch && projectContentFingerprint() === requestFingerprint; };
        target.setAttribute("aria-busy","true");
        target.innerHTML = '<div role="status" class="pmk135-muted"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> Chargement ' + (kind === "authority" ? "de l’autorité" : "de la notice") + '…</div>';
        try {
            const marc = await fetchMarcXmlCached(recordId, kind, !!options.forceMarcReload);
            if (!isCurrent()) return;
            target.innerHTML = "";
            if (compare && currentProject && currentProject.sourceXml) {
                const grid = document.createElement("div");
                grid.className = "pmk135-preview-compare";
                const before = document.createElement("div");
                before.className = "pmk135-preview-column";
                before.innerHTML = "<strong>Avant — XSLT importé</strong>";
                const after = document.createElement("div");
                after.className = "pmk135-preview-column";
                after.innerHTML = "<strong>Après — vos modifications</strong>";
                try { before.appendChild(transformRecord(parseXml(currentProject.sourceXml), marc, { interactive: false })); }
                catch (e) { before.insertAdjacentHTML("beforeend", '<div class="alert alert-warning">' + esc(e.message) + '</div>'); }
                try { after.appendChild(transformRecord(workingDoc, marc, { interactive: !!options.interactive })); }
                catch (e) { after.insertAdjacentHTML("beforeend", '<div class="alert alert-warning">' + esc(e.message) + '</div>'); }
                grid.appendChild(before); grid.appendChild(after); target.appendChild(grid);
            } else {
                target.appendChild(transformRecord(workingDoc, marc, { interactive: !!options.interactive }));
            }
            if (options.interactive) {
                bindLivePreviewInteractions(target);
                updateLivePreviewSelection(target, selectedNodeId);
            }
            const status = app && app.querySelector("#pmk136-live-preview-status");
            if (status && options.live) status.textContent = "Mis à jour à " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        } catch (e) {
            if (!isCurrent()) return;
            target.innerHTML = '<div class="alert alert-warning"><strong>Aperçu réel indisponible.</strong><br>' + esc(e.message) + '<br><small>Le XSLT reste éditable et copiable. Certains XSLT Koha dépendent de paramètres ou inclusions fournis par Koha et ne peuvent pas être reproduits intégralement dans le navigateur.</small></div>';
            const status = app && app.querySelector("#pmk136-live-preview-status");
            if (status && options.live) status.textContent = "Aperçu en erreur";
        } finally {if(target.__pmkPreviewRequest===requestToken)target.setAttribute("aria-busy","false");}

    }

    function scheduleAutoPreview(immediate, force) {
        if (autoPreviewTimer) { window.clearTimeout(autoPreviewTimer); autoPreviewTimer = null; }
        if (!app || !currentProject || !workingDoc || activeWorkspaceStep !== "build") return;
        if(currentProject.autoPreview===false && !force){const target=app.querySelector('#pmk136-live-preview');const status=app.querySelector('#pmk136-live-preview-status');if(target && !target.childNodes.length)target.textContent='Choisissez une notice puis cliquez sur Actualiser pour calculer l’aperçu.';if(status)status.textContent='Actualisation manuelle';return;}
        const kind = currentRecordKind();
        const idKey = kind === "authority" ? "previewAuthorityId" : "previewBiblionumber";
        const id = clean(currentProject[idKey] || "").replace(/\D/g, "");
        const target = app.querySelector("#pmk136-live-preview");
        if (!target) return;
        if (!id) {
            target.innerHTML = '<div class="pmk136-live-preview-empty"><i class="fa fa-eye" aria-hidden="true"></i><strong>Voir le résultat de vos modifications</strong><span>Indiquez ' + (kind === "authority" ? "un numéro d’autorité" : "un numéro de notice") + ' ci-dessus. PMK réutilisera ensuite cette ' + (kind === "authority" ? "autorité" : "notice") + ' après chaque modification.</span></div>';
            const status = app.querySelector("#pmk136-live-preview-status");
            if (status) status.textContent = "En attente d’un document test";
            return;
        }
        const delay = immediate ? 0 : 180;
        const requestNo = ++autoPreviewRequest;
        autoPreviewTimer = window.setTimeout(async function () {
            autoPreviewTimer = null;
            const currentTarget = app && app.querySelector("#pmk136-live-preview");
            if (!currentTarget || requestNo !== autoPreviewRequest) return;
            const status = app.querySelector("#pmk136-live-preview-status");
            if (status) status.textContent = "Mise à jour…";
            await renderRecordPreview(currentTarget, id, !!currentProject.autoPreviewCompare, { interactive: true, live: true });
        }, delay);
    }

    function saveWorking() {
        if (!currentProject || !workingDoc) return;
        const previousXml = currentProject.workingXml || "";
        const nextXml = serializeDoc(workingDoc, false);
        if (nextXml !== previousXml) {
            recordUndoSnapshot(previousXml);
            currentProject.workingXml = nextXml;
            currentProject.updatedAt = new Date().toISOString();
        }
        saveProject(currentProject);
        updateTopbarStatus();
        scheduleAutoPreview(false);
    }

    function setWorkingXml(xml, sourceToo) {
        const previousXml = currentProject && currentProject.workingXml ? currentProject.workingXml : "";
        if (!sourceToo && previousXml && previousXml !== xml) recordUndoSnapshot(previousXml);
        const doc = parseXml(xml);
        ensureNamespaces(doc);
        restorePmkMetadataComments(doc);
        annotate(doc);
        projectEpoch += 1;
        workingDoc = doc;
        recognizeVisualDocument(doc);
        if (sourceToo) currentProject.sourceXml = xml;
        currentProject.workingXml = serializeDoc(doc, false);
        if (sourceToo) currentProject.dependencies = [];
        currentProject.activeStep = "build";
        activeWorkspaceStep = "build";
        saveProject(currentProject);
        selectedNodeId = getLiteralNodes()[0]?.getAttribute("data-pmk-xslt-node") || null;
        renderAll();
        const epoch = projectEpoch;
        const projectId = currentProject.id;
        window.setTimeout(function () {
            loadDependencyTree(false).then(function () {
                if (app && currentProject && currentProject.id === projectId && projectEpoch === epoch) renderWorkspace();
            }).catch(function () {});
        }, 0);
    }

    function resolveSourceUrl(value) {
        value = clean(value);
        if (!value || value === "default") return "";
        try {
            return new URL(value, window.location.origin).href;
        } catch (_) {
            return value;
        }
    }

    function readLocalXsltFile(file) {
        return new Promise(function (resolve, reject) {
            if (!file) return reject(new Error("Aucun fichier sélectionné."));
            const reader = new FileReader();
            reader.onerror = function () { reject(new Error("Impossible de lire le fichier sélectionné.")); };
            reader.onload = function () {
                try {
                    const xml = String(reader.result || "");
                    parseXml(xml);
                    resolve(xml);
                } catch (e) { reject(e); }
            };
            reader.readAsText(file, "UTF-8");
        });
    }


    function normalizeDependenciesProject() {
        if (!currentProject) return [];
        if (!Array.isArray(currentProject.dependencies)) currentProject.dependencies = [];
        return currentProject.dependencies;
    }

    function dependencyBasename(value) {
        value = clean(value).split(/[?#]/)[0];
        const bits = value.split('/');
        return bits[bits.length - 1] || 'dependency.xsl';
    }

    function resolveDependencyUrl(href, baseUrl) {
        href = clean(href);
        if (!href) return '';
        try { return new URL(href, baseUrl || window.location.href).href; }
        catch (_) { return href; }
    }

    function dependencyRefsFromDoc(doc, baseUrl, parentId) {
        if (!doc) return [];
        const refs = [];
        ['import','include'].forEach(function (kind) {
            Array.from(doc.getElementsByTagNameNS(XSL_NS, kind)).forEach(function (el) {
                const href = clean(el.getAttribute('href'));
                if (!href) return;
                refs.push({
                    kind: kind,
                    href: href,
                    originalHref: href,
                    resolvedUrl: resolveDependencyUrl(href, baseUrl),
                    parentId: parentId || '',
                    topLevel: !parentId
                });
            });
        });
        return refs;
    }

    function dependencyTemplateNames(xml) {
        if (!clean(xml)) return [];
        try {
            const doc = parseXml(xml);
            return Array.from(doc.getElementsByTagNameNS(XSL_NS, 'template'))
                .map(function (el) { return clean(el.getAttribute('name')); })
                .filter(Boolean);
        } catch (_) { return []; }
    }

    function dependencyCalls(dep) {
        if (!workingDoc || !dep) return [];
        const names = new Set(dep.templates || dependencyTemplateNames(dep.customXml || dep.sourceXml));
        if (!names.size) return [];
        return Array.from(workingDoc.getElementsByTagNameNS(XSL_NS, 'call-template')).map(function (el) {
            return clean(el.getAttribute('name'));
        }).filter(function (name) { return names.has(name); });
    }

    function countDependencyCalls(dep) {
        return dependencyCalls(dep).length;
    }

    function syncDependencyUsage() {
        normalizeDependenciesProject().forEach(function (dep) {
            dep.templates = dependencyTemplateNames(dep.customXml || dep.sourceXml);
            dep.calledTemplates = Array.from(new Set(dependencyCalls(dep)));
            dep.usageCount = dep.calledTemplates.reduce(function(total, name){
                return total + Array.from(workingDoc ? workingDoc.getElementsByTagNameNS(XSL_NS, 'call-template') : []).filter(function(el){ return clean(el.getAttribute('name')) === name; }).length;
            }, 0);
        });
    }

    function dependencyByHref(href, baseUrl) {
        href = clean(href);
        const resolved = resolveDependencyUrl(href, baseUrl);
        return normalizeDependenciesProject().find(function (dep) {
            return clean(dep.href) === href || clean(dep.customFilename) === href || clean(dep.resolvedUrl) === resolved;
        }) || null;
    }

    function inlineKnownDependenciesForPreview(doc, baseUrl, depth) {
        if (!doc || depth > 5) return doc;
        const refs = Array.from(doc.getElementsByTagNameNS(XSL_NS, 'include')).concat(Array.from(doc.getElementsByTagNameNS(XSL_NS, 'import')));
        refs.forEach(function (el) {
            const href = clean(el.getAttribute('href'));
            const dep = dependencyByHref(href, baseUrl);
            const xml = dep && clean(dep.customXml || dep.sourceXml);
            if (!xml) return;
            try {
                const depDoc = parseXml(xml);
                inlineKnownDependenciesForPreview(depDoc, dep.resolvedUrl || baseUrl, depth + 1);
                const root = depDoc.documentElement;
                const parent = el.parentNode;
                if (!parent || !root) return;
                Array.from(root.childNodes).forEach(function (child) {
                    if (child.nodeType === 1 && child.namespaceURI === XSL_NS && ['output','strip-space','preserve-space'].indexOf(child.localName) >= 0) return;
                    const imported = doc.importNode(child, true);
                    // An imported template may use prefixes only in XPath
                    // strings. Keep declarations inherited from its old root.
                    if (imported.nodeType === 1) {
                        Array.from(root.attributes || []).forEach(function (attr) {
                            if (attr.namespaceURI !== XMLNS_NS) return;
                            if (!imported.hasAttributeNS(XMLNS_NS, attr.localName)) imported.setAttributeNS(XMLNS_NS, attr.name, attr.value);
                        });
                    }
                    parent.insertBefore(imported, el);
                });
                parent.removeChild(el);
            } catch (_) {}
        });
        return doc;
    }

    async function loadDependencyTree() {
        if (!currentProject || !workingDoc) return [];
        const previous = normalizeDependenciesProject();
        const queue = dependencyRefsFromDoc(workingDoc, window.location.href, "");
        const result = [], seen = new Set();
        while (queue.length) {
            const ref = queue.shift();
            const key = ref.resolvedUrl || ref.href;
            if (seen.has(key)) continue;
            seen.add(key);
            const old = previous.find(function (dep) { return (dep.resolvedUrl || dep.href) === key || dep.href === ref.href; });
            const dep = Object.assign({}, old || {}, ref, { id: old && old.id || uid("dep") });
            dep.status = clean(dep.customXml || dep.sourceXml) ? "loaded-local" : "manual";
            dep.templates = dependencyTemplateNames(dep.customXml || dep.sourceXml);
            result.push(dep);
            if (clean(dep.customXml || dep.sourceXml) && result.length < 100) {
                try { dependencyRefsFromDoc(parseXml(dep.customXml || dep.sourceXml), dep.resolvedUrl, dep.id).forEach(function (child) { queue.push(child); }); }
                catch (_) {}
            }
        }
        currentProject.dependencies = result;
        syncDependencyUsage();
        saveProject(currentProject);
        return result;
    }

    function dependencyById(id) {
        return normalizeDependenciesProject().find(function (dep) { return dep.id === id; }) || null;
    }

    function importDependencyManually(dep) {
        if (!dep) return;
        const wrap = document.createElement('div');
        wrap.innerHTML = '<div class="alert alert-light">Collez le contenu complet du fichier <code>' + esc(dep.href) + '</code>.</div>';
        const fileInput = document.createElement('input'); fileInput.type='file'; fileInput.className='form-control form-control-sm'; fileInput.accept='.xsl,.xslt,.xml,application/xml,text/xml,application/xslt+xml,text/xsl';
        wrap.appendChild(makeField('Fichier local', fileInput, 'Ou collez le contenu ci-dessous. Ce fichier sert uniquement à l’aperçu.'));
        const ta = document.createElement('textarea'); ta.className='form-control'; ta.rows=18; ta.spellcheck=false; wrap.appendChild(ta);
        fileInput.addEventListener('change', async function(){
            if (!fileInput.files || !fileInput.files[0]) return;
            try { ta.value = await readLocalXsltFile(fileInput.files[0]); toast('Dépendance chargée depuis le fichier local.', 'success'); }
            catch(e) { toast(e.message,'danger'); }
        });
        dialog('Ajouter un fichier pour l’aperçu', wrap, [
            {label:'Annuler',className:'btn btn-sm btn-outline-secondary',icon:'fa fa-times',run:function(box){box.remove();}},
            {label:'Ajouter pour l’aperçu',className:'btn btn-sm btn-primary',icon:'fa fa-save',run:function(box){
                try { parseXml(ta.value); dep.sourceXml=ta.value; if(!dep.originalSourceXml)dep.originalSourceXml=ta.value; dep.status='loaded-local'; dep.error=''; dep.templates=dependencyTemplateNames(dep.sourceXml); syncDependencyUsage(); saveProject(currentProject); box.remove(); loadDependencyTree(false).then(function () { renderWorkspace(); scheduleAutoPreview(true); }); toast('Fichier ajouté pour l’aperçu.', 'success'); }
                catch(e){ toast(e.message,'danger'); }
            }}
        ]);
    }

    function renderProjectOptions(select) {
        const index = loadIndex();
        select.innerHTML = "";
        if (!index.length) {
            const option = document.createElement("option");
            option.value = "";
            option.textContent = "Aucun projet";
            select.appendChild(option);
            return;
        }
        index.sort(function (a, b) { return String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")); });
        index.forEach(function (meta) {
            const option = document.createElement("option");
            option.value = meta.id;
            option.textContent = meta.name || meta.syspref || "Projet XSLT";
            if (currentProject && meta.id === currentProject.id) option.selected = true;
            select.appendChild(option);
        });
    }

    function createButton(label, cls, handler, icon) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = cls || "btn btn-sm btn-outline-secondary";
        button.innerHTML = (icon ? '<i class="' + esc(icon) + '" aria-hidden="true"></i> ' : "") + esc(label);
        button.addEventListener("click", handler);
        return button;
    }

    function updateTopbarStatus() {
        if (!app || !currentProject) return;
        const node = app.querySelector(".pmk136-project-status");
        if (!node) return;
        const updated = currentProject.updatedAt ? new Date(currentProject.updatedAt) : null;
        let label = updated && !Number.isNaN(updated.getTime()) ? "Enregistré à " + updated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "Projet local";
        if (currentProject.lastValidation) {
            const stale = currentProject.lastValidation.fingerprint !== validationFingerprint();
            if (stale) label += " · validation à refaire";
            else if (currentProject.lastValidation.status === "ok") label += " · validé";
            else if (currentProject.lastValidation.status === "warn") label += " · validé avec avertissements";
            else label += " · erreurs de validation";
        }
        if(unsavedProjects.has(currentProject.id))label='Modifications en mémoire — sauvegarde à télécharger';
        node.textContent = label;
    }

    function duplicateCurrentProject() {
        if (!currentProject) return;
        const copy = clone(currentProject);
        copy.id = uid("project");
        copy.name = (currentProject.name || "Projet XSLT") + " — copie";
        copy.createdAt = new Date().toISOString();
        copy.updatedAt = copy.createdAt;
        copy.lastValidation = null;
        if (copy.publication) {
            copy.publication.backupAcknowledgedRevision = "";
            copy.publication.backupAcknowledgedAt = "";
            copy.publication.backupAcknowledgedFingerprint = "";
            copy.publication.lastExportFingerprint = "";
            copy.publication.lastExportRevision = 0;
            copy.publication.lastExportAt = "";
        }
        saveProject(copy);
        openProject(copy);
        toast("Projet dupliqué.", "success");
    }

    function deleteCurrentProjectFromUi() {
        if (!currentProject) return;
        if (!window.confirm("Supprimer le projet « " + (currentProject.name || "Projet XSLT") + " » de ce navigateur ?")) return;
        const id = currentProject.id;
        deleteProject(id);
        projectHistories.delete(id);
        const index = loadIndex();
        const next = index.length ? loadProject(index[index.length - 1].id) : defaultProject();
        if (!index.length) saveProject(next);
        openProject(next);
        toast("Projet supprimé.", "success");
    }

    function openProjectActionsDialog() {
        const wrap = document.createElement("div");
        const input = document.createElement("input"); input.className = "form-control"; input.value = currentProject.name || "";
        wrap.appendChild(makeField("Nom du document dans l’éditeur", input));
        input.addEventListener("input", function () { currentProject.name = clean(input.value) || "Mon XSLT"; saveProject(currentProject); renderTopbar(); });
        const tools = document.createElement("div"); tools.className = "pmk135-toolbar";
        tools.appendChild(createButton("Ouvrir un nouveau XSLT", "btn btn-outline-primary", function () { const p = defaultProject(); saveProject(p); document.querySelector(".pmk135-dialog-backdrop")?.remove(); openProject(p); openPasteDialog(); }));
        tools.appendChild(createButton("Dupliquer ce document", "btn btn-outline-secondary", function () { document.querySelector(".pmk135-dialog-backdrop")?.remove(); duplicateCurrentProject(); }));
        tools.appendChild(createButton("Supprimer ce brouillon", "btn btn-outline-danger", function () { document.querySelector(".pmk135-dialog-backdrop")?.remove(); deleteCurrentProjectFromUi(); }));
        tools.appendChild(createButton('Sauvegarder ce projet','btn btn-outline-secondary',downloadProject,'fa fa-download'));
        const restore=document.createElement('input');restore.type='file';restore.accept='.json';restore.setAttribute('aria-label','Importer une sauvegarde de projet');
        restore.addEventListener('change',async()=>{try{if(restore.files[0]){await restoreProjectFile(restore.files[0]);restore.closest('.pmk135-dialog-backdrop')?.remove();}}catch(error){toast(error.message,'danger');}});
        wrap.appendChild(tools);wrap.appendChild(makeField('Restaurer une sauvegarde de projet',restore,'La sauvegarde est ajoutée comme un nouveau projet ; vos projets existants sont conservés.'));
        dialog("Mes projets XSLT", wrap, [{ label: "Fermer", className: "btn btn-outline-secondary", run: function (box) { box.remove(); } }]);
    }

    function renderTopbar() {
        if (!app) return;
        const bar = app.querySelector(".pmk135-topbar");
        if (!bar) return;
        bar.innerHTML = "";
        app.classList.toggle("pmk136-mode-simple", currentUiMode() === "simple");
        app.classList.toggle("pmk136-mode-advanced", currentUiMode() === "advanced");

        const brand = document.createElement("div");
        brand.className = "pmk135-brand";
        brand.innerHTML = '<i class="fa fa-code" aria-hidden="true"></i><span>Éditeur XSLT</span>';
        bar.appendChild(brand);

        const projectSelect = document.createElement("select");
        projectSelect.className = "form-control form-control-sm";
        projectSelect.setAttribute("aria-label","Projet XSLT ouvert");
        renderProjectOptions(projectSelect);
        projectSelect.addEventListener("change", function () {
            const project = loadProject(projectSelect.value);
            if (project) openProject(project);
        });
        bar.appendChild(projectSelect);
        bar.appendChild(createButton('Nouveau projet','btn btn-sm btn-outline-primary',()=>{const project=defaultProject();saveProject(project);openProject(project);openPasteDialog();},'fa fa-plus'));
        bar.appendChild(createButton("Mes projets", "btn btn-sm btn-outline-secondary", openProjectActionsDialog, "fa fa-folder-open"));

        if (workingDoc) {
            bar.appendChild(createButton("Annuler", "btn btn-sm btn-outline-secondary", undoWorking, "fa fa-undo"));
            bar.lastChild.title = "Annuler";
            bar.appendChild(createButton("Rétablir", "btn btn-sm btn-outline-secondary", redoWorking, "fa fa-redo"));
            bar.lastChild.title = "Rétablir";
        }

        bar.appendChild(createButton(currentUiMode() === "advanced" ? "Masquer les options techniques" : "Options techniques", "btn btn-sm btn-outline-secondary", function () {
            if (!currentProject) return;
            currentProject.uiMode = currentUiMode() === "advanced" ? "simple" : "advanced";
            saveProject(currentProject);
            const workspace = app.querySelector(".pmk135-pane-workspace"); if (workspace) workspace.dataset.step = "";
            renderAll();
        }, currentUiMode() === "advanced" ? "fa fa-tools" : "fa fa-leaf"));

        const spacer = document.createElement("div");
        spacer.className = "pmk135-spacer";
        bar.appendChild(spacer);
        const status = document.createElement("span");
        status.className = "pmk136-project-status";
        bar.appendChild(status);

        if (workingDoc) {
            bar.appendChild(createButton("Vérifier et exporter", "btn btn-sm btn-primary", function () { setWorkspaceStep("publish"); }, "fa fa-copy"));
        }
        bar.appendChild(createButton("Fermer", "btn btn-sm btn-outline-secondary", closeAssistant, "fa fa-times"));
        updateTopbarStatus();
    }

    function openProject(project) {
        if (autoPreviewTimer) { window.clearTimeout(autoPreviewTimer); autoPreviewTimer = null; }
        autoPreviewRequest += 1;
        projectEpoch += 1;
        currentProject = normalizeProjectState(project);
        activeWorkspaceStep = currentProject.activeStep || (currentProject.workingXml ? "build" : "source");
        workingDoc = null;
        selectedNodeId = null;
        normalizeDependenciesProject();
        if (project.workingXml) {
            try {
                workingDoc = parseXml(project.workingXml);
                ensureNamespaces(workingDoc);
                restorePmkMetadataComments(workingDoc);
                annotate(workingDoc);
                recognizeVisualDocument(workingDoc);
                syncDependencyUsage();
                selectedNodeId = getLiteralNodes()[0]?.getAttribute("data-pmk-xslt-node") || null;
            } catch (e) {
                toast("Le brouillon local est invalide : " + e.message, "danger");
            }
        }
        const pane = app && app.querySelector(".pmk135-pane-workspace"); if (pane) pane.dataset.step = "";
        renderAll();
        if (workingDoc) {
            const epoch = projectEpoch;
            const projectId = currentProject.id;
            window.setTimeout(function(){
                loadDependencyTree(false).then(function(){
                    if(app && currentProject && currentProject.id === projectId && projectEpoch === epoch) renderWorkspace();
                }).catch(function(){});
            },0);
        }
    }

    function renderVisualRecognitionSummary() {
        const stats = currentProject && currentProject.visualRecognition ? currentProject.visualRecognition : recognizeVisualDocument(workingDoc);
        const box = document.createElement("div");
        box.className = "pmk135-section";
        box.innerHTML = '<h4><i class="fa fa-eye" aria-hidden="true"></i> Analyse de l’interface générée</h4>' +
            '<div class="alert alert-light">' +
            '<strong>' + (stats.recognized || 0) + ' élément(s) éditable(s)</strong><br>' +
            '<span class="badge badge-success">' + (stats.recognized || 0) + ' reconnus</span> ' +
            '<span class="badge badge-warning">' + (stats.partial || 0) + ' partiellement éditables</span> ' +
            '<span class="badge badge-dark">' + (stats.advanced || 0) + ' blocs XSLT avancés préservés</span>' +
            '<div class="pmk135-muted" style="margin-top:.45rem">Les blocs avancés sont conservés sans réécriture automatique tant que vous ne les modifiez pas.</div></div>';
        return box;
    }

    function templateLabelForNode(node) {
        const template = xsltTemplateForNode(node);
        if (!template) return "Autres éléments";
        const name = clean(template.getAttribute("name"));
        const match = clean(template.getAttribute("match"));
        const mode = clean(template.getAttribute("mode"));
        if (currentUiMode() === "advanced") return (name ? "Modèle : " + name : "Modèle pour : " + match) + (mode ? " · " + mode : "");
        if (match === "/") return "Affichage principal";
        if (match && /record/.test(match)) return "Affichage de la notice" + (mode ? " — " + mode : "");
        if (name) return "Section — " + name.replace(/[_-]+/g, " ");
        return "Section de l’affichage — " + (match || "sans nom");
    }

    function xsltTemplateForNode(node) {
        let p = node;
        while (p) {
            if (p.nodeType === 1 && p.namespaceURI === XSL_NS && p.localName === "template") return p;
            p = p.parentNode;
        }
        return null;
    }

    function canContainDroppedNode(node) {
        if (!node || node.nodeType !== 1 || node.namespaceURI === XSL_NS) return false;
        const tag = String(node.localName || "").toLowerCase();
        return !["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"].includes(tag);
    }

    function clearDropIndicators(root) {
        if (!root) return;
        Array.from(root.querySelectorAll(".is-drop-target,.is-drop-before,.is-drop-after,.is-drop-inside")).forEach(function (el) {
            el.classList.remove("is-drop-target", "is-drop-before", "is-drop-after", "is-drop-inside");
        });
    }

    function pointerDropAllowed(dragged, target, position) {
        if (!dragged || !target || dragged === target) return false;
        const draggedUnit = movableUnit(dragged);
        const targetUnit = movableUnit(target);
        if (!draggedUnit || !targetUnit || !targetUnit.parentNode) return false;
        if (draggedUnit.contains && draggedUnit.contains(targetUnit)) return false;
        const a = xsltTemplateForNode(dragged);
        const b = xsltTemplateForNode(target);
        if (a !== b) return false;
        if (position === "inside" && !canContainDroppedNode(target)) return false;
        const destination = position === "inside" ? target : targetUnit.parentNode;
        if (draggedUnit.contains && draggedUnit.contains(destination)) return false;
        return true;
    }

    function performPointerDrop(dragged, target, position) {
        if (!pointerDropAllowed(dragged, target, position)) return false;
        const draggedUnit = movableUnit(dragged);
        const targetUnit = movableUnit(target);
        if (position === "inside") {
            target.appendChild(draggedUnit);
        } else if (position === "before") {
            targetUnit.parentNode.insertBefore(draggedUnit, targetUnit);
        } else {
            targetUnit.parentNode.insertBefore(draggedUnit, targetUnit.nextSibling);
        }
        return true;
    }

    function startPointerStructureDrag(event, nodeId, card, body) {
        if (activeWorkspaceStep !== "build" || event.button !== 0) return;
        if (event.target && event.target.closest && event.target.closest("button,input,select,textarea,a")) return;
        const dragged = findNode(nodeId);
        if (!dragged) return;
        const startX = event.clientX;
        const startY = event.clientY;
        const state = {
            nodeId: nodeId, card: card, body: body, pointerId: event.pointerId,
            startX: startX, startY: startY, active: false, ghost: null, hint: null,
            targetId: "", position: ""
        };
        pointerDrag = state;

        function activate() {
            if (state.active) return;
            state.active = true;
            draggedNodeId = nodeId;
            card.classList.add("is-dragging");
            document.documentElement.style.userSelect = "none";
            const ghost = document.createElement("div");
            ghost.className = "pmk136-drag-ghost";
            ghost.innerHTML = '<i class="fa fa-grip-vertical" aria-hidden="true"></i> ' + esc(recognitionTitle(dragged));
            document.body.appendChild(ghost);
            state.ghost = ghost;
            const hint = document.createElement("div");
            hint.className = "pmk136-drag-hint";
            hint.textContent = "Déplacer";
            document.body.appendChild(hint);
            state.hint = hint;
        }

        function moveFloating(x, y) {
            if (state.ghost) { state.ghost.style.left = (x + 16) + "px"; state.ghost.style.top = (y + 14) + "px"; }
            if (state.hint) { state.hint.style.left = (x + 18) + "px"; state.hint.style.top = (y - 20) + "px"; }
        }

        function onMove(ev) {
            if (pointerDrag !== state || ev.pointerId !== state.pointerId) return;
            const dx = ev.clientX - startX;
            const dy = ev.clientY - startY;
            if (!state.active && Math.hypot(dx, dy) < 5) return;
            activate();
            ev.preventDefault();
            moveFloating(ev.clientX, ev.clientY);
            clearDropIndicators(body);
            state.targetId = ""; state.position = "";
            const hit = document.elementFromPoint(ev.clientX, ev.clientY);
            const targetCard = hit && hit.closest ? hit.closest(".pmk135-card[data-node-id]") : null;
            if (!targetCard || targetCard === card || !body.contains(targetCard)) {
                if (state.hint) state.hint.textContent = "Déplacement interdit";
                return;
            }
            const targetId = targetCard.dataset.nodeId || "";
            const target = findNode(targetId);
            if (!target) return;
            const rect = targetCard.getBoundingClientRect();
            const ratio = rect.height ? (ev.clientY - rect.top) / rect.height : .5;
            let position = ratio < .30 ? "before" : (ratio > .70 ? "after" : "inside");
            if (!pointerDropAllowed(dragged, target, position) && position === "inside") {
                position = ratio < .5 ? "before" : "after";
            }
            if (!pointerDropAllowed(dragged, target, position)) {
                if (state.hint) state.hint.textContent = "Déplacement interdit";
                return;
            }
            state.targetId = targetId;
            state.position = position;
            targetCard.classList.add("is-drop-target", position === "before" ? "is-drop-before" : (position === "after" ? "is-drop-after" : "is-drop-inside"));
            if (state.hint) state.hint.textContent = position === "before" ? "Placer avant" : (position === "after" ? "Placer après" : "Placer à l’intérieur");
        }

        function cleanup() {
            window.removeEventListener("pointermove", onMove, true);
            window.removeEventListener("pointerup", onUp, true);
            window.removeEventListener("pointercancel", onCancel, true);
            clearDropIndicators(body);
            card.classList.remove("is-dragging");
            if (state.ghost) state.ghost.remove();
            if (state.hint) state.hint.remove();
            document.documentElement.style.userSelect = "";
            draggedNodeId = null;
            pointerDrag = null;
        }

        function finish(ev, cancelled) {
            if (pointerDrag !== state) return;
            const wasActive = state.active;
            const targetId = state.targetId;
            const position = state.position;
            cleanup();
            if (!wasActive || cancelled) return;
            dragJustFinishedUntil = Date.now() + 250;
            const source = findNode(nodeId);
            const target = findNode(targetId);
            if (!source || !target || !performPointerDrop(source, target, position)) {
                toast("Déplacement impossible à cet endroit.", "info");
                return;
            }
            selectedNodeId = nodeId;
            saveWorking();
            renderStructure();
            renderInspector();
            renderWorkspace();
            toast(position === "inside" ? "Bloc déplacé à l’intérieur." : (position === "before" ? "Bloc déplacé avant." : "Bloc déplacé après."), "success");
        }

        function onUp(ev) { if (ev.pointerId === state.pointerId) finish(ev, false); }
        function onCancel(ev) { if (ev.pointerId === state.pointerId) finish(ev, true); }
        window.addEventListener("pointermove", onMove, { capture:true, passive:false });
        window.addEventListener("pointerup", onUp, true);
        window.addEventListener("pointercancel", onCancel, true);
    }

    function moveSelectedBlock(direction) {
        const node=findNode(selectedNodeId),unit=movableUnit(node);
        if(!unit)return;
        const sibling=direction<0?unit.previousElementSibling:unit.nextElementSibling;
        if(!sibling || (sibling.namespaceURI===XSL_NS && !['if','choose','for-each'].includes(sibling.localName)))return;
        if(direction<0)unit.parentNode.insertBefore(unit,sibling);else unit.parentNode.insertBefore(unit,sibling.nextSibling);
        saveWorking();renderAll();
    }

    function renderStructure() {
        if (!app) return;
        const pane = app.querySelector(".pmk135-pane-structure");
        if (!pane) return;
        pane.innerHTML = "";
        const head = document.createElement("div");
        head.className = "pmk135-pane-head";
        head.innerHTML = "<strong>Blocs de l’affichage</strong>";
        if (workingDoc && activeWorkspaceStep === "build") head.appendChild(createButton("Ajouter un élément", "btn btn-sm btn-primary", openAddElementMenu, "fa fa-plus"));
        if(workingDoc && activeWorkspaceStep==='build') {
            for(const [label,direction,icon] of [['Monter le bloc',-1,'fa fa-arrow-up'],['Descendre le bloc',1,'fa fa-arrow-down']]) {
                const button=createButton(label,'btn btn-sm btn-outline-secondary',()=>moveSelectedBlock(direction),icon);
                const unit=movableUnit(findNode(selectedNodeId));const sibling=unit && (direction<0?unit.previousElementSibling:unit.nextElementSibling);
                button.disabled=!sibling || (sibling.namespaceURI===XSL_NS && !['if','choose','for-each'].includes(sibling.localName));head.appendChild(button);
            }
        }
        pane.appendChild(head);

        const body = document.createElement("div");
        body.className = "pmk135-structure";
        pane.appendChild(body);

        if (!workingDoc) {
            body.innerHTML = '<div class="pmk135-empty"><i class="fa fa-sitemap"></i>Chargez un XSLT pour afficher sa structure.</div>';
            return;
        }

        const controls = document.createElement("div");
        controls.className = "pmk136-structure-controls";
        const search = document.createElement("input");
        search.type = "search";
        search.id = "pmk136-structure-search";
        search.className = "form-control form-control-sm";
        search.placeholder = "Rechercher un titre, un auteur, une zone MARC…";
        search.value = structureFilterText;
        const mode = document.createElement("select");
        mode.className = "form-control form-control-sm";
        mode.innerHTML = '<option value="all">Tous</option><option value="editable">Éditables</option><option value="advanced">Avancés</option>';
        mode.value = structureFilterMode;
        search.addEventListener("input", function () {
            structureFilterText = search.value;
            const pos = search.selectionStart;
            renderStructure();
            window.setTimeout(function () {
                const next = app && app.querySelector("#pmk136-structure-search");
                if (!next) return;
                next.focus();
                try { next.setSelectionRange(pos, pos); } catch (_) {}
            }, 0);
        });
        mode.addEventListener("change", function () { structureFilterMode = mode.value; renderStructure(); });
        controls.appendChild(search);
        controls.appendChild(mode);
        body.appendChild(controls);

        let nodes = getLiteralNodes();
        if (!nodes.length) {
            body.insertAdjacentHTML("beforeend", '<div class="pmk135-empty">Aucun élément de sortie HTML détecté.</div>');
            return;
        }

        const q = clean(structureFilterText).toLowerCase();
        nodes = nodes.filter(function (node) {
            const state = node.getAttribute("data-pmk-xslt-recognition") || "advanced";
            if (structureFilterMode === "editable" && state === "advanced") return false;
            if (structureFilterMode === "advanced" && state !== "advanced") return false;
            if (!q) return true;
            const haystack = [recognitionTitle(node), nodeSummary(node), node.getAttribute("class") || "", templateLabelForNode(node)]
                .join(" ").toLowerCase();
            return haystack.indexOf(q) >= 0;
        });

        if (!nodes.length) {
            body.insertAdjacentHTML("beforeend", '<div class="pmk135-empty">Aucun bloc ne correspond au filtre.</div>');
            return;
        }

        let lastTemplate = null;
        nodes.forEach(function (node) {
            const templateLabel = templateLabelForNode(node);
            if (templateLabel !== lastTemplate) {
                const title = document.createElement("div");
                title.className = "pmk136-template-title";
                title.innerHTML = '<i class="fa ' + (collapsedTemplates.has(templateLabel) ? 'fa-chevron-right' : 'fa-chevron-down') + ' fa-fw" aria-hidden="true"></i> ' + esc(templateLabel);
                title.title = "Replier / déplier cette section";
                title.addEventListener("click", function () {
                    if (collapsedTemplates.has(templateLabel)) collapsedTemplates.delete(templateLabel);
                    else collapsedTemplates.add(templateLabel);
                    renderStructure();
                });
                body.appendChild(title);
                lastTemplate = templateLabel;
            }
            if (collapsedTemplates.has(templateLabel)) return;

            const id = node.getAttribute("data-pmk-xslt-node");
            const card = document.createElement("div");
            card.className = "pmk135-card" + (id === selectedNodeId ? " is-selected" : "");
            card.draggable = false;
            card.dataset.nodeId = id;
            const depth = Math.min(8, literalDepth(node));
            card.style.marginLeft = (depth * 10) + "px";
            const condition = conditionWrapperFor(node);
            const state = node.getAttribute("data-pmk-xslt-recognition") || "advanced";
            card.innerHTML = '<div class="pmk135-card-title"><span class="pmk135-drag" title="Glisser pour déplacer cet élément"><i class="fa fa-grip-vertical" aria-hidden="true"></i></span><strong>' + esc(recognitionTitle(node)) + '</strong></div><div class="pmk135-node-meta">' + esc(nodeSummary(node)) + '</div>';
            if (condition) card.insertAdjacentHTML("beforeend", '<small class="pmk135-muted">Affiché sous condition</small>');
            if (currentUiMode() === "advanced") card.insertAdjacentHTML("beforeend", '<div class="pmk135-node-meta">&lt;' + esc(node.localName) + '&gt; · ' + esc(node.getAttribute("class") || "") + ' · ' + esc(state) + '</div>');
            card.setAttribute("role", "button"); card.tabIndex = 0;
            card.setAttribute("aria-label", recognitionTitle(node) + ". " + nodeSummary(node));
            card.addEventListener("keydown", function (event) { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); card.click(); } });
            card.addEventListener("click", function () {
                if (Date.now() < dragJustFinishedUntil) return;
                selectedNodeId = id;
                renderStructure();
                renderInspector();
                if (activeWorkspaceStep === "build") {
                    const live = app && app.querySelector("#pmk136-live-preview");
                    updateLivePreviewSelection(live, selectedNodeId);
                }
            });
            card.addEventListener("pointerdown", function (event) {
                startPointerStructureDrag(event, id, card, body);
            });
            body.appendChild(card);
        });
    }

    function openAddElementMenu() {
        const wrap = document.createElement("div"); wrap.className = "pmk136-add-options";
        const choices = [
            ["Une donnée de la notice", "Exemple : le titre en 200$a, le résumé en 330$a ou un auteur en 700$a.", openAddFieldDialog],
            ["Un encadré avec du texte", "Un titre et un texte que vous rédigez, avec des données de la notice si besoin.", openCustomBlockDialog],
            ["Plusieurs données ensemble", "Exemple : collection, numéro de volume et séparateurs sur une même ligne.", openCompositeDialog],
            ["Un titre, une image ou un bouton", "Ajouter un élément de présentation et régler son apparence.", openGenericElementDialog]
        ];
        choices.forEach(function (choice) {
            const button = createButton(choice[0], "btn btn-outline-secondary", function () { box.remove(); choice[2](); });
            const help = document.createElement("small"); help.textContent = choice[1]; button.appendChild(help); wrap.appendChild(button);
        });
        const box = dialog("Que souhaitez-vous ajouter ?", wrap, [{ label: "Annuler", className: "btn btn-outline-secondary", run: function (box) { box.remove(); } }]);
    }

    function sourceControl() {
        const wrap = document.createElement("div");
        wrap.className = "pmk135-section";
        wrap.innerHTML = '<h4>Ouvrir une feuille XSLT</h4><p>Une feuille XSLT décrit la façon dont Koha affiche les informations d’une notice. Ouvrez votre fichier actuel ou collez son contenu complet.</p><p class="pmk135-muted">Vos projets sont enregistrés dans ce navigateur. L’éditeur ne modifie pas les préférences ni les fichiers de votre Koha.</p>';
        const use = document.createElement("select");
        use.className = "form-control";
        use.innerHTML = '<option value="">Notice bibliographique — usage général</option>' + KNOWN_PREFS.map(function (pref) { return '<option value="' + esc(pref.id) + '">' + esc(pref.label) + '</option>'; }).join("");
        use.value = currentProject.syspref || "";
        use.addEventListener("change", function () { currentProject.syspref = use.value; saveProject(currentProject); });
        wrap.appendChild(makeField("Quel affichage modifiez-vous ?", use, "Ce choix détermine le type de notice utilisé pour l’aperçu."));
        wrap.appendChild(createButton(workingDoc ? "Remplacer par un autre XSLT" : "Choisir un fichier ou coller mon XSLT", "btn btn-primary", function () { openPasteDialog(); }, "fa fa-file-import"));
        if (workingDoc) {
            const info = document.createElement("p");
            info.style.marginTop = "1rem";
            info.textContent = "XSLT chargé : " + (currentProject.importedFilename || currentProject.name || "contenu collé");
            wrap.appendChild(info);
            const tools = document.createElement("div");
            tools.className = "pmk135-toolbar";
            tools.appendChild(createButton("Reprendre les modifications", "btn btn-primary", function () { setWorkspaceStep("build"); }, "fa fa-arrow-right"));
            tools.appendChild(createButton("Revenir au XSLT importé", "btn btn-outline-secondary", function () {
                if (!currentProject.sourceXml) return;
                if (window.confirm("Annuler les modifications et revenir au contenu importé ?")) setWorkingXml(currentProject.sourceXml, false);
            }, "fa fa-undo"));
            wrap.appendChild(tools);
            const deps = normalizeDependenciesProject();
            if (deps.length) {
                const extra = document.createElement("details");
                extra.style.marginTop = "1rem";
                extra.innerHTML = '<summary>Fichiers complémentaires pour l’aperçu (facultatif)</summary><p>Si l’aperçu réclame un fichier comme Utils.xsl, collez son contenu ici. Le XSLT final conserve ses références d’origine.</p>';
                deps.forEach(function (dep) {
                    const row = document.createElement("div"); row.className = "pmk135-toolbar";
                    const name = document.createElement("span"); name.textContent = dependencyBasename(dep.href) + (clean(dep.customXml || dep.sourceXml) ? " — ajouté" : " — non ajouté");
                    row.appendChild(name);
                    row.appendChild(createButton("Ajouter le contenu", "btn btn-sm btn-outline-secondary", function () { importDependencyManually(dep); }));
                    extra.appendChild(row);
                });
                wrap.appendChild(extra);
            }
        }
        return wrap;
    }

    function setWorkspaceStep(step) {
        if (!["source", "build", "publish"].includes(step)) return;
        if (!workingDoc && step !== "source") step = "source";
        activeWorkspaceStep = step;
        if (currentProject) {
            currentProject.activeStep = step;
            saveProject(currentProject);
        }
        renderWorkspace();
        renderStructure();
        renderInspector();
        app?.querySelector(".pmk136-navigation [aria-current=step]")?.focus();
    }

    function renderStepBar() {
        const bar = document.createElement("div"); bar.className = "pmk136-stepbar";
        [["source", "1. Ouvrir un XSLT"], ["build", "2. Modifier et prévisualiser"], ["publish", "3. Vérifier et exporter"]].forEach(function (item) {
            const button = createButton(item[1], "", function () { setWorkspaceStep(item[0]); });
            button.classList.toggle("is-active", activeWorkspaceStep === item[0]);
            if(activeWorkspaceStep===item[0])button.setAttribute("aria-current","step");
            button.disabled = !workingDoc && item[0] !== "source";
            bar.appendChild(button);
        });
        return bar;
    }

    function renderBuildStep(body) {
        const kind = currentRecordKind();
        const noun = kind === "authority" ? "autorité" : "notice";
        const idKey = kind === "authority" ? "previewAuthorityId" : "previewBiblionumber";
        const knownRecords = currentProject.previewRecords.filter(function (r) { return (r.kind || "biblio") === kind; });
        if (!currentProject[idKey]) {
            const fromPage = currentPageRecordId(kind);
            const fallback = fromPage || (knownRecords[0] && knownRecords[0].id) || "";
            if (fallback) { currentProject[idKey] = fallback; saveProject(currentProject); }
        }

        const live = document.createElement("div");
        live.className = "pmk135-section pmk136-live-preview-section";
        const liveHead = document.createElement("div");
        liveHead.className = "pmk136-live-preview-head";
        liveHead.innerHTML = '<h4><i class="fa fa-eye" aria-hidden="true"></i> Aperçu en direct</h4><span id="pmk136-live-preview-status" class="pmk136-live-preview-status">Automatique</span>';
        live.appendChild(liveHead);

        const controls = document.createElement("div");
        controls.className = "pmk136-live-controls";
        const idInput = document.createElement("input");
        idInput.className = "form-control form-control-sm";
        idInput.inputMode = "numeric";
        idInput.placeholder = kind === "authority" ? "Numéro d’autorité" : "Numéro de notice, ex. 380818";
        idInput.value = currentProject[idKey] || "";
        idInput.addEventListener("input", function () {
            currentProject[idKey] = clean(idInput.value).replace(/\D/g, "");
            saveProject(currentProject);
            scheduleAutoPreview(false);
        });
        controls.appendChild(makeField(kind === "authority" ? "Autorité de test" : "Notice de test", idInput, "Conservée pour les prochaines modifications."));

        const compareWrap = document.createElement("label");
        compareWrap.className = "pmk135-toggle-line";
        const compare = document.createElement("input");
        compare.type = "checkbox";
        compare.checked = !!currentProject.autoPreviewCompare;
        compare.addEventListener("change", function () {
            currentProject.autoPreviewCompare = compare.checked;
            saveProject(currentProject);
            scheduleAutoPreview(true);
        });
        compareWrap.appendChild(compare);
        compareWrap.appendChild(document.createTextNode(" Avant / après"));
        controls.appendChild(compareWrap);
        const automaticLabel=document.createElement('label');automaticLabel.className='pmk135-toggle-line';
        const automatic=document.createElement('input');automatic.type='checkbox';automatic.checked=currentProject.autoPreview!==false;
        automaticLabel.append(automatic,document.createTextNode(' Mise à jour automatique'));
        automatic.addEventListener('change',()=>{currentProject.autoPreview=automatic.checked;saveProject(currentProject);scheduleAutoPreview(true);});
        controls.appendChild(automaticLabel);

        const previewTools = document.createElement("div");
        previewTools.className = "pmk135-toolbar";
        previewTools.appendChild(createButton("Actualiser", "btn btn-sm btn-primary", function () {
            const id = clean(idInput.value).replace(/\D/g, "");
            currentProject[idKey] = id;
            saveProject(currentProject);
            if (id) marcPreviewCache.delete(kind + ":" + id);
            scheduleAutoPreview(true,true);
        }, "fa fa-sync"));
        if (kind === "biblio") {
            previewTools.appendChild(createButton("Choisir une notice", "btn btn-sm btn-outline-secondary", function () {
                openPreviewSearchDialog(idInput, livePreview, { auto: true });
            }, "fa fa-search"));
        } else {
            previewTools.appendChild(createButton("Recherche autorités", "btn btn-sm btn-outline-secondary", function () {
                window.open('/cgi-bin/koha/authorities/authorities-home.pl', '_blank', 'noopener');
            }, "fa fa-search"));
        }
        controls.appendChild(previewTools);
        live.appendChild(controls);

        const hint = document.createElement("div");
        hint.className = "alert alert-light";
        hint.innerHTML = '<strong>Édition visuelle :</strong> l’aperçu se met à jour après chaque changement. Survolez puis cliquez directement sur un élément du rendu pour sélectionner le bloc XSLT qui le génère.';
        live.appendChild(hint);

        const livePreview = document.createElement("div");
        livePreview.id = "pmk136-live-preview";
        livePreview.className = "pmk135-real-preview pmk136-live-preview";
        live.appendChild(livePreview);
        body.appendChild(live);

        scheduleAutoPreview(true);
    }

    function renderPublishStep(body) {
        const section = document.createElement("div"); section.className = "pmk135-section";
        section.innerHTML = '<h4>Vérifier et récupérer le résultat</h4><p>Vérifiez le document, puis téléchargez le fichier XSLT ou copiez son code complet. Le fichier conserve les modèles, les conditions et les références aux fichiers complémentaires.</p>';
        const tools = document.createElement("div"); tools.className = "pmk135-toolbar";
        tools.appendChild(createButton('Télécharger le fichier XSLT','btn btn-primary',downloadXslt,'fa fa-download'));
        tools.appendChild(createButton('Sauvegarder le projet','btn btn-outline-secondary',downloadProject,'fa fa-save'));
        tools.appendChild(createButton("Copier tout le XSLT", "btn btn-primary", copyOutput, "fa fa-copy"));
        const ta = document.createElement("textarea");
        ta.id = "pmk136-output"; ta.className = "form-control pmk135-code"; ta.rows = 24;
        ta.readOnly = true; ta.spellcheck = false; ta.value = serializeDoc(workingDoc, true);
        ta.setAttribute("aria-label", "XSLT complet prêt à copier");
        tools.appendChild(createButton("Sélectionner tout le code", "btn btn-outline-secondary", function () { ta.focus(); ta.select(); }));
        tools.appendChild(createButton("Retour aux modifications", "btn btn-outline-secondary", function () { setWorkspaceStep("build"); }));
        section.appendChild(tools);
        const status = document.createElement("p"); status.id = "pmk136-copy-status"; status.setAttribute("role", "status"); section.appendChild(status);
        section.appendChild(ta);
        const checks = document.createElement("details"); checks.style.marginTop = "1rem";
        checks.open=true;
        checks.innerHTML = '<summary>Vérifications avant utilisation dans Koha</summary><p>Le contrôle vérifie le code et, si une notice de test est choisie, sa transformation. Les fonctions et fichiers fournis par Koha peuvent nécessiter une vérification dans Koha.</p>';
        checks.appendChild(createButton("Lancer les vérifications", "btn btn-sm btn-outline-secondary", validateCurrent));
        checks.appendChild(renderValidationReport()); section.appendChild(checks);
        body.appendChild(section);
    }

    function renderWorkspace() {
        if (!app || !currentProject) return;
        normalizePreviewProject();
        if (!workingDoc) activeWorkspaceStep = "source";
        app.classList.toggle("pmk136-focus-step", activeWorkspaceStep !== "build");
        const pane = app.querySelector(".pmk135-pane-workspace");
        // Input changes keep the preview and its controls in place.
        if (activeWorkspaceStep === "build" && pane.dataset.step === "build" && pane.dataset.project === currentProject.id && pane.querySelector("#pmk136-live-preview")) {
            scheduleAutoPreview(false); return;
        }
        pane.innerHTML = "";
        pane.dataset.step = activeWorkspaceStep; pane.dataset.project = currentProject.id;
        const navigation=app.querySelector(".pmk136-navigation");if(navigation)navigation.replaceChildren(renderStepBar());
        const body = document.createElement("div"); body.className = "pmk135-workspace"; pane.appendChild(body);
        if (activeWorkspaceStep === "source") body.appendChild(sourceControl());
        else if (activeWorkspaceStep === "build") renderBuildStep(body);
        else renderPublishStep(body);
    }

    function tabButton(label, id, active) {
        const b = document.createElement("button");
        b.type = "button";
        b.dataset.tab = id;
        b.textContent = label;
        if (active) b.classList.add("is-active");
        return b;
    }

    function makeField(label, control, help) {
        const wrap = document.createElement("div");
        wrap.className = "pmk135-field";
        const l = document.createElement("label");
        l.textContent = label;
        if (control && /^(INPUT|SELECT|TEXTAREA)$/.test(control.tagName)) { if (!control.id) control.id = uid("pmk136-input"); l.htmlFor = control.id; }
        if (/^(Classes? CSS|ID HTML|Classe responsive|Classe d’infobulle|Position souhaitée|Balise)/.test(label)) wrap.classList.add("pmk136-advanced-only");
        wrap.appendChild(l);
        wrap.appendChild(control);
        if (help) {
            const small = document.createElement("small");
            small.textContent = help;
            wrap.appendChild(small);
        }
        return wrap;
    }

    function renderInspector(tab) {
        if (!app) return;
        const pane = app.querySelector(".pmk135-pane-inspector");
        if (!pane) return;
        const wantedTab = tab || pane.dataset.activeTab || "properties";
        pane.dataset.activeTab = wantedTab;
        pane.innerHTML = "";

        const head = document.createElement("div");
        head.className = "pmk135-pane-head";
        head.innerHTML = "<strong>Réglages du bloc sélectionné</strong>";
        pane.appendChild(head);

        if (!workingDoc) {
            pane.insertAdjacentHTML("beforeend", '<div class="pmk135-empty">Les propriétés apparaîtront après chargement d’un XSLT.</div>');
            return;
        }
        if (activeWorkspaceStep !== "build") {
            pane.insertAdjacentHTML("beforeend", '<div class="pmk135-empty"><i class="fa fa-sliders-h"></i>Cliquez sur un élément dans « Modifier l’affichage » pour accéder à ses réglages.</div>');
            return;
        }

        const tabs = document.createElement("div");
        tabs.className = "pmk135-tabs";
        const inspectorTabs = [
            ["Contenu", "properties"],
            ["Quand l’afficher", "conditions"],
            ["Au clic", "link"],
            ["Mise en forme", "style"],
            ["Texte au survol", "tooltip"]
        ];
        if (currentUiMode() === "advanced") inspectorTabs.push(["Avancé", "raw"]);
        if (wantedTab === "raw" && currentUiMode() !== "advanced") pane.dataset.activeTab = "properties";
        inspectorTabs.forEach(function (t) {
            const b = tabButton(t[0], t[1], wantedTab === t[1]);
            b.addEventListener("click", function () { renderInspector(t[1]); });
            tabs.appendChild(b);
        });
        pane.appendChild(tabs);

        const body = document.createElement("div");
        body.className = "pmk135-inspector";
        pane.appendChild(body);

        const effectiveTab = (wantedTab === "raw" && currentUiMode() !== "advanced") ? "properties" : wantedTab;
        const node = findNode(selectedNodeId);
        if (effectiveTab !== "raw" && !node) {
            body.innerHTML = '<div class="pmk135-empty">Choisissez un bloc dans la liste à gauche ou cliquez sur son rendu dans l’aperçu. Ses réglages apparaîtront ici.</div>';
            return;
        }

        if (effectiveTab === "properties") renderPropertiesTab(body, node);
        else if (effectiveTab === "conditions") renderConditionsTab(body, node);
        else if (effectiveTab === "link") renderLinkTab(body, node);
        else if (effectiveTab === "style") renderStyleTab(body, node);
        else if (effectiveTab === "tooltip") renderTooltipTab(body, node);
        else renderRawTab(body);
    }

    function renderPropertiesTab(body, node) {
        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>Élément sélectionné</h4>';
        const info = document.createElement("div");
        info.innerHTML = '<strong>' + esc(recognitionTitle(node)) + '</strong><p class="pmk135-muted">' + esc(nodeSummary(node)) + '</p>';
        if (currentUiMode() === "advanced") info.insertAdjacentHTML("beforeend", '<p>Balise HTML : &lt;' + esc(node.localName) + '&gt;</p>');
        section.appendChild(info);
        const name = document.createElement("input"); name.className = "form-control form-control-sm";
        name.value = node.getAttribute("data-pmk-xslt-display-name") || ""; name.placeholder = recognitionTitle(node);
        name.addEventListener("input", function () { if (clean(name.value)) node.setAttribute("data-pmk-xslt-display-name", name.value); else node.removeAttribute("data-pmk-xslt-display-name"); saveWorking(); renderStructure(); });
        section.appendChild(makeField("Nom dans la liste des éléments", name, "Un repère pour vous : ce nom n’apparaît pas dans Koha."));
        const display = document.createElement("select");
        display.className = "form-control form-control-sm";
        display.innerHTML = '<option value="">Valeur du XSLT / CSS existant</option><option value="inline">En ligne</option><option value="inline-block">En ligne avec dimensions</option><option value="block">Bloc / nouvelle ligne</option><option value="none">Masqué</option>';
        display.value = getStyleValue(node, "display");
        display.addEventListener("change", function () { setStyleValue(node, "display", display.value); saveWorking(); renderWorkspace(); });
        section.appendChild(makeField("Disposition", display, "Permet de forcer l’affichage sur la même ligne ou en bloc sans modifier la structure XSLT."));

        const visualKind = node.getAttribute("data-pmk-xslt-kind") || "advanced";
        if (visualKind === "field") {
            const refs = directMarcRefs(node);
            if (refs.length === 1) {
                const fieldBox = document.createElement("div"); fieldBox.className = "pmk135-section"; fieldBox.style.marginTop = ".75rem"; fieldBox.innerHTML = "<h4>Donnée de la notice</h4>";
                const fg = document.createElement("div"); fg.className = "pmk135-grid2";
                const tagInput = document.createElement("input"); tagInput.className = "form-control form-control-sm"; tagInput.value = refs[0].tag;
                const subInput = document.createElement("input"); subInput.className = "form-control form-control-sm"; subInput.value = refs[0].subfield;
                function updateImportedField() {
                    const tag = clean(tagInput.value).replace(/[^0-9A-Za-z]/g, "");
                    const sub = clean(subInput.value).replace(/[^0-9A-Za-z]/g, "");
                    if (!tag) return;
                    refs[0].element.setAttribute("select", retargetMarcXPath(refs[0].element.getAttribute("select"),tag,sub));
                    recognizeVisualDocument(workingDoc); saveWorking(); renderStructure(); renderWorkspace();
                }
                tagInput.addEventListener("input", updateImportedField); subInput.addEventListener("input", updateImportedField);
                fg.appendChild(makeField("Zone", tagInput)); fg.appendChild(makeField("Sous-zone", subInput)); fieldBox.appendChild(fg);
                section.appendChild(fieldBox);
            }
        } else if (visualKind === "composite") {
            const refs = descendantMarcRefs(node);
            if (refs.length) {
                const compBox = document.createElement("div"); compBox.className = "pmk135-section"; compBox.style.marginTop = ".75rem"; compBox.innerHTML = "<h4>Zones du groupe de données détecté</h4>";
                refs.slice(0, 12).forEach(function (ref, index) {
                    const row = document.createElement("div"); row.className = "pmk135-grid2";
                    const tagInput = document.createElement("input"); tagInput.className="form-control form-control-sm"; tagInput.value=ref.tag;
                    const subInput = document.createElement("input"); subInput.className="form-control form-control-sm"; subInput.value=ref.subfield;
                    function updateRef() { const t=clean(tagInput.value).replace(/[^0-9A-Za-z]/g,""); const sf=clean(subInput.value).replace(/[^0-9A-Za-z]/g,""); if(!t)return; ref.element.setAttribute("select",retargetMarcXPath(ref.element.getAttribute("select"),t,sf)); recognizeVisualDocument(workingDoc); saveWorking(); renderStructure(); renderWorkspace(); }
                    tagInput.addEventListener("input",updateRef); subInput.addEventListener("input",updateRef);
                    row.appendChild(makeField("Zone " + (index+1),tagInput)); row.appendChild(makeField("Sous-zone",subInput)); compBox.appendChild(row);
                });
                const textNodes = Array.from(node.childNodes || []).filter(function (c) { return c.nodeType === 3; });
                if (textNodes.length) {
                    const sep = document.createElement("textarea"); sep.className="form-control"; sep.rows=3; sep.value=textNodes.map(function(c){return c.nodeValue||"";}).join("⟦séparation⟧");
                    sep.addEventListener("input",function(){ const vals=sep.value.split("⟦séparation⟧"); textNodes.forEach(function(c,i){ c.nodeValue=vals[i] != null ? vals[i] : c.nodeValue; }); saveWorking(); renderStructure(); renderWorkspace(); });
                    compBox.appendChild(makeField("Textes / séparateurs",sep,"Les textes directs du bloc sont séparés par ⟦séparation⟧ pour ne pas les fusionner."));
                }
                section.appendChild(compBox);
            }
        } else if (["text", "group", "group-label", "button", "link"].includes(visualKind)) {
            const textNodes = Array.from(node.childNodes || []).filter(function (c) { return c.nodeType === 3; });
            if (textNodes.length && descendantMarcRefs(node).length === 0) {
                const textBox=document.createElement("div"); textBox.className="pmk135-section"; textBox.style.marginTop=".75rem"; textBox.innerHTML="<h4>Texte détecté</h4>";
                const ta=document.createElement("textarea"); ta.className="form-control"; ta.rows=4; ta.value=textNodes.map(function(c){return c.nodeValue||"";}).join("");
                ta.addEventListener("input",function(){ textNodes[0].nodeValue=ta.value; textNodes.slice(1).forEach(function(c){c.remove();}); saveWorking(); renderStructure(); renderWorkspace(); });
                textBox.appendChild(makeField("Texte affiché",ta,"Modifie uniquement le texte de ce bloc, sans toucher aux conditions XSLT.")); section.appendChild(textBox);
            }
        } else if (visualKind === "image" && node.localName === "img") {
            const imageBox=document.createElement("div"); imageBox.className="pmk135-section"; imageBox.style.marginTop=".75rem"; imageBox.innerHTML="<h4>Image détectée</h4>";
            const ig=document.createElement("div"); ig.className="pmk135-grid2";
            const src=document.createElement("input"); src.className="form-control form-control-sm"; src.value=node.getAttribute("src")||"";
            const alt=document.createElement("input"); alt.className="form-control form-control-sm"; alt.value=node.getAttribute("alt")||"";
            src.addEventListener("input",function(){ if(clean(src.value))node.setAttribute("src",src.value);else node.removeAttribute("src");saveWorking();renderWorkspace(); });
            alt.addEventListener("input",function(){ node.setAttribute("alt",alt.value);saveWorking(); });
            ig.appendChild(makeField("Source",src)); ig.appendChild(makeField("Texte alternatif",alt)); imageBox.appendChild(ig); section.appendChild(imageBox);
        }

        if (node.getAttribute("data-pmk-xslt-generic") === "custom-block") {
            const custom = document.createElement("div");
            custom.className = "pmk135-section";
            custom.style.marginTop = ".75rem";
            custom.innerHTML = "<h4>Contenu du bloc personnalisé</h4>";

            function directCustomRole(role) {
                return Array.from(node.children || []).find(function (child) {
                    return child.getAttribute && child.getAttribute("data-pmk-xslt-custom-role") === role;
                }) || null;
            }
            function templateFromNode(target) {
                if (!target) return "";
                let out = "";
                Array.from(target.childNodes || []).forEach(function (child) {
                    if (child.nodeType === 3) out += child.nodeValue || "";
                    else if (child.nodeType === 1 && child.namespaceURI === XSL_NS && child.localName === "value-of") {
                        const select = child.getAttribute("select") || "";
                        const m = select.match(/datafield\[@tag='([^']+)'\]\/marc:subfield\[@code='([^']+)'\]/);
                        if (m) out += "{" + m[1] + "$" + m[2] + "}";
                    }
                });
                return out;
            }
            function replaceTemplateContent(target, value) {
                if (!target) return;
                while (target.firstChild) target.removeChild(target.firstChild);
                appendTemplateTo(target, value || "");
            }

            let heading = directCustomRole("title");
            const content = directCustomRole("body");

            const titleEdit = document.createElement("input");
            titleEdit.className = "form-control form-control-sm";
            titleEdit.value = templateFromNode(heading);
            titleEdit.placeholder = "Titre facultatif";
            titleEdit.addEventListener("input", function () {
                const value = titleEdit.value;
                if (!heading && clean(value)) {
                    heading = workingDoc.createElement("h4");
                    heading.setAttribute("data-pmk-xslt-custom-role", "title");
                    node.insertBefore(heading, node.firstChild);
                }
                if (heading) {
                    if (clean(value)) replaceTemplateContent(heading, value);
                    else { heading.remove(); heading = null; }
                }
                annotate(workingDoc);
                saveWorking();
                renderStructure();
                renderWorkspace();
            });
            custom.appendChild(makeField("Titre", titleEdit, "Peut contenir des placeholders MARC comme {200$a}."));

            const textEdit = document.createElement("textarea");
            textEdit.className = "form-control";
            textEdit.rows = 7;
            textEdit.value = templateFromNode(content);
            textEdit.addEventListener("input", function () {
                replaceTemplateContent(content, textEdit.value);
                saveWorking();
                renderStructure();
                renderWorkspace();
            });
            custom.appendChild(makeField("Texte", textEdit, "Texte multiligne éditable. Les placeholders MARC sont autorisés."));
            section.appendChild(custom);
        }

        const actions = document.createElement("div");
        actions.className = "pmk135-toolbar";
        actions.style.marginTop = ".7rem";
        actions.appendChild(createButton("Dupliquer", "btn btn-sm btn-outline-secondary", function () {
            const cloneNode = node.cloneNode(true);
            Array.from(cloneNode.querySelectorAll("[data-pmk-xslt-node]")).concat([cloneNode]).forEach(function (el) {
                if (el.nodeType === 1) el.removeAttribute("data-pmk-xslt-node");
            });
            const unit = movableUnit(node);
            unit.parentNode.insertBefore(cloneNode, unit.nextSibling);
            annotate(workingDoc);
            selectedNodeId = cloneNode.getAttribute("data-pmk-xslt-node");
            saveWorking();
            renderAll();
        }, "fa fa-clone"));
        actions.appendChild(createButton("Supprimer", "btn btn-sm btn-outline-danger", function () {
            if (!window.confirm("Supprimer ce bloc du XSLT ?")) return;
            const wrapper = conditionWrapperFor(node);
            if (wrapper) wrapper.remove();
            else node.remove();
            selectedNodeId = getLiteralNodes()[0]?.getAttribute("data-pmk-xslt-node") || null;
            saveWorking();
            renderAll();
        }, "fa fa-trash"));
        section.appendChild(actions);
        body.appendChild(section);
    }

    function renderStyleTab(body, node) {
        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>Présentation visuelle</h4>';

        const cls = document.createElement("input");
        cls.type = "text"; cls.className = "form-control form-control-sm";
        cls.value = node.getAttribute("class") || "";
        cls.placeholder = "ex. pmk-auteur text-muted";
        cls.addEventListener("input", function () {
            const v = clean(cls.value); if (v) node.setAttribute("class", v); else node.removeAttribute("class");
            saveWorking(); renderStructure(); renderWorkspace();
        });
        section.appendChild(makeField("Classes CSS", cls, "Classes libres. Elles peuvent être ciblées ensuite dans IntranetUserCSS / OPACUserCSS."));

        const id = document.createElement("input");
        id.type = "text"; id.className = "form-control form-control-sm"; id.value = node.getAttribute("id") || "";
        id.addEventListener("input", function () { const v = clean(id.value); if (v) node.setAttribute("id", v); else node.removeAttribute("id"); saveWorking(); });
        section.appendChild(makeField("ID HTML", id));

        const grid = document.createElement("div"); grid.className = "pmk135-grid2";
        function styleInput(label, prop, placeholder, type) {
            const i = document.createElement("input"); i.className = "form-control form-control-sm"; i.type = type || "text"; i.value = getStyleValue(node, prop); i.placeholder = placeholder || "";
            i.addEventListener("input", function () { setStyleValue(node, prop, i.value); saveWorking(); renderWorkspace(); });
            grid.appendChild(makeField(label, i)); return i;
        }
        styleInput("Couleur du texte", "color", "#212529", "color");
        styleInput("Couleur de fond", "background-color", "#ffffff", "color");
        styleInput("Taille", "font-size", "16px");
        styleInput("Graisse", "font-weight", "400 / 600 / bold");
        styleInput("Marges", "margin", "0 .5rem");
        styleInput("Espacement interne", "padding", ".25rem .5rem");
        styleInput("Largeur", "width", "auto / 100% / 240px");
        styleInput("Rayon bordure", "border-radius", ".4rem");
        styleInput("Couleur bordure", "border-color", "#ced4da", "color");
        styleInput("Épaisseur bordure", "border-width", "1px");
        section.appendChild(grid);

        const borderStyle = document.createElement("select"); borderStyle.className = "form-control form-control-sm";
        borderStyle.innerHTML = '<option value="">Aucune / existante</option><option value="solid">Continue</option><option value="dashed">Tirets</option><option value="dotted">Pointillée</option><option value="double">Double</option>';
        borderStyle.value = getStyleValue(node, "border-style");
        borderStyle.addEventListener("change", function () { setStyleValue(node, "border-style", borderStyle.value); saveWorking(); renderWorkspace(); });
        section.appendChild(makeField("Style de bordure", borderStyle));

        const align = document.createElement("select"); align.className = "form-control form-control-sm";
        align.innerHTML = '<option value="">Par défaut</option><option value="left">Gauche</option><option value="center">Centré</option><option value="right">Droite</option><option value="justify">Justifié</option>';
        align.value = getStyleValue(node, "text-align");
        align.addEventListener("change", function () { setStyleValue(node, "text-align", align.value); saveWorking(); renderWorkspace(); });
        section.appendChild(makeField("Alignement", align));

        const buttons = document.createElement("div"); buttons.className = "pmk135-style-buttons";
        function toggleStyle(label, prop, onValue, offValue) {
            const b = createButton(label, "btn btn-sm btn-outline-secondary", function () {
                const active = getStyleValue(node, prop) === onValue;
                setStyleValue(node, prop, active ? (offValue || "") : onValue); saveWorking(); renderInspector("style"); renderWorkspace();
            });
            if (getStyleValue(node, prop) === onValue) b.classList.add("active"); buttons.appendChild(b);
        }
        toggleStyle("Gras", "font-weight", "bold");
        toggleStyle("Italique", "font-style", "italic");
        toggleStyle("Souligné", "text-decoration", "underline");
        toggleStyle("Barré", "text-decoration", "line-through");
        section.appendChild(makeField("Raccourcis", buttons));

        const responsive = document.createElement("input"); responsive.className = "form-control form-control-sm";
        responsive.value = node.getAttribute("data-pmk-xslt-responsive-class") || ""; responsive.placeholder = "ex. pmk-hide-mobile";
        responsive.addEventListener("input", function () {
            const old = node.getAttribute("data-pmk-xslt-responsive-class") || "";
            let classes = (node.getAttribute("class") || "").split(/\s+/).filter(Boolean).filter(function (c) { return c !== old; });
            const v = clean(responsive.value); if (v) classes.push(v);
            if (classes.length) node.setAttribute("class", Array.from(new Set(classes)).join(" ")); else node.removeAttribute("class");
            if (v) node.setAttribute("data-pmk-xslt-responsive-class", v); else node.removeAttribute("data-pmk-xslt-responsive-class");
            saveWorking(); renderStructure();
        });
        section.appendChild(makeField("Classe responsive / hover", responsive, "Pour les règles dépendant de la taille d’écran ou du :hover, utilise une classe définie dans le CSS Koha."));

        const icon = getIconMeta(node);
        const iconGrid = document.createElement("div"); iconGrid.className = "pmk135-grid2";
        const iconType = document.createElement("select"); iconType.className = "form-control form-control-sm"; iconType.innerHTML = '<option value="none">Aucune</option><option value="fa">Font Awesome</option><option value="image">Image</option>'; iconType.value = icon.type || "none";
        const iconValue = document.createElement("input"); iconValue.className = "form-control form-control-sm"; iconValue.value = icon.value || ""; iconValue.placeholder = "fa fa-book ou URL image";
        const iconPos = document.createElement("select"); iconPos.className = "form-control form-control-sm"; iconPos.innerHTML = '<option value="before">Avant</option><option value="after">Après</option>'; iconPos.value = icon.position || "before";
        const iconSize = document.createElement("input"); iconSize.className = "form-control form-control-sm"; iconSize.type = "number"; iconSize.min = "8"; iconSize.max = "96"; iconSize.value = icon.size || ""; iconSize.placeholder = "16";
        function updateIcon() { applyIcon(node, { type: iconType.value, value: iconValue.value, position: iconPos.value, size: iconSize.value }); saveWorking(); renderWorkspace(); }
        [iconType,iconValue,iconPos,iconSize].forEach(function (c) { c.addEventListener(c.tagName === "SELECT" ? "change" : "input", updateIcon); });
        iconGrid.appendChild(makeField("Icône", iconType)); iconGrid.appendChild(makeField("Classe / URL", iconValue)); iconGrid.appendChild(makeField("Position", iconPos)); iconGrid.appendChild(makeField("Taille px", iconSize));
        section.appendChild(iconGrid);
        body.appendChild(section);
    }

    function renderTooltipTab(body, node) {
        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>Infobulle et accessibilité</h4>';

        const text = document.createElement("textarea"); text.className = "form-control form-control-sm"; text.rows = 3;
        text.value = node.getAttribute("title") || ""; text.placeholder = "Texte affiché au survol…";
        text.addEventListener("input", function () { const v = clean(text.value); if (v) node.setAttribute("title", v); else node.removeAttribute("title"); saveWorking(); renderStructure(); renderWorkspace(); });
        section.appendChild(makeField("Texte de l’infobulle", text, "Utilise title : fonctionne sans bibliothèque JavaScript supplémentaire."));

        const aria = document.createElement("input"); aria.type = "text"; aria.className = "form-control form-control-sm"; aria.value = node.getAttribute("aria-label") || ""; aria.placeholder = "Libellé accessible";
        aria.addEventListener("input", function () { const v = clean(aria.value); if (v) node.setAttribute("aria-label", v); else node.removeAttribute("aria-label"); saveWorking(); });
        section.appendChild(makeField("aria-label", aria));

        const position = document.createElement("select"); position.className = "form-control form-control-sm";
        position.innerHTML = '<option value="auto">Automatique</option><option value="top">Haut</option><option value="right">Droite</option><option value="bottom">Bas</option><option value="left">Gauche</option>';
        position.value = node.getAttribute("data-pmk-xslt-tooltip-position") || "auto";
        position.addEventListener("change", function () { node.setAttribute("data-pmk-xslt-tooltip-position", position.value); saveWorking(); });
        section.appendChild(makeField("Position souhaitée", position, "Mémorisée pour un futur moteur d’infobulles PMK ; title natif reste le repli universel."));

        const tipClass = document.createElement("input"); tipClass.type = "text"; tipClass.className = "form-control form-control-sm"; tipClass.value = node.getAttribute("data-tooltip-class") || ""; tipClass.placeholder = "ex. pmk-tooltip-important";
        tipClass.addEventListener("input", function () { const v = clean(tipClass.value); if (v) node.setAttribute("data-tooltip-class", v); else node.removeAttribute("data-tooltip-class"); saveWorking(); });
        section.appendChild(makeField("Classe d’infobulle avancée", tipClass, "Cette classe reste dans le HTML exporté et peut recevoir ton propre rendu CSS/JS."));
        body.appendChild(section);
    }

    function conditionEditorRow(meta, index, rerender) {
        const rule = meta.rules[index];
        const row = document.createElement("div");
        row.className = "pmk135-condition-row";

        const source = document.createElement("select");
        source.className = "form-control form-control-sm";
        source.innerHTML = '<option value="marc">Champ MARC</option>' + ((currentUiMode() === "advanced" || rule.source === "xpath") ? '<option value="xpath">XPath avancé</option>' : '');
        source.value = rule.source || "marc";
        source.addEventListener("change", function () { rule.source = source.value; rerender(); });
        row.appendChild(source);

        const tag = document.createElement("input");
        tag.className = "form-control form-control-sm";
        tag.placeholder = "200";
        tag.value = rule.tag || "";
        tag.title = "Zone MARC";
        tag.disabled = source.value === "xpath";
        tag.addEventListener("input", function () { rule.tag = tag.value; saveConditionDraft(meta); });
        row.appendChild(tag);

        const sub = document.createElement("input");
        sub.className = "form-control form-control-sm";
        sub.placeholder = "a";
        sub.value = rule.subfield || "";
        sub.title = "Sous-zone";
        sub.disabled = source.value === "xpath";
        sub.addEventListener("input", function () { rule.subfield = sub.value; saveConditionDraft(meta); });
        row.appendChild(sub);

        const operator = document.createElement("select");
        operator.className = "form-control form-control-sm";
        const operatorOptions = [
            ["not-empty", "n’est pas vide"],
            ["empty", "est vide"],
            ["exists", "existe"],
            ["equals", "est égal à"],
            ["not-equals", "est différent de"],
            ["contains", "contient"],
            ["starts-with", "commence par"]
        ];
        if (currentUiMode() === "advanced" || rule.operator === "custom") operatorOptions.push(["custom", "XPath personnalisé"]);
        operator.innerHTML = operatorOptions.map(function (x) { return '<option value="' + x[0] + '">' + x[1] + '</option>'; }).join("");
        operator.value = rule.operator || "not-empty";
        operator.addEventListener("change", function () { rule.operator = operator.value; rerender(); });
        row.appendChild(operator);

        const second = document.createElement("div");
        second.style.gridColumn = "1 / -1";
        second.className = "pmk135-grid2";

        if (source.value === "xpath") {
            const xp = document.createElement("input");
            xp.className = "form-control form-control-sm";
            xp.placeholder = "normalize-space(marc:datafield[@tag='200']/marc:subfield[@code='a']) != ''";
            xp.value = rule.xpath || "";
            xp.addEventListener("input", function () { rule.xpath = xp.value; saveConditionDraft(meta); });
            second.appendChild(makeField("XPath", xp));
        }
        if (["equals", "not-equals", "contains", "starts-with"].includes(operator.value)) {
            const value = document.createElement("input");
            value.className = "form-control form-control-sm";
            value.placeholder = "Valeur";
            value.value = rule.value || "";
            value.addEventListener("input", function () { rule.value = value.value; saveConditionDraft(meta); });
            second.appendChild(makeField("Valeur", value));
        }
        row.appendChild(second);

        const remove = createButton("Retirer", "btn btn-sm btn-outline-danger pmk135-remove-cond", function () {
            meta.rules.splice(index, 1);
            rerender();
        }, "fa fa-times");
        remove.style.gridColumn = "1 / -1";
        row.appendChild(remove);
        return row;
    }

    function saveConditionDraft(meta) {
        const node = findNode(selectedNodeId);
        if (!node) return;
        applyCondition(node, meta);
        saveWorking();
        renderStructure();
        renderWorkspace();
    }

    function renderConditionsTab(body, node) {
        const meta = getConditionMeta(node);
        if (!Array.isArray(meta.rules)) meta.rules = [];

        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>Affichage conditionnel</h4>';

        const enabled = document.createElement("input");
        enabled.type = "checkbox";
        enabled.checked = !!meta.enabled;
        const enabledWrap = document.createElement("label");
        enabledWrap.style.display = "flex";
        enabledWrap.style.gap = ".45rem";
        enabledWrap.style.alignItems = "center";
        enabledWrap.appendChild(enabled);
        enabledWrap.appendChild(document.createTextNode("Afficher ce bloc seulement si les conditions sont vraies"));
        section.appendChild(enabledWrap);

        const join = document.createElement("select");
        join.className = "form-control form-control-sm";
        join.innerHTML = '<option value="and">Toutes les conditions (ET)</option><option value="or">Au moins une condition (OU)</option>';
        join.value = meta.join || "and";
        section.appendChild(makeField("Combinaison", join));

        const list = document.createElement("div");
        section.appendChild(list);

        function rerenderRows() {
            meta.enabled = enabled.checked;
            meta.join = join.value;
            list.innerHTML = "";
            if (!meta.rules.length) {
                const empty = document.createElement("div");
                empty.className = "pmk135-muted";
                empty.textContent = "Aucune condition. Exemple conseillé : 200$a n’est pas vide.";
                list.appendChild(empty);
            }
            meta.rules.forEach(function (_, index) {
                list.appendChild(conditionEditorRow(meta, index, rerenderRows));
            });
            applyCondition(node, meta);
            saveWorking();
            renderStructure();
            renderWorkspace();
        }

        enabled.addEventListener("change", rerenderRows);
        join.addEventListener("change", rerenderRows);
        section.appendChild(createButton("Ajouter une condition", "btn btn-sm btn-outline-primary", function () {
            meta.rules.push({ source: "marc", tag: "200", subfield: "a", operator: "not-empty", value: "", xpath: "" });
            meta.enabled = true;
            enabled.checked = true;
            rerenderRows();
        }, "fa fa-plus"));

        const explanation = document.createElement("div");
        explanation.className = "alert alert-light";
        explanation.style.marginTop = ".7rem";
        explanation.innerHTML = '<strong>Libellé vide :</strong> la condition entoure le bloc complet. Si le bloc contient par exemple « Auteur : » + la valeur MARC, ni le libellé ni l’espace ne seront affichés lorsque le champ est vide.';
        section.appendChild(explanation);

        body.appendChild(section);
        rerenderRows();
    }

    function renderLinkTab(body, node) {
        const meta = getLinkMeta(node);
        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>Lien du bloc / segment</h4>';

        const enabled = document.createElement("input");
        enabled.type = "checkbox";
        enabled.checked = !!meta.enabled;
        const enabledLabel = document.createElement("label");
        enabledLabel.className = "pmk135-toggle-line";
        enabledLabel.appendChild(enabled);
        enabledLabel.appendChild(document.createTextNode("Rendre ce bloc ou segment cliquable"));
        section.appendChild(enabledLabel);

        const mode = document.createElement("select");
        mode.className = "form-control form-control-sm";
        mode.innerHTML = '<option value="koha">Recherche catalogue Koha</option><option value="external">URL externe dynamique</option><option value="fixed">URL fixe</option>';
        mode.value = meta.mode || "koha";
        section.appendChild(makeField("Type de lien", mode));

        const dynamic = document.createElement("div");
        section.appendChild(dynamic);

        function renderDynamic() {
            dynamic.innerHTML = "";
            if (mode.value === "koha") {
                const g = document.createElement("div"); g.className = "pmk135-grid2";
                const index = document.createElement("input"); index.className = "form-control form-control-sm"; index.value = meta.index || "kw"; index.setAttribute("list", "pmk135-koha-indexes"); index.placeholder = "kw, au, ti, su, se…";
                const dl = document.createElement("datalist"); dl.id = "pmk135-koha-indexes"; ["kw","ti","au","su","se","nb","bc","callnum","pb","yr","itype","branch"].forEach(function (v) { const o=document.createElement("option");o.value=v;dl.appendChild(o); });
                const qtype = document.createElement("select"); qtype.className = "form-control form-control-sm"; qtype.innerHTML = '<option value="contains">Recherche normale</option><option value="exact">Expression exacte</option><option value="starts">Commence par</option><option value="custom">Syntaxe personnalisée</option>'; qtype.value = meta.queryType || "contains";
                const tpl = document.createElement("input"); tpl.className = "form-control form-control-sm"; tpl.value = meta.valueTemplate || "{200$a}"; tpl.placeholder = "{700$a} ou {225$a} {225$v}";
                g.appendChild(makeField("Index Koha", index, "Liste proposée + saisie libre : tout index accepté."));
                g.appendChild(makeField("Type de recherche", qtype));
                dynamic.appendChild(g); dynamic.appendChild(makeField("Valeur / requête", tpl, "Utilise des placeholders MARC : {700$a}, {225$a}, etc. Plusieurs zones peuvent être combinées.")); dynamic.appendChild(dl);
                const base = document.createElement("input"); base.className = "form-control form-control-sm"; base.value = meta.searchBase || "/cgi-bin/koha/catalogue/search.pl";
                dynamic.appendChild(makeField("Chemin de recherche", base, "Modifiable pour rester compatible avec des routes Koha spécifiques."));
                if (qtype.value === "custom") {
                    const cg = document.createElement("div"); cg.className = "pmk135-grid2";
                    const pre = document.createElement("input"); pre.className = "form-control form-control-sm"; pre.value = meta.queryPrefix || ""; pre.placeholder = "préfixe";
                    const suf = document.createElement("input"); suf.className = "form-control form-control-sm"; suf.value = meta.querySuffix || ""; suf.placeholder = "suffixe";
                    pre.addEventListener("input", function () { meta.queryPrefix = pre.value; save(); }); suf.addEventListener("input", function () { meta.querySuffix = suf.value; save(); });
                    cg.appendChild(makeField("Préfixe de requête", pre)); cg.appendChild(makeField("Suffixe de requête", suf)); dynamic.appendChild(cg);
                }
                index.addEventListener("input", function () { meta.index = index.value; save(); });
                qtype.addEventListener("change", function () { meta.queryType = qtype.value; renderDynamic(); save(); });
                tpl.addEventListener("input", function () { meta.valueTemplate = tpl.value; save(); });
                base.addEventListener("input", function () { meta.searchBase = base.value; save(); });
            } else if (mode.value === "external") {
                const tpl = document.createElement("input"); tpl.className = "form-control form-control-sm"; tpl.value = meta.externalTemplate || "https://example.org/?q={200$a}"; tpl.placeholder = "https://service.example/?isbn={010$a}";
                dynamic.appendChild(makeField("Modèle d’URL", tpl, "Les placeholders {zone$sous-zone} sont remplacés par la valeur de la notice."));
                tpl.addEventListener("input", function () { meta.externalTemplate = tpl.value; save(); });
            } else {
                const fixed = document.createElement("input"); fixed.className = "form-control form-control-sm"; fixed.value = meta.fixedUrl || ""; fixed.placeholder = "https://…";
                dynamic.appendChild(makeField("URL fixe", fixed));
                fixed.addEventListener("input", function () { meta.fixedUrl = fixed.value; save(); });
            }

            const target = document.createElement("select"); target.className = "form-control form-control-sm"; target.innerHTML = '<option value="same">Même onglet</option><option value="new">Nouvel onglet</option>'; target.value = meta.target || "same";
            const missing = document.createElement("select"); missing.className = "form-control form-control-sm"; missing.innerHTML = '<option value="plain">Si donnée absente : garder le texte non cliquable</option><option value="hide">Si donnée absente : masquer le contenu lié</option>'; missing.value = meta.missingBehavior || "plain";
            dynamic.appendChild(makeField("Ouverture", target)); dynamic.appendChild(makeField("Donnée manquante", missing));
            const extraCondition = document.createElement("input"); extraCondition.className = "form-control form-control-sm"; extraCondition.value = meta.conditionXPath || ""; extraCondition.placeholder = "XPath optionnel, ex. marc:datafield[@tag='099']/marc:subfield[@code='a']";
            dynamic.appendChild(makeField("Condition supplémentaire du lien", extraCondition, "Le lien n’est créé que si les données dynamiques et cette condition XPath sont vraies."));
            target.addEventListener("change", function () { meta.target = target.value; save(); });
            missing.addEventListener("change", function () { meta.missingBehavior = missing.value; save(); });
            extraCondition.addEventListener("input", function () { meta.conditionXPath = extraCondition.value; save(); });

            const ex = document.createElement("div"); ex.className = "pmk135-link-example"; ex.textContent = "Sortie : " + buildHrefTemplate(meta); dynamic.appendChild(ex);
        }

        function save() {
            meta.enabled = enabled.checked;
            meta.mode = mode.value;
            applyLink(node, meta);
            saveWorking();
            renderStructure();
            renderWorkspace();
        }
        enabled.addEventListener("change", save);
        mode.addEventListener("change", function () { meta.mode = mode.value; renderDynamic(); save(); });
        renderDynamic();

        const help = document.createElement("div"); help.className = "alert alert-light"; help.style.marginTop = ".65rem";
        help.innerHTML = '<strong>Exemples :</strong> <code>{700$a}</code> vers l’index auteur, <code>{225$a}</code> vers l’index collection, ou <code>https://…?isbn={010$a}</code> vers un service externe.';
        section.appendChild(help);
        body.appendChild(section);
    }

    function renderRawTab(body) {
        const section = document.createElement("div");
        section.className = "pmk135-section";
        section.innerHTML = '<h4>XSLT complet</h4>';
        const ta = document.createElement("textarea");
        ta.className = "form-control pmk135-code";
        ta.spellcheck = false;
        ta.value = serializeDoc(workingDoc, true);
        section.appendChild(ta);
        const tools = document.createElement("div");
        tools.className = "pmk135-toolbar";
        tools.style.marginTop = ".6rem";
        tools.appendChild(createButton("Appliquer le code brut", "btn btn-sm btn-outline-danger", function () {
            try {
                setWorkingXml(ta.value, false);
                toast("Code brut appliqué.", "success");
            } catch (e) {
                toast(e.message, "danger");
            }
        }, "fa fa-code"));
        tools.appendChild(createButton("Copier", "btn btn-sm btn-primary", copyOutput, "fa fa-copy"));
        section.appendChild(tools);
        body.appendChild(section);
    }

    function dialog(title, bodyNode, actions) {
        const backdrop = document.createElement("div");
        backdrop.className = "pmk135-dialog-backdrop";
        const box = document.createElement("div");
        box.className = "pmk135-dialog";box.setAttribute("role","dialog");box.setAttribute("aria-modal","true");box.setAttribute("aria-label",title);
        const head = document.createElement("div");
        head.className = "pmk135-dialog-head";
        head.innerHTML = "<strong>" + esc(title) + "</strong>";
        head.appendChild(createButton("Fermer", "btn btn-sm btn-outline-secondary", function () { backdrop.remove(); }, "fa fa-times"));
        box.appendChild(head);
        const body = document.createElement("div");
        body.className = "pmk135-dialog-body";
        body.appendChild(bodyNode);
        box.appendChild(body);
        const foot = document.createElement("div");
        foot.className = "pmk135-dialog-foot";
        actions.forEach(function (a) {
            foot.appendChild(createButton(a.label, a.className, function () { a.run(backdrop); }, a.icon));
        });
        box.appendChild(foot);
        backdrop.appendChild(box);
        document.body.appendChild(backdrop);
        backdrop.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();backdrop.remove();}if(event.key==='Tab'){const nodes=[...box.querySelectorAll('button,input,textarea,select,a[href]')].filter(el=>!el.disabled && el.getClientRects().length);const first=nodes[0],last=nodes[nodes.length-1];if(event.shiftKey && document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first?.focus();}}});
        setTimeout(()=>box.querySelector('input,textarea,button')?.focus(),0);
        return backdrop;
    }

    function openPasteDialog() {
        const projectId = currentProject && currentProject.id;
        const epoch = projectEpoch;
        const wrap = document.createElement("div");
        wrap.innerHTML = '<p>Ouvrez un fichier XSLT ou collez le code complet ci-dessous.</p>';
        const file = document.createElement("input");
        file.type = "file"; file.className = "form-control";
        file.accept = ".xsl,.xslt,.xml,.txt,application/xml,text/xml,text/plain";
        wrap.appendChild(makeField("Choisir mon fichier XSLT", file));
        const ta = document.createElement("textarea");
        ta.className = "form-control pmk135-code"; ta.rows = 16; ta.spellcheck = false;
        ta.placeholder = "Collez ici le XSLT complet, de <?xml… jusqu’à </xsl:stylesheet>.";
        wrap.appendChild(makeField("Ou coller mon XSLT", ta));
        const status = document.createElement("p"); status.className = "pmk135-muted"; wrap.appendChild(status);
        let filename = "", readNo = 0, reading = false;
        function belongsToProject() { return currentProject && currentProject.id === projectId && projectEpoch === epoch; }
        file.addEventListener("change", async function () {
            const chosen = file.files && file.files[0]; if (!chosen) return;
            const request = ++readNo; reading = true; status.textContent = "Lecture du fichier…";
            try {
                const xml = await readLocalXsltFile(chosen);
                if (request !== readNo || !belongsToProject() || !wrap.isConnected) return;
                ta.value = xml; filename = chosen.name; status.textContent = chosen.name + " — prêt à ouvrir";
            } catch (e) { if (request === readNo && wrap.isConnected) status.textContent = e.message; }
            finally { if (request === readNo) reading = false; }
        });
        ta.addEventListener("input", function () { readNo += 1; reading = false; filename = ""; status.textContent = "Contenu collé ou modifié"; });
        dialog("Importer mon XSLT", wrap, [
            { label: "Annuler", className: "btn btn-outline-secondary", run: function (box) { readNo += 1; box.remove(); } },
            { label: "Ouvrir dans l’éditeur", className: "btn btn-primary", icon: "fa fa-arrow-right", run: function (box) {
                if (!belongsToProject()) return toast("Le document courant a changé. Rouvrez l’import.", "warning");
                if (reading) return toast("Le fichier est encore en cours de lecture.", "info");
                try {
                    const doc = parseXml(ta.value); const root = doc.documentElement;
                    if (root.namespaceURI !== XSL_NS || !["stylesheet", "transform"].includes(root.localName)) throw new Error("Collez une feuille XSLT complète : la racine doit être xsl:stylesheet ou xsl:transform.");
                    if (workingDoc && !window.confirm("Remplacer le XSLT actuellement ouvert par ce contenu ?")) return;
                    currentProject.sourceUrl = ""; currentProject.importedFilename = filename;
                    currentProject.name = filename || "XSLT collé";
                    projectHistories.delete(currentProject.id);
                    setWorkingXml(ta.value, true);
                    box.remove(); toast("XSLT ouvert. Choisissez une notice pour l’aperçu.", "success");
                } catch (e) { status.textContent = e.message; toast(e.message, "danger"); }
            } }
        ]);
        ta.focus();
    }

    function canSafelyContainAddedBlocks(node) {
        if (!node || node.namespaceURI === XSL_NS) return false;
        return ["div", "section", "article", "aside", "main", "nav", "header", "footer", "li", "ul", "ol", "td", "th", "dd", "dt"].includes(String(node.localName || "").toLowerCase());
    }

    function createInsertionChooser() {
        const selected = findNode(selectedNodeId) || getLiteralNodes()[0] || null;
        if (!selected) return null;
        const select = document.createElement("select");
        select.className = "form-control form-control-sm";
        select.innerHTML = '<option value="after">Après le bloc sélectionné</option><option value="before">Avant le bloc sélectionné</option>' +
            (canSafelyContainAddedBlocks(selected) ? '<option value="inside">À l’intérieur du bloc sélectionné</option>' : '');
        const field = makeField("Emplacement", select, "Par défaut, le nouveau bloc est ajouté après le bloc sélectionné. L’ajout à l’intérieur n’est proposé que pour les conteneurs adaptés.");
        return { selected: selected, select: select, field: field };
    }

    function insertNewNodeAtSelection(node, chooser) {
        if (!node || !chooser || !chooser.selected) throw new Error("Aucun emplacement d’insertion valide.");
        const selected = chooser.selected;
        const mode = chooser.select.value || "after";
        if (mode === "inside") {
            if (!canSafelyContainAddedBlocks(selected)) throw new Error("Ce bloc ne peut pas recevoir de nouvel élément à l’intérieur.");
            selected.appendChild(node);
            return;
        }
        const unit = movableUnit(selected);
        if (!unit || !unit.parentNode) throw new Error("Impossible de déterminer le parent du bloc sélectionné.");
        unit.parentNode.insertBefore(node, mode === "before" ? unit : unit.nextSibling);
    }

    function openAddFieldDialog() {
        if (!workingDoc) return;
        const insertion = createInsertionChooser();
        if (!insertion) return toast("Sélectionnez un bloc près duquel ajouter le champ.", "info");

        const wrap = document.createElement("div");
        wrap.appendChild(insertion.field);
        const grid = document.createElement("div");
        grid.className = "pmk135-grid2";
        wrap.appendChild(grid);

        function input(value, placeholder) {
            const i = document.createElement("input");
            i.className = "form-control form-control-sm";
            i.value = value || "";
            i.placeholder = placeholder || "";
            return i;
        }

        const tag = input("200", "200");
        const sub = input("a", "a");
        const label = input("", "ex. Titre :");
        const cls = input("", "ex. pmk-zone-titre");
        const tooltip = input("", "Texte d’aide au survol");
        const separator = input(" ; ", " ; ");
        const wrapperTag = document.createElement("select");
        wrapperTag.className = "form-control form-control-sm";
        wrapperTag.innerHTML = '<option value="span">Sur la même ligne</option><option value="div">Sur une nouvelle ligne</option><option value="li">Élément de liste</option><option value="p">Paragraphe</option>';
        const repeat = document.createElement("select");
        repeat.className = "form-control form-control-sm";
        repeat.innerHTML = '<option value="first">Première valeur</option><option value="all">Toutes les valeurs</option>';
        const hideEmpty = document.createElement("input");
        hideEmpty.type = "checkbox";
        hideEmpty.checked = true;

        grid.appendChild(makeField("Zone MARC", tag));
        grid.appendChild(makeField("Sous-zone", sub));
        grid.appendChild(makeField("Libellé", label));
        grid.appendChild(makeField("Classe CSS", cls));
        grid.appendChild(makeField("Balise HTML", wrapperTag));
        grid.appendChild(makeField("Répétitions", repeat));
        grid.appendChild(makeField("Séparateur", separator));
        grid.appendChild(makeField("Infobulle", tooltip));
        const c = document.createElement("label");
        c.style.display = "flex";
        c.style.alignItems = "center";
        c.style.gap = ".45rem";
        c.appendChild(hideEmpty);
        c.appendChild(document.createTextNode("Ne pas afficher le bloc ni son libellé si la zone est vide"));
        wrap.appendChild(c);

        dialog("Ajouter une donnée de la notice", wrap, [
            { label: "Annuler", className: "btn btn-sm btn-outline-secondary", icon: "fa fa-times", run: function (d) { d.remove(); } },
            { label: "Ajouter", className: "btn btn-sm btn-primary", icon: "fa fa-plus", run: function (d) {
                try {
                    const path = fieldXPath(tag.value, sub.value);
                    if (!path) throw new Error("La zone MARC est obligatoire.");
                    const el = workingDoc.createElement(wrapperTag.value || "span");
                    if (clean(cls.value)) el.setAttribute("class", clean(cls.value));
                    if (clean(tooltip.value)) el.setAttribute("title", clean(tooltip.value));
                    el.setAttribute("data-pmk-xslt-node", uid("node"));
                    if (label.value) el.appendChild(workingDoc.createTextNode(label.value));

                    if (repeat.value === "all") {
                        const each = workingDoc.createElementNS(XSL_NS, "xsl:for-each");
                        each.setAttribute("select", path);
                        const val = workingDoc.createElementNS(XSL_NS, "xsl:value-of");
                        val.setAttribute("select", ".");
                        each.appendChild(val);
                        const ifMore = workingDoc.createElementNS(XSL_NS, "xsl:if");
                        ifMore.setAttribute("test", "position() != last()");
                        ifMore.appendChild(workingDoc.createTextNode(separator.value || " ; "));
                        each.appendChild(ifMore);
                        el.appendChild(each);
                    } else {
                        const val = workingDoc.createElementNS(XSL_NS, "xsl:value-of");
                        val.setAttribute("select", path + "[1]");
                        el.appendChild(val);
                    }
                    insertNewNodeAtSelection(el, insertion);
                    if (hideEmpty.checked) {
                        applyCondition(el, {
                            enabled: true,
                            join: "and",
                            rules: [{ source: "marc", tag: clean(tag.value), subfield: clean(sub.value), operator: "not-empty", value: "", xpath: "" }]
                        });
                    }
                    annotate(workingDoc);
                    selectedNodeId = el.getAttribute("data-pmk-xslt-node");
                    saveWorking();
                    d.remove();
                    renderAll();
                    toast("Bloc MARC ajouté.", "success");
                } catch (e) { toast(e.message, "danger"); }
            } }
        ]);
    }

    function setTemplateAttribute(node, name, template) {
        if (!node || !name) return;
        const value = String(template || "");
        node.removeAttribute(name);
        Array.from(node.childNodes || []).forEach(function (child) {
            if (child.nodeType === 1 && child.namespaceURI === XSL_NS && child.localName === "attribute" && child.getAttribute("data-pmk-xslt-generic-attr") === name) child.remove();
        });
        if (!/\{[0-9A-Za-z]{3}\$[0-9A-Za-z]\}/.test(value)) {
            if (clean(value)) node.setAttribute(name, value);
            return;
        }
        const attr = workingDoc.createElementNS(XSL_NS, "xsl:attribute");
        attr.setAttribute("name", name);
        attr.setAttribute("data-pmk-xslt-generic-attr", name);
        appendTemplateTo(attr, value);
        node.insertBefore(attr, node.firstChild);
    }

    function openCustomBlockDialog() {
        if (!workingDoc) return;
        const insertion = createInsertionChooser();
        if (!insertion) return toast("Sélectionnez un bloc près duquel ajouter le nouveau bloc.", "info");

        const wrap = document.createElement("div");
        wrap.appendChild(insertion.field);
        const intro = document.createElement("div");
        intro.className = "alert alert-light";
        intro.innerHTML = '<strong>Encadré avec titre et texte.</strong> Créez un encadré ou une zone éditoriale indépendante de la notice, avec un titre facultatif et du texte multiligne. Les placeholders MARC comme <code>{200$a}</code> restent possibles si vous souhaitez mêler texte fixe et donnée dynamique.';
        wrap.appendChild(intro);

        function input(value, placeholder) {
            const i = document.createElement("input");
            i.className = "form-control form-control-sm";
            i.value = value || "";
            i.placeholder = placeholder || "";
            return i;
        }

        const grid = document.createElement("div");
        grid.className = "pmk135-grid2";
        const titleInput = input("", "ex. À savoir");
        const wrapper = document.createElement("select");
        wrapper.className = "form-control form-control-sm";
        wrapper.innerHTML = '<option value="div">div</option><option value="section">section</option><option value="aside">aside</option>';
        const titleTag = document.createElement("select");
        titleTag.className = "form-control form-control-sm";
        titleTag.innerHTML = '<option value="h3">h3</option><option value="h4" selected>h4</option><option value="h5">h5</option><option value="strong">strong</option><option value="div">div</option>';
        const bodyTag = document.createElement("select");
        bodyTag.className = "form-control form-control-sm";
        bodyTag.innerHTML = '<option value="div">div</option><option value="p">p</option>';
        const cls = input("pmk-xslt-custom-block", "classe CSS du bloc");
        const htmlId = input("", "id HTML optionnel");
        const tooltip = input("", "infobulle du bloc");

        grid.appendChild(makeField("Titre facultatif", titleInput));
        grid.appendChild(makeField("Balise HTML (technique)", wrapper));
        grid.appendChild(makeField("Balise du titre", titleTag));
        grid.appendChild(makeField("Balise du texte", bodyTag));
        grid.appendChild(makeField("Classe CSS", cls));
        grid.appendChild(makeField("ID HTML", htmlId));
        grid.appendChild(makeField("Infobulle", tooltip));
        wrap.appendChild(grid);

        const bodyText = document.createElement("textarea");
        bodyText.className = "form-control";
        bodyText.rows = 7;
        bodyText.placeholder = "Saisissez ici le texte du bloc.\nLes retours à la ligne seront conservés.\nVous pouvez aussi utiliser {200$a}, {700$a}, etc.";
        wrap.appendChild(makeField("Texte du bloc", bodyText, "Texte fixe ou mixte avec placeholders MARC. Les retours à la ligne sont conservés."));

        const preserveLines = document.createElement("input");
        preserveLines.type = "checkbox";
        preserveLines.checked = true;
        const preserveLabel = document.createElement("label");
        preserveLabel.className = "pmk135-toggle-line";
        preserveLabel.appendChild(preserveLines);
        preserveLabel.appendChild(document.createTextNode("Conserver les retours à la ligne du texte"));
        wrap.appendChild(preserveLabel);

        dialog("Ajouter un bloc personnalisé", wrap, [
            { label: "Annuler", className: "btn btn-sm btn-outline-secondary", icon: "fa fa-times", run: function (d) { d.remove(); } },
            { label: "Ajouter le bloc", className: "btn btn-sm btn-primary", icon: "fa fa-plus", run: function (d) {
                try {
                    const block = workingDoc.createElement(wrapper.value || "div");
                    block.setAttribute("data-pmk-xslt-node", uid("node"));
                    block.setAttribute("data-pmk-xslt-generic", "custom-block");
                    block.setAttribute("data-pmk-xslt-custom-block", "1");
                    if (clean(cls.value)) block.setAttribute("class", clean(cls.value));
                    if (clean(htmlId.value)) block.setAttribute("id", clean(htmlId.value));
                    if (clean(tooltip.value)) block.setAttribute("title", clean(tooltip.value));

                    if (clean(titleInput.value)) {
                        const heading = workingDoc.createElement(titleTag.value || "h4");
                        heading.setAttribute("data-pmk-xslt-custom-role", "title");
                        appendTemplateTo(heading, titleInput.value);
                        block.appendChild(heading);
                    }

                    const content = workingDoc.createElement(bodyTag.value || "div");
                    content.setAttribute("data-pmk-xslt-custom-role", "body");
                    appendTemplateTo(content, bodyText.value || "");
                    if (preserveLines.checked) setStyleValue(content, "white-space", "pre-line");
                    block.appendChild(content);

                    insertNewNodeAtSelection(block, insertion);
                    annotate(workingDoc);
                    selectedNodeId = block.getAttribute("data-pmk-xslt-node");
                    saveWorking();
                    d.remove();
                    renderAll();
                    toast("Encadré de texte ajouté.", "success");
                } catch (e) {
                    toast(e.message, "danger");
                }
            } }
        ]);
    }

    function openGenericElementDialog() {
        if (!workingDoc) return;
        const insertion = createInsertionChooser();
        if (!insertion) return toast("Sélectionnez un bloc près duquel ajouter l’élément.", "info");

        const wrap = document.createElement("div");
        wrap.appendChild(insertion.field);
        const intro = document.createElement("div");
        intro.className = "alert alert-light";
        intro.innerHTML = '<strong>Éléments sans données de notice.</strong> Ajoutez des titres de groupe, textes, images, icônes, boutons, séparateurs, espacements ou conteneurs. Ils restent ensuite configurables dans les onglets Au clic, Mise en forme, Texte au survol et Quand l’afficher.';
        wrap.appendChild(intro);

        const grid = document.createElement("div"); grid.className = "pmk135-grid2"; wrap.appendChild(grid);
        function input(value, placeholder) { const i=document.createElement("input"); i.className="form-control form-control-sm"; i.value=value||""; i.placeholder=placeholder||""; return i; }

        const type=document.createElement("select"); type.className="form-control form-control-sm";
        type.innerHTML='<option value="custom-block">Encadré avec titre et texte</option><option value="group-label">Titre de section</option><option value="text">Texte libre</option><option value="image">Image</option><option value="icon">Icône Font Awesome</option><option value="button">Bouton</option><option value="separator">Ligne de séparation</option><option value="spacer">Espacement</option><option value="container">Groupe vide pour regrouper des éléments</option>';
        const textValue=input("","Texte affiché");
        const cls=input("","classe CSS libre");
        const htmlId=input("","id HTML optionnel");
        const tooltip=input("","infobulle");
        const tag=document.createElement("select"); tag.className="form-control form-control-sm";
        tag.innerHTML='<option value="h3">Titre de section</option><option value="h4">Sous-titre</option><option value="div">Zone sur une nouvelle ligne</option><option value="span">Texte sur la même ligne</option><option value="p">Paragraphe</option><option value="strong">Texte en gras</option>';
        grid.appendChild(makeField("Type",type)); grid.appendChild(makeField("Présentation",tag));
        grid.appendChild(makeField("Texte",textValue)); grid.appendChild(makeField("Classe CSS",cls));
        grid.appendChild(makeField("ID HTML",htmlId)); grid.appendChild(makeField("Infobulle",tooltip));

        const detail=document.createElement("div"); wrap.appendChild(detail);
        const linkBox=document.createElement("div"); linkBox.className="pmk135-section"; linkBox.innerHTML='<h4>Lien initial (facultatif)</h4>'; wrap.appendChild(linkBox);
        const linkEnabled=document.createElement("input"); linkEnabled.type="checkbox";
        const linkEnabledLabel=document.createElement("label"); linkEnabledLabel.className="pmk135-toggle-line"; linkEnabledLabel.appendChild(linkEnabled); linkEnabledLabel.appendChild(document.createTextNode("Rendre l’élément cliquable dès sa création")); linkBox.appendChild(linkEnabledLabel);
        const linkMode=document.createElement("select"); linkMode.className="form-control form-control-sm"; linkMode.innerHTML='<option value="fixed">URL fixe</option><option value="external">URL externe dynamique</option><option value="koha">Recherche catalogue Koha</option>';
        const linkValue=input("","https://… ou modèle {200$a}");
        const linkIndex=input("kw","kw / ti / au / index libre");
        const linkTarget=document.createElement("select"); linkTarget.className="form-control form-control-sm"; linkTarget.innerHTML='<option value="same">Même onglet</option><option value="new">Nouvel onglet</option>';
        const linkGrid=document.createElement("div"); linkGrid.className="pmk135-grid2"; linkGrid.appendChild(makeField("Type de lien",linkMode)); linkGrid.appendChild(makeField("URL / valeur",linkValue,"Les placeholders MARC comme {700$a} sont autorisés.")); linkGrid.appendChild(makeField("Index Koha",linkIndex)); linkGrid.appendChild(makeField("Ouverture",linkTarget)); linkBox.appendChild(linkGrid);

        function renderDetail(){
            detail.innerHTML="";
            const t=type.value;
            if(t==="image"){
                const g=document.createElement("div"); g.className="pmk135-grid2";
                const src=input("","https://…/image.png ou URL avec {010$a}"); const alt=input("","Texte alternatif"); const width=input("","ex. 48px ou 48"); const height=input("","ex. 48px ou 48");
                src.dataset.role="image-src"; alt.dataset.role="image-alt"; width.dataset.role="image-width"; height.dataset.role="image-height";
                g.appendChild(makeField("Source image",src,"Peut être fixe ou dynamique avec placeholders MARC.")); g.appendChild(makeField("Texte alternatif",alt)); g.appendChild(makeField("Largeur",width)); g.appendChild(makeField("Hauteur",height)); detail.appendChild(g);
            } else if(t==="icon"){
                const g=document.createElement("div"); g.className="pmk135-grid2";
                const icon=input("fa fa-star","fa fa-star"); const aria=input("","Libellé accessible"); const size=input("","ex. 18px"); icon.dataset.role="icon-class"; aria.dataset.role="icon-aria"; size.dataset.role="icon-size";
                g.appendChild(makeField("Classe d’icône",icon)); g.appendChild(makeField("Libellé accessible",aria)); g.appendChild(makeField("Taille",size)); detail.appendChild(g);
            } else if(t==="button"){
                const g=document.createElement("div"); g.className="pmk135-grid2";
                const btnClass=input("btn btn-sm btn-outline-primary","classes du bouton"); btnClass.dataset.role="button-class"; g.appendChild(makeField("Classes CSS du bouton",btnClass)); detail.appendChild(g);
            } else if(t==="separator"){
                const g=document.createElement("div"); g.className="pmk135-grid2";
                const thickness=input("1px","1px"); const style=document.createElement("select"); style.className="form-control form-control-sm"; style.innerHTML='<option value="solid">Continu</option><option value="dashed">Tirets</option><option value="dotted">Pointillé</option><option value="double">Double</option>'; const color=input("#ced4da","#ced4da"); thickness.dataset.role="sep-thickness"; style.dataset.role="sep-style"; color.dataset.role="sep-color";
                g.appendChild(makeField("Épaisseur",thickness)); g.appendChild(makeField("Style",style)); g.appendChild(makeField("Couleur",color)); detail.appendChild(g);
            } else if(t==="spacer"){
                const height=input("1rem","1rem"); height.dataset.role="spacer-height"; detail.appendChild(makeField("Hauteur de l’espace",height));
            } else if(t==="container"){
                const note=document.createElement("div"); note.className="pmk135-muted"; note.textContent="Crée un conteneur vide dans lequel vous pourrez ensuite ajouter d’autres blocs et les déplacer."; detail.appendChild(note);
            }
        }
        type.addEventListener("change",renderDetail); renderDetail();

        dialog("Ajouter un élément de présentation",wrap,[
            {label:"Annuler",className:"btn btn-sm btn-outline-secondary",icon:"fa fa-times",run:function(d){d.remove();}},
            {label:"Ajouter",className:"btn btn-sm btn-primary",icon:"fa fa-plus",run:function(d){
                try{
                    const t=type.value; let el;
                    if(t==="custom-block"){
                        d.remove();
                        openCustomBlockDialog();
                        return;
                    }
                    if(t==="image"){
                        el=workingDoc.createElement("span");
                        const image=workingDoc.createElement("img");
                        const src=detail.querySelector('[data-role="image-src"]'); const alt=detail.querySelector('[data-role="image-alt"]'); const width=detail.querySelector('[data-role="image-width"]'); const height=detail.querySelector('[data-role="image-height"]');
                        setTemplateAttribute(image,"src",src?src.value:""); image.setAttribute("alt",alt?alt.value:"");
                        if(width && clean(width.value)) setStyleValue(image,"width",/^\d+$/.test(clean(width.value))?clean(width.value)+"px":clean(width.value));
                        if(height && clean(height.value)) setStyleValue(image,"height",/^\d+$/.test(clean(height.value))?clean(height.value)+"px":clean(height.value));
                        el.appendChild(image);
                    } else if(t==="icon"){
                        el=workingDoc.createElement("span");
                        const iconNode=workingDoc.createElement("i"); const icon=detail.querySelector('[data-role="icon-class"]'); const aria=detail.querySelector('[data-role="icon-aria"]'); const size=detail.querySelector('[data-role="icon-size"]');
                        iconNode.setAttribute("class",clean(icon&&icon.value)||"fa fa-star"); if(clean(aria&&aria.value)){iconNode.setAttribute("aria-label",clean(aria.value));iconNode.removeAttribute("aria-hidden");}else iconNode.setAttribute("aria-hidden","true"); if(size&&clean(size.value)) setStyleValue(iconNode,"font-size",clean(size.value));
                        el.appendChild(iconNode);
                    } else if(t==="separator"){
                        el=workingDoc.createElement("hr"); const th=detail.querySelector('[data-role="sep-thickness"]'); const st=detail.querySelector('[data-role="sep-style"]'); const co=detail.querySelector('[data-role="sep-color"]'); setStyleValue(el,"border-top-width",clean(th&&th.value)||"1px"); setStyleValue(el,"border-top-style",clean(st&&st.value)||"solid"); setStyleValue(el,"border-top-color",clean(co&&co.value)||"#ced4da");
                    } else if(t==="spacer"){
                        el=workingDoc.createElement("div"); const h=detail.querySelector('[data-role="spacer-height"]'); setStyleValue(el,"height",clean(h&&h.value)||"1rem"); el.setAttribute("aria-hidden","true");
                    } else {
                        const chosen=t==="container"?"div":tag.value||"span"; el=workingDoc.createElement(chosen);
                        if(t==="button") { const bc=detail.querySelector('[data-role="button-class"]'); el.setAttribute("class",clean(bc&&bc.value)||"btn btn-sm btn-outline-primary"); }
                        if(t!=="container" && textValue.value) el.appendChild(workingDoc.createTextNode(textValue.value));
                    }
                    el.setAttribute("data-pmk-xslt-node",uid("node")); el.setAttribute("data-pmk-xslt-generic",t);
                    if(t!=="button" && clean(cls.value)) el.setAttribute("class",clean(cls.value)); else if(t==="button" && clean(cls.value)) el.setAttribute("class",((el.getAttribute("class")||"")+" "+clean(cls.value)).trim());
                    if(clean(htmlId.value)) el.setAttribute("id",clean(htmlId.value)); if(clean(tooltip.value)) el.setAttribute("title",clean(tooltip.value));
                    insertNewNodeAtSelection(el, insertion);
                    if(linkEnabled.checked){
                        const meta=getLinkMeta(el); meta.enabled=true; meta.mode=linkMode.value; meta.target=linkTarget.value; meta.index=clean(linkIndex.value)||"kw";
                        if(meta.mode==="fixed") meta.fixedUrl=clean(linkValue.value); else if(meta.mode==="external") meta.externalTemplate=linkValue.value; else meta.valueTemplate=linkValue.value||"{200$a}";
                        applyLink(el,meta);
                    }
                    annotate(workingDoc); selectedNodeId=el.getAttribute("data-pmk-xslt-node"); saveWorking(); d.remove(); renderAll(); toast("Élément ajouté.","success");
                }catch(e){toast(e.message,"danger");}
            }}
        ]);
    }

    function openCompositeDialog() {
        if (!workingDoc) return;
        const insertion = createInsertionChooser();
        if (!insertion) return toast("Sélectionnez un bloc près duquel ajouter le groupe de données.", "info");

        const wrap = document.createElement("div");
        wrap.appendChild(insertion.field);
        const top = document.createElement("div"); top.className = "pmk135-grid2";
        function input(value, placeholder) { const i=document.createElement("input"); i.className="form-control form-control-sm"; i.value=value||""; i.placeholder=placeholder||""; return i; }
        const blockLabel=input("", "ex. Collection : ");
        const blockClass=input("pmk-xslt-composite", "classe CSS");
        const tooltip=input("", "infobulle du bloc");
        const layout=document.createElement("select"); layout.className="form-control form-control-sm"; layout.innerHTML='<option value="inline">Même ligne</option><option value="lines">Une ligne par segment</option>';
        const wrapper=document.createElement("select"); wrapper.className="form-control form-control-sm"; wrapper.innerHTML='<option value="span">Sur la même ligne</option><option value="div">Sur une nouvelle ligne</option><option value="p">Paragraphe</option><option value="li">Élément de liste</option>';
        const hideEmpty=document.createElement("input"); hideEmpty.type="checkbox"; hideEmpty.checked=true;
        top.appendChild(makeField("Texte avant les données",blockLabel)); top.appendChild(makeField("Classe CSS",blockClass)); top.appendChild(makeField("Disposition",layout)); top.appendChild(makeField("Balise HTML (technique)",wrapper)); top.appendChild(makeField("Infobulle",tooltip));
        const he=document.createElement("label"); he.className="pmk135-toggle-line"; he.appendChild(hideEmpty); he.appendChild(document.createTextNode("Masquer le bloc complet et son libellé si toutes les zones sont vides")); top.appendChild(he); wrap.appendChild(top);

        const intro=document.createElement("div"); intro.className="alert alert-light"; intro.innerHTML='Chaque segment peut avoir sa propre zone/sous-zone, son libellé, son séparateur de répétition et son séparateur avant. Les séparateurs sont générés conditionnellement pour éviter les <strong>« ; » orphelins</strong>.'; wrap.appendChild(intro);
        const list=document.createElement("div"); list.className="pmk135-segment-list"; wrap.appendChild(list);
        const segments=[
            {type:"marc",tag:"225",subfield:"a",label:"",before:"",repeat:"first",repeatSeparator:" ; ",className:""},
            {type:"marc",tag:"225",subfield:"v",label:"",before:" ; ",repeat:"first",repeatSeparator:" ; ",className:""}
        ];

        function renderSegments() {
            list.innerHTML="";
            segments.forEach(function(seg,index){
                const row=document.createElement("div"); row.className="pmk135-segment-row";
                const head=document.createElement("div"); head.className="pmk135-segment-head"; head.innerHTML='<i class="fa fa-grip-vertical"></i><strong>Segment '+(index+1)+'</strong>';
                head.appendChild(createButton("↑","btn btn-sm btn-outline-secondary",function(){ if(index>0){ const x=segments.splice(index,1)[0]; segments.splice(index-1,0,x); renderSegments(); }}));
                head.appendChild(createButton("↓","btn btn-sm btn-outline-secondary",function(){ if(index<segments.length-1){ const x=segments.splice(index,1)[0]; segments.splice(index+1,0,x); renderSegments(); }}));
                head.appendChild(createButton("","btn btn-sm btn-outline-danger",function(){ segments.splice(index,1); renderSegments(); },"fa fa-times")); row.appendChild(head);
                const g=document.createElement("div"); g.className="pmk135-grid2";
                const type=document.createElement("select"); type.className="form-control form-control-sm"; type.innerHTML='<option value="marc">Zone MARC</option><option value="text">Texte fixe</option><option value="break">Retour à la ligne</option>'; type.value=seg.type;
                type.addEventListener("change",function(){seg.type=type.value;renderSegments();}); g.appendChild(makeField("Type",type));
                if(seg.type==="marc"){
                    const tag=input(seg.tag||"","200"); const sub=input(seg.subfield||"","a"); const lab=input(seg.label||"","libellé propre"); const before=input(seg.before||""," ; "); const repSep=input(seg.repeatSeparator||" ; "," ; "); const cls=input(seg.className||"","classe CSS du segment");
                    const repeat=document.createElement("select"); repeat.className="form-control form-control-sm"; repeat.innerHTML='<option value="first">Première valeur</option><option value="all">Toutes les occurrences</option>'; repeat.value=seg.repeat||"first";
                    [[tag,"tag"],[sub,"subfield"],[lab,"label"],[before,"before"],[repSep,"repeatSeparator"],[cls,"className"]].forEach(function(pair){pair[0].addEventListener("input",function(){seg[pair[1]]=pair[0].value;});}); repeat.addEventListener("change",function(){seg.repeat=repeat.value;});
                    g.appendChild(makeField("Zone",tag)); g.appendChild(makeField("Sous-zone",sub)); g.appendChild(makeField("Libellé segment",lab)); g.appendChild(makeField("Séparateur avant",before,"Émis uniquement si ce segment et un segment précédent ont une valeur.")); g.appendChild(makeField("Répétitions",repeat)); g.appendChild(makeField("Séparateur entre occurrences",repSep)); g.appendChild(makeField("Classe CSS",cls));
                } else if(seg.type==="text"){
                    const txt=input(seg.text||"","texte libre"); txt.addEventListener("input",function(){seg.text=txt.value;}); g.appendChild(makeField("Texte",txt));
                } else {
                    const note=document.createElement("div"); note.className="pmk135-muted"; note.textContent="Insère un <br/> dans le bloc."; g.appendChild(note);
                }
                row.appendChild(g); list.appendChild(row);
            });
        }
        renderSegments();
        const adds=document.createElement("div"); adds.className="pmk135-toolbar";
        adds.appendChild(createButton("Zone MARC","btn btn-sm btn-outline-primary",function(){segments.push({type:"marc",tag:"200",subfield:"a",label:"",before:" ; ",repeat:"first",repeatSeparator:" ; ",className:""});renderSegments();},"fa fa-plus"));
        adds.appendChild(createButton("Texte libre","btn btn-sm btn-outline-secondary",function(){segments.push({type:"text",text:""});renderSegments();},"fa fa-font"));
        adds.appendChild(createButton("Retour ligne","btn btn-sm btn-outline-secondary",function(){segments.push({type:"break"});renderSegments();},"fa fa-level-down")); wrap.appendChild(adds);

        dialog("Ajouter un groupe de données",wrap,[
            {label:"Annuler",className:"btn btn-sm btn-outline-secondary",icon:"fa fa-times",run:function(d){d.remove();}},
            {label:"Créer le bloc",className:"btn btn-sm btn-primary",icon:"fa fa-check",run:function(d){
                try{
                    if(!segments.length) throw new Error("Ajoutez au moins un segment.");
                    const container=workingDoc.createElement(wrapper.value||"span"); container.setAttribute("data-pmk-xslt-node",uid("node")); container.setAttribute("data-pmk-xslt-composite","1");
                    if(clean(blockClass.value)) container.setAttribute("class",clean(blockClass.value)); if(clean(tooltip.value)) container.setAttribute("title",clean(tooltip.value));
                    if(blockLabel.value) container.appendChild(workingDoc.createTextNode(blockLabel.value));
                    insertNewNodeAtSelection(container, insertion);
                    const fields=[]; const previous=[];
                    segments.forEach(function(seg){
                        if(seg.type==="break"){ container.appendChild(workingDoc.createElement("br")); return; }
                        if(seg.type==="text"){ container.appendChild(workingDoc.createTextNode(seg.text||"")); return; }
                        const path=fieldXPath(seg.tag,seg.subfield); if(!path) return;
                        fields.push({tag:clean(seg.tag),subfield:clean(seg.subfield),path:path});
                        const nonEmpty="normalize-space(string("+path+")) != ''";
                        const segment=workingDoc.createElement("span"); segment.setAttribute("data-pmk-xslt-node",uid("segment")); segment.setAttribute("data-pmk-xslt-segment","1");
                        setJsonAttr(segment,"data-pmk-xslt-segment-meta",seg); if(clean(seg.className)) segment.setAttribute("class",clean(seg.className)); if(seg.label) segment.appendChild(workingDoc.createTextNode(seg.label));
                        if(seg.repeat==="all"){
                            const each=workingDoc.createElementNS(XSL_NS,"xsl:for-each"); each.setAttribute("select",path); const val=workingDoc.createElementNS(XSL_NS,"xsl:value-of"); val.setAttribute("select","."); each.appendChild(val);
                            const more=workingDoc.createElementNS(XSL_NS,"xsl:if"); more.setAttribute("test","position() != last()"); more.appendChild(workingDoc.createTextNode(seg.repeatSeparator||" ; ")); each.appendChild(more); segment.appendChild(each);
                        } else { const val=workingDoc.createElementNS(XSL_NS,"xsl:value-of"); val.setAttribute("select",path+"[1]"); segment.appendChild(val); }
                        container.appendChild(segment);
                        applyCondition(segment,{enabled:true,join:"and",rules:[{source:"marc",tag:clean(seg.tag),subfield:clean(seg.subfield),operator:"not-empty",value:"",xpath:""}]});
                        const segmentWrapper=conditionWrapperFor(segment);
                        if(segmentWrapper && previous.length){
                            const beforeIf=workingDoc.createElementNS(XSL_NS,"xsl:if"); beforeIf.setAttribute("test","("+previous.join(" or ")+")");
                            if(layout.value==="lines") beforeIf.appendChild(workingDoc.createElement("br"));
                            else if(clean(seg.before)) beforeIf.appendChild(workingDoc.createTextNode(seg.before));
                            if(beforeIf.childNodes.length) segmentWrapper.insertBefore(beforeIf,segment);
                        }
                        previous.push(nonEmpty);
                    });
                    if(hideEmpty.checked && fields.length){ applyCondition(container,{enabled:true,join:"or",rules:fields.map(function(f){return {source:"marc",tag:f.tag,subfield:f.subfield,operator:"not-empty",value:"",xpath:""};})}); }
                    annotate(workingDoc); selectedNodeId=container.getAttribute("data-pmk-xslt-node"); saveWorking(); d.remove(); renderAll(); toast("Plusieurs données sur une ligne ajouté.","success");
                }catch(e){toast(e.message,"danger");}
            }}
        ]);
    }

    function openPreviewSearchDialog(targetInput, previewTarget, options) {
        options = options || {};
        normalizePreviewProject();
        const wrap=document.createElement("div"); const g=document.createElement("div"); g.className="pmk135-grid2";
        const term=document.createElement("input"); term.className="form-control form-control-sm"; term.placeholder="titre, auteur, ISBN, code-barres…";
        const index=document.createElement("input"); index.className="form-control form-control-sm"; index.value=currentProject.previewSearchIndex||"kw"; index.placeholder="kw / ti / au / nb / bc / index libre";
        g.appendChild(makeField("Recherche",term)); g.appendChild(makeField("Index Koha",index)); wrap.appendChild(g);
        const results=document.createElement("div"); results.className="pmk135-result-list"; wrap.appendChild(results);
        const d=dialog("Choisir une vraie notice",wrap,[
            {label:"Fermer",className:"btn btn-sm btn-outline-secondary",icon:"fa fa-times",run:function(x){x.remove();}},
            {label:"Rechercher",className:"btn btn-sm btn-primary",icon:"fa fa-search",run:async function(){
                results.innerHTML='<div class="pmk135-muted"><i class="fa fa-spinner fa-spin"></i> Recherche…</div>';
                try{
                    currentProject.previewSearchIndex=clean(index.value)||"kw"; saveProject(currentProject);
                    const rows=await searchPreviewRecords(term.value,index.value); results.innerHTML="";
                    if(!rows.length){results.innerHTML='<div class="pmk135-muted">Aucune notice trouvée.</div>';return;}
                    rows.forEach(function(r){ const row=document.createElement("div"); row.className="pmk135-result"; const label=document.createElement("span"); label.textContent=r.label+" — "+r.id; row.appendChild(label);
                        row.appendChild(createButton("Choisir","btn btn-sm btn-outline-primary",async function(){ targetInput.value=r.id; currentProject.previewBiblionumber=r.id; if(!currentProject.previewRecords.some(function(x){return x.id===r.id && (x.kind || "biblio") === "biblio";})) currentProject.previewRecords.push({ id:r.id, label:r.label, kind:"biblio" }); saveProject(currentProject); d.remove(); if(options.auto){ scheduleAutoPreview(true); } else { await renderRecordPreview(previewTarget,r.id,true); } },"fa fa-check")); results.appendChild(row); });
                }catch(e){results.innerHTML='<div class="alert alert-warning">'+esc(e.message)+'</div>';}
            }}
        ]);
        window.setTimeout(function(){term.focus();},0);
    }

    function validationCheck(level, label, detail) {
        return { level: level, label: label, detail: detail || "" };
    }

    function validationDocuments() {
        const docs = [];
        if (workingDoc) docs.push({ name: "XSLT principal", doc: workingDoc });
        normalizeDependenciesProject().forEach(function (dep) {
            const xml = clean(dep.customXml || dep.sourceXml);
            if (!xml) return;
            try { docs.push({ name: dep.customFilename || dep.href || "Dépendance", doc: parseXml(xml) }); }
            catch (_) {}
        });
        return docs;
    }

    function namedTemplateAudit() {
        const defined = new Set();
        const called = new Set();
        validationDocuments().forEach(function (entry) {
            Array.from(entry.doc.getElementsByTagNameNS(XSL_NS, "template")).forEach(function (el) {
                const name = clean(el.getAttribute("name"));
                if (name) defined.add(name);
            });
            Array.from(entry.doc.getElementsByTagNameNS(XSL_NS, "call-template")).forEach(function (el) {
                const name = clean(el.getAttribute("name"));
                if (name) called.add(name);
            });
        });
        return Array.from(called).filter(function (name) { return !defined.has(name); }).sort();
    }

    async function runValidation() {
        const validationProject = currentProject;
        const validationEpoch = projectEpoch;
        const startedFingerprint = currentProject && workingDoc ? validationFingerprint() : "";
        const checks = [];
        if (!workingDoc || !currentProject) {
            return { status: "error", checks: [validationCheck("error", "Aucun XSLT chargé", "Importez d’abord une feuille XSLT.")], fingerprint: "", at: new Date().toISOString() };
        }

        try {
            const xml = serializeDoc(workingDoc, true);
            const doc = parseXml(xml);
            const root = doc.documentElement;
            if (!(root.namespaceURI === XSL_NS && ["stylesheet", "transform"].includes(root.localName))) {
                checks.push(validationCheck("error", "Racine XSLT invalide", "La racine doit être xsl:stylesheet ou xsl:transform."));
            } else {
                checks.push(validationCheck("ok", "XML lisible et racine XSLT reconnue", "La feuille principale est sérialisable et possède une racine XSLT valide."));
                const version=root.getAttribute('version')||'1.0';
                checks.push(validationCheck(version==='1.0'?'ok':'warn','Compatibilité XSLT '+version,version==='1.0'?'Koha utilise libxslt (XSLT 1.0). Les extensions et inclusions doivent aussi être disponibles sur le serveur.':'Le moteur libxslt de Koha ne prend pas en charge intégralement XSLT '+version+'. Vérifiez les fonctions utilisées avant installation.'));
            }
        } catch (e) {
            checks.push(validationCheck("error", "XML/XSLT principal invalide", e.message));
        }

        const deps = normalizeDependenciesProject();
        const invalidCustom = [];
        deps.forEach(function (dep) {
            if (!dep.custom || !clean(dep.customXml)) return;
            try { parseXml(dep.customXml); }
            catch (e) { invalidCustom.push((dep.customFilename || dep.href || "Dépendance") + " : " + e.message); }
        });
        if (invalidCustom.length) checks.push(validationCheck("error", "Dépendances personnalisées invalides", invalidCustom.join(" · ")));
        else if (deps.some(function (d) { return d.custom; })) checks.push(validationCheck("ok", "Dépendances personnalisées valides", deps.filter(function (d) { return d.custom; }).length + " fichier(s) contrôlé(s)."));

        const unresolved = deps.filter(function (dep) { return !clean(dep.customXml || dep.sourceXml); });
        if (unresolved.length) {
            checks.push(validationCheck("warn", "Dépendances non lisibles dans le navigateur", unresolved.map(function (d) { return dependencyBasename(d.href); }).join(", ") + ". Koha peut néanmoins les résoudre côté serveur ; vérifiez-les avant copie."));
        } else if (deps.length) {
            checks.push(validationCheck("ok", "Dépendances disponibles", deps.length + " dépendance(s) chargée(s) pour les contrôles navigateur."));
        }

        const missingTemplates = namedTemplateAudit();
        if (missingTemplates.length) {
            checks.push(validationCheck(unresolved.length ? "warn" : "error", "Templates appelés non trouvés", missingTemplates.slice(0, 12).join(", ") + (missingTemplates.length > 12 ? "…" : "")));
        } else {
            checks.push(validationCheck("ok", "Appels de templates nommés cohérents", "Aucun xsl:call-template orphelin détecté dans les fichiers actuellement disponibles."));
        }

        if (typeof XSLTProcessor === "undefined") {
            checks.push(validationCheck("warn", "Compilation navigateur indisponible", "Ce navigateur ne fournit pas XSLTProcessor."));
        } else {
            try {
                const proc = new XSLTProcessor();
                proc.importStylesheet(prepareXsltForBrowser(workingDoc));
                checks.push(validationCheck("ok", "Compilation navigateur réussie", "Le navigateur accepte la feuille préparée avec les dépendances connues."));
            } catch (e) {
                checks.push(validationCheck("warn", "Compilation navigateur non concluante", e.message));
            }
        }

        normalizePreviewProject();
        const kind = currentRecordKind();
        const testIds = validationRecordIds(kind);
        if(!testIds.length)checks.push(validationCheck('warn','Aucun enregistrement de test','Ajoutez un identifiant dans l’aperçu pour vérifier une transformation réelle.'));
        for(const id of testIds.slice(0,5)){
            if(currentProject!==validationProject||projectEpoch!==validationEpoch)break;
            try{const marc=await fetchMarcXmlCached(id,kind);transformRecord(workingDoc,marc);checks.push(validationCheck('ok',(kind==='authority'?'Autorité':'Notice')+' test transformée','Identifiant '+id+'.'));}
            catch(error){checks.push(validationCheck('warn','Transformation non concluante — '+id,error.message+' Vérifiez les paramètres et inclusions dans Koha.'));}
        }
        if(testIds.length>5)checks.push(validationCheck('warn','Échantillon de cinq enregistrements','Les cinq premiers identifiants ont été contrôlés. Modifiez la sélection pour en vérifier d’autres.'));

        const status = checks.some(function (c) { return c.level === "error"; }) ? "error" :
            (checks.some(function (c) { return c.level === "warn"; }) ? "warn" : "ok");
        const result = { status: status, checks: checks, fingerprint: startedFingerprint, at: new Date().toISOString() };
        if (currentProject !== validationProject || projectEpoch !== validationEpoch || validationFingerprint() !== startedFingerprint) {
            return { status: "warn", checks: [validationCheck("warn", "Contrôle interrompu", "Le document a changé pendant la vérification. Relancez-la sur le document courant.")], fingerprint: "", at: result.at };
        }
        currentProject.lastValidation = result;
        saveProject(currentProject);
        updateTopbarStatus();
        return result;
    }

    function renderValidationReport() {
        const wrap = document.createElement("div");
        wrap.style.marginTop = ".65rem";
        if (!currentProject || !currentProject.lastValidation) {
            wrap.innerHTML = '<div class="alert alert-info">Aucun contrôle complet n’a encore été exécuté sur cette version du projet.</div>';
            return wrap;
        }
        const result = currentProject.lastValidation;
        const stale = result.fingerprint !== validationFingerprint();
        if (stale) {
            wrap.innerHTML = '<div class="alert alert-warning"><strong>Validation obsolète.</strong> Le XSLT ou une dépendance a été modifié depuis les derniers contrôles.</div>';
            return wrap;
        }
        const summary = document.createElement("div");
        summary.className = result.status === "ok" ? "alert alert-success" : (result.status === "warn" ? "alert alert-warning" : "alert alert-danger");
        summary.innerHTML = result.status === "ok" ? '<strong>Contrôles disponibles réussis.</strong> Aucun problème détecté par les contrôles disponibles.' :
            (result.status === "warn" ? '<strong>Validation avec avertissements.</strong> Relisez les points ci-dessous avant copie.' : '<strong>Erreurs détectées.</strong> Corrigez les erreurs ci-dessous.');
        wrap.appendChild(summary);
        const list = document.createElement("div");
        list.className = "pmk136-validation";
        (result.checks || []).forEach(function (check) {
            const row = document.createElement("div");
            row.className = "pmk136-check " + check.level;
            const icon = check.level === "ok" ? "fa fa-check-circle" : (check.level === "warn" ? "fa fa-exclamation-triangle" : "fa fa-times-circle");
            row.innerHTML = '<i class="' + icon + '" aria-hidden="true"></i><div><strong>' + esc(check.label) + '</strong>' + (check.detail ? '<small>' + esc(check.detail) + '</small>' : '') + '</div>';
            list.appendChild(row);
        });
        wrap.appendChild(list);
        return wrap;
    }

    async function validateCurrent() {
        const result = await runValidation();
        if (app && activeWorkspaceStep === "publish") { const details = app.querySelector(".pmk135-workspace details"); const wasOpen = details && details.open; renderWorkspace(); const next = app.querySelector(".pmk135-workspace details"); if (next) next.open = wasOpen; }
        if (result.status === "ok") toast("Validation terminée : aucun problème détecté.", "success");
        else if (result.status === "warn") toast("Validation terminée avec avertissements.", "warning");
        else toast("Validation terminée : des erreurs doivent être corrigées.", "danger");
        return result;
    }

    function downloadFile(name,type,content) {
        const url=URL.createObjectURL(new Blob([content],{type}));
        const link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }
    function filenameBase() {return (currentProject?.name || 'mon-xslt').replace(/\.(xslt?|xml|json)$/i,'').replace(/[\\/:*?"<>|]/g,'-');}
    function downloadXslt() {
        if(!workingDoc)return;
        downloadFile(filenameBase()+'.xsl','application/xml;charset=utf-8',serializeDoc(workingDoc,true));
    }
    function downloadProject() {
        if(!currentProject)return;
        saveWorking();
        downloadFile(filenameBase()+'.pmk-xslt.json','application/json;charset=utf-8',JSON.stringify({format:'pmk-xslt-project',version:1,project:currentProject},null,2));
    }
    async function restoreProjectFile(file) {
        const imported=JSON.parse(await file.text());
        if(imported.format!=='pmk-xslt-project' || !imported.project || typeof imported.project!=='object')throw new Error('Ce fichier n’est pas une sauvegarde de projet XSLT PMK.');
        const project=clone(imported.project);
        if(project.workingXml) {const doc=parseXml(project.workingXml);if(doc.documentElement.namespaceURI!==XSL_NS || !['stylesheet','transform'].includes(doc.documentElement.localName))throw new Error('La sauvegarde ne contient pas une feuille XSLT valide.');}
        project.id=uid('project');project.name=(project.name || 'Projet restauré')+' — importé';
        if(!saveProject(project))throw new Error('Le navigateur ne peut pas enregistrer ce projet.');
        openProject(project);
    }

    async function copyText(text) {
        try {
            await navigator.clipboard.writeText(text);
            return true;
        } catch (_) {
            const ta = document.createElement("textarea");
            ta.value = text;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            const ok = document.execCommand("copy");
            ta.remove();
            return ok;
        }
    }

    async function copyOutput() {
        if (!workingDoc || !currentProject) return;
        try {
            const xml = serializeDoc(workingDoc, true);
            const doc = parseXml(xml);
            if (doc.documentElement.namespaceURI !== XSL_NS || !["stylesheet", "transform"].includes(doc.documentElement.localName)) throw new Error("La feuille XSLT n’a pas une racine valide.");
            const ok = await copyText(xml);
            const status = app && app.querySelector("#pmk136-copy-status");
            if (status) status.textContent = ok ? "XSLT complet copié. Vous pouvez le coller dans votre fichier." : "Sélectionnez tout le code ci-dessous puis utilisez Ctrl+C.";
            if (!ok) { const ta = app && app.querySelector("#pmk136-output"); if (ta) { ta.focus(); ta.select(); } }
            toast(ok ? "XSLT complet copié." : "Utilisez « Sélectionner tout le code », puis Ctrl+C.", ok ? "success" : "info");
        } catch (e) { toast(e.message, "danger"); }
    }

    function renderAll() {
        renderTopbar();
        renderStructure();
        renderWorkspace();
        renderInspector();
    }

    function openAssistant() {
        addStyles();
        if (moduleConfig.enabled === false || !isSuperlibrarian()) return;
        if (app) return;
        app = document.createElement("div");
        app.className = "pmk135-overlay";
        app.innerHTML = '<div class="pmk135-topbar"></div><nav class="pmk136-navigation" aria-label="Étapes de l’édition XSLT"></nav>' +
            '<div class="pmk135-main">' +
            '<section class="pmk135-pane pmk135-pane-structure"></section>' +
            '<section class="pmk135-pane pmk135-pane-workspace"></section>' +
            '<section class="pmk135-pane pmk135-pane-inspector"></section>' +
            '</div>';
        document.body.appendChild(app);
        pageContext?.setInformationHost?.(app);
        previousOverflow=document.documentElement.style.overflow;
        document.documentElement.style.overflow = "hidden";

        const index = loadIndex().sort((a,b)=>String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")));
        if (index.length) {
            const p = loadProject(index[0].id);
            if (p) currentProject = p;
        }
        if (!currentProject) {
            currentProject = defaultProject();
            saveProject(currentProject);
        }
        openProject(currentProject);
    }

    function closeAssistant() {
        if (!app) return;
        if (autoPreviewTimer) { window.clearTimeout(autoPreviewTimer); autoPreviewTimer = null; }
        autoPreviewRequest += 1;
        saveWorking();
        pageContext?.setInformationHost?.(null);
        app.remove();
        app = null;
        document.documentElement.style.overflow = previousOverflow;
        if (isAssistantPage() && !window.PMKPages) {
            window.location.href = "/cgi-bin/koha/mainpage.pl?pmk_page=hub";
        }
    }

    function renderLauncher() {
        const wrap = document.createElement("div");
        wrap.className = "pmk135-launch";
        const p = document.createElement("p");
        p.textContent = "Importez manuellement votre XSLT, modifiez les éléments dans l’aperçu puis copiez le XSLT complet. L’aperçu se met à jour à chaque modification.";
        wrap.appendChild(p);
        wrap.appendChild(createButton("Ouvrir l’assistant XSLT", "btn btn-primary", openAssistantPage, "fa fa-code"));
        return wrap;
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 3,
            compactActivation:true,
            hidePageCount:true,
            name: { fr: "Éditeur XSLT", en: "XSLT editor" },
            description: {
                fr: "Ouvrez une feuille XSLT, organisez ses blocs et vérifiez le résultat sur une notice Koha. Téléchargez ensuite le fichier modifié et une sauvegarde de votre projet.",
                en: "Visual builder to import, reorganize and enrich Koha XSLT files, then copy the complete output without hand-editing XML."
            },
            category: { fr: "Catalogue / XSLT", en: "Catalog / XSLT" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: function (cfg) {
                if(!cfg||typeof cfg.enabled!=="boolean")return {ok:false,message:"Configuration invalide."};
                if(cfg.previewTimeoutMs && (Number(cfg.previewTimeoutMs)<1000||Number(cfg.previewTimeoutMs)>180000))return {ok:false,message:"Délai entre 1 000 et 180 000 ms."};
                try{if(new URL(cfg.marcApiBase||"/api/v1",location.origin).origin!==location.origin)throw new Error();}catch(_){return {ok:false,message:"L’API MARC doit appartenir à ce Koha."};}
                return { ok: true };
            },
            schema: [
                {
                    type: "section",
                    id: "assistant",
                    label: { fr: "Assistant XSLT", en: "XSLT assistant" },
                    description: {
                        fr: "Le travail XSLT est conservé localement dans ce navigateur pendant la phase pré-plugin.",
                        en: "XSLT work is stored locally in this browser during the pre-plugin phase."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        {key:"defaultPreviewBiblio",type:"text",label:{fr:"Notice de test proposée aux nouveaux projets",en:"Default test biblio ID"}},
                        {key:"defaultPreviewAuthority",type:"text",label:{fr:"Autorité de test proposée aux nouveaux projets",en:"Default test authority ID"}},
                        {key:"marcApiBase",type:"text",advanced:true,label:{fr:"Racine API pour lire le MARC",en:"MARC API base"}},
                        {key:"previewTimeoutMs",type:"number",advanced:true,min:1000,max:180000,label:{fr:"Délai maximal de lecture MARC (ms)",en:"MARC read timeout"}},
                        { type: "custom", render: renderLauncher }
                    ]
                }
            ]
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try {
            window.PMKConfig.registerModule(moduleDefinition());
            if(!window.__pmk136ConfigConnected){window.__pmk136ConfigConnected=true;
                const apply=cfg=>{moduleConfig={enabled:true,...cfg};if(moduleConfig.enabled===false && app)closeAssistant();};
                Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).then(apply).catch(()=>{});
                window.PMKConfig.subscribe?.(MODULE_ID,apply);
            }
            return true;
        } catch (_) {
            return false;
        }
    }

    function start() {
        addStyles();

        // Enregistrement PMK : indépendant de l'ouverture de la page autonome.
        if (!registerModule()) {
            window.addEventListener("pmk:config-ready", registerModule, { once: true });
            window.setTimeout(registerModule, 5000);
        }

        // Route virtuelle autonome, sur le même principe que les autres pages PMK.
        if (isAssistantPage() && !window.PMKPages) {
            try { document.documentElement.classList.add("pmk136-xslt-route"); } catch (_) {}
            window.setTimeout(function () {
                if (window.PMKPages && typeof window.PMKPages.isSuperlibrarian === "function" && !isSuperlibrarian()) {
                    const denied = document.createElement("div");
                    denied.className = "pmk135-overlay";
                    denied.innerHTML = '<div style="max-width:760px;margin:60px auto;padding:22px;border:1px solid #e1b5b5;border-radius:8px;background:#fff1f1;color:#822929"><strong>Accès réservé.</strong><br>L’Assistant XSLT est accessible uniquement aux superlibrarians Koha.<div style="margin-top:1rem"><a class="btn btn-default btn-sm" href="/cgi-bin/koha/mainpage.pl"><i class="fa fa-home"></i> Accueil Koha</a></div></div>';
                    document.body.appendChild(denied);
                    return;
                }
                openAssistant();
                document.title = "Assistant XSLT — Koha";
            }, 100);
        }
    }

    const publicApi = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        pageParam: PAGE_PARAM,
        pageUrl: PAGE_URL,
        open: openAssistantPage,
        openPage: openAssistantPage,
        openOverlay: openAssistant,
        close: closeAssistant,
        knownPreferences: clone(KNOWN_PREFS),
        validateProject: runValidation,
        validateXml: function (xml) {
            try { parseXml(xml); return { ok: true }; }
            catch (e) { return { ok: false, message: e.message }; }
        }
    };
    window.PMK136XsltAssistant = publicApi;
    window.PMK135XsltAssistant = publicApi; // compatibilité avec les versions 0.2.x

    function registerPage() {
        return window.PMKPages?.register({id:PAGE_PARAM,mount:async (container,context)=>{
            try{moduleConfig={enabled:true,...await window.PMKConfig?.getConfig(MODULE_ID)};}catch(_){}
            if(context.signal.aborted)return;
            if(moduleConfig.enabled===false){container.textContent='L’éditeur XSLT est désactivé.';return;}
            pageContext=context;
            container.appendChild(createButton('Ouvrir l’éditeur XSLT','btn btn-primary',openAssistant,'fa fa-code'));
            openAssistant();
            return ()=>{closeAssistant();pageContext=null;};
        }});
    }
    if (!registerPage()) document.addEventListener('pmk:pages-ready',registerPage,{once:true});
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
})(window, document);

;window.PMKNonPlugin.loaded.push("136-xslt-assistant.js");
} catch (error) { window.PMKNonPlugin.errors.push("136-xslt-assistant.js: "+error.message); console.error("[PMK] 136-xslt-assistant.js",error); };
try {
/* ============================================================
   PimpMyKoha 137 — Widgets & blocs d’accueil
   v1.2.1-preplugin — 15/10/2026

   Rôle :
   - module PMK unique pour les widgets de la page d'accueil ;
   - activation/désactivation individuelle ;
   - ordre par glisser-déposer dans PMK (deux zones séparées) ;
   - chargement des widgets depuis des fichiers JS distincts ;
   - aucun réglage métier des widgets n'est déplacé dans PMK.

   Fichiers enfants attendus :
   /137-widgets/137-widget-frequency-nedap.js
   /137-widgets/137-widget-doodle-koha.js
   /137-widgets/137-widget-circulation-abonnements.js
   /137-widgets/137-widget-planning-services.js
   /137-widgets/137-widget-liens-utiles.js
   ============================================================ */
(function (window, document) {
    'use strict';

    if (window.PMKHomeWidgets && window.PMKHomeWidgets.version) return;

    const MODULE_ID = 'home-widgets';
    const IS_LEGACY_INSTALLATION = /(^|\.)dracenie\.com$/i.test(window.location.hostname);
    const VERSION = '1.2.1-preplugin';
    const currentScript = document.currentScript;
    const selfUrl = currentScript && currentScript.src
        ? new URL(currentScript.src, window.location.href)
        : new URL('/public/koha-scripts/137-home-widgets.js', window.location.origin);
    const release = selfUrl.searchParams.get('v') || '20261015-pmk137-reports-v121';

    const WIDGET_FILES = [
        './137-widgets/137-widget-frequency-nedap.js',
        './137-widgets/137-widget-doodle-koha.js',
        './137-widgets/137-widget-circulation-abonnements.js',
        './137-widgets/137-widget-planning-services.js',
        './137-widgets/137-widget-liens-utiles.js'
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        // Rapports SQL Koha existants ; jamais créer ces rapports automatiquement.
        circulationReportId: IS_LEGACY_INSTALLATION ? 4918 : 0,
        subscriptionReportId: IS_LEGACY_INSTALLATION ? 4878 : 0,
        announcementsWidgets: [
            { id: 'frequency-nedap', labelFr: 'Fréquentation NEDAP', labelEn: 'NEDAP attendance', enabled: IS_LEGACY_INSTALLATION },
            { id: 'doodle-koha', labelFr: 'Rendez-vous', labelEn: 'Appointments', enabled: IS_LEGACY_INSTALLATION },
            { id: 'circulation-abonnements', labelFr: 'Circulation & abonnements', labelEn: 'Circulation & subscriptions', enabled: IS_LEGACY_INSTALLATION },
            { id: 'liens-utiles', labelFr: 'Liens utiles', labelEn: 'Useful links', enabled: true }
        ],
        mainBlockWidgets: [
            { id: 'planning-services', deferUntilVisible:true, labelFr: 'Planning des services', labelEn: 'Services schedule', enabled: IS_LEGACY_INSTALLATION }
        ]
    };

    const registry = new Map();
    const mounted = new Set();
    const waiting = new Map();
    const widgetStates = new Map();
    const disposers = new Map();
    const mounting = new Map();
    const mountEpochs = new Map();
    const loadedScripts = new Map();
    let config = clone(DEFAULT_CONFIG);
    let configReady = false;
    let modulesRequested = false;
    let importTask = null;
    const failedImports = new Set();
    let initialConfigSignature = '';

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isHomePage() {
        return document.body?.id === 'main_intranet-main'
            || /(?:^|\/)mainpage\.pl$/i.test(window.location.pathname)
            || window.location.pathname === '/cgi-bin/koha/'
            || window.location.pathname === '/cgi-bin/koha';
    }

    function isSuperlibrarian() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === 'function') {
                return !!window.PMKConfig.isKohaSuperlibrarian();
            }
        } catch (_) {}

        try {
            const user = document.querySelector('.loggedinusername[data-is-superlibrarian], .loggedinusername.is_superlibrarian');
            if (!user) return false;
            if (user.classList.contains('is_superlibrarian')) return true;
            const raw = String(user.getAttribute('data-is-superlibrarian') || '').trim().toLowerCase();
            return ['is_superlibrarian', 'superlibrarian', '1', 'true', 'yes'].includes(raw);
        } catch (_) {
            return false;
        }
    }

    function normalizeList(saved, defaults) {
        const output = [];
        const seen = new Set();

        (Array.isArray(saved) ? saved : []).forEach(item => {
            const def = defaults.find(candidate => candidate.id === item?.id);
            if (!item || typeof item.id !== 'string' || !item.id || seen.has(item.id)) return;
            seen.add(item.id);
            output.push(def ? Object.assign({}, def, item, { id: def.id }) : clone(item));
        });

        defaults.forEach(def => {
            if (!output.some(item => item.id === def.id)) output.push(clone(def));
        });
        return output;
    }

    function normalizeConfig(raw) {
        raw = raw && typeof raw === 'object' ? raw : {};
        const announcementsWidgets = normalizeList(raw.announcementsWidgets, DEFAULT_CONFIG.announcementsWidgets);
        const firstZoneIds = new Set(announcementsWidgets.map(item => item.id));
        const mainBlockWidgets = normalizeList(raw.mainBlockWidgets, DEFAULT_CONFIG.mainBlockWidgets)
            .filter(item => !firstZoneIds.has(item.id));
        return Object.assign({}, raw, {
            enabled: raw.enabled !== false,
            circulationReportId: raw.circulationReportId === undefined ? DEFAULT_CONFIG.circulationReportId : raw.circulationReportId,
            subscriptionReportId: raw.subscriptionReportId === undefined ? DEFAULT_CONFIG.subscriptionReportId : raw.subscriptionReportId,
            announcementsWidgets,
            mainBlockWidgets
        });
    }

    function widgetSettings(id) {
        const all = [...config.announcementsWidgets, ...config.mainBlockWidgets];
        return all.find(item => item.id === id) || null;
    }

    function widgetTarget(id) {
        if (config.announcementsWidgets.some(item => item.id === id)) return 'announcements-column';
        if (config.mainBlockWidgets.some(item => item.id === id)) return 'intranet-main-userblock';
        return null;
    }

    function orderedIds(target) {
        const list = target === 'announcements-column' ? config.announcementsWidgets : config.mainBlockWidgets;
        return list.filter(item => item.enabled !== false).map(item => item.id);
    }

    function ensureAnnouncementsZone() {
        let zone = document.getElementById('pmk137-announcements-widgets');
        if (zone) return zone;

        const news = document.getElementById('area-news');
        const column = news?.closest('.col-md-3, .col-sm-3, [class*="col-"]')
            || document.querySelector('#container-main > .row > .col-md-3.order-sm-2')
            || document.querySelector('#container-main .col-md-3');
        if (!column) return null;

        zone = document.createElement('div');
        zone.id = 'pmk137-announcements-widgets';
        zone.className = 'pmk137-widget-zone pmk137-announcements-zone';

        if (news?.parentNode === column) news.insertAdjacentElement('afterend', zone);
        else column.prepend(zone);
        return zone;
    }

    function ensureMainBlockZone() {
        let zone = document.getElementById('pmk137-main-userblock-widgets');
        if (zone) return zone;

        const native = document.getElementById('IntranetmainUserblock');
        if (native) {
            zone = document.createElement('div');
            zone.id = 'pmk137-main-userblock-widgets';
            zone.className = 'pmk137-widget-zone pmk137-mainblock-zone';
            native.appendChild(zone);
            return zone;
        }

        const mainColumn = document.querySelector('#container-main .col-md-9.order-md-2')
            || document.querySelector('#container-main .col-md-9');
        if (!mainColumn) return null;

        const row = document.createElement('div');
        row.className = 'row pmk137-mainblock-row';
        const col = document.createElement('div');
        col.className = 'col-sm-12';
        const section = document.createElement('div');
        section.className = 'page-section pmk137-mainblock-section';
        zone = document.createElement('div');
        zone.id = 'pmk137-main-userblock-widgets';
        zone.className = 'pmk137-widget-zone pmk137-mainblock-zone';

        section.appendChild(zone);
        col.appendChild(section);
        row.appendChild(col);

        const versionRow = document.getElementById('koha_version')?.closest('.row');
        if (versionRow?.parentNode === mainColumn) mainColumn.insertBefore(row, versionRow);
        else mainColumn.appendChild(row);
        return zone;
    }

    function zoneFor(target) {
        if (target === 'announcements-column') return ensureAnnouncementsZone();
        if (target === 'intranet-main-userblock') return ensureMainBlockZone();
        return null;
    }

    function ensureSlot(id, target) {
        const zone = zoneFor(target);
        if (!zone) return null;

        let slot = [...zone.querySelectorAll('[data-pmk137-widget]')]
            .find(element => element.dataset.pmk137Widget === id);
        if (!slot) {
            slot = document.createElement('div');
            slot.className = 'pmk137-widget-slot';
            slot.dataset.pmk137Widget = id;
            zone.appendChild(slot);
        }
        return slot;
    }

    function sortZone(target) {
        const zone = zoneFor(target);
        if (!zone) return;
        orderedIds(target).forEach(id => {
            const slot = [...zone.querySelectorAll('[data-pmk137-widget]')]
                .find(element => element.dataset.pmk137Widget === id);
            if (slot) zone.appendChild(slot);
        });
    }

    function widgetError(id, slot) {
        widgetStates.set(id,'error');slot.replaceChildren();
        const message=document.createElement('div');message.className='alert alert-warning';message.setAttribute('role','status');message.textContent='Widget indisponible. Les autres widgets restent utilisables. ';
        const retry=document.createElement('button');retry.type='button';retry.className='btn btn-default btn-sm';retry.textContent='Réessayer';
        retry.addEventListener('click',async()=>{retry.disabled=true;if(!registry.has(id))await importWidgets();if(!registry.has(id)){retry.disabled=false;return;}unmountWidget(id);mountWidget(id,true);});
        message.appendChild(retry);slot.appendChild(message);
    }

    async function mountWidget(id, force) {
        if (!isHomePage() || config.enabled === false) return;
        const settings = widgetSettings(id);
        if (!settings || settings.enabled === false || mounted.has(id)) return;
        if (mounting.has(id)) {
            const pending=mounting.get(id);
            return pending.pmkEpoch!==mountEpochs.get(id) ? pending.then(()=>mountWidget(id,force)) : pending;
        }
        if(!force && widgetStates.get(id)==='error')return;

        const def = registry.get(id);
        if (!def || typeof def.mount !== 'function') return;
        const target = widgetTarget(id) || def.target;
        const slot = ensureSlot(id, target);
        if (!slot) return;

        if(!force && settings.deferUntilVisible && window.IntersectionObserver){
            if(waiting.has(id))return;
            widgetStates.set(id,'waiting');
            const placeholder=document.createElement('p');placeholder.textContent='Chargement à l’approche de l’affichage…';slot.replaceChildren(placeholder);
            const observer=new IntersectionObserver(entries=>{
                if(!entries.some(entry=>entry.isIntersecting) || waiting.get(id)?.slot!==slot)return;
                observer.disconnect();waiting.delete(id);mountWidget(id,true);
            },{rootMargin:'200px'});
            waiting.set(id,{observer,slot});observer.observe(slot);return;
        }
        const pending=waiting.get(id);if(pending){pending.observer.disconnect();waiting.delete(id);}
        slot.replaceChildren();widgetStates.set(id,'loading');
        const epoch = (mountEpochs.get(id) || 0) + 1;
        mountEpochs.set(id, epoch);
        const task = Promise.resolve().then(async () => {
            try {
                const disposer = await def.mount(slot, {
                    moduleId: MODULE_ID,
                    widgetId: id,
                    target,
                    labelFr: settings.labelFr || def.name || id,
                    labelEn: settings.labelEn || settings.labelFr || def.name || id,
                    isSuperlibrarian,
                    loadScript
                });
                // Un démontage intervenu pendant await def.mount ne doit pas remonter le widget.
                if (mountEpochs.get(id) !== epoch || config.enabled === false || widgetSettings(id)?.enabled === false || !slot.isConnected) {
                    if (typeof disposer === 'function') { try { disposer(); } catch (error) { console.warn('PMK137 — nettoyage tardif:', error); } }
                    slot.remove();
                    return;
                }
                if (typeof disposer === 'function') disposers.set(id, disposer);
                mounted.add(id);widgetStates.set(id,'ready');
                const refresh=document.createElement('button');refresh.type='button';refresh.className='btn btn-link btn-sm pmk137-refresh';refresh.textContent='Actualiser';refresh.setAttribute('aria-label','Actualiser '+(settings.labelFr||def.name||id));
                refresh.addEventListener('click',async()=>{
                    if(refresh.disabled)return;
                    let note=slot.querySelector('.pmk137-refresh-note');if(note)note.remove();
                    const inform=text=>{note=document.createElement('span');note.className='pmk137-refresh-note';note.setAttribute('role','status');note.textContent=text;refresh.after(note);};
                    if(disposer?.canRefresh && !disposer.canRefresh()){inform('Terminez ou fermez le formulaire ouvert avant d’actualiser. Vos saisies sont conservées.');return;}
                    if(typeof disposer?.refresh==='function'){
                        refresh.disabled=true;
                        try{await disposer.refresh();}catch(_){inform('Actualisation impossible. Les informations affichées et vos saisies sont conservées.');}
                        finally{refresh.disabled=false;}
                    }else{unmountWidget(id);mountWidget(id,true);}
                });slot.appendChild(refresh);
                sortZone(target);
            } catch (error) {
                console.error(`PMK137 — erreur montage ${id}:`, error);
                if(mountEpochs.get(id)===epoch && slot.isConnected)widgetError(id,slot);
            } finally {
                mounting.delete(id);
            }
        });
        task.pmkEpoch=epoch;
        mounting.set(id, task);
        return task;
    }

    function unmountWidget(id) {
        const pending=waiting.get(id);if(pending){pending.observer.disconnect();waiting.delete(id);}
        widgetStates.set(id,'closed');
        mountEpochs.set(id, (mountEpochs.get(id) || 0) + 1);
        const dispose = disposers.get(id);
        disposers.delete(id);
        if (typeof dispose === 'function') {
            try { dispose(); } catch (error) { console.warn(`PMK137 — démontage ${id}:`, error); }
        }
        mounted.delete(id);
        document.querySelectorAll('[data-pmk137-widget]').forEach(slot => {
            if (slot.dataset.pmk137Widget === id) slot.remove();
        });
    }

    // Les pages restaurées depuis le back-forward cache doivent pouvoir
    // remonter leurs widgets après un pagehide. Ne pas utiliser once ici.
    window.addEventListener('pagehide', () => {
        [...new Set([...mounted, ...mounting.keys(), ...waiting.keys()])].forEach(unmountWidget);
    });
    window.addEventListener('pageshow', event => {
        if (event.persisted && configReady) reconcile();
    });

    function reconcile() {
        if (!isHomePage() || !configReady) return;
        if (config.enabled === false) {
            [...new Set([...mounted, ...mounting.keys(), ...waiting.keys()])].forEach(unmountWidget);
            return;
        }
        [...new Set([...mounted, ...mounting.keys(), ...waiting.keys()])].forEach(id => {
            const settings = widgetSettings(id);
            if (!settings || settings.enabled === false) unmountWidget(id);
        });
        [...config.announcementsWidgets, ...config.mainBlockWidgets].forEach(item => {
            if (item.enabled !== false) mountWidget(item.id);
        });
        sortZone('announcements-column');
        sortZone('intranet-main-userblock');
    }

    function register(widget) {
        if (!widget || !widget.id) return false;
        registry.set(widget.id, widget);
        if (configReady) mountWidget(widget.id);
        return true;
    }

    // Chargeur partagé pour les dépendances JS classiques (Chart.js, etc.).
    // Ne bloque pas indéfiniment lorsqu'un script est déjà inséré et n'a
    // pas été créé par PMK 137 : son événement load peut être déjà passé.
    function loadScript(url) {
        const absolute = new URL(url, window.location.href).href;
        if (loadedScripts.has(absolute)) return loadedScripts.get(absolute);

        const promise = new Promise((resolve, reject) => {
            const existing = [...document.scripts].find(s => s.src === absolute);
            if (existing) {
                // Un élément déjà présent n'est pas nécessairement exécuté.
                // Pour les scripts PMK gérés ici, attendre leur vrai état.
                if (existing.dataset.pmk137Loading === '1') {
                    existing.addEventListener('load', () => resolve(existing), { once: true });
                    existing.addEventListener('error', () => reject(new Error(`Chargement impossible : ${absolute}`)), { once: true });
                } else {
                    // Script externe non géré : impossible de connaître son état
                    // après coup ; préserver le comportement historique.
                    resolve(existing);
                }
                return;
            }
            const script = document.createElement('script');
            script.async = true;
            script.dataset.pmk137Loading = '1';
            script.src = absolute;
            script.addEventListener('load', () => {
                delete script.dataset.pmk137Loading;
                script.dataset.pmk137Loaded = '1';
                resolve(script);
            }, { once: true });
            script.addEventListener('error', () => {
                delete script.dataset.pmk137Loading;
                script.remove();
                reject(new Error(`Chargement impossible : ${absolute}`));
            }, { once: true });
            document.head.appendChild(script);
        });
        loadedScripts.set(absolute, promise);
        promise.catch(() => {
            if (loadedScripts.get(absolute) === promise) loadedScripts.delete(absolute);
        });
        return promise;
    }

    function importWidgets() {
        if (!isHomePage()) return Promise.resolve();
        if (importTask) return importTask;
        if (modulesRequested && failedImports.size === 0) return Promise.resolve();
        const pending = modulesRequested ? [...failedImports] : WIDGET_FILES;
        modulesRequested = true;
        importTask = (async () => {
            for (const relative of pending) {
                try {
                    const url = new URL(relative, selfUrl);
                    url.searchParams.set('v', release);
                    if(failedImports.has(relative))url.searchParams.set('pmk_retry',String(Date.now()));
                    await import(url.href);
                    failedImports.delete(relative);
                } catch (error) {
                    failedImports.add(relative);
                    const ids={'frequency-nedap':'frequency-nedap','doodle-koha':'doodle-koha','circulation-abonnements':'circulation-abonnements','planning-services':'planning-services','liens-utiles':'liens-utiles'};
                    const name=relative.split('/').pop().replace(/^137-widget-/,'').replace(/\.js$/,'');const id=ids[name],settings=id&&widgetSettings(id);
                    if(config.enabled!==false && settings?.enabled!==false && settings){const slot=ensureSlot(id,widgetTarget(id));if(slot)widgetError(id,slot);}

                    console.error('PMK137 — chargement widget impossible :', relative, error);
                }
            }
            reconcile();
        })().finally(() => { importTask = null; });
        return importTask;
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr: 'Widgets & blocs d’accueil', en: 'Home widgets & blocks' },
            description: {
                fr: 'Centralise les widgets par défaut placés dans les annonces et IntranetmainUserblock. PMK pilote uniquement leur activation ; chaque widget conserve son propre fonctionnement et sa propre configuration accessible uniquement pour les superlibrarian directement sur le widget.',
                en: 'Centralizes the default widgets placed in announcements and IntranetmainUserblock. PMK only controls activation; each widget keeps its own behavior and configuration, available only to superlibrarians directly from the widget.'
            },
            category: { fr: 'Accueil / interface', en: 'Home / interface' },
            supportedPages: ['*'],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: function (cfg) {
                if (!cfg || typeof cfg.enabled !== 'boolean') return { ok: false, message: 'Configuration invalide.' };
                if (!Array.isArray(cfg.announcementsWidgets) || !Array.isArray(cfg.mainBlockWidgets)) return { ok: false, message: 'Liste de widgets invalide.' };
                return { ok: true };
            },
            schema: [
                {
                    type: 'section',
                    id: 'announcements',
                    label: { fr: 'Colonne des annonces', en: 'Announcements column' },
                    description: { fr: 'Activez ou désactivez les widgets. Leurs réglages sont accessibles sur chaque widget.', en: 'Enable or disable widgets. Settings are available on each widget.' },
                    fields: [
                        {
                            key: 'announcementsWidgets',
                            type: 'repeater',
                            reorder: false,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function (item) { return item?.labelFr || item?.id || 'Widget'; },
                            fields: [
                                { key: 'enabled', type: 'boolean', label: { fr: 'Afficher ce widget', en: 'Show this widget' } },
                                { key: 'deferUntilVisible', type: 'boolean', label: { fr: 'Charger à l’approche de l’affichage', en: 'Load when approaching the viewport' } },
                            ]
                        }
                    ]
                },
                {
                    type: 'section',
                    id: 'mainblock',
                    label: { fr: 'Zone IntranetmainUserblock', en: 'IntranetmainUserblock area' },
                    description: { fr: 'Widgets affichés sous les modules principaux de l’accueil.', en: 'Widgets displayed below the main home modules.' },
                    fields: [
                        {
                            key: 'mainBlockWidgets',
                            type: 'repeater',
                            reorder: false,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function (item) { return item?.labelFr || item?.id || 'Widget'; },
                            fields: [
                                { key: 'enabled', type: 'boolean', label: { fr: 'Afficher ce widget', en: 'Show this widget' } },
                                { key: 'deferUntilVisible', type: 'boolean', label: { fr: 'Charger à l’approche de l’affichage', en: 'Load when approaching the viewport' } },
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function applyConfig(next, initial) {
        const normalized = normalizeConfig(next);
        const signature = JSON.stringify(normalized);

        if (!initial && configReady && initialConfigSignature && signature !== initialConfigSignature && isHomePage()) {
            window.location.reload();
            return;
        }

        config = normalized;
        initialConfigSignature = signature;
        configReady = true;
        if (isHomePage()) {
            importWidgets();
            reconcile();
        }
    }

    function registerPmk() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function') return false;
        try {
            window.PMKConfig.registerModule(moduleDefinition());
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(cfg => applyConfig(cfg, true))
                .catch(error => {
                    console.warn('PMK137 — configuration inaccessible, valeurs par défaut utilisées provisoirement :', error);
                    applyConfig(clone(DEFAULT_CONFIG), true);
                });

            if (typeof window.PMKConfig.subscribe === 'function') {
                window.PMKConfig.subscribe(MODULE_ID, cfg => applyConfig(cfg, false));
            }
            return true;
        } catch (error) {
            console.error('PMK137 — enregistrement PMK impossible :', error);
            return false;
        }
    }

    // PMK 137 — couche de stockage substituable. Un adaptateur est propre à chaque
    // widget et son espace de données ; aucun identifiant Firebase n'est mutualisé.
    // Les widgets utilisent le stockage natif du plugin Koha. La forme des
    // documents historiques reste conservée pour la migration.
    const storageProviders = new Map();
    const storage = Object.freeze({
        register(namespace, provider) {
            if (typeof namespace !== 'string' || !namespace || !provider ||
                !['read','write','subscribe','transact'].some(operation => typeof provider[operation] === 'function')) {
                throw new TypeError('PMK137 storage: au moins une opération doit être fournie');
            }
            if (storageProviders.has(namespace)) return storageProviders.get(namespace);
            const api = Object.freeze({
                ...(typeof provider.read === 'function' ? { read: (...args) => Promise.resolve().then(() => provider.read(...args)) } : {}),
                ...(typeof provider.write === 'function' ? { write: (...args) => Promise.resolve().then(() => provider.write(...args)) } : {}),
                ...(typeof provider.subscribe === 'function' ? { subscribe: (...args) => provider.subscribe(...args) } : {}),
                ...(typeof provider.transact === 'function' ? { transact: (...args) => provider.transact(...args) } : {})
            });
            storageProviders.set(namespace, api);
            return api;
        },
        get(namespace) { return storageProviders.get(namespace) || null; }
    });

    window.PMKHomeWidgets = {
        version: VERSION,
        moduleId: MODULE_ID,
        register,
        storage,
        isSuperlibrarian,
        loadScript,
        reconcile,
        getConfig: () => clone(config),
        getStatus: id => widgetStates.get(id) || 'idle'
    };

    function start() {
        if (!registerPmk()) {
            window.addEventListener('pmk:config-ready', registerPmk, { once: true });
            window.setTimeout(() => {
                if (!configReady) applyConfig(clone(DEFAULT_CONFIG), true);
                registerPmk();
            }, 5000);
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})(window, document);

;window.PMKNonPlugin.loaded.push("137-home-widgets.js");
} catch (error) { window.PMKNonPlugin.errors.push("137-home-widgets.js: "+error.message); console.error("[PMK] 137-home-widgets.js",error); };
try {
/*
 Nom du fichier : 138-pages-manager.js
 Version : 1.3.0
 Date : 2026-10-17

 PimpMyKoha — Pages & outils internes
 - aucune page Koha personnalisée requise ;
 - routes virtuelles sur mainpage.pl?pmk_page=... ;
 - accès selon les droits historiques de chaque outil ;
 - configuration des pages regroupée dans PMK, sauf Autorités ;
 - une application par fichier JS séparé ;
 - seul le fichier demandé est chargé.
*/
(function (window, document) {
    'use strict';
    if (window.__PMK138_PAGES_MANAGER__) return;
    window.__PMK138_PAGES_MANAGER__ = true;

    const MODULE_ID = 'internal-pages-tools';
    const VERSION = '1.3.0';
    const ROUTE_PARAM = 'pmk_page';
    const HUB_ID = 'hub';

    // Marque immédiatement les routes virtuelles et canonicalise les anciennes URL.
    const initialParams = new URLSearchParams(window.location.search);
    let initialRoute = initialParams.get(ROUTE_PARAM);
    if(initialRoute==='rulelab'){initialRoute=HUB_ID;initialParams.set(ROUTE_PARAM,HUB_ID);try{history.replaceState(history.state,'',location.pathname+'?'+initialParams.toString()+location.hash);}catch(_){}}
    if (initialRoute && location.pathname === '/cgi-bin/koha/mainpage.pl') {
        try { document.documentElement.classList.add('pmk138-virtual-route'); } catch (_) {}
        if (initialRoute === 'attendance-counter' && initialParams.has('source')) {
            initialParams.delete('source');
            const cleanUrl = window.location.pathname + '?' + initialParams.toString() + window.location.hash;
            try { window.history.replaceState(window.history.state, '', cleanUrl); } catch (_) {}
        }
    }
    const selfUrl = new URL(document.currentScript && document.currentScript.src || window.location.href, window.location.href);
    const baseUrl = new URL('./', selfUrl);
    const release = selfUrl.searchParams.get('v') || '20261017-pmk138-v130';
    const manifest = [
    {
        "id": "attendance-counter",
        "title": "Compteur de fréquentation",
        "out": "138-page-attendance-counter",
        "icon": "fa-users",
        "group": "Outils généraux",
        "desc": "Saisie et suivi de fréquentation."
    },
    {
        "id": "action-journal",
        "title": "Journal des actions",
        "out": "138-page-action-journal",
        "icon": "fa-book",
        "group": "Outils généraux",
        "desc": "Journal partagé des actions et suivi."
    },
    {
        "id": "restore-deleted-items",
        "title": "Restauration d’exemplaires",
        "out": "138-page-restore-deleted-items",
        "icon": "fa-medkit",
        "group": "Outils généraux",
        "desc": "Recherche, restauration et traitement d’exemplaires supprimés."
    },
    {
        "id": "weeding",
        "title": "Désherbage",
        "out": "138-page-weeding",
        "icon": "fa-trash",
        "group": "Outils généraux",
        "desc": "Outil de désherbage et d’analyse des collections."
    },
    {
        "id": "appointments",
        "title": "Rendez-vous réseau / Doodle",
        "out": "138-page-appointments",
        "icon": "fa-calendar",
        "group": "Outils généraux",
        "desc": "Créneaux, rendez-vous et sondages réseau."
    },
    {
        "id": "authorities",
        "title": "Maintenance des autorités",
        "out": "138-page-authorities",
        "icon": "fa-user-circle",
        "group": "Qualité Koha",
        "desc": "Doublons, fusions, orphelines, relink et audit des autorités."
    },
    {
        "id": "inventory",
        "title": "Inventaire",
        "out": "138-page-inventory",
        "icon": "fa-clipboard",
        "group": "Outils généraux",
        "desc": "Inventaire autonome des collections."
    },
    {
        "id": "reservations",
        "title": "Maintenance des réservations",
        "out": "138-page-reservations",
        "icon": "fa-hand-paper-o",
        "group": "Qualité Koha",
        "desc": "Analyse et maintenance des réservations."
    },
    {
        "id": "loans",
        "title": "Prêts & litiges",
        "out": "138-page-loans",
        "icon": "fa-retweet",
        "group": "Qualité Koha",
        "desc": "Analyse des prêts anciens, litiges et réclamations."
    },
    {
        "id": "transfers",
        "title": "Transferts / navette",
        "out": "138-page-transfers",
        "icon": "fa-exchange",
        "group": "Qualité Koha",
        "desc": "Analyse des transferts et navette."
    },
    {
        "id": "items",
        "title": "Maintenance des exemplaires",
        "out": "138-page-items",
        "icon": "fa-barcode",
        "group": "Qualité Koha",
        "desc": "Contrôle d’intégrité et maintenance des exemplaires."
    },
    {
        "id": "biblios",
        "title": "Qualité du catalogue bibliographique",
        "out": "138-page-biblios",
        "icon": "fa-book",
        "group": "Qualité Koha",
        "desc": "Audit bibliographique, doublons et enrichissement assisté."
    },
    {
        "id": "serials",
        "title": "Maintenance des périodiques",
        "out": "138-page-serials",
        "icon": "fa-newspaper-o",
        "group": "Qualité Koha",
        "desc": "Abonnements, fascicules attendus et réclamations."
    },
    {
        "id": "patrons",
        "title": "Qualité des comptes lecteurs",
        "out": "138-page-patrons",
        "icon": "fa-users",
        "group": "Qualité Koha",
        "desc": "Doublons, comptes expirés et coordonnées lecteurs."
    },
    {
        "id": "quality-center",
        "title": "Centre qualité Koha",
        "out": "138-page-quality-center",
        "icon": "fa-check-circle",
        "group": "Qualité Koha",
        "desc": "Point d’entrée des outils de qualité Koha."
    },
    {
        "id": "bulk-framework-change",
        "title": "Modification de grille par lot",
        "icon": "fa-table",
        "group": "Outils généraux",
        "desc": "Change la grille de catalogage de plusieurs notices à partir de numéros de notice ou de codes-barres d’exemplaires.",
        "external": true
    },
    {
        "id": "xslt-assistant",
        "title": "Éditeur XSLT",
        "icon": "fa-code",
        "group": "Outils généraux",
        "desc": "Ouvrir, modifier, prévisualiser et exporter les feuilles XSLT Koha, avec sauvegarde des projets.",
        "external": true
    },
    {
        "id": "bibliography-builder",
        "title": "Bibliographies & publications",
        "icon": "fa-file-text-o",
        "group": "Outils généraux",
        "desc": "Créer et imprimer des bibliographies depuis les listes, paniers, paquets et réserves de cours.",
        "external": true
    },
    {
        "id": "overdue-management",
        "title": "Gestion des retards TP4",
        "icon": "fa-clock-o",
        "group": "Outils généraux",
        "desc": "Suivi des dossiers TP4, consultation des prêts en retard et ajout ou modification de messages dans la fiche Koha sans quitter la page.",
        "external": true
    }
];
    // External tools retain their existing access policy and business configuration.
    const externalSources = {
        'bulk-framework-change': {file:'141-modif-grille-par-lot.js',access:'staff'},
        'xslt-assistant': {file:'136-xslt-assistant.js',access:'superlibrarian'},
        'bibliography-builder': {file:'142-bibliography-builder.js',access:'staff'},
        'overdue-management': {file:'143-gestion-retards.js',access:'staff'}
    };
    manifest.forEach(item=>Object.assign(item,externalSources[item.id] || {access:'superlibrarian'}));
    let config = {enabled:true};
    let configConnected=false;
    let routeGeneration=0;
    let disposePage=null;
    let routeController=null;
    let scriptSequence=0;
    const pageStatus=new Map();
    const hiddenNative=new Map();
    const originalTitle=document.title;
    const byId = new Map(manifest.map(item => [item.id, item]));
    const registry = new Map();
    const loading = new Map();

    function isSuperlibrarian() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === 'function') {
                const result = window.PMKConfig.isKohaSuperlibrarian();
                if (result === true) return true;
            }
        } catch (_) {}
        try {
            const user = document.querySelector(
                '#logged-in-info-full .loggedinusername[data-loggedinusername], ' +
                '.loggedinusername[data-loggedinusername], ' +
                '.loggedinusername[data-is-superlibrarian], ' +
                '.loggedinusername.is_superlibrarian'
            );
            if (!user) return false;
            if (user.classList && user.classList.contains('is_superlibrarian')) return true;
            const raw = String(
                (user.dataset && user.dataset.isSuperlibrarian) ||
                user.getAttribute('data-is-superlibrarian') || ''
            ).trim().toLowerCase();
            return ['is_superlibrarian','superlibrarian','1','true','yes'].includes(raw);
        } catch (_) { return false; }
    }

    function urlFor(id) {
        if(id==='rulelab')id=HUB_ID;
        if (id && id !== HUB_ID && !byId.has(id)) throw new Error('Page inconnue : '+id);
        const u = new URL('/cgi-bin/koha/mainpage.pl', window.location.origin);
        u.searchParams.set(ROUTE_PARAM, String(id || HUB_ID));
        return u.pathname + u.search;
    }

    function open(id, target) {
        const url = urlFor(id);
        if (target === 'new') window.open(url, '_blank', 'noopener');
        else window.location.href = url;
    }

    function register(def) {
        if (!def || !def.id || !byId.has(def.id)) return false;
        registry.set(def.id, def);
        try { document.dispatchEvent(new CustomEvent('pmk:page-registered', { detail: { id:def.id } })); } catch (_) {}
        return true;
    }

    function childUrl(def) {
        const u = new URL(def.external ? './'+def.file : './138-pages/' + def.out + '.js', baseUrl);
        if (release) u.searchParams.set('v', release);
        return u.href;
    }

    function loadScript(src) {
        if (loading.has(src)) return loading.get(src);
        const promise = new Promise((resolve, reject) => {
            const existing = Array.from(document.scripts).find(s => s.src === src);
            if (existing && existing.dataset.pmk138Loaded === '1') return resolve(existing);
            const s = existing || document.createElement('script');
            const timer=setTimeout(()=>{s.remove();reject(new Error('Délai de chargement dépassé : '+src));},15000);
            s.addEventListener('load', () => { clearTimeout(timer);s.dataset.pmk138Loaded='1'; resolve(s); }, { once:true });
            s.addEventListener('error', () => {clearTimeout(timer);s.remove();reject(new Error('Impossible de charger ' + src));}, { once:true });
            if (!existing) {
                s.src = src;
                s.async = false;
                s.dataset.pmk138Child = '1';
                document.head.appendChild(s);
            } else if (existing.dataset.pmk138Loaded === '1') resolve(existing);
        });
        promise.catch(()=>loading.delete(src));
        loading.set(src, promise);
        return promise;
    }

    async function ensurePage(id) {
        if (registry.has(id)) return registry.get(id);
        const def = byId.get(id);
        if (!def) throw new Error('Page inconnue : ' + id);
        await loadScript(childUrl(def));
        if (registry.has(id)) return registry.get(id);
        await new Promise((resolve, reject) => {
            const started = Date.now();
            const timer = window.setInterval(() => {
                if (registry.has(id)) { window.clearInterval(timer); resolve(); }
                else if (Date.now()-started > 5000) { window.clearInterval(timer); reject(new Error('La page ne s’est pas enregistrée : '+id)); }
            }, 50);
        });
        return registry.get(id);
    }

    function pageHost() {
        // A floating counter must not cover the internal page's toolbar.
        window.PMKAttendance?.hide?.('internal-page');
        document.body && document.body.classList.add('pmk138-virtual-page');
        let host = document.getElementById('pmk138-page-host');
        if (host) return host;
        host = document.createElement('div');
        host.id = 'pmk138-page-host';
        host.className = 'pmk138-page-host';
        const main = document.querySelector('#container-main, main#main_intranet-main, main.container-fluid, main, #main');
        if (main) {
            Array.from(main.children).forEach(node => {
                if (node.id === host.id || node.matches('#toplevelmenu,#bottomActionBar,[data-pmk-intranetnav],.pmk-intranetnav,[id^="pmk-intranetnav"]')) return;
                hiddenNative.set(node,{value:node.style.getPropertyValue('display'),priority:node.style.getPropertyPriority('display')});
                node.style.setProperty('display','none','important');
            });
            main.appendChild(host);
        } else {
            document.body.appendChild(host);
        }
        return host;
    }

    function injectStyles() {
        if (document.getElementById('pmk138-styles')) return;
        const s=document.createElement('style');
        s.id='pmk138-styles';
        s.textContent=`
#pmk138-page-host{display:block!important;width:100%;max-width:none;margin:0;padding:14px 18px 40px;box-sizing:border-box}
#pmk138-page-host *{box-sizing:border-box}
#pmk138-page-host [hidden]{display:none!important}
#pmk138-page-host .pmk138-app-container > #pmk142-root{position:relative;inset:auto;z-index:auto;min-height:80vh}
.pmk138-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 14px;padding:8px 10px;border:1px solid #d9dee3;border-radius:7px;background:#f7f8f9}
.pmk138-toolbar .pmk138-title{font-weight:700;color:#39444d;margin-right:auto}
.pmk138-hub{max-width:1500px;margin:0 auto}
.pmk138-hub-head{padding:18px 20px;margin-bottom:14px;border:1px solid #cedbbd;border-left:5px solid #6f8f32;border-radius:8px;background:linear-gradient(135deg,#fff,#f5f9ef)}
.pmk138-hub-head h1{font-size:26px;margin:0 0 4px;color:#526d22}
.pmk138-hub-head p{margin:0;color:#697680}
.pmk138-group{margin:18px 0}
.pmk138-group h2{font-size:18px;margin:0 0 9px;color:#39444d}
.pmk138-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.pmk138-card{display:flex;flex-direction:column;min-height:145px;padding:14px;border:1px solid #d8dee3;border-radius:8px;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.pmk138-card h3{font-size:16px;margin:0 0 6px;color:#39444d}
.pmk138-card p{color:#697680;margin:0 0 12px;font-size:13px;flex:1}
.pmk138-card .btn{align-self:flex-start}
.pmk138-denied{max-width:760px;margin:35px auto;padding:20px;border:1px solid #e1b5b5;border-radius:8px;background:#fff1f1;color:#822929}
@media(max-width:1050px){.pmk138-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:680px){#pmk138-page-host{padding:10px}.pmk138-grid{grid-template-columns:1fr}}
`;
        document.head.appendChild(s);
    }

    function toolbar(title) {
        const bar=document.createElement('div');bar.className='pmk138-toolbar';
        const back=document.createElement('a');back.className='btn btn-default btn-sm';back.href=urlFor(HUB_ID);back.innerHTML='<i class="fa fa-arrow-left" aria-hidden="true"></i> Pages & outils internes';
        const t=document.createElement('div');t.className='pmk138-title';t.textContent=title || '';
        const home=document.createElement('a');home.className='btn btn-default btn-sm';home.href='/cgi-bin/koha/mainpage.pl';home.innerHTML='<i class="fa fa-home" aria-hidden="true"></i> Accueil Koha';
        if(canOpen(HUB_ID))bar.appendChild(back);bar.append(t,home);if(isSuperlibrarian() && requestedPage()!=='authorities'){const settings=document.createElement('button');settings.type='button';settings.className='btn btn-default btn-sm';settings.textContent='Configurer cette page';settings.onclick=()=>window.PMKPagesSettings?.openSettings(requestedPage());bar.appendChild(settings);}return bar;
    }

    function renderHub(host) {
        host.replaceChildren();
        const wrap=document.createElement('div');wrap.className='pmk138-hub';
        const head=document.createElement('div');head.className='pmk138-hub-head';head.innerHTML='<h1>Pages & outils internes</h1><p>Retrouvez les outils accessibles avec votre compte Koha.</p>';
        wrap.appendChild(head);
        const search=document.createElement('input');search.type='search';search.className='form-control';search.placeholder='Rechercher un outil';search.setAttribute('aria-label','Rechercher un outil');wrap.appendChild(search);
        const empty=document.createElement('p');empty.textContent='Aucun outil ne correspond à cette recherche.';empty.hidden=true;
        search.addEventListener('input',()=>{
            const term=search.value.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
            wrap.querySelectorAll('.pmk138-card').forEach(card=>{card.hidden=!card.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(term);});
            wrap.querySelectorAll('.pmk138-group').forEach(sec=>{sec.hidden=!Array.from(sec.querySelectorAll('.pmk138-card')).some(card=>!card.hidden);});
            empty.hidden=Array.from(wrap.querySelectorAll('.pmk138-card')).some(card=>!card.hidden);
        });
        const groups=[...new Set(manifest.filter(x=>canOpen(x.id)).map(x=>x.group))];
        groups.forEach(group => {
            const sec=document.createElement('section');sec.className='pmk138-group';
            const h=document.createElement('h2');h.textContent=group;sec.appendChild(h);
            const grid=document.createElement('div');grid.className='pmk138-grid';
            manifest.filter(x=>x.group===group && canOpen(x.id)).forEach(item => {
                const card=document.createElement('div');card.className='pmk138-card';
                const h3=document.createElement('h3');h3.innerHTML='<i class="fa '+item.icon+' fa-fw" aria-hidden="true"></i> '+escapeHtml(item.title);
                const p=document.createElement('p');p.textContent=item.desc;
                const a=document.createElement('a');a.className='btn btn-primary btn-sm';a.href=urlFor(item.id);a.textContent='Ouvrir';
                card.append(h3,p,a);grid.appendChild(card);
            });
            sec.appendChild(grid);wrap.appendChild(sec);
        });
        wrap.appendChild(empty);
        host.appendChild(wrap);
        document.title='Pages & outils internes — Koha';
    }

    function escapeHtml(v) { return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

    async function executeScript(oldScript, context) {
        if(context?.signal.aborted)return;
        return new Promise((resolve,reject)=>{
            const script=document.createElement('script');
            Array.from(oldScript.attributes || []).forEach(attr=>script.setAttribute(attr.name,attr.value));
            const token='pmk138-script-'+(++scriptSequence);
            const sourceName=token+'.js';
            let finished=false;
            const finish=error=>{
                if(finished)return;finished=true;clearTimeout(timer);
                document.removeEventListener('pmk:internal-script-complete',complete);
                window.removeEventListener('error',runtimeError);
                context?.signal.removeEventListener('abort',cancel);
                if(error)reject(error);else resolve();
            };
            const complete=event=>{if(event.detail===token)finish();};
            const runtimeError=event=>{if(String(event.filename || '').includes(sourceName)){event.preventDefault();finish(new Error(event.message || 'Erreur d’initialisation'));}};
            const cancel=()=>{script.remove();finish(new DOMException('Page fermée','AbortError'));};
            const timer=setTimeout(()=>finish(new Error('Délai d’initialisation dépassé')),15000);
            context?.signal.addEventListener('abort',cancel,{once:true});
            script.onerror=()=>finish(new Error('Impossible de charger une dépendance de la page'));
            if(oldScript.src){script.onload=()=>finish();oldScript.replaceWith(script);return;}
            document.addEventListener('pmk:internal-script-complete',complete);
            window.addEventListener('error',runtimeError);
            script.textContent=(oldScript.textContent || '')+'\n;document.dispatchEvent(new CustomEvent("pmk:internal-script-complete",{detail:'+JSON.stringify(token)+'}));\n//# sourceURL='+sourceName;
            try{oldScript.replaceWith(script);}catch(error){finish(error);}
        });
    }

    async function mountLegacyHtml(container, source) {
        const context=container.__pmkPageContext;
        if(context?.signal.aborted)return;
        container.innerHTML=source;
        const scripts=Array.from(container.querySelectorAll('script'));
        for(const script of scripts){
            if(context?.signal.aborted)return;
            if(script.dataset.pmkOptional==='true'){
                void executeScript(script,context).catch(error=>{if(context?.signal.aborted)return;const status=pageStatus.get(context?.id);if(status)(status.optionalDependenciesUnavailable ||= []).push(error.message);});
            }else await executeScript(script,context);
        }
    }

    function cleanupQualityCenter(container) {
        const root=container.querySelector('#dq-center-app');if(!root)return null;
        const clean=()=>{
            root.querySelectorAll('.dqc-panel').forEach(panel=>{
                const h=panel.querySelector('h3');
                if (h && /Configuration locale des pages/i.test(h.textContent||'')) panel.remove();
            });
        };
        clean();const obs=new MutationObserver(clean);obs.observe(root,{childList:true,subtree:true});return obs;
    }

    const pageChecks = new Map();
    function pageInformation(id, host, context) {
        if(id==='authorities')return;
        const service=window.PMKPagesSettings, definition=service?.catalog[id];
        if(!definition)return;
        const details=document.createElement('details');details.className='pmk138-page-information';
        details.style.cssText='margin:8px 0;padding:8px 12px;border:1px solid #ddd;border-radius:6px;background:#fff;max-height:45vh;overflow:auto;flex-shrink:0';
        const summary=document.createElement('summary');summary.textContent='À propos de cette page et vérifications';details.appendChild(summary);
        const add=(label,text)=>{const p=document.createElement('p');const strong=document.createElement('strong');strong.textContent=label+' : ';p.append(strong,document.createTextNode(text||'Non renseigné'));details.appendChild(p);};
        add('Objectif',definition.objective);add('Fonctions',definition.functions?.join(' · '));add('Moteur',definition.engine);add('Prérequis',definition.prerequisites);
        const choice=config.pageOptions?.[id]?.access,access=choice&&choice!=='default'?choice:byId.get(id)?.access;add('Accès',(access==='staff'?'Personnel Koha':'Administrateur Koha')+' — les droits métier Koha restent nécessaires');
        const link=document.createElement('a');link.href=urlFor(id);link.textContent='Lien direct vers cette page';details.appendChild(link);
        const check=document.createElement('button');check.type='button';check.className='btn btn-default btn-sm';check.textContent='Vérifier les réglages et les rapports';check.style.marginLeft='12px';details.appendChild(check);
        const output=document.createElement('div');output.setAttribute('aria-live','polite');details.appendChild(output);
        const show=result=>{output.replaceChildren();const p=document.createElement('p');p.textContent=result?'Dernière vérification dans cette session : '+new Date(result.at).toLocaleString()+' — contrôle des réglages et des métadonnées, sans exécuter les rapports.':'Aucune vérification effectuée dans cette session.';output.appendChild(p);for(const text of result?.messages||[]){const row=document.createElement('p');row.textContent=text;output.appendChild(row);}};
        show(pageChecks.get(id));
        check.addEventListener('click',async()=>{
            check.disabled=true;
            try{
                const workbench=window.PMKWorkbench;if(!workbench)throw new Error('Service de diagnostic indisponible');
                const effective={runtime:service.runtime(id),settings:service.settings(id)};
                const diagnosis=workbench.diagnose(effective),reports=await workbench.checkReports(effective,{signal:context.signal});if(context.signal.aborted)return;
                const messages=diagnosis.rows.filter(row=>row.kind!=='report').map(row=>row.path.join(' / ')+' : '+row.message);
                const states={ok:'disponible',missing:'introuvable',forbidden:'accès refusé',unavailable:'indisponible'};
                for(const row of reports.rows)messages.push('Rapport '+row.id+' : '+states[row.state]+(row.name?' — '+row.name:''));
                if(!messages.length)messages.push('Aucune cible ni aucun rapport à contrôler automatiquement. Les prérequis indiqués ci-dessus restent à vérifier.');
                const result={at:new Date().toISOString(),messages};pageChecks.set(id,result);show(result);
            }catch(error){output.textContent='Vérification interrompue : '+error.message;}finally{check.disabled=false;}
        });
        context.informationElement=details;
        context.setInformationHost(context.informationHost);
        context.onDispose(()=>details.remove());
    }

    async function renderPage(id, host, generation) {
        const meta=byId.get(id);if(!meta) { host.textContent='Page inconnue.'; return; }
        host.replaceChildren();host.appendChild(toolbar(meta.title));
        const app=document.createElement('div');app.className='pmk138-app-container';host.appendChild(app);
        const controller=routeController;const cleanups=[];
        const context={id,meta,isSuperlibrarian,urlFor,open,mountLegacyHtml,signal:controller.signal,onDispose:callback=>{if(typeof callback!=='function')return;if(controller.signal.aborted)callback();else cleanups.push(callback);}};
        // Full-screen tools may host the same information panel inside their own surface.
        context.setInformationHost=target=>{
            context.informationHost=target||host;
            if(context.informationElement)context.informationHost.prepend(context.informationElement);
        };
        app.__pmkPageContext=context;
        disposePage=()=>{pageStatus.set(id,Object.assign({},pageStatus.get(id),{state:'closed'}));cleanups.splice(0).reverse().forEach(callback=>{try{callback();}catch(_){}});};
        app.textContent='Ouverture de la page…';pageStatus.set(id,{state:'loading'});
        try {
            const def=await ensurePage(id);
            if (generation !== routeGeneration || !host.isConnected || config.enabled === false) return;
            app.replaceChildren();
            const cleanup=await def.mount(app,context);
            if(typeof cleanup==='function')context.onDispose(cleanup);
            if(generation!==routeGeneration || controller.signal.aborted)return;
            pageStatus.set(id,Object.assign({},pageStatus.get(id),{state:'mounted'}));
            if(id==='quality-center'){const observer=cleanupQualityCenter(app);context.onDispose(()=>observer?.disconnect());}
            pageInformation(id,host,context);
            document.title=meta.title+' — Koha';
        } catch(error) {
            if(generation!==routeGeneration || controller.signal.aborted)return;
            pageStatus.set(id,{state:'error',message:error.message || String(error)});
            console.error('PMK138 — page indisponible',id,error);
            const b=document.createElement('div');b.className='alert alert-danger';b.textContent='Application indisponible : '+(error.message||error);const retry=document.createElement('button');retry.type='button';retry.className='btn btn-default';retry.textContent='Réessayer';retry.addEventListener('click',renderRoute);app.replaceChildren(b,retry);
        }
    }

    function requestedPage() { return location.pathname === '/cgi-bin/koha/mainpage.pl' ? new URLSearchParams(window.location.search).get(ROUTE_PARAM) : null; }

    function renderDenied(host) { host.innerHTML='<div class="pmk138-denied"><strong>Accès réservé.</strong><br>Cette page exige le rôle superlibrarian Koha.<p><a href="/cgi-bin/koha/mainpage.pl">Retour à l’accueil Koha</a></p></div>'; }

    function renderPmkLauncher() {
        const wrap=document.createElement('div');
        const description=document.createElement('p');description.textContent='Les dix-neuf pages utilisent le même point d’entrée. Les droits ci-dessous concernent leur ouverture ; les contrôles Koha, les comptes Koha et les éventuels filtres propres à une page restent nécessaires.';
        const link=document.createElement('a');link.className='btn btn-primary';link.href=urlFor(HUB_ID);link.target='_blank';link.rel='noopener';link.textContent='Ouvrir les pages & outils internes';
        const table=document.createElement('table');table.className='table table-striped';
        const head=table.createTHead().insertRow();['Page','Accès à la page','Prérequis particuliers'].forEach(label=>{const cell=document.createElement('th');cell.textContent=label;head.appendChild(cell);});
        const details={
            'attendance-counter':'Authentification et droits du compteur Koha',
            'action-journal':'Accès au journal stockage Koha',appointments:'Accès stockage Koha ; contrôle administrateur propre aux rendez-vous',
            'restore-deleted-items':'Filtre nominatif supplémentaire dans la page ; droits Koha de restauration',inventory:'Stockage local IndexedDB et droits API Koha',
            'quality-center':'Navigation et état des prérequis',transfers:'Droits Koha et rapport SQL configuré',serials:'Droits Koha et rapport SQL configuré',
            weeding:'Droits Koha ; référentiel Koha facultatif',
            'xslt-assistant':'Module Éditeur XSLT actif ; projets stockés dans le navigateur',
            'bibliography-builder':'Droits Koha ; listes et modèles personnels selon la source',
            'bulk-framework-change':'Droits Koha de catalogage pour les modifications',
            'overdue-management':'Rapport SQL et droits Koha pour les opérations'
        };
        const body=table.createTBody();
        manifest.forEach(item=>{const row=body.insertRow();const a=document.createElement('a');a.href=urlFor(item.id);a.target='_blank';a.rel='noopener';a.textContent=item.title;row.insertCell().appendChild(a);row.insertCell().textContent=(item.id!=='authorities'&&config.pageOptions?.[item.id]?.access && config.pageOptions[item.id].access!=='default'?config.pageOptions[item.id].access:item.access)==='staff'?'Personnel Koha':'Superlibrarian Koha';row.insertCell().textContent=details[item.id] || 'Droits API Koha et paramètres de la page';});
        const detail=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Voir les dix-neuf pages, leurs accès et leurs prérequis';detail.append(summary,table);wrap.append(description,link,detail);return wrap;
    }
    function registerPmk() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule!=='function') return false;
        try {
            window.PMKConfig.registerModule({
                id:MODULE_ID,schemaVersion:4,compactActivation:true,hidePageCount:true,
                name:{fr:'Pages & outils internes',en:'Internal pages & tools'},
                description:{fr:'Retrouvez et ouvrez les outils internes depuis une page commune. Configurez les accès et les paramètres de chaque page ; la page Autorités conserve ses réglages actuels.',en:'Open internal tools from a shared hub. Configure access and settings for each page; the Authorities page retains its existing settings.'},
                category:{fr:'Navigation et interface',en:'Navigation and interface'},
                supportedPages:['*'],prerequisites:[],dependencies:[],defaults:{enabled:true,hubAccess:'superlibrarian',pageOptions:{}},
                validate:cfg=>window.PMKPagesSettings?.validate(cfg)||{ok:true},
                schema:[
                    {type:'section',id:'page-settings',label:{fr:'Configurer une page',en:'Configure a page'},fields:[{type:'custom',render:ctx=>window.PMKPagesSettings.renderEditor(ctx)}]},
                    {type:'section',id:'pages',label:{fr:'Accès et inventaire des pages',en:'Page access and inventory'},fields:[
                        {key:'hubAccess',type:'select',label:{fr:'Accès à l’accueil des outils',en:'Tools hub access'},options:[{value:'superlibrarian',label:{fr:'Superlibrarian Koha',en:'Koha superlibrarian'}},{value:'staff',label:{fr:'Personnel Koha — uniquement ses outils autorisés',en:'Koha staff — permitted tools only'}}]},
                        {type:'custom',render:renderPmkLauncher}
                    ]}
                ]
            });
            return true;
        } catch(_) { return false; }
    }

    window.PMKPages={version:VERSION,moduleId:MODULE_ID,manifest:manifest.map(x=>Object.assign({},x)),register,urlFor,open,isSuperlibrarian,mountLegacyHtml,canOpen,assetUrl:file=>new URL(file,baseUrl).href,refresh:renderRoute,getStatus:id=>Object.assign({},pageStatus.get(id)||{state:'not-opened'}),get:id=>registry.get(id)||null};
    try { document.dispatchEvent(new CustomEvent('pmk:pages-ready')); } catch (_) {}

    function canOpen(id) {
        if (id!==HUB_ID && !byId.has(id))return false;
        if (config.enabled === false) return false;
        const meta=byId.get(id);
        if(id==='authorities')return isSuperlibrarian();
        const access=id===HUB_ID?(config.hubAccess||'superlibrarian'):(config.pageOptions?.[id]?.access && config.pageOptions[id].access!=='default'?config.pageOptions[id].access:meta?.access);
        return access==='staff' || isSuperlibrarian();
    }
    function clearSurface() {
        routeGeneration++;
        routeController?.abort();routeController=null;
        if (disposePage) {try {disposePage();} catch (_) {} disposePage=null;}
        document.getElementById('pmk138-page-host')?.remove();
        hiddenNative.forEach((style,node)=>{if(style.value)node.style.setProperty('display',style.value,style.priority);else node.style.removeProperty('display');});
        hiddenNative.clear();
        document.body?.classList.remove('pmk138-virtual-page');
        document.documentElement.classList.remove('pmk138-virtual-route');
        document.title=originalTitle;
    }
    async function renderRoute() {
        const id=requestedPage();
        if (!id || config.enabled === false) {clearSurface();return;}
        clearSurface();
        document.documentElement.classList.add('pmk138-virtual-route');
        const generation=routeGeneration;
        routeController=new AbortController();
        const host=pageHost();
        if (id !== HUB_ID && !byId.has(id)) {host.appendChild(toolbar('Page inconnue'));host.append('Cette page interne n’existe pas.');return;}
        if (!canOpen(id)) {pageStatus.set(id,{state:'denied'});renderDenied(host);return;}
        if (id===HUB_ID) renderHub(host); else await renderPage(id,host,generation);
    }
    async function connectConfig() {
        if (!registerPmk() || configConnected) return;
        configConnected=true;
        try {config=Object.assign({enabled:true},await window.PMKConfig.getConfig(MODULE_ID));} catch (_) {}
        await renderRoute();
        window.PMKConfig.subscribe?.(MODULE_ID,next=>{
            const changed=config.enabled !== (next?.enabled !== false);
            config=Object.assign({enabled:true},next || {});
            if (changed) renderRoute();
        });
    }
    async function start() {
        injectStyles();
        try{if(!window.PMKPagesSettings){const source=new URL('138-pages-settings.js',baseUrl);source.searchParams.set('v',release);await loadScript(source.href);}window.PMKPagesSettings.attach({get:()=>config,update:next=>{config=Object.assign({enabled:true},next)}});}catch(error){if(requestedPage()){const host=pageHost();host.textContent='Configuration des pages indisponible : '+error.message;const retry=document.createElement('button');retry.type='button';retry.textContent='Réessayer';retry.onclick=start;host.appendChild(retry);}return;}
        if (window.PMKConfig) await connectConfig();
        else {await renderRoute();window.addEventListener('pmk:config-ready',connectConfig,{once:true});}
    }
    if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})(window, document);

;window.PMKNonPlugin.loaded.push("138-pages-manager.js");
} catch (error) { window.PMKNonPlugin.errors.push("138-pages-manager.js: "+error.message); console.error("[PMK] 138-pages-manager.js",error); };
try {
/* ============================================================
   139-attendance-mediabus.js
   PimpMyKoha — Compteur de fréquentation
   Version : 2.0.0 — 22/09/2026

   Extraction du compteur flottant historiquement collé dans IntranetNav.
   - périmètre des bibliothèques configurable ;
   - même Koha / mêmes collections que Attendance Counter 138 ;
   - configuration et moteur de comptage partagés entre les deux vues ;
   - PMK pilote présentation, catégories, pas de saisie et stockage ;
   - API open consommée par IntranetNav 134 ;
   - aucune fermeture utilisateur : le compteur reste disponible sur les sites autorisés ;
   - boutons statistiques / rapport complet 138 visibles uniquement aux superlibrarians ;
   - +/- sécurisés par transaction stockage Koha.
   ============================================================ */
(function(window, document) {
    'use strict';

    if (window.__PMK_ATTENDANCE_MEDIABUS_139__) return;
    window.__PMK_ATTENDANCE_MEDIABUS_139__ = true;

    const MODULE_ID = 'attendance-mediabus-mini';
    const VERSION = '2.0.0';
    const REPORT_URL = '/cgi-bin/koha/mainpage.pl?pmk_page=attendance-counter';
    const STYLE_ID = 'pmk139-attendance-mediabus-style';
    // Keep the historical document ID and count fields; both views use this configuration.
    const DEFAULTS = { enabled:true, autoOpen:true, miniEnabled:true, pageEnabled:true,
        branchNames:'', branchSelector:'.logged-in-branch-name', defaultLocationId:'',
        title:'Compteur de fréquentation', adminPin:'admin', defaultCountedWeeks:8, adultsLabel:'Adultes', kidsLabel:'Enfants',
        step:1, miniWidth:340, countsCollection:'counts', locationsCollection:'locations' };
    let resolveReady;
    const ready = new Promise(resolve => {resolveReady=resolve});

    let config = { ...DEFAULTS };
    let started = false;
    let starting = null;
    let registered = false;
    let unsubscribe = null;

    const LEGACY_CSS = `

    #freqAppMini {
        --freq-bg: #0f1720;
        --freq-card: #0b1220;
        --freq-accent: #10b981;
        --freq-muted: #9aa4b2;
        --freq-radius: 12px;
        --freq-pad: 12px;
        font-family: Inter, system-ui, Segoe UI, Roboto, "Helvetica Neue", Arial;
        color: #e6eef6;
        background: var(--freq-bg);
        border-radius: var(--freq-radius);
        padding: var(--freq-pad);
        width: 340px;
        position: fixed;
        z-index: 10000;
        top: 20px;
        right: 20px;
        border: 1px solid rgba(255, 255, 255, 0.15);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        cursor: move;
        user-select: none;
        resize: both;
        overflow: hidden;
        min-width: 300px;
        max-width: 520px;
        min-height: 250px;
        transition: all 0.3s ease;
        display: none;
    }

    #freqAppMini.visible {
        display: block;
    }

    #freqAppMini:hover {
        border-color: rgba(255, 255, 255, 0.25);
        box-shadow: 0 16px 48px rgba(0, 0, 0, 0.5);
    }

    #freqAppMini.compact {
        width: 200px !important;
        min-width: 200px;
        height: 50px !important;
        min-height: 50px;
        max-height: 50px;
        padding: 8px 12px;
    }

    #freqAppMini.compact .freq-content {
        display: none !important;
    }

    #freqAppMini.compact .freq-title {
        font-size: 11px;
    }

    #freqAppMini .freq-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    }

    #freqAppMini.compact .freq-header {
        margin-bottom: 0;
        padding-bottom: 0;
        border-bottom: none;
    }

    #freqAppMini .freq-title {
        font-size: 11px;
        font-weight: 700;
        color: var(--freq-accent);
        letter-spacing: 0.5px;
    }

    #freqAppMini .freq-controls-btn {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 6px;
        padding: 4px 8px;
        font-size: 11px;
        font-weight: bold;
        color: var(--freq-muted);
        cursor: pointer;
        transition: all 0.2s ease;
        min-width: 24px;
        text-align: center;
    }

    #freqAppMini .freq-controls-btn:hover {
        background: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.3);
        color: white;
    }

    #freqAppMini .freq-content {
        transition: all 0.3s ease;
    }

    #freqAppMini .freq-compact-row {
        display: flex;
        gap: 8px;
        align-items: center;
        margin-bottom: 6px;
        font-size: 11px;
    }

    #freqAppMini select, #freqAppMini input[type=date] {
        padding: 6px 8px;
        border-radius: 6px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        background: rgba(0, 0, 0, 0.4);
        color: white;
        font-size: 11px;
        width: 100%;
        transition: all 0.2s ease;
    }

    #freqAppMini select:focus, #freqAppMini input[type=date]:focus {
        border-color: var(--freq-accent);
        outline: none;
    }

    #freqAppMini select {
        flex: 2;
    }

    #freqAppMini input[type=date] {
        flex: 1;
    }

    #freqAppMini.compact .freq-date-input {
        display: none;
    }

    #freqAppMini .freq-counters {
        display: flex;
        gap: 12px;
        margin: 12px 0;
    }

    #freqAppMini .freq-counter-compact {
        flex: 1;
        text-align: center;
    }

    #freqAppMini .freq-counter-label {
        font-size: 10px;
        color: var(--freq-muted);
        margin-bottom: 6px;
        font-weight: 600;
        letter-spacing: 0.5px;
    }

    #freqAppMini .freq-counter-buttons {
        display: flex;
        align-items: center;
        gap: 6px;
        justify-content: center;
    }

    #freqAppMini .freq-counter-btn {
        width: 32px;
        height: 32px;
        font-size: 14px;
        font-weight: bold;
        background: linear-gradient(180deg, #10b981, #059669);
        border: 1px solid #047857;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        color: white;
        cursor: pointer;
    }

    #freqAppMini .freq-counter-btn:hover {
        background: linear-gradient(180deg, #34d399, #10b981);
        transform: translateY(-1px);
    }

    #freqAppMini .freq-counter-btn:active {
        transform: translateY(0px);
    }

    #freqAppMini .freq-counter-btn:disabled {
        background: linear-gradient(180deg, #6b7280, #4b5563);
        border-color: #374151;
        cursor: not-allowed;
        transform: none;
        opacity: 0.6;
    }

    #freqAppMini .freq-count-display {
        min-width: 40px;
        height: 32px;
        text-align: center;
        font-weight: 800;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: #10b981;
    }

    #freqAppMini .freq-footer {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    #freqAppMini .freq-status {
        font-size: 10px;
        color: var(--freq-muted);
        flex: 1 1 100%;
        font-weight: 500;
    }

    #freqAppMini .freq-action-btn {
        background: linear-gradient(180deg, #3b82f6, #1d4ed8);
        border: 1px solid #1e40af;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 10px;
        font-weight: 600;
        color: white;
        cursor: pointer;
        margin-left: 0;
        transition: all 0.2s ease;
        white-space: nowrap;
    }

    #freqAppMini .freq-action-btn:hover {
        background: linear-gradient(180deg, #60a5fa, #3b82f6);
        transform: translateY(-1px);
    }

    #freqAppMini .freq-action-btn:disabled {
        background: linear-gradient(180deg, #6b7280, #4b5563);
        border-color: #374151;
        cursor: not-allowed;
        transform: none;
        opacity: 0.6;
    }

    #freqAppMini .freq-reset-btn {
        background: linear-gradient(180deg, #6b7280, #4b5563);
        border: 1px solid #374151;
    }

    #freqAppMini .freq-reset-btn:hover {
        background: linear-gradient(180deg, #9ca3af, #6b7280);
    }

    #freqAppMini .freq-report-btn {
        background: linear-gradient(180deg, #8b5cf6, #7c3aed);
        border: 1px solid #6d28d9;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 10px;
        font-weight: 600;
        color: white;
        cursor: pointer;
        margin-left: 6px;
        transition: all 0.2s ease;
        text-decoration: none;
        display: inline-block;
        line-height: 1.2;
    }

    #freqAppMini .freq-report-btn:hover {
        background: linear-gradient(180deg, #a78bfa, #8b5cf6);
        transform: translateY(-1px);
        text-decoration: none;
        color: white;
    }

    #freqAppMini .freq-correction-btn {
        background: linear-gradient(180deg, #f59e0b, #d97706);
        border: 1px solid #b45309;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 10px;
        font-weight: 600;
        color: white;
        cursor: pointer;
        margin-left: 6px;
        transition: all 0.2s ease;
    }

    #freqAppMini .freq-correction-btn:hover {
        background: linear-gradient(180deg, #fbbf24, #f59e0b);
        transform: translateY(-1px);
    }

    /* Overlay et modal de correction */
    #freq-correction-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 10001;
        display: none;
    }

    #freq-correction-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: var(--freq-card);
        border-radius: var(--freq-radius);
        padding: 20px;
        z-index: 10002;
        width: 280px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        display: none;
    }

    #freq-correction-modal.visible {
        display: block;
    }

    #freq-correction-overlay.visible {
        display: block;
    }

    .freq-correction-title {
        font-size: 14px;
        font-weight: 700;
        color: var(--freq-accent);
        margin-bottom: 15px;
        text-align: center;
    }

    .freq-time-inputs {
        display: flex;
        gap: 8px;
        align-items: center;
        justify-content: center;
        margin-bottom: 15px;
    }

    .freq-time-inputs input {
        width: 50px;
        padding: 8px;
        text-align: center;
        background: rgba(0, 0, 0, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 6px;
        color: white;
        font-size: 14px;
    }

    .freq-time-inputs span {
        color: var(--freq-muted);
        font-weight: bold;
    }

    .freq-correction-buttons {
        display: flex;
        gap: 8px;
        margin-bottom: 15px;
        justify-content: center;
    }

    .freq-correction-counter-btn {
        background: linear-gradient(180deg, #10b981, #059669);
        border: 1px solid #047857;
        border-radius: 8px;
        padding: 10px 15px;
        font-size: 11px;
        font-weight: 600;
        color: white;
        cursor: pointer;
        transition: all 0.2s ease;
        flex: 1;
    }

    .freq-correction-counter-btn:hover {
        background: linear-gradient(180deg, #34d399, #10b981);
        transform: translateY(-1px);
    }

    .freq-modal-actions {
        display: flex;
        gap: 8px;
        justify-content: center;
    }

    .freq-modal-btn {
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        border: 1px solid;
    }

    .freq-modal-cancel {
        background: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.2);
        color: var(--freq-muted);
    }

    .freq-modal-cancel:hover {
        background: rgba(255, 255, 255, 0.15);
        color: white;
    }

    .freq-modal-validate {
        background: linear-gradient(180deg, #10b981, #059669);
        border-color: #047857;
        color: white;
    }

    .freq-modal-validate:hover {
        background: linear-gradient(180deg, #34d399, #10b981);
    }

    .freq-modal-validate:disabled {
        background: linear-gradient(180deg, #6b7280, #4b5563);
        border-color: #374151;
        cursor: not-allowed;
        opacity: 0.6;
    }

    .freq-correction-preview {
        font-size: 11px;
        text-align: center;
        color: var(--freq-muted);
        margin-bottom: 10px;
        min-height: 16px;
    }

    .freq-correction-reason {display:block;font-size:11px;color:var(--freq-muted);margin:0 0 12px}
    .freq-correction-reason textarea {display:block;width:100%;box-sizing:border-box;margin-top:5px;padding:7px;border:1px solid rgba(255,255,255,.2);border-radius:6px;background:rgba(0,0,0,.4);color:#fff;resize:vertical}

    #freq-location-fix-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 10001;
        display: none;
    }

    #freq-location-fix-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: var(--freq-card);
        border-radius: var(--freq-radius);
        padding: 16px;
        z-index: 10002;
        width: 320px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        display: none;
    }

    #freq-location-fix-modal.visible,
    #freq-location-fix-overlay.visible {
        display: block;
    }

    .freq-fix-row {
        margin-bottom: 10px;
    }

    .freq-fix-row label {
        display: block;
        font-size: 11px;
        color: var(--freq-muted);
        margin-bottom: 4px;
    }

    .freq-fix-row select,
    .freq-fix-row input {
        width: 100%;
        padding: 7px;
        border-radius: 6px;
        border: 1px solid rgba(255, 255, 255, 0.12);
        background: rgba(0, 0, 0, 0.4);
        color: white;
        font-size: 11px;
    }

    .freq-fix-dates {
        display: flex;
        gap: 8px;
    }

    .freq-fix-dates > div {
        flex: 1;
    }

    /* Style pour le drag */
    #freqAppMini.dragging {
        opacity: 0.9;
        cursor: grabbing;
        transform: scale(1.02);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
    }

    /* Style pour le redimensionnement */
    #freqAppMini::-webkit-resizer {
        background: var(--freq-accent);
        border-radius: 0 0 12px 0;
    }

    #freqAppMini::-webkit-resizer:hover {
        background: #34d399;
    }

    /* Cacher le resizer en mode compact */
    #freqAppMini.compact {
        resize: none;
    }


    #freqAppMini .freq-header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* ============================================================
       v1.1.0 — ergonomie terrain / design Koha
       ============================================================ */
    #freqAppMini {
        --freq-bg: #ffffff;
        --freq-card: #ffffff;
        --freq-accent: #2f7d5b;
        --freq-accent-strong: #236448;
        --freq-accent-soft: #edf7f1;
        --freq-text: #23313a;
        --freq-muted: #6b7882;
        --freq-border: #d9e2e7;
        --freq-danger: #b42318;
        width: 450px;
        min-width: 430px;
        max-width: min(480px, calc(100vw - 24px));
        min-height: 0;
        padding: 0;
        color: var(--freq-text);
        background: var(--freq-bg);
        border: 1px solid var(--freq-border);
        border-radius: 14px;
        box-shadow: 0 12px 34px rgba(31, 51, 62, .22);
        overflow: hidden;
        resize: none !important;
        height: auto !important;
        max-height: none;
    }

    #freqAppMini:hover {
        border-color: #c5d2d8;
        box-shadow: 0 15px 40px rgba(31, 51, 62, .26);
    }

    #freqAppMini .freq-header {
        margin: 0;
        padding: 8px 10px;
        border: 0;
        border-bottom: 1px solid var(--freq-border);
        background: linear-gradient(180deg, #fbfdfc 0%, #f4f8f6 100%);
        cursor: move;
    }

    #freqAppMini .freq-heading {
        display: flex;
        align-items: center;
        gap: 5px;
        min-width: 0;
    }

    #freqAppMini .freq-heading-icon {
        width: 27px;
        height: 27px;
        border-radius: 9px;
        display: grid;
        place-items: center;
        background: var(--freq-accent-soft);
        color: var(--freq-accent);
        font-size: 14px;
        font-weight: 800;
    }

    #freqAppMini .freq-title {
        color: var(--freq-text);
        font-size: 13px;
        line-height: 1.15;
        letter-spacing: 0;
        text-transform: none;
    }

    #freqAppMini .freq-subtitle {
        margin-top: 1px;
        color: var(--freq-muted);
        font-size: 9px;
        font-weight: 500;
    }

    #freqAppMini .freq-controls-btn {
        width: 27px;
        height: 27px;
        min-width: 30px;
        padding: 0;
        border: 1px solid var(--freq-border);
        border-radius: 8px;
        background: #fff;
        color: #53636e;
        font-size: 15px;
        display: grid;
        place-items: center;
    }

    #freqAppMini .freq-controls-btn:hover {
        background: var(--freq-accent-soft);
        border-color: #bad3c5;
        color: var(--freq-accent-strong);
    }


    #freqAppMini .freq-content {
        padding: 9px 10px;
        background: #fff;
    }

    #freqAppMini .freq-context {
        display: grid;
        grid-template-columns: minmax(0, 1.5fr) minmax(120px, .8fr);
        gap: 5px;
        margin-bottom: 11px;
    }

    #freqAppMini .freq-field {
        min-width: 0;
    }

    #freqAppMini .freq-field > span {
        display: block;
        margin: 0 0 3px;
        color: var(--freq-muted);
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .04em;
    }

    #freqAppMini select,
    #freqAppMini input[type=date] {
        width: 100%;
        height: 34px;
        padding: 5px 8px;
        border: 1px solid var(--freq-border);
        border-radius: 8px;
        background: #fff;
        color: var(--freq-text);
        font-size: 11px;
        box-shadow: none;
    }

    #freqAppMini select:focus,
    #freqAppMini input[type=date]:focus {
        border-color: var(--freq-accent);
        box-shadow: 0 0 0 3px rgba(47, 125, 91, .12);
    }

    #freqAppMini .freq-counters {
        gap: 5px;
        margin: 0;
    }

    #freqAppMini .freq-counter-compact {
        padding: 7px 8px;
        border: 1px solid var(--freq-border);
        border-radius: 11px;
        background: #fbfcfc;
    }

    #freqAppMini .freq-counter-label {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        margin-bottom: 6px;
        color: #53636e;
        font-size: 11px;
        letter-spacing: 0;
        text-transform: none;
    }

    #freqAppMini .freq-counter-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        display: inline-block;
    }

    #freqAppMini .freq-adult-dot { background: #2f73b7; }
    #freqAppMini .freq-kid-dot { background: #b35c87; }

    #freqAppMini .freq-counter-buttons {
        gap: 5px;
    }

    #freqAppMini .freq-counter-btn {
        width: 36px;
        height: 36px;
        border: 1px solid #bfd5c9;
        border-radius: 10px;
        background: var(--freq-accent-soft);
        color: var(--freq-accent-strong);
        font-size: 19px;
        font-weight: 700;
        box-shadow: none;
        touch-action: manipulation;
    }

    #freqAppMini .freq-counter-btn:hover {
        background: #dff1e7;
        border-color: #a9c9b8;
        transform: none;
    }

    #freqAppMini .freq-counter-btn:active {
        background: #d2eadd;
        transform: scale(.96);
    }

    #freqAppMini .freq-counter-btn:disabled {
        background: #f2f4f5;
        border-color: #e0e5e7;
        color: #9aa5ab;
        opacity: 1;
    }

    #freqAppMini .freq-count-display {
        min-width: 58px;
        height: 36px;
        border: 0;
        border-radius: 10px;
        background: #fff;
        color: var(--freq-text);
        font-size: 21px;
        font-variant-numeric: tabular-nums;
        box-shadow: inset 0 0 0 1px var(--freq-border);
    }

    #freqAppMini .freq-total-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-top: 7px;
        padding: 6px 9px;
        border-radius: 9px;
        background: var(--freq-accent-soft);
        color: var(--freq-accent-strong);
        font-size: 11px;
        font-weight: 700;
    }

    #freqAppMini .freq-total-bar strong {
        font-size: 16px;
        font-variant-numeric: tabular-nums;
    }

    #freqAppMini .freq-footer {
        display: block;
        margin: 7px 0 0;
        padding: 7px 0 0;
        border-top: 1px solid var(--freq-border);
    }

    #freqAppMini .freq-status-row {
        min-height: 17px;
        display: flex;
        align-items: center;
        gap: 6px;
        margin-bottom: 6px;
    }

    #freqAppMini .freq-status-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: var(--freq-accent);
        box-shadow: 0 0 0 3px rgba(47, 125, 91, .10);
    }

    #freqAppMini .freq-status {
        flex: 1;
        color: var(--freq-muted);
        font-size: 10px;
        font-weight: 600;
    }

    #freqAppMini .freq-actions-toggle {
        width: 100%;
        min-height: 28px;
        margin: 0;
        padding: 4px 8px;
        border: 1px solid var(--freq-border);
        border-radius: 8px;
        background: #f7f9f8;
        color: #43535e;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        font-size: 9px;
        font-weight: 800;
        cursor: pointer;
    }

    #freqAppMini .freq-actions-toggle:hover {
        background: #f0f5f3;
        border-color: #c5d3ce;
        color: var(--freq-accent-strong);
    }

    #freqAppMini .freq-actions-toggle .freq-actions-chevron {
        display: inline-block;
        font-size: 11px;
        line-height: 1;
        transform: rotate(0deg);
        transition: transform .16s ease;
    }

    #freqAppMini .freq-actions-toggle[aria-expanded="true"] .freq-actions-chevron {
        transform: rotate(180deg);
    }

    #freqAppMini .freq-actions-panel {
        display: none;
        padding-top: 6px;
    }

    #freqAppMini .freq-actions-panel.open {
        display: block;
    }

    #freqAppMini .freq-primary-actions {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 5px;
    }

    #freqAppMini .freq-secondary-actions {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 5px;
        margin-top: 7px;
    }

    #freqAppMini .freq-action-btn,
    #freqAppMini .freq-report-btn,
    #freqAppMini .freq-correction-btn {
        min-height: 30px;
        margin: 0;
        padding: 4px 6px;
        border: 1px solid var(--freq-border);
        border-radius: 8px;
        background: #fff;
        color: #43535e;
        font-size: 9px;
        font-weight: 700;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        box-shadow: none;
    }

    #freqAppMini .freq-action-btn:hover,
    #freqAppMini .freq-report-btn:hover,
    #freqAppMini .freq-correction-btn:hover {
        background: #f5f8f7;
        border-color: #c5d3ce;
        color: var(--freq-accent-strong);
        transform: none;
        text-decoration: none;
    }

    #freqAppMini .freq-update-btn {
        background: var(--freq-accent);
        border-color: var(--freq-accent);
        color: #fff;
    }

    #freqAppMini .freq-update-btn:hover {
        background: var(--freq-accent-strong);
        border-color: var(--freq-accent-strong);
        color: #fff;
    }

    #freqAppMini .freq-stat-btn {
        background: #eef5fb;
        border-color: #c9ddeb;
        color: #265e87;
    }

    #freqAppMini .freq-reset-btn {
        color: #7a4c4a;
        background: #fff8f7;
        border-color: #edd6d3;
    }

    #freqAppMini .freq-action-btn:disabled {
        background: #f2f4f5;
        border-color: #e0e5e7;
        color: #9aa5ab;
        opacity: 1;
    }

    #freqAppMini .freq-more-actions {
        margin-top: 5px;
    }

    #freqAppMini .freq-more-actions summary {
        cursor: pointer;
        color: var(--freq-muted);
        font-size: 9px;
        font-weight: 700;
        user-select: none;
        list-style: none;
    }

    #freqAppMini .freq-more-actions summary::-webkit-details-marker {
        display: none;
    }

    #freqAppMini .freq-more-actions summary::before {
        content: "›";
        display: inline-block;
        margin-right: 5px;
        transition: transform .15s ease;
    }

    #freqAppMini .freq-more-actions[open] summary::before {
        transform: rotate(90deg);
    }

    #freq-correction-overlay,
    #freq-location-fix-overlay {
        background: rgba(22, 34, 41, .38);
        backdrop-filter: blur(2px);
    }

    #freq-correction-modal,
    #freq-location-fix-modal {
        background: #fff;
        color: var(--freq-text);
        border: 1px solid var(--freq-border);
        border-radius: 14px;
        box-shadow: 0 20px 60px rgba(31, 51, 62, .25);
    }

    .freq-correction-title {
        color: var(--freq-text);
        font-size: 14px;
        text-align: left;
        letter-spacing: 0;
    }

    .freq-time-inputs input,
    .freq-fix-row select,
    .freq-fix-row input {
        background: #fff;
        color: var(--freq-text);
        border: 1px solid var(--freq-border);
        border-radius: 8px;
    }

    .freq-time-inputs input:focus,
    .freq-fix-row select:focus,
    .freq-fix-row input:focus {
        outline: none;
        border-color: var(--freq-accent);
        box-shadow: 0 0 0 3px rgba(47, 125, 91, .12);
    }

    .freq-time-inputs span,
    .freq-fix-row label,
    .freq-correction-preview {
        color: var(--freq-muted);
    }

    .freq-correction-counter-btn,
    .freq-modal-validate {
        background: var(--freq-accent);
        border-color: var(--freq-accent);
        color: #fff;
        border-radius: 8px;
        box-shadow: none;
    }

    .freq-correction-counter-btn:hover,
    .freq-modal-validate:hover {
        background: var(--freq-accent-strong);
        border-color: var(--freq-accent-strong);
        transform: none;
    }

    .freq-modal-cancel {
        background: #fff;
        border-color: var(--freq-border);
        color: #53636e;
        border-radius: 8px;
    }

    .freq-modal-cancel:hover {
        background: #f5f8f7;
        color: var(--freq-text);
    }

    #freqAppMini.compact {
        width: 210px !important;
        min-width: 210px;
        height: 48px !important;
        min-height: 48px;
        max-height: 48px;
        padding: 0;
        resize: none;
    }

    #freqAppMini.compact .freq-header {
        height: 48px;
        padding: 8px 9px;
        border-bottom: 0;
    }

    #freqAppMini.compact .freq-subtitle,
    #freqAppMini.compact .freq-heading-icon,
    #freqAppMini.compact #freq-openFullReport {
        display: none !important;
    }

    #freqAppMini.compact .freq-title {
        font-size: 11px;
    }

    @media (max-width: 575.98px) {
        #freqAppMini {
            width: calc(100vw - 16px) !important;
            min-width: 0 !important;
            max-width: none;
            left: 8px !important;
            right: 8px !important;
            top: auto !important;
            bottom: 8px !important;
            resize: none;
            border-radius: 12px;
        }

        #freqAppMini .freq-header {
            cursor: default;
        }

        #freqAppMini .freq-context {
            grid-template-columns: 1fr;
        }

        #freqAppMini .freq-counters {
            gap: 5px;
        }

        #freqAppMini .freq-counter-btn {
            width: 40px;
            height: 40px;
        }

        #freqAppMini .freq-count-display {
            min-width: 56px;
            height: 40px;
        }

        #freqAppMini .freq-primary-actions,
        #freqAppMini .freq-secondary-actions {
            grid-template-columns: 1fr 1fr;
        }
    }

    `;

    const LEGACY_HTML = `
<!-- Module compteur flottant - Caché par défaut -->
<div id="freqAppMini">
    <div class="freq-header">
        <div class="freq-heading">
            <div class="freq-heading-icon" aria-hidden="true">↕</div>
            <div>
                <div class="freq-title">Compteur de fréquentation</div>
                <div class="freq-subtitle">Fréquentation terrain</div>
            </div>
        </div>
        <div class="freq-header-actions">
            <button class="freq-controls-btn" id="freq-openFullReport" title="Ouvrir les statistiques complètes" aria-label="Ouvrir les statistiques complètes" style="display:none">↗</button>
            <button class="freq-controls-btn" id="freq-toggleCompact" title="Réduire/Agrandir" aria-label="Réduire ou agrandir">−</button>
        </div>
    </div>

    <div class="freq-content">
        <div class="freq-context">
            <label class="freq-field freq-location-field">
                <span>Lieu</span>
                <select id="freq-selectLocationMini">
                    <option value="">Sélectionnez un lieu</option>
                </select>
            </label>
            <label class="freq-field freq-date-field">
                <span>Date</span>
                <input type="date" id="freq-inputDateMini" class="freq-date-input" />
            </label>
        </div>

        <div class="freq-counters">
            <div class="freq-counter-compact">
                <div class="freq-counter-label"><span class="freq-counter-dot freq-adult-dot"></span>Adultes</div>
                <div class="freq-counter-buttons">
                    <button class="freq-counter-btn" id="freq-decAdultsMini" title="Décrémenter" disabled>−</button>
                    <div class="freq-count-display" id="freq-countAdultsMini">0</div>
                    <button class="freq-counter-btn" id="freq-incAdultsMini" title="Incrémenter" disabled>+</button>
                </div>
            </div>
            <div class="freq-counter-compact">
                <div class="freq-counter-label"><span class="freq-counter-dot freq-kid-dot"></span>Enfants</div>
                <div class="freq-counter-buttons">
                    <button class="freq-counter-btn" id="freq-decKidsMini" title="Décrémenter" disabled>−</button>
                    <div class="freq-count-display" id="freq-countKidsMini">0</div>
                    <button class="freq-counter-btn" id="freq-incKidsMini" title="Incrémenter" disabled>+</button>
                </div>
            </div>
        </div>

        <div class="freq-total-bar">
            <span>Total du jour</span>
            <strong id="freq-totalMini">0</strong>
        </div>

        <div class="freq-footer">
            <div class="freq-status-row">
                <span class="freq-status-dot" aria-hidden="true"></span>
                <div class="freq-status" id="freq-statusMini">Sélectionnez un lieu</div>
            </div>

            <button type="button"
                    class="freq-actions-toggle"
                    id="freq-actionsToggleMini"
                    aria-expanded="false"
                    aria-controls="freq-actionsPanelMini">
                <span>Actions <span class="freq-muted-count">(6)</span></span>
                <span class="freq-actions-chevron" aria-hidden="true">⌄</span>
            </button>

            <div class="freq-actions-panel" id="freq-actionsPanelMini">
                <div class="freq-primary-actions">
                    <button class="freq-action-btn freq-update-btn"
                            id="freq-btnUpdateMini"
                            title="Synchroniser avec le serveur"
                            disabled>
                        <span aria-hidden="true">↻</span> Actualiser
                    </button>

                    <button class="freq-action-btn freq-correction-btn"
                            id="freq-btnCorrectionMini"
                            title="Ajouter une correction horaire"
                            disabled>
                        <span aria-hidden="true">＋</span> Correction
                    </button>

                    <a href="${REPORT_URL}"
                       target="_blank"
                       rel="noopener"
                       id="freq-statsLinkMini"
                       class="freq-action-btn freq-stat-btn"
                       title="Ouvrir les statistiques Attendance Counter">
                        <span aria-hidden="true">▥</span> Statistiques
                    </a>
                </div>

                <div class="freq-secondary-actions" aria-label="Actions complémentaires">
                        <button class="freq-action-btn freq-reset-btn"
                                id="freq-btnResetMini"
                                title="Remettre les compteurs locaux à zéro"
                                disabled>
                            Reset
                        </button>

                        <button class="freq-action-btn freq-correction-btn"
                                id="freq-btnFixLocationMini"
                                title="Corriger un lieu sur l'historique"
                                disabled>
                            Correction lieu
                        </button>

                        <a href="${REPORT_URL}"
                           target="_blank"
                           rel="noopener"
                           class="freq-action-btn freq-report-btn"
                           title="Ouvrir le rapport SQL configuré">
                            Rapport SQL
                        </a>
                </div>
            </div>
        </div>


    </div>
</div>

<!-- Modal de correction -->
<div id="freq-correction-overlay"></div>
<div id="freq-correction-modal">
    <div class="freq-correction-title">CORRECTION HORAIRE</div>

    <div class="freq-time-inputs">
        <input type="number" id="freq-correction-hours" min="0" max="23" value="12" placeholder="HH">
        <span>h</span>
        <input type="number" id="freq-correction-minutes" min="0" max="59" value="0" placeholder="MM">
    </div>

    <div class="freq-correction-preview" id="freq-correction-preview">
        Heure sélectionnée : 12h00
    </div>

    <label class="freq-correction-reason" for="freq-correction-reason">Justification de la correction
        <textarea id="freq-correction-reason" maxlength="300" rows="2" placeholder="Ex. saisie différée après fermeture"></textarea>
    </label>

    <div class="freq-correction-buttons">
        <button class="freq-correction-counter-btn" id="freq-correction-adult">+1 Adulte</button>
        <button class="freq-correction-counter-btn" id="freq-correction-kid">+1 Enfant</button>
    </div>

    <div class="freq-modal-actions">
        <button class="freq-modal-btn freq-modal-cancel" id="freq-correction-cancel">Annuler</button>
        <button class="freq-modal-btn freq-modal-validate" id="freq-correction-validate" disabled>Valider (0)</button>
    </div>
</div>

<!-- Modal correction de lieu -->
<div id="freq-location-fix-overlay"></div>
<div id="freq-location-fix-modal">
    <div class="freq-correction-title">CORRECTION DE LIEU</div>

    <div class="freq-fix-row">
        <label for="freq-fix-old-location-mini">Lieu source</label>
        <select id="freq-fix-old-location-mini">
            <option value="">Lieu à corriger</option>
        </select>
    </div>

    <div class="freq-fix-row">
        <label for="freq-fix-new-location-mini">Nouveau lieu</label>
        <select id="freq-fix-new-location-mini">
            <option value="">Lieu de destination</option>
        </select>
    </div>

    <div class="freq-fix-row freq-fix-dates">
        <div>
            <label for="freq-fix-from-mini">Du</label>
            <input type="date" id="freq-fix-from-mini" />
        </div>
        <div>
            <label for="freq-fix-to-mini">Au</label>
            <input type="date" id="freq-fix-to-mini" />
        </div>
    </div>

    <div class="freq-modal-actions">
        <button class="freq-modal-btn freq-modal-cancel" id="freq-fix-cancel-mini">Annuler</button>
        <button class="freq-modal-btn freq-modal-validate" id="freq-fix-validate-mini">Corriger</button>
    </div>
</div>
    `;

    function isMediabus() { // Legacy method name retained for saved menu actions.
        const names=String(config.branchNames || '').split(/[\n,;]+/).map(value=>value.trim().toLocaleLowerCase()).filter(Boolean);
        if (!names.length) return true;
        try {
            const branch=document.querySelector(config.branchSelector || DEFAULTS.branchSelector);
            const values=[branch?.textContent,branch?.getAttribute('data-branchcode')].filter(Boolean).map(value=>String(value).trim().toLocaleLowerCase());
            return values.some(value=>names.includes(value));
        } catch (_) {return false}
    }

    function normalizeConfiguration(next) {
        const cfg=Object.assign({},DEFAULTS,next || {});
        cfg.step=Math.max(1,Math.min(100,Math.round(Number(cfg.step) || 1)));
        cfg.miniWidth=Math.max(300,Math.min(520,Number(cfg.miniWidth) || 340));
        cfg.defaultCountedWeeks=Math.max(1,Math.min(53,Math.round(Number(cfg.defaultCountedWeeks) || 8)));
        return cfg;
    }

    function decorate(root) {
        if (!root) return;
        if(root.id==='freqApp'){root.inert=config.enabled===false || config.pageEnabled===false || !isMediabus();}
        const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
        const texts=[];while(walker.nextNode())texts.push(walker.currentNode);
        texts.forEach(node=>{
            if(node.parentElement?.closest('script, style, option, .freq-location-list')) return;
            const original=node.__pmkAttendanceLabel ?? node.nodeValue;
            if(!/Adultes|Enfants/.test(original))return;
            node.__pmkAttendanceLabel=original;
            node.nodeValue=original.replace(/Adultes/g,()=>String(config.adultsLabel)).replace(/Enfants/g,()=>String(config.kidsLabel));
        });
        const title=root.querySelector('.freq-title, header h1');if(title)title.textContent=config.title;
        if(root.id==='freqAppMini')root.style.width=config.miniWidth+'px';
        root.querySelectorAll('[id^="freq-inc"], [id^="freq-dec"]').forEach(button=>{
            const label=button.id.includes('Adults')?config.adultsLabel:config.kidsLabel;
            button.title=(button.id.includes('-inc')?'Ajouter ':'Retirer ')+config.step+' — '+label;
            button.setAttribute('aria-label',button.title);
        });
    }

    // Single transaction engine shared by the floating and full-page views.
    async function mutateSharedCounter(deps, request) {
        if(config.enabled===false || !isMediabus())throw new Error('Compteur désactivé pour ce site');
        const {db,doc,runTransaction,serverTimestamp}=deps;
        const storage=deps.configuration || config;
        if(storage.countsCollection!==config.countsCollection)throw new Error('Rechargez la page après un changement du stockage.');
        const {type,locationId,date,userId,existingId,notes,additions}=request;
        if(!['adults','kids','notes','correction'].includes(type) || !locationId || !/^\d{4}-\d{2}-\d{2}$/.test(date))throw new Error('Saisie de fréquentation invalide');
        const delta=Math.sign(Number(request.delta) || 0)*config.step;
        const id=existingId || (locationId+'__'+date).replace(/[^A-Za-z0-9_.-]/g,'_');
        const ref=doc(db,storage.countsCollection,id);
        const result=await runTransaction(db,async transaction=>{
            const snap=await transaction.get(ref);
            const data=snap.exists()?snap.data():{};
            const count=value=>Math.max(0,Math.floor(Number(value) || 0));
            const payload={locationId,date,adults:count(data.adults),kids:count(data.kids),
                adultTimestamps:Array.isArray(data.adultTimestamps)?data.adultTimestamps.slice():[],
                kidTimestamps:Array.isArray(data.kidTimestamps)?data.kidTimestamps.slice():[],
                userId:userId || 'anonymous',updatedAt:serverTimestamp()};
            function adjust(category,change,timestamp) {
                const before=payload[category];payload[category]=Math.max(0,before+change);
                const times=category==='adults'?payload.adultTimestamps:payload.kidTimestamps;
                const actual=payload[category]-before;
                if(actual>0)for(let i=0;i<actual;i++)times.push(timestamp || new Date().toISOString());
                else times.splice(Math.max(0,times.length+actual),-actual);
            }
            if(type==='adults' || type==='kids')adjust(type,delta);
            if(type==='correction') {
                if(!additions || !Number.isFinite(Date.parse(additions.timestamp)))throw new Error('Heure de correction invalide');
                const reason=String(request.reason || '').trim();
                if(reason.length<3 || reason.length>300)throw new Error('Indiquez une justification de 3 à 300 caractères.');
                for(const category of ['adults','kids']) {
                    const amount=Number(additions[category] || 0);
                    if(!Number.isInteger(amount) || amount<0 || amount>10000)throw new Error('Nombre de personnes invalide');
                    adjust(category,amount,additions.timestamp);
                }
                const log=Array.isArray(data.correctionLog)?data.correctionLog.slice(-49):[];
                log.push({reason,userId:userId || 'anonymous',recordedAt:new Date().toISOString(),eventAt:additions.timestamp,
                    adults:Number(additions.adults || 0),kids:Number(additions.kids || 0)});
                payload.correctionLog=log;
                payload.lastCorrection=log[log.length-1];
            }
            if(notes) {
                if(Object.prototype.hasOwnProperty.call(notes,'adults'))payload.noteAdults=String(notes.adults);
                if(Object.prototype.hasOwnProperty.call(notes,'kids'))payload.noteKids=String(notes.kids);
            }
            if(!snap.exists())payload.createdAt=serverTimestamp();
            transaction.set(ref,payload,{merge:true});
            return payload;
        });
        document.dispatchEvent(new CustomEvent('pmk:attendance-count-changed',{detail:{locationId,date}}));
        return result;
    }

    function isSuperlibrarian() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === 'function') {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }
        const user = document.querySelector('.loggedinusername[data-is-superlibrarian], .loggedinusername.is_superlibrarian');
        if (!user) return false;
        if (user.classList.contains('is_superlibrarian')) return true;
        return /^(1|true|yes|superlibrarian|is_superlibrarian)$/i.test(String(user.getAttribute('data-is-superlibrarian') || '').trim());
    }

    function dispatchState(reason) {
        try {
            document.dispatchEvent(new CustomEvent('pmk:attendance-mediabus-state', {
                detail: {
                    reason: reason || 'state',
                    available: isMediabus(),
                    enabled: config.enabled !== false,
                    autoOpen: config.autoOpen !== false,
                    started,
                    visible: !!document.getElementById('freqAppMini')?.classList.contains('visible')
                }
            }));
        } catch (_) {}
    }

    function injectShell() {
        if (!document.getElementById(STYLE_ID)) {
            const style = document.createElement('style');
            style.id = STYLE_ID;
            style.textContent = LEGACY_CSS;
            document.head.appendChild(style);
        }
        if (!document.getElementById('freqAppMini')) {
            const holder = document.createElement('div');
            holder.innerHTML = LEGACY_HTML;
            while (holder.firstChild) document.body.appendChild(holder.firstChild);
        }
        const report = document.getElementById('freq-openFullReport');
        const statsLink = document.getElementById('freq-statsLinkMini');
        const canOpenStats = isSuperlibrarian();

        if (statsLink) {
            statsLink.href = REPORT_URL;
            statsLink.style.display = canOpenStats ? '' : 'none';
        }

        if (report && !report.dataset.pmkBound) {
            report.dataset.pmkBound = '1';
            report.style.display = canOpenStats ? '' : 'none';
            report.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                window.open(REPORT_URL, '_blank', 'noopener');
            });
        }

    }

    async function startLegacy() {

    // Configuration Koha — même projet et mêmes collections que Attendance Counter 138.


    const {
        collection,
        addDoc,
        getDocs,
        updateDoc,
        doc,
        serverTimestamp,
        query,
        where,
        runTransaction
    , createDatabase, getSession} = window.PMKNativeData;

    const attendanceConfig=window.PMKAttendance.getConfig();
    const db = createDatabase('attendance');

    function getLocalDateString(date = new Date()) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function buildTimestampForLocalDateTime(dateString, hourMinute) {
        const [year, month, day] = (dateString || '').split('-').map(Number);
        const [hour, minute] = (hourMinute || '').split(':').map(Number);

        if (!year || !month || !day || Number.isNaN(hour) || Number.isNaN(minute)) {
            return new Date().toISOString();
        }

        const localDate = new Date(year, month - 1, day, hour, minute, 0, 0);
        return localDate.toISOString();
    }

    function getDocTimestampMillis(docData) {
        const updated = docData && docData.updatedAt && typeof docData.updatedAt.toMillis === 'function'
            ? docData.updatedAt.toMillis()
            : 0;
        const created = docData && docData.createdAt && typeof docData.createdAt.toMillis === 'function'
            ? docData.createdAt.toMillis()
            : 0;
        return Math.max(updated, created);
    }

    let state = {
        user: null,
        locations: [],
        current: {
            adults: 0,
            kids: 0,
            date: getLocalDateString(),
            locationId: null
        },
        timestamps: {
            adults: [],
            kids: []
        },
        isCompact: false,
        correction: {
            adults: 0,
            kids: 0,
            hour: "12:00",
            reason: ""
        }
    };

    const el = id => document.getElementById(id);

    function updateStatus(message) {
        el('freq-statusMini').textContent = message;
    }

    function selectPrimaryCountDoc(docs) {
        if (!docs || docs.length === 0) return null;
        if (docs.length === 1) return docs[0];

        let bestDoc = docs[0];
        let bestScore = getDocTimestampMillis(bestDoc.data());

        for (let i = 1; i < docs.length; i++) {
            const score = getDocTimestampMillis(docs[i].data());
            if (score > bestScore) {
                bestDoc = docs[i];
                bestScore = score;
            }
        }

        return bestDoc;
    }

    function ensureMiniButtonsVisible() {
        if (state.isCompact) return;
        const appElement = el('freqAppMini');
        if (!appElement) return;
        appElement.style.removeProperty('width');
        appElement.style.removeProperty('height');
    }

    // Maintient le compteur dans la zone visible après un changement de taille d'écran.
    function fitMiniToViewport() {
        const appElement = el('freqAppMini');
        if (!appElement || !appElement.classList.contains('visible')) return;

        // En smartphone, le CSS responsive impose volontairement la position.
        if (window.matchMedia('(max-width: 575.98px)').matches) {
            return;
        }

        const margin = 8;
        const rect = appElement.getBoundingClientRect();
        const maxLeft = Math.max(margin, window.innerWidth - rect.width - margin);
        const maxTop = Math.max(margin, window.innerHeight - Math.min(rect.height, window.innerHeight - (margin * 2)) - margin);

        const nextLeft = Math.min(Math.max(rect.left, margin), maxLeft);
        const nextTop = Math.min(Math.max(rect.top, margin), maxTop);

        if (Math.abs(nextLeft - rect.left) > 0.5 || Math.abs(nextTop - rect.top) > 0.5) {
            appElement.style.left = nextLeft + 'px';
            appElement.style.top = nextTop + 'px';
            appElement.style.right = 'auto';

            localStorage.setItem('freqAppPosition', JSON.stringify({
                x: nextLeft,
                y: nextTop
            }));
        }
    }

    // Activer/désactiver les boutons selon la sélection de commune
    function updateButtonsState() {
        const hasLocation = !!state.current.locationId;

        // Boutons de compteur
        el('freq-incAdultsMini').disabled = !hasLocation;
        el('freq-decAdultsMini').disabled = !hasLocation;
        el('freq-incKidsMini').disabled = !hasLocation;
        el('freq-decKidsMini').disabled = !hasLocation;

        // Boutons d'action
        el('freq-btnResetMini').disabled = !hasLocation;
        el('freq-btnUpdateMini').disabled = !hasLocation;
        el('freq-btnCorrectionMini').disabled = !hasLocation;
        el('freq-btnFixLocationMini').disabled = !hasLocation;

        if (!hasLocation) {
            updateStatus('Sélectionnez un lieu');
        } else {
            updateStatus('Prêt');
        }
    }

    // Gestion du drag & drop
    function initDragAndDrop() {
        const appElement = el('freqAppMini');
        let isDragging = false;
        let startX, startY, initialX, initialY;

        // Charger la position sauvegardée
        const savedPosition = localStorage.getItem('freqAppPosition');
        if (savedPosition) {
            const { x, y } = JSON.parse(savedPosition);
            appElement.style.left = x + 'px';
            appElement.style.top = y + 'px';
            appElement.style.right = 'auto';
        }

        // La taille est désormais imposée par le design pour garantir que tout reste visible.
        localStorage.removeItem('freqAppSize');
        localStorage.removeItem('freqAppNormalSize');
        if (!state.isCompact) ensureMiniButtonsVisible();

        requestAnimationFrame(fitMiniToViewport);

        appElement.addEventListener("mousedown", dragStart);
        appElement.addEventListener("touchstart", dragStart);

        function dragStart(e) {
            const interactiveTarget = e.target.closest(
                'button, a, input, select, option, label, textarea'
            );

            if (interactiveTarget || window.matchMedia('(max-width: 575.98px)').matches) {
                return;
            }

            if (e.type === "touchstart") {
                startX = e.touches[0].clientX;
                startY = e.touches[0].clientY;
            } else {
                startX = e.clientX;
                startY = e.clientY;
            }

            const rect = appElement.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;

            isDragging = true;
            appElement.classList.add('dragging');

            document.addEventListener("mousemove", drag);
            document.addEventListener("touchmove", drag);
            document.addEventListener("mouseup", dragEnd);
            document.addEventListener("touchend", dragEnd);
        }

        function drag(e) {
            if (!isDragging) return;

            e.preventDefault();

            let currentX, currentY;
            if (e.type === "touchmove") {
                currentX = e.touches[0].clientX;
                currentY = e.touches[0].clientY;
            } else {
                currentX = e.clientX;
                currentY = e.clientY;
            }

            const deltaX = currentX - startX;
            const deltaY = currentY - startY;

            const newX = initialX + deltaX;
            const newY = initialY + deltaY;

            const maxX = window.innerWidth - appElement.offsetWidth;
            const maxY = window.innerHeight - appElement.offsetHeight;

            appElement.style.left = Math.max(0, Math.min(newX, maxX)) + 'px';
            appElement.style.top = Math.max(0, Math.min(newY, maxY)) + 'px';
            appElement.style.right = 'auto';
        }

        function dragEnd() {
            if (!isDragging) return;

            isDragging = false;
            appElement.classList.remove('dragging');

            const rect = appElement.getBoundingClientRect();
            localStorage.setItem('freqAppPosition', JSON.stringify({
                x: rect.left,
                y: rect.top
            }));

            document.removeEventListener("mousemove", drag);
            document.removeEventListener("touchmove", drag);
            document.removeEventListener("mouseup", dragEnd);
            document.removeEventListener("touchend", dragEnd);
        }
    }

    // Mode accordéon
    function initCompactMode() {
        const toggleBtn = el('freq-toggleCompact');
        const appElement = el('freqAppMini');

        const savedCompact = localStorage.getItem('freqAppCompact');
        if (savedCompact === 'true') {
            state.isCompact = true;
            appElement.classList.add('compact');
            toggleBtn.textContent = '+';
        }

        toggleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            state.isCompact = !state.isCompact;

            if (state.isCompact) {
                appElement.classList.add('compact');
                toggleBtn.textContent = '+';
            } else {
                appElement.classList.remove('compact');
                toggleBtn.textContent = '−';
                ensureMiniButtonsVisible();
            }

            localStorage.setItem('freqAppCompact', state.isCompact.toString());
            requestAnimationFrame(fitMiniToViewport);
        });
    }

    // Gestion de la correction horaire
    function initCorrectionModal() {
        const overlay = el('freq-correction-overlay');
        const modal = el('freq-correction-modal');
        const hoursInput = el('freq-correction-hours');
        const minutesInput = el('freq-correction-minutes');
        const preview = el('freq-correction-preview');
        const cancelBtn = el('freq-correction-cancel');
        const validateBtn = el('freq-correction-validate');
        const adultBtn = el('freq-correction-adult');
        const kidBtn = el('freq-correction-kid');
        const reasonInput = el('freq-correction-reason');

        // Ouvrir la modal
        el('freq-btnCorrectionMini').addEventListener('click', () => {
            // Réinitialiser la correction
            state.correction.adults = 0;
            state.correction.kids = 0;
            state.correction.hour = "12:00";
            state.correction.reason = "";
            reasonInput.value = '';

            // Mettre l'heure actuelle par défaut
            const now = new Date();
            hoursInput.value = now.getHours().toString().padStart(2, '0');
            minutesInput.value = now.getMinutes().toString().padStart(2, '0');

            updateCorrectionPreview();
            updateCorrectionValidateButton();

            overlay.classList.add('visible');
            modal.classList.add('visible');
        });

        // Fermer la modal
        function closeModal() {
            overlay.classList.remove('visible');
            modal.classList.remove('visible');
        }

        overlay.addEventListener('click', closeModal);
        cancelBtn.addEventListener('click', closeModal);

        // Mettre à jour l'aperçu quand l'heure change
        function updateCorrectionPreview() {
            const hours = hoursInput.value.padStart(2, '0');
            const minutes = minutesInput.value.padStart(2, '0');
            state.correction.hour = `${hours}:${minutes}`;
            preview.textContent = `Heure sélectionnée : ${hours}h${minutes}`;
        }

        function updateCorrectionValidateButton() {
            const total = state.correction.adults + state.correction.kids;
            state.correction.reason = reasonInput.value.trim();
            validateBtn.disabled = total === 0 || state.correction.reason.length < 3;
            validateBtn.textContent = total === 0 ? 'Valider (0)' : `Valider (${total}) — justification ${state.correction.reason.length < 3 ? 'requise' : 'prête'}`;
        }

        hoursInput.addEventListener('input', updateCorrectionPreview);
        minutesInput.addEventListener('input', updateCorrectionPreview);
        reasonInput.addEventListener('input', updateCorrectionValidateButton);

        // Gestion des boutons de comptage
        adultBtn.addEventListener('click', () => {
            state.correction.adults++;
            updateCorrectionValidateButton();
        });

        kidBtn.addEventListener('click', () => {
            state.correction.kids++;
            updateCorrectionValidateButton();
        });

        // Validation de la correction
        validateBtn.addEventListener('click', async () => {
            if (state.correction.adults + state.correction.kids === 0 || state.correction.reason.length < 3) return;

            try {
                updateStatus('Correction...');

                const date = el('freq-inputDateMini').value || getLocalDateString();
                const baseTimestamp = buildTimestampForLocalDateTime(date, state.correction.hour);
                await saveCountWithTimestamps(state.correction, baseTimestamp);
                updateCountsUI();

                updateStatus(`Correction enregistrée et justifiée : ${state.correction.adults} ${attendanceConfig.adultsLabel}, ${state.correction.kids} ${attendanceConfig.kidsLabel}`);
                setTimeout(() => updateStatus('Prêt'), 2000);

                closeModal();

            } catch (error) {
                updateStatus('Erreur correction');
            }
        });

        // Validation des inputs d'heure
        hoursInput.addEventListener('blur', () => {
            let value = parseInt(hoursInput.value) || 0;
            if (value < 0) value = 0;
            if (value > 23) value = 23;
            hoursInput.value = value.toString().padStart(2, '0');
            updateCorrectionPreview();
        });

        minutesInput.addEventListener('blur', () => {
            let value = parseInt(minutesInput.value) || 0;
            if (value < 0) value = 0;
            if (value > 59) value = 59;
            minutesInput.value = value.toString().padStart(2, '0');
            updateCorrectionPreview();
        });
    }

    function initActionsCollapse() {
        const toggle = el('freq-actionsToggleMini');
        const panel = el('freq-actionsPanelMini');
        if (!toggle || !panel) return;

        const STORAGE_KEY = 'freqMiniActionsExpanded';
        let expanded = localStorage.getItem(STORAGE_KEY) === 'true';

        function apply() {
            panel.classList.toggle('open', expanded);
            toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            localStorage.setItem(STORAGE_KEY, expanded ? 'true' : 'false');
            requestAnimationFrame(fitMiniToViewport);
        }

        // Par défaut : rétracté. Une ouverture volontaire est mémorisée sur ce poste.
        apply();

        toggle.addEventListener('click', function() {
            expanded = !expanded;
            apply();
        });
    }

    function initMiniUI() {
        el('freq-inputDateMini').value = state.current.date;
        el('freq-fix-from-mini').value = state.current.date;
        el('freq-fix-to-mini').value = state.current.date;

        loadLocations();
        initMiniEvents();
        initDragAndDrop();
        initCompactMode();
        initActionsCollapse();
        initCorrectionModal();
        initLocationFixModal();
        initDayRollover();
        setTimeout(function () {
            ensureMiniButtonsVisible();
            fitMiniToViewport();
        }, 0);

        window.addEventListener('resize', function () {
            ensureMiniButtonsVisible();
            fitMiniToViewport();
        });

        updateButtonsState();
        updateStatus('Initialisation...');
    }

    let observedLocalDay = getLocalDateString();
    let dayTimer = null;
    async function reconcileLocalDay() {
        const today = getLocalDateString();
        if (today === observedLocalDay) return false;
        const dateInput = el('freq-inputDateMini');
        const followedToday = !dateInput || !dateInput.value || dateInput.value === observedLocalDay;
        observedLocalDay = today;
        if (!followedToday || !dateInput) return false;
        dateInput.value = today;
        state.current.date = today;
        el('freq-fix-from-mini').value = today;
        el('freq-fix-to-mini').value = today;
        updateStatus('Nouvelle journée : chargement du ' + today);
        await loadCountsForSelectedDate();
        return true;
    }
    function initDayRollover() {
        if (dayTimer) return;
        dayTimer = window.setInterval(reconcileLocalDay, 30000);
        window.addEventListener('focus', reconcileLocalDay);
        document.addEventListener('visibilitychange', function() { if (!document.hidden) reconcileLocalDay(); });
        window.addEventListener('beforeunload', function() { if (dayTimer) window.clearInterval(dayTimer); }, {once:true});
    }

    function initMiniEvents() {
        el('freq-incAdultsMini').addEventListener('click', async () => {
            await handleIncrement('adults');
        });

        el('freq-decAdultsMini').addEventListener('click', async () => {
            await handleDecrement('adults');
        });

        el('freq-incKidsMini').addEventListener('click', async () => {
            await handleIncrement('kids');
        });

        el('freq-decKidsMini').addEventListener('click', async () => {
            await handleDecrement('kids');
        });

        el('freq-btnUpdateMini').addEventListener('click', async () => {
            updateStatus('MAJ...');
            await loadCountsForSelectedDate();
            updateStatus('MAJ OK');
            setTimeout(() => updateStatus('Prêt'), 2000);
        });

        el('freq-btnResetMini').addEventListener('click', () => {
            state.current.adults = 0;
            state.current.kids = 0;
            state.timestamps.adults = [];
            state.timestamps.kids = [];
            updateCountsUI();
            updateStatus('Reset OK');
            setTimeout(() => updateStatus('Prêt'), 2000);
        });

        el('freq-selectLocationMini').addEventListener('change', () => {
            state.current.locationId = el('freq-selectLocationMini').value;

            if (state.current.locationId) {
                localStorage.setItem('freqSelectedLocation', state.current.locationId);
            } else {
                localStorage.removeItem('freqSelectedLocation');
            }

            updateButtonsState();
            updateStatus('Chargement...');
            loadCountsForSelectedDate();
        });

        el('freq-inputDateMini').addEventListener('change', () => {
            state.current.date = el('freq-inputDateMini').value;
            updateStatus('Chargement...');
            loadCountsForSelectedDate();
        });
    }

    function initLocationFixModal() {
        const overlay = el('freq-location-fix-overlay');
        const modal = el('freq-location-fix-modal');

        function openModal() {
            el('freq-fix-from-mini').value = state.current.date || getLocalDateString();
            el('freq-fix-to-mini').value = state.current.date || getLocalDateString();
            overlay.classList.add('visible');
            modal.classList.add('visible');
        }

        function closeModal() {
            overlay.classList.remove('visible');
            modal.classList.remove('visible');
        }

        el('freq-btnFixLocationMini').addEventListener('click', openModal);
        el('freq-fix-cancel-mini').addEventListener('click', closeModal);
        overlay.addEventListener('click', closeModal);

        el('freq-fix-validate-mini').addEventListener('click', async () => {
            await applyLocationCorrectionMini();
            closeModal();
        });
    }

    // Authentification Koha : déclenchée sur les sites configurés.
    // On laisse Koha restaurer sa session via onAuthStateChanged, puis on ne
    // tente qu'une seule connexion anonyme si aucune session n'existe.
    let kohaSessionStarted = false;
    let miniUiInitialized = false;

    function initMiniUIOnce() {
        if (miniUiInitialized) return;
        miniUiInitialized = true;
        initMiniUI();
    }

    async function startKohaSession() {
        if(kohaSessionStarted)return;kohaSessionStarted=true;
        try{state.user=await getSession();updateStatus('Session Koha connectée');initMiniUIOnce();}
        catch(error){updateStatus('Session Koha indisponible');kohaSessionStarted=false;}
    }

    async function loadLocations() {
        try {
            updateStatus('Chargement lieux...');
            state.locations = [];
            const locationsSnapshot = await getDocs(collection(db, attendanceConfig.locationsCollection));

            locationsSnapshot.forEach((docSnap) => {
                const data = docSnap.data();
                state.locations.push({
                    id: docSnap.id,
                    name: data.name
                });
            });

            state.locations.sort((a, b) => a.name.localeCompare(b.name));
            renderLocations();

            if (state.locations.length > 0) {
                await loadCountsForSelectedDate();
            }

        } catch (error) {
            updateStatus('Erreur lieux');
        }
    }

    function renderLocations() {
        const selectLocation = el('freq-selectLocationMini');
        const fixOldSelect = el('freq-fix-old-location-mini');
        const fixNewSelect = el('freq-fix-new-location-mini');
        selectLocation.innerHTML = '<option value="">-- Sélectionnez un lieu --</option>';
        fixOldSelect.innerHTML = '<option value="">Lieu à corriger</option>';
        fixNewSelect.innerHTML = '<option value="">Lieu de destination</option>';

        state.locations.forEach(location => {
            const option = document.createElement('option');
            option.value = location.id;
            option.textContent = location.name;
            selectLocation.appendChild(option);

            const oldOption = document.createElement('option');
            oldOption.value = location.id;
            oldOption.textContent = location.name;
            fixOldSelect.appendChild(oldOption);

            const newOption = document.createElement('option');
            newOption.value = location.id;
            newOption.textContent = location.name;
            fixNewSelect.appendChild(newOption);
        });

        const savedLocation = localStorage.getItem('freqSelectedLocation') || attendanceConfig.defaultLocationId;
        if (savedLocation && state.locations.some(loc => loc.id === savedLocation)) {
            state.current.locationId = savedLocation;
            selectLocation.value = savedLocation;
            updateButtonsState();
            updateStatus('Lieu restauré');
        } else {
            state.current.locationId = null;
            selectLocation.value = '';
            updateButtonsState();
            updateStatus('Sélectionnez un lieu');
        }

        updateStatus(`${state.locations.length} lieux`);
    }

    async function applyLocationCorrectionMini() {
        const oldLocationId = el('freq-fix-old-location-mini').value;
        const newLocationId = el('freq-fix-new-location-mini').value;
        const from = el('freq-fix-from-mini').value;
        const to = el('freq-fix-to-mini').value;

        if (!oldLocationId || !newLocationId) {
            alert('Sélectionnez le lieu source et le nouveau lieu');
            return;
        }

        if (oldLocationId === newLocationId) {
            alert('Le lieu source et le nouveau lieu doivent être différents');
            return;
        }

        if (!from || !to) {
            alert('Sélectionnez une plage de dates');
            return;
        }

        if (from > to) {
            alert('La date de début doit être antérieure ou égale à la date de fin');
            return;
        }

        const oldLocationName = state.locations.find(l => l.id === oldLocationId)?.name || oldLocationId;
        const newLocationName = state.locations.find(l => l.id === newLocationId)?.name || newLocationId;

        if (!confirm(`Corriger les passages de "${oldLocationName}" vers "${newLocationName}" du ${from} au ${to} ?`)) {
            return;
        }

        try {
            updateStatus('Recherche des corrections...');
            const snapshot = await getDocs(collection(db, attendanceConfig.countsCollection));
            const docsToFix = [];

            snapshot.forEach(docSnap => {
                const data = docSnap.data();
                if (data.locationId === oldLocationId && data.date >= from && data.date <= to) {
                    docsToFix.push({ id: docSnap.id });
                }
            });

            if (docsToFix.length === 0) {
                updateStatus('Aucune entrée à corriger');
                alert('Aucune entrée trouvée pour ces critères');
                return;
            }

            updateStatus(`Correction de ${docsToFix.length} entrée(s)...`);

            for (const entry of docsToFix) {
                await updateDoc(doc(db, attendanceConfig.countsCollection, entry.id), {
                    locationId: newLocationId,
                    correctedFromLocationId: oldLocationId,
                    correctedAt: serverTimestamp(),
                    correctedBy: state.user ? state.user.uid : 'unknown',
                    updatedAt: serverTimestamp()
                });
            }

            if (state.current.locationId === oldLocationId) {
                state.current.locationId = newLocationId;
                el('freq-selectLocationMini').value = newLocationId;
                localStorage.setItem('freqSelectedLocation', newLocationId);
            }

            await loadCountsForSelectedDate();
            updateStatus(`${docsToFix.length} entrée(s) corrigée(s)`);
            alert(`${docsToFix.length} entrée(s) corrigée(s) avec succès`);
            setTimeout(() => updateStatus('Prêt'), 2000);
        } catch (error) {
            updateStatus('Erreur correction lieux');
            alert('Erreur lors de la correction des lieux: ' + error.message);
        }
    }

    function updateCountsUI() {
        el('freq-countAdultsMini').textContent = state.current.adults;
        el('freq-countKidsMini').textContent = state.current.kids;
        const total = el('freq-totalMini');
        if (total) total.textContent = Number(state.current.adults || 0) + Number(state.current.kids || 0);
    }

    async function mutateCounter(type, delta) {
        if (!state.current.locationId) {updateStatus('Sélectionnez un lieu');return false;}
        state.current.date=el('freq-inputDateMini').value || getLocalDateString();
        const currentData=await getCurrentCountFromDB();
        const result=await window.PMKAttendance.mutate({db,doc,runTransaction,serverTimestamp,configuration:attendanceConfig},{
            type,delta,locationId:state.current.locationId,date:state.current.date,
            existingId:currentData?.id,userId:state.user?.uid
        });
        state.current.adults=result.adults;state.current.kids=result.kids;
        state.timestamps.adults=result.adultTimestamps;state.timestamps.kids=result.kidTimestamps;
        updateCountsUI();return true;
    }

    async function handleIncrement(type) {
        try {
            updateStatus('Sync...');
            if (!await mutateCounter(type, 1)) return;
            updateStatus((type==='adults'?attendanceConfig.adultsLabel:attendanceConfig.kidsLabel)+' +'+attendanceConfig.step);
            setTimeout(() => updateStatus('Prêt'), 1500);
        } catch (error) {
            console.error('PMK139 — incrément', error);
            updateStatus('Erreur');
        }
    }

    async function handleDecrement(type) {
        try {
            updateStatus('Sync...');
            if (!await mutateCounter(type, -1)) return;
            updateStatus('Annulation OK');
            setTimeout(() => updateStatus('Prêt'), 1500);
        } catch (error) {
            console.error('PMK139 — décrément', error);
            updateStatus('Erreur');
        }
    }

    async function getCurrentCountFromDB() {
        if (!state.current.locationId || !state.current.date) return null;

        try {
            const countsQuery = query(
                collection(db, attendanceConfig.countsCollection),
                where('locationId', '==', state.current.locationId),
                where('date', '==', state.current.date)
            );

            const countsSnapshot = await getDocs(countsQuery);

            if (!countsSnapshot.empty) {
                const allDocs = countsSnapshot.docs;
                const primaryDoc = selectPrimaryCountDoc(allDocs);
                if (!primaryDoc) return null;
                return {
                    data: primaryDoc.data(),
                    id: primaryDoc.id,
                    duplicateCount: allDocs.length
                };
            }

            return null;
        } catch (error) {
            return null;
        }
    }

    async function loadCountsForSelectedDate() {
        if (!state.current.locationId || !state.current.date) return;

        try {
            updateStatus('Chargement...');
            const currentData = await getCurrentCountFromDB();

            if (currentData) {
                state.current.adults = currentData.data.adults || 0;
                state.current.kids = currentData.data.kids || 0;
                state.timestamps.adults = currentData.data.adultTimestamps || [];
                state.timestamps.kids = currentData.data.kidTimestamps || [];
                updateCountsUI();
                updateStatus('Données OK');
            } else {
                state.current.adults = 0;
                state.current.kids = 0;
                state.timestamps.adults = [];
                state.timestamps.kids = [];
                updateCountsUI();
                updateStatus('Nouveau');
            }

        } catch (error) {
            updateStatus('Erreur chargement');
        }
    }

    async function saveCountWithTimestamps(correction,timestamp) {
        if (!state.current.locationId) return;
        state.current.date=el('freq-inputDateMini').value || getLocalDateString();
        const currentData=await getCurrentCountFromDB();
        const result=await window.PMKAttendance.mutate({db,doc,runTransaction,serverTimestamp,configuration:attendanceConfig},{
            type:'correction',locationId:state.current.locationId,date:state.current.date,existingId:currentData?.id,userId:state.user?.uid,
            additions:{adults:correction.adults,kids:correction.kids,timestamp},reason:correction.reason
        });
        state.current.adults=result.adults;state.current.kids=result.kids;
        state.timestamps.adults=result.adultTimestamps;state.timestamps.kids=result.kidTimestamps;
    }

    // Initialisation pilotée par PMK 139.
    const bridge = window.PMKAttendanceMediabus;
    const module = document.getElementById('freqAppMini');
    if (module && bridge && bridge.enabled !== false && bridge.isMediabus()) {
        if (bridge.autoOpen !== false) module.classList.add('visible');
        requestAnimationFrame(fitMiniToViewport);
        startKohaSession();
        if (typeof bridge._markReady === 'function') bridge._markReady();
    }
    }

    async function ensureStarted() {
        if (started) return true;
        if (starting) return starting;
        if (!isMediabus() || config.enabled === false || config.miniEnabled===false) return false;

        starting = (async function() {
            injectShell();
            decorate(document.getElementById('freqAppMini'));
            await startLegacy();
            started = true;
            dispatchState('started');
            return true;
        })().catch(function(error) {
            console.error('PMK139 — compteur de fréquentation indisponible', error);
            dispatchState('error');
            return false;
        }).finally(function() { starting = null; });
        return starting;
    }

    async function open() {
        if (!isMediabus() || config.enabled === false || config.miniEnabled===false) return false;
        await ensureStarted();
        const node = document.getElementById('freqAppMini');
        if (!node) return false;
        node.classList.add('visible');
        dispatchState('open');
        return true;
    }

    function hideInternally(reason) {
        const node = document.getElementById('freqAppMini');
        if (!node) return false;
        node.classList.remove('visible');
        dispatchState(reason || 'hidden');
        return true;
    }

    function applyConfig(next) {
        config = normalizeConfiguration(next);
        resolveReady(bridge);
        decorate(document.getElementById('freqAppMini'));
        decorate(document.getElementById('freqApp'));
        bridge.enabled = config.enabled !== false;
        bridge.autoOpen = config.autoOpen !== false;
        if (!isMediabus() || config.miniEnabled===false) {hideInternally('outside-scope'); dispatchState('outside-scope'); return;}
        if (config.enabled === false) { hideInternally('disabled'); dispatchState('disabled'); return; }
        if (config.autoOpen !== false && !new URLSearchParams(location.search).has('pmk_page')) open();
        else dispatchState('configured');
    }

    function registerWithPMK() {
        if (!window.PMKConfig || registered) return false;
        registered = true;
        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 1,
            name: {fr:'Compteur de fréquentation',en:'Attendance counter'},
            description: {fr:'Un compteur commun aux vues flottante et pleine page : mêmes lieux, compteurs, réglages et historique. Les statistiques et exports restent disponibles dans la page dédiée.',en:'One counter shared by floating and full-page views, with the same locations, settings and history.'},
            category:{fr:'Circulation et accueil',en:'Circulation and front desk'},
            defaults:JSON.parse(JSON.stringify(DEFAULTS)),
            normalize:normalizeConfiguration,
            validate:cfg=>{
                try {document.querySelector(cfg.branchSelector || DEFAULTS.branchSelector)} catch(_){return {ok:false,message:'La cible du site de connexion est invalide.'}}
                if(![cfg.countsCollection,cfg.locationsCollection].every(value=>typeof value==='string' && value.trim() && !value.includes('/')))return {ok:false,message:'Chaque collection doit avoir un nom simple, sans barre oblique.'};
                return {ok:true};
            },
            schema:[{type:'section',id:'views',label:{fr:'Vues et périmètre',en:'Views and scope'},fields:[
                {key:'enabled',type:'boolean',label:'Activer le compteur'},
                {key:'miniEnabled',type:'boolean',label:'Proposer le compteur flottant'},
                {key:'pageEnabled',type:'boolean',label:'Activer la page de saisie et de rapports'},
                {key:'autoOpen',type:'boolean',label:'Ouvrir automatiquement le compteur flottant'},
                {key:'branchNames',type:'textarea',label:'Sites autorisés (vide = tous)',help:'Codes ou noms des sites de connexion, séparés par des virgules ou des lignes. Les lieux de comptage se gèrent dans la page du compteur.'},
                {key:'branchSelector',type:'elementPicker',allowManual:true,manualAlways:true,label:'Élément portant le site de connexion',pick:ctx=>{
                    const picker=window.PMKConfig.elementPicker;
                    picker?.register(MODULE_ID,{});
                    return picker?.pickForConfig ? picker.pickForConfig({moduleId:MODULE_ID,targetUrl:location.pathname,rootObject:ctx.rootObject,fieldPath:ctx.fieldPath,persistAfterPick:false}) : Promise.resolve(null);
                }}
            ]},{type:'section',id:'counting',label:'Saisie et présentation',fields:[
                {key:'title',type:'text',label:'Titre du compteur'},
                {key:'adultsLabel',type:'text',label:'Nom de la première catégorie (champ historique adults)'},
                {key:'kidsLabel',type:'text',label:'Nom de la seconde catégorie (champ historique kids)'},
                {key:'step',type:'number',min:1,max:100,label:'Nombre de personnes ajouté ou retiré par clic'},
                {key:'defaultLocationId',type:'text',label:'ID du lieu proposé par défaut',help:'Utilisé en l’absence de choix mémorisé sur ce navigateur. Aucun lieu ni comptage existant n’est renommé.'},
                {key:'miniWidth',type:'number',min:300,max:520,label:'Largeur initiale du compteur flottant (px)'},
                {key:'defaultCountedWeeks',type:'number',min:1,max:53,label:'Semaines comptées par an proposées pour un nouveau lieu'},
            ]},{type:'section',id:'storage',advanced:true,label:'Stockage commun aux deux vues',description:'Les valeurs initiales conservent le stockage historique. Un changement de projet ou de collection prend effet au prochain chargement et ne déplace aucune donnée.',fields:[
                {key:'countsCollection',type:'text',label:'Collection des comptages'},
                {key:'locationsCollection',type:'text',label:'Collection des lieux'}
            ]}]
        });
        window.PMKConfig.getConfig(MODULE_ID).then(applyConfig).catch(function() { applyConfig(DEFAULTS); });
        if (typeof window.PMKConfig.subscribe === 'function') unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
        return true;
    }

    const bridge = window.PMKAttendance = window.PMKAttendanceMediabus = {
        version: VERSION,
        moduleId: MODULE_ID,
        ready,
        getConfig:()=>JSON.parse(JSON.stringify(config)),
        mutate:mutateSharedCounter,
        decorate,
        inScope:isMediabus,
        hide:hideInternally,
        reportUrl: REPORT_URL,
        enabled: true,
        autoOpen: true,
        get available() { return isMediabus(); },
        isMediabus,
        isSuperlibrarian,
        open,
        openReport: function() {
            if (!isSuperlibrarian() || config.enabled===false || config.pageEnabled===false || !isMediabus()) return false;
            window.open(REPORT_URL, '_blank', 'noopener');
            return true;
        },
        _markReady: function() { started = true; dispatchState('legacy-ready'); }
    };

    function bootstrap() {
        if (!registerWithPMK()) {
            window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });
            let tries = 0;
            const timer = window.setInterval(function() {
                tries += 1;
                if (registerWithPMK() || tries >= 100) {
                    window.clearInterval(timer);
                    if (!registered) applyConfig(DEFAULTS);
                }
            }, 50);
        }
        dispatchState('bootstrap');
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    else bootstrap();

    window.addEventListener('beforeunload', function() {
        if (typeof unsubscribe === 'function') { try { unsubscribe(); } catch (_) {} }
    }, { once: true });
})(window, document);

;window.PMKNonPlugin.loaded.push("139-attendance-mediabus.js");
} catch (error) { window.PMKNonPlugin.errors.push("139-attendance-mediabus.js: "+error.message); console.error("[PMK] 139-attendance-mediabus.js",error); };
try {
/* ============================================================
   138-authorised-values-bulk-import.js
   PimpMyKoha — Import / export en masse de valeurs autorisées
   Version : 1.1.1-preplugin

   Fonctionnalités :
   - import texte : 1 libellé par ligne ;
   - import CSV collé ou depuis un fichier ;
   - si une ligne ne contient qu'un libellé, ce libellé devient aussi l'identifiant ;
   - CSV avec ou sans entête ;
   - détection automatique du séparateur (; , ou tabulation) ;
   - prévisualisation avant import ;
   - détection des doublons déjà présents dans Koha ;
   - détection des doublons dans l'import ;
   - contrôle longueur ID/libellés ;
   - contrôle des catégories « nombres uniquement » ;
   - import avec jeton CSRF natif Koha ;
   - rapport final et progression ;
   - export CSV d'une catégorie ;
   - export CSV de toutes les catégories et de toutes leurs valeurs autorisées.

   Pages : /cgi-bin/koha/admin/authorised_values.pl
   ============================================================ */
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK138AuthorisedValuesBulkImport) return;
    window.__PMK138AuthorisedValuesBulkImport = true;

    const MODULE_ID = "authorised-values-bulk-import";
    const MODULE_VERSION = "1.1.1-preplugin";
    const PAGE_PATH = "/cgi-bin/koha/admin/authorised_values.pl";
    const DIALOG_ID = "pmk138-av-import-dialog";
    const BUTTON_ID = "pmk138-av-import-button";
    const STYLE_ID = "pmk138-av-import-style";
    const MAX_PARALLEL = 4;

    const isFrench = /^fr\b/i.test(document.documentElement.lang || navigator.language || "fr");

    const I18N = {
        fr: {
            button: "Importer des valeurs",
            exportButton: "Exporter",
            exportTitle: "Exporter les valeurs autorisées",
            exportCurrent: "Exporter la catégorie affichée",
            exportAll: "Exporter toutes les catégories",
            exporting: "Export en cours…",
            exportDone: "Export terminé.",
            exportNoCurrent: "Aucune catégorie n’est actuellement affichée.",
            exportError: "Impossible d’exporter les valeurs autorisées.",
            exportPrepareCurrent: "Préparer la catégorie affichée",
            exportPrepareAll: "Préparer toutes les catégories",
            exportDownload: "Télécharger le CSV",
            exportReady: "Le fichier est prêt.",
            exportRows: "valeurs exportées",
            exportWorking: "Préparation de l’export…",
            exportClose: "Fermer",
            title: "Import en masse de valeurs autorisées",
            category: "Catégorie cible",
            loadingCategories: "Chargement des catégories…",
            source: "Source",
            linesMode: "1 valeur par ligne",
            csvMode: "CSV",
            content: "Valeurs à importer",
            linesHint: "Une ligne = un libellé. Le libellé est également utilisé comme identifiant.",
            csvHint: "CSV avec ou sans entête. Colonnes possibles : id, libelle, libelle_opac. Sans entête : 1 colonne = libellé ; 2 colonnes = id + libellé ; 3 colonnes = id + libellé + libellé OPAC.",
            file: "Charger un fichier CSV",
            copyOpac: "Copier le libellé dans le libellé OPAC lorsqu'il est vide",
            preview: "Prévisualiser",
            import: "Importer",
            close: "Fermer",
            cancel: "Annuler",
            refresh: "Actualiser la catégorie",
            previewTitle: "Prévisualisation",
            status: "État",
            id: "Identifiant",
            label: "Libellé",
            opac: "Libellé OPAC",
            ready: "Prête",
            existing: "Existe déjà",
            duplicateInput: "Doublon dans l'import",
            invalid: "Erreur",
            empty: "Aucune valeur à importer.",
            chooseCategory: "Choisissez une catégorie.",
            preparing: "Analyse en cours…",
            importing: "Import en cours…",
            done: "Import terminé.",
            success: "Ajoutée",
            error: "Erreur d'import",
            summaryReady: "à importer",
            summaryExisting: "déjà présentes",
            existingTitle: "Déjà présentes dans Koha",
            existingIntro: "Ces valeurs existent déjà dans la catégorie et ne seront pas réimportées.",
            noExisting: "Aucune valeur déjà existante détectée.",
            summaryDuplicate: "doublons dans l'import",
            summaryErrors: "erreurs",
            imported: "ajoutées",
            failed: "en erreur",
            idTooLong: "Identifiant supérieur à 80 caractères",
            labelTooLong: "Libellé supérieur à 200 caractères",
            opacTooLong: "Libellé OPAC supérieur à 200 caractères",
            invalidInteger: "Cette catégorie n'accepte que des nombres entiers de -128 à 127",
            emptyId: "Identifiant vide",
            serverError: "Koha a refusé l'ajout",
            networkError: "Erreur réseau",
            csvReadError: "Impossible de lire ce fichier.",
            noCategory: "Aucune catégorie de valeurs autorisées disponible.",
            invalidPage: "Ce module fonctionne uniquement sur l'administration des valeurs autorisées.",
            sourceChanged: "La source a changé : relancez la prévisualisation avant d'importer.",
            categoryChanged: "La catégorie a changé : relancez la prévisualisation avant d'importer.",
            exampleLines: "Roman\nPolicier\nScience-fiction",
            exampleCsv: "id;libelle;libelle_opac\nROM;Roman;Roman\nPOL;Policier;Policier\nSF;Science-fiction;Science-fiction"
        },
        en: {
            button: "Import values",
            exportButton: "Export",
            exportTitle: "Export authorised values",
            exportCurrent: "Export displayed category",
            exportAll: "Export all categories",
            exporting: "Exporting…",
            exportDone: "Export complete.",
            exportNoCurrent: "No category is currently displayed.",
            exportError: "Unable to export authorised values.",
            exportPrepareCurrent: "Prepare displayed category",
            exportPrepareAll: "Prepare all categories",
            exportDownload: "Download CSV",
            exportReady: "The file is ready.",
            exportRows: "exported values",
            exportWorking: "Preparing export…",
            exportClose: "Close",
            title: "Bulk import authorised values",
            category: "Target category",
            loadingCategories: "Loading categories…",
            source: "Source",
            linesMode: "1 value per line",
            csvMode: "CSV",
            content: "Values to import",
            linesHint: "One line = one label. The label is also used as the identifier.",
            csvHint: "CSV with or without a header. Supported columns: id, label, opac_label. Without a header: 1 column = label; 2 columns = id + label; 3 columns = id + label + OPAC label.",
            file: "Load CSV file",
            copyOpac: "Copy label to OPAC label when empty",
            preview: "Preview",
            import: "Import",
            close: "Close",
            cancel: "Cancel",
            refresh: "Refresh category",
            previewTitle: "Preview",
            status: "Status",
            id: "Identifier",
            label: "Label",
            opac: "OPAC label",
            ready: "Ready",
            existing: "Already exists",
            duplicateInput: "Duplicate in import",
            invalid: "Error",
            empty: "No value to import.",
            chooseCategory: "Choose a category.",
            preparing: "Analysing…",
            importing: "Importing…",
            done: "Import complete.",
            success: "Added",
            error: "Import error",
            summaryReady: "to import",
            summaryExisting: "already present",
            existingTitle: "Already present in Koha",
            existingIntro: "These values already exist in the category and will not be imported again.",
            noExisting: "No existing value detected.",
            summaryDuplicate: "duplicates in import",
            summaryErrors: "errors",
            imported: "added",
            failed: "failed",
            idTooLong: "Identifier is longer than 80 characters",
            labelTooLong: "Label is longer than 200 characters",
            opacTooLong: "OPAC label is longer than 200 characters",
            invalidInteger: "This category only accepts integers from -128 to 127",
            emptyId: "Empty identifier",
            serverError: "Koha rejected the value",
            networkError: "Network error",
            csvReadError: "Unable to read this file.",
            noCategory: "No authorised value category is available.",
            invalidPage: "This module only runs on the authorised values administration page.",
            sourceChanged: "The source changed: run the preview again before importing.",
            categoryChanged: "The category changed: run the preview again before importing.",
            exampleLines: "Novel\nCrime\nScience fiction",
            exampleCsv: "id;label;opac_label\nNOV;Novel;Novel\nCRI;Crime;Crime\nSF;Science fiction;Science fiction"
        }
    };

    const t = I18N[isFrench ? "fr" : "en"];

    const state = {
        categories: [],
        preview: [],
        context: null,
        previewFingerprint: "",
        importing: false
    };

    function onTargetPage() {
        return window.location.pathname === PAGE_PATH;
    }

    function normalizeSpace(value) {
        return String(value == null ? "" : value)
            .replace(/^\uFEFF/, "")
            .replace(/\r/g, "")
            .trim();
    }

    function normalizeKey(value) {
        return normalizeSpace(value).toLocaleLowerCase();
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function css() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #${DIALOG_ID}[hidden],
            #pmk138-export-dialog[hidden] { display:none !important; }
            #pmk138-export-dialog {
                position:fixed; inset:0; z-index:100000;
                background:rgba(0,0,0,.45);
                display:flex; align-items:flex-start; justify-content:center;
                padding:4vh 16px; overflow:auto;
            }
            #pmk138-export-dialog .pmk138-panel {
                width:min(720px, 100%); background:#fff; border-radius:8px;
                box-shadow:0 15px 45px rgba(0,0,0,.28); overflow:hidden;
            }
            #pmk138-export-dialog .pmk138-head {
                display:flex; align-items:center; justify-content:space-between;
                gap:1rem; padding:14px 18px; border-bottom:1px solid #ddd;
            }
            #pmk138-export-dialog .pmk138-head h2 { margin:0; font-size:1.25rem; }
            #pmk138-export-dialog .pmk138-x {
                border:0; background:transparent; font-size:1.6rem; line-height:1;
                cursor:pointer; padding:0 4px;
            }
            #pmk138-export-dialog .pmk138-body { padding:18px; }
            #pmk138-export-dialog .pmk138-actions {
                display:flex; flex-wrap:wrap; gap:8px; margin-top:14px;
            }
            #pmk138-export-dialog .pmk138-footer {
                display:flex; justify-content:flex-end; gap:8px;
                padding:12px 18px; border-top:1px solid #ddd; background:#fafafa;
            }
            #pmk138-export-dialog .pmk138-progress-bar {
                height:12px; background:#eee; border-radius:999px; overflow:hidden;
            }
            #pmk138-export-dialog .pmk138-progress-bar > span {
                display:block; height:100%; width:0%; background:#3c763d; transition:width .15s linear;
            }
            #pmk138-export-dialog .pmk138-hint { color:#666; font-size:.92em; margin-top:5px; }

            #${DIALOG_ID}[hidden] { display:none !important; }
            #${DIALOG_ID} {
                position:fixed; inset:0; z-index:100000;
                background:rgba(0,0,0,.45);
                display:flex; align-items:flex-start; justify-content:center;
                padding:4vh 16px; overflow:auto;
            }
            #${DIALOG_ID} .pmk138-panel {
                width:min(1180px, 100%); background:#fff; border-radius:8px;
                box-shadow:0 15px 45px rgba(0,0,0,.28); overflow:hidden;
            }
            #${DIALOG_ID} .pmk138-head {
                display:flex; align-items:center; justify-content:space-between;
                gap:1rem; padding:14px 18px; border-bottom:1px solid #ddd;
            }
            #${DIALOG_ID} .pmk138-head h2 { margin:0; font-size:1.25rem; }
            #${DIALOG_ID} .pmk138-x {
                border:0; background:transparent; font-size:1.6rem; line-height:1;
                cursor:pointer; padding:0 4px;
            }
            #${DIALOG_ID} .pmk138-body { padding:18px; }
            #${DIALOG_ID} .pmk138-grid {
                display:grid; grid-template-columns:minmax(220px, 1fr) minmax(0, 2fr);
                gap:16px;
            }
            #${DIALOG_ID} .pmk138-field { margin-bottom:14px; }
            #${DIALOG_ID} .pmk138-field > label,
            #${DIALOG_ID} .pmk138-field > .pmk138-label {
                display:block; font-weight:600; margin-bottom:6px;
            }
            #${DIALOG_ID} select,
            #${DIALOG_ID} textarea,
            #${DIALOG_ID} input[type="file"] { width:100%; max-width:100%; }
            #${DIALOG_ID} textarea { min-height:210px; resize:vertical; font-family:monospace; }
            #${DIALOG_ID} .pmk138-modes { display:flex; flex-wrap:wrap; gap:12px; }
            #${DIALOG_ID} .pmk138-hint { color:#666; font-size:.92em; margin-top:5px; }
            #${DIALOG_ID} .pmk138-actions {
                display:flex; flex-wrap:wrap; align-items:center; gap:8px;
                margin-top:14px;
            }
            #${DIALOG_ID} .pmk138-summary { display:flex; flex-wrap:wrap; gap:8px; margin:14px 0; }
            #${DIALOG_ID} .pmk138-chip {
                display:inline-flex; align-items:center; border:1px solid #d9d9d9;
                border-radius:999px; padding:3px 10px; background:#f7f7f7;
            }
            #${DIALOG_ID} .pmk138-preview-wrap { overflow:auto; max-height:42vh; border:1px solid #ddd; }
            #${DIALOG_ID} table { width:100%; margin:0; border-collapse:collapse; }
            #${DIALOG_ID} th,
            #${DIALOG_ID} td { padding:7px 9px; border-bottom:1px solid #e7e7e7; vertical-align:top; }
            #${DIALOG_ID} thead th { position:sticky; top:0; background:#f5f5f5; z-index:1; }
            #${DIALOG_ID} .pmk138-status-ready { color:#1e6b34; font-weight:600; }
            #${DIALOG_ID} .pmk138-status-skip { color:#8a5b00; font-weight:600; }
            #${DIALOG_ID} .pmk138-status-error { color:#b42318; font-weight:600; }
            #${DIALOG_ID} .pmk138-progress { margin-top:14px; }
            #${DIALOG_ID} .pmk138-progress-bar { height:12px; background:#eee; border-radius:999px; overflow:hidden; }
            #${DIALOG_ID} .pmk138-progress-bar > span { display:block; height:100%; width:0%; background:#3c763d; transition:width .15s linear; }
            #${DIALOG_ID} .pmk138-log { margin-top:8px; max-height:120px; overflow:auto; font-size:.92em; }
            #${DIALOG_ID} .pmk138-footer {
                display:flex; justify-content:flex-end; flex-wrap:wrap; gap:8px;
                padding:12px 18px; border-top:1px solid #ddd; background:#fafafa;
            }
            #${DIALOG_ID} .pmk138-message { margin:10px 0; }
            @media (max-width: 780px) {
                #${DIALOG_ID} { padding:0; }
                #${DIALOG_ID} .pmk138-panel { min-height:100vh; border-radius:0; }
                #${DIALOG_ID} .pmk138-grid { grid-template-columns:1fr; }
                #${DIALOG_ID} .pmk138-preview-wrap { max-height:none; }
            }
        `;
        document.head.appendChild(style);
    }

    function getDialog() {
        return document.getElementById(DIALOG_ID);
    }

    function buildDialog() {
        if (getDialog()) return getDialog();
        css();
        const root = document.createElement("div");
        root.id = DIALOG_ID;
        root.hidden = true;
        root.setAttribute("role", "dialog");
        root.setAttribute("aria-modal", "true");
        root.setAttribute("aria-labelledby", "pmk138-title");
        root.innerHTML = `
            <div class="pmk138-panel">
                <div class="pmk138-head">
                    <h2 id="pmk138-title"><i class="fa fa-file-import" aria-hidden="true"></i> ${escapeHtml(t.title)}</h2>
                    <button type="button" class="pmk138-x" id="pmk138-close-x" aria-label="${escapeHtml(t.close)}">&times;</button>
                </div>
                <div class="pmk138-body">
                    <div id="pmk138-message" class="pmk138-message" hidden></div>
                    <div class="pmk138-grid">
                        <div>
                            <div class="pmk138-field">
                                <label for="pmk138-category">${escapeHtml(t.category)}</label>
                                <select id="pmk138-category"><option value="">${escapeHtml(t.loadingCategories)}</option></select>
                            </div>
                            <div class="pmk138-field">
                                <span class="pmk138-label">${escapeHtml(t.source)}</span>
                                <div class="pmk138-modes">
                                    <label><input type="radio" name="pmk138-mode" value="lines" checked> ${escapeHtml(t.linesMode)}</label>
                                    <label><input type="radio" name="pmk138-mode" value="csv"> ${escapeHtml(t.csvMode)}</label>
                                </div>
                            </div>
                            <div class="pmk138-field" id="pmk138-file-field" hidden>
                                <label for="pmk138-file">${escapeHtml(t.file)}</label>
                                <input type="file" id="pmk138-file" accept=".csv,text/csv,text/plain">
                            </div>
                            <div class="pmk138-field">
                                <label><input type="checkbox" id="pmk138-copy-opac"> ${escapeHtml(t.copyOpac)}</label>
                            </div>
                        </div>
                        <div>
                            <div class="pmk138-field">
                                <label for="pmk138-source">${escapeHtml(t.content)}</label>
                                <textarea id="pmk138-source" spellcheck="false" placeholder="${escapeHtml(t.exampleLines)}"></textarea>
                                <div class="pmk138-hint" id="pmk138-source-hint">${escapeHtml(t.linesHint)}</div>
                            </div>
                        </div>
                    </div>
                    <div class="pmk138-actions">
                        <button type="button" class="btn btn-primary" id="pmk138-preview-btn"><i class="fa fa-eye" aria-hidden="true"></i> ${escapeHtml(t.preview)}</button>
                        <button type="button" class="btn btn-success" id="pmk138-import-btn" disabled><i class="fa fa-file-import" aria-hidden="true"></i> ${escapeHtml(t.import)}</button>
                    </div>
                    <div id="pmk138-preview-section" hidden>
                        <h3>${escapeHtml(t.previewTitle)}</h3>
                        <div id="pmk138-summary" class="pmk138-summary"></div>

                        <div id="pmk138-existing-section" class="alert alert-warning" hidden>
                            <h4 style="margin-top:0">
                                <i class="fa fa-triangle-exclamation" aria-hidden="true"></i>
                                ${escapeHtml(t.existingTitle)}
                            </h4>
                            <p>${escapeHtml(t.existingIntro)}</p>
                            <div class="pmk138-preview-wrap" style="max-height:220px;background:#fff">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>${escapeHtml(t.id)}</th>
                                            <th>${escapeHtml(t.label)}</th>
                                            <th>${escapeHtml(t.opac)}</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pmk138-existing-body"></tbody>
                                </table>
                            </div>
                        </div>

                        <div class="pmk138-preview-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>${escapeHtml(t.status)}</th>
                                        <th>${escapeHtml(t.id)}</th>
                                        <th>${escapeHtml(t.label)}</th>
                                        <th>${escapeHtml(t.opac)}</th>
                                    </tr>
                                </thead>
                                <tbody id="pmk138-preview-body"></tbody>
                            </table>
                        </div>
                    </div>
                    <div id="pmk138-progress" class="pmk138-progress" hidden>
                        <div class="pmk138-progress-bar"><span id="pmk138-progress-bar"></span></div>
                        <div id="pmk138-progress-text" class="pmk138-hint"></div>
                        <div id="pmk138-log" class="pmk138-log"></div>
                    </div>
                </div>
                <div class="pmk138-footer">
                    <button type="button" class="btn btn-default" id="pmk138-refresh" hidden><i class="fa fa-rotate" aria-hidden="true"></i> ${escapeHtml(t.refresh)}</button>
                    <button type="button" class="btn btn-default" id="pmk138-close">${escapeHtml(t.close)}</button>
                </div>
            </div>
        `;
        document.body.appendChild(root);
        bindDialogEvents(root);
        return root;
    }

    function showMessage(message, kind) {
        const el = document.getElementById("pmk138-message");
        if (!el) return;
        el.hidden = !message;
        el.className = "pmk138-message alert " + (kind === "error" ? "alert-danger" : kind === "success" ? "alert-success" : "alert-info");
        el.textContent = message || "";
    }

    function getMode() {
        const checked = document.querySelector('input[name="pmk138-mode"]:checked');
        return checked ? checked.value : "lines";
    }

    function fingerprint() {
        const category = document.getElementById("pmk138-category")?.value || "";
        const source = document.getElementById("pmk138-source")?.value || "";
        const mode = getMode();
        const copyOpac = !!document.getElementById("pmk138-copy-opac")?.checked;
        return JSON.stringify([category, mode, copyOpac, source]);
    }

    function invalidatePreview(message) {
        state.preview = [];
        state.context = null;
        state.previewFingerprint = "";
        const btn = document.getElementById("pmk138-import-btn");
        if (btn) btn.disabled = true;
        const section = document.getElementById("pmk138-preview-section");
        if (section) section.hidden = true;
        const progress = document.getElementById("pmk138-progress");
        if (progress) progress.hidden = true;
        const existingSection = document.getElementById("pmk138-existing-section");
        if (existingSection) existingSection.hidden = true;
        const refresh = document.getElementById("pmk138-refresh");
        if (refresh) refresh.hidden = true;
        if (message) showMessage(message, "info");
    }

    function bindDialogEvents(root) {
        const close = () => {
            if (state.importing) return;
            root.hidden = true;
            document.body.style.overflow = "";
        };
        root.querySelector("#pmk138-close-x").addEventListener("click", close);
        root.querySelector("#pmk138-close").addEventListener("click", close);
        root.addEventListener("click", function (event) {
            if (event.target === root) close();
        });
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && !root.hidden) close();
        });

        root.querySelectorAll('input[name="pmk138-mode"]').forEach(function (radio) {
            radio.addEventListener("change", function () {
                const csv = getMode() === "csv";
                root.querySelector("#pmk138-file-field").hidden = !csv;
                root.querySelector("#pmk138-source-hint").textContent = csv ? t.csvHint : t.linesHint;
                root.querySelector("#pmk138-source").placeholder = csv ? t.exampleCsv : t.exampleLines;
                invalidatePreview();
            });
        });

        root.querySelector("#pmk138-category").addEventListener("change", function () {
            invalidatePreview(t.categoryChanged);
        });
        root.querySelector("#pmk138-source").addEventListener("input", function () {
            invalidatePreview();
        });
        root.querySelector("#pmk138-copy-opac").addEventListener("change", function () {
            invalidatePreview();
        });

        root.querySelector("#pmk138-file").addEventListener("change", async function () {
            const file = this.files && this.files[0];
            if (!file) return;
            try {
                const text = await file.text();
                root.querySelector("#pmk138-source").value = text;
                invalidatePreview();
            } catch (error) {
                showMessage(t.csvReadError, "error");
            }
        });

        root.querySelector("#pmk138-preview-btn").addEventListener("click", previewImport);
        root.querySelector("#pmk138-import-btn").addEventListener("click", executeImport);
        root.querySelector("#pmk138-refresh").addEventListener("click", function () {
            const category = root.querySelector("#pmk138-category").value;
            if (!category) return;
            window.location.href = PAGE_PATH + "?searchfield=" + encodeURIComponent(category);
        });
    }

    function getCategoriesFromDocument(doc) {
        const set = new Set();
        const select = doc.querySelector("#category_search");
        if (select) {
            Array.from(select.options).forEach(function (option) {
                const value = normalizeSpace(option.value);
                if (value) set.add(value);
            });
        }
        doc.querySelectorAll('a[href*="authorised_values.pl?searchfield="]').forEach(function (a) {
            try {
                const url = new URL(a.getAttribute("href"), window.location.origin);
                const value = normalizeSpace(url.searchParams.get("searchfield"));
                if (value) set.add(value);
            } catch (error) { /* noop */ }
        });
        return Array.from(set).sort(function (a, b) { return a.localeCompare(b, undefined, { sensitivity: "base" }); });
    }

    async function loadCategories() {
        let categories = getCategoriesFromDocument(document);
        if (!categories.length) {
            try {
                const response = await fetch(PAGE_PATH, { credentials: "same-origin", cache: "no-store" });
                const html = await response.text();
                const doc = new DOMParser().parseFromString(html, "text/html");
                categories = getCategoriesFromDocument(doc);
            } catch (error) { /* handled below */ }
        }
        state.categories = categories;
        return categories;
    }

    async function openDialog() {
        const root = buildDialog();
        root.hidden = false;
        document.body.style.overflow = "hidden";
        showMessage("", "info");
        const select = root.querySelector("#pmk138-category");
        select.innerHTML = `<option value="">${escapeHtml(t.loadingCategories)}</option>`;
        const categories = await loadCategories();
        if (!categories.length) {
            select.innerHTML = `<option value="">${escapeHtml(t.noCategory)}</option>`;
            showMessage(t.noCategory, "error");
            return;
        }
        select.innerHTML = '<option value=""></option>' + categories.map(function (category) {
            return `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`;
        }).join("");

        const current = new URLSearchParams(window.location.search).get("searchfield");
        if (current && categories.includes(current)) select.value = current;
    }

    function detectDelimiter(text) {
        const first = String(text || "").split(/\r?\n/).find(function (line) { return line.trim(); }) || "";
        const candidates = [";", "\t", ","];
        let best = ";";
        let bestCount = -1;
        candidates.forEach(function (delimiter) {
            let count = 0;
            let quoted = false;
            for (let i = 0; i < first.length; i += 1) {
                const ch = first[i];
                if (ch === '"') {
                    if (quoted && first[i + 1] === '"') { i += 1; continue; }
                    quoted = !quoted;
                } else if (!quoted && ch === delimiter) {
                    count += 1;
                }
            }
            if (count > bestCount) {
                best = delimiter;
                bestCount = count;
            }
        });
        return bestCount > 0 ? best : null;
    }

    function parseDelimited(text, delimiter) {
        const rows = [];
        let row = [];
        let field = "";
        let quoted = false;
        const src = String(text == null ? "" : text).replace(/^\uFEFF/, "");

        for (let i = 0; i < src.length; i += 1) {
            const ch = src[i];
            if (quoted) {
                if (ch === '"') {
                    if (src[i + 1] === '"') {
                        field += '"';
                        i += 1;
                    } else {
                        quoted = false;
                    }
                } else {
                    field += ch;
                }
            } else if (ch === '"') {
                quoted = true;
            } else if (ch === delimiter) {
                row.push(field);
                field = "";
            } else if (ch === "\n") {
                row.push(field.replace(/\r$/, ""));
                rows.push(row);
                row = [];
                field = "";
            } else {
                field += ch;
            }
        }
        row.push(field.replace(/\r$/, ""));
        rows.push(row);
        return rows.filter(function (r) { return r.some(function (cell) { return normalizeSpace(cell) !== ""; }); });
    }

    function headerIndex(header, names) {
        const normalized = header.map(function (cell) {
            return normalizeKey(cell)
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "")
                .replace(/[\s-]+/g, "_");
        });
        for (let i = 0; i < normalized.length; i += 1) {
            if (names.includes(normalized[i])) return i;
        }
        return -1;
    }

    function parseCsv(text) {
        const delimiter = detectDelimiter(text);
        if (!delimiter) {
            const values = String(text || "").split(/\r?\n/)
                .map(normalizeSpace)
                .filter(Boolean);
            if (!values.length) return [];
            const first = normalizeKey(values[0])
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "")
                .replace(/[\s-]+/g, "_");
            const singleColumnHeaders = [
                "label", "lib", "libelle", "description", "designation",
                "id", "code", "value", "valeur", "authorised_value",
                "authorized_value", "identifiant"
            ];
            const data = singleColumnHeaders.includes(first) ? values.slice(1) : values;
            return data.map(function (label) { return { id: label, label: label, opac: "" }; });
        }

        const rows = parseDelimited(text, delimiter);
        if (!rows.length) return [];
        const header = rows[0];
        const idIdx = headerIndex(header, ["id", "code", "value", "valeur", "authorised_value", "authorized_value", "identifiant"]);
        const labelIdx = headerIndex(header, ["label", "lib", "libelle", "description", "designation"]);
        const opacIdx = headerIndex(header, ["lib_opac", "opac", "opac_label", "label_opac", "libelle_opac", "description_opac"]);
        const hasHeader = idIdx >= 0 || labelIdx >= 0 || opacIdx >= 0;
        const data = hasHeader ? rows.slice(1) : rows;

        return data.map(function (row) {
            let id = "";
            let label = "";
            let opac = "";
            if (hasHeader) {
                if (idIdx >= 0) id = normalizeSpace(row[idIdx]);
                if (labelIdx >= 0) label = normalizeSpace(row[labelIdx]);
                if (opacIdx >= 0) opac = normalizeSpace(row[opacIdx]);
                if (!label && id) label = id;
                if (!id && label) id = label;
            } else if (row.length <= 1) {
                label = normalizeSpace(row[0]);
                id = label;
            } else {
                id = normalizeSpace(row[0]);
                label = normalizeSpace(row[1]);
                opac = normalizeSpace(row[2]);
                if (!label && id) label = id;
                if (!id && label) id = label;
            }
            return { id: id, label: label, opac: opac };
        }).filter(function (item) {
            return item.id || item.label || item.opac;
        });
    }

    function parseLines(text) {
        return String(text || "")
            .split(/\r?\n/)
            .map(normalizeSpace)
            .filter(Boolean)
            .map(function (label) {
                return { id: label, label: label, opac: "" };
            });
    }

    async function getCategoryContext(category) {
        const listUrl = PAGE_PATH + "?searchfield=" + encodeURIComponent(category);
        const formUrl = PAGE_PATH + "?op=add_form&category=" + encodeURIComponent(category);
        const [listResponse, formResponse] = await Promise.all([
            fetch(listUrl, { credentials: "same-origin", cache: "no-store" }),
            fetch(formUrl, { credentials: "same-origin", cache: "no-store" })
        ]);
        if (!listResponse.ok || !formResponse.ok) throw new Error("HTTP");
        const [listHtml, formHtml] = await Promise.all([listResponse.text(), formResponse.text()]);
        const listDoc = new DOMParser().parseFromString(listHtml, "text/html");
        const formDoc = new DOMParser().parseFromString(formHtml, "text/html");

        const existing = new Set();
        listDoc.querySelectorAll("#categoriest tbody tr").forEach(function (tr) {
            const first = tr.querySelector("td:first-child");
            if (first) {
                const value = normalizeSpace(first.textContent);
                if (value) existing.add(normalizeKey(value));
            }
        });

        const csrf = formDoc.querySelector('input[name="csrf_token"]')?.value
            || listDoc.querySelector('input[name="csrf_token"]')?.value
            || "";
        if (!csrf) throw new Error("CSRF");

        const idInput = formDoc.querySelector('#authorised_value[name="authorised_value"]');
        const integerOnly = !!(idInput && (idInput.getAttribute("inputmode") === "numeric" || idInput.hasAttribute("min")));

        return {
            category: category,
            existing: existing,
            csrf: csrf,
            integerOnly: integerOnly
        };
    }

    function validateItem(item, context, seen, copyOpac) {
        const result = {
            id: normalizeSpace(item.id),
            label: normalizeSpace(item.label),
            opac: normalizeSpace(item.opac),
            status: "ready",
            reason: ""
        };
        if (!result.label && result.id) result.label = result.id;
        if (!result.id && result.label) result.id = result.label;
        if (copyOpac && !result.opac) result.opac = result.label;

        if (!result.id) {
            result.status = "error";
            result.reason = t.emptyId;
            return result;
        }
        if (result.id.length > 80) {
            result.status = "error";
            result.reason = t.idTooLong;
            return result;
        }
        if (result.label.length > 200) {
            result.status = "error";
            result.reason = t.labelTooLong;
            return result;
        }
        if (result.opac.length > 200) {
            result.status = "error";
            result.reason = t.opacTooLong;
            return result;
        }
        if (context.integerOnly) {
            if (!/^-?\d+$/.test(result.id) || Number(result.id) < -128 || Number(result.id) > 127) {
                result.status = "error";
                result.reason = t.invalidInteger;
                return result;
            }
        }

        const key = normalizeKey(result.id);
        if (context.existing.has(key)) {
            result.status = "existing";
            result.reason = t.existing;
            return result;
        }
        if (seen.has(key)) {
            result.status = "duplicate";
            result.reason = t.duplicateInput;
            return result;
        }
        seen.add(key);
        return result;
    }

    function countPreview(rows) {
        return rows.reduce(function (acc, row) {
            acc[row.status] = (acc[row.status] || 0) + 1;
            return acc;
        }, { ready: 0, existing: 0, duplicate: 0, error: 0 });
    }

    function statusMarkup(row) {
        if (row.status === "ready") return `<span class="pmk138-status-ready">✓ ${escapeHtml(t.ready)}</span>`;
        if (row.status === "existing") return `<span class="pmk138-status-skip">↷ ${escapeHtml(t.existing)}</span>`;
        if (row.status === "duplicate") return `<span class="pmk138-status-skip">↷ ${escapeHtml(t.duplicateInput)}</span>`;
        return `<span class="pmk138-status-error">✕ ${escapeHtml(row.reason || t.invalid)}</span>`;
    }

    function renderPreview(rows) {
        const counts = countPreview(rows);
        const body = document.getElementById("pmk138-preview-body");

        body.innerHTML = rows.map(function (row) {
            return `<tr>
                <td>${statusMarkup(row)}</td>
                <td>${escapeHtml(row.id)}</td>
                <td>${escapeHtml(row.label)}</td>
                <td>${escapeHtml(row.opac)}</td>
            </tr>`;
        }).join("");

        document.getElementById("pmk138-summary").innerHTML = `
            <span class="pmk138-chip"><strong>${counts.ready}</strong>&nbsp;${escapeHtml(t.summaryReady)}</span>
            <span class="pmk138-chip"><strong>${counts.existing}</strong>&nbsp;${escapeHtml(t.summaryExisting)}</span>
            <span class="pmk138-chip"><strong>${counts.duplicate}</strong>&nbsp;${escapeHtml(t.summaryDuplicate)}</span>
            <span class="pmk138-chip"><strong>${counts.error}</strong>&nbsp;${escapeHtml(t.summaryErrors)}</span>
        `;

        const existingSection = document.getElementById("pmk138-existing-section");
        const existingBody = document.getElementById("pmk138-existing-body");
        const existingRows = rows.filter(function (row) {
            return row.status === "existing";
        });

        if (existingSection && existingBody) {
            if (existingRows.length) {
                existingBody.innerHTML = existingRows.map(function (row) {
                    return `<tr>
                        <td><strong>${escapeHtml(row.id)}</strong></td>
                        <td>${escapeHtml(row.label)}</td>
                        <td>${escapeHtml(row.opac)}</td>
                    </tr>`;
                }).join("");
                existingSection.hidden = false;
            } else {
                existingBody.innerHTML = "";
                existingSection.hidden = true;
            }
        }

        document.getElementById("pmk138-preview-section").hidden = false;
        document.getElementById("pmk138-import-btn").disabled = counts.ready === 0;
    }

    async function previewImport() {
        if (state.importing) return;
        const category = document.getElementById("pmk138-category")?.value || "";
        if (!category) {
            showMessage(t.chooseCategory, "error");
            return;
        }
        const source = document.getElementById("pmk138-source")?.value || "";
        const parsed = getMode() === "csv" ? parseCsv(source) : parseLines(source);
        if (!parsed.length) {
            showMessage(t.empty, "error");
            return;
        }

        const previewBtn = document.getElementById("pmk138-preview-btn");
        const importBtn = document.getElementById("pmk138-import-btn");
        previewBtn.disabled = true;
        importBtn.disabled = true;
        showMessage(t.preparing, "info");

        try {
            const context = await getCategoryContext(category);
            const copyOpac = !!document.getElementById("pmk138-copy-opac")?.checked;
            const seen = new Set();
            const rows = parsed.map(function (item) {
                return validateItem(item, context, seen, copyOpac);
            });
            state.context = context;
            state.preview = rows;
            state.previewFingerprint = fingerprint();
            renderPreview(rows);
            showMessage("", "info");
        } catch (error) {
            showMessage(t.networkError + " (" + (error && error.message ? error.message : "") + ")", "error");
        } finally {
            previewBtn.disabled = false;
        }
    }

    async function postValue(context, row) {
        const body = new URLSearchParams();
        body.set("csrf_token", context.csrf);
        body.set("op", "cud-add");
        body.set("category", context.category);
        body.set("authorised_value", row.id);
        body.set("lib", row.label);
        body.set("lib_opac", row.opac);
        body.set("image", "");

        try {
            const response = await fetch(PAGE_PATH, {
                method: "POST",
                credentials: "same-origin",
                cache: "no-store",
                headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
                body: body.toString()
            });
            const html = await response.text();
            if (!response.ok) {
                return { ok: false, reason: "HTTP " + response.status };
            }
            const doc = new DOMParser().parseFromString(html, "text/html");
            const errorBox = doc.querySelector(".alert-error, .alert-danger");
            if (errorBox) {
                return { ok: false, reason: normalizeSpace(errorBox.textContent) || t.serverError };
            }
            const found = Array.from(doc.querySelectorAll("#categoriest tbody tr td:first-child")).some(function (td) {
                return normalizeKey(td.textContent) === normalizeKey(row.id);
            });
            if (!found) {
                const message = doc.querySelector(".alert-message, .alert-success");
                if (!message) return { ok: false, reason: t.serverError };
            }
            return { ok: true };
        } catch (error) {
            return { ok: false, reason: t.networkError };
        }
    }

    function appendLog(html) {
        const log = document.getElementById("pmk138-log");
        if (!log) return;
        const line = document.createElement("div");
        line.innerHTML = html;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
    }

    function updateProgress(done, total) {
        const pct = total ? Math.round((done / total) * 100) : 100;
        const bar = document.getElementById("pmk138-progress-bar");
        const text = document.getElementById("pmk138-progress-text");
        if (bar) bar.style.width = pct + "%";
        if (text) text.textContent = done + " / " + total + " (" + pct + " %)";
    }

    async function runPool(items, worker, parallel, onProgress) {
        let cursor = 0;
        let done = 0;
        const results = new Array(items.length);
        async function runOne() {
            while (true) {
                const index = cursor;
                cursor += 1;
                if (index >= items.length) return;
                results[index] = await worker(items[index], index);
                done += 1;
                if (onProgress) onProgress(done, items.length, results[index], items[index]);
            }
        }
        const jobs = [];
        const count = Math.min(Math.max(1, parallel), items.length);
        for (let i = 0; i < count; i += 1) jobs.push(runOne());
        await Promise.all(jobs);
        return results;
    }

    async function executeImport() {
        if (state.importing) return;
        if (!state.context || !state.preview.length || state.previewFingerprint !== fingerprint()) {
            showMessage(t.sourceChanged, "error");
            document.getElementById("pmk138-import-btn").disabled = true;
            return;
        }
        const ready = state.preview.filter(function (row) { return row.status === "ready"; });
        if (!ready.length) return;

        state.importing = true;
        const previewBtn = document.getElementById("pmk138-preview-btn");
        const importBtn = document.getElementById("pmk138-import-btn");
        const closeBtn = document.getElementById("pmk138-close");
        const closeX = document.getElementById("pmk138-close-x");
        previewBtn.disabled = true;
        importBtn.disabled = true;
        closeBtn.disabled = true;
        closeX.disabled = true;
        document.getElementById("pmk138-progress").hidden = false;
        document.getElementById("pmk138-log").innerHTML = "";
        updateProgress(0, ready.length);
        showMessage(t.importing, "info");

        const results = await runPool(
            ready,
            function (row) { return postValue(state.context, row); },
            MAX_PARALLEL,
            function (done, total, result, row) {
                updateProgress(done, total);
                if (result.ok) {
                    appendLog(`<span class="pmk138-status-ready">✓ ${escapeHtml(row.id)}</span> — ${escapeHtml(t.success)}`);
                } else {
                    appendLog(`<span class="pmk138-status-error">✕ ${escapeHtml(row.id)}</span> — ${escapeHtml(result.reason || t.error)}`);
                }
            }
        );

        let success = 0;
        let failed = 0;
        results.forEach(function (result, index) {
            const row = ready[index];
            if (result && result.ok) {
                success += 1;
                row.status = "imported";
            } else {
                failed += 1;
                row.status = "error";
                row.reason = result && result.reason ? result.reason : t.error;
            }
        });

        showMessage(`${t.done} ${success} ${t.imported}, ${failed} ${t.failed}.`, failed ? "info" : "success");
        document.getElementById("pmk138-refresh").hidden = false;
        closeBtn.disabled = false;
        closeX.disabled = false;
        previewBtn.disabled = false;
        state.importing = false;
        state.previewFingerprint = "";
    }


    function csvCell(value) {
        const str = String(value == null ? "" : value);
        return '"' + str.replace(/"/g, '""') + '"';
    }

    function parseCategoryRows(doc, category) {
        const rows = [];

        const table = doc.querySelector("#categoriest")
            || doc.querySelector("table[id*='categori']")
            || doc.querySelector("table");

        if (!table) return rows;

        table.querySelectorAll("tbody tr").forEach(function (tr) {
            const cells = Array.from(tr.querySelectorAll("td"));
            if (!cells.length) return;

            // On ignore la dernière cellule quand elle contient uniquement les actions.
            const id = normalizeSpace(cells[0]?.textContent || "");
            if (!id) return;

            const label = normalizeSpace(cells[1]?.textContent || "");
            const opac = normalizeSpace(cells[2]?.textContent || "");

            rows.push({
                category: category,
                id: id,
                label: label,
                opac: opac
            });
        });

        return rows;
    }

    function getCurrentCategory() {
        const params = new URLSearchParams(window.location.search);
        let current = normalizeSpace(params.get("searchfield"));

        if (!current) {
            const select = document.querySelector("#category_search");
            if (select) current = normalizeSpace(select.value);
        }

        if (!current) {
            const heading = document.querySelector("h1, h2");
            const txt = normalizeSpace(heading?.textContent || "");
            const m = txt.match(/(?:cat[ée]gorie|category)\s*[:\-]\s*(.+)$/i);
            if (m) current = normalizeSpace(m[1]);
        }

        return current;
    }

    async function fetchCategoryRows(category) {
        const url = PAGE_PATH + "?searchfield=" + encodeURIComponent(category);
        const response = await fetch(url, {
            credentials: "same-origin",
            cache: "no-store",
            redirect: "follow"
        });
        if (!response.ok) throw new Error("HTTP " + response.status);

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        const rows = parseCategoryRows(doc, category);

        return rows;
    }

    function buildExportCsv(rows) {
        const lines = [
            ["categorie", "id", "libelle", "libelle_opac"].map(csvCell).join(";")
        ];
        rows.forEach(function (row) {
            lines.push([
                row.category,
                row.id,
                row.label,
                row.opac
            ].map(csvCell).join(";"));
        });
        return lines.join("\r\n");
    }

    function safeFilenamePart(value) {
        return normalizeSpace(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-zA-Z0-9_-]+/g, "-")
            .replace(/^-+|-+$/g, "") || "categorie";
    }

    function buildDownloadLink(filename, content) {
        const blob = new Blob(["\uFEFF", content], { type: "text/csv;charset=utf-8" });
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.className = "btn btn-success";
        link.id = "pmk138-export-download";
        link.href = url;
        link.download = filename;
        link.innerHTML = `<i class="fa fa-download" aria-hidden="true"></i> ${escapeHtml(t.exportDownload)}`;
        link.dataset.objectUrl = url;
        return link;
    }

    function revokeExportUrl(root) {
        const old = root?.querySelector("#pmk138-export-download");
        const url = old?.dataset?.objectUrl;
        if (url) {
            try { URL.revokeObjectURL(url); } catch (e) { /* noop */ }
        }
    }

    function buildExportDialog() {
        let root = document.getElementById("pmk138-export-dialog");
        if (root) return root;

        css();

        root = document.createElement("div");
        root.id = "pmk138-export-dialog";
        root.hidden = true;
        root.setAttribute("role", "dialog");
        root.setAttribute("aria-modal", "true");
        root.innerHTML = `
            <div class="pmk138-panel" style="max-width:720px">
                <div class="pmk138-head">
                    <h2><i class="fa fa-file-export" aria-hidden="true"></i> ${escapeHtml(t.exportTitle)}</h2>
                    <button type="button" class="pmk138-x" id="pmk138-export-close-x" aria-label="${escapeHtml(t.exportClose)}">&times;</button>
                </div>
                <div class="pmk138-body">
                    <div id="pmk138-export-message" class="pmk138-message alert alert-info">
                        ${escapeHtml(t.exportTitle)}
                    </div>

                    <div class="pmk138-actions">
                        <button type="button" class="btn btn-primary" id="pmk138-export-prepare-current">
                            <i class="fa fa-download" aria-hidden="true"></i>
                            ${escapeHtml(t.exportPrepareCurrent)}
                        </button>

                        <button type="button" class="btn btn-default" id="pmk138-export-prepare-all">
                            <i class="fa fa-file-export" aria-hidden="true"></i>
                            ${escapeHtml(t.exportPrepareAll)}
                        </button>
                    </div>

                    <div id="pmk138-export-progress" style="margin-top:16px" hidden>
                        <div class="pmk138-progress-bar"><span id="pmk138-export-progress-bar"></span></div>
                        <div id="pmk138-export-progress-text" class="pmk138-hint" style="margin-top:6px"></div>
                    </div>

                    <div id="pmk138-export-result" style="margin-top:16px"></div>
                </div>

                <div class="pmk138-footer">
                    <button type="button" class="btn btn-default" id="pmk138-export-close">
                        ${escapeHtml(t.exportClose)}
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(root);

        function close() {
            revokeExportUrl(root);
            root.hidden = true;
            document.body.style.overflow = "";
        }

        root.querySelector("#pmk138-export-close-x").addEventListener("click", close);
        root.querySelector("#pmk138-export-close").addEventListener("click", close);
        root.addEventListener("click", function (event) {
            if (event.target === root) close();
        });

        root.querySelector("#pmk138-export-prepare-current").addEventListener("click", prepareCurrentExport);
        root.querySelector("#pmk138-export-prepare-all").addEventListener("click", prepareAllExport);

        return root;
    }

    function showExportMessage(message, kind) {
        const el = document.getElementById("pmk138-export-message");
        if (!el) return;
        el.className = "pmk138-message alert " +
            (kind === "error" ? "alert-danger" : kind === "success" ? "alert-success" : "alert-info");
        el.textContent = message || "";
    }

    function setExportBusy(busy) {
        ["pmk138-export-prepare-current", "pmk138-export-prepare-all", "pmk138-export-close", "pmk138-export-close-x"]
            .forEach(function (id) {
                const el = document.getElementById(id);
                if (el) el.disabled = !!busy;
            });
    }

    function resetExportResult() {
        const root = document.getElementById("pmk138-export-dialog");
        revokeExportUrl(root);

        const result = document.getElementById("pmk138-export-result");
        if (result) result.innerHTML = "";

        const progress = document.getElementById("pmk138-export-progress");
        if (progress) progress.hidden = true;

        const bar = document.getElementById("pmk138-export-progress-bar");
        if (bar) bar.style.width = "0%";

        const txt = document.getElementById("pmk138-export-progress-text");
        if (txt) txt.textContent = "";
    }

    function showExportDownload(rows, filename) {
        const result = document.getElementById("pmk138-export-result");
        if (!result) return;

        const csv = buildExportCsv(rows);
        const link = buildDownloadLink(filename, csv);

        const info = document.createElement("div");
        info.className = "alert alert-success";
        info.style.marginBottom = "10px";
        info.textContent = `${t.exportReady} ${rows.length} ${t.exportRows}.`;

        result.innerHTML = "";
        result.appendChild(info);
        result.appendChild(link);
        showExportMessage(t.exportReady, "success");
    }

    function openExportDialog() {
        const root = buildExportDialog();
        resetExportResult();
        root.hidden = false;
        document.body.style.overflow = "hidden";

        const current = getCurrentCategory();
        showExportMessage(
            current
                ? `${t.exportTitle} — ${current}`
                : t.exportTitle,
            "info"
        );
    }

    async function prepareCurrentExport() {
        const current = getCurrentCategory();
        if (!current) {
            showExportMessage(t.exportNoCurrent, "error");
            return;
        }

        resetExportResult();
        setExportBusy(true);
        showExportMessage(t.exportWorking, "info");

        try {
            // Si la catégorie affichée correspond à la page actuelle, on privilégie
            // le DOM déjà rendu par Koha ; sinon on recharge explicitement la catégorie.
            let rows = parseCategoryRows(document, current);
            if (!rows.length) {
                rows = await fetchCategoryRows(current);
            }

            showExportDownload(
                rows,
                "koha-valeurs-autorisees-" + safeFilenamePart(current) + ".csv"
            );
        } catch (error) {
            console.error("PMK138 prepare current export", error);
            showExportMessage(t.exportError + " (" + (error?.message || "erreur") + ")", "error");
        } finally {
            setExportBusy(false);
        }
    }

    async function prepareAllExport() {
        resetExportResult();
        setExportBusy(true);
        showExportMessage(t.exportWorking, "info");

        const progress = document.getElementById("pmk138-export-progress");
        const bar = document.getElementById("pmk138-export-progress-bar");
        const txt = document.getElementById("pmk138-export-progress-text");
        if (progress) progress.hidden = false;

        try {
            const categories = state.categories.length ? state.categories : await loadCategories();
            if (!categories.length) throw new Error("Aucune catégorie");

            const allRows = [];

            for (let i = 0; i < categories.length; i += 1) {
                const category = categories[i];
                const rows = await fetchCategoryRows(category);
                allRows.push.apply(allRows, rows);

                const done = i + 1;
                const pct = Math.round((done / categories.length) * 100);
                if (bar) bar.style.width = pct + "%";
                if (txt) txt.textContent = `${done} / ${categories.length} — ${category}`;
            }

            const now = new Date();
            const stamp = [
                now.getFullYear(),
                String(now.getMonth() + 1).padStart(2, "0"),
                String(now.getDate()).padStart(2, "0")
            ].join("-");

            showExportDownload(
                allRows,
                "koha-valeurs-autorisees-toutes-categories-" + stamp + ".csv"
            );
        } catch (error) {
            console.error("PMK138 prepare all export", error);
            showExportMessage(t.exportError + " (" + (error?.message || "erreur") + ")", "error");
        } finally {
            setExportBusy(false);
        }
    }

    function findControlsHost() {
        const toolbar = document.querySelector("#toolbar.btn-toolbar, #toolbar, .btn-toolbar");
        if (toolbar) return toolbar;

        const categorySearch = document.querySelector("#category_search");
        if (categorySearch) {
            const form = categorySearch.closest("form");
            if (form && form.parentNode) {
                let host = document.getElementById("pmk138-controls-host");
                if (!host) {
                    host = document.createElement("div");
                    host.id = "pmk138-controls-host";
                    host.className = "btn-toolbar";
                    host.style.margin = "0 0 1rem 0";
                    form.parentNode.insertBefore(host, form);
                }
                return host;
            }
        }

        const main = document.querySelector("main, .main, #main, .main.container-fluid, .container-fluid");
        const heading = main ? main.querySelector("h1, h2") : document.querySelector("h1, h2");
        if (heading && heading.parentNode) {
            let host = document.getElementById("pmk138-controls-host");
            if (!host) {
                host = document.createElement("div");
                host.id = "pmk138-controls-host";
                host.className = "btn-toolbar";
                host.style.margin = "0 0 1rem 0";
                heading.insertAdjacentElement("afterend", host);
            }
            return host;
        }

        return null;
    }

    function makeButton(id, icon, label, handler) {
        let button = document.getElementById(id);
        if (button) return button;
        button = document.createElement("button");
        button.type = "button";
        button.id = id;
        button.className = "btn btn-default";
        button.style.marginRight = "6px";
        button.innerHTML = `<i class="fa ${icon}" aria-hidden="true"></i> ${escapeHtml(label)}`;
        button.addEventListener("click", handler);
        return button;
    }

    function ensureControls() {
        if (!onTargetPage()) return false;

        const host = findControlsHost();
        if (!host) return false;

        const importButton = makeButton(
            BUTTON_ID,
            "fa-file-import",
            t.button,
            openDialog
        );
        if (!importButton.isConnected) host.appendChild(importButton);

        const exportButton = makeButton(
            "pmk138-export-button",
            "fa-file-export",
            t.exportButton,
            openExportDialog
        );
        if (!exportButton.isConnected) host.appendChild(exportButton);

        return true;
    }

    function boot() {
        if (!onTargetPage()) return;

        ensureControls();

        // Koha peut construire/reconstruire certaines zones après DOMContentLoaded.
        // On réessaie quelques fois puis on observe les changements du DOM.
        [100, 300, 700, 1500, 3000].forEach(function (delay) {
            window.setTimeout(ensureControls, delay);
        });

        const observer = new MutationObserver(function () {
            if (!document.getElementById(BUTTON_ID)
                || !document.getElementById("pmk138-export-button")) {
                ensureControls();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
        window.setTimeout(function () { observer.disconnect(); }, 10000);
    }

    window.PMK138AuthorisedValuesBulkImport = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        open: openDialog,
        parseLines: parseLines,
        parseCsv: parseCsv,
        openExport: openExportDialog,
        prepareCurrentExport: prepareCurrentExport,
        prepareAllExport: prepareAllExport
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
        boot();
    }
})(window, document);

;window.PMKNonPlugin.loaded.push("140-authorised-values-bulk-import.js");
} catch (error) { window.PMKNonPlugin.errors.push("140-authorised-values-bulk-import.js: "+error.message); console.error("[PMK] 140-authorised-values-bulk-import.js",error); };
try {
/* ============================================================
   PimpMyKoha — Modification de grille de catalogage par lot
   Module : bulk-framework-change
   Version : 1.0.2-preplugin
   Koha ciblé : 25.11+ (REST API v1)
   ------------------------------------------------------------
   Fonctions :
   - page autonome : /cgi-bin/koha/mainpage.pl?pmk_page=bulk-framework-change
   - entrée par biblionumber OU code-barres d'exemplaire
   - résolution code-barres -> item -> biblionumber
   - dédoublonnage des notices
   - aperçu avant traitement
   - récupération de la grille actuelle et des grilles disponibles
   - changement via PUT /api/v1/biblios/{id} + x-framework-id
   - conservation du MARCXML : le MARC est relu puis renvoyé à l'identique
   - vérification après modification
   - journal + export CSV
   - arrêt du traitement possible
   ============================================================ */

(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMKBulkFrameworkChange) return;
    window.__PMKBulkFrameworkChange = true;

    const MODULE_ID = "bulk-framework-change";
    const MODULE_VERSION = "1.1.0-preplugin";
    const PAGE_PARAM = "bulk-framework-change";
    let API_BASE = "/api/v1";
    let MAX_INPUTS = 5000;
    let CONCURRENCY = 2;
    let RECORD_SCHEMA="UNIMARC";
    let pageContext=null;
    const pageFetch=(url,options)=>window.PMKPagesSettings?window.PMKPagesSettings.request(PAGE_PARAM,url,options,pageContext):window.fetch(url,options);
    function applyPageOptions(){const opts=window.PMKPagesSettings?.runtime(PAGE_PARAM,{apiBase:"/api/v1",maxInputs:5000,concurrency:2})||{};API_BASE=opts.apiBase||"/api/v1";MAX_INPUTS=Math.max(1,Number(opts.maxInputs)||5000);CONCURRENCY=Math.max(1,Math.min(5,Number(opts.concurrency)||2));RECORD_SCHEMA=opts.marcFormat||"UNIMARC";}

    const state = {
        mode: "biblio",
        sourceValues: [],
        rows: [],
        frameworks: [],
        targetFramework: null,
        running: false,
        stopRequested: false,
        processed: 0,
        success: 0,
        skipped: 0,
        errors: 0
    };

    function qs(sel, root = document) {
        return root.querySelector(sel);
    }

    function qsa(sel, root = document) {
        return Array.from(root.querySelectorAll(sel));
    }

    function esc(v) {
        return String(v ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function normalizeText(v) {
        return String(v ?? "").replace(/\s+/g, " ").trim();
    }

    function csvCell(v) {
        const s = String(v ?? "");
        return `"${s.replace(/"/g, '""')}"`;
    }

    function getCsrfToken() {
        return (
            qs('meta[name="csrf-token"]')?.getAttribute("content") ||
            qs('input[name="csrf_token"]')?.value ||
            ""
        );
    }

    async function fetchText(url, options = {}) {
        const response = await pageFetch(url, {
            credentials: "same-origin",
            cache: "no-store",
            ...options
        });
        if (!response.ok) {
            const text = await response.text().catch(() => "");
            throw new Error(`${response.status} ${response.statusText}${text ? " — " + normalizeText(text).slice(0, 300) : ""}`);
        }
        return response.text();
    }

    async function fetchJSON(url, options = {}) {
        const headers = new Headers(options.headers || {});
        if (!headers.has("Accept")) headers.set("Accept", "application/json");

        const response = await pageFetch(url, {
            credentials: "same-origin",
            cache: "no-store",
            ...options,
            headers
        });

        const text = await response.text();
        let data = null;
        try {
            data = text ? JSON.parse(text) : null;
        } catch (_) {
            data = text;
        }

        if (!response.ok) {
            const msg =
                (data && typeof data === "object" && (data.error || data.error_code))
                    ? `${data.error || ""}${data.error_code ? " [" + data.error_code + "]" : ""}`
                    : normalizeText(text).slice(0, 300);
            throw new Error(`${response.status} ${response.statusText}${msg ? " — " + msg : ""}`);
        }

        return { data, response };
    }

    function parseHTML(html) {
        return new DOMParser().parseFromString(html, "text/html");
    }

    function isOurPage() {
        const url = new URL(window.location.href);
        return url.pathname.endsWith("/cgi-bin/koha/mainpage.pl") &&
            url.searchParams.get("pmk_page") === PAGE_PARAM;
    }

    function setStatus(message, type = "info") {
        const box = qs("#pmk-bfc-status");
        if (!box) return;
        box.className = `pmk-bfc-alert pmk-bfc-${type}`;
        box.textContent = message;
        box.hidden = !message;
    }

    function updateCounters() {
        const total = state.rows.length;
        const ready = state.rows.filter(r => r.status === "ready").length;
        const same = state.rows.filter(r => r.status === "same").length;
        const err = state.rows.filter(r => r.status === "error").length;
        const done = state.rows.filter(r => r.status === "done").length;

        const el = qs("#pmk-bfc-counters");
        if (el) {
            el.innerHTML = `
                <span><strong>${total}</strong> notice(s)</span>
                <span><strong>${ready}</strong> à modifier</span>
                <span><strong>${same}</strong> déjà sur la grille cible</span>
                <span><strong>${done}</strong> modifiée(s)</span>
                <span><strong>${err}</strong> erreur(s)</span>
            `;
        }

        const progress = qs("#pmk-bfc-progress");
        if (progress) {
            const processed = state.processed || 0;
            const denom = Math.max(1, state.rows.filter(r => ["ready", "processing", "done", "error", "same"].includes(r.status)).length);
            progress.value = Math.min(100, Math.round((processed / denom) * 100));
        }
    }

    function renderRows() {
        const tbody = qs("#pmk-bfc-table tbody");
        if (!tbody) return;

        tbody.innerHTML = state.rows.map((row, idx) => {
            let badge = "";
            const labels = {
                loading: "Analyse…",
                ready: "Prête",
                same: "Déjà conforme",
                processing: "Modification…",
                done: "Modifiée",
                error: "Erreur"
            };
            badge = `<span class="pmk-bfc-badge pmk-bfc-badge-${esc(row.status)}">${esc(labels[row.status] || row.status)}</span>`;

            return `
                <tr data-index="${idx}">
                    <td>${idx + 1}</td>
                    <td>${esc(row.sourceDisplay || "")}</td>
                    <td>
                        <a href="/cgi-bin/koha/catalogue/detail.pl?biblionumber=${encodeURIComponent(row.biblioId)}"
                           target="_blank" rel="noopener">${esc(row.biblioId)}</a>
                    </td>
                    <td>${esc(row.title || "—")}</td>
                    <td><code>${esc(row.currentFrameworkDisplay ?? "—")}</code></td>
                    <td><code>${esc(row.targetFrameworkDisplay ?? "—")}</code></td>
                    <td>${row.marcPreserved === true ? '<span class="pmk-bfc-badge pmk-bfc-badge-done">MARC conservé</span>' : row.marcPreserved === false ? '<span class="pmk-bfc-badge pmk-bfc-badge-error">Écart MARC</span>' : esc(row.marcSummary || "Contrôle prévu")}${row.marcDiff ? `<div class="pmk-bfc-message">${esc(row.marcDiff)}</div>` : ""}</td>
                    <td>${badge}</td>
                    <td class="pmk-bfc-message">${esc(row.message || "")}</td>
                </tr>
            `;
        }).join("");

        updateCounters();
    }

    function parseInput(raw) {
        const values = String(raw || "")
            .split(/[\r\n;,]+/)
            .map(v => v.trim())
            .filter(Boolean);

        return [...new Set(values)];
    }

    function titleFromMarcXML(xml) {
        try {
            const doc = new DOMParser().parseFromString(xml, "application/xml");
            const marcNs = "http://www.loc.gov/MARC21/slim";
            const fields = Array.from(doc.getElementsByTagNameNS(marcNs, "datafield"));
            const f200 = fields.find(f => f.getAttribute("tag") === "200");
            if (f200) {
                const subs = Array.from(f200.getElementsByTagNameNS(marcNs, "subfield"));
                const a = subs.find(s => s.getAttribute("code") === "a");
                const e = subs.find(s => s.getAttribute("code") === "e");
                return [a?.textContent, e?.textContent].filter(Boolean).map(normalizeText).join(" : ");
            }

            // fallback MARC21
            const f245 = fields.find(f => f.getAttribute("tag") === "245");
            if (f245) {
                const subs = Array.from(f245.getElementsByTagNameNS(marcNs, "subfield"));
                return subs
                    .filter(s => ["a", "b"].includes(s.getAttribute("code")))
                    .map(s => normalizeText(s.textContent))
                    .filter(Boolean)
                    .join(" ");
            }
        } catch (_) {}
        return "";
    }

    function marcStructure(xml) {
        const doc = new DOMParser().parseFromString(xml, "application/xml");
        if (doc.querySelector("parsererror")) throw new Error("MARCXML invalide");
        const record = doc.getElementsByTagNameNS("http://www.loc.gov/MARC21/slim", "record")[0] || doc.querySelector("record");
        if (!record) throw new Error("Enregistrement MARC absent");
        const children = Array.from(record.children).map(field => {
            const type = field.localName;
            if (type === "leader") return { type, value: field.textContent || "" };
            if (type === "controlfield") return { type, tag: field.getAttribute("tag") || "", value: field.textContent || "" };
            if (type === "datafield") return { type, tag: field.getAttribute("tag") || "", ind1: field.getAttribute("ind1") || " ", ind2: field.getAttribute("ind2") || " ", subfields: Array.from(field.children).filter(node => node.localName === "subfield").map(node => ({ code: node.getAttribute("code") || "", value: node.textContent || "" })) };
            return { type, value: field.textContent || "" };
        });
        return { children, fieldCount: children.filter(field => field.type === "controlfield" || field.type === "datafield").length, subfieldCount: children.reduce((sum, field) => sum + (field.subfields?.length || 0), 0) };
    }

    function compareMarc(beforeXML, afterXML) {
        const before = marcStructure(beforeXML), after = marcStructure(afterXML);
        if (JSON.stringify(before.children) === JSON.stringify(after.children)) return { preserved: true, before, after, details: "Zones, indicateurs, sous-zones, ordre et valeurs inchangés." };
        const details = [], max = Math.max(before.children.length, after.children.length);
        for (let index = 0; index < max && details.length < 5; index++) if (JSON.stringify(before.children[index]) !== JSON.stringify(after.children[index])) {
            const left = before.children[index], right = after.children[index];
            details.push(`position ${index + 1} : ${left?.tag || left?.type || "absent"} → ${right?.tag || right?.type || "absent"}`);
        }
        return { preserved: false, before, after, details: details.join(" ; ") || "structure différente" };
    }

    async function getMarcXML(biblioId) {
        const response = await pageFetch(`${API_BASE}/biblios/${encodeURIComponent(biblioId)}`, {
            method: "GET",
            credentials: "same-origin",
            cache: "no-store",
            headers: {
                "Accept": "application/marcxml+xml"
            }
        });

        const text = await response.text();
        if (!response.ok) {
            throw new Error(`${response.status} ${response.statusText} — ${normalizeText(text).slice(0, 300)}`);
        }
        return text;
    }

    function extractFrameworkInfoFromEditPage(html) {
        const doc = parseHTML(html);

        // Koha peut rendre la grille sous forme de select ou de champ caché.
        const direct = doc.querySelector('[name="frameworkcode"]');
        let current = direct ? String(direct.value ?? "") : null;

        // On collecte aussi toutes les grilles proposées par l'éditeur.
        const options = [];
        doc.querySelectorAll('select[name="frameworkcode"] option, #frameworkcode option').forEach(opt => {
            options.push({
                code: String(opt.value ?? ""),
                label: normalizeText(opt.textContent || "") || (opt.value || "Défaut")
            });
            if (opt.selected) current = String(opt.value ?? "");
        });

        // fallback éventuel sur liens/inputs portant explicitement frameworkcode
        if (current === null) {
            const hidden = doc.querySelector('input[name="frameworkcode"]');
            if (hidden) current = String(hidden.value ?? "");
        }

        return { current, options };
    }

    async function getBiblioFrameworkInfo(biblioId) {
        const html = await fetchText(`/cgi-bin/koha/cataloguing/addbiblio.pl?biblionumber=${encodeURIComponent(biblioId)}`);
        return extractFrameworkInfoFromEditPage(html);
    }

    function extractFrameworksFromAdminPage(html) {
        const doc = parseHTML(html);
        const found = new Map();

        // La grille par défaut n'a pas de code.
        found.set("", { code: "", label: "Défaut" });

        // 1) Méthode la plus fiable : récupérer les frameworkcode présents
        // dans les liens d'action de la page Administration > Grilles bibliographiques.
        doc.querySelectorAll('a[href*="biblio_framework.pl"]').forEach(a => {
            let u;
            try { u = new URL(a.getAttribute("href"), window.location.origin); } catch (_) { return; }
            if (!u.searchParams.has("frameworkcode")) return;

            const code = String(u.searchParams.get("frameworkcode") ?? "");
            const row = a.closest("tr");
            let label = "";

            if (row) {
                const cells = Array.from(row.querySelectorAll("td"));
                // Koha affiche généralement le code puis la description.
                const clean = cells
                    .map(td => normalizeText(td.textContent || ""))
                    .filter(Boolean)
                    .filter(v => !/modifier|actions?|supprimer|marc|structure/i.test(v));

                label = clean.find(v => v !== code) || clean[0] || "";
            }

            if (!label) label = normalizeText(a.getAttribute("title") || a.textContent || "");
            if (!label || /modifier|actions?|supprimer/i.test(label)) label = code || "Défaut";

            if (!found.has(code)) found.set(code, { code, label });
        });

        // 2) Fallback : certaines versions rendent le code dans un data-* ou une cellule.
        doc.querySelectorAll('tr').forEach(row => {
            const explicit = row.querySelector('[data-frameworkcode]');
            let code = explicit ? String(explicit.getAttribute('data-frameworkcode') ?? '') : null;

            if (code === null) {
                const link = row.querySelector('a[href*="frameworkcode="]');
                if (link) {
                    try {
                        code = String(new URL(link.getAttribute('href'), window.location.origin).searchParams.get('frameworkcode') ?? '');
                    } catch (_) {}
                }
            }
            if (code === null || found.has(code)) return;

            const cells = Array.from(row.querySelectorAll('td'));
            const values = cells.map(td => normalizeText(td.textContent || '')).filter(Boolean);
            const label = values.find(v => v !== code) || code || 'Défaut';
            found.set(code, { code, label });
        });

        return Array.from(found.values());
    }

    async function loadAllFrameworks() {
        try {
            const html = await fetchText('/cgi-bin/koha/admin/biblio_framework.pl');
            const list = extractFrameworksFromAdminPage(html);
            if (list.length <= 1) {
                throw new Error('aucune grille supplémentaire détectée dans la page d’administration');
            }
            mergeFrameworks(list);
            renderFrameworkSelector();
            return list;
        } catch (err) {
            console.warn('[PMK141] Impossible de charger la liste complète des grilles', err);
            return [];
        }
    }

    async function resolveBarcode(barcode) {
        const url = `${API_BASE}/items?external_id=${encodeURIComponent(barcode)}&_match=exact&_per_page=20`;
        const { data } = await fetchJSON(url);

        if (!Array.isArray(data) || data.length === 0) {
            throw new Error(`Code-barres introuvable : ${barcode}`);
        }

        const exact = data.filter(item => String(item.external_id ?? "") === String(barcode));
        const candidates = exact.length ? exact : data;

        const uniqueBiblios = [...new Set(candidates.map(item => item.biblio_id).filter(v => v !== null && v !== undefined))];
        if (uniqueBiblios.length === 0) {
            throw new Error(`Aucune notice rattachée au code-barres ${barcode}`);
        }
        if (uniqueBiblios.length > 1) {
            throw new Error(`Le code-barres ${barcode} renvoie plusieurs notices (${uniqueBiblios.join(", ")})`);
        }

        return {
            biblioId: Number(uniqueBiblios[0]),
            itemIds: candidates.map(i => i.item_id).filter(Boolean),
            barcode
        };
    }

    async function hydrateBiblio(row) {
        row.status = "loading";
        renderRows();

        try {
            const [xml, fw] = await Promise.all([
                getMarcXML(row.biblioId),
                getBiblioFrameworkInfo(row.biblioId)
            ]);

            row.marcXML = xml;
            const structure = marcStructure(xml);
            row.marcSummary = `${structure.fieldCount} zone(s), ${structure.subfieldCount} sous-zone(s)`;
            row.marcPreserved = null;
            row.marcDiff = "";
            row.title = titleFromMarcXML(xml) || row.title || "";
            row.currentFramework = fw.current ?? "";
            row.currentFrameworkDisplay = row.currentFramework === "" ? "Défaut" : row.currentFramework;

            if (fw.options?.length) mergeFrameworks(fw.options);

            row.status = "ready";
            row.message = "";
        } catch (err) {
            row.status = "error";
            row.message = err?.message || String(err);
        }

        applyTargetToRow(row);
        renderFrameworkSelector();
        renderRows();
    }

    function mergeFrameworks(list) {
        const map = new Map(state.frameworks.map(f => [String(f.code), f]));
        for (const f of list || []) {
            const code = String(f.code ?? "");
            if (!map.has(code)) {
                map.set(code, {
                    code,
                    label: normalizeText(f.label || "") || (code || "Défaut")
                });
            }
        }
        // Toujours prévoir la grille par défaut.
        if (!map.has("")) map.set("", { code: "", label: "Défaut" });

        state.frameworks = Array.from(map.values()).sort((a, b) => {
            if (a.code === "") return -1;
            if (b.code === "") return 1;
            return a.label.localeCompare(b.label, "fr", { sensitivity: "base" });
        });
    }

    function renderFrameworkSelector() {
        const select = qs("#pmk-bfc-target-framework");
        if (!select) return;

        const selected = state.targetFramework !== null ? String(state.targetFramework) : select.value;
        select.innerHTML = `<option value="">— Grille par défaut —</option>` +
            state.frameworks
                .filter(f => f.code !== "")
                .map(f => `<option value="${esc(f.code)}">${esc(f.label)} (${esc(f.code)})</option>`)
                .join("");

        if (state.targetFramework !== null) {
            select.value = String(state.targetFramework);
        } else if (selected && state.frameworks.some(f => String(f.code) === selected)) {
            select.value = selected;
        }
    }

    function applyTargetToRow(row) {
        if (state.targetFramework === null) {
            row.targetFramework = null;
            row.targetFrameworkDisplay = "—";
            if (row.status === "same") row.status = "ready";
            return;
        }

        row.targetFramework = String(state.targetFramework);
        row.targetFrameworkDisplay = row.targetFramework === "" ? "Défaut" : row.targetFramework;

        if (["ready", "same"].includes(row.status)) {
            if (String(row.currentFramework ?? "") === row.targetFramework) {
                row.status = "same";
                row.message = "La notice utilise déjà cette grille.";
            } else {
                row.status = "ready";
                row.message = "";
            }
        }
    }

    function applyTargetToAll() {
        state.rows.forEach(applyTargetToRow);
        renderRows();
    }

    async function analyze() {
        // Si le chargement initial n'a ramené que la grille par défaut,
        // on retente juste avant l'analyse (utile après expiration de session/cache).
        if (state.frameworks.filter(f => String(f.code ?? "") !== "").length === 0) {
            await loadAllFrameworks();
        }

        const textarea = qs("#pmk-bfc-input");
        const values = parseInput(textarea?.value || "");

        if (!values.length) {
            setStatus("Saisis au moins une valeur.", "warning");
            return;
        }
        if (values.length > MAX_INPUTS) {
            setStatus(`Le lot contient ${values.length} valeurs. Limite de sécurité : ${MAX_INPUTS}.`, "danger");
            return;
        }

        state.sourceValues = values;
        state.rows = [];
        state.processed = 0;
        state.success = 0;
        state.skipped = 0;
        state.errors = 0;
        state.targetFramework = null;
        qs("#pmk-bfc-target-framework").value = "";
        qs("#pmk-bfc-target-wrap").hidden = true;
        qs("#pmk-bfc-actions-wrap").hidden = true;
        qs("#pmk-bfc-results-wrap").hidden = false;
        setStatus(`Analyse de ${values.length} valeur(s)…`, "info");

        const resolved = [];
        const resolveErrors = [];

        if (state.mode === "biblio") {
            for (const v of values) {
                if (!/^\d+$/.test(v)) {
                    resolveErrors.push({
                        sourceDisplay: v,
                        biblioId: "—",
                        title: "",
                        currentFrameworkDisplay: "—",
                        targetFrameworkDisplay: "—",
                        status: "error",
                        message: "Numéro de notice invalide."
                    });
                } else {
                    resolved.push({
                        biblioId: Number(v),
                        sourceDisplay: v,
                        sources: [v],
                        sourceType: "biblio",
                        status: "loading",
                        message: ""
                    });
                }
            }
        } else {
            const queue = [...values];
            const workers = Array.from({ length: Math.min(CONCURRENCY * 2, queue.length) }, async () => {
                while (queue.length) {
                    const barcode = queue.shift();
                    try {
                        const r = await resolveBarcode(barcode);
                        resolved.push({
                            biblioId: r.biblioId,
                            sourceDisplay: barcode,
                            sources: [barcode],
                            barcodes: [barcode],
                            itemIds: r.itemIds,
                            sourceType: "barcode",
                            status: "loading",
                            message: ""
                        });
                    } catch (err) {
                        resolveErrors.push({
                            sourceDisplay: barcode,
                            biblioId: "—",
                            title: "",
                            currentFrameworkDisplay: "—",
                            targetFrameworkDisplay: "—",
                            status: "error",
                            message: err?.message || String(err)
                        });
                    }
                }
            });
            await Promise.all(workers);
        }

        // Dédoublonnage par biblionumber
        const byBiblio = new Map();
        for (const row of resolved) {
            const key = String(row.biblioId);
            if (!byBiblio.has(key)) {
                byBiblio.set(key, row);
            } else {
                const existing = byBiblio.get(key);
                existing.sources.push(...(row.sources || []));
                existing.barcodes = [...new Set([...(existing.barcodes || []), ...(row.barcodes || [])])];
                existing.itemIds = [...new Set([...(existing.itemIds || []), ...(row.itemIds || [])])];
                existing.sourceDisplay = existing.sources.join(", ");
            }
        }

        state.rows = [...byBiblio.values(), ...resolveErrors];
        renderRows();

        const hydratable = state.rows.filter(r => r.biblioId !== "—");
        const queue = [...hydratable];
        const workers = Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
            while (queue.length) {
                const row = queue.shift();
                await hydrateBiblio(row);
            }
        });
        await Promise.all(workers);

        const okCount = state.rows.filter(r => r.status === "ready").length;
        const errCount = state.rows.filter(r => r.status === "error").length;

        qs("#pmk-bfc-target-wrap").hidden = okCount === 0;
        qs("#pmk-bfc-actions-wrap").hidden = okCount === 0;

        if (okCount) {
            setStatus(
                `${state.rows.length} ligne(s) analysée(s), ${okCount} notice(s) exploitable(s)` +
                (errCount ? `, ${errCount} erreur(s).` : ".") +
                " Choisis maintenant la grille cible.",
                errCount ? "warning" : "success"
            );
        } else {
            setStatus("Aucune notice exploitable dans ce lot.", "danger");
        }

        renderFrameworkSelector();
        updateCounters();
    }

    async function updateBiblioFramework(row, targetFramework) {
        // On relit le MARC juste avant écriture afin de ne jamais pousser
        // une version devenue obsolète depuis l'analyse.
        const xml = await getMarcXML(row.biblioId);
        const csrf = getCsrfToken();

        // IMPORTANT Koha :
        // le contrôleur REST utilise :
        //   header('x-framework-id') || $biblio->frameworkcode
        // Une chaîne vide est donc ignorée.
        // Pour basculer vers la grille par défaut, il faut envoyer "Default",
        // que ModBiblio normalise ensuite en chaîne vide.
        const frameworkHeaderValue =
            String(targetFramework ?? "") === "" ? "Default" : String(targetFramework);

        const headers = new Headers({
            "Accept": "application/json",
            "Content-Type": "application/marcxml+xml",
            "x-framework-id": frameworkHeaderValue,
            "x-record-schema": RECORD_SCHEMA,
            "x-confirm-not-duplicate": "1"
        });

        if (csrf) {
            // Koha 24.05+ vérifie le jeton CSRF pour les méthodes PUT
            // lorsqu'une authentification par cookie est utilisée.
            headers.set("X-CSRF-Token", csrf);
            headers.set("CSRF-TOKEN", csrf);
        }

        const response = await pageFetch(`${API_BASE}/biblios/${encodeURIComponent(row.biblioId)}`, {
            method: "PUT",
            credentials: "same-origin",
            cache: "no-store",
            headers,
            body: xml
        });

        const text = await response.text();
        if (!response.ok) {
            let msg = normalizeText(text).slice(0, 400);
            try {
                const j = JSON.parse(text);
                msg = `${j.error || msg}${j.error_code ? " [" + j.error_code + "]" : ""}`;
            } catch (_) {}
            throw new Error(`${response.status} ${response.statusText}${msg ? " — " + msg : ""}`);
        }

        return xml;
    }

    async function verifyFramework(biblioId, expected) {
        const fw = await getBiblioFrameworkInfo(biblioId);
        return {
            ok: String(fw.current ?? "") === String(expected ?? ""),
            actual: String(fw.current ?? "")
        };
    }

    async function processOne(row) {
        if (state.stopRequested) return;

        if (row.status === "same") {
            state.skipped++;
            state.processed++;
            return;
        }
        if (row.status !== "ready") return;

        row.status = "processing";
        row.message = "";
        renderRows();

        try {
            row.operationAttempted = true;
            const beforeXML = await updateBiblioFramework(row, state.targetFramework);

            const verification = await verifyFramework(row.biblioId, state.targetFramework);
            if (!verification.ok) {
                throw new Error(
                    `Koha a répondu sans erreur, mais la vérification indique la grille ` +
                    `${verification.actual === "" ? "Défaut" : verification.actual || "inconnue"}.`
                );
            }

            const afterXML = await getMarcXML(row.biblioId);
            const marcCheck = compareMarc(beforeXML, afterXML);
            row.marcPreserved = marcCheck.preserved;
            row.marcDiff = marcCheck.details;
            row.marcSummary = `${marcCheck.after.fieldCount} zone(s), ${marcCheck.after.subfieldCount} sous-zone(s)`;
            if (!marcCheck.preserved) {
                row.retryable = false;
                throw new Error(`La grille a été modifiée, mais le contrôle MARC détecte un écart : ${marcCheck.details}. Vérification manuelle requise avant toute reprise.`);
            }

            row.currentFramework = String(state.targetFramework);
            row.currentFrameworkDisplay = row.currentFramework === "" ? "Défaut" : row.currentFramework;
            row.status = "done";
            row.message = "Grille modifiée et vérifiée.";
            state.success++;
        } catch (err) {
            row.status = "error";
            row.message = err?.message || String(err);
            if (row.retryable !== false) row.retryable = true;
            state.errors++;
        } finally {
            state.processed++;
            renderRows();
        }
    }

    async function retryFailures() {
        if (state.running) return;
        const failures = state.rows.filter(row => row.status === "error" && row.biblioId !== "—" && row.retryable !== false);
        if (!failures.length) {
            setStatus("Aucun échec technique réessayable. Les écarts MARC exigent une vérification manuelle.", "warning");
            return;
        }
        setStatus(`Relecture de ${failures.length} échec(s) avant reprise…`, "info");
        const queue = [...failures];
        const workers = Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
            while (queue.length) await hydrateBiblio(queue.shift());
        });
        await Promise.all(workers);
        failures.forEach(row => applyTargetToRow(row));
        renderRows();
        const ready = failures.filter(row => row.status === "ready").length;
        setStatus(`${ready} notice(s) relue(s) et prête(s). Contrôlez l’aperçu puis relancez uniquement ces erreurs.`, ready ? "success" : "warning");
    }

    async function runBatch() {
        if (state.running) return;

        if (state.targetFramework === null) {
            setStatus("Choisis une grille cible avant de lancer le traitement.", "warning");
            return;
        }

        const ready = state.rows.filter(r => r.status === "ready");
        const same = state.rows.filter(r => r.status === "same");

        if (!ready.length) {
            setStatus(
                same.length
                    ? "Toutes les notices exploitables utilisent déjà la grille cible."
                    : "Aucune notice prête à être modifiée.",
                "warning"
            );
            return;
        }

        const targetLabel = state.targetFramework === "" ? "Défaut" : state.targetFramework;
        const confirmation = window.confirm(
            `Modifier la grille de ${ready.length} notice(s) vers « ${targetLabel} » ?\n\n` +
            `Le contenu MARC sera relu puis réenregistré à l'identique avec cette grille.\n` +
            `Cette opération modifie réellement les notices Koha.`
        );
        if (!confirmation) return;

        const second = window.prompt(
            `Confirmation de sécurité : tape ${ready.length} pour lancer le traitement.`
        );
        if (String(second).trim() !== String(ready.length)) {
            setStatus("Traitement annulé : confirmation incorrecte.", "warning");
            return;
        }

        state.running = true;
        state.stopRequested = false;
        state.processed = 0;
        state.success = 0;
        state.skipped = 0;
        state.errors = 0;

        qs("#pmk-bfc-run").disabled = true;
        qs("#pmk-bfc-stop").disabled = false;
        qs("#pmk-bfc-analyze").disabled = true;
        qs("#pmk-bfc-target-framework").disabled = true;

        setStatus(`Traitement en cours : ${ready.length} notice(s)…`, "info");

        const queue = [...state.rows.filter(r => ["ready", "same"].includes(r.status))];
        const workers = Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
            while (queue.length && !state.stopRequested) {
                const row = queue.shift();
                await processOne(row);
            }
        });

        await Promise.all(workers);

        state.running = false;
        if(pageContext?.signal.aborted)return;
        qs("#pmk-bfc-run").disabled = false;
        qs("#pmk-bfc-stop").disabled = true;
        qs("#pmk-bfc-analyze").disabled = false;
        qs("#pmk-bfc-target-framework").disabled = false;

        const remaining = state.rows.filter(r => r.status === "ready").length;

        if (state.stopRequested) {
            setStatus(
                `Traitement arrêté. ${state.success} modification(s) réussie(s), ` +
                `${state.errors} erreur(s), ${remaining} restante(s).`,
                "warning"
            );
        } else if (state.errors) {
            setStatus(
                `Traitement terminé avec erreurs : ${state.success} réussite(s), ` +
                `${state.errors} erreur(s).`,
                "warning"
            );
        } else {
            setStatus(
                `Traitement terminé : ${state.success} notice(s) modifiée(s)` +
                (state.skipped ? `, ${state.skipped} déjà conforme(s)` : "") + ".",
                "success"
            );
        }

        renderRows();
    }

    function stopBatch() {
        if (!state.running) return;
        state.stopRequested = true;
        const stop=qs("#pmk-bfc-stop");if(stop)stop.disabled=true;
        setStatus("Arrêt demandé : les opérations déjà lancées vont se terminer, aucune nouvelle notice ne sera démarrée.", "warning");
    }

    function exportCSV() {
        if (!state.rows.length) return;

        const lines = [
            ["source", "biblionumber", "titre", "grille_actuelle", "grille_cible", "controle_marc", "detail_marc", "statut", "message"]
                .map(csvCell).join(";")
        ];

        for (const row of state.rows) {
            lines.push([
                row.sourceDisplay || "",
                row.biblioId || "",
                row.title || "",
                row.currentFrameworkDisplay || "",
                row.targetFrameworkDisplay || "",
                row.marcPreserved === true ? "conserve" : row.marcPreserved === false ? "ecart" : "non_execute",
                row.marcDiff || row.marcSummary || "",
                row.status || "",
                row.message || ""
            ].map(csvCell).join(";"));
        }

        const blob = new Blob(["\uFEFF" + lines.join("\r\n")], {
            type: "text/csv;charset=utf-8"
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `pmk-modification-grille-${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function resetAll() {
        if (state.running) return;
        state.sourceValues = [];
        state.rows = [];
        state.targetFramework = null;
        state.processed = 0;
        state.success = 0;
        state.skipped = 0;
        state.errors = 0;

        qs("#pmk-bfc-input").value = "";
        qs("#pmk-bfc-target-wrap").hidden = true;
        qs("#pmk-bfc-actions-wrap").hidden = true;
        qs("#pmk-bfc-results-wrap").hidden = true;
        qs("#pmk-bfc-target-framework").value = "";
        setStatus("", "info");
        renderRows();
    }

    function installCSS() {
        if (qs("#pmk-bfc-style")) return;
        const style = document.createElement("style");
        style.id = "pmk-bfc-style";
        style.textContent = `
            #pmk-bfc-app { max-width: 1500px; margin: 0 auto; }
            #pmk-bfc-app .pmk-bfc-card {
                background: var(--bs-body-bg, #fff);
                border: 1px solid #d7dce1;
                border-radius: 8px;
                padding: 18px;
                margin: 0 0 16px;
                box-shadow: 0 1px 2px rgba(0,0,0,.04);
            }
            #pmk-bfc-app .pmk-bfc-header {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 20px;
                margin-bottom: 16px;
            }
            #pmk-bfc-app .pmk-bfc-header h1 { margin: 0 0 4px; font-size: 1.55rem; }
            #pmk-bfc-app .pmk-bfc-muted { color: #67727e; }
            #pmk-bfc-app .pmk-bfc-mode {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                margin-bottom: 12px;
            }
            #pmk-bfc-app .pmk-bfc-mode label {
                border: 1px solid #cbd2d9;
                border-radius: 6px;
                padding: 9px 12px;
                cursor: pointer;
                background: #fff;
            }
            #pmk-bfc-app .pmk-bfc-mode label:has(input:checked) {
                border-color: #0b6fa4;
                box-shadow: 0 0 0 1px #0b6fa4 inset;
                background: #f2f9fc;
            }
            #pmk-bfc-app textarea {
                min-height: 170px;
                resize: vertical;
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            }
            #pmk-bfc-app .pmk-bfc-toolbar {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: 8px;
                margin-top: 12px;
            }
            #pmk-bfc-app .pmk-bfc-alert {
                border-radius: 6px;
                padding: 10px 12px;
                margin-bottom: 16px;
                border: 1px solid transparent;
            }
            #pmk-bfc-app .pmk-bfc-info { background:#eef7fb; border-color:#b8deed; }
            #pmk-bfc-app .pmk-bfc-success { background:#edf8f0; border-color:#b9dfc2; }
            #pmk-bfc-app .pmk-bfc-warning { background:#fff7e6; border-color:#efd79a; }
            #pmk-bfc-app .pmk-bfc-danger { background:#fdeeee; border-color:#e8b8b8; }
            #pmk-bfc-app .pmk-bfc-grid {
                display: grid;
                grid-template-columns: minmax(240px, 500px) 1fr;
                gap: 16px;
                align-items: end;
            }
            #pmk-bfc-app .pmk-bfc-counters {
                display:flex; flex-wrap:wrap; gap:10px 18px; margin: 8px 0 12px;
            }
            #pmk-bfc-app .pmk-bfc-table-wrap {
                overflow: auto;
                max-height: 62vh;
                border: 1px solid #d7dce1;
                border-radius: 6px;
            }
            #pmk-bfc-app table { margin: 0; width: 100%; }
            #pmk-bfc-app thead th {
                position: sticky;
                top: 0;
                z-index: 2;
                background: #f5f6f7;
                white-space: nowrap;
            }
            #pmk-bfc-app .pmk-bfc-badge {
                display:inline-block; border-radius:999px; padding:3px 8px; font-size:.83em; white-space:nowrap;
                background:#e9ecef;
            }
            #pmk-bfc-app .pmk-bfc-badge-ready { background:#e8f3fb; }
            #pmk-bfc-app .pmk-bfc-badge-same { background:#f1f1f1; }
            #pmk-bfc-app .pmk-bfc-badge-processing { background:#fff2c9; }
            #pmk-bfc-app .pmk-bfc-badge-done { background:#dff2e3; }
            #pmk-bfc-app .pmk-bfc-badge-error { background:#f8dada; }
            #pmk-bfc-app .pmk-bfc-message { min-width: 220px; max-width: 520px; }
            #pmk-bfc-app progress { width: 100%; height: 12px; margin-top: 8px; }
            #pmk-bfc-app code { white-space: nowrap; }
            #pmk-bfc-app .pmk-bfc-note {
                border-left: 4px solid #d19a00;
                padding: 8px 12px;
                background: #fffaf0;
                margin-top: 12px;
            }
            @media (max-width: 900px) {
                #pmk-bfc-app .pmk-bfc-grid { grid-template-columns: 1fr; }
            }
        `;
        document.head.appendChild(style);
    }

    function renderApp(managedContainer) {
        installCSS();

        const main =
            qs("#main") ||
            qs("main") ||
            qs(".main") ||
            qs("#content") ||
            document.body;

        // On garde autant que possible l'entête/navigation Koha mais on remplace
        // le contenu central de mainpage.
        const existing = qs("#pmk-bfc-app");
        if (existing) {if(managedContainer && !managedContainer.contains(existing)){managedContainer.appendChild(existing);existing.style.removeProperty("display");}return existing;}

        const app = document.createElement("div");
        app.id = "pmk-bfc-app";
        app.innerHTML = `
            <div class="pmk-bfc-header">
                <div>
                    <h1><i class="fa-solid fa-table-list" aria-hidden="true"></i> Modification de grille par lot</h1>
                    <div class="pmk-bfc-muted">
                        Change la grille de catalogage de plusieurs notices à partir de numéros de notice
                        ou de codes-barres d'exemplaires.
                    </div>
                </div>
                <div class="pmk-bfc-muted">PimpMyKoha · ${esc(MODULE_VERSION)}</div>
            </div>

            <div id="pmk-bfc-status" class="pmk-bfc-alert pmk-bfc-info" hidden></div>

            <section class="pmk-bfc-card">
                <h2>1. Sélectionner les notices</h2>

                <div class="pmk-bfc-mode">
                    <label>
                        <input type="radio" name="pmk_bfc_mode" value="biblio" checked>
                        <strong>Numéros de notice</strong>
                    </label>
                    <label>
                        <input type="radio" name="pmk_bfc_mode" value="barcode">
                        <strong>Codes-barres d'exemplaires</strong>
                    </label>
                </div>

                <label for="pmk-bfc-input" id="pmk-bfc-input-label">
                    Un numéro de notice par ligne
                </label>
                <textarea id="pmk-bfc-input" class="form-control"
                    placeholder="379480&#10;381245&#10;402117"></textarea>

                <div class="pmk-bfc-toolbar">
                    <button type="button" class="btn btn-primary" id="pmk-bfc-analyze">
                        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> Analyser le lot
                    </button>
                    <button type="button" class="btn btn-default" id="pmk-bfc-reset">
                        Réinitialiser
                    </button>
                </div>
                <div class="pmk-bfc-muted" style="margin-top:8px">
                    Les doublons sont éliminés. Avec les codes-barres, plusieurs exemplaires d'une même notice
                    ne produiront qu'une seule modification.
                </div>
            </section>

            <section class="pmk-bfc-card" id="pmk-bfc-target-wrap" hidden>
                <h2>2. Choisir la nouvelle grille</h2>
                <div class="pmk-bfc-grid">
                    <div>
                        <label for="pmk-bfc-target-framework"><strong>Grille cible</strong></label>
                        <select id="pmk-bfc-target-framework" class="form-control">
                            <option value="">— Grille par défaut —</option>
                        </select>
                    </div>
                    <div class="pmk-bfc-note">
                        Le changement de grille ne supprime ni n'ajoute volontairement de zones MARC.
                        La notice est relue en MARCXML, puis réenregistrée avec la grille sélectionnée.
                    </div>
                </div>
            </section>

            <section class="pmk-bfc-card" id="pmk-bfc-actions-wrap" hidden>
                <h2>3. Exécuter</h2>
                <div class="pmk-bfc-counters" id="pmk-bfc-counters"></div>
                <progress id="pmk-bfc-progress" max="100" value="0"></progress>
                <div class="pmk-bfc-toolbar">
                    <button type="button" class="btn btn-danger" id="pmk-bfc-run">
                        <i class="fa-solid fa-arrows-rotate" aria-hidden="true"></i>
                        Modifier les grilles
                    </button>
                    <button type="button" class="btn btn-default" id="pmk-bfc-stop" disabled>
                        Arrêter
                    </button>
                    <button type="button" class="btn btn-default" id="pmk-bfc-retry">
                        Reprendre les échecs techniques
                    </button>
                    <button type="button" class="btn btn-default" id="pmk-bfc-export">
                        Exporter le rapport CSV
                    </button>
                </div>
            </section>

            <section class="pmk-bfc-card" id="pmk-bfc-results-wrap" hidden>
                <h2>Aperçu et résultat</h2>
                <div class="pmk-bfc-counters" id="pmk-bfc-counters-copy"></div>
                <div class="pmk-bfc-table-wrap">
                    <table class="table table-striped table-hover" id="pmk-bfc-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Entrée</th>
                                <th>Notice</th>
                                <th>Titre</th>
                                <th>Grille actuelle</th>
                                <th>Grille cible</th>
                                <th>Contrôle MARC</th>
                                <th>État</th>
                                <th>Message</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </section>
        `;

        // On vise le conteneur de contenu sans casser les menus Koha.
        const content = managedContainer ||
            qs("#main_intranet-main") ||
            qs(".maincontent") ||
            qs("#content") ||
            main;

        /*
         * IMPORTANT :
         * ne jamais vider globalement le conteneur de mainpage.pl.
         * IntranetNav (134) et plusieurs modules PMK injectent leurs éléments
         * dans/près de cette zone. Un content.innerHTML = "" les détruisait.
         *
         * On masque uniquement le contenu natif de l'accueil Koha déjà présent,
         * tout en conservant explicitement les zones de navigation PMK/Koha.
         */
        const protectedSelectors = [
            "#toplevelmenu",
            "#bottomActionBar",
            "#custom-tools-menu",
            "[data-pmk-intranetnav]",
            ".pmk-intranetnav",
            "[id^='pmk-intranetnav']",
            "[class*='pmk-intranetnav']"
        ].join(",");

        Array.from(content.children).forEach(child => {
            if (child === app) return;

            const isProtected =
                (child.matches && child.matches(protectedSelectors)) ||
                (child.querySelector && child.querySelector(protectedSelectors));

            if (isProtected) return;

            // Conserver les noeuds appartenant explicitement à PMK.
            const id = String(child.id || "");
            const cls = String(child.className || "");
            const isPMK =
                id.startsWith("pmk-") ||
                /(^|\s)pmk[-_]/i.test(cls);

            if (isPMK) return;

            child.dataset.pmkBfcHiddenNative = "1";
            child.style.display = "none";
        });

        content.appendChild(app);

        // Le second compteur est volontairement synchronisé par observer léger.
        const c1 = qs("#pmk-bfc-counters");
        const c2 = qs("#pmk-bfc-counters-copy");
        if (c1 && c2) {
            new MutationObserver(() => { c2.innerHTML = c1.innerHTML; })
                .observe(c1, { childList: true, subtree: true, characterData: true });
        }

        qsa('input[name="pmk_bfc_mode"]').forEach(radio => {
            radio.addEventListener("change", () => {
                if (!radio.checked) return;
                state.mode = radio.value;
                const label = qs("#pmk-bfc-input-label");
                const ta = qs("#pmk-bfc-input");
                if (state.mode === "barcode") {
                    label.textContent = "Un code-barres d'exemplaire par ligne";
                    ta.placeholder = "0000637178\n0000582144\n0000719321";
                } else {
                    label.textContent = "Un numéro de notice par ligne";
                    ta.placeholder = "379480\n381245\n402117";
                }
            });
        });

        qs("#pmk-bfc-analyze").addEventListener("click", analyze);
        qs("#pmk-bfc-reset").addEventListener("click", resetAll);
        qs("#pmk-bfc-run").addEventListener("click", runBatch);
        qs("#pmk-bfc-stop").addEventListener("click", stopBatch);
        qs("#pmk-bfc-retry").addEventListener("click", retryFailures);
        qs("#pmk-bfc-export").addEventListener("click", exportCSV);

        qs("#pmk-bfc-target-framework").addEventListener("change", ev => {
            state.targetFramework = String(ev.target.value ?? "");
            applyTargetToAll();
        });

        return app;
    }

    async function boot(managedContainer) {
        if (!isOurPage()) return;
        if(state.running){if(managedContainer){managedContainer.textContent="Le lot précédent termine son arrêt. ";const retry=document.createElement("button");retry.type="button";retry.textContent="Réessayer l’ouverture";retry.onclick=()=>window.PMKPages?.refresh();managedContainer.appendChild(retry);}return;}
        applyPageOptions();
        pageContext=managedContainer?.__pmkPageContext||null;
        renderApp(managedContainer);

        // Charge immédiatement la liste complète des grilles depuis
        // Administration > Grilles bibliographiques.
        const allFrameworks = await loadAllFrameworks();
        if (!allFrameworks.length) {
            setStatus(
                "Impossible de charger automatiquement toutes les grilles bibliographiques. " +
                "Le module utilisera les informations disponibles dans les notices analysées.",
                "warning"
            );
        }

        // Vérification informative de la présence du jeton CSRF.
        if (!getCsrfToken()) {
            setStatus(
                "Le jeton CSRF Koha n'est pas visible dans cette page. L'analyse restera possible, " +
                "mais Koha peut refuser les modifications PUT avec une erreur 403.",
                "warning"
            );
        }
    }

    window.PMKBulkFrameworkChange = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        state,
        loadAllFrameworks,
        analyze,
        runBatch,
        retryFailures,
        compareMarc,
        stopBatch,
        reset: resetAll,
        open() {
            window.location.href = `/cgi-bin/koha/mainpage.pl?pmk_page=${encodeURIComponent(PAGE_PARAM)}`;
        }
    };

    function registerPage() {
        return window.PMKPages?.register({id:PAGE_PARAM,mount:async container=>{await boot(container);return stopBatch;}});
    }
    if (!registerPage()) document.addEventListener('pmk:pages-ready',registerPage,{once:true});
    const standaloneBoot=()=>{if(!window.PMKPages)boot();};
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", standaloneBoot, { once: true });
    } else {
        standaloneBoot();
    }

})(window, document);

;window.PMKNonPlugin.loaded.push("141-modif-grille-par-lot.js");
} catch (error) { window.PMKNonPlugin.errors.push("141-modif-grille-par-lot.js: "+error.message); console.error("[PMK] 141-modif-grille-par-lot.js",error); };
try {
/*
 Nom du fichier : 142-bibliography-builder.js
 Module : PimpMyKoha — Bibliographies & publications
 Version : 0.3.0-preplugin
 Date : 2026-10-01

 Dépendances :
 - 000-pmk-config-firestore.js
 - gestionnaire de listes personnelles PMK existant
 - 000-pmk-cover-resolver.js recommandé (moteur transverse partagé avec 066-067)
 - aucune authentification Koha requise par le module 142

 Objectifs V0.1 :
 - source : listes personnelles PMK notices/exemplaires ;
 - source : sélection d'une liste native Koha via la page des listes ;
 - source : paquets Koha (bundles) depuis « Gérer le paquet » ;
 - source : panier Koha ;
 - source : réserves de cours Koha (course_reserves/course-details.pl), y compris réserves notice/exemplaire ;
 - récupération de toutes les réserves même quand le tableau est paginé par DataTables ;
 - injection paquet robuste malgré l'enveloppe DataTables et le chargement asynchrone ;
 - résolution centralisée des couvertures pour listes PMK, listes Koha et paquets ;
 - sélection dynamique du contenu publié : notices et exemplaires masquables/réaffichables sans modifier la source ;
 - rendu : notice / exemplaire / notice + exemplaires ;
 - 9 modèles prédéfinis immuables et duplicables ;
 - modèles personnels stockés dans le même projet stockage Koha et sous le même profil logique que les listes PMK ;
 - aucun écran, compte, e-mail, mot de passe ou état de connexion Koha n'est créé par le module 142 ;
 - éditeur de blocs réordonnables ;
 - données bibliographiques étendues + exemplaires ;
 - codes-barres exemplaires fiabilisés (barcode/external_id) ;
 - récupération exemplaires corrigée (_per_page + fallback public) ;
 - champs item.* utilisables aussi en mode notice + exemplaires ;
 - bibliothèque étendue de blocs bibliographiques et exemplaires ;
 - bloc détails exemplaires + tableau détaillé ;
 - bloc code-barres exemplaire scannable sur papier via le service natif Koha ;
 - résumé métier lu directement en UNIMARC 330$a ;
 - enrichissement MARCXML avec accès générique biblio.marc.TAG.souszone ;
 - habillage de blocs type Word : flux, flottant gauche/droite, pleine largeur, en ligne ;
 - alignement justifié disponible sur les blocs texte ;
 - 9 modèles prédéfinis, dont un modèle dédié aux codes-barres scannables ;
 - QR natif Koha corrigé via /cgi-bin/koha/svc/barcode ;
 - masquage global des numéros de notices ;
 - filtres simples, tri, regroupement ;
 - aperçu HTML A4 ;
 - impression / PDF via navigateur ;
 - export/import JSON des modèles.
 - lien cliquable vers la notice Koha, utilisable en ligne et dans les PDF.
 - interface de configuration restylée en thème vert Koha, sections mieux séparées et plus contrastées.
 - couvertures résolues uniquement via Koha : HTML notice, MARC/856, fournisseurs configurés et endpoint Electre Koha ;
 - réutilisation prioritaire du moteur transverse window.PMKCoverResolver, avec fallback interne historique si absent ;
 - suppression des fallbacks directs Google Books / Open Library / Amazon codés dans le module.
*/
(function (window, document) {
    'use strict';

    if (window.__PMK142_BIBLIOGRAPHY_BUILDER__) return;
    window.__PMK142_BIBLIOGRAPHY_BUILDER__ = true;

    const MODULE_ID = 'bibliography-builder';
    const VERSION = '0.3.0-preplugin';
    const PAGE_PARAM = 'bibliography-builder';
    const PAGE_URL = '/cgi-bin/koha/mainpage.pl?pmk_page=' + PAGE_PARAM;
    const SESSION_SOURCE_KEY = 'pmk142-session-source';
    const ROOT_ID = 'pmk142-root';
    const STYLE_ID = 'pmk142-style';

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        injectPersonalListsButton: true,
        injectKohaListsButton: true,
        injectBundleButton: true,
        injectBasketButton: true,
        injectCourseReservesButton: true,
        defaultTemplate: 'builtin-illustrated',
        defaultMode: 'notice-items',
        defaultPageSize: 'A4',
        defaultOrientation: 'portrait',
        readTimeoutMs:15000,
        readConcurrency:5
    });

    const FIELD_CATALOG = [
        // Notice — champs principaux
        { key: 'biblio.title', label: 'Titre', scope: 'biblio' },
        { key: 'biblio.subtitle', label: 'Sous-titre', scope: 'biblio' },
        { key: 'biblio.author', label: 'Auteur / responsabilité principale', scope: 'biblio' },
        { key: 'biblio.editor', label: 'Éditeur (API)', scope: 'biblio' },
        { key: 'biblio.publisher', label: 'Éditeur (210$c / 214$c)', scope: 'biblio' },
        { key: 'biblio.publication_year', label: 'Année / date d’édition (210$d / 214$d)', scope: 'biblio' },
        { key: 'biblio.summary', label: 'Résumé (330$a)', scope: 'biblio' },
        { key: 'biblio.collection', label: 'Collection (225$a)', scope: 'biblio' },
        { key: 'biblio.isbn', label: 'ISBN (010$a)', scope: 'biblio' },
        { key: 'biblio.public_audience', label: 'Public (999$q)', scope: 'biblio' },
        { key: 'biblio.sublocation_local', label: 'Sous-localisation locale (999$y)', scope: 'biblio' },
        { key: 'biblio.medium', label: 'Support / medium', scope: 'biblio' },
        { key: 'biblio.part_number', label: 'Numéro de partie', scope: 'biblio' },
        { key: 'biblio.part_name', label: 'Nom de partie', scope: 'biblio' },
        { key: 'biblio.uniform_title', label: 'Titre uniforme', scope: 'biblio' },
        { key: 'biblio.series_title', label: 'Titre de série / collection', scope: 'biblio' },
        { key: 'biblio.copyright_date', label: 'Date de publication / copyright', scope: 'biblio' },
        { key: 'biblio.abstract', label: 'Abstract API (si présent)', scope: 'biblio' },
        { key: 'biblio.notes', label: 'Notes', scope: 'biblio' },
        { key: 'biblio.creation_date', label: 'Date de création de la notice', scope: 'biblio' },
        { key: 'biblio.last_modified', label: 'Dernière modification de la notice', scope: 'biblio' },
        { key: 'biblio.framework_id', label: 'Grille / framework', scope: 'biblio' },
        { key: 'biblio.biblionumber', label: 'N° notice', scope: 'biblio' },
        { key: 'biblio.link', label: 'Lien catalogue', scope: 'biblio' },

        // Exemplaire
        { key: 'item.barcode', label: 'Code-barres exemplaire', scope: 'item' },
        { key: 'item.item_id', label: 'N° exemplaire', scope: 'item' },
        { key: 'item.callnumber', label: 'Cote', scope: 'item' },
        { key: 'item.home_library_id', label: 'Site propriétaire', scope: 'item' },
        { key: 'item.holding_library_id', label: 'Site actuel', scope: 'item' },
        { key: 'item.location', label: 'Localisation', scope: 'item' },
        { key: 'item.permanent_location', label: 'Localisation permanente', scope: 'item' },
        { key: 'item.item_type_id', label: 'Type de document', scope: 'item' },
        { key: 'item.not_for_loan_status', label: 'Statut / exclusion du prêt', scope: 'item' },
        { key: 'item.lost_status', label: 'Perdu', scope: 'item' },
        { key: 'item.damaged_status', label: 'Endommagé', scope: 'item' },
        { key: 'item.withdrawn', label: 'Retiré des collections', scope: 'item' },
        { key: 'item.acquisition_date', label: 'Date d’acquisition', scope: 'item' },
        { key: 'item.purchase_price', label: 'Prix d’achat', scope: 'item' },
        { key: 'item.replacement_price', label: 'Prix de remplacement', scope: 'item' },
        { key: 'item.last_checkout_date', label: 'Dernier prêt', scope: 'item' },
        { key: 'item.last_seen_date', label: 'Dernière vue', scope: 'item' }
    ];

    const BUILTIN_TEMPLATES = Object.freeze([
        {
            id: 'builtin-classic',
            builtin: true,
            name: 'Bibliographie classique',
            description: 'Présentation sobre et complète, une colonne, avec résumé UNIMARC.',
            mode: 'notice',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 1, gap: 8, margin: 14 },
            card: { border: false, padding: 5, breakInside: true },
            blocks: [
                block('field', 'biblio.title', 'Titre', {
                    size: 18, weight: 800, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.subtitle', 'Sous-titre', {
                    size: 11, italic: true, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 11, weight: 650, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 10, prefix: 'Éditeur : ', wrapMode: 'inline', blockWidth: 48
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 10, prefix: 'Année : ', wrapMode: 'inline', blockWidth: 42
                }),
                block('field', 'biblio.collection', 'Collection', {
                    size: 9.5, prefix: 'Collection : ', wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.isbn', 'ISBN', {
                    size: 9, prefix: 'ISBN : ', muted: true, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.summary', 'Résumé (330$a)', {
                    size: 9.5, align: 'justify', wrapMode: 'full', blockWidth: 100, wrapGap: 2
                }),
                block('field', 'biblio.biblionumber', 'N° notice', {
                    size: 8, muted: true, prefix: 'Notice : ', wrapMode: 'full', blockWidth: 100
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-illustrated',
            builtin: true,
            name: 'Nouveautés illustrées',
            description: 'Couverture à gauche avec texte habillé, résumé et exemplaires.',
            mode: 'notice-items',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 8, margin: 12 },
            card: { border: true, padding: 7, breakInside: true },
            blocks: [
                block('cover', 'biblio.cover', 'Couverture', {
                    width: 92, height: 132,
                    wrapMode: 'float-left', blockWidth: 32, wrapGap: 2.5
                }),
                block('field', 'biblio.title', 'Titre', {
                    size: 15, weight: 800, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 10, weight: 650, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 9, prefix: 'Éditeur : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 9, prefix: 'Année : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.summary', 'Résumé (330$a)', {
                    size: 8.5, align: 'justify', wrapMode: 'normal', blockWidth: 100
                }),
                block('items', 'items', 'Exemplaires', {
                    size: 8,
                    showBarcode: true,
                    showCallnumber: true,
                    showHomeLibrary: true,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: true,
                    showStatus: true,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true,
                    wrapGap: 2
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-favorite',
            builtin: true,
            name: 'Sélection / Coup de cœur',
            description: 'Présentation éditoriale avec couverture, résumé, QR catalogue et disponibilité.',
            mode: 'notice-items',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 10, margin: 13 },
            card: { border: true, padding: 8, breakInside: true },
            blocks: [
                block('badge', '', 'Coup de cœur', {
                    size: 9, text: 'Coup de cœur',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('cover', 'biblio.cover', 'Couverture', {
                    width: 120, height: 175,
                    wrapMode: 'float-left', blockWidth: 38, wrapGap: 3
                }),
                block('field', 'biblio.title', 'Titre', {
                    size: 17, weight: 850, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 11, weight: 650, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 9, prefix: 'Éditeur : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 9, prefix: 'Année : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.summary', 'Résumé (330$a)', {
                    size: 9.5, align: 'justify', wrapMode: 'normal', blockWidth: 100
                }),
                block('qrcode', 'biblio.link', 'QR catalogue', {
                    size: 82, align: 'center',
                    wrapMode: 'inline', blockWidth: 28, clearBefore: true, wrapGap: 2
                }),
                block('items', 'items', 'Disponibilité / exemplaires', {
                    size: 8,
                    showBarcode: false,
                    showCallnumber: true,
                    showHomeLibrary: true,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: false,
                    showStatus: true,
                    wrapMode: 'inline',
                    blockWidth: 66,
                    wrapGap: 2
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-compact',
            builtin: true,
            name: 'Catalogue compact',
            description: 'Maximum de références par page avec données éditoriales essentielles.',
            mode: 'notice',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 3, gap: 5, margin: 10 },
            card: { border: false, padding: 3, breakInside: true },
            blocks: [
                block('field', 'biblio.title', 'Titre', {
                    size: 10.5, weight: 750, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 8.5, weight: 650, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 7.5, prefix: 'Éd. : ', muted: true, wrapMode: 'inline', blockWidth: 62
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 7.5, prefix: '', muted: true, wrapMode: 'inline', blockWidth: 28
                }),
                block('field', 'biblio.collection', 'Collection', {
                    size: 7.5, prefix: 'Coll. : ', muted: true, wrapMode: 'full', blockWidth: 100
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-exhibition',
            builtin: true,
            name: 'Catalogue d’exposition',
            description: 'Présentation visuelle avec grand visuel, résumé justifié et QR catalogue.',
            mode: 'notice',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 12, margin: 14 },
            card: { border: false, padding: 8, breakInside: true },
            blocks: [
                block('cover', 'biblio.cover', 'Couverture', {
                    width: 150, height: 210, align: 'center',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.title', 'Titre', {
                    size: 19, weight: 850, align: 'center',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 11, align: 'center',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 9, prefix: 'Éditeur : ', align: 'center',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 9, prefix: 'Année : ', align: 'center',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.summary', 'Résumé (330$a)', {
                    size: 9.5, align: 'justify',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('qrcode', 'biblio.link', 'QR catalogue', {
                    size: 90, align: 'center',
                    wrapMode: 'full', blockWidth: 100
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-items',
            builtin: true,
            name: 'Liste d’exemplaires',
            description: 'Une fiche par exemplaire avec localisation détaillée et code-barres scannable.',
            mode: 'item',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 7, margin: 12 },
            card: { border: true, padding: 7, breakInside: true },
            blocks: [
                block('field', 'biblio.title', 'Titre', {
                    size: 13, weight: 800, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 9, weight: 650, wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'item.callnumber', 'Cote', {
                    size: 10, weight: 700, prefix: 'Cote : ',
                    wrapMode: 'inline', blockWidth: 48
                }),
                block('field', 'item.item_type_id', 'Type', {
                    size: 8, prefix: 'Type : ',
                    wrapMode: 'inline', blockWidth: 45
                }),
                block('field', 'item.home_library_id', 'Site propriétaire', {
                    size: 8.5, prefix: 'Site propriétaire : ',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'item.holding_library_id', 'Site actuel', {
                    size: 8.5, prefix: 'Site actuel : ',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'item.location', 'Localisation', {
                    size: 8.5, prefix: 'Localisation : ',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('field', 'item.not_for_loan_status', 'Statut', {
                    size: 8.5, prefix: 'Statut : ',
                    wrapMode: 'full', blockWidth: 100
                }),
                block('barcode-image', 'item.barcode', 'Code-barres exemplaire scannable', {
                    barcodeType: 'Code39',
                    barcodeHeight: 48,
                    imageWidth: 190,
                    showText: true,
                    align: 'center',
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true,
                    wrapGap: 2
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-by-library',
            builtin: true,
            name: 'Nouveautés par bibliothèque',
            description: 'Exemplaires regroupés par site avec informations de notice et détails de localisation.',
            mode: 'item',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 7, margin: 12 },
            card: { border: true, padding: 6, breakInside: true },
            groupBy: 'item.home_library_id',
            blocks: [
                block('cover', 'biblio.cover', 'Couverture', {
                    width: 70, height: 100,
                    wrapMode: 'float-left', blockWidth: 27, wrapGap: 2
                }),
                block('field', 'biblio.title', 'Titre', {
                    size: 13, weight: 800, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 9, weight: 650, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 8, prefix: 'Éditeur : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 8, prefix: 'Année : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('items', 'items', 'Détails exemplaire', {
                    size: 8,
                    showBarcode: true,
                    showCallnumber: true,
                    showHomeLibrary: false,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: true,
                    showStatus: true,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true,
                    wrapGap: 2
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-thematic',
            builtin: true,
            name: 'Bibliographie thématique',
            description: 'Rendu éditorial avec couverture habillée, résumé UNIMARC, collection et QR.',
            mode: 'notice-items',
            showBiblionumber: false,
            page: { size: 'A4', orientation: 'portrait', columns: 2, gap: 9, margin: 13 },
            card: { border: false, padding: 6, breakInside: true },
            coverPage: true,
            blocks: [
                block('cover', 'biblio.cover', 'Couverture', {
                    width: 95, height: 135,
                    wrapMode: 'float-left', blockWidth: 30, wrapGap: 2.5
                }),
                block('field', 'biblio.title', 'Titre', {
                    size: 15, weight: 820, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.author', 'Auteur', {
                    size: 10, weight: 650, wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publisher', 'Éditeur', {
                    size: 8.5, prefix: 'Éditeur : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.publication_year', 'Année', {
                    size: 8.5, prefix: 'Année : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.collection', 'Collection', {
                    size: 8.5, prefix: 'Collection : ', wrapMode: 'normal', blockWidth: 100
                }),
                block('field', 'biblio.summary', 'Résumé (330$a)', {
                    size: 9, align: 'justify', wrapMode: 'normal', blockWidth: 100
                }),
                block('qrcode', 'biblio.link', 'QR catalogue', {
                    size: 76, align: 'center',
                    wrapMode: 'inline', blockWidth: 25,
                    clearBefore: true, wrapGap: 2
                }),
                block('items', 'items', 'Exemplaires', {
                    size: 7.5,
                    showBarcode: false,
                    showCallnumber: true,
                    showHomeLibrary: true,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: false,
                    showStatus: true,
                    wrapMode: 'inline',
                    blockWidth: 70,
                    wrapGap: 2
                })
            ,
                block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 8.5,
                    weight: 650,
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: true
                })]
        },
        {
            id: 'builtin-scannable-barcodes',
            builtin: true,
            name: 'Codes-barres scannables',
            description: 'Nom de la liste en titre, puis uniquement les codes-barres exemplaires scannables en 3 colonnes, avec le numéro sous chaque code-barres.',
            mode: 'item',
            showBiblionumber: false,
            useSourceNameAsTitle: true,
            page: {
                size: 'A4',
                orientation: 'portrait',
                columns: 3,
                gap: 6,
                margin: 10
            },
            card: {
                border: false,
                padding: 5,
                breakInside: true
            },
            blocks: [
                block('barcode-image', 'item.barcode', 'Code-barres exemplaire scannable', {
                    barcodeType: 'Code39',
                    barcodeHeight: 50,
                    imageWidth: 190,
                    showText: true,
                    align: 'center',
                    wrapMode: 'full',
                    blockWidth: 100,
                    clearBefore: false,
                    wrapGap: 2
                })
            ]
        }
    ]);

    let config = { ...DEFAULT_CONFIG };
    let registered = false;
    let builderInitStarted = false;

    // Cache commun à toutes les sources de création.
    const coverResolutionCache = new Map();
    const detailHtmlCache = new Map();
    const readCache = new Map();
    let listsReadyPromise=null, listChoicesPromise=null, listChoices=[];
    let sourceSelection=0, previewPaintTimer=null;
    const readTimeout=()=>Math.max(1000,Math.min(180000,Number(config.readTimeoutMs)||15000));
    function cachedRead(key, read) {
        if(readCache.has(key)) return readCache.get(key);
        const pending=Promise.resolve().then(read);
        readCache.set(key,pending);
        pending.catch(()=>{if(readCache.get(key)===pending)readCache.delete(key);});
        return pending;
    }
    async function boundedFetch(url,options={}) {
        const controller=new AbortController();
        const timer=setTimeout(()=>controller.abort(),readTimeout());
        try {
            const response=await fetch(url,{...options,signal:controller.signal});
            // Optional providers can return large HTML diagnostics on an absent route.
            // Their HTTP status is sufficient for the existing fallback logic.
            if(!response.ok){try{await response.body?.cancel();}catch(_){}return {ok:false,status:response.status,text:async()=>'',json:async()=>{throw new Error('HTTP '+response.status);}};}
            // Consume successful bodies before releasing the timeout.
            const text=await response.text();
            return {ok:response.ok,status:response.status,text:async()=>text,json:async()=>JSON.parse(text)};
        } finally {clearTimeout(timer);}
    }
    function queuePreviewPaint() {
        if(previewPaintTimer)return;
        previewPaintTimer=setTimeout(()=>{previewPaintTimer=null;renderPreview();},200);
    }
    async function listOptions() {
        if(listChoicesPromise)return listChoicesPromise;
        listChoicesPromise=(async()=>{const api=await listsApi();listChoices=api ? await api.getLists() : [];return listChoices;})();
        listChoicesPromise.catch(()=>{listChoicesPromise=null;});
        return listChoicesPromise;
    }
    function updateLoading(operation) {
        if(!operation || operation.revision!==recordsRevision)return;
        current.loading=!operation.dataDone || operation.covers>0;
        current.loadWarning=!current.loading && operation.errors>0;
        document.querySelectorAll('#'+ROOT_ID+' [data-action="retry-notice"]').forEach(button=>{button.disabled=current.loading;});
        const total=operation.total;
        const label=!operation.dataDone ? 'Chargement des notices : '+operation.done+' / '+total
            : operation.covers ? 'Notices chargées — couvertures en cours : '+operation.covers
            : operation.errors ? 'Certaines informations n’ont pas pu être chargées. Les données disponibles sont conservées.' : '';
        setStatus(label);
    }
    function noticeLoaded(operation,biblio) {
        if(!operation)return;
        if(operation.revision===recordsRevision && biblio){current.records.forEach(record=>{if(clean(record.biblio?.biblionumber)===clean(biblio.biblionumber))record.biblio=biblio;});queuePreviewPaint();}
        operation.done++;updateLoading(operation);
    }
    let current = {
        source: null,
        list: null,
        entries: [],
        records: [],
        templates: [],
        selectedTemplateId: '',
        workingTemplate: null,
        title: '',
        mode: DEFAULT_CONFIG.defaultMode,
        selectedBlockId: '',
        loading: false,
        error: '',
        filterText: '',
        groupBy: '',
        sortBy: 'biblio.title',
        allItemsForItemLists: false,
        showBiblionumber: true,
        bundleHostItem: null,
        includeBundleHost: false,
        hiddenBiblios: new Set(),
        hiddenItems: new Set(),
        contentManagerSearch: ''
    };

    function uid(prefix) {
        return (prefix || 'id') + '-' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36);
    }

    function block(type, field, label, style) {
        return {
            id: uid('block'),
            type,
            field: field || '',
            label: label || '',
            hiddenWhenEmpty: true,
            style: {
                size: 10,
                weight: 400,
                italic: false,
                muted: false,
                align: 'left',
                prefix: '',
                suffix: '',
                width: 90,
                height: 130,
                ...style
            }
        };
    }

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    }

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function getPath(obj, path) {
        if (!path) return '';
        return String(path).split('.').reduce((acc, key) => acc == null ? undefined : acc[key], obj);
    }

    function asText(value) {
        if (value == null) return '';
        if (Array.isArray(value)) return value.map(asText).filter(Boolean).join(' • ');
        if (typeof value === 'object') return '';
        return clean(value);
    }

    function query() {
        return new URLSearchParams(window.location.search);
    }

    function isBuilderPage() {
        return query().get('pmk_page') === PAGE_PARAM;
    }

    function isKohaNativeListPage() {
        return /\/virtualshelves\/shelves\.pl$/.test(window.location.pathname);
    }

    function isCatalogueDetailPage() {
        return /\/cgi-bin\/koha\/catalogue\/detail\.pl$/.test(window.location.pathname);
    }

    function isKohaBasketPage() {
        return /\/cgi-bin\/koha\/basket\/basket\.pl$/.test(window.location.pathname)
            || document.body?.id === 'cart_basket';
    }

    function isCourseReservesDetailPage() {
        return /\/cgi-bin\/koha\/course_reserves\/course-details\.pl$/.test(window.location.pathname)
            || document.body?.id === 'courses_course_details';
    }

    function pmkReady() {
        return !!window.PMKPersonalLists;
    }

    async function listsApi() {
        if(window.PMKPersonalLists)return window.PMKPersonalLists;
        if(!listsReadyPromise) listsReadyPromise=(async()=>{
            for(let i=0;i<120 && !window.PMKPersonalLists;i++) await new Promise(resolve=>setTimeout(resolve,50));
            return window.PMKPersonalLists || null;
        })();
        return listsReadyPromise;
    }

    async function storageContext() {
        const api = await listsApi();
        if (!api) return null;

        // The loader exposes this method before the lists runtime is ready.
        // Await it so a first opening also finds the existing personal models.
        if(typeof api.getStorageContext==='function'){
            const context=await api.getStorageContext();
            if(context)return context;
        }

        if (window.PMKConfig && typeof window.PMKConfig.getStorageContext === 'function') {
            try {
                const ctx = await window.PMKConfig.getStorageContext();
                if (ctx) return ctx;
            } catch (_) {}
        }

        return null;
    }

    function normalizeProfileId(value) {
        const id = clean(value);
        return id && id.length <= 160 ? id : '';
    }

    async function resolveActiveProfile() {
        const api = await listsApi();

        /*
         * Le profil est uniquement le profil logique déjà choisi/utilisé
         * par le gestionnaire de listes PMK.
         *
         * Aucun fallback vers un UID, un compte ou une adresse e-mail.
         */

        if (api) {
            try {
                if (typeof api.getProfile === 'function') {
                    const profile = await api.getProfile();
                    const id = normalizeProfileId(
                        profile?.id ||
                        profile?.profileId ||
                        profile?.canonicalName
                    );
                    if (id) return {
                        id,
                        displayName: clean(profile?.displayName || profile?.name || ''),
                        canonicalName: clean(profile?.canonicalName || id)
                    };
                }
            } catch (_) {}

            try {
                if (typeof api.getProfileId === 'function') {
                    const id = normalizeProfileId(await api.getProfileId());
                    if (id) return { id, displayName: '', canonicalName: id };
                }
            } catch (_) {}

            try {
                if (typeof api.getState === 'function') {
                    const state = await api.getState();
                    const profile = state?.profile || null;
                    const id = normalizeProfileId(
                        state?.profileId ||
                        profile?.id ||
                        profile?.profileId ||
                        profile?.canonicalName
                    );
                    if (id) return {
                        id,
                        displayName: clean(profile?.displayName || profile?.name || ''),
                        canonicalName: clean(profile?.canonicalName || id)
                    };
                }
            } catch (_) {}
        }

        const ctx = await storageContext();
        const profile = ctx?.profile || null;
        const id = normalizeProfileId(
            ctx?.profileId ||
            profile?.id ||
            profile?.profileId ||
            profile?.canonicalName
        );

        if (id) {
            return {
                id,
                displayName: clean(profile?.displayName || profile?.name || ''),
                canonicalName: clean(profile?.canonicalName || id)
            };
        }

        return null;
    }

    async function templatesCollection() {
        const ctx = await storageContext();
        const profile = await resolveActiveProfile();

        if (!ctx?.db || !ctx?.firestoreMod) {
            throw new Error(
                'Le stockage stockage Koha PMK n’est pas disponible. ' +
                'Le module 142 ne crée volontairement aucune connexion séparée.'
            );
        }

        if (!profile?.id) {
            throw new Error(
                'Aucun profil logique PMK actif n’a pu être identifié. ' +
                'Le 142 n’ouvrira pas de connexion : il attend le profil déjà utilisé par les listes personnelles.'
            );
        }

        return {
            ctx,
            profile,
            ref: ctx.firestoreMod.collection(
                ctx.db,
                'profiles',
                profile.id,
                'bibliographyTemplates'
            )
        };
    }

    async function loadUserTemplates() {
        try {
            const col = await templatesCollection();
            if (!col) return [];
            const snap = await col.ctx.firestoreMod.getDocs(col.ref);
            return snap.docs.map(doc => ({ id: doc.id, ...doc.data(), builtin: false }));
        } catch (error) {
            console.warn('[PMK142] Modèles personnels indisponibles', error);
            return [];
        }
    }

    async function saveUserTemplate(template, forcedName) {
        const col = await templatesCollection();
        if (!col) throw new Error('Connexion stockage Koha des listes PMK indisponible.');

        const copy = clone(template);
        delete copy.builtin;
        copy.name = clean(forcedName || copy.name || 'Mon modèle').slice(0, 100);
        copy.version = 1;
        copy.updatedAtIso = new Date().toISOString();

        const data = {
            ...copy,
            createdAt: copy.createdAt || col.ctx.firestoreMod.serverTimestamp(),
            updatedAt: col.ctx.firestoreMod.serverTimestamp()
        };

        let id = copy.id && !String(copy.id).startsWith('builtin-') ? copy.id : '';
        if (id) {
            await col.ctx.firestoreMod.setDoc(col.ctx.firestoreMod.doc(col.ref, id), data, { merge: true });
            return id;
        }
        const ref = await col.ctx.firestoreMod.addDoc(col.ref, data);
        return ref.id;
    }

    async function deleteUserTemplate(id) {
        if (!id || String(id).startsWith('builtin-')) return;
        const col = await templatesCollection();
        if (!col) throw new Error('Connexion stockage Koha indisponible.');
        await col.ctx.firestoreMod.deleteDoc(col.ctx.firestoreMod.doc(col.ref, id));
    }

    function normalizeStoredNotice(raw) {
        const biblionumber = clean(raw?.biblionumber || raw?.biblioNumber);
        return {
            biblionumber,
            title: clean(raw?.title) || (biblionumber ? 'Notice #' + biblionumber : 'Notice'),
            subtitle: clean(raw?.subtitle),
            author: clean(raw?.author),
            editor: clean(raw?.editor),
            medium: clean(raw?.medium),
            part_number: clean(raw?.part_number || raw?.partnumber),
            part_name: clean(raw?.part_name || raw?.partname),
            uniform_title: clean(raw?.uniform_title || raw?.unititle),
            series_title: clean(raw?.series_title || raw?.seriestitle),
            copyright_date: clean(raw?.copyright_date || raw?.copyrightdate),
            abstract: clean(raw?.abstract),
            notes: clean(raw?.notes),
            creation_date: clean(raw?.creation_date || raw?.datecreated),
            last_modified: clean(raw?.last_modified || raw?.timestamp),
            framework_id: clean(raw?.framework_id || raw?.frameworkcode),
            link: clean(raw?.link) || (biblionumber ? '/cgi-bin/koha/catalogue/detail.pl?biblionumber=' + encodeURIComponent(biblionumber) : ''),
            cover: clean(raw?.imgSrc || raw?.cover || raw?.image),
            coverCandidates: Array.isArray(raw?.coverCandidates) ? raw.coverCandidates : [],
            raw: raw || {}
        };
    }

    function normalizeStoredItem(raw) {
        return {
            item_id: clean(raw?.itemNumber || raw?.itemnumber || raw?.item_id),
            barcode: clean(raw?.codeBarre || raw?.barcode || raw?.external_id),
            home_library_id: clean(raw?.site || raw?.homebranch || raw?.home_library_id),
            holding_library_id: clean(raw?.holdingbranch || raw?.holding_library_id),
            callnumber: clean(raw?.cote || raw?.itemcallnumber || raw?.callnumber),
            item_type_id: clean(raw?.type || raw?.itype || raw?.item_type_id),
            location: clean(raw?.location),
            permanent_location: clean(raw?.permanent_location),
            not_for_loan_status: raw?.not_for_loan_status ?? raw?.notforloan ?? '',
            acquisition_date: clean(raw?.acquisition_date || raw?.dateaccessioned),
            purchase_price: raw?.purchase_price ?? raw?.price ?? '',
            replacement_price: raw?.replacement_price ?? raw?.replacementprice ?? '',
            lost_status: raw?.lost_status ?? raw?.itemlost ?? '',
            damaged_status: raw?.damaged_status ?? raw?.damaged ?? '',
            withdrawn: raw?.withdrawn ?? raw?.wthdrawn ?? '',
            last_checkout_date: clean(raw?.last_checkout_date || raw?.datelastborrowed),
            last_seen_date: clean(raw?.last_seen_date || raw?.datelastseen),
            biblionumber: clean(raw?.biblionumber || raw?.biblioNumber || raw?.biblio_id),
            title: clean(raw?.title || raw?.biblio?.title),
            subtitle: clean(raw?.subtitle || raw?.biblio?.subtitle),
            raw: raw || {}
        };
    }

    function normalizeApiItem(raw, bib) {
        return {
            item_id: clean(raw?.item_id || raw?.itemnumber),
            // Koha REST récent expose le code-barres sous external_id.
            // On garde aussi barcode pour compatibilité avec les versions / réponses plus anciennes.
            barcode: clean(raw?.barcode || raw?.external_id),
            home_library_id: clean(raw?.home_library_id || raw?.homebranch),
            holding_library_id: clean(raw?.holding_library_id || raw?.holdingbranch),
            callnumber: clean(raw?.callnumber || raw?.itemcallnumber),
            item_type_id: clean(raw?.item_type_id || raw?.itype),
            location: clean(raw?.location),
            permanent_location: clean(raw?.permanent_location),
            not_for_loan_status: raw?.not_for_loan_status ?? raw?.notforloan ?? '',
            lost_status: raw?.lost_status ?? raw?.itemlost ?? '',
            damaged_status: raw?.damaged_status ?? raw?.damaged ?? '',
            withdrawn: raw?.withdrawn ?? raw?.wthdrawn ?? '',
            acquisition_date: clean(raw?.acquisition_date || raw?.dateaccessioned),
            purchase_price: raw?.purchase_price ?? raw?.price ?? '',
            replacement_price: raw?.replacement_price ?? raw?.replacementprice ?? '',
            last_checkout_date: clean(raw?.last_checkout_date || raw?.datelastborrowed),
            last_seen_date: clean(raw?.last_seen_date || raw?.datelastseen),
            biblionumber: clean(raw?.biblio_id || raw?.biblionumber || bib),
            raw
        };
    }

    function fetchJson(url) {
        return cachedRead('json:'+url,async()=>{
            const response=await boundedFetch(url,{credentials:'same-origin',headers:{Accept:'application/json'}});
            if(!response.ok)throw new Error('HTTP '+response.status+' — '+url);
            return response.json();
        });
    }

    function absoluteUrl(value) {
        const url = clean(value);
        if (!url) return '';
        try {
            return new URL(url, window.location.origin).href;
        } catch (_) {
            return url;
        }
    }

    function normalizeIsbn(value) {
        const source = Array.isArray(value) ? value[0] : value;
        const first = clean(source).split(/[\s,;]+/)[0] || '';
        return first.replace(/[^0-9Xx]/g, '').toUpperCase();
    }

    function isbnValues(value) {
        const source = Array.isArray(value) ? value : [value];
        const out = [];

        source.forEach(entry => {
            String(entry || '')
                .split(/[\s,;|]+/)
                .map(part => normalizeIsbn(part))
                .filter(Boolean)
                .forEach(isbn => {
                    if (!out.includes(isbn)) out.push(isbn);
                });
        });

        return out;
    }

    function isbn13to10(value) {
        const isbn = normalizeIsbn(value);

        if (/^\d{9}[\dX]$/.test(isbn)) {
            return isbn;
        }

        if (!/^978\d{10}$/.test(isbn)) return '';

        const core = isbn.slice(3, 12);
        let sum = 0;

        for (let i = 0; i < 9; i += 1) {
            sum += (10 - i) * Number(core[i]);
        }

        const check = (11 - (sum % 11)) % 11;
        return core + (check === 10 ? 'X' : String(check));
    }

    function electreIsbn10Candidates(biblio, marc) {
        const values = [
            ...isbnValues(biblio?.isbn),
            ...isbnValues(marcValue(marc || {}, '010', 'a'))
        ];

        const out = [];
        values.forEach(value => {
            const isbn10 = isbn13to10(value);
            if (isbn10 && !out.includes(isbn10)) out.push(isbn10);
        });

        return out;
    }

    function uniqueCoverCandidates(values) {
        const out = [];
        const seen = new Set();

        (values || []).flat(Infinity).forEach(value => {
            const url = absoluteUrl(value);
            if (!url) return;

            const lowered = url.toLowerCase();
            if (
                lowered.includes('/img/spinner')
                || lowered.includes('favicon')
                || lowered.includes('blank.gif')
                || lowered.includes('transparent')
                || lowered === 'about:blank'
            ) return;

            if (seen.has(url)) return;
            seen.add(url);
            out.push(url);
        });

        return out;
    }

    async function fetchDetailHtml(biblionumber) {
        const id = clean(biblionumber);
        if (!id) return '';

        if (detailHtmlCache.has(id)) {
            return await detailHtmlCache.get(id);
        }

        const promise = (async () => {
            const response = await boundedFetch(
                '/cgi-bin/koha/catalogue/detail.pl?biblionumber=' + encodeURIComponent(id),
                {
                    credentials: 'same-origin',
                    headers: { Accept: 'text/html,application/xhtml+xml' }
                }
            );

            if (!response.ok) {
                throw new Error('HTTP ' + response.status + ' — fiche notice ' + id);
            }

            return await response.text();
        })();

        detailHtmlCache.set(id, promise);

        try {
            return await promise;
        } catch (error) {
            detailHtmlCache.delete(id);
            throw error;
        }
    }

    function imgCandidateUrls(img) {
        if (!img) return [];

        const urls = [
            img.getAttribute('src'),
            img.getAttribute('data-src'),
            img.getAttribute('data-original'),
            img.getAttribute('data-lazy-src')
        ];

        const srcset = clean(img.getAttribute('srcset'));
        if (srcset) {
            srcset.split(',').forEach(part => {
                const url = clean(part.trim().split(/\s+/)[0]);
                if (url) urls.push(url);
            });
        }

        return uniqueCoverCandidates(urls);
    }

    function extractKohaCoverCandidatesFromHtml(htmlText) {
        if (!htmlText) return [];

        const doc = new DOMParser().parseFromString(htmlText, 'text/html');
        const urls = [];

        /*
         * Tout ce qui suit provient du HTML produit par Koha :
         * - couvertures locales ;
         * - Amazon/Syndetics/CustomCoverImages si Koha les a activés ;
         * - éventuels fournisseurs/plugins ayant déjà injecté une URL statique ;
         * - fallback 856 rendu par les XSLT Dracénie (.imgcouv/.imgcouvlist).
         */
        [
            '#biblio-cover-slider .cover-image img',
            '.bookcoverimg .cover-image img',
            '#biblio-cover-slider img',
            '.bookcoverimg img',
            '#custom-img',
            '.imgcouv',
            '.imgcouvlist',
            '.thumbimg'
        ].forEach(selector => {
            doc.querySelectorAll(selector).forEach(img => {
                urls.push(...imgCandidateUrls(img));

                // Pour les couvertures locales Koha, ajoute aussi l'image pleine taille.
                const link = img.closest('a[href]')?.getAttribute('href');
                if (link && /\/catalogue\/image\.pl\?/i.test(link)) {
                    urls.push(link);
                }
            });
        });

        return uniqueCoverCandidates(urls);
    }

    function extractLiveKohaCoverCandidates(biblionumber) {
        const bibId = clean(biblionumber);
        if (!bibId) return [];

        const currentBib = clean(
            new URL(window.location.href).searchParams.get('biblionumber')
        );

        if (!isCatalogueDetailPage() || currentBib !== bibId) return [];

        const urls = [];

        document.querySelectorAll(
            '#biblio-cover-slider img, .bookcoverimg img, .imgcouv, .imgcouvlist, .thumbimg'
        ).forEach(img => {
            urls.push(...imgCandidateUrls(img));
        });

        return uniqueCoverCandidates(urls);
    }

    function marc856CoverCandidates(marc) {
        const raw = marcValue(marc || {}, '856', 'u');
        const values = Array.isArray(raw) ? raw : [raw];

        /*
         * On garde les URL 856 en dernier recours.
         * Si l'URL pointe vers une page HTML plutôt qu'une image, l'événement
         * error du <img> fera simplement passer au candidat suivant.
         */
        return uniqueCoverCandidates(
            values
                .map(value => clean(value))
                .filter(value => /^https?:\/\//i.test(value) || value.startsWith('/'))
        );
    }

    async function fetchElectreCoverViaKoha(biblio, marc) {
        const candidates = electreIsbn10Candidates(biblio, marc);
        if (!candidates.length) return '';

        for (const isbn10 of candidates) {
            const url = '/api/v1/contrib/electre/image'
                + '?isbn10=' + encodeURIComponent(isbn10)
                + '&side=staff'
                + '&result_page=true';

            try {
                const response = await boundedFetch(url, {
                    credentials: 'same-origin',
                    headers: { Accept: 'text/plain, application/json;q=0.9, */*;q=0.8' }
                });

                /*
                 * 404/403 signifie simplement que l'endpoint n'est pas disponible
                 * ou qu'aucune image n'est fournie. On continue sans casser le 142.
                 */
                if (!response.ok) continue;

                let value = clean(await response.text());
                value = value.replace(/^"(.*)"$/s, '$1').trim();

                if (value && value !== 'null' && value !== 'undefined') {
                    return absoluteUrl(value);
                }
            } catch (error) {
                console.warn('[PMK142] Electre via Koha indisponible pour', isbn10, error);
            }
        }

        return '';
    }

    async function resolveCoverCandidates(biblio, marc) {
        // Moteur commun PMK : si disponible, le 142 partage exactement la même
        // résolution et le même cache que les listes personnelles 066-067.
        const sharedResolver = window.PMKCoverResolver;
        if (sharedResolver && typeof sharedResolver.resolveCandidates === 'function') {
            try {
                return await sharedResolver.resolveCandidates({
                    ...(biblio || {}),
                    imgSrc: clean(biblio?.cover),
                    cover: clean(biblio?.cover),
                    coverCandidates: Array.isArray(biblio?.coverCandidates) ? biblio.coverCandidates : []
                }, { marc: marc || biblio?.marc || {} });
            } catch (error) {
                console.warn('[PMK142] Moteur transverse couvertures indisponible, fallback interne', error);
            }
        }

        const bibId = clean(biblio?.biblionumber);
        const isbn = normalizeIsbn(
            biblio?.isbn || firstMarcValue(marc || {}, [['010', 'a']])
        );
        const cacheKey = bibId || ('isbn:' + isbn);

        if (cacheKey && coverResolutionCache.has(cacheKey)) {
            return await coverResolutionCache.get(cacheKey);
        }

        const promise = (async () => {
            const sourceCandidates = uniqueCoverCandidates([
                biblio?.cover,
                ...(Array.isArray(biblio?.coverCandidates) ? biblio.coverCandidates : [])
            ]);

            const liveCandidates = extractLiveKohaCoverCandidates(bibId);

            let detailCandidates = [];
            if (bibId) {
                try {
                    detailCandidates = extractKohaCoverCandidatesFromHtml(
                        await fetchDetailHtml(bibId)
                    );
                } catch (error) {
                    console.warn('[PMK142] Couvertures fiche Koha indisponibles', bibId, error);
                }
            }

            /*
             * Electre est interrogé UNIQUEMENT via l'endpoint Koha déjà installé.
             * Aucun token, domaine fournisseur ou paramétrage externe n'est stocké
             * dans le module 142.
             */
            const electreCandidate = await fetchElectreCoverViaKoha(biblio, marc);

            const marc856Candidates = marc856CoverCandidates(marc);

            /*
             * Priorité :
             * 1. DOM Koha déjà rendu dynamiquement (si on est sur la notice) ;
             * 2. HTML de detail.pl et fournisseurs activés par Koha ;
             * 3. Electre via endpoint Koha ;
             * 4. couverture déjà transmise par la source ;
             * 5. 856 de la notice en dernier recours.
             *
             * Aucun appel direct à Google Books, Open Library ou Amazon n'est
             * construit par le 142. Si Amazon/Syndetics/etc. apparaissent ici,
             * c'est uniquement parce que Koha les a lui-même rendus dans detail.pl.
             */
            return uniqueCoverCandidates([
                liveCandidates,
                detailCandidates,
                electreCandidate,
                sourceCandidates,
                marc856Candidates
            ]);
        })();

        if (cacheKey) coverResolutionCache.set(cacheKey, promise);

        try {
            return await promise;
        } catch (error) {
            if (cacheKey) coverResolutionCache.delete(cacheKey);
            console.warn('[PMK142] Résolution couverture Koha impossible', cacheKey, error);
            return uniqueCoverCandidates([biblio?.cover, marc856CoverCandidates(marc)]);
        }
    }

    function activateCoverFallbacks(container) {
        if (!container) return;

        container.querySelectorAll('img.pmk142-cover[data-cover-candidates]').forEach(img => {
            if (img.dataset.coverFallbackBound === '1') return;
            img.dataset.coverFallbackBound = '1';

            let candidates = [];
            try {
                candidates = JSON.parse(img.dataset.coverCandidates || '[]');
            } catch (_) {}

            candidates = uniqueCoverCandidates(candidates);
            let index = Math.max(0, candidates.indexOf(img.src));

            function tryNext() {
                index += 1;
                if (index >= candidates.length) {
                    img.style.display = 'none';
                    return;
                }
                img.src = candidates[index];
            }

            img.addEventListener('error', tryNext);

            // Certaines sources renvoient une image vide/minuscule plutôt qu'une 404.
            img.addEventListener('load', () => {
                if (
                    img.naturalWidth > 0 &&
                    img.naturalHeight > 0 &&
                    (img.naturalWidth < 20 || img.naturalHeight < 20)
                ) {
                    tryNext();
                }
            });
        });
    }

    function fetchMarcXml(url) {
        return cachedRead("marc:"+url,async()=>{
        const response = await boundedFetch(url, {
            credentials: 'same-origin',
            headers: { Accept: 'application/marcxml+xml' }
        });

        if (!response.ok) {
            throw new Error('HTTP ' + response.status + ' — ' + url);
        }

        const xml = await response.text();
        if (!xml || !/<(?:\w+:)?record\b/i.test(xml)) {
            throw new Error('Réponse MARCXML invalide — ' + url);
        }
        return xml;
        });
    }

    function addMarcValue(target, tag, code, value) {
        const cleanValue = clean(value);
        if (!cleanValue) return;

        if (!target[tag]) target[tag] = {};
        const previous = target[tag][code];

        if (previous == null || previous === '') {
            target[tag][code] = cleanValue;
        } else if (Array.isArray(previous)) {
            if (!previous.includes(cleanValue)) previous.push(cleanValue);
        } else if (previous !== cleanValue) {
            target[tag][code] = [previous, cleanValue];
        }
    }

    function parseMarcXml(xmlText) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(xmlText, 'application/xml');

        if (doc.querySelector('parsererror')) {
            throw new Error('MARCXML illisible.');
        }

        const marc = {};
        const fields = Array.from(doc.getElementsByTagNameNS('*', 'datafield'));

        fields.forEach(field => {
            const tag = clean(field.getAttribute('tag'));
            if (!tag) return;

            Array.from(field.getElementsByTagNameNS('*', 'subfield')).forEach(subfield => {
                const code = clean(subfield.getAttribute('code'));
                if (!code) return;
                addMarcValue(marc, tag, code, subfield.textContent);
            });
        });

        return marc;
    }

    function marcValue(marc, tag, code) {
        return marc?.[String(tag)]?.[String(code)] ?? '';
    }

    function firstMarcValue(marc, candidates) {
        for (const [tag, code] of candidates) {
            const value = marcValue(marc, tag, code);
            if (Array.isArray(value)) {
                const first = value.find(Boolean);
                if (first) return first;
            } else if (clean(value)) {
                return clean(value);
            }
        }
        return '';
    }

    async function fetchMarcForBiblio(biblionumber, strict=false) {
        if (!biblionumber) return {};

        const id = encodeURIComponent(biblionumber);
        const candidates = [
            '/api/v1/biblios/' + id,
            '/api/v1/public/biblios/' + id
        ];

        for (const url of candidates) {
            try {
                return parseMarcXml(await fetchMarcXml(url));
            } catch (error) {
                console.warn('[PMK142] MARCXML indisponible', url, error);
            }
        }

        if(strict)throw new Error("MARCXML indisponible pour la notice "+biblionumber);
        return {};
    }

    async function fetchItemsForBiblio(biblionumber) {
        if (!biblionumber) return [];

        const id = encodeURIComponent(biblionumber);
        const candidates = [
            '/api/v1/biblios/' + id + '/items?_per_page=200',
            '/api/v1/public/biblios/' + id + '/items?_per_page=200'
        ];

        for (const url of candidates) {
            try {
                const data = await fetchJson(url);
                const rows = Array.isArray(data) ? data : (data?.items || []);
                return rows.map(item => normalizeApiItem(item, biblionumber));
            } catch (error) {
                console.warn('[PMK142] Essai API exemplaires échoué', url, error);
            }
        }

        return [];
    }

    async function fetchItemById(itemId, fallbackBiblionumber) {
        const id = clean(itemId);
        if (!id) return null;

        try {
            const raw = await fetchJson('/api/v1/items/' + encodeURIComponent(id));
            return normalizeApiItem(raw, fallbackBiblionumber);
        } catch (error) {
            console.warn('[PMK142] API exemplaire indisponible pour', id, error);
            return null;
        }
    }

    async function fetchBundleItems(bundleItemId) {
        const id = clean(bundleItemId);
        if (!id) return [];

        const perPage = 100;
        const out = [];

        for (let page = 1; page <= 100; page += 1) {
            const url = '/api/v1/items/' + encodeURIComponent(id)
                + '/bundled_items?_per_page=' + perPage
                + '&_page=' + page;

            const rows = await fetchJson(url);
            const batch = Array.isArray(rows) ? rows : (rows?.items || []);

            if (!batch.length) break;
            out.push(...batch);

            if (batch.length < perPage) break;
        }

        return out;
    }

    async function fetchBundleHostItem(bundleItemId) {
        const id = clean(bundleItemId);
        if (!id) return null;

        try {
            return await fetchJson('/api/v1/items/' + encodeURIComponent(id));
        } catch (error) {
            console.warn('[PMK142] Exemplaire hôte du paquet indisponible', id, error);
            return null;
        }
    }

    function bundleSourceName(bundleItemId, hostItem) {
        const pageTitle = clean(document.querySelector('h1')?.textContent)
            .replace(/^Détails pour\\s*/i, '')
            .replace(/^Details for\\s*/i, '');

        const barcode = clean(hostItem?.external_id || hostItem?.barcode);
        const suffix = barcode || ('exemplaire ' + bundleItemId);

        return pageTitle
            ? 'Paquet — ' + pageTitle + ' — ' + suffix
            : 'Paquet — ' + suffix;
    }

    async function openBundleBibliography(bundleItemId, button) {
        const itemId = clean(bundleItemId);
        if (!itemId) return;

        const originalHtml = button?.innerHTML || '';

        if (button) {
            button.disabled = true;
            button.innerHTML = '<i class="fa-solid fa-spinner fa-spin" aria-hidden="true"></i> Chargement…';
        }

        try {
            const [items, hostItem] = await Promise.all([
                fetchBundleItems(itemId),
                fetchBundleHostItem(itemId)
            ]);

            if (!items.length) {
                alert('Ce paquet ne contient actuellement aucun exemplaire.');
                return;
            }

            const payload = {
                kind: 'koha-bundle',
                type: 'item',
                name: bundleSourceName(itemId, hostItem),
                bundleItemId: itemId,
                hostItem: hostItem || null,
                entries: items
            };

            sessionStorage.setItem(SESSION_SOURCE_KEY, JSON.stringify(payload));
            window.location.href = PAGE_URL + '&source=session&bundle=' + encodeURIComponent(itemId);
        } catch (error) {
            console.error('[PMK142] Impossible de charger le paquet', error);
            alert('Impossible de charger le contenu du paquet. Vérifiez vos droits sur l’API Koha.');
        } finally {
            if (button && document.contains(button)) {
                button.disabled = false;
                button.innerHTML = originalHtml;
            }
        }
    }

    function findBundleScope(table) {
        if (!table) return null;

        return table.closest('td.bundle')
            || table.closest('tr.bundle')
            || table.closest('.bundle')
            || table.closest('td')
            || table.parentElement;
    }

    function hasBundleBibliographyButton(scope, bundleItemId) {
        if (!scope || !bundleItemId) return false;

        return Array.from(
            scope.querySelectorAll('.pmk142-bundle-bibliography[data-bundle-item]')
        ).some(button => clean(button.dataset.bundleItem) === clean(bundleItemId));
    }

    function findOrCreateBundleToolbar(table, bundleItemId) {
        const scope = findBundleScope(table);
        if (!scope) return null;

        let toolbar = scope.querySelector('.btn-toolbar');

        if (toolbar) {
            return toolbar;
        }

        /*
         * DataTables peut avoir déjà enveloppé table.tbundle dans plusieurs
         * conteneurs. Si la barre native Koha n'est plus accessible dans le
         * sous-arbre immédiat, on crée une barre PMK juste au-dessus du
         * wrapper du tableau.
         */
        const wrapper =
            table.closest('.dt-container')
            || table.closest('.dataTables_wrapper')
            || table;

        toolbar = document.createElement('div');
        toolbar.className = 'btn-toolbar pmk142-bundle-toolbar';
        toolbar.dataset.bundleItem = bundleItemId;
        toolbar.setAttribute('role', 'toolbar');
        toolbar.style.marginBottom = '8px';

        wrapper.parentNode?.insertBefore(toolbar, wrapper);

        return toolbar;
    }

    function injectBundleBibliographyButtons() {
        if (!config.enabled || !config.injectBundleButton || !isCatalogueDetailPage()) return;

        document.querySelectorAll('table.tbundle[data-itemnumber]').forEach(table => {
            const bundleItemId = clean(table.dataset.itemnumber);
            if (!bundleItemId) return;

            const scope = findBundleScope(table);
            if (!scope) return;

            if (hasBundleBibliographyButton(scope, bundleItemId)) return;

            const toolbar = findOrCreateBundleToolbar(table, bundleItemId);
            if (!toolbar) return;

            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'btn btn-default pmk142-bundle-bibliography';
            button.dataset.bundleItem = bundleItemId;
            button.innerHTML =
                '<i class="fa-solid fa-file-lines" aria-hidden="true"></i> ' +
                'Créer une bibliographie';
            button.title = 'Créer une bibliographie à partir des exemplaires de ce paquet';

            button.addEventListener('click', () => openBundleBibliography(bundleItemId, button));
            toolbar.appendChild(button);
        });
    }

    let bundleInjectionTimer = null;

    function scheduleBundleBibliographyInjection() {
        if (!isCatalogueDetailPage()) return;

        if (bundleInjectionTimer) {
            window.clearTimeout(bundleInjectionTimer);
        }

        bundleInjectionTimer = window.setTimeout(() => {
            bundleInjectionTimer = null;
            injectBundleBibliographyButtons();

            /*
             * Le contenu du paquet est construit puis transformé en DataTable
             * de façon asynchrone par Koha. On refait quelques passes courtes
             * pour couvrir ces différentes étapes sans polling permanent.
             */
            [120, 350, 800, 1500].forEach(delay => {
                window.setTimeout(injectBundleBibliographyButtons, delay);
            });
        }, 0);
    }

    function installBundleOpenHook() {
        if (!isCatalogueDetailPage()) return;
        if (window.__PMK142_BUNDLE_OPEN_HOOK__) return;
        window.__PMK142_BUNDLE_OPEN_HOOK__ = true;

        document.addEventListener('click', event => {
            if (!event.target.closest(
                '#holdings_table tbody button.details-control, ' +
                '#otherholdings_table tbody button.details-control'
            )) return;

            scheduleBundleBibliographyInjection();
        }, true);
    }

    async function enrichNotice(biblio, options = {}) {
        if (!biblio?.biblionumber) return biblio;

        // Une actualisation indisponible conserve le dernier contenu déjà reçu.
        let raw = biblio.api || null;
        let marc = biblio.marc || {};

        const [jsonResult, marcResult] = await Promise.allSettled([
            fetchJson('/api/v1/biblios/' + encodeURIComponent(biblio.biblionumber)),
            fetchMarcForBiblio(biblio.biblionumber,true)
        ]);

        if (jsonResult.status === 'fulfilled') raw = jsonResult.value;
        if(options.operation && (jsonResult.status==='rejected' || marcResult.status==='rejected'))options.operation.errors++;
        if (marcResult.status === 'fulfilled') marc = marcResult.value || {};

        const summary330 = firstMarcValue(marc, [['330', 'a']]);
        const publisher = firstMarcValue(marc, [['214', 'c'], ['210', 'c']]);
        const publicationYear = firstMarcValue(marc, [['214', 'd'], ['210', 'd']]);
        const collection = firstMarcValue(marc, [['225', 'a']]);
        const isbn = firstMarcValue(marc, [['010', 'a']]);
        const publicAudience = firstMarcValue(marc, [['999', 'q']]);
        const sublocationLocal = firstMarcValue(marc, [['999', 'y']]);

        const enriched = {
            ...biblio,
            _pmkSources:{at:new Date().toISOString(),json:jsonResult.status==='fulfilled',marc:marcResult.status==='fulfilled'},
            title: clean(raw?.title) || biblio.title,
            subtitle: clean(raw?.subtitle) || biblio.subtitle,
            author: clean(raw?.author) || biblio.author,
            editor: clean(raw?.editor) || biblio.editor,
            publisher: publisher || biblio.publisher || '',
            publication_year: publicationYear || biblio.publication_year || '',
            summary: summary330 || biblio.summary || '',
            collection: collection || biblio.collection || '',
            isbn: isbn || biblio.isbn || '',
            public_audience: publicAudience || biblio.public_audience || '',
            sublocation_local: sublocationLocal || biblio.sublocation_local || '',
            medium: clean(raw?.medium) || biblio.medium,
            part_number: clean(raw?.part_number || raw?.partnumber) || biblio.part_number,
            part_name: clean(raw?.part_name || raw?.partname) || biblio.part_name,
            uniform_title: clean(raw?.uniform_title || raw?.unititle) || biblio.uniform_title,
            series_title: clean(raw?.series_title || raw?.seriestitle) || biblio.series_title,
            copyright_date: clean(raw?.copyright_date || raw?.copyrightdate) || biblio.copyright_date,
            abstract: clean(raw?.abstract) || biblio.abstract,
            notes: clean(raw?.notes) || biblio.notes,
            creation_date: clean(raw?.creation_date || raw?.datecreated) || biblio.creation_date,
            last_modified: clean(raw?.last_modified || raw?.timestamp) || biblio.last_modified,
            framework_id: clean(raw?.framework_id || raw?.frameworkcode) || biblio.framework_id,
            marc,
            api: raw,
            raw: { ...(biblio.raw || {}), api: raw, marc }
        };

        const operation=options.operation;
        const needsCovers=!operation || current.workingTemplate?.blocks?.some(block=>block.type==='cover');
        if(needsCovers) {
            const coverTask=resolveCoverCandidates(enriched,marc);
            const assign=candidates=>{enriched.coverCandidates=candidates;enriched.cover=candidates[0] || clean(biblio.cover);};
            if(operation) {
                operation.covers++;
                let timer;
                Promise.race([coverTask,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Délai couvertures dépassé')),readTimeout());})])
                    .then(candidates=>{assign(candidates);if(operation.revision===recordsRevision)queuePreviewPaint();})
                    .catch(()=>{operation.errors++;})
                    .finally(()=>{clearTimeout(timer);operation.covers--;updateLoading(operation);});
            } else assign(await coverTask);
        }

        return enriched;
    }

    // Pool borné : les notices indépendantes ne doivent pas être traitées en série.
    // La limite protège le serveur Koha et les fournisseurs de couvertures.
    async function mapConcurrent(values, concurrency, mapper) {
        const results = new Array(values.length);
        let next = 0;
        const workers = Array.from({ length: Math.min(concurrency, values.length) }, async () => {
            while (next < values.length) {
                const index = next++;
                results[index] = await mapper(values[index], index);
            }
        });
        await Promise.all(workers);
        return results;
    }

    async function buildRecordsFromPmk(list, entries, mode, allItemsForItemLists, operation) {
        const listType = list?.type || 'notice';

        if (listType === 'notice') {
            const notices = entries.map(normalizeStoredNotice);
            const records = await mapConcurrent(notices, Math.max(1,Math.min(5,Number(config.readConcurrency)||5)), async biblio => {
                const [enriched, items] = await Promise.all([
                    enrichNotice(biblio,{operation}),
                    mode === 'notice' ? Promise.resolve([]) : fetchItemsForBiblio(biblio.biblionumber)
                ]);
                noticeLoaded(operation,enriched);
                if (mode === 'item') {
                    return items.length
                        ? items.map(item => ({ biblio: enriched, item, items: [item] }))
                        : [{ biblio: enriched, item: null, items: [] }];
                }
                return [{ biblio: enriched, item: null, items }];
            });
            return records.flat();
        }

        const selectedItems = entries.map(normalizeStoredItem);
        const grouped = new Map();
        selectedItems.forEach(item => {
            const key = item.biblionumber || ('item:' + item.item_id);
            if (!grouped.has(key)) grouped.set(key, []);
            grouped.get(key).push(item);
        });

        const records = await mapConcurrent([...grouped.entries()], Math.max(1,Math.min(5,Number(config.readConcurrency)||5)), async ([bib, group]) => {
            const first = group[0];
            const [biblio, fetched] = await Promise.all([
                enrichNotice(normalizeStoredNotice({
                    biblionumber: first.biblionumber,
                    title: first.title,
                    subtitle: first.subtitle
                }),{operation}),
                allItemsForItemLists && first.biblionumber
                    ? fetchItemsForBiblio(first.biblionumber)
                    : Promise.resolve([])
            ]);
            noticeLoaded(operation,biblio);
            const items = fetched.length ? fetched : group;
            return mode === 'item'
                ? items.map(item => ({ biblio, item, items: [item] }))
                : [{ biblio, item: null, items }];
        });
        return records.flat();
    }

    async function buildRecordsFromCourseReserves(entries, mode, allItemsForCourse, operation) {
        const grouped = new Map();

        (entries || []).forEach(raw => {
            const bib = clean(raw?.biblionumber || raw?.biblioNumber || raw?.biblio_id);
            if (!bib) return;

            if (!grouped.has(bib)) grouped.set(bib, []);
            grouped.get(bib).push(raw);
        });

        const rows=await mapConcurrent([...grouped.entries()],3,async([bib,group])=>{
            const out=[];
            const first = group[0] || {};
            const biblio = await enrichNotice(normalizeStoredNotice({
                biblionumber: bib,
                title: first.title,
                subtitle: first.subtitle,
                author: first.author,
                link: first.link
            }),{operation});

            noticeLoaded(operation,biblio);
            if (mode === 'notice') {
                out.push({ biblio, item: null, items: [] });
                return out;
            }

            const hasBiblioLevelReserve = group.some(entry =>
                !clean(entry?.item_id || entry?.itemnumber || entry?.itemNumber)
            );

            const selectedItems = [];
            for (const entry of group) {
                const itemId = clean(entry?.item_id || entry?.itemnumber || entry?.itemNumber);
                if (!itemId) continue;

                const fetched = await fetchItemById(itemId, bib);
                const normalized = fetched || normalizeStoredItem(entry);

                if (
                    normalized?.item_id &&
                    !selectedItems.some(item => itemVisibilityKey(item) === itemVisibilityKey(normalized))
                ) {
                    selectedItems.push(normalized);
                }
            }

            let items = selectedItems;

            /*
             * Une réserve au niveau notice porte sur la notice entière :
             * dans les modes qui affichent les exemplaires, on récupère donc
             * les exemplaires de la notice. L'option "tous les exemplaires"
             * permet aussi d'élargir volontairement une réserve item-level.
             */
            if ((hasBiblioLevelReserve || allItemsForCourse) && bib) {
                const fetched = await fetchItemsForBiblio(bib);
                if (fetched.length) items = fetched;
            }

            if (mode === 'item') {
                if (items.length) {
                    items.forEach(item => out.push({ biblio, item, items: [item] }));
                } else {
                    out.push({ biblio, item: null, items: [] });
                }
            } else {
                out.push({ biblio, item: null, items });
            }
            return out;
        });
        return rows.flat();
    }

    function collectNativeKohaListEntries() {
        const seen = new Set();
        const notices = [];

        document.querySelectorAll(
            'input[name="biblionumber"], input.selection[name="biblionumber"], a[href*="detail.pl?biblionumber="]'
        ).forEach(node => {
            let id = '';
            if (node.matches('input')) id = clean(node.value);
            else {
                try { id = new URL(node.href, window.location.origin).searchParams.get('biblionumber') || ''; }
                catch (_) {}
            }
            if (!/^\d+$/.test(id) || seen.has(id)) return;
            seen.add(id);

            const row = node.closest('tr') || node.closest('.bibliocol') || node.parentElement;
            const titleLink = row?.querySelector('a[href*="detail.pl?biblionumber="]') || (node.matches('a') ? node : null);
            const coverImg =
                row?.querySelector('.cover-image img[src]') ||
                row?.querySelector('.bookcoverimg img[src]') ||
                row?.querySelector('img[src*="cover"]') ||
                row?.querySelector('img[src*="image.pl"]');

            notices.push({
                biblionumber: id,
                title: clean(titleLink?.textContent) || 'Notice #' + id,
                link: titleLink?.href || '/cgi-bin/koha/catalogue/detail.pl?biblionumber=' + id,
                imgSrc: coverImg?.src || coverImg?.getAttribute('src') || ''
            });
        });
        return notices;
    }

    function injectKohaNativeListButton() {
        if (!config.enabled || !config.injectKohaListsButton || !isKohaNativeListPage()) return;
        if (document.getElementById('pmk142-koha-list-button')) return;

        const anchor =
            document.querySelector('.btn-toolbar') ||
            document.querySelector('#toolbar') ||
            document.querySelector('main .row') ||
            document.querySelector('#main');

        if (!anchor) return;

        const button = document.createElement('button');
        button.id = 'pmk142-koha-list-button';
        button.type = 'button';
        button.className = 'btn btn-default';
        button.innerHTML = '<i class="fa-solid fa-file-lines" aria-hidden="true"></i> Créer une bibliographie';

        button.addEventListener('click', () => {
            const entries = collectNativeKohaListEntries();
            if (!entries.length) {
                alert('Aucune notice n’a pu être identifiée dans cette liste Koha.');
                return;
            }
            sessionStorage.setItem(SESSION_SOURCE_KEY, JSON.stringify({
                kind: 'koha-native',
                type: 'notice',
                name: clean(document.querySelector('h1')?.textContent) || 'Liste Koha',
                entries
            }));
            window.location.href = PAGE_URL + '&source=session';
        });

        anchor.appendChild(button);
    }

    function collectKohaBasketEntries() {
        const seen = new Set();
        const entries = [];

        document.querySelectorAll('input.select_record[value]').forEach(input => {
            const bib = clean(input.value);
            if (!/^\d+$/.test(bib) || seen.has(bib)) return;
            seen.add(bib);

            const scope =
                input.closest('tr')
                || input.closest('h3')?.parentElement
                || input.parentElement;

            const titleLink =
                scope?.querySelector('a[href*="/catalogue/detail.pl?biblionumber="]')
                || document.querySelector(
                    'a[href*="/catalogue/detail.pl?biblionumber=' + CSS.escape(bib) + '"]'
                );

            const coverImg =
                scope?.querySelector('.cover-image img[src]')
                || scope?.querySelector('img[src*="cover"]')
                || scope?.querySelector('img[src*="image.pl"]');

            entries.push({
                biblionumber: bib,
                title: clean(titleLink?.textContent) || 'Notice #' + bib,
                link: titleLink?.href || '/cgi-bin/koha/catalogue/detail.pl?biblionumber=' + bib,
                imgSrc: coverImg?.src || coverImg?.getAttribute('src') || ''
            });
        });

        /*
         * Secours : dans une présentation atypique du panier, les liens
         * vers detail.pl permettent quand même de récupérer les notices.
         */
        if (!entries.length) {
            document.querySelectorAll('a[href*="/catalogue/detail.pl?biblionumber="]').forEach(link => {
                try {
                    const bib = clean(
                        new URL(link.href, window.location.origin)
                            .searchParams.get('biblionumber')
                    );
                    if (!/^\d+$/.test(bib) || seen.has(bib)) return;
                    seen.add(bib);
                    entries.push({
                        biblionumber: bib,
                        title: clean(link.textContent) || 'Notice #' + bib,
                        link: link.href
                    });
                } catch (_) {}
            });
        }

        return entries;
    }

    function injectKohaBasketButton() {
        if (!config.enabled || !config.injectBasketButton || !isKohaBasketPage()) return;
        if (document.getElementById('pmk142-basket-button')) return;

        const toolbar =
            document.querySelector('#toolbar.btn-toolbar')
            || document.querySelector('#toolbar')
            || document.querySelector('.btn-toolbar');

        if (!toolbar) return;

        const button = document.createElement('button');
        button.id = 'pmk142-basket-button';
        button.type = 'button';
        button.className = 'btn btn-default';
        button.innerHTML =
            '<i class="fa-solid fa-file-lines" aria-hidden="true"></i> ' +
            'Créer une bibliographie';
        button.title = 'Créer une bibliographie avec le contenu du panier Koha';

        button.addEventListener('click', () => {
            const entries = collectKohaBasketEntries();

            if (!entries.length) {
                alert('Aucune notice n’a pu être identifiée dans le panier Koha.');
                return;
            }

            sessionStorage.setItem(SESSION_SOURCE_KEY, JSON.stringify({
                kind: 'koha-basket',
                type: 'notice',
                name: 'Panier Koha',
                entries
            }));

            /*
             * Le panier Koha est souvent ouvert dans une fenêtre dédiée.
             * On garde cette même fenêtre pour conserver son sessionStorage.
             */
            window.location.href = PAGE_URL + '&source=session';
        });

        toolbar.appendChild(button);
    }

    function courseReserveRows(table) {
        if (!table) return [];

        /*
         * course-details.pl transforme le tableau en DataTable. En cas de
         * pagination, les lignes des autres pages peuvent être détachées du
         * DOM : on demande donc toutes les lignes à l'API DataTables quand
         * elle est disponible.
         */
        try {
            if (
                window.jQuery
                && window.jQuery.fn?.dataTable?.isDataTable
                && window.jQuery.fn.dataTable.isDataTable(table)
            ) {
                const api = window.jQuery(table).DataTable();
                const nodes = api.rows().nodes().toArray();
                if (nodes.length) return nodes;
            }
        } catch (error) {
            console.warn('[PMK142] Lecture DataTables réserve de cours impossible', error);
        }

        return Array.from(table.querySelectorAll('tbody tr'));
    }

    function collectCourseReserveEntries() {
        const table = document.getElementById('course_reserves_table');
        if (!table) return [];

        const entries = [];
        const seen = new Set();

        courseReserveRows(table).forEach(row => {
            const detailLink = row.querySelector(
                'a[href*="/catalogue/detail.pl?biblionumber="]'
            );
            if (!detailLink) return;

            let bib = '';
            try {
                bib = clean(
                    new URL(detailLink.href, window.location.origin)
                        .searchParams.get('biblionumber')
                );
            } catch (_) {}

            if (!/^\d+$/.test(bib)) return;

            const itemLink = row.querySelector(
                'a[href*="/catalogue/moredetail.pl?itemnumber="]'
            );

            let itemId = '';
            let barcode = '';

            if (itemLink) {
                try {
                    itemId = clean(
                        new URL(itemLink.href, window.location.origin)
                            .searchParams.get('itemnumber')
                    );
                } catch (_) {}
                barcode = clean(itemLink.textContent);
            }

            const key = bib + '|' + (itemId || 'biblio');
            if (seen.has(key)) return;
            seen.add(key);

            entries.push({
                entryType: itemId ? 'item' : 'notice',
                biblionumber: bib,
                item_id: itemId,
                barcode,
                title: clean(detailLink.textContent) || 'Notice #' + bib,
                author: clean(row.cells?.[1]?.textContent),
                link: detailLink.href
            });
        });

        return entries;
    }

    function courseSourceName() {
        const h1 = clean(document.querySelector('h1')?.textContent);
        if (!h1) return 'Réserve de cours';

        return h1
            .replace(/^Course details for\s*/i, '')
            .replace(/^Détails du cours\s*/i, '')
            .replace(/^Détails pour le cours\s*/i, '')
            .trim() || 'Réserve de cours';
    }

    function findOrCreateCourseToolbar() {
        let toolbar = document.querySelector('#toolbar');

        if (toolbar) return toolbar;

        const table = document.getElementById('course_reserves_table');
        if (!table) return null;

        toolbar = document.createElement('div');
        toolbar.id = 'pmk142-course-toolbar';
        toolbar.className = 'btn-toolbar';
        toolbar.style.marginBottom = '12px';

        const section = table.closest('.page-section') || table.parentElement;
        section?.parentNode?.insertBefore(toolbar, section);

        return toolbar;
    }

    function injectCourseReservesButton() {
        if (
            !config.enabled
            || !config.injectCourseReservesButton
            || !isCourseReservesDetailPage()
        ) return;

        if (document.getElementById('pmk142-course-reserves-button')) return;

        const entries = collectCourseReserveEntries();
        if (!entries.length) return;

        const toolbar = findOrCreateCourseToolbar();
        if (!toolbar) return;

        const button = document.createElement('button');
        button.id = 'pmk142-course-reserves-button';
        button.type = 'button';
        button.className = 'btn btn-default';
        button.innerHTML =
            '<i class="fa-solid fa-file-lines" aria-hidden="true"></i> ' +
            'Créer une bibliographie';
        button.title = 'Créer une bibliographie à partir des réserves de ce cours';

        button.addEventListener('click', () => {
            const currentEntries = collectCourseReserveEntries();

            if (!currentEntries.length) {
                alert('Aucune réserve n’a pu être identifiée pour ce cours.');
                return;
            }

            sessionStorage.setItem(SESSION_SOURCE_KEY, JSON.stringify({
                kind: 'koha-course-reserves',
                type: 'mixed',
                name: courseSourceName(),
                courseId: query().get('course_id') || '',
                entries: currentEntries
            }));

            window.location.href = PAGE_URL + '&source=session';
        });

        toolbar.appendChild(button);
    }

    async function openActivePmkList(type) {
        const api = await listsApi();
        if (!api) return;
        const list = await api.getActiveList(type);
        if (!list) {
            alert('Aucune liste active.');
            return;
        }
        window.location.href = PAGE_URL +
            '&source=pmk&list=' + encodeURIComponent(list.id) +
            '&type=' + encodeURIComponent(list.type || type);
    }

    function injectPersonalListButtons() {
        if (!config.enabled || !config.injectPersonalListsButton) return;
        const panel = document.getElementById('kx-temp-lists-panel');
        if (!panel) return;

        ['notices', 'items'].forEach(tab => {
            const pane = panel.querySelector('[data-pane="' + tab + '"]');
            const actions = pane?.querySelector('.kx-tl-actions');
            if (!actions || actions.querySelector('.pmk142-open-builder')) return;

            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'kx-tl-action is-wide pmk142-open-builder';
            button.innerHTML = '<i class="fa-solid fa-file-lines" aria-hidden="true"></i><span>Créer une bibliographie</span>';
            button.addEventListener('click', () => openActivePmkList(tab === 'items' ? 'item' : 'notice'));
            actions.appendChild(button);
        });
    }

    function installIntegrationObserver() {
        const observer = new MutationObserver(() => {
            injectPersonalListButtons();
            injectKohaNativeListButton();
            injectKohaBasketButton();
            injectCourseReservesButton();
            scheduleBundleBibliographyInjection();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        installBundleOpenHook();
    }

    function installStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            #${ROOT_ID} {
                position: fixed;
                inset: 0;
                z-index: 11000;
                display: flex;
                flex-direction: column;
                background: #e8efe9;
                color: #26352d;
                font-family: inherit;
            }
            #${ROOT_ID} * { box-sizing: border-box; }
            #${ROOT_ID} .pmk142-status.is-loading::before{content:'';display:inline-block;width:14px;height:14px;margin-right:8px;vertical-align:middle;border:2px solid #b7c9bb;border-top-color:#315f46;border-radius:50%;animation:pmk142-loading .8s linear infinite}
            @keyframes pmk142-loading{to{transform:rotate(360deg)}}
            @media(prefers-reduced-motion:reduce){#${ROOT_ID} .pmk142-status.is-loading::before{animation:none}}
            #${ROOT_ID} button,
            #${ROOT_ID} input,
            #${ROOT_ID} select,
            #${ROOT_ID} textarea { font: inherit; }
            #${ROOT_ID} .pmk142-topbar {
                display: flex;
                align-items: center;
                gap: 10px;
                min-height: 58px;
                padding: 9px 14px;
                background: linear-gradient(135deg, #315f46 0%, #487a57 100%);
                color: #fff;
                border-bottom: 1px solid #234c37;
                box-shadow: 0 2px 10px rgba(35,76,55,.28);
            }
            #${ROOT_ID} .pmk142-title { flex: 1; min-width: 0; }
            #${ROOT_ID} .pmk142-title strong { display:block; font-size:16px; }
            #${ROOT_ID} .pmk142-title small { color:#d8e2ea; }
            #${ROOT_ID} .pmk142-topbar button {
                border: 1px solid rgba(255,255,255,.34);
                border-radius: 7px;
                background: rgba(255,255,255,.12);
                color: #fff;
                padding: 7px 10px;
                cursor: pointer;
            }
            #${ROOT_ID} .pmk142-layout {
                flex: 1;
                min-height: 0;
                display: grid;
                grid-template-columns: 300px minmax(420px, 1fr) 330px;
                gap: 0;
            }
            #${ROOT_ID} .pmk142-panel {
                min-height: 0;
                overflow: auto;
                background: #f2f6f3;
                border-right: 1px solid #afc2b4;
                padding: 12px;
            }
            #${ROOT_ID} .pmk142-panel-right {
                border-right: 0;
                border-left: 1px solid #afc2b4;
            }
            #${ROOT_ID} .pmk142-preview-wrap {
                min-width: 0;
                min-height: 0;
                overflow: auto;
                padding: 22px;
                background: #dde7df;
            }
            #${ROOT_ID} .pmk142-section {
                margin-bottom: 12px;
                padding: 12px;
                border: 1px solid #b8c9bd;
                border-left: 4px solid #5f8f6a;
                border-radius: 9px;
                background: #ffffff;
                box-shadow: 0 1px 3px rgba(47,83,59,.08);
            }
            #${ROOT_ID} .pmk142-section:nth-child(even) {
                background: #f9fbf9;
            }
            #${ROOT_ID} .pmk142-section h3 {
                margin: -12px -12px 11px -12px;
                padding: 8px 10px;
                border-bottom: 1px solid #bfd0c3;
                border-radius: 8px 8px 0 0;
                background: #dfece2;
                font-size: 12px;
                text-transform: uppercase;
                letter-spacing: .045em;
                color: #315f46;
                font-weight: 800;
            }
            #${ROOT_ID} label {
                display:block;
                margin:8px 0 4px;
                font-size:11px;
                font-weight:750;
                color:#405d49;
            }
            #${ROOT_ID} input[type="text"],
            #${ROOT_ID} input[type="number"],
            #${ROOT_ID} select,
            #${ROOT_ID} textarea {
                width:100%;
                padding:7px 8px;
                border:1px solid #aabfaf;
                border-radius:6px;
                background:#fff;
                color:#26352d;
                box-shadow: inset 0 1px 1px rgba(42,74,51,.04);
            }
            #${ROOT_ID} input[type="text"]:focus,
            #${ROOT_ID} input[type="number"]:focus,
            #${ROOT_ID} select:focus,
            #${ROOT_ID} textarea:focus {
                border-color:#4f7f59;
                outline:2px solid rgba(79,127,89,.16);
                outline-offset:0;
            }
            #${ROOT_ID} .pmk142-topbar button:hover {
                background:rgba(255,255,255,.22);
                border-color:rgba(255,255,255,.5);
            }
            #${ROOT_ID} .pmk142-panel .pmk142-section + .pmk142-section {
                margin-top:14px;
            }
            #${ROOT_ID} .pmk142-panel-right .pmk142-section {
                border-left-color:#467653;
            }
            #${ROOT_ID} .pmk142-panel-right .pmk142-section h3 {
                background:#d8e8dc;
                color:#2f5f43;
            }

            #${ROOT_ID} .pmk142-row { display:flex; gap:6px; align-items:center; }
            #${ROOT_ID} .pmk142-row > * { min-width:0; }
            #${ROOT_ID} .pmk142-btn {
                border:1px solid #9fb5a4;
                border-radius:6px;
                background:#f7faf8;
                color:#315f46;
                padding:6px 8px;
                cursor:pointer;
            }
            #${ROOT_ID} .pmk142-btn:hover {
                background:#e4efe6;
                border-color:#789b80;
            }
            #${ROOT_ID} .pmk142-btn-primary {
                background:#4f7f59;
                color:#fff;
                border-color:#416c4b;
            }
            #${ROOT_ID} .pmk142-btn-primary:hover {
                background:#426f4c;
                border-color:#355c3e;
            }
            #${ROOT_ID} .pmk142-btn-danger { color:#9d2525; }
            #${ROOT_ID} .pmk142-muted {
                color:#687a6e;
                font-size:11px;
                line-height:1.35;
            }
            #${ROOT_ID} .pmk142-source-summary {
                padding:8px 9px;
                border:1px solid #afc2b4;
                border-radius:7px;
                background:#edf5ef;
                line-height:1.35;
            }
            #${ROOT_ID} .pmk142-source-summary strong {
                display:block;
                margin-bottom:2px;
            }
            .pmk142-bundle-toolbar {
                display:flex;
                flex-wrap:wrap;
                gap:5px;
                align-items:center;
            }
            #${ROOT_ID} .pmk142-block-list { display:flex; flex-direction:column; gap:5px; }
            #${ROOT_ID} .pmk142-block {
                display:flex;
                align-items:center;
                gap:6px;
                padding:7px;
                border:1px solid #b6c8ba;
                border-radius:7px;
                background:#f7faf8;
                cursor:grab;
                box-shadow:0 1px 2px rgba(44,76,53,.05);
            }
            #${ROOT_ID} .pmk142-block:hover {
                border-color:#7fa087;
                background:#edf5ef;
            }
            #${ROOT_ID} .pmk142-block.is-selected {
                border-color:#4f7f59;
                background:#dcebdd;
                box-shadow:0 0 0 2px rgba(79,127,89,.14);
            }
            #${ROOT_ID} .pmk142-block .grab { color:#82909c; }
            #${ROOT_ID} .pmk142-block .name { flex:1; min-width:0; font-size:11px; }
            #${ROOT_ID} .pmk142-a4 {
                margin: 0 auto;
                background:#fff;
                border:1px solid #c5d1c8;
                box-shadow:0 6px 30px rgba(42,75,51,.18);
                min-height:297mm;
                width:210mm;
                padding:12mm;
            }
            #${ROOT_ID} .pmk142-a4.landscape {
                width:297mm;
                min-height:210mm;
            }
            #${ROOT_ID} .pmk142-doc-title {
                margin:0 0 8mm;
                padding-bottom:3mm;
                border-bottom:2px solid #d7e2da;
                font-size:24px;
                font-weight:850;
                line-height:1.1;
                color:#26352d;
            }
            #${ROOT_ID} .pmk142-grid { display:grid; align-items:start; }
            #${ROOT_ID} .pmk142-card {
                min-width:0;
                break-inside:avoid;
                page-break-inside:avoid;
                overflow:visible;
            }
            #${ROOT_ID} .pmk142-card::after {
                content:"";
                display:block;
                clear:both;
            }
            #${ROOT_ID} .pmk142-block-wrap {
                max-width:100%;
                box-sizing:border-box;
            }
            #${ROOT_ID} .pmk142-card.has-border { border:1px solid #d8dfe4; border-radius:6px; }
            #${ROOT_ID} .pmk142-cover {
                display:block;
                max-width:100%;
                object-fit:cover;
                background:#f2f4f5;
                border:1px solid #e0e4e7;
                margin-bottom:5px;
            }
            #${ROOT_ID} .pmk142-field { overflow-wrap:anywhere; }
            #${ROOT_ID} .pmk142-notice-link a,
            #${ROOT_ID} .pmk142-catalogue-link a {
                color:#0b62a4;
                text-decoration:underline;
                text-underline-offset:2px;
            }
            #${ROOT_ID} .pmk142-notice-link-print-url {
                display:none;
                overflow-wrap:anywhere;
                font-size:.85em;
            }
            #${ROOT_ID} .pmk142-field-label { font-weight:700; }
            #${ROOT_ID} .pmk142-items { margin-top:5px; border-top:1px solid #e3e7ea; padding-top:4px; }
            #${ROOT_ID} .pmk142-itemline { margin:2px 0; }
            #${ROOT_ID} .pmk142-items-table-wrap { overflow-x:auto; }
            #${ROOT_ID} .pmk142-items-table {
                width:100%;
                border-collapse:collapse;
                table-layout:auto;
            }
            #${ROOT_ID} .pmk142-items-table th,
            #${ROOT_ID} .pmk142-items-table td {
                padding:3px 4px;
                border:1px solid #dfe4e7;
                text-align:left;
                vertical-align:top;
                overflow-wrap:anywhere;
            }
            #${ROOT_ID} .pmk142-items-table th {
                background:#f4f6f7;
                font-weight:750;
            }
            #${ROOT_ID} .pmk142-badge {
                display:inline-block;
                padding:3px 7px;
                border-radius:999px;
                background:#edf4e8;
                color:#3d642d;
                font-weight:750;
            }
            #${ROOT_ID} .pmk142-group-title {
                grid-column:1/-1;
                margin:8mm 0 3mm;
                padding-bottom:2mm;
                border-bottom:2px solid #485f70;
                font-size:18px;
                font-weight:850;
            }
            #${ROOT_ID} .pmk142-status {
                position:absolute;
                inset:auto 14px 14px auto;
                max-width:min(520px,calc(100% - 28px));
                padding:12px 16px;
                border:1px solid #afc2b4;
                border-radius:7px;
                box-shadow:0 3px 12px rgba(0,0,0,.12);
                pointer-events:none;
                z-index:3;
                display:flex;
                align-items:center;
                justify-content:center;
                background:rgba(232,239,233,.92);
                color:#315f46;
                font-size:14px;
                font-weight:750;
            }
            #${ROOT_ID} .pmk142-status[hidden] { display:none; }

            #${ROOT_ID} .pmk142-content-modal {
                position:absolute;
                inset:0;
                z-index:20;
                display:flex;
                align-items:center;
                justify-content:center;
                padding:24px;
                background:rgba(31,61,43,.58);
            }
            #${ROOT_ID} .pmk142-content-modal[hidden] { display:none; }
            #${ROOT_ID} .pmk142-content-dialog {
                width:min(980px, 96vw);
                max-height:90vh;
                display:flex;
                flex-direction:column;
                background:#fff;
                border-radius:10px;
                box-shadow:0 18px 60px rgba(0,0,0,.28);
                overflow:hidden;
            }
            #${ROOT_ID} .pmk142-content-header,
            #${ROOT_ID} .pmk142-content-footer {
                display:flex;
                align-items:center;
                justify-content:space-between;
                gap:10px;
                padding:12px 14px;
                border-bottom:1px solid #bed0c2;
            }
            #${ROOT_ID} .pmk142-content-footer {
                border-top:1px solid #e1e6ea;
                border-bottom:0;
            }
            #${ROOT_ID} .pmk142-content-header strong {
                font-size:15px;
            }
            #${ROOT_ID} .pmk142-content-tools {
                display:grid;
                grid-template-columns:minmax(220px,1fr) auto auto;
                gap:7px;
                padding:10px 14px;
                border-bottom:1px solid #e1e6ea;
                background:#edf4ef;
            }
            #${ROOT_ID} .pmk142-content-list {
                flex:1;
                overflow:auto;
                padding:10px 14px 18px;
            }
            #${ROOT_ID} .pmk142-content-biblio {
                margin-bottom:8px;
                border:1px solid #b7c9bb;
                border-radius:8px;
                overflow:hidden;
            }
            #${ROOT_ID} .pmk142-content-biblio-label {
                display:flex;
                align-items:flex-start;
                gap:8px;
                margin:0;
                padding:9px 10px;
                background:#e4efe7;
                color:#315f46;
                cursor:pointer;
            }
            #${ROOT_ID} .pmk142-content-biblio-label > span {
                display:flex;
                flex-wrap:wrap;
                gap:4px 10px;
                align-items:baseline;
            }
            #${ROOT_ID} .pmk142-content-biblio-label small {
                color:#687a6e;
                font-weight:400;
            }
            #${ROOT_ID} .pmk142-content-items {
                display:grid;
                grid-template-columns:repeat(auto-fit,minmax(270px,1fr));
                gap:1px;
                background:#c7d7ca;
            }
            #${ROOT_ID} .pmk142-content-items label {
                display:flex;
                align-items:flex-start;
                gap:7px;
                margin:0;
                padding:7px 10px;
                background:#fff;
                color:#3f5746;
                font-weight:400;
                cursor:pointer;
            }
            #${ROOT_ID} .pmk142-content-items input,
            #${ROOT_ID} .pmk142-content-biblio-label input {
                width:auto;
                margin-top:2px;
            }
            @media (max-width: 1200px) {
                #${ROOT_ID} .pmk142-layout { grid-template-columns:260px minmax(380px,1fr); }
                #${ROOT_ID} .pmk142-panel-right { display:none; }
            }
            @media print {
                #${ROOT_ID} .pmk142-print-mode-hide { display:none !important; }
                #${ROOT_ID} .pmk142-print-mode-url a { display:none !important; }
                #${ROOT_ID} .pmk142-print-mode-url .pmk142-notice-link-print-url { display:inline !important; }
                body > *:not(#${ROOT_ID}) { display:none !important; }
                #${ROOT_ID} { position:static; display:block; background:#fff; }
                #${ROOT_ID} .pmk142-topbar,
                #${ROOT_ID} .pmk142-panel,
                #${ROOT_ID} .pmk142-panel-right,
                #${ROOT_ID} .pmk142-status { display:none !important; }
                #${ROOT_ID} .pmk142-layout { display:block; }
                #${ROOT_ID} .pmk142-preview-wrap { padding:0; overflow:visible; }
                #${ROOT_ID} .pmk142-a4 { box-shadow:none; border:0; margin:0; width:auto; min-height:0; padding:0; }
                #${ROOT_ID} .pmk142-doc-title { color:#000; border-bottom-color:#ddd; }
            }
        `;
        document.head.appendChild(style);
    }

    const BLOCK_LIBRARY = Object.freeze([
        // Structure
        { value: 'special:text', group: 'Structure', label: 'Texte libre' },
        { value: 'special:badge', group: 'Structure', label: 'Badge' },
        { value: 'special:separator', group: 'Structure', label: 'Séparateur' },
        { value: 'special:cover', group: 'Structure', label: 'Couverture' },
        { value: 'special:qrcode', group: 'Structure', label: 'QR code catalogue' },
        { value: 'special:notice-link', group: 'Structure', label: 'Lien vers la notice' },

        // Bibliographie
        { value: 'field:biblio.title', group: 'Bibliographie', label: 'Titre' },
        { value: 'field:biblio.subtitle', group: 'Bibliographie', label: 'Sous-titre' },
        { value: 'field:biblio.author', group: 'Bibliographie', label: 'Auteur / responsabilité' },
        { value: 'field:biblio.publisher', group: 'Bibliographie', label: 'Éditeur (210$c / 214$c)' },
        { value: 'field:biblio.publication_year', group: 'Bibliographie', label: 'Année / date d’édition (210$d / 214$d)' },
        { value: 'field:biblio.collection', group: 'Bibliographie', label: 'Collection (225$a)' },
        { value: 'field:biblio.isbn', group: 'Bibliographie', label: 'ISBN (010$a)' },
        { value: 'field:biblio.summary', group: 'Bibliographie', label: 'Résumé (330$a)' },
        { value: 'field:biblio.public_audience', group: 'Bibliographie', label: 'Public (999$q)' },
        { value: 'field:biblio.sublocation_local', group: 'Bibliographie', label: 'Sous-localisation (999$y)' },
        { value: 'field:biblio.series_title', group: 'Bibliographie', label: 'Série (API)' },
        { value: 'field:biblio.notes', group: 'Bibliographie', label: 'Notes' },
        { value: 'field:biblio.medium', group: 'Bibliographie', label: 'Support / medium' },
        { value: 'field:biblio.part_number', group: 'Bibliographie', label: 'Numéro de partie' },
        { value: 'field:biblio.part_name', group: 'Bibliographie', label: 'Nom de partie' },
        { value: 'field:biblio.uniform_title', group: 'Bibliographie', label: 'Titre uniforme' },
        { value: 'field:biblio.biblionumber', group: 'Bibliographie', label: 'N° notice' },
        { value: 'field:biblio.link', group: 'Bibliographie', label: 'Lien catalogue' },

        // Exemplaires
        { value: 'field:item.barcode', group: 'Exemplaires', label: 'Code-barres exemplaire — texte' },
        { value: 'special:item-barcode-image', group: 'Exemplaires', label: 'Code-barres exemplaire — scannable' },
        { value: 'field:item.callnumber', group: 'Exemplaires', label: 'Cote' },
        { value: 'field:item.home_library_id', group: 'Exemplaires', label: 'Site propriétaire' },
        { value: 'field:item.holding_library_id', group: 'Exemplaires', label: 'Site actuel' },
        { value: 'field:item.location', group: 'Exemplaires', label: 'Localisation' },
        { value: 'field:item.permanent_location', group: 'Exemplaires', label: 'Localisation permanente' },
        { value: 'field:item.item_type_id', group: 'Exemplaires', label: 'Type de document' },
        { value: 'field:item.not_for_loan_status', group: 'Exemplaires', label: 'Statut / exclusion du prêt' },
        { value: 'field:item.acquisition_date', group: 'Exemplaires', label: 'Date d’acquisition' },
        { value: 'field:item.purchase_price', group: 'Exemplaires', label: 'Prix d’achat' },
        { value: 'field:item.replacement_price', group: 'Exemplaires', label: 'Prix de remplacement' },
        { value: 'field:item.last_checkout_date', group: 'Exemplaires', label: 'Dernier prêt' },
        { value: 'field:item.last_seen_date', group: 'Exemplaires', label: 'Dernière vue' },
        { value: 'special:items', group: 'Exemplaires', label: 'Détails exemplaires — compact' },
        { value: 'special:items-table', group: 'Exemplaires', label: 'Tableau détaillé des exemplaires' }
    ]);

    function blockLibraryOptionsHtml() {
        const groups = new Map();

        BLOCK_LIBRARY.forEach(entry => {
            if (!groups.has(entry.group)) groups.set(entry.group, []);
            groups.get(entry.group).push(entry);
        });

        return [...groups.entries()].map(([group, entries]) => `
            <optgroup label="${esc(group)}">
                ${entries.map(entry => `<option value="${esc(entry.value)}">${esc(entry.label)}</option>`).join('')}
            </optgroup>
        `).join('');
    }

    function fieldLabel(field) {
        return FIELD_CATALOG.find(entry => entry.key === field)?.label || field || 'Champ';
    }

    function defaultFieldStyle(field) {
        const style = { size: 10 };

        if (field === 'biblio.title') Object.assign(style, { size: 16, weight: 800 });
        if (field === 'biblio.author') Object.assign(style, { size: 10, weight: 650 });
        if (field === 'biblio.summary' || field === 'biblio.abstract') Object.assign(style, { size: 9 });
        if (field === 'biblio.publication_year' || field === 'biblio.copyright_date') Object.assign(style, { prefix: 'Année : ' });
        if (field === 'biblio.publisher' || field === 'biblio.editor') Object.assign(style, { prefix: 'Éditeur : ' });
        if (field === 'biblio.collection' || field === 'biblio.series_title') Object.assign(style, { prefix: 'Collection : ' });
        if (field === 'biblio.isbn') Object.assign(style, { prefix: 'ISBN : ' });
        if (field === 'biblio.public_audience') Object.assign(style, { prefix: 'Public : ' });
        if (field === 'item.barcode') Object.assign(style, { prefix: 'Code-barres : ', weight: 700 });
        if (field === 'item.callnumber') Object.assign(style, { prefix: 'Cote : ', weight: 700 });
        if (field === 'item.home_library_id') Object.assign(style, { prefix: 'Site propriétaire : ' });
        if (field === 'item.holding_library_id') Object.assign(style, { prefix: 'Site actuel : ' });
        if (field === 'item.location') Object.assign(style, { prefix: 'Localisation : ' });
        if (field === 'item.item_type_id') Object.assign(style, { prefix: 'Type : ' });
        if (field === 'item.not_for_loan_status') Object.assign(style, { prefix: 'Statut : ' });

        return style;
    }

    function createBlockFromLibrary(value) {
        const [kind, payload] = String(value || '').split(':', 2);

        if (kind === 'field') {
            return block('field', payload, fieldLabel(payload), defaultFieldStyle(payload));
        }

        if (kind === 'special') {
            if (payload === 'cover') return block('cover', 'biblio.cover', 'Couverture', { width: 90, height: 130 });
            if (payload === 'text') return block('text', '', 'Texte libre', { text: 'Votre texte' });
            if (payload === 'badge') return block('badge', '', 'Badge', { text: 'Sélection' });
            if (payload === 'separator') return block('separator', '', 'Séparateur');
            if (payload === 'qrcode') return block('qrcode', 'biblio.link', 'QR code catalogue', { size: 78 });
            if (payload === 'notice-link') {
                return block('notice-link', 'biblio.link', 'Lien vers la notice', {
                    text: 'Voir la notice',
                    newTab: true,
                    showIcon: true,
                    printMode: 'link',
                    size: 9,
                    weight: 650,
                    align: 'left',
                    wrapMode: 'normal',
                    blockWidth: 100
                });
            }
            if (payload === 'item-barcode-image') {
                return block('barcode-image', 'item.barcode', 'Code-barres exemplaire scannable', {
                    barcodeType: 'Code39',
                    barcodeHeight: 50,
                    imageWidth: 190,
                    showText: true,
                    align: 'left',
                    gap: 6
                });
            }
            if (payload === 'items') {
                return block('items', 'items', 'Détails exemplaires', {
                    size: 8,
                    showBarcode: true,
                    showCallnumber: true,
                    showHomeLibrary: true,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: true,
                    showStatus: true
                });
            }
            if (payload === 'items-table') {
                return block('items-table', 'items', 'Tableau détaillé des exemplaires', {
                    size: 7.5,
                    showBarcode: true,
                    showCallnumber: true,
                    showHomeLibrary: true,
                    showHoldingLibrary: true,
                    showLocation: true,
                    showItemType: true,
                    showStatus: true,
                    showAcquisitionDate: false
                });
            }
        }

        return block('field', 'biblio.title', 'Titre', defaultFieldStyle('biblio.title'));
    }

    function templateOptionsHtml() {
        const all = [...BUILTIN_TEMPLATES, ...current.templates];
        return all.map(t => '<option value="' + esc(t.id) + '"' +
            (t.id === current.selectedTemplateId ? ' selected' : '') + '>' +
            esc((t.builtin ? '' : 'Personnel — ') + t.name) + '</option>').join('');
    }

    function sourceListOptionsHtml(lists) {
        return lists.map(list =>
            '<option value="' + esc(list.id) + '"' + (current.list?.id === list.id ? ' selected' : '') + '>' +
            esc((list.type === 'item' ? 'Exemplaires — ' : 'Notices — ') + (list.name || 'Liste')) +
            '</option>'
        ).join('');
    }

    async function renderBuilder() {
        installStyles();
        let root = document.getElementById(ROOT_ID);
        if (!root) {
            root = document.createElement('div');
            root.id = ROOT_ID;
            document.body.appendChild(root);
        }

        root.innerHTML = `
            <div class="pmk142-topbar">
                <button type="button" data-action="close">← Koha</button>
                <div class="pmk142-title">
                    <strong>Bibliographies & publications</strong>
                </div>
                <button type="button" data-action="reload-data">Actualiser les données</button>
                <button type="button" data-action="save-template"><i class="fa-solid fa-floppy-disk"></i> Enregistrer le modèle</button>
                <button type="button" data-action="print"><i class="fa-solid fa-print"></i> Imprimer / PDF</button>
            </div>
            <div class="pmk142-layout">
                <aside class="pmk142-panel" data-zone="left"></aside>
                <main class="pmk142-preview-wrap">
                    <div class="pmk142-a4" data-zone="preview"></div>
                </main>
                <aside class="pmk142-panel pmk142-panel-right" data-zone="right"></aside>
            </div>
            <div class="pmk142-status" data-zone="status" hidden></div>
            <div class="pmk142-content-modal" data-zone="content-manager" hidden></div>
        `;

        root.addEventListener('click', handleRootClick);
        root.addEventListener('change', handleRootChange);
        root.addEventListener('input', handleRootInput);

        await refreshLeftPanel();
        refreshRightPanel();
        renderPreview();
    }

    function setStatus(message, busy = current.loading) {
        const el=document.querySelector('#'+ROOT_ID+' [data-zone="status"]');
        if(!el)return;
        if(!message && (current.loading || current.loadWarning))return;
        el.hidden=!message;el.classList.toggle('is-loading',!!message && busy);
        el.setAttribute('role','status');el.setAttribute('aria-live','polite');el.textContent=message || '';
        const preview=document.querySelector('#'+ROOT_ID+' [data-zone="preview"]');
        preview?.setAttribute('aria-busy',String(busy));
    }

    async function refreshLeftPanel() {
        const zone = document.querySelector('#' + ROOT_ID + ' [data-zone="left"]');
        if (!zone) return;

        // Une source Koha transmise par session n'a pas besoin de Koha ni des listes PMK.
        const isSessionSource = [
            'koha-native',
            'koha-bundle',
            'koha-basket',
            'koha-course-reserves'
        ].includes(current.source?.kind);
        const lists=listChoices;
        if(!isSessionSource) void listOptions().then(choices=>{
            const select=document.querySelector('#'+ROOT_ID+' [data-control="source-list"]');
            if(select)select.innerHTML=sourceListOptionsHtml(choices);
        }).catch(error=>setStatus('Listes PMK indisponibles : '+error.message));

        const sourceKindLabel = {
            'koha-native': 'Liste Koha',
            'koha-bundle': 'Paquet Koha',
            'koha-basket': 'Panier Koha',
            'koha-course-reserves': 'Réserve de cours'
        }[current.source?.kind] || 'Source Koha';

        const sourceControlHtml = isSessionSource
            ? `
                <div class="pmk142-source-summary">
                    <strong>${esc(sourceKindLabel)}</strong>
                    <div>${esc(current.list?.name || current.source?.name || '')}</div>
                    <div class="pmk142-muted">${current.entries.length} entrée(s) chargée(s)</div>
                </div>
            `
            : `
                <label>Liste</label>
                <select data-control="source-list">
                    ${sourceListOptionsHtml(lists)}
                </select>
                <div class="pmk142-muted">${current.entries.length} entrée(s) chargée(s)</div>
            `;

        zone.innerHTML = `
            <div class="pmk142-section">
                <h3>Source</h3>
                ${sourceControlHtml}

                <label>Mode de rendu</label>
                <select data-control="mode">
                    <option value="notice"${current.mode === 'notice' ? ' selected' : ''}>Une fiche par notice</option>
                    <option value="item"${current.mode === 'item' ? ' selected' : ''}>Une fiche par exemplaire</option>
                    <option value="notice-items"${current.mode === 'notice-items' ? ' selected' : ''}>Notice + exemplaires</option>
                </select>

                ${current.source?.kind === 'koha-bundle' ? `
                    <div class="pmk142-muted" style="margin-top:8px">
                        Par défaut, seuls les exemplaires réellement présents dans le paquet sont utilisés.
                    </div>
                    <label style="font-weight:600">
                        <input type="checkbox" data-control="include-bundle-host"${current.includeBundleHost ? ' checked' : ''}>
                        Inclure aussi l’exemplaire « paquet » lui-même
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-control="all-items"${current.allItemsForItemLists ? ' checked' : ''}>
                        Récupérer tous les exemplaires des notices concernées
                    </label>
                ` : current.source?.kind === 'koha-course-reserves' ? `
                    <div class="pmk142-muted" style="margin-top:8px">
                        Les réserves au niveau exemplaire restent limitées aux exemplaires réservés.
                        Les réserves au niveau notice utilisent les exemplaires de la notice dans les modes qui en ont besoin.
                    </div>
                    <label style="font-weight:600">
                        <input type="checkbox" data-control="all-items"${current.allItemsForItemLists ? ' checked' : ''}>
                        Élargir toutes les réserves aux exemplaires des notices concernées
                    </label>
                ` : current.list?.type === 'item' ? `
                    <label style="font-weight:600">
                        <input type="checkbox" data-control="all-items"${current.allItemsForItemLists ? ' checked' : ''}>
                        Pour une liste d’exemplaires, récupérer tous les exemplaires des notices
                    </label>
                ` : ''}
            </div>

            <div class="pmk142-section">
                <h3>Contenu publié</h3>
                ${(() => {
                    const stats = contentVisibilityStats();
                    return `
                        <div class="pmk142-muted" style="margin-bottom:7px">
                            ${stats.visibleBiblios}/${stats.totalBiblios} notice(s) affichée(s)
                            ${stats.totalItems ? ` • ${stats.visibleItems}/${stats.totalItems} exemplaire(s)` : ''}
                        </div>
                    `;
                })()}
                <button type="button" class="pmk142-btn" style="width:100%" data-action="open-content-manager">
                    <i class="fa-solid fa-eye" aria-hidden="true"></i>
                    Choisir les documents / exemplaires
                </button>
            </div>

            <div class="pmk142-section">
                <h3>Document</h3>
                <label>Titre de la publication</label>
                <input type="text" data-control="doc-title" value="${esc(current.title)}">

                <label style="font-weight:600">
                    <input type="checkbox" data-control="show-biblionumber"${current.showBiblionumber ? ' checked' : ''}>
                    Afficher les numéros de notices
                </label>
                <div class="pmk142-muted">Décochez pour masquer tous les blocs « N° notice » du rendu, sans modifier le modèle.</div>

                <label>Modèle</label>
                <select data-control="template">${templateOptionsHtml()}</select>

                <div class="pmk142-row" style="margin-top:6px">
                    <button class="pmk142-btn" type="button" data-action="duplicate-template">Dupliquer</button>
                    <button class="pmk142-btn" type="button" data-action="export-template">Exporter</button>
                    <button class="pmk142-btn" type="button" data-action="import-template">Importer</button>
                    <input type="file" data-control="import-file" accept=".json,application/json" hidden>
                </div>

                ${!String(current.selectedTemplateId).startsWith('builtin-') ? `
                    <button class="pmk142-btn pmk142-btn-danger" style="margin-top:6px;width:100%" type="button" data-action="delete-template">
                        Supprimer mon modèle
                    </button>` : ''}
            </div>

            <div class="pmk142-section">
                <h3>Mise en page</h3>
                <div class="pmk142-row">
                    <div style="flex:1">
                        <label>Colonnes</label>
                        <input type="number" min="1" max="4" data-control="columns" value="${Number(current.workingTemplate?.page?.columns || 1)}">
                    </div>
                    <div style="flex:1">
                        <label>Marge (mm)</label>
                        <input type="number" min="0" max="35" data-control="margin" value="${Number(current.workingTemplate?.page?.margin || 12)}">
                    </div>
                </div>
                <label>Orientation</label>
                <select data-control="orientation">
                    <option value="portrait"${current.workingTemplate?.page?.orientation !== 'landscape' ? ' selected' : ''}>Portrait</option>
                    <option value="landscape"${current.workingTemplate?.page?.orientation === 'landscape' ? ' selected' : ''}>Paysage</option>
                </select>
            </div>

            <div class="pmk142-section">
                <h3>Organisation</h3>
                <label>Tri</label>
                <select data-control="sort-by">
                    ${FIELD_CATALOG.map(f => `<option value="${esc(f.key)}"${current.sortBy === f.key ? ' selected' : ''}>${esc(f.label)}</option>`).join('')}
                </select>
                <label>Regrouper par</label>
                <select data-control="group-by">
                    <option value="">Aucun regroupement</option>
                    ${FIELD_CATALOG.map(f => `<option value="${esc(f.key)}"${current.groupBy === f.key ? ' selected' : ''}>${esc(f.label)}</option>`).join('')}
                </select>
                <label>Filtre texte</label>
                <input type="text" data-control="filter-text" placeholder="Titre, auteur, cote, code-barres…" value="${esc(current.filterText)}">
            </div>

            <div class="pmk142-section">
                <h3>Blocs</h3>
                <div class="pmk142-block-list" data-zone="blocks"></div>
                <div class="pmk142-row" style="margin-top:7px">
                    <select data-control="add-block-kind" style="flex:1">
                        ${blockLibraryOptionsHtml()}
                    </select>
                    <button type="button" class="pmk142-btn" data-action="add-block">Ajouter</button>
                </div>
            </div>
        `;

        renderBlocks();
    }

    function renderBlocks() {
        const zone = document.querySelector('#' + ROOT_ID + ' [data-zone="blocks"]');
        if (!zone || !current.workingTemplate) return;
        zone.innerHTML = '';

        current.workingTemplate.blocks.forEach((b, index) => {
            const el = document.createElement('div');
            el.className = 'pmk142-block' + (current.selectedBlockId === b.id ? ' is-selected' : '');
            el.draggable = true;
            el.dataset.blockId = b.id;
            el.innerHTML = `
                <span class="grab">⋮⋮</span>
                <span class="name">${esc(b.label || b.type)}<br><small>${esc(b.field || b.type)}</small></span>
                <button class="pmk142-btn" type="button" data-action="remove-block" data-block-id="${esc(b.id)}">×</button>
            `;
            el.addEventListener('click', evt => {
                if (evt.target.closest('button')) return;
                current.selectedBlockId = b.id;
                renderBlocks();
                refreshRightPanel();
            });
            el.addEventListener('dragstart', evt => {
                evt.dataTransfer.setData('text/plain', b.id);
                evt.dataTransfer.effectAllowed = 'move';
            });
            el.addEventListener('dragover', evt => evt.preventDefault());
            el.addEventListener('drop', evt => {
                evt.preventDefault();
                const sourceId = evt.dataTransfer.getData('text/plain');
                reorderBlock(sourceId, b.id);
            });
            zone.appendChild(el);
        });
    }

    function reorderBlock(sourceId, targetId) {
        const blocks = current.workingTemplate.blocks;
        const from = blocks.findIndex(b => b.id === sourceId);
        const to = blocks.findIndex(b => b.id === targetId);
        if (from < 0 || to < 0 || from === to) return;
        const [moved] = blocks.splice(from, 1);
        blocks.splice(to, 0, moved);
        renderBlocks();
        renderPreview();
    }

    function refreshRightPanel() {
        const zone = document.querySelector('#' + ROOT_ID + ' [data-zone="right"]');
        if (!zone) return;

        const b = current.workingTemplate?.blocks?.find(block => block.id === current.selectedBlockId);
        if (!b) {
            zone.innerHTML = `
                <div class="pmk142-section">
                    <h3>Propriétés</h3>
                    <p class="pmk142-muted">Sélectionnez un bloc à gauche pour modifier son contenu et son style.</p>
                </div>
                <div class="pmk142-section">
                    <h3>Données disponibles</h3>
                    <p class="pmk142-muted">Les champs bibliographiques et exemplaires peuvent être mélangés. Un champ absent est simplement masqué si « masquer si vide » est actif.</p>
                </div>
            `;
            return;
        }

        zone.innerHTML = `
            <div class="pmk142-section">
                <h3>${esc(b.label || b.type)}</h3>

                <label>Libellé interne</label>
                <input type="text" data-block-control="label" value="${esc(b.label || '')}">

                ${['field', 'qrcode'].includes(b.type) ? `
                    <label>Champ</label>
                    <select data-block-control="field">
                        <option value="biblio.link"${b.field === 'biblio.link' ? ' selected' : ''}>Lien catalogue</option>
                        ${FIELD_CATALOG.map(f => `<option value="${esc(f.key)}"${b.field === f.key ? ' selected' : ''}>${esc(f.label)} — ${esc(f.key)}</option>`).join('')}
                    </select>
                    <label>Chemin libre</label>
                    <input type="text" data-block-control="field-free" value="${esc(b.field || '')}" placeholder="ex. biblio.api.xxx ou item.raw.xxx">
                ` : ''}

                ${['text', 'badge'].includes(b.type) ? `
                    <label>Texte</label>
                    <textarea rows="3" data-style-control="text">${esc(b.style?.text || '')}</textarea>
                ` : ''}

                <div class="pmk142-row">
                    <div style="flex:1">
                        <label>Taille</label>
                        <input type="number" min="6" max="48" data-style-control="size" value="${Number(b.style?.size || 10)}">
                    </div>
                    <div style="flex:1">
                        <label>Graisse</label>
                        <select data-style-control="weight">
                            <option value="400"${Number(b.style?.weight || 400) === 400 ? ' selected' : ''}>Normal</option>
                            <option value="650"${Number(b.style?.weight || 400) === 650 ? ' selected' : ''}>Semi-gras</option>
                            <option value="800"${Number(b.style?.weight || 400) >= 800 ? ' selected' : ''}>Gras</option>
                        </select>
                    </div>
                </div>

                <label>Alignement</label>
                <select data-style-control="align">
                    <option value="left"${!b.style?.align || b.style?.align === 'left' ? ' selected' : ''}>Gauche</option>
                    <option value="center"${b.style?.align === 'center' ? ' selected' : ''}>Centre</option>
                    <option value="right"${b.style?.align === 'right' ? ' selected' : ''}>Droite</option>
                    <option value="justify"${b.style?.align === 'justify' ? ' selected' : ''}>Justifié</option>
                </select>

                ${b.type === 'field' ? `
                    <label>Préfixe</label>
                    <input type="text" data-style-control="prefix" value="${esc(b.style?.prefix || '')}">
                    <label>Suffixe</label>
                    <input type="text" data-style-control="suffix" value="${esc(b.style?.suffix || '')}">
                ` : ''}

                ${b.type === 'cover' ? `
                    <div class="pmk142-row">
                        <div style="flex:1"><label>Largeur px</label><input type="number" data-style-control="width" value="${Number(b.style?.width || 90)}"></div>
                        <div style="flex:1"><label>Hauteur px</label><input type="number" data-style-control="height" value="${Number(b.style?.height || 130)}"></div>
                    </div>
                ` : ''}

                ${b.type === 'notice-link' ? `
                    <label>Texte du lien</label>
                    <input type="text" data-style-control="text" value="${esc(b.style?.text || 'Voir la notice')}">

                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="newTab"${b.style?.newTab !== false ? ' checked' : ''}>
                        Ouvrir dans un nouvel onglet
                    </label>

                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showIcon"${b.style?.showIcon !== false ? ' checked' : ''}>
                        Afficher l’icône
                    </label>

                    <label>À l’impression / PDF</label>
                    <select data-style-control="printMode">
                        <option value="link"${(b.style?.printMode || 'link') === 'link' ? ' selected' : ''}>Conserver le lien cliquable</option>
                        <option value="url"${b.style?.printMode === 'url' ? ' selected' : ''}>Afficher l’URL complète</option>
                        <option value="hide"${b.style?.printMode === 'hide' ? ' selected' : ''}>Masquer à l’impression</option>
                    </select>
                ` : ''}

                ${b.type === 'barcode-image' ? `
                    <label>Type de code-barres</label>
                    <select data-style-control="barcodeType">
                        <option value="Code39"${(b.style?.barcodeType || 'Code39') === 'Code39' ? ' selected' : ''}>Code39 — recommandé</option>
                        <option value="EAN13"${b.style?.barcodeType === 'EAN13' ? ' selected' : ''}>EAN13</option>
                        <option value="EAN8"${b.style?.barcodeType === 'EAN8' ? ' selected' : ''}>EAN8</option>
                        <option value="UPCA"${b.style?.barcodeType === 'UPCA' ? ' selected' : ''}>UPCA</option>
                        <option value="UPCE"${b.style?.barcodeType === 'UPCE' ? ' selected' : ''}>UPCE</option>
                        <option value="NW7"${b.style?.barcodeType === 'NW7' ? ' selected' : ''}>NW7</option>
                        <option value="ITF"${b.style?.barcodeType === 'ITF' ? ' selected' : ''}>ITF</option>
                        <option value="Matrix2of5"${b.style?.barcodeType === 'Matrix2of5' ? ' selected' : ''}>Matrix 2 of 5</option>
                        <option value="Industrial2of5"${b.style?.barcodeType === 'Industrial2of5' ? ' selected' : ''}>Industrial 2 of 5</option>
                        <option value="IATA2of5"${b.style?.barcodeType === 'IATA2of5' ? ' selected' : ''}>IATA 2 of 5</option>
                        <option value="COOP2of5"${b.style?.barcodeType === 'COOP2of5' ? ' selected' : ''}>COOP 2 of 5</option>
                    </select>

                    <div class="pmk142-row">
                        <div style="flex:1">
                            <label>Hauteur (px)</label>
                            <input type="number" min="20" max="180" data-style-control="barcodeHeight" value="${Number(b.style?.barcodeHeight || 50)}">
                        </div>
                        <div style="flex:1">
                            <label>Largeur affichée (px)</label>
                            <input type="number" min="80" max="420" data-style-control="imageWidth" value="${Number(b.style?.imageWidth || 190)}">
                        </div>
                    </div>

                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showText"${b.style?.showText !== false ? ' checked' : ''}>
                        Afficher le numéro sous le code-barres
                    </label>
                    <div class="pmk142-muted">
                        Code39 accepte facilement les codes-barres alphanumériques et reste le choix recommandé par défaut.
                    </div>
                ` : ''}

                ${['items', 'items-table'].includes(b.type) ? `
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showBarcode"${b.style?.showBarcode !== false ? ' checked' : ''}>
                        Afficher le code-barres
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showCallnumber"${b.style?.showCallnumber !== false ? ' checked' : ''}>
                        Afficher la cote
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showHomeLibrary"${b.style?.showHomeLibrary !== false ? ' checked' : ''}>
                        Afficher le site propriétaire
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showHoldingLibrary"${b.style?.showHoldingLibrary !== false ? ' checked' : ''}>
                        Afficher le site actuel
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showLocation"${b.style?.showLocation !== false ? ' checked' : ''}>
                        Afficher la localisation
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showItemType"${b.style?.showItemType !== false ? ' checked' : ''}>
                        Afficher le type de document
                    </label>
                    <label style="font-weight:600">
                        <input type="checkbox" data-style-control="showStatus"${b.style?.showStatus !== false ? ' checked' : ''}>
                        Afficher le statut
                    </label>
                    ${b.type === 'items-table' ? `
                        <label style="font-weight:600">
                            <input type="checkbox" data-style-control="showAcquisitionDate"${b.style?.showAcquisitionDate ? ' checked' : ''}>
                            Afficher la date d’acquisition
                        </label>
                    ` : ''}
                ` : ''}

                <hr style="border:0;border-top:1px solid #e3e8ec;margin:12px 0">
                <label>Habillage / positionnement</label>
                <select data-style-control="wrapMode">
                    <option value="normal"${!b.style?.wrapMode || b.style?.wrapMode === 'normal' ? ' selected' : ''}>Dans le flux</option>
                    <option value="float-left"${b.style?.wrapMode === 'float-left' ? ' selected' : ''}>Flottant à gauche — texte à droite</option>
                    <option value="float-right"${b.style?.wrapMode === 'float-right' ? ' selected' : ''}>Flottant à droite — texte à gauche</option>
                    <option value="full"${b.style?.wrapMode === 'full' ? ' selected' : ''}>Pleine largeur — texte au-dessus/dessous</option>
                    <option value="inline"${b.style?.wrapMode === 'inline' ? ' selected' : ''}>En ligne / côte à côte</option>
                </select>

                <div class="pmk142-row">
                    <div style="flex:1">
                        <label>Largeur du bloc (%)</label>
                        <input type="number" min="10" max="100" data-style-control="blockWidth" value="${Number(b.style?.blockWidth || 100)}">
                    </div>
                    <div style="flex:1">
                        <label>Espace autour (mm)</label>
                        <input type="number" min="0" max="20" step="0.5" data-style-control="wrapGap" value="${Number(b.style?.wrapGap ?? 2)}">
                    </div>
                </div>

                <label style="font-weight:600">
                    <input type="checkbox" data-style-control="clearBefore"${b.style?.clearBefore ? ' checked' : ''}>
                    Revenir sous les éléments flottants avant ce bloc
                </label>

                <label style="font-weight:600">
                    <input type="checkbox" data-block-control="hiddenWhenEmpty"${b.hiddenWhenEmpty !== false ? ' checked' : ''}>
                    Masquer si vide
                </label>
                <label style="font-weight:600">
                    <input type="checkbox" data-style-control="italic"${b.style?.italic ? ' checked' : ''}>
                    Italique
                </label>
                <label style="font-weight:600">
                    <input type="checkbox" data-style-control="muted"${b.style?.muted ? ' checked' : ''}>
                    Couleur secondaire
                </label>
            </div>
        `;
    }

    function biblioVisibilityKey(biblio) {
        if (!biblio) return '';
        return clean(
            biblio.biblionumber
            || biblio.biblio_id
            || biblio.link
            || [biblio.title, biblio.author].filter(Boolean).join('|')
        );
    }

    function itemVisibilityKey(item) {
        if (!item) return '';
        return clean(
            item.item_id
            || item.itemNumber
            || item.itemnumber
            || item.barcode
            || item.external_id
            || [
                item.biblionumber,
                item.callnumber,
                item.home_library_id
            ].filter(Boolean).join('|')
        );
    }

    function resetContentVisibility() {
        current.hiddenBiblios = new Set();
        current.hiddenItems = new Set();
        current.contentManagerSearch = '';
    }

    function isBiblioVisible(biblio) {
        const key = biblioVisibilityKey(biblio);
        return !key || !current.hiddenBiblios.has(key);
    }

    function isItemVisible(item) {
        const key = itemVisibilityKey(item);
        return !key || !current.hiddenItems.has(key);
    }

    function filteredRecordForPublication(record) {
        if (!record || !isBiblioVisible(record.biblio)) return null;

        if (record.item && !isItemVisible(record.item)) return null;

        const visibleItems = (record.items || []).filter(isItemVisible);

        return {
            ...record,
            items: visibleItems,
            item: record.item && isItemVisible(record.item) ? record.item : null
        };
    }

    function contentGroups() {
        const groups = new Map();

        (current.records || []).forEach(record => {
            const biblio = record.biblio || {};
            const key = biblioVisibilityKey(biblio) || uid('anonymous-bib');

            if (!groups.has(key)) {
                groups.set(key, {
                    key,
                    biblio,
                    items: []
                });
            }

            const group = groups.get(key);
            const candidates = record.item
                ? [record.item]
                : (record.items || []);

            candidates.forEach(item => {
                const itemKey = itemVisibilityKey(item);
                if (!itemKey) return;
                if (!group.items.some(existing => itemVisibilityKey(existing) === itemKey)) {
                    group.items.push(item);
                }
            });
        });

        return [...groups.values()];
    }

    function contentVisibilityStats() {
        const groups = contentGroups();
        const totalBiblios = groups.length;
        const visibleBiblios = groups.filter(group => isBiblioVisible(group.biblio)).length;

        const allItems = groups.flatMap(group => group.items);
        const totalItems = allItems.length;
        const visibleItems = allItems.filter(isItemVisible).length;

        return { totalBiblios, visibleBiblios, totalItems, visibleItems };
    }

    function renderContentManager() {
        const modal = document.querySelector('#' + ROOT_ID + ' [data-zone="content-manager"]');
        if (!modal) return;

        const groups = contentGroups();
        const q = clean(current.contentManagerSearch).toLocaleLowerCase('fr');

        const visibleGroups = q
            ? groups.filter(group => {
                const haystack = [
                    group.biblio?.title,
                    group.biblio?.subtitle,
                    group.biblio?.author,
                    group.biblio?.biblionumber,
                    ...group.items.flatMap(item => [
                        item.barcode,
                        item.callnumber,
                        item.home_library_id,
                        item.holding_library_id,
                        item.location
                    ])
                ].filter(Boolean).join(' ').toLocaleLowerCase('fr');

                return haystack.includes(q);
            })
            : groups;

        const stats = contentVisibilityStats();

        modal.innerHTML = `
            <div class="pmk142-content-dialog" role="dialog" aria-modal="true" aria-label="Choisir le contenu publié">
                <div class="pmk142-content-header">
                    <div>
                        <strong>Choisir le contenu publié</strong>
                        <div class="pmk142-muted">
                            ${stats.visibleBiblios}/${stats.totalBiblios} notice(s) affichée(s)
                            ${stats.totalItems ? ` • ${stats.visibleItems}/${stats.totalItems} exemplaire(s) affiché(s)` : ''}
                        </div>
                    </div>
                    <button type="button" class="pmk142-btn" data-action="close-content-manager">×</button>
                </div>

                <div class="pmk142-content-tools">
                    <input type="text"
                           data-control="content-manager-search"
                           placeholder="Rechercher un titre, auteur, code-barres, cote…"
                           value="${esc(current.contentManagerSearch)}">
                    <button type="button" class="pmk142-btn" data-action="content-show-all">Tout afficher</button>
                    <button type="button" class="pmk142-btn" data-action="content-hide-all">Tout masquer</button>
                </div>

                <div class="pmk142-content-list">
                    ${visibleGroups.map(group => {
                        const bibChecked = isBiblioVisible(group.biblio);
                        return `
                            <section class="pmk142-content-biblio">
                                <label class="pmk142-content-biblio-label">
                                    <input type="checkbox"
                                           data-content-biblio="${esc(group.key)}"
                                           ${bibChecked ? 'checked' : ''}>
                                    <span>
                                        <strong>${esc(group.biblio?.title || 'Sans titre')}</strong>
                                        ${group.biblio?.author ? `<small>${esc(group.biblio.author)}</small>` : ''}
                                        ${group.biblio?.biblionumber ? `<small>Notice ${esc(group.biblio.biblionumber)}</small>` : ''}
                                    </span>
                                </label>

                                <div class="pmk142-muted">
                                    ${group.biblio?._pmkSources ? 'Source de liste conservée · Données Koha : '+(group.biblio._pmkSources.json?'chargées':'indisponibles')+' · MARC : '+(group.biblio._pmkSources.marc?'chargé':'indisponible') : 'Données de la liste source'}
                                    ${group.biblio?.biblionumber ? `<button type="button" class="pmk142-btn" data-action="retry-notice" data-biblionumber="${esc(group.biblio.biblionumber)}" ${current.loading?'disabled':''}>Actualiser cette notice</button>` : ''}
                                </div>

                                ${group.items.length ? `
                                    <div class="pmk142-content-items">
                                        ${group.items.map(item => {
                                            const itemKey = itemVisibilityKey(item);
                                            return `
                                                <label>
                                                    <input type="checkbox"
                                                           data-content-item="${esc(itemKey)}"
                                                           ${isItemVisible(item) ? 'checked' : ''}>
                                                    <span>
                                                        ${esc(item.barcode || 'Sans code-barres')}
                                                        ${item.callnumber ? ` • ${esc(item.callnumber)}` : ''}
                                                        ${item.home_library_id ? ` • ${esc(item.home_library_id)}` : ''}
                                                        ${item.location ? ` • ${esc(item.location)}` : ''}
                                                    </span>
                                                </label>
                                            `;
                                        }).join('')}
                                    </div>
                                ` : ''}
                            </section>
                        `;
                    }).join('') || '<div class="pmk142-muted">Aucun résultat.</div>'}
                </div>

                <div class="pmk142-content-footer">
                    <span class="pmk142-muted">Les éléments masqués ne sont pas supprimés de la liste source.</span>
                    <button type="button" class="pmk142-btn pmk142-btn-primary" data-action="close-content-manager">Terminé</button>
                </div>
            </div>
        `;
    }

    function openContentManager() {
        const modal = document.querySelector('#' + ROOT_ID + ' [data-zone="content-manager"]');
        if (!modal) return;
        modal.hidden = false;
        renderContentManager();
    }

    function closeContentManager() {
        const modal = document.querySelector('#' + ROOT_ID + ' [data-zone="content-manager"]');
        if (modal) modal.hidden = true;
    }

    function recordsForPreview() {
        let rows = (current.records || [])
            .map(filteredRecordForPublication)
            .filter(Boolean);

        const q = clean(current.filterText).toLocaleLowerCase('fr');

        if (q) {
            rows = rows.filter(record => {
                const text = [
                    record.biblio?.title,
                    record.biblio?.subtitle,
                    record.biblio?.author,
                    record.biblio?.editor,
                    record.item?.barcode,
                    record.item?.callnumber,
                    record.item?.home_library_id,
                    ...(record.items || []).flatMap(i => [
                        i.barcode,
                        i.callnumber,
                        i.home_library_id,
                        i.holding_library_id,
                        i.location,
                        i.item_type_id,
                        i.not_for_loan_status
                    ])
                ].filter(value => value !== '' && value != null).join(' ').toLocaleLowerCase('fr');
                return text.includes(q);
            });
        }

        const sortKey = current.sortBy;
        rows.sort((a, b) => asText(resolveField(a, sortKey)).localeCompare(asText(resolveField(b, sortKey)), 'fr', { numeric: true, sensitivity: 'base' }));
        return rows;
    }

    function resolveField(record, field) {
        if (!record || !field) return '';

        if (field.startsWith('biblio.')) {
            return getPath(record.biblio, field.slice(7));
        }

        if (field.startsWith('item.')) {
            const itemPath = field.slice(5);

            if (record.item) {
                return getPath(record.item, itemPath);
            }

            /*
             * En mode « notice + exemplaires », record.item est volontairement
             * vide. Pour qu'un bloc individuel « Code-barres », « Cote », etc.
             * reste utilisable, on agrège les valeurs de tous les exemplaires.
             */
            const values = (record.items || [])
                .map(item => asText(getPath(item, itemPath)))
                .filter(Boolean);

            return [...new Set(values)];
        }

        return getPath(record, field);
    }

    function isNoticeNumberField(field) {
        const value = clean(field).toLowerCase();
        return value === 'biblio.biblionumber'
            || value === 'biblio.biblio_id'
            || value === 'biblio.api.biblionumber'
            || value === 'biblio.api.biblio_id';
    }

    function renderBlockHtml(b, record) {
        const st = b.style || {};

        if (!current.showBiblionumber && b.type === 'field' && isNoticeNumberField(b.field)) {
            return '';
        }
        const common = `font-size:${Number(st.size || 10)}px;font-weight:${Number(st.weight || 400)};font-style:${st.italic ? 'italic' : 'normal'};text-align:${esc(st.align || 'left')};color:${st.muted ? '#6f7d88' : 'inherit'};margin:2px 0;`;

        if (b.type === 'separator') {
            return '<hr style="border:0;border-top:1px solid #dfe4e7;margin:5px 0">';
        }

        if (b.type === 'text') {
            const value = clean(st.text);
            if (!value && b.hiddenWhenEmpty !== false) return '';
            return `<div class="pmk142-field" style="${common}">${esc(value)}</div>`;
        }

        if (b.type === 'badge') {
            const value = clean(st.text || b.label);
            if (!value && b.hiddenWhenEmpty !== false) return '';
            return `<div style="text-align:${esc(st.align || 'left')};margin:3px 0"><span class="pmk142-badge" style="font-size:${Number(st.size || 9)}px">${esc(value)}</span></div>`;
        }

        if (b.type === 'cover') {
            const candidates = uniqueCoverCandidates([
                record.biblio?.cover,
                ...(record.biblio?.coverCandidates || [])
            ]);
            const src = candidates[0] || '';

            if (!src && b.hiddenWhenEmpty !== false) return '';
            if (!src) return '';

            return `<img
                class="pmk142-cover"
                src="${esc(src)}"
                data-cover-candidates="${esc(JSON.stringify(candidates))}"
                alt="Couverture"
                loading="eager"
                style="width:${Number(st.width || 90)}px;height:${Number(st.height || 130)}px;margin-left:${st.align === 'center' ? 'auto' : '0'};margin-right:${st.align === 'center' ? 'auto' : '0'}"
            >`;
        }

        if (b.type === 'items') {
            const items = record.items || (record.item ? [record.item] : []);
            if (!items.length && b.hiddenWhenEmpty !== false) return '';

            return `<div class="pmk142-items" style="${common}">
                ${items.map(item => {
                    const bits = [];

                    if (st.showBarcode !== false && item.barcode) {
                        bits.push('CB : ' + item.barcode);
                    }

                    if (st.showCallnumber !== false && item.callnumber) {
                        bits.push('Cote : ' + item.callnumber);
                    }

                    if (st.showHomeLibrary !== false && item.home_library_id) {
                        bits.push('Site propriétaire : ' + item.home_library_id);
                    }

                    if (
                        st.showHoldingLibrary !== false &&
                        item.holding_library_id
                    ) {
                        bits.push('Site actuel : ' + item.holding_library_id);
                    }

                    if (st.showLocation !== false && item.location) {
                        bits.push('Localisation : ' + item.location);
                    }

                    if (st.showItemType !== false && item.item_type_id) {
                        bits.push('Type : ' + item.item_type_id);
                    }

                    if (
                        st.showStatus !== false &&
                        item.not_for_loan_status !== '' &&
                        item.not_for_loan_status != null
                    ) {
                        bits.push('Statut : ' + item.not_for_loan_status);
                    }

                    return '<div class="pmk142-itemline">' + esc(bits.join(' • ')) + '</div>';
                }).join('')}
            </div>`;
        }

        if (b.type === 'items-table') {
            const items = record.items || (record.item ? [record.item] : []);
            if (!items.length && b.hiddenWhenEmpty !== false) return '';

            const columns = [
                st.showBarcode !== false ? ['Code-barres', 'barcode'] : null,
                st.showCallnumber !== false ? ['Cote', 'callnumber'] : null,
                st.showHomeLibrary !== false ? ['Site propriétaire', 'home_library_id'] : null,
                st.showHoldingLibrary !== false ? ['Site actuel', 'holding_library_id'] : null,
                st.showLocation !== false ? ['Localisation', 'location'] : null,
                st.showItemType !== false ? ['Type', 'item_type_id'] : null,
                st.showStatus !== false ? ['Statut', 'not_for_loan_status'] : null,
                st.showAcquisitionDate ? ['Acquisition', 'acquisition_date'] : null
            ].filter(Boolean);

            if (!columns.length) return '';

            return `
                <div class="pmk142-items pmk142-items-table-wrap" style="${common}">
                    <table class="pmk142-items-table">
                        <thead>
                            <tr>${columns.map(([label]) => `<th>${esc(label)}</th>`).join('')}</tr>
                        </thead>
                        <tbody>
                            ${items.map(item => `
                                <tr>
                                    ${columns.map(([, key]) => `<td>${esc(asText(item[key]))}</td>`).join('')}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        if (b.type === 'notice-link') {
            let href = asText(resolveField(record, b.field || 'biblio.link'));

            if (!href && record.biblio?.biblionumber) {
                href = '/cgi-bin/koha/catalogue/detail.pl?biblionumber='
                    + encodeURIComponent(record.biblio.biblionumber);
            }

            if (!href && b.hiddenWhenEmpty !== false) return '';
            if (!href) return '';

            const absoluteHref = absoluteUrl(href);
            const label = clean(st.text) || 'Voir la notice';
            const target = st.newTab !== false
                ? ' target="_blank" rel="noopener noreferrer"'
                : '';
            const icon = st.showIcon !== false
                ? '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> '
                : '';
            const printMode = clean(st.printMode) || 'link';

            return `
                <div class="pmk142-notice-link pmk142-print-mode-${esc(printMode)}"
                     data-print-url="${esc(absoluteHref)}"
                     style="${common}">
                    <a href="${esc(absoluteHref)}"${target}>${icon}${esc(label)}</a>
                    <span class="pmk142-notice-link-print-url">${esc(absoluteHref)}</span>
                </div>
            `;
        }

        if (b.type === 'barcode-image') {
            let barcodes = [];

            if (record.item?.barcode) {
                barcodes = [record.item.barcode];
            } else {
                barcodes = (record.items || [])
                    .map(item => clean(item?.barcode))
                    .filter(Boolean);
            }

            barcodes = [...new Set(barcodes)];

            if (!barcodes.length && b.hiddenWhenEmpty !== false) return '';
            if (!barcodes.length) return '';

            const barcodeType = clean(st.barcodeType) || 'Code39';
            const barcodeHeight = Math.max(20, Math.min(180, Number(st.barcodeHeight || 50)));
            const imageWidth = Math.max(80, Math.min(420, Number(st.imageWidth || 190)));
            const showText = st.showText !== false;
            const gap = Math.max(2, Number(st.gap || 6));

            return `
                <div class="pmk142-barcode-images"
                     style="display:flex;flex-wrap:wrap;gap:${gap}px;justify-content:${
                         st.align === 'center' ? 'center' : st.align === 'right' ? 'flex-end' : 'flex-start'
                     };margin:5px 0">
                    ${barcodes.map(value => {
                        // Le service Koha génère uniquement les barres. Le numéro est
                        // affiché séparément en HTML juste dessous pour garantir un rendu
                        // lisible, homogène et imprimable, notamment dans le modèle 3 colonnes.
                        const url = '/cgi-bin/koha/svc/barcode'
                            + '?barcode=' + encodeURIComponent(value)
                            + '&type=' + encodeURIComponent(barcodeType)
                            + '&height=' + encodeURIComponent(barcodeHeight)
                            + '&notext=1';

                        return `
                            <div class="pmk142-barcode-image"
                                 style="max-width:100%;break-inside:avoid;text-align:center">
                                <img src="${esc(url)}"
                                     alt="Code-barres ${esc(value)}"
                                     loading="eager"
                                     style="display:block;width:${imageWidth}px;max-width:100%;height:auto;object-fit:contain;margin:0 auto">
                                ${showText ? `
                                    <div class="pmk142-barcode-text"
                                         style="margin-top:3px;font-size:10px;line-height:1.2;font-family:monospace;text-align:center;white-space:nowrap">
                                        ${esc(value)}
                                    </div>
                                ` : ''}
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }

        if (b.type === 'qrcode') {
            const value = asText(resolveField(record, b.field || 'biblio.link'));
            if (!value && b.hiddenWhenEmpty !== false) return '';
            if (!value) return '';

            let target = value;
            try {
                target = new URL(value, window.location.origin).href;
            } catch (_) {}

            const moduleSize = target.length <= 180 ? 5 :
                target.length <= 350 ? 6 :
                target.length <= 600 ? 7 :
                target.length <= 900 ? 8 :
                target.length <= 1400 ? 9 : 10;

            const url = '/cgi-bin/koha/svc/barcode'
                + '?type=QRcode'
                + '&barcode=' + encodeURIComponent(target)
                + '&modulesize=' + encodeURIComponent(moduleSize)
                + '&notext=1';

            const displaySize = Math.max(60, Number(st.size || 90));

            return `<div class="pmk142-qr" style="text-align:${esc(st.align || 'left')};margin:5px 0">
                <img src="${esc(url)}" alt="QR code vers le catalogue" loading="eager"
                     style="width:${displaySize}px;height:${displaySize}px;object-fit:contain">
            </div>`;
        }

        const value = asText(resolveField(record, b.field));
        if (!value && b.hiddenWhenEmpty !== false) return '';

        if (b.field === 'biblio.link' && value) {
            const href = absoluteUrl(value);
            const label = clean(st.prefix) || 'Voir la notice';
            return `<div class="pmk142-field pmk142-catalogue-link" style="${common}">
                <a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>
                ${st.suffix ? esc(st.suffix) : ''}
            </div>`;
        }

        return `<div class="pmk142-field" style="${common}">${esc(st.prefix || '')}${esc(value)}${esc(st.suffix || '')}</div>`;
    }

    function applyBlockLayout(b, html) {
        if (!html) return '';

        const st = b.style || {};
        const mode = st.wrapMode || 'normal';
        const width = Math.max(10, Math.min(100, Number(st.blockWidth || 100)));
        const gap = Math.max(0, Math.min(20, Number(st.wrapGap ?? 2)));

        const css = [];

        if (st.clearBefore) css.push('clear:both');

        if (mode === 'float-left') {
            css.push('float:left');
            css.push('width:' + width + '%');
            css.push('margin:0 ' + gap + 'mm ' + gap + 'mm 0');
        } else if (mode === 'float-right') {
            css.push('float:right');
            css.push('width:' + width + '%');
            css.push('margin:0 0 ' + gap + 'mm ' + gap + 'mm');
        } else if (mode === 'full') {
            css.push('display:block');
            css.push('width:100%');
            css.push('clear:both');
            css.push('margin:' + gap + 'mm 0');
        } else if (mode === 'inline') {
            css.push('display:inline-block');
            css.push('width:' + width + '%');
            css.push('vertical-align:top');
            css.push('margin:0 ' + gap + 'mm ' + gap + 'mm 0');
        } else {
            css.push('display:block');
            css.push('width:' + width + '%');
        }

        return `<div class="pmk142-block-wrap pmk142-wrap-${esc(mode)}" style="${css.join(';')}">${html}</div>`;
    }

    function renderRecordCard(record) {
        const t = current.workingTemplate || {};
        const cardStyle = t.card || {};
        return `<article class="pmk142-card${cardStyle.border ? ' has-border' : ''}" style="padding:${Number(cardStyle.padding || 4)}px">
            ${(t.blocks || []).map(b => applyBlockLayout(b, renderBlockHtml(b, record))).join('')}
        </article>`;
    }

    function renderPreview() {
        const zone = document.querySelector('#' + ROOT_ID + ' [data-zone="preview"]');
        if (!zone || !current.workingTemplate) return;

        const page = current.workingTemplate.page || {};
        zone.classList.toggle('landscape', page.orientation === 'landscape');
        zone.style.padding = Number(page.margin ?? 12) + 'mm';

        const rows = recordsForPreview();
        const cols = Math.max(1, Math.min(4, Number(page.columns || 1)));
        const gap = Number(page.gap || 8);

        const groupBy = current.groupBy || current.workingTemplate.groupBy || '';
        let body = '';

        if (groupBy) {
            const groups = new Map();
            rows.forEach(record => {
                const key = asText(resolveField(record, groupBy)) || 'Sans valeur';
                if (!groups.has(key)) groups.set(key, []);
                groups.get(key).push(record);
            });
            body = [...groups.entries()].map(([name, records]) =>
                `<section style="display:contents">
                    <div class="pmk142-group-title">${esc(name)}</div>
                    ${records.map(renderRecordCard).join('')}
                </section>`
            ).join('');
        } else {
            body = rows.map(renderRecordCard).join('');
        }

        zone.innerHTML = `
            <h1 class="pmk142-doc-title">${esc(current.title || current.list?.name || 'Bibliographie')}</h1>
            <div class="pmk142-grid" style="grid-template-columns:repeat(${cols},minmax(0,1fr));gap:${gap}mm">
                ${body || '<div class="pmk142-muted">Aucun résultat à afficher.</div>'}
            </div>
        `;

        activateCoverFallbacks(zone);
    }

    function selectedBlock() {
        return current.workingTemplate?.blocks?.find(b => b.id === current.selectedBlockId) || null;
    }

    async function applySelectedTemplate(id, rebuild = true) {
        const template = [...BUILTIN_TEMPLATES, ...current.templates].find(t => t.id === id);
        if (!template) return;

        current.selectedTemplateId = id;
        current.workingTemplate = clone(template);
        current.workingTemplate.blocks = (current.workingTemplate.blocks || []).map(b => ({ ...b, id: uid('block') }));
        current.selectedBlockId = current.workingTemplate.blocks[0]?.id || '';

        if (template.mode) current.mode = template.mode;
        if (template.useSourceNameAsTitle) {
            current.title = clean(
                current.list?.name
                || current.source?.name
                || 'Bibliographie'
            );
        }
        current.showBiblionumber = template.showBiblionumber !== false;
        if (template.groupBy && !current.groupBy) current.groupBy = template.groupBy;

        if (rebuild) await rebuildRecords();
        await refreshLeftPanel();
        refreshRightPanel();
        renderPreview();
    }

    function effectiveSourceEntries() {
        const entries = [...(current.entries || [])];

        if (
            current.source?.kind === 'koha-bundle'
            && current.includeBundleHost
            && current.bundleHostItem
        ) {
            const hostId = clean(
                current.bundleHostItem.item_id
                || current.bundleHostItem.itemnumber
                || current.bundleHostItem.itemNumber
            );

            const alreadyPresent = entries.some(entry =>
                clean(entry?.item_id || entry?.itemnumber || entry?.itemNumber) === hostId
            );

            if (!alreadyPresent) entries.unshift(current.bundleHostItem);
        }

        return entries;
    }

    // One revision protects all sources and ignores late responses from older selections.
    let recordsRevision = 0;
    async function rebuildRecords() {
        if(!current.list)return;
        const revision=++recordsRevision;
        const list=current.list,entries=effectiveSourceEntries(),mode=current.mode,allItems=current.allItemsForItemLists;
        const isCourse=current.source?.kind==='koha-course-reserves';
        const grouped=new Map();
        entries.forEach(raw=>{const bib=clean(raw.biblionumber || raw.biblio_id || raw.biblioNumber);const key=bib || 'item:'+clean(raw.item_id || raw.itemnumber);if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(raw);});
        const operation={revision,total:list.type==='notice'?entries.length:grouped.size,done:0,covers:0,dataDone:false,errors:0};
        current.loading=true;current.loadWarning=false;current.error='';
        current.records=list.type==='notice' ? entries.map(raw=>({biblio:normalizeStoredNotice(raw),item:null,items:[]}))
            : [...grouped.values()].flatMap(group=>{const first=group[0],biblio=normalizeStoredNotice(first),items=group.map(normalizeStoredItem);return mode==='item'?items.map(item=>({biblio,item,items:[item]})):[{biblio,item:null,items:mode==='notice'?[]:items}];});
        renderPreview();updateLoading(operation);
        try {
            const records=isCourse ? await buildRecordsFromCourseReserves(entries,mode,allItems,operation)
                : await buildRecordsFromPmk(list,entries,mode,allItems,operation);
            if(revision!==recordsRevision)return;
            current.records=records;
        } catch(error) {
            if(revision!==recordsRevision)return;
            current.error=error?.message || String(error);operation.errors++;
        } finally {
            if(revision===recordsRevision){operation.dataDone=true;renderPreview();updateLoading(operation);}
        }
    }

    async function selectPmkList(listId) {
        const api = await listsApi();
        if (!api || !listId) return;
        const selection=++sourceSelection;
        setStatus('Chargement de la liste…',true);
        try {
            const [list,entries]=await Promise.all([api.getList(listId),api.getEntries(listId)]);
            if(selection!==sourceSelection)return;
            resetContentVisibility();
            current.source = { kind: 'pmk', type: list?.type || 'notice', name: list?.name || '' };
            current.list = list;
            current.entries = entries;
            current.bundleHostItem = null;
            current.includeBundleHost = false;
            current.title = current.title || list?.name || 'Bibliographie';
            await rebuildRecords();
        } finally {
            if(selection===sourceSelection)setStatus('');
        }
    }

    async function loadInitialSource() {
        const params = query();
        const source = params.get('source');

        if (source === 'session') {
            try {
                const payload = JSON.parse(sessionStorage.getItem(SESSION_SOURCE_KEY) || 'null');

                if (payload?.entries?.length) {
                    const kind = payload.kind || 'koha-native';
                    const type = ['item', 'mixed'].includes(payload.type)
                        ? payload.type
                        : 'notice';

                    const sessionId = kind === 'koha-bundle'
                        ? 'session-bundle-' + clean(payload.bundleItemId || 'bundle')
                        : kind === 'koha-basket'
                            ? 'session-basket'
                            : kind === 'koha-course-reserves'
                                ? 'session-course-' + clean(payload.courseId || 'course')
                                : 'session-koha';

                    const fallbackName = kind === 'koha-bundle'
                        ? 'Paquet Koha'
                        : kind === 'koha-basket'
                            ? 'Panier Koha'
                            : kind === 'koha-course-reserves'
                                ? 'Réserve de cours'
                                : 'Liste Koha';

                    resetContentVisibility();
                    current.source = payload;
                    current.list = {
                        id: sessionId,
                        name: payload.name || fallbackName,
                        type
                    };
                    current.entries = payload.entries;
                    current.bundleHostItem = payload.hostItem || null;
                    current.includeBundleHost = false;
                    current.allItemsForItemLists = false;
                    current.title = current.list.name;

                    await rebuildRecords();
                    return;
                }
            } catch (error) {
                console.warn('[PMK142] Source de session illisible', error);
            }
        }

        const api = await listsApi();
        if (!api) throw new Error('Gestionnaire de listes PMK indisponible.');

        const listId = params.get('list');
        if (listId) {
            await selectPmkList(listId);
            return;
        }

        const lists = await listOptions();
        if (lists.length) await selectPmkList(lists[0].id);
    }

    async function loadTemplatesAndPreset() {
        current.templates = await loadUserTemplates();
        const wanted = query().get('template') || config.defaultTemplate || DEFAULT_CONFIG.defaultTemplate;
        const exists = [...BUILTIN_TEMPLATES, ...current.templates].some(t => t.id === wanted);
        current.selectedTemplateId = exists ? wanted : BUILTIN_TEMPLATES[0].id;
        const template = [...BUILTIN_TEMPLATES, ...current.templates].find(t => t.id === current.selectedTemplateId);
        current.workingTemplate = clone(template);
        current.workingTemplate.blocks = (current.workingTemplate.blocks || []).map(b => ({ ...b, id: uid('block') }));
        current.mode = template?.mode || config.defaultMode;
        current.showBiblionumber = template?.showBiblionumber !== false;
        current.groupBy = template?.groupBy || '';
        current.selectedBlockId = current.workingTemplate.blocks[0]?.id || '';
    }

    async function duplicateCurrentTemplate() {
        const name = prompt('Nom du nouveau modèle :', 'Copie de ' + (current.workingTemplate?.name || 'modèle'));
        if (name == null || !clean(name)) return;

        const copy = clone(current.workingTemplate);
        copy.id = '';
        copy.name = clean(name);
        copy.builtin = false;

        setStatus('Enregistrement du modèle…');
        try {
            const id = await saveUserTemplate(copy, copy.name);
            current.templates = await loadUserTemplates();
            await applySelectedTemplate(id, false);
        } catch (error) {
            alert(error?.message || error);
        } finally {
            setStatus('');
        }
    }

    async function saveCurrentTemplate() {
        if (!current.workingTemplate) return;
        let name = current.workingTemplate.name || 'Mon modèle';

        if (String(current.selectedTemplateId).startsWith('builtin-')) {
            const proposed = prompt('Les modèles PMK sont protégés. Nom de votre copie personnalisée :', 'Copie de ' + name);
            if (proposed == null || !clean(proposed)) return;
            name = clean(proposed);
            current.workingTemplate.id = '';
            current.workingTemplate.builtin = false;
        }

        current.workingTemplate.name = name;
        current.workingTemplate.mode = current.mode;
        current.workingTemplate.groupBy = current.groupBy;
        current.workingTemplate.showBiblionumber = current.showBiblionumber;

        setStatus('Enregistrement du modèle…');
        try {
            const id = await saveUserTemplate(current.workingTemplate, name);
            current.templates = await loadUserTemplates();
            current.selectedTemplateId = id;
            current.workingTemplate.id = id;
            alert('Modèle enregistré.');
            await refreshLeftPanel();
        } catch (error) {
            alert(error?.message || error);
        } finally {
            setStatus('');
        }
    }

    function exportCurrentTemplate() {
        if (!current.workingTemplate) return;
        const data = clone(current.workingTemplate);
        data.exportedBy = 'PimpMyKoha 142';
        data.exportedAt = new Date().toISOString();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (clean(data.name || 'modele-bibliographie').replace(/[^\p{L}\p{N}._-]+/gu, '-') || 'modele') + '.pmk-biblio.json';
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 0);
    }

    async function importTemplateFile(file) {
        if (!file) return;
        try {
            const data = JSON.parse(await file.text());
            if (!Array.isArray(data.blocks) || !data.name) throw new Error('Ce fichier ne ressemble pas à un modèle PMK de bibliographie.');
            data.id = '';
            data.builtin = false;
            data.name = clean(data.name) + ' (importé)';
            const id = await saveUserTemplate(data, data.name);
            current.templates = await loadUserTemplates();
            await applySelectedTemplate(id, false);
        } catch (error) {
            alert(error?.message || error);
        }
    }

    async function handleRootClick(event) {
        const actionEl = event.target.closest('[data-action]');
        if (!actionEl) return;
        const action = actionEl.dataset.action;

        if (action === 'open-content-manager') {
            openContentManager();
            return;
        }
        if (action === 'close-content-manager') {
            closeContentManager();
            await refreshLeftPanel();
            renderPreview();
            return;
        }
        if (action === 'content-show-all') {
            current.hiddenBiblios.clear();
            current.hiddenItems.clear();
            renderContentManager();
            renderPreview();
            await refreshLeftPanel();
            return;
        }
        if (action === 'content-hide-all') {
            contentGroups().forEach(group => {
                if (group.key) current.hiddenBiblios.add(group.key);
                group.items.forEach(item => {
                    const itemKey = itemVisibilityKey(item);
                    if (itemKey) current.hiddenItems.add(itemKey);
                });
            });
            renderContentManager();
            renderPreview();
            await refreshLeftPanel();
            return;
        }

        if(action==='retry-notice') {
            if(current.loading)return;
            const id=clean(actionEl.dataset.biblionumber),record=current.records.find(r=>clean(r.biblio?.biblionumber)===id);
            if(!record)return;
            const revision=recordsRevision,operation={revision,total:1,done:0,covers:0,dataDone:false,errors:0};
            actionEl.disabled=true;updateLoading(operation);
            const suffix='/biblios/'+encodeURIComponent(id);
            for(const key of readCache.keys())if(key.endsWith(suffix))readCache.delete(key);
            coverResolutionCache.delete(id);detailHtmlCache.delete(id);
            try{
                const biblio=await enrichNotice(record.biblio,{operation});
                if(revision!==recordsRevision)return;
                current.records.forEach(r=>{if(clean(r.biblio?.biblionumber)===id)r.biblio=biblio;});
                renderPreview();renderContentManager();
            }catch(error){operation.errors++;if(revision===recordsRevision)setStatus(error.message);}
            finally{operation.done=1;operation.dataDone=true;updateLoading(operation);actionEl.disabled=false;if(revision===recordsRevision)renderContentManager();}
            return;
        }
        if(action==='reload-data') {
            readCache.clear();coverResolutionCache.clear();detailHtmlCache.clear();
            window.PMKCoverResolver?.clearCache?.();
            listChoicesPromise=null;
            if(!window.PMKPersonalLists)listsReadyPromise=null;
            await rebuildRecords();return;
        }
        if (action === 'close') {
            if (document.getElementById(ROOT_ID)?.closest('.pmk138-app-container')) {window.location.href=window.PMKPages.canOpen('hub')?window.PMKPages.urlFor('hub'):'/cgi-bin/koha/mainpage.pl';return;}
            history.back();
            return;
        }
        if (action === 'print') {
            window.print();
            return;
        }
        if (action === 'duplicate-template') {
            await duplicateCurrentTemplate();
            return;
        }
        if (action === 'save-template') {
            await saveCurrentTemplate();
            return;
        }
        if (action === 'export-template') {
            exportCurrentTemplate();
            return;
        }
        if (action === 'import-template') {
            document.querySelector('#' + ROOT_ID + ' [data-control="import-file"]')?.click();
            return;
        }
        if (action === 'delete-template') {
            if (!confirm('Supprimer ce modèle personnel ?')) return;
            await deleteUserTemplate(current.selectedTemplateId);
            current.templates = await loadUserTemplates();
            await applySelectedTemplate(config.defaultTemplate || BUILTIN_TEMPLATES[0].id, false);
            return;
        }
        if (action === 'add-block') {
            const choice = document.querySelector('#' + ROOT_ID + ' [data-control="add-block-kind"]')?.value || 'field:biblio.title';
            const b = createBlockFromLibrary(choice);
            current.workingTemplate.blocks.push(b);
            current.selectedBlockId = b.id;
            renderBlocks();
            refreshRightPanel();
            renderPreview();
            return;
        }
        if (action === 'remove-block') {
            const id = actionEl.dataset.blockId;
            current.workingTemplate.blocks = current.workingTemplate.blocks.filter(b => b.id !== id);
            if (current.selectedBlockId === id) current.selectedBlockId = current.workingTemplate.blocks[0]?.id || '';
            renderBlocks();
            refreshRightPanel();
            renderPreview();
        }
    }

    async function handleRootChange(event) {
        if (event.target.matches('[data-content-biblio]')) {
            const key = clean(event.target.dataset.contentBiblio);
            if (key) {
                if (event.target.checked) current.hiddenBiblios.delete(key);
                else current.hiddenBiblios.add(key);
            }
            renderContentManager();
            renderPreview();
            return;
        }

        if (event.target.matches('[data-content-item]')) {
            const key = clean(event.target.dataset.contentItem);
            if (key) {
                if (event.target.checked) current.hiddenItems.delete(key);
                else current.hiddenItems.add(key);
            }
            renderContentManager();
            renderPreview();
            return;
        }

        const control = event.target.dataset.control;
        if (control === 'source-list') {
            await selectPmkList(event.target.value);
            await refreshLeftPanel();
            return;
        }
        if (control === 'mode') {
            current.mode = event.target.value;
            await rebuildRecords();
            return;
        }
        if (control === 'show-biblionumber') {
            current.showBiblionumber = !!event.target.checked;
            renderPreview();
            return;
        }
        if (control === 'all-items') {
            current.allItemsForItemLists = !!event.target.checked;
            await rebuildRecords();
            return;
        }
        if (control === 'include-bundle-host') {
            current.includeBundleHost = !!event.target.checked;
            await rebuildRecords();
            return;
        }
        if (control === 'template') {
            await applySelectedTemplate(event.target.value);
            return;
        }
        if (control === 'columns') {
            current.workingTemplate.page.columns = Math.max(1, Math.min(4, Number(event.target.value || 1)));
            renderPreview();
            return;
        }
        if (control === 'margin') {
            current.workingTemplate.page.margin = Math.max(0, Math.min(35, Number(event.target.value || 0)));
            renderPreview();
            return;
        }
        if (control === 'orientation') {
            current.workingTemplate.page.orientation = event.target.value;
            renderPreview();
            return;
        }
        if (control === 'sort-by') {
            current.sortBy = event.target.value;
            renderPreview();
            return;
        }
        if (control === 'group-by') {
            current.groupBy = event.target.value;
            renderPreview();
            return;
        }
        if (control === 'import-file') {
            await importTemplateFile(event.target.files?.[0]);
            event.target.value = '';
            return;
        }

        const block = selectedBlock();
        if (!block) return;

        if (event.target.dataset.blockControl) {
            const key = event.target.dataset.blockControl;
            if (key === 'hiddenWhenEmpty') block.hiddenWhenEmpty = !!event.target.checked;
            else if (key === 'field-free') block.field = event.target.value;
            else block[key] = event.target.value;
            renderBlocks();
            renderPreview();
            return;
        }

        if (event.target.dataset.styleControl) {
            const key = event.target.dataset.styleControl;
            let value = event.target.type === 'checkbox' ? !!event.target.checked : event.target.value;
            if (['size', 'weight', 'width', 'height', 'barcodeHeight', 'imageWidth', 'gap', 'blockWidth', 'wrapGap'].includes(key)) value = Number(value || 0);
            block.style[key] = value;
            renderPreview();
        }
    }

    function handleRootInput(event) {
        const control = event.target.dataset.control;

        if (control === 'content-manager-search') {
            current.contentManagerSearch = event.target.value;
            renderContentManager();
            const input = document.querySelector(
                '#' + ROOT_ID + ' [data-control="content-manager-search"]'
            );
            if (input) {
                input.focus();
                input.setSelectionRange(input.value.length, input.value.length);
            }
            return;
        }
        if (control === 'doc-title') {
            current.title = event.target.value;
            renderPreview();
            return;
        }
        if (control === 'filter-text') {
            current.filterText = event.target.value;
            renderPreview();
            return;
        }

        const block = selectedBlock();
        if (!block) return;

        if (event.target.dataset.blockControl) {
            const key = event.target.dataset.blockControl;
            if (key === 'field-free') block.field = event.target.value;
            else block[key] = event.target.value;
            renderBlocks();
            renderPreview();
            return;
        }

        if (event.target.dataset.styleControl) {
            const key = event.target.dataset.styleControl;
            let value = event.target.type === 'checkbox' ? !!event.target.checked : event.target.value;
            if (['size', 'weight', 'width', 'height', 'barcodeHeight', 'imageWidth', 'gap', 'blockWidth', 'wrapGap'].includes(key)) value = Number(value || 0);
            block.style[key] = value;
            renderPreview();
        }
    }

    async function initBuilderPage(managedContainer) {
        if (!isBuilderPage() || builderInitStarted) return;
        builderInitStarted = true;
        if (managedContainer && !document.getElementById(ROOT_ID)) {const root=document.createElement('div');root.id=ROOT_ID;managedContainer.appendChild(root);}
        installStyles();
        // Afficher une interface immédiatement, même si stockage Koha ou PMK tarde.
        try {
            current.templates = [];
            const preset = BUILTIN_TEMPLATES.find(t => t.id === DEFAULT_CONFIG.defaultTemplate) || BUILTIN_TEMPLATES[0];
            current.selectedTemplateId = preset.id;
            current.workingTemplate = clone(preset);
            current.workingTemplate.blocks = (current.workingTemplate.blocks || []).map(b => ({ ...b, id: uid('block') }));
            current.mode = preset.mode || DEFAULT_CONFIG.defaultMode;
            current.selectedBlockId = current.workingTemplate.blocks[0]?.id || '';
            await renderBuilder();
            // Les modèles stockage Koha ne bloquent plus le premier rendu ni la source du paquet.
            const templatesTask = loadUserTemplates().then(templates => {
                current.templates = templates;
                // Conserver le modèle déjà visible et les éventuelles modifications de l'agent.
                // Les modèles personnels deviennent disponibles dans le sélecteur au chargement.
                return refreshLeftPanel();
            }).catch(error => {
                console.warn('[PMK142] Modèles personnels indisponibles', error);
            });
            if (query().get('source') !== 'session') await refreshLeftPanel();
            refreshRightPanel();
            renderPreview();
            setStatus('Chargement de la source…',true);
            await loadInitialSource();
            await refreshLeftPanel();
            refreshRightPanel();
            renderPreview();
            // Ne pas attendre templatesTask : stockage Koha peut être lent ou indisponible.
            void templatesTask;
            setStatus('');
        } catch (error) {
            console.error('[PMK142] Échec initialisation', error);
            const root = document.getElementById(ROOT_ID) || document.body;
            const message = document.createElement('div');
            message.setAttribute('role', 'alert');
            message.style.cssText = 'position:relative;z-index:99999;padding:18px;margin:16px;background:#fff3cd;color:#664d03;border:1px solid #ffecb5;border-radius:6px';
            message.textContent = 'Bibliographies & publications : erreur de chargement — ' + (error?.message || String(error));
            root.prepend(message);
            setStatus('');
        }
    }

    function registerWithPMK() {
        if (!window.PMKConfig || registered) return false;
        registered = true;

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 2,
            validate:cfg=>({ok:(!cfg.readTimeoutMs||(Number(cfg.readTimeoutMs)>=1000&&Number(cfg.readTimeoutMs)<=180000))&&(!cfg.readConcurrency||(Number(cfg.readConcurrency)>=1&&Number(cfg.readConcurrency)<=5)),message:'Délai de lecture : 1 000 à 180 000 ms ; concurrence : 1 à 5.'}),
            name: { fr: 'Bibliographies & publications', en: 'Bibliographies & publications' },
            description: {
                fr: 'Crée des bibliographies et publications personnalisées à partir des listes PMK, listes Koha, paniers, paquets et réserves de cours, par notices ou exemplaires. Les modèles personnels sont stockés sous le profil logique PMK actif, sans authentification supplémentaire.',
                en: 'Creates customizable bibliographies and publications from PMK lists, Koha lists, carts, bundles and course reserves, using bibliographic records or items.'
            },
            category: { fr: 'Outils', en: 'Tools' },
            defaults: DEFAULT_CONFIG,
            schema: [
                {key:'defaultTemplate',type:'text',label:{fr:'Identifiant du modèle proposé à l’ouverture',en:'Initial template ID'},help:{fr:'Identifiant d’un modèle intégré ou personnel ; vos brouillons restent prioritaires.',en:'Built-in or personal template ID.'}},
                {key:'readTimeoutMs',type:'number',advanced:true,label:{fr:'Délai maximal de lecture (ms)',en:'Read timeout (ms)'},min:1000,max:180000},
                {key:'readConcurrency',type:'number',advanced:true,label:{fr:'Lectures de notices simultanées',en:'Concurrent record reads'},min:1,max:5},
                { key: 'injectPersonalListsButton', type: 'boolean', label: { fr: 'Ajouter le bouton dans les listes PMK', en: 'Add button to PMK lists' } },
                { key: 'injectKohaListsButton', type: 'boolean', label: { fr: 'Ajouter le bouton dans les listes Koha', en: 'Add button to Koha lists' } },
                { key: 'injectBundleButton', type: 'boolean', label: { fr: 'Ajouter le bouton dans les paquets Koha', en: 'Add button to Koha bundles' } },
                { key: 'injectBasketButton', type: 'boolean', label: { fr: 'Ajouter le bouton dans le panier Koha', en: 'Add button to Koha cart' } },
                { key: 'injectCourseReservesButton', type: 'boolean', label: { fr: 'Ajouter le bouton dans les réserves de cours', en: 'Add button to course reserves' } }
            ]
        });

        window.PMKConfig.getConfig(MODULE_ID).then(value => {
            config = { ...DEFAULT_CONFIG, ...(value || {}) };
            if (config.enabled !== false) {
                injectPersonalListButtons();
                injectKohaNativeListButton();
                injectKohaBasketButton();
                injectCourseReservesButton();
                scheduleBundleBibliographyInjection();
                if (isBuilderPage() && !window.PMKPages) initBuilderPage();
            }
        }).catch(() => {
            config = { ...DEFAULT_CONFIG };
            if (isBuilderPage() && !window.PMKPages) initBuilderPage();
        });

        if (typeof window.PMKConfig.subscribe === 'function') {
            window.PMKConfig.subscribe(MODULE_ID, value => {
                config = { ...DEFAULT_CONFIG, ...(value || {}) };
                if (config.enabled !== false) {
                    injectPersonalListButtons();
                    injectKohaNativeListButton();
                    injectKohaBasketButton();
                    injectCourseReservesButton();
                    scheduleBundleBibliographyInjection();
                }
            });
        }
        return true;
    }

    function boot() {
        installIntegrationObserver();
        // La page dédiée ne doit pas dépendre de l'arrivée du module de configuration.
        // Un appel ultérieur depuis PMKConfig ne recréera pas l'interface.
        if (isBuilderPage() && !window.PMKPages) initBuilderPage();

        if (registerWithPMK()) return;
        window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });

        let tries = 0;
        const timer = setInterval(() => {
            tries += 1;
            if (registerWithPMK() || tries >= 120) {
                clearInterval(timer);
                if (!registered) {
                    config = { ...DEFAULT_CONFIG };
                    injectPersonalListButtons();
                    injectKohaNativeListButton();
                    injectKohaBasketButton();
                    injectCourseReservesButton();
                    scheduleBundleBibliographyInjection();
                    if (isBuilderPage() && !window.PMKPages) initBuilderPage();
                }
            }
        }, 50);
    }

    window.PMKBibliography = {
        version: VERSION,
        moduleId: MODULE_ID,
        authentication: 'none',
        open: function (options) {
            const params = new URLSearchParams();
            params.set('pmk_page', PAGE_PARAM);
            if (options?.source) params.set('source', options.source);
            if (options?.listId) params.set('list', options.listId);
            if (options?.type) params.set('type', options.type);
            if (options?.template) params.set('template', options.template);
            window.location.href = '/cgi-bin/koha/mainpage.pl?' + params.toString();
        },
        builtins: () => clone(BUILTIN_TEMPLATES),
        getActiveProfile: resolveActiveProfile,
        openBundle: openBundleBibliography,
        collectBasket: collectKohaBasketEntries,
        collectCourseReserves: collectCourseReserveEntries,
        resolveCovers: async biblionumber => {
            const id = clean(biblionumber);
            if (!id) return [];
            const marc = await fetchMarcForBiblio(id);
            const biblio = await enrichNotice(normalizeStoredNotice({ biblionumber: id }));
            return clone(biblio.coverCandidates || []);
        }
    };

    function registerPage() {
        return window.PMKPages?.register({id:PAGE_PARAM,mount:async container=>{
            const existing=document.getElementById(ROOT_ID);
            if(existing)container.appendChild(existing);
            else {const root=document.createElement('div');root.id=ROOT_ID;container.appendChild(root);}
            // Preserve an in-memory publication draft when the manager arrives late or is re-enabled.
            if(builderInitStarted && current.workingTemplate) {await renderBuilder();return;}
            builderInitStarted=false;
            await initBuilderPage(container);
        }});
    }
    if (!registerPage()) document.addEventListener('pmk:pages-ready',registerPage,{once:true});
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }

})(window, document);

;window.PMKNonPlugin.loaded.push("142-bibliography-builder.js");
} catch (error) { window.PMKNonPlugin.errors.push("142-bibliography-builder.js: "+error.message); console.error("[PMK] 142-bibliography-builder.js",error); };
try {
/*
 * 143 — Gestion des retards TP4 — v0.2.1 (pilote préplugin)
 * Ajouter ce fichier COMPLET à IntranetUserJS, sans balises <script>.
 * Page : /cgi-bin/koha/mainpage.pl?pmk_page=overdue-management
 * Source de classement : rapport privé 5261 V0.3 sans seuil de montant.
 * Aucun stockage externe. Aucun envoi de mail/SMS. Écrans natifs pour les prêts et statuts.
 * Les écritures réutilisent le formulaire Koha et son jeton CSRF frais.
 * Configuration facultative, avant le script :
 * window.PMK143_CONFIG = { reportId: 5261, defaultBranch: 'BAR' };
 */
(function (window, document) {
  'use strict';
  if (window.PMK143) return;
  const VERSION = '0.2.1';
  const CONFIG = Object.assign({ reportId: 5261, defaultBranch: '', pageSize: 500, maxPages: 200, timeoutMs: 45000 }, window.PMK143_CONFIG || {});
  const PAGE = 'overdue-management';
  let REPORT_PATH = '/cgi-bin/koha/reports/guided_reports.pl';
  let MEMBER_PATH = '/cgi-bin/koha/members/moremember.pl';
  let DELETE_PATH = '/cgi-bin/koha/circ/del_message.pl';
  let MESSAGE_PATH = '/cgi-bin/koha/circ/add_message.pl';
  const url = new URL(window.location.href);
  const STAGES = [
    ['all', 'Tous'], ['call', 'À appeler'], ['search', 'Recherche documents'],
    ['letter', 'Lettre à préparer'], ['signature', 'À signer'], ['sent', 'Lettre envoyée'], ['finance', 'Finances / clôture'], ['cleanup', 'À nettoyer'], ['dnr', 'DNR'], ['control', 'À contrôler']
  ];
  let QUICK = ['Appelé pour TP4', 'Lettre TP4 à la signature', 'Lettre TP4 envoyée', 'Transmis au service finances', 'Documents recherchés pour TP4', 'Adhérent contacté pour TP4'];
  const state = { rows: [], selected: null, dossier: null, loans: [], stage: 'all', query: '', branch: CONFIG.defaultBranch,
    sort: 'overdue', loading: false, busy: false, draft: null, uncertain: null, reportStale: false, request: 0, panelRequest: 0, root: null, cleanup: null, manual: false, itemManual: false, loansLoaded: false, prepared: new Map(), operations: [] };
  let mounting = false;
  const $ = (s) => state.root?.querySelector(s);
  const all = (s, node) => Array.from((node || state.root).querySelectorAll(s));
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const normalize = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const number = v => { const n = Number(String(v == null ? '' : v).replace(/[\s\u00a0]/g, '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
  const money = v => new Intl.NumberFormat(CONFIG.locale||'fr-FR', { style: 'currency', currency: CONFIG.currency||'EUR' }).format(number(v));
  const lines = v => esc(v).replace(/\n/g, '<br>');
  const idOK = v => /^\d+$/.test(String(v));
  function text(node) {
    if (!node) return '';
    const copy = node.cloneNode(true);
    copy.querySelectorAll('script,style,.autolink').forEach(n => n.remove());
    copy.querySelectorAll('br').forEach(n => n.replaceWith('\n'));
    return copy.textContent.trim();
  }
  function safeURL(value, path) {
    const u = new URL(value, window.location.origin);
    if (u.origin !== window.location.origin || (path && u.pathname !== path)) throw new Error('Adresse Koha inattendue.');
    return u;
  }
  function reportURL(branch, page) {
    const u = new URL(REPORT_PATH, window.location.origin);
    u.searchParams.set('id', String(CONFIG.reportId));
    u.searchParams.set('op', 'run');
    if (branch != null) {
      u.searchParams.set('param_name', CONFIG.branchParameter||'Site adhérent|branches:all');
      u.searchParams.set('sql_params', branch);
      u.searchParams.set('limit', String(CONFIG.pageSize));
      u.searchParams.set('page', String(page || 1));
    }
    return u;
  }
  function memberURL(id) {
    if (!idOK(id)) throw new Error('Numéro lecteur invalide.');
    return new URL(MEMBER_PATH + '?borrowernumber=' + id, window.location.origin);
  }
  async function request(target, options) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), CONFIG.timeoutMs);
    try {
      const r = await (window.PMKPagesSettings?((url,options)=>window.PMKPagesSettings.request(PAGE,url,options)):window.fetch)(safeURL(target).href, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, options || {}, { signal: controller.signal }));
      safeURL(r.url || target);
      if (!r.ok) throw new Error('Koha a répondu HTTP ' + r.status + '.');
      return await r.text();
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('Koha ne répond pas dans le délai prévu.');
      throw e;
    } finally { clearTimeout(timer); }
  }
  function parseHTML(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    if (doc.querySelector('#loginform, form input[name="password"], input[name="koha_login_context"]')) {
      throw new Error('Session Koha expirée. Reconnecte-toi à Koha puis actualise cette page.');
    }
    return doc;
  }
  function stageOf(value) {
    const v = normalize(value);
    if(Array.isArray(CONFIG.stageRules)){for(const rule of CONFIG.stageRules){try{if(new RegExp(rule.pattern,rule.flags??'i').test(value))return rule.stage;}catch(_){}}return 'control';}
    if (/^DNR/.test(value)) return 'dnr';
    if (/^6\s*[—-]/.test(v)) return 'finance';
    if (/^7\s*[—-]/.test(v)) return 'cleanup';
    if (/^5\s*[—-]/.test(v)) return 'sent';
    if (/^4\s*[—-]/.test(v)) return 'signature';
    if (/^3\s*[—-]/.test(v)) return 'letter';
    if (/^2\s*[—-]/.test(v)) return 'search';
    if (/^1b?\s*[—-]/.test(v)) return 'call';
    return 'control';
  }
  function columnName(name){for(const [key,value]of Object.entries(CONFIG.columnMap||{}))if(normalize(key)===normalize(name))return value;return name;}
  function patternMatches(pattern,value){try{return new RegExp(pattern,'i').test(normalize(value));}catch(_){return false;}}
  function readReport(doc) {
    const table = doc.querySelector(CONFIG.reportTableSelector||'#report_results') || Array.from(doc.querySelectorAll('table')).find(t => /Retard max/.test(t.textContent));
    if (!table) {
      const alert = doc.querySelector('.alert-danger, .error');
      throw new Error(alert ? text(alert).slice(0,500) : 'Résultats du rapport '+CONFIG.reportId+' introuvables. Vérifiez ses paramètres et la permission d’exécuter des rapports.');
    }
    const header = table.tHead ? table.tHead.rows[0] : table.rows[0];
    if (!header) throw new Error('Le rapport ne contient pas de colonnes.');
    const names = Array.from(header.cells).map(c => normalize(c.textContent));
    for (const required of ['nom', 'prenom', 'retard max', 'etape', 'action maintenant', 'anciennete', 'categorie', 'suivi procedure']) {
      if(!names.includes(normalize(columnName(required))))throw new Error('Rapport '+CONFIG.reportId+' : colonne « '+columnName(required)+' » absente. Vérifiez le rapport et la correspondance des colonnes.');
    }
    const idx = name => names.indexOf(normalize(columnName(name)));
    return Array.from(table.querySelectorAll('tbody tr')).filter(r => r.querySelector('td')).map(tr => {
      const cell = name => tr.cells[idx(name)];
      const get = name => text(cell(name));
      let id = get('borrowernumber');
      const plain = cell('borrowernumber') && cell('borrowernumber').querySelector('.data-plain');
      if (plain) id = text(plain);
      if (!idOK(id)) {
        const a = tr.querySelector('a[href*="borrowernumber="]');
        if (a) id = safeURL(a.getAttribute('href')).searchParams.get('borrowernumber');
      }
      if (!idOK(id)) throw new Error('Une ligne du rapport ne permet pas d’identifier le lecteur.');
      const historicalCell = cell('Workflow historique');
      const historical = historicalCell ? Array.from(historicalCell.querySelectorAll('a[href]')).map(a => {
        try { const u = safeURL(a.getAttribute('href'), REPORT_PATH); return { label: text(a), href: u.href }; } catch (_) { return null; }
      }).filter(Boolean) : [];
      return { id: String(id), card: get('Carte lecteur'), surname: get('Nom'), firstname: get('Prénom'), branch: get('Site lecteur'),
        phone: get('Téléphone'), email: get('Mail'), due: get('Plus ancien retour prévu'), overdue: number(get('Retard max')),
        count: number(get('Docs >= 35 j')), active: number(get('Prêts actifs')), value: get('Valeur docs >= 35 j'),
        step: get('Étape'), stage: stageOf(get('Étape')), action: get('Action maintenant'), age: get('Ancienneté'),
        checks: get('Contrôles'), historyText: get('Workflow historique'), historical,
        called: get('Appelé TP4'), signature: get('À la signature'), sent: get('Lettre envoyée'),
        last: get('Dernière action TP4'), suspension: get('Suspension'), notes: get('Notes circulation'), messages: get('Messages TP4'), category: get('Catégorie'), procedure: get('Suivi procédure') };
    });
  }
  function pagination(doc) {
    const pages = all('.pages a[href], #pagination_top a[href], #pagination_bottom a[href]', doc).map(a => {
      try { const u = safeURL(a.getAttribute('href'), REPORT_PATH); return u.searchParams.get('id') === String(CONFIG.reportId) ? number(u.searchParams.get('page')) : 0; }
      catch (_) { return 0; }
    });
    return Array.from(new Set(pages.filter(n => Number.isInteger(n) && n > 0)));
  }
  async function loadRows(branch, seq) {
    const queue = [1], seen = new Set(), rows = new Map();
    while (queue.length) {
      if (seq !== state.request) return null;
      const page = queue.shift();
      if (seen.has(page)) continue;
      if (seen.size >= CONFIG.maxPages || page > CONFIG.maxPages) throw new Error('Trop de pages : sélectionne un site pour charger un tableau complet.');
      seen.add(page);
      status('Chargement des dossiers… page ' + page, 'info');
      const doc = parseHTML(await request(reportURL(branch, page)));
      if (seq !== state.request) return null;
      readReport(doc).forEach(row => rows.set(row.id, row));
      pagination(doc).forEach(n => { if (!seen.has(n) && !queue.includes(n)) queue.push(n); });
    }
    return Array.from(rows.values());
  }
  function formValue(form, name) {
    const field = form.querySelector('[name="' + name + '"]');
    return field ? field.value : '';
  }
  function nativeForms(doc, id) {
    const forms = Array.from(doc.querySelectorAll('form')).filter(f => {
      try { return safeURL(f.getAttribute('action') || MEMBER_PATH).pathname === MESSAGE_PATH; } catch (_) { return false; }
    });
    const add = forms.find(f => formValue(f, 'op') === 'cud-add_message' && formValue(f, 'borrowernumber') === String(id));
    const allowedAdd = !!doc.querySelector(CONFIG.messageAddAllowedSelector||'#toolbar_addnewmessageLabel');
    const edits = forms.filter(f => formValue(f, 'op') === 'cud-edit_message');
    const lis = Array.from(doc.querySelectorAll(CONFIG.messageContainerSelector||'#messages > ul > li'));
    const messages = edits.map((form, index) => {
      const mid = formValue(form, 'message_id');
      const container = form.closest('[id^="edit_message_form_"]');
      const li = lis.find(n => all(CONFIG.editMessageLinkSelector||'.edit_message', n).some(a => [a.getAttribute('href'), a.getAttribute('data-bs-target'), a.getAttribute('data-target')].includes('#edit_message_form_' + mid))) || lis[index];
      const canEdit = !!(container && all(CONFIG.editMessageLinkSelector||'.edit_message', doc).some(a => [a.getAttribute('href'), a.getAttribute('data-bs-target'), a.getAttribute('data-target')].includes('#' + container.id)));
      const label = li && li.querySelector(':scope > span');
      let meta = '';
      if (label) { const copy = label.cloneNode(true); copy.querySelectorAll('em').forEach(n => n.remove()); meta = text(copy); }
      const deletion = li && all('form', li).find(f => { try { return safeURL(f.getAttribute('action')).pathname === DELETE_PATH && formValue(f, 'message_id') === mid && !!f.querySelector('.delete_message'); } catch (_) { return false; } });
      return { deleteForm: deletion || null, id: mid, value: formValue(form, 'borrower_message'), type: formValue(form, 'message_type'), form, canEdit, meta };
    });
    const raw = text(doc.querySelector('#messages'));
    return { add: allowedAdd ? add : null, messages, raw, inventoryComplete: lis.length === messages.length };
  }
  async function getDossier(id) {
    const doc = parseHTML(await request(memberURL(id)));
    const identity = doc.querySelector(CONFIG.memberIdentitySelector||'#borrowernumber, input[name="borrowernumber"]');
    // moremember n’a pas toujours un champ #borrowernumber ; ses formulaires en portent un.
    if (!identity || identity.value !== String(id)) throw new Error('Fiche lecteur inaccessible ou identité différente.');
    const dossier = nativeForms(doc, id);
    const edit = doc.querySelector('#editpatron[href]');
    const attributes=doc.querySelector(CONFIG.extendedAttributesSelector||'#patron-extended-attributes');
    dossier.attributes=text(attributes);
    const groups=attributes?all('[id^="aai_"]',attributes).filter(g=>patternMatches(CONFIG.attributeGroupPattern,text(g.querySelector('h4,legend'))+' '+text(g))):[];
    const fields=attributes?all('li',attributes).filter(n=>patternMatches(CONFIG.attributeFieldPattern,text(n))):[];
    dossier.dnrAttributes=groups.length?groups.map(text).join('\n'):fields.length?fields.map(text).join('\n'):patternMatches(CONFIG.attributeGroupPattern,dossier.attributes)?dossier.attributes:'';
    dossier.editHref = edit ? safeURL(edit.getAttribute('href'), '/cgi-bin/koha/members/memberentry.pl').href : null;
    return dossier;
  }
  async function getLoans(id) {
    const u = new URL('/cgi-bin/koha/svc/checkouts', window.location.origin);
    u.searchParams.set('borrowernumber', id); u.searchParams.set('iDisplayLength', '-1');
    const body = await request(u);
    let data;
    try { data = JSON.parse(body); } catch (_) { throw new Error('Prêts indisponibles : réponse Koha non JSON ou permission insuffisante.'); }
    if (!Array.isArray(data.aaData)) throw new Error('Format des prêts Koha non reconnu.');
    return data.aaData;
  }
  function status(message, type) {
    if (!state.root) return;
    const n = $('#tp4-status'); n.textContent = message; n.className = 'tp4-status ' + (type || 'info');
    n.setAttribute('role', type === 'error' ? 'alert' : 'status');
  }
  function locked() { return state.loading || state.busy || !!state.draft || !!state.uncertain || !!state.cleanup || state.manual || state.itemManual; }
  function syncLocks() {
    all('[data-navigation]').forEach(n => { n.disabled = locked(); });
    all('[data-quick]').forEach(n => { n.disabled = state.busy || !!state.uncertain || !!state.draft || !state.dossier || !state.dossier.add || !!state.cleanup || state.manual || state.itemManual; });
    all('[data-edit]').forEach(n => { n.disabled = state.busy || !!state.uncertain || !!state.draft || !!state.cleanup || state.manual || state.itemManual; });
    all('[data-item-status]').forEach(n=>{n.disabled=state.busy||!!state.draft||!!state.uncertain||!!state.cleanup||state.itemManual;});
    const nativeClose=$('#tp4-native-close');if(nativeClose)nativeClose.disabled=state.itemManual;
    all('[data-workflow]').forEach(n => { n.disabled = locked() || !state.dossier || !state.loansLoaded; });
    const clean = $('#tp4-clean-confirm'); if (clean) clean.disabled = state.busy || !!state.uncertain;
    all('[data-clean-select]').forEach(n => { const m=state.dossier && state.dossier.messages.find(x => x.id === n.dataset.cleanSelect); n.disabled = state.busy || !!state.uncertain || !m || !m.deleteForm || protectedMessage(m); });
    const done = $('#tp4-clean-done'); if(done) done.disabled = state.busy || !!state.uncertain;
    const close = $('#tp4-clean-cancel'); if(close) close.disabled = state.busy || !!state.uncertain;
    const verify = $('#tp4-verify'); if (verify) verify.hidden = !state.uncertain;
    if (verify) verify.disabled = state.busy;
    const save = $('#tp4-save'); if (save) save.disabled = state.busy || !!state.uncertain || !$('#tp4-confirm-preview')?.checked;
    const cancel = $('#tp4-cancel'); if (cancel) cancel.disabled = state.busy || !!state.uncertain;
  }
  function visibleRows() {
    const q = normalize(state.query);
    return state.rows.filter(r => (state.stage === 'all' || r.stage === state.stage) && (!q || normalize([r.surname, r.firstname, r.card, r.phone, r.email].join(' ')).includes(q)))
      .sort((a, b) => state.sort === 'name' ? (a.surname + ' ' + a.firstname).localeCompare(b.surname + ' ' + b.firstname, 'fr') : state.sort === 'value' ? number(b.value) - number(a.value) : b.overdue - a.overdue);
  }
  function renderList() {
    $('#tp4-stages').innerHTML = STAGES.filter(([key])=>key==='all'||state.stage===key||state.rows.some(r=>r.stage===key)).map(([key, label]) => '<button type="button" data-stage="' + key + '" aria-pressed="' + (state.stage === key) + '" class="tp4-stage ' + key + '">' + esc(CONFIG.stageLabels?.[key]||label) + ' <strong>' + state.rows.filter(r => key === 'all' || r.stage === key).length + '</strong></button>').join('');
    const rows = visibleRows();
    $('#tp4-count').textContent = rows.length + ' dossier(s) affiché(s) sur ' + state.rows.length;
    const exceptions=state.rows.filter(r=>r.stage==='control'||r.checks).length;
    const recovery=(state.uncertain?1:0)+(state.cleanup?.selected?.filter(id=>!state.cleanup.done.includes(id)).length||0);
    const summary=$('#tp4-summary');if(summary)summary.innerHTML='<span><strong>'+state.rows.length+'</strong>dossiers lus</span><span><strong>'+exceptions+'</strong>exceptions à contrôler</span><span><strong>'+recovery+'</strong>action(s) à reprendre</span><span><strong>'+state.operations.length+'</strong>action(s) vérifiée(s) dans cette session</span>';
    $('#tp4-list').innerHTML = rows.map(r => '<button type="button" data-reader="' + r.id + '" data-navigation class="tp4-reader ' + r.stage + (state.selected === r.id ? ' selected' : '') + '" aria-pressed="' + (state.selected === r.id) + '"><span class="tp4-row-head"><strong>' + esc(r.surname + ' ' + r.firstname) + '</strong><span>' + r.overdue + ' j ' + (r.overdue >= 280 ? '🚨' : r.overdue >= 183 ? '⚠' : '') + '</span></span><span>' + esc(r.card) + ' · ' + esc(r.branch) + (r.count>0||number(r.value)>0 ? ' · '+money(r.value) : '') + '</span><span class="tp4-badge ' + r.stage + '">' + esc(r.action || r.step) + '</span>' + (r.checks ? '<small class="tp4-warning">⚠ Contrôle à consulter</small>' : '') + '</button>').join('') || '<p class="tp4-empty">Aucun dossier pour ce filtre.</p>';
    syncLocks();
  }
  function loansHTML() {
    const overdue=state.loans.filter(l=>l.date_due_overdue).sort((a,b)=>String(a.date_due).localeCompare(String(b.date_due)));
    if(!overdue.length)return '<p class="tp4-muted">Aucun prêt en retard'+(state.loans.length?' · '+state.loans.length+' prêt(s) actif(s)':'')+'.</p>';
    const date=v=>{const m=String(v||'').match(/^(\d{4})-(\d{2})-(\d{2})/);return m?m[3]+'/'+m[2]+'/'+m[1]:String(v||'');};
    return '<p class="tp4-muted">'+overdue.length+' en retard · '+state.loans.length+' prêt(s) actif(s)</p><div class="tp4-scroll"><table><thead><tr><th>Document</th><th>Retour prévu</th><th>Sites</th><th>Remplacement</th></tr></thead><tbody>'+overdue.map(l=>{
      const link=idOK(l.biblionumber)?'/cgi-bin/koha/catalogue/detail.pl?biblionumber='+l.biblionumber:null;
      const title=esc(String(l.title||'').replace(/[\u0088\u0089]/g,''));
      return '<tr><td>'+(link?'<a target="_blank" rel="noopener" href="'+esc(link)+'">'+title+'</a>':title)+'<small class="tp4-loan-meta">'+esc(l.barcode)+' · '+esc(l.itemcallnumber)+'</small><small>'+itemLink(l).replace('Statut de l’exemplaire ↗','Exemplaire ↗')+'</small></td><td>'+esc(date(l.date_due))+'</td><td><small>Prêt : '+esc(l.branchname||l.branchcode)+'</small><small>Propriétaire : '+esc(l.homebranch||'à vérifier')+'</small></td><td>'+(l.price===''||l.price==null?'—':money(l.price))+'</td></tr>';
    }).join('')+'</tbody></table></div>';
  }

  function messagesHTML() {
    if (!state.dossier) return '<p>Chargement des messages Koha…</p>';
    if (!state.dossier.messages.length) return state.dossier.raw ? '<p class="tp4-pre">' + lines(state.dossier.raw) + '</p>' : '<p>Aucun message dans la fiche Koha.</p>';
    return state.dossier.messages.map(m => '<article class="tp4-message"><div class="tp4-row-head"><small>' + esc(m.meta || (m.type === 'L' ? 'Note interne' : 'Message OPAC')) + '</small>' + (m.canEdit ? '<button type="button" data-edit="' + esc(m.id) + '">Modifier</button>' : '<small>Lecture seule</small>') + '</div><p class="tp4-pre">' + lines(m.value) + '</p></article>').join('');
  }
  function contextHint(r) {
    if (r.stage === 'cleanup') return 'Vérifier l’ancien dossier avant de supprimer ses messages.';
    if (r.stage === 'finance') return 'Transmission tracée : vérifier les documents et terminer la clôture.';
    if (r.stage === 'dnr') return 'Suivre les informations DNR enregistrées sur la carte.';
    if (r.stage === 'signature') return 'Faire signer la lettre, puis tracer son envoi.';
    if (r.stage === 'letter') return 'Préparer la lettre et la transmettre pour signature.';
    if (r.stage === 'call') return 'Rechercher les documents dans les deux sites, puis tracer l’appel.';
    return r.procedure || r.action || 'Vérifier les messages et les prêts du dossier.';
  }
  function suggestedIds() { return state.dossier ? state.dossier.messages.filter(m => m.deleteForm && suggestedMessage(m)).map(m => m.id) : []; }
  function actionButton(action, primary) {
    return '<button type="button" ' + (action.quick != null ? 'data-quick="' + action.quick : 'data-workflow="' + action.workflow) + '"' + (primary ? ' class="tp4-primary"' : '') + '>' + esc(action.label) + '</button>';
  }
  function workflowHTML() {
    const r = state.rows.find(x => x.id === state.selected);
    if (!r) return '';
    const suggestions=suggestedIds(), hasMessages=!!(state.dossier && state.dossier.messages.some(m=>m.deleteForm && !protectedMessage(m)));
    const overdue=state.loans.filter(l=>l.date_due_overdue).length;
    const quick=QUICK.map((label,i)=>({quick:String(i),label}));
    const operations=[{workflow:'card',label:'Imprimer les retards'}, {workflow:'notices',label:'Notifications envoyées'}, {workflow:'dnr',label:r.category === (CONFIG.dnrCategory||'DNR') ? CONFIG.dnrEditLabel||'Modifier le dossier DNR' : CONFIG.dnrPrepareLabel||'Préparer un dossier DNR'}, {workflow:'returns',label:'Retours des documents'}, {workflow:'edit',label:'Catégorie, notes et restrictions'}, {workflow:'cleanup',label:'Choisir les messages à supprimer' + (suggestions.length ? ' ('+suggestions.length+')' : '')}];
    const canEdit=!state.dossier || !!state.dossier.editHref;
    const available=operations.filter(a=>(a.workflow!=='dnr'||CONFIG.dnrEnabled!==false) && (a.workflow!=='returns'||!state.loansLoaded||overdue>0) && (a.workflow!=='cleanup'||hasMessages) && (!['edit','dnr'].includes(a.workflow)||canEdit));
    const op=k=>available.find(a=>a.workflow===k);
    let main=[];
    if (r.stage==='call') main=[quick[4],quick[0]];
    else if (r.stage==='search') main=[quick[4],quick[5]];
    else if (r.stage==='letter') main=[op('card'),quick[1]];
    else if (r.stage==='signature') main=[quick[2],op('card')];
    else if (r.stage==='sent') main=[/atteint|pour transmission/.test(normalize(r.procedure+' '+r.action)) ? quick[3] : quick[5]];
    else if (r.stage==='dnr') main=[op('dnr'),op('returns')];
    else if (r.stage==='finance') main=[op('returns'),suggestions.length ? op('cleanup') : op('edit')];
    else if (r.stage==='cleanup') main=[suggestions.length ? op('cleanup') : op('edit')];
    if(Object.prototype.hasOwnProperty.call(CONFIG.stageQuickMessages||{},r.stage))main=[...main.filter(a=>a?.workflow),...CONFIG.stageQuickMessages[r.stage].map(index=>quick[index])];
    main=main.filter(Boolean);
    const key=a=>a.quick!=null?'q'+a.quick:'w'+a.workflow;
    const used=new Set(main.map(key));
    const otherQuick=quick.filter(a=>!used.has(key(a)));
    const otherOperations=available.filter(a=>!used.has(key(a)));
    return '<p class="tp4-next">'+esc(contextHint(r))+'</p><div class="tp4-actions">'+main.map((a,i)=>actionButton(a,i===0)).join('')+actionButton({quick:'free',label:'Ajouter une note'},false)+'</div>'+
      '<details class="tp4-more" id="tp4-more-actions"><summary>Autres actions</summary><div class="tp4-actions">'+otherQuick.map(a=>actionButton(a,false)).join('')+'</div><div class="tp4-actions">'+otherOperations.map(a=>actionButton(a,false)).join('')+'</div></details>'+
      '<details class="tp4-guide"><summary>Consignes de traitement</summary><p>'+esc(r.procedure || '')+'</p>' + (CONFIG.workflowGuide||[]).map(value=>'<p>'+esc(value)+'</p>').join('') + '</details>';
  }
  function panelAttributesHTML(r) {
    if(CONFIG.dnrEnabled===false)return '';
    const content=state.dossier && state.dossier.dnrAttributes;
    return '<section class="tp4-section" id="tp4-dnr-section"'+(r.category!==(CONFIG.dnrCategory||'DNR')&&!content?' hidden':'')+'><h3>'+esc(CONFIG.dnrLabel||'Dossier DNR')+'</h3><p id="tp4-attributes" class="tp4-pre">'+lines(content || (r.category===(CONFIG.dnrCategory||'DNR') ? 'Consulter les champs DNR dans la carte Koha.' : ''))+'</p></section>';
  }
  function renderPanel() {
    const r = state.rows.find(x => x.id === state.selected);
    if (!r) { $('#tp4-panel').innerHTML = '<div class="tp4-empty">Sélectionne un lecteur pour consulter son dossier.</div>'; return; }
    const phone=r.phone.replace(/[^+\d]/g,''), mail=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r.email)?r.email:'';
    const overdue=state.loans.filter(l=>l.date_due_overdue).length;
    const metrics=[];
    if (r.overdue>0) metrics.push('<strong>'+r.overdue+' j</strong> de retard max.');
    if (state.loansLoaded && overdue) metrics.push('<strong>'+overdue+'</strong> prêt(s) en retard');
    if (r.count>0) metrics.push('<strong>'+r.count+'</strong> à ≥ 35 j · '+money(r.value));
    const notes=r.notes||r.suspension;
    const history=r.historical.length||r.historyText.trim();
    $('#tp4-panel').innerHTML='<header class="tp4-panel-head"><div><h2>'+esc(r.surname+' '+r.firstname)+'</h2><p>'+esc(r.card)+' · '+esc(r.branch)+'</p></div><a target="_blank" rel="noopener" href="'+esc(memberURL(r.id).href)+'">Fiche Koha ↗</a></header>'+
      '<div class="tp4-contact">'+(phone?'<a href="tel:'+esc(phone)+'">☎ '+esc(r.phone)+'</a>':'')+(mail?'<a href="mailto:'+esc(mail)+'">✉ '+esc(mail)+'</a>':'')+'</div>'+
      '<p class="tp4-badge '+r.stage+'">'+esc(r.step)+'</p>'+(metrics.length?'<p class="tp4-metrics">'+metrics.join(' <span>·</span> ')+'</p>':'')+
      (r.age?'<p class="tp4-warning">'+esc(r.age)+'</p>':'')+
      (r.checks?'<details class="tp4-checks"><summary>Points à vérifier</summary><p>'+lines(r.checks)+'</p></details>':'')+
      '<section class="tp4-section tp4-treatment"><h3>Traitement</h3><div id="tp4-workflow">'+workflowHTML()+'</div><p id="tp4-permission"></p><div id="tp4-composer"></div><div id="tp4-operation"></div></section>'+
      '<section class="tp4-section"><h3>Documents en retard</h3><div id="tp4-loans">'+(state.loansLoaded?loansHTML():'Chargement des prêts…')+'</div><div id="tp4-item-operation"></div></section>'+panelAttributesHTML(r)+
      '<section class="tp4-section"'+(state.dossier&&!state.dossier.messages.length&&!state.dossier.raw?' hidden':'')+'><h3>Messages Koha</h3><div id="tp4-messages">'+messagesHTML()+'</div></section>'+
      (notes?'<details class="tp4-supplement"><summary>Notes de circulation et restriction</summary><p class="tp4-pre">'+lines(r.notes||'')+'</p>'+(r.suspension?'<p>'+lines(r.suspension)+'</p>':'')+'</details>':'')+
      (history?'<details class="tp4-supplement"><summary>Rapports historiques</summary>'+r.historical.map(h=>'<a class="tp4-history" target="_blank" rel="noopener" href="'+esc(h.href)+'">'+esc(h.label)+'</a>').join('')+(!r.historical.length?'<p>'+lines(r.historyText)+'</p>':'')+'</details>':'');
    if(state.dossier&&!state.dossier.add)$('#tp4-permission').textContent='Ajout de note non proposé par Koha avec tes droits.';
    syncLocks();
  }
  async function select(id) {
    if(locked())return;
    state.selected=id;state.dossier=null;state.loans=[];state.loansLoaded=false;
    const seq=++state.panelRequest;
    renderList();renderPanel();
    const results=await Promise.allSettled([getDossier(id),getLoans(id)]);
    if(seq!==state.panelRequest||id!==state.selected)return;
    if(results[0].status==='fulfilled')state.dossier=results[0].value;
    if(results[1].status==='fulfilled'){state.loans=results[1].value;state.loansLoaded=true;}
    renderPanel();
    if(results[0].status==='rejected'){
      $('#tp4-messages').textContent=results[0].reason.message;
      $('#tp4-permission').textContent='Actions désactivées : fiche Koha non chargée.';
      status(results[0].reason.message,'error');
    }
    if(results[1].status==='rejected')$('#tp4-loans').textContent=results[1].reason.message;
    syncLocks();
  }

  async function refresh() {
    if (state.busy || state.draft || state.uncertain || state.cleanup || state.manual || state.itemManual) return;
    state.loading = true; state.reportStale = true; syncLocks();
    const seq = ++state.request, selected = state.selected;
    try {
      const rows = await loadRows(state.branch, seq);
      if (!rows || seq !== state.request) return;
      state.rows = rows; state.reportStale = false;
      window.PMKPagesSettings?.recordAnalysis(PAGE,{outcome:'success',count:rows.length,source:'Rapport SQL Koha '+CONFIG.reportId});
      $('#tp4-updated').textContent = 'Actualisé à ' + new Date().toLocaleTimeString('fr-FR');
      status(rows.length + ' dossier(s) chargé(s). Classement fourni par le rapport ' + CONFIG.reportId + '.', 'success');
      state.selected = rows.some(r => r.id === selected) ? selected : null;
    } catch (e) { state.rows = []; state.selected = null; status(e.message, 'error'); }
    finally {
      if (seq === state.request) {
        state.loading = false; state.dossier = null; ++state.panelRequest;
        renderList(); renderPanel();
        if (state.selected) await select(state.selected);
      }
    }
  }
  function focusItemFrame(frame,item) {
    try {
      const doc=frame.contentDocument;
      if(!doc || doc.querySelector('#loginform,input[name="password"]'))return;
      safeURL(doc.location.href,'/cgi-bin/koha/catalogue/moredetail.pl');
      const forms=all('form',doc).filter(f=>{
        try {return safeURL(new URL(f.getAttribute('action'),doc.location.href),'/cgi-bin/koha/catalogue/updateitem.pl') && String(f.method).toLowerCase()==='post' && formValue(f,'itemnumber')===String(item.itemnumber) && formValue(f,'biblionumber')===String(item.biblionumber) && ['cud-set_lost','cud-set_damaged','cud-set_withdrawn'].includes(formValue(f,'op')) && !!formValue(f,'csrf_token');}
        catch(_){return false;}
      });
      if(!forms.length)return; // Garder l'écran natif, notamment en lecture seule ou en cas d'alerte.
      const box=doc.createElement('main');box.id='pmk143-item-focus';
      all('.alert,.error,.dialog',doc).forEach(n=>{if(!n.closest('form'))box.appendChild(n.cloneNode(true));});
      const labels={'cud-set_lost':'Perdu','cud-set_damaged':'Endommagé','cud-set_withdrawn':'Retiré'};
      forms.forEach(f=>{
        const section=doc.createElement('section'),title=doc.createElement('h3');
        title.textContent=labels[formValue(f,'op')];section.append(title,f);box.appendChild(section);
      });
      doc.body.replaceChildren(box);
      const style=doc.createElement('style');style.textContent='body{background:white!important;padding:0!important;margin:0!important}#pmk143-item-focus{max-width:100%;padding:14px;font:14px system-ui;color:#23352a}#pmk143-item-focus section{margin:0 0 18px}#pmk143-item-focus h3{font-size:15px;margin:0 0 8px}#pmk143-item-focus select{max-width:100%;min-width:180px;margin-right:8px}#pmk143-item-focus input[type=submit]{margin:5px 0}';doc.head.appendChild(style);
      frame.style.height=Math.min(620,Math.max(300,doc.body.scrollHeight+20))+'px';
    }catch(_){ /* Le lien natif reste utilisable si le thème ou l'encapsulation diffère. */ }
  }
  function openItemStatus(id) {
    if(state.busy||state.draft||state.uncertain||state.cleanup||state.itemManual||!state.loansLoaded)return;
    const item=state.loans.concat(state.prepared.get(state.selected)||[]).find(l=>String(l.itemnumber)===String(id));
    if(!item||!idOK(item.itemnumber)||!idOK(item.biblionumber)){status('Exemplaire non identifié dans ce dossier.','error');return;}
    const target=new URL('/cgi-bin/koha/catalogue/moredetail.pl',window.location.origin);
    target.searchParams.set('itemnumber',item.itemnumber);target.searchParams.set('biblionumber',item.biblionumber);target.hash='item'+item.itemnumber;
    state.itemManual=true;
    $('#tp4-item-operation').innerHTML='<div class="tp4-editor"><h4>Statuts de l’exemplaire</h4><p>'+esc(String(item.title||'').replace(/[\u0088\u0089]/g,''))+' · <strong>'+esc(item.barcode)+'</strong></p><p class="tp4-muted">Choisir le statut et enregistrer chaque changement dans Koha.</p><iframe id="tp4-item-native" class="tp4-native" title="Modifier les statuts de l’exemplaire"></iframe><div class="tp4-actions"><button type="button" id="tp4-item-close">Terminé</button><a target="_blank" rel="noopener" href="'+esc(target.href)+'">Fiche exemplaire ↗</a></div></div>';
    const frame=$('#tp4-item-native');frame.addEventListener('load',()=>focusItemFrame(frame,item));frame.src=target.href;
    $('#tp4-item-operation').scrollIntoView({block:'nearest'});syncLocks();
  }
  async function closeItemStatus() {
    state.itemManual=false;$('#tp4-item-operation').innerHTML='';syncLocks();
    if(!state.manual)await refresh();
    else status('Écran des statuts fermé. Terminer l’autre opération Koha pour actualiser le dossier.','info');
  }

  function nativeTarget(kind) {
    if (kind === 'edit' || kind === 'dnr') {
      if (!state.dossier.editHref) throw new Error('Koha ne propose pas la modification de cette carte avec tes droits.');
      return state.dossier.editHref;
    }
    if (kind === 'notices') return '/cgi-bin/koha/members/notices.pl?borrowernumber=' + state.selected;
    if (kind === 'returns') return '/cgi-bin/koha/circ/returns.pl';
    return memberURL(state.selected).href;
  }
  function snapshotDNR() {
    if (!state.loansLoaded) throw new Error('Attendre le chargement complet des prêts.');
    if (!state.prepared.has(state.selected)) state.prepared.set(state.selected, state.loans.filter(l => l.date_due_overdue).map(l => Object.assign({}, l)));
    return state.prepared.get(state.selected);
  }
  function preparedHTML() {
    const docs = snapshotDNR();
    if (!docs.length) return '<p>Aucun prêt en retard à préparer. Les informations du dossier existant se trouvent dans les attributs Koha enregistrés ; ne pas remplacer son montant par zéro.</p><p>Pour sortir du DNR : effacer dernier contact, année, documents dus et montant, puis choisir Adulte / Jeune. Conserver la note interne datée si nécessaire.</p>';
    const total = docs.reduce((v,l) => v + number(l.price), 0);
    return '<h4>Informations à enregistrer dans les champs DNR</h4><p>Choisir les documents du litige. Le montant proposé est à vérifier : les prix absents ne sont pas estimés. Utiliser « Ajouter » dans Koha pour un champ « Document dû » par document. Ces propositions restent disponibles dans cette session après les retours.</p>' +
      '<p>Année de DNR : ' + new Date().getFullYear() + ' · Montant proposé pour tous les documents ci-dessous : ' + money(total) + (docs.some(l => !l.price) ? ' · Prix absent ou nul à vérifier.' : '') + '</p>' +
      docs.map((l,i) => '<article class="tp4-message"><p>' + esc(documentText(l)) + '</p><div class="tp4-actions"><button type="button" data-copy-doc="' + i + '">Copier pour « Document dû »</button>' + itemLink(l) + '</div></article>').join('') +
      '<p>'+esc(CONFIG.dnrEntryGuide||'')+'</p>' +
      '<p>'+esc(CONFIG.dnrExitGuide||'')+'</p>';
  }
  function documentText(l) { return [l.title, 'Code-barres : ' + (l.barcode || 'non renseigné'), 'Cote : ' + (l.itemcallnumber || ''), 'Site propriétaire : ' + (l.homebranch || 'à vérifier'), 'Site de prêt : ' + (l.branchname || l.branchcode || ''), 'Retour prévu : ' + (l.date_due || ''), 'Remplacement : ' + (l.price === '' || l.price == null ? 'non renseigné' : money(l.price))].join(' | '); }
  function itemLink(l) {
    return idOK(l.itemnumber) && idOK(l.biblionumber) ? '<button type="button" data-item-status="'+esc(l.itemnumber)+'">Modifier les statuts</button>' : '<span>Ouvrir l’exemplaire depuis la fiche bibliographique.</span>';
  }
  async function copyPrepared(index) {
    const docs = state.prepared.get(state.selected) || [];
    if (!docs[index]) return;
    try { await navigator.clipboard.writeText(documentText(docs[index])); status('Informations du document copiées : les coller dans « Document dû » de Koha.', 'success'); }
    catch (_) { status('Copie indisponible : sélectionner le texte du document ci-dessus puis Ctrl+C.', 'info'); }
  }
  function workflowAction(kind) {
    if(kind==='dnr' && CONFIG.dnrEnabled===false)return;
    if (locked() || !state.dossier || !state.loansLoaded) return;
    if (kind === 'cleanup') { openCleanup(); return; }
    try {
      const target = safeURL(nativeTarget(kind));
      // Conserver les identifiants des exemplaires avant les retours, même sans prêt ensuite.
      if (kind === 'dnr' || kind === 'returns') snapshotDNR();
      state.manual = true;
      const docs = state.prepared.get(state.selected) || state.loans.filter(l => l.date_due_overdue);
      $('#tp4-operation').innerHTML = '<div class="tp4-editor"><h4>Écran Koha</h4>' +
        (kind === 'dnr' ? preparedHTML() : kind === 'returns' ? '<p>'+esc(CONFIG.returnGuide||'')+'</p>' + docs.map(l => '<p>' + esc(l.title) + ' · <strong>' + esc(l.barcode) + '</strong> · ' + itemLink(l) + '</p>').join('') : kind === 'card' ? '<p>'+esc(CONFIG.cardGuide||'')+'</p>' : '') +
        '<p><a href="' + esc(target.href) + '" target="_blank" rel="noopener">Ouvrir cet écran Koha dans un onglet ↗</a></p><iframe class="tp4-native" id="tp4-native" title="Opération dans Koha" src="' + esc(target.href) + '"></iframe><p>Enregistrer ou annuler les modifications dans Koha avant de revenir au tableau.</p><button type="button" id="tp4-native-close">Terminé — actualiser le dossier</button></div>';
      syncLocks();
    } catch (e) { state.manual = false; status(e.message, 'error'); syncLocks(); }
  }
  async function closeNative() { state.manual = false; $('#tp4-operation').innerHTML = ''; syncLocks(); await refresh(); }
  function protectedMessage(m) { return /ne pas supprimer|ne pas effacer|conserver ce message/.test(normalize(m.value)); }
  function suggestedMessage(m) { return m.type === 'L' && !protectedMessage(m) && (/\btp4\b/.test(normalize(m.value)) || /^transmis au service finances\b/.test(normalize(m.value))); }
  function openCleanup() {
    state.cleanup = { patron: state.selected, originals: state.dossier.messages.map(m => ({ id:m.id, value:m.value, type:m.type })), done:[], selected:state.dossier.messages.filter(m => m.deleteForm && suggestedMessage(m)).map(m => m.id) };
    renderCleanup();
  }
  function cleanRow(m,c) {
    return '<label class="tp4-clean-row"><input type="checkbox" data-clean-select="'+esc(m.id)+'" '+(c.selected.includes(m.id)?'checked ':'')+(!m.deleteForm||protectedMessage(m)?'disabled ':'')+'><span><small>'+esc(m.meta|| (m.type==='L'?'Note interne':'Message OPAC'))+'</small><span class="tp4-pre">'+esc(m.value)+'</span>'+(!m.deleteForm?'<small>Suppression non proposée par Koha.</small>':protectedMessage(m)?'<small>À conserver.</small>':'')+'</span></label>';
  }
  function updateCleanCount() {
    if(!state.cleanup)return;
    const count=state.cleanup.selected.filter(id=>!state.cleanup.done.includes(id)&&state.dossier.messages.some(m=>m.id===id)).length;
    const n=$('#tp4-clean-count');if(n)n.textContent=count+' message(s) sélectionné(s)';
    const button=$('#tp4-clean-confirm');if(button)button.textContent='Supprimer '+count+' message(s)';
  }
  function renderCleanup(message) {
    const c=state.cleanup;if(!c)return;
    const related=state.dossier.messages.filter(m=>/\btp4\b|^transmis au service finances\b/.test(normalize(m.value)));
    const other=state.dossier.messages.filter(m=>!related.includes(m));
    $('#tp4-operation').innerHTML='<div class="tp4-editor"><h4>Messages à supprimer</h4><p>Seuls les messages cochés seront supprimés. Vérifier leur date : ils peuvent appartenir à un ancien litige.</p>'+
      (message?'<p role="status">'+esc(message)+'</p>':'')+
      related.map(m=>cleanRow(m,c)).join('')+
      (other.length?'<details class="tp4-more"><summary>Autres messages de la carte ('+other.length+')</summary>'+other.map(m=>cleanRow(m,c)).join('')+'</details>':'')+
      '<p><strong id="tp4-clean-count"></strong></p><p><label><input type="checkbox" id="tp4-clean-done"> J’ai vérifié la clôture et les messages sélectionnés.</label></p>'+
      '<details class="tp4-guide"><summary>Quoi vérifier avant de supprimer ?</summary><p>Documents concernés traités, statuts corrects, catégorie et champs DNR / notes / restriction contrôlés, logistique informée si nécessaire.</p><p>Les notes internes TP4 et la transmission aux finances sont proposées. Les autres notes et les messages OPAC restent décochés. Les messages demandant à être conservés sont protégés.</p><p>Cette action ne retire ni prêts ni restrictions, et ne modifie ni catégorie ni attribut DNR.</p></details>'+
      '<div class="tp4-actions"><button type="button" id="tp4-clean-confirm">Supprimer les messages sélectionnés</button><button type="button" id="tp4-clean-cancel">Fermer / actualiser</button></div></div>';
    all('[data-clean-select]').forEach(n=>n.addEventListener('change',()=>{c.selected=all('[data-clean-select]:checked').map(x=>x.dataset.cleanSelect);updateCleanCount();}));
    updateCleanCount();syncLocks();
  }

  function prepareDelete(dossier, original, patron) {
    if (!dossier.inventoryComplete) throw new Error('Liste native des messages incomplète. Utiliser la fiche Koha pour le nettoyage.');
    const m = dossier.messages.find(x => x.id === original.id);
    if (!m || !m.deleteForm) throw new Error('Message absent ou suppression non autorisée par Koha : ' + original.id + '.');
    if (protectedMessage(m)) throw new Error('Ce message doit être conservé.');
    if (m.value !== original.value || m.type !== original.type) throw new Error('Un message a changé dans Koha. Fermer puis rouvrir le nettoyage pour vérifier la nouvelle version.');
    const f=m.deleteForm, p=encodeForm(f);
    safeURL(f.getAttribute('action'), DELETE_PATH);
    if (String(f.method).toLowerCase() !== 'post' || p.get('op') !== 'cud-delete' || p.get('borrowernumber') !== patron || p.get('message_id') !== m.id || !p.get('csrf_token')) throw new Error('Formulaire de suppression Koha incomplet ou inattendu. Aucune suppression effectuée pour ce message.');
    return p;
  }
  async function cleanMessages() {
    if (!state.cleanup || state.busy || state.uncertain) return;
    const c=state.cleanup;
    if (!$('#tp4-clean-done').checked) { status('Confirmer le contrôle de clôture avant de nettoyer les messages.', 'info'); return; }
    const ids=c.selected.filter(id => !c.done.includes(id));
    if (!ids.length) { status('Cocher au moins un message supprimable.', 'info'); return; }
    state.busy=true; syncLocks();
    try {
      // Contrôler toute la sélection avant la première suppression, puis relire pour chaque message.
      const preflight=await getDossier(c.patron);
      for (const id of ids) prepareDelete(preflight,c.originals.find(m=>m.id===id),c.patron);
      for (const id of ids) {
        const before=await getDossier(c.patron), original=c.originals.find(m=>m.id===id);
        const payload=prepareDelete(before,original,c.patron);
        state.uncertain={kind:'delete',patron:c.patron,id};
        status('Suppression du message ' + (c.done.length+1) + '…', 'info');
        let postError;
        try { await request(DELETE_PATH,{method:'POST',body:payload}); } catch(e) {postError=e;}
        const after=await getDossier(c.patron);
        if (!writeVerified(after,state.uncertain)) throw new Error(postError ? postError.message : 'Suppression non confirmée dans Koha.');
        c.done.push(id); state.uncertain=null; state.dossier=after;
      }
      state.busy=false; $('#tp4-messages').innerHTML=messagesHTML();
      state.operations.push({at:new Date().toISOString(),patron:c.patron,kind:'message-cleanup',count:c.done.length,verified:true});
      renderCleanup(c.done.length + ' message(s) supprimé(s) et vérifié(s). Fermer pour actualiser le tableau.');
      status('Nettoyage vérifié dans Koha. Les autres messages ont été conservés.', 'success');
    } catch(e) {
      state.busy=false;
      status((c.done.length ? c.done.length+' suppression(s) déjà vérifiée(s). ' : '') + e.message + (state.uncertain ? ' Utiliser « Vérifier l’enregistrement » : aucune suppression supplémentaire avant confirmation.' : ''),'error');
      syncLocks();
    }
  }
  async function closeCleanup() { if(state.busy || state.uncertain)return; state.cleanup=null; $('#tp4-operation').innerHTML=''; syncLocks(); await refresh(); }

  function startDraft(kind) {
    if (state.busy || state.uncertain || state.draft || state.cleanup || state.manual || state.itemManual || !state.dossier) return;
    if (kind === 'free' || /^\d$/.test(kind)) {
      if (!state.dossier.add) return;
      const prefix = kind === 'free' ? '' : QUICK[Number(kind)];
      const day = new Date().toLocaleDateString('fr-FR');
      const agentNode = document.querySelector('.loggedinusername');
      const agent = agentNode ? String(agentNode.dataset.loggedinusername || agentNode.textContent).trim() : '';
      state.draft = { patron: state.selected, id: null, original: '', value: prefix ? prefix + ' - ' + day + (agent ? ' - ' + agent : '') : '', type: 'L' };
    } else {
      const m = state.dossier.messages.find(x => 'edit:' + x.id === kind);
      if (!m || !m.canEdit) return;
      state.draft = { patron: state.selected, id: m.id, original: m.value, value: m.value, type: m.type };
    }
    const reader=state.rows.find(row=>row.id===state.selected);
    state.draft.recipient={id:state.selected,name:reader?[reader.surname,reader.firstname].filter(Boolean).join(' '):'',card:reader?.card||'',stage:reader?.step||''};
    $('#tp4-composer').innerHTML = '<div class="tp4-editor"><h4>' + (state.draft.id ? 'Modifier le message' : 'Ajouter une note interne') + '</h4><div class="tp4-action-preview"><p><strong>Dossier destinataire :</strong> <span id="tp4-preview-recipient"></span></p><p><strong>Destination :</strong> '+(state.draft.type === 'B' ? 'message visible dans l’OPAC' : 'note interne visible par les agents')+'. Aucun courriel ni SMS n’est envoyé.</p><p><strong>Étape au moment de l’action :</strong> '+esc(state.draft.recipient.stage||'À contrôler')+'</p><p><strong>Contenu exact qui sera enregistré :</strong></p><p id="tp4-preview-content" class="tp4-pre"></p></div><label for="tp4-message-text">Message</label><textarea id="tp4-message-text" rows="5"></textarea><label class="tp4-confirm"><input type="checkbox" id="tp4-confirm-preview"> J’ai vérifié le dossier destinataire et le contenu ci-dessus.</label><div class="tp4-actions"><button type="button" id="tp4-save" class="tp4-primary">Enregistrer dans Koha</button><button type="button" id="tp4-cancel">Annuler</button></div></div>';
    const more=$('#tp4-more-actions'); if(more) more.open=false;
    $('#tp4-composer').scrollIntoView({block:'nearest'});
    $('#tp4-message-text').value = state.draft.value;
    $('#tp4-preview-recipient').textContent=[state.draft.recipient.name,state.draft.recipient.card?'carte '+state.draft.recipient.card:'','n° '+state.draft.recipient.id].filter(Boolean).join(' · ');
    const updatePreview=()=>{$('#tp4-preview-content').textContent=$('#tp4-message-text').value||'Contenu vide';$('#tp4-confirm-preview').checked=false;syncLocks();};
    updatePreview();$('#tp4-message-text').addEventListener('input', e => { state.draft.value = e.target.value;updatePreview(); });
    $('#tp4-confirm-preview').addEventListener('change',syncLocks);
    $('#tp4-message-text').focus(); syncLocks();
  }
  function cancelDraft() { if (state.busy || state.uncertain) return; state.draft = null; $('#tp4-composer').innerHTML = ''; syncLocks(); }
  function encodeForm(form) {
    const payload = new URLSearchParams();
    Array.from(form.elements).forEach(field => {
      if (!field.name || field.disabled || ['button', 'submit', 'reset', 'file'].includes(field.type) || (['radio', 'checkbox'].includes(field.type) && !field.checked)) return;
      if (field.tagName === 'SELECT' && field.multiple) Array.from(field.selectedOptions).forEach(o => payload.append(field.name, o.value));
      else payload.append(field.name, field.value);
    });
    return payload;
  }
  function prepareWrite(dossier, draft) {
    let form;
    if (draft.id) {
      const m = dossier.messages.find(x => x.id === draft.id);
      if (!m || !m.canEdit) throw new Error('Ce message n’est plus modifiable depuis ta fiche Koha.');
      if (m.type !== draft.type) throw new Error('Le type du message a changé dans Koha. Annule puis rouvre-le.');
      if (m.value !== draft.original) throw new Error('Le message a changé dans Koha depuis son ouverture. Annule puis rouvre-le pour reprendre la version actuelle.');
      form = m.form;
    } else { form = dossier.add; }
    if (!form) throw new Error('Formulaire d’ajout Koha indisponible.');
    if (String(form.method).toLowerCase() !== 'post') throw new Error('Méthode du formulaire Koha inattendue.');
    safeURL(form.getAttribute('action'), MESSAGE_PATH);
    const p = encodeForm(form);
    if (!p.get('csrf_token')) throw new Error('Jeton CSRF absent du formulaire Koha. Aucune écriture effectuée.');
    if (p.get('op') !== (draft.id ? 'cud-edit_message' : 'cud-add_message')) throw new Error('Opération Koha non reconnue.');
    if (!draft.id && (p.get('borrowernumber') !== draft.patron || !p.get('branchcode'))) throw new Error('Identité ou site de session absent du formulaire.');
    if (draft.id && p.get('message_id') !== draft.id) throw new Error('Identifiant de message différent.');
    p.set('borrower_message', draft.value);
    // Les ajouts TP4 sont toujours internes. Les éditions conservent le type natif.
    if (!draft.id) p.set('message_type', 'L');
    p.delete('select_patron_notice'); p.delete('borrower_subject');
    return p;
  }
  function writeVerified(dossier, pending) {
    if (pending.kind === 'delete') return dossier.inventoryComplete && !dossier.messages.some(m => m.id === pending.id);
    return dossier.messages.some(m => m.value === pending.value && (pending.id ? m.id === pending.id : !pending.beforeIds.includes(m.id) && m.type === 'L'));
  }
  async function finishWrite(dossier) {
    state.operations.push({at:new Date().toISOString(),patron:state.draft?.patron||state.uncertain?.patron,kind:state.draft?.id?'message-edit':'message-add',verified:true});
    state.uncertain = null; state.busy = false; state.draft = null; state.dossier = dossier;
    $('#tp4-composer').innerHTML = ''; $('#tp4-messages').innerHTML = messagesHTML();
    status('Message enregistré et vérifié dans Koha. Actualisation des étapes…', 'success');
    syncLocks();
    await refresh();
    if (state.reportStale) status('Message enregistré dans Koha ; le tableau n’a pas pu être actualisé. Utilise « Actualiser les dossiers ».', 'error');
    else status('Message enregistré dans Koha ; classement actualisé depuis 5261.', 'success');
  }
  async function saveDraft() {
    if (!state.draft || state.busy || state.uncertain) return;
    if(!$('#tp4-confirm-preview')?.checked){status('Vérifie le dossier destinataire et le contenu avant l’enregistrement.','error');return;}
    const draft = Object.assign({}, state.draft, { value: $('#tp4-message-text').value.trim() });
    if (!draft.value) { status('Saisis un message avant d’enregistrer.', 'error'); return; }
    state.draft.value = draft.value;
    state.busy = true; syncLocks(); status('Vérification du formulaire Koha…', 'info');
    let pending, postError;
    try {
      const fresh = await getDossier(draft.patron);
      const payload = prepareWrite(fresh, draft);
      pending = Object.assign({}, draft, { beforeIds: fresh.messages.map(m => m.id) });
      state.uncertain = pending;
      status('Enregistrement dans Koha…', 'info');
      try { await request(MESSAGE_PATH, { method: 'POST', body: payload }); }
      catch (e) { postError = e; }
      // Une redirection/HTTP 200 n’est pas une preuve d’écriture : relire la fiche.
      const after = await getDossier(draft.patron);
      if (!writeVerified(after, pending)) throw new Error(postError ? postError.message : 'Koha n’affiche pas encore le message enregistré.');
      await finishWrite(after);
    } catch (e) {
      state.busy = false;
      if (!pending) state.uncertain = null;
      status(state.uncertain ? 'Enregistrement non confirmé : ' + e.message + ' Utilise « Vérifier l’enregistrement » avant toute nouvelle écriture.' : e.message, 'error');
      syncLocks();
    }
  }
  async function verifyPending() {
    if (!state.uncertain || state.busy) return;
    state.busy = true; syncLocks();
    try {
      const after = await getDossier(state.uncertain.patron);
      if (writeVerified(after, state.uncertain)) {
        if (state.uncertain.kind === 'delete') { state.cleanup.done.push(state.uncertain.id); state.uncertain = null; state.busy = false; state.dossier = after; $('#tp4-messages').innerHTML=messagesHTML(); renderCleanup('Suppression vérifiée. Relancer uniquement les messages restant dans la liste.'); status('Suppression vérifiée dans Koha. Fermer pour actualiser, ou contrôler les messages restants.', 'success'); }
        else await finishWrite(after);
      }
      else {
        state.busy = false;
        status('Le message n’est pas confirmé dans Koha. Les écritures restent bloquées pour éviter un doublon ; consulte la fiche Koha avant de recharger la page.', 'error');
        syncLocks();
      }
    } catch (e) { state.busy = false; status('Vérification impossible : ' + e.message, 'error'); syncLocks(); }
  }
  async function loadBranches() {
    const doc = parseHTML(await request(reportURL(null)));
    const select = doc.querySelector('select[name="sql_params"]');
    if (!select) throw new Error('Le paramètre « Site adhérent » du rapport est introuvable. Vérifie le SQL V0.3 de 5261.');
    const opts = Array.from(select.options).filter(o => o.value && o.value !== '%');
    $('#tp4-branch').innerHTML = '<option value="%">Tous les sites</option>' + opts.map(o => '<option value="' + esc(o.value) + '">' + esc(o.textContent) + '</option>').join('');
    const pageBranch = url.searchParams.get('tp4_site');
    const sessionBranch = document.querySelector('.logged-in-branch-code, .loggedinbranchcode, #logged-in-branch-code');
    const preferred = pageBranch || state.branch || (sessionBranch && sessionBranch.textContent.trim()) || '';
    state.branch = opts.some(o => o.value === preferred) || preferred === '%' ? preferred : '';
    if (!state.branch) {
      $('#tp4-branch').insertAdjacentHTML('afterbegin', '<option value="" selected>Choisir un site…</option>');
      $('#tp4-branch').value = ''; return false;
    }
    $('#tp4-branch').value = state.branch;
    return true;
  }
  function addStyle() {
    if (document.getElementById('pmk143-style')) return;
    const style = document.createElement('style'); style.id = 'pmk143-style';
    style.textContent = `
      #pmk143{--tp4-green:#287b37;--tp4-border:#cdd8cf;color:#23352a;font-size:14px;max-width:1800px;margin:18px auto;padding:0 14px}
      #pmk143 *{box-sizing:border-box}#pmk143 [hidden]{display:none!important}
      #pmk143 h1{font-size:29px;margin:0 0 6px}#pmk143 h2{font-size:23px;margin:0 0 5px}#pmk143 h3{font-size:18px;margin:0 0 12px}#pmk143 p{margin:6px 0 12px}
      #pmk143 button,#pmk143 select,#pmk143 input{font:inherit;border:1px solid var(--tp4-border);border-radius:7px;background:white;padding:9px 12px;color:#23352a}
      #pmk143 button{cursor:pointer}#pmk143 button:hover{border-color:var(--tp4-green);background:#edf6ef}#pmk143 button:disabled{opacity:.5;cursor:default}
      #pmk143 :focus-visible{outline:3px solid #74a4dd;outline-offset:2px}#pmk143 a{color:#21642d;text-decoration:underline}
      #pmk143 .tp4-primary{background:var(--tp4-green);color:white;border-color:var(--tp4-green)}#pmk143 .tp4-head,#pmk143 .tp4-toolbar,#pmk143 .tp4-actions,#pmk143 .tp4-contact{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
      #pmk143 .tp4-head{justify-content:space-between;margin-bottom:20px}#pmk143 .tp4-toolbar{padding:15px;background:#e8f0e9;border:1px solid var(--tp4-border);border-radius:10px}
      #pmk143 #tp4-search{flex:1;min-width:240px}#pmk143 .tp4-stage{border-radius:20px;white-space:nowrap}#pmk143 .tp4-stage[aria-pressed=true]{box-shadow:0 0 0 2px var(--tp4-green);font-weight:bold}
      #pmk143 #tp4-stages{display:flex;gap:9px;flex-wrap:wrap;margin:17px 0}#pmk143 .tp4-status{padding:12px 14px;margin:12px 0;border-radius:8px;border:1px solid #bdcdbf;background:#f0f5f0;white-space:pre-line}
      #pmk143 .tp4-status.error,#pmk143 .tp4-alert{background:#fff3ed;border-color:#d9a284;color:#7a351a}#pmk143 .tp4-status.success{background:#eef8ef;color:#235b2a}
      #pmk143 .tp4-layout{display:grid;grid-template-columns:minmax(280px,360px) minmax(0,1fr);gap:20px;align-items:start}#pmk143 #tp4-list{max-height:76vh;overflow:auto;padding:3px}
      #pmk143 .tp4-reader{display:flex;flex-direction:column;gap:8px;width:100%;text-align:left;margin:0 0 10px;padding:14px;border-left:5px solid #82988a}#pmk143 .tp4-reader.selected{box-shadow:0 0 0 2px var(--tp4-green)}
      #pmk143 .tp4-row-head,#pmk143 .tp4-panel-head{display:flex;justify-content:space-between;gap:12px;align-items:baseline}#pmk143 .tp4-row-head>span{white-space:nowrap}
      #pmk143 #tp4-panel{min-width:0;background:#fff;border:1px solid var(--tp4-border);border-radius:12px;padding:22px;min-height:300px}#pmk143 .tp4-summary{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}
      #pmk143 .tp4-summary>span{display:flex;flex:1;flex-direction:column;background:#f0f5f0;padding:15px;border-radius:8px;min-width:130px}#pmk143 .tp4-summary strong{font-size:23px;margin-bottom:5px}
      #pmk143 .tp4-action-preview{background:#f2f7f3;border:1px solid #b8cfbf;border-radius:7px;padding:12px;margin:8px 0 14px}#pmk143 .tp4-action-preview p{margin:4px 0 8px}#pmk143 .tp4-confirm{display:block;margin:10px 0 14px;font-weight:600}
      #pmk143 .tp4-section{padding:18px;border:1px solid var(--tp4-border);background:#f8faf8;border-radius:9px;margin:18px 0}#pmk143 .tp4-section.tp4-alert{background:#fff3ed;border-color:#d9a284}#pmk143 .tp4-contact{gap:20px}
      #pmk143 .tp4-badge{display:inline-block;border-radius:6px;padding:5px 8px;font-size:13px}#pmk143 .call{background:#eaf3ff}#pmk143 .search{background:#fff9d9}#pmk143 .letter{background:#fff0df}#pmk143 .signature{background:#f3eaff}#pmk143 .sent{background:#e7f5e9}#pmk143 .control{background:#f0f0f0}
      #pmk143 .tp4-reader.call{border-left-color:#4380b8}#pmk143 .tp4-reader.search{border-left-color:#b49635}#pmk143 .tp4-reader.letter{border-left-color:#c77a28}#pmk143 .tp4-reader.signature{border-left-color:#9364b1}#pmk143 .tp4-reader.sent{border-left-color:#4a925a}
      #pmk143 .tp4-warning{color:#9a421b;font-weight:600}#pmk143 .tp4-empty{padding:35px 15px;text-align:center;color:#617367}#pmk143 .tp4-pre{white-space:pre-wrap;overflow-wrap:anywhere}
      #pmk143 .tp4-message{background:white;border:1px solid #dce3dc;border-radius:7px;padding:12px;margin:10px 0}#pmk143 .tp4-message small{color:#56665b}#pmk143 .tp4-editor{background:white;border:2px solid var(--tp4-green);border-radius:8px;padding:16px;margin-top:15px}
      #pmk143 .tp4-native{width:100%;height:680px;border:1px solid var(--tp4-border);background:white}#pmk143 .tp4-clean-row{display:block;padding:10px;border-bottom:1px solid var(--tp4-border)}#pmk143 .finance,#pmk143 .cleanup{background:#fff0df}#pmk143 .dnr{background:#f3eaff}
      #pmk143 .tp4-section{background:transparent;border:0;border-top:1px solid #e0e7e1;border-radius:0;padding:16px 0;margin:14px 0}
      #pmk143 .tp4-contact{font-size:13px;margin:8px 0 14px}#pmk143 .tp4-metrics,#pmk143 .tp4-muted{font-size:13px;color:#627168}#pmk143 .tp4-metrics span{padding:0 5px}
      #pmk143 .tp4-next{margin-bottom:12px}#pmk143 .tp4-more,#pmk143 .tp4-guide,#pmk143 .tp4-supplement{font-size:13px;margin:12px 0;color:#526459}
      #pmk143 summary{cursor:pointer;padding:5px 0;font-weight:600}#pmk143 details[open]>summary{margin-bottom:8px}#pmk143 .tp4-more .tp4-actions{margin:10px 0}
      #pmk143 .tp4-checks{font-size:13px;color:#925221;margin:8px 0}#pmk143 .tp4-checks p{margin:8px 0}
      #pmk143 .tp4-message{border:0;border-bottom:1px solid #e0e7e1;border-radius:0;padding:10px 0;margin:0}#pmk143 .tp4-message button{padding:4px 8px;font-size:12px}
      #pmk143 .tp4-message p{margin-top:8px}#pmk143 table small{display:block;font-size:12px;line-height:1.5;color:#627168}#pmk143 table [data-item-status]{font-size:12px;padding:4px 7px;margin:3px 0}#pmk143 .tp4-loan-meta{margin:5px 0}#pmk143 th,#pmk143 td{padding:9px 8px}#pmk143 th{background:#f3f6f3;font-size:12px}
      #pmk143 .tp4-clean-row{display:flex;gap:9px;align-items:flex-start;padding:10px 0}#pmk143 .tp4-clean-row input{margin-top:3px;flex:none}#pmk143 .tp4-clean-row>span{min-width:0}#pmk143 .tp4-clean-row small,#pmk143 .tp4-clean-row .tp4-pre{display:block}#pmk143 .tp4-clean-row small{font-size:12px;color:#627168;margin-bottom:5px}
      #pmk143 .tp4-editor{border:1px solid #b8cfbf}#pmk143 .tp4-status.success{border:0;background:transparent;padding:5px 0;font-size:13px}
      #pmk143 textarea{display:block;width:100%;font:inherit;border:1px solid #a8bdaa;border-radius:6px;padding:10px;margin:8px 0 12px}#pmk143 .tp4-scroll{overflow:auto}#pmk143 table{border-collapse:collapse;width:100%;background:white}#pmk143 th,#pmk143 td{padding:10px;border-bottom:1px solid #dce3dc;text-align:left;vertical-align:top}#pmk143 th{background:#eaf0eb}#pmk143 .tp4-history{display:inline-block;margin:3px 12px 6px 0}
      @media(max-width:950px){#pmk143 .tp4-layout{grid-template-columns:minmax(0,1fr)}#pmk143 #tp4-list{max-height:320px}#pmk143 #tp4-panel{padding:14px}}
    `;
    document.head.appendChild(style);
  }
  function bind() {
    state.root.addEventListener('click', e => {
      const button = e.target.closest('button'); if (!button || button.disabled) return;
      if (button.dataset.stage) { state.stage = button.dataset.stage; renderList(); }
      else if (button.dataset.reader) select(button.dataset.reader);
      else if (button.dataset.quick != null) startDraft(button.dataset.quick);
      else if (button.dataset.edit) startDraft('edit:' + button.dataset.edit);
      else if (button.dataset.workflow) workflowAction(button.dataset.workflow);
      else if (button.dataset.itemStatus) openItemStatus(button.dataset.itemStatus);
      else if (button.id === 'tp4-item-close') closeItemStatus();
      else if (button.dataset.copyDoc != null) copyPrepared(Number(button.dataset.copyDoc));
      else if (button.id === 'tp4-clean-confirm') cleanMessages();
      else if (button.id === 'tp4-clean-cancel') closeCleanup();
      else if (button.id === 'tp4-native-close') closeNative();
      else if (button.id === 'tp4-refresh') { if (state.branch) refresh(); else status('Choisis un site.', 'info'); }
      else if (button.id === 'tp4-save') saveDraft();
      else if (button.id === 'tp4-cancel') cancelDraft();
      else if (button.id === 'tp4-verify') verifyPending();
    });
    $('#tp4-search').addEventListener('input', e => { state.query = e.target.value; renderList(); });
    $('#tp4-sort').addEventListener('change', e => { state.sort = e.target.value; renderList(); });
    $('#tp4-branch').addEventListener('change', e => { state.branch = e.target.value; state.selected = null; refresh(); });
    window.addEventListener('beforeunload', e => { if (state.busy || state.uncertain || state.manual || state.itemManual || state.cleanup || (state.draft && state.draft.value)) { e.preventDefault(); e.returnValue = ''; } });
  }
  function pageTarget() {
    // Même surface que le gestionnaire 138, avec les variantes Koha récentes.
    return document.querySelector('#container-main, main#main_intranet-main, main.container-fluid, main[role="main"], main, #main, #content, .main');
  }
  async function mount(managedContainer) {
    if(document.getElementById('pmk143'))return;
    if(mounting||state.busy){if(managedContainer){managedContainer.textContent='L’opération précédente se termine. ';const retry=document.createElement('button');retry.type='button';retry.textContent='Réessayer l’ouverture';retry.onclick=()=>window.PMKPages?.refresh();managedContainer.appendChild(retry);}return;}
    mounting = true;
    Object.assign(CONFIG,window.PMKPagesSettings?.runtime(PAGE,CONFIG)||{});
    REPORT_PATH=CONFIG.reportPath||REPORT_PATH;MEMBER_PATH=CONFIG.memberPath||MEMBER_PATH;DELETE_PATH=CONFIG.deleteMessagePath||DELETE_PATH;MESSAGE_PATH=CONFIG.addMessagePath||MESSAGE_PATH;
    if(Array.isArray(CONFIG.quickMessages))QUICK=CONFIG.quickMessages;
    state.branch=CONFIG.defaultBranch||state.branch;
    const pageContext=managedContainer?.__pmkPageContext;pageContext?.onDispose(()=>{state.request++;state.panelRequest++;});
    document.documentElement.classList.add('pmk138-virtual-route');
    document.body.classList.add('pmk138-virtual-page');
    let main = pageTarget();
    if (!main) {
      // Afficher le pilote même si le thème ne porte aucun sélecteur connu.
      main = document.createElement('div'); main.id = 'pmk143-fallback-host';
      document.body.appendChild(main);
    }
    // Un seul propriétaire de la surface virtuelle : réutiliser le host 138
    // s'il existe déjà, au lieu de créer deux pages qui se masquent mutuellement.
    let host = managedContainer || document.getElementById('pmk138-page-host');
    if (!managedContainer && (!host || !main.contains(host))) {
      host = document.createElement('div'); host.id = 'pmk138-page-host';
      main.appendChild(host);
    }
    if (!managedContainer) Array.from(main.children).forEach(n => {
      if (n === host) return;
      n.hidden = true; n.style.setProperty('display', 'none', 'important');
    });
    host.hidden = false; host.style.setProperty('display', 'block', 'important');
    host.replaceChildren();
    state.root = document.createElement('section'); state.root.id = 'pmk143';
    state.root.innerHTML = '<div class="tp4-head"><div><h1>Gestion des retards TP4</h1><p>Consulter et traiter les dossiers dans Koha.</p></div><div class="tp4-actions"><a href="/cgi-bin/koha/mainpage.pl?pmk_page=hub">← Pages & outils internes</a><a href="/cgi-bin/koha/mainpage.pl">Accueil Koha</a></div></div><div class="tp4-toolbar"><label for="tp4-branch">Site du lecteur</label><select id="tp4-branch" data-navigation><option>Chargement…</option></select><input id="tp4-search" data-navigation type="search" aria-label="Rechercher un lecteur" placeholder="Nom, carte, téléphone, mail…"><label for="tp4-sort">Tri</label><select id="tp4-sort" data-navigation><option value="overdue">Retard décroissant</option><option value="name">Nom</option><option value="value">Valeur décroissante</option></select><button id="tp4-refresh" type="button" data-navigation>Actualiser les dossiers</button></div><div id="tp4-status" class="tp4-status" role="status" aria-live="polite">Chargement…</div><button id="tp4-verify" type="button" hidden>Vérifier l’enregistrement</button><div id="tp4-summary" class="tp4-summary" aria-label="Résumé du traitement"></div><div id="tp4-stages" aria-label="Filtrer par étape"></div><div class="tp4-row-head"><p id="tp4-count"></p><small id="tp4-updated"></small></div><div class="tp4-layout"><aside id="tp4-list" aria-label="Dossiers lecteurs"></aside><div id="tp4-panel"></div></div>';
    if(window.PMKPages && !window.PMKPages.canOpen('hub'))state.root.querySelector('a[href="/cgi-bin/koha/mainpage.pl?pmk_page=hub"]')?.remove();
    if(CONFIG.title)state.root.querySelector('h1').textContent=CONFIG.title;
    host.appendChild(state.root); document.title = (CONFIG.title||'Gestion des retards TP4')+' › Koha'; addStyle(); bind();
    state.loading = true; syncLocks(); renderPanel();
    try {
      const chosen = await loadBranches();if(pageContext?.signal.aborted)return; state.loading = false; syncLocks();
      if (chosen) await refresh(); else { status('Choisis le site de rattachement des lecteurs pour charger les dossiers.', 'info'); renderList(); }
    } catch (e) {if(pageContext?.signal.aborted)return; state.loading = false; status(e.message, 'error'); syncLocks(); }
    finally { mounting = false; }
  }
  window.PMK143 = {
    version: VERSION,
    open: () => { window.location.href = '/cgi-bin/koha/mainpage.pl?pmk_page=' + PAGE; },
    debug: () => ({ version: VERSION, reportId: CONFIG.reportId, branch: state.branch, rows: state.rows.length,
      loading: state.loading, busy: state.busy, reportStale: state.reportStale, writeUnconfirmed: !!state.uncertain,
      pageMounted: !!(state.root && state.root.isConnected), pageHostFound: !!pageTarget(),
      hubVersion: window.PMKPages ? window.PMKPages.version : null,
      hubKnowsRoute: !!(window.PMKPages && window.PMKPages.manifest && window.PMKPages.manifest.some(p => p.id === PAGE)),
      nativeOperation: state.manual, itemEditorOpen: state.itemManual, cleanupOpen: !!state.cleanup, nativeAddForm: !!(state.dossier && state.dossier.add), nativeEditForms: state.dossier ? state.dossier.messages.filter(m => m.canEdit).length : 0 })
  };
  function registerPage() { return window.PMKPages?.register({id:PAGE,mount}); }
  if (!registerPage()) document.addEventListener('pmk:pages-ready',registerPage,{once:true});
  function boot() {
    const launcher=document.getElementById('pmk143-launch'); if(launcher){ const parent=launcher.parentElement;launcher.remove();if(parent&&parent.tagName==='P'&&!parent.textContent.trim()&&!parent.children.length)parent.remove(); }
    if (!window.PMKPages && url.pathname.endsWith('/mainpage.pl') && url.searchParams.get('pmk_page') === PAGE) mount();

  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true }); else boot();
})(window, document);

;window.PMKNonPlugin.loaded.push("143-gestion-retards.js");
} catch (error) { window.PMKNonPlugin.errors.push("143-gestion-retards.js: "+error.message); console.error("[PMK] 143-gestion-retards.js",error); };
try {
/**
 * PimpMyKoha — Module 144
 * Contrôle des doublons adhérents à l'inscription
 *
 * Version : 0.4.0
 *
 * - Interface compacte par défaut.
 * - Recherche des noms/prénoms proches : une modification par champ, accents et séparateurs ignorés.
 * - Comparaison de la date de naissance pour qualifier le risque.
 * - Ouverture des fiches candidates dans un nouvel onglet.
 * - Validation explicite "ce n'est pas un doublon".
 * - Configuration centralisée dans PimpMyKoha (PMKConfig).
 * - Contrôle automatique sur toutes les pages affichant un bloc .patroninfo.
 */

(function () {
    "use strict";

    if (window.PMK144PatronDuplicateCheck && window.PMK144PatronDuplicateCheck.version === "0.4.0") {
        return;
    }

    const MODULE_ID = "144";
    const VERSION = "0.4.0";
    const PAGE_ID = "members.memberentry";
    const PAGE_PATH = "/cgi-bin/koha/members/memberentry.pl";

    const DEFAULTS = {
        enabled: true,
        page: {
            enabled: true,
            path: PAGE_PATH
        },
        existingPatron: {
            enabled: true,
            autoCheck: true,
            showCandidates: true
        },
        comparison: {
            fields: [
                {enabled: true, apiField: "surname", selector: '#surname, #borrower_surname, input[name="surname"], input[name="borrower_surname"]', mode: "fuzzy", role: "candidate", maxDistance: 1},
                {enabled: true, apiField: "firstname", selector: '#firstname, #borrower_firstname, input[name="firstname"], input[name="borrower_firstname"]', mode: "fuzzy", role: "candidate", maxDistance: 1},
                {enabled: true, apiField: "date_of_birth", selector: '#dateofbirth, #borrower_dateofbirth, input[name="dateofbirth"]', mode: "date", role: "qualifier", maxDistance: 0}
            ]
        },
        behavior: {
            requireCheckBeforeSave: true,
            requireBirthDate: true,
            allowContinueOnApiError: true,
            invalidateAfterIdentityChange: true
        },
        display: {
            density: "compact",
            showCardNumber: true,
            showLibrary: true,
            showCategory: false,
            showAddress: false,
            showContact: false
        },
        labels: {
            title: "Vérifier si l’adhérent est déjà inscrit",
            checkButton: "Vérifier",
            noMatch: "Aucun doublon détecté",
            continueButton: "Vérifié : continuer",
            openButton: "Ouvrir",
            useExistingButton: "Utiliser cette fiche"
        },
        advanced: {
            perPage: 100
        }
    };

    const PMK144 = {
        version: VERSION,
        id: "pmk144-patron-duplicate-check",
        config: clone(DEFAULTS),
        pmkRegistered: false,
        subscribed: false,
        initialized: false,
        existingObserver: null,
        existingCache: new Map(),
        state: {
            checked: false,
            checkedSignature: "",
            busy: false,
            lastResults: []
        },
        selectors: {
            surname: [
                "#surname",
                "#borrower_surname",
                'input[name="surname"]',
                'input[name="borrower_surname"]'
            ],
            firstname: [
                "#firstname",
                "#borrower_firstname",
                'input[name="firstname"]',
                'input[name="borrower_firstname"]'
            ],
            dateofbirth: [
                "#dateofbirth",
                "#borrower_dateofbirth",
                'input[name="dateofbirth"]',
                'input[name="borrower_dateofbirth"]'
            ]
        }
    };

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function object(value) {
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    }

    function merge(base, extra) {
        const out = clone(base);
        if (!extra || typeof extra !== "object") return out;

        Object.keys(extra).forEach(function (key) {
            if (Array.isArray(extra[key])) {
                out[key] = clone(extra[key]);
            } else if (
                extra[key] &&
                typeof extra[key] === "object" &&
                !Array.isArray(extra[key]) &&
                out[key] &&
                typeof out[key] === "object" &&
                !Array.isArray(out[key])
            ) {
                out[key] = merge(out[key], extra[key]);
            } else if (extra[key] !== undefined) {
                out[key] = extra[key];
            }
        });

        return out;
    }

    function clamp(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, Math.round(n)));
    }

    function normalizeConfig(config) {
        const cfg = merge(DEFAULTS, object(config));

        cfg.enabled = cfg.enabled !== false;

        cfg.page = merge(DEFAULTS.page, object(cfg.page));
        cfg.page.enabled = cfg.page.enabled !== false;
        cfg.page.path = PAGE_PATH;

        cfg.existingPatron = merge(DEFAULTS.existingPatron, object(cfg.existingPatron));
        cfg.existingPatron.enabled = cfg.existingPatron.enabled !== false;
        cfg.existingPatron.autoCheck = cfg.existingPatron.autoCheck !== false;
        cfg.existingPatron.showCandidates = cfg.existingPatron.showCandidates !== false;

        cfg.behavior = merge(DEFAULTS.behavior, object(cfg.behavior));
        cfg.behavior.requireCheckBeforeSave = cfg.behavior.requireCheckBeforeSave !== false;
        cfg.behavior.requireBirthDate = cfg.behavior.requireBirthDate !== false;
        cfg.behavior.allowContinueOnApiError = cfg.behavior.allowContinueOnApiError !== false;
        cfg.behavior.invalidateAfterIdentityChange = cfg.behavior.invalidateAfterIdentityChange !== false;

        cfg.display = merge(DEFAULTS.display, object(cfg.display));
        cfg.display.density = cfg.display.density === "detailed" ? "detailed" : "compact";
        cfg.display.showCardNumber = cfg.display.showCardNumber !== false;
        cfg.display.showLibrary = cfg.display.showLibrary !== false;
        cfg.display.showCategory = cfg.display.showCategory === true;
        cfg.display.showAddress = cfg.display.showAddress === true;
        cfg.display.showContact = cfg.display.showContact === true;

        cfg.labels = merge(DEFAULTS.labels, object(cfg.labels));
        Object.keys(DEFAULTS.labels).forEach(function (key) {
            cfg.labels[key] = String(cfg.labels[key] || DEFAULTS.labels[key]).trim() || DEFAULTS.labels[key];
        });

        cfg.comparison = merge(DEFAULTS.comparison, object(cfg.comparison));
        cfg.comparison.fields = (Array.isArray(cfg.comparison.fields) ? cfg.comparison.fields : DEFAULTS.comparison.fields).map(field => ({
            enabled: field.enabled !== false,
            apiField: clean(field.apiField), selector: clean(field.selector),
            mode: ["fuzzy", "exact", "date"].includes(field.mode) ? field.mode : "exact",
            role: field.role === "qualifier" ? "qualifier" : "candidate",
            maxDistance: clamp(field.maxDistance, 0, 3, 1)
        }));

        cfg.advanced = merge(DEFAULTS.advanced, object(cfg.advanced));
        cfg.advanced.perPage = clamp(cfg.advanced.perPage, 10, 200, DEFAULTS.advanced.perPage);

        return cfg;
    }

    function comparisonFields(role) {
        return PMK144.config.comparison.fields.filter(field => field.enabled && (!role || field.role === role));
    }
    function pickComparisonField(ctx) {
        return window.PMKConfig.elementPicker.pickForConfig({moduleId: MODULE_ID, targetUrl: PMK144.config.page.path,
            rootObject: ctx.rootObject, fieldPath: ctx.fieldPath, persistAfterPick: false});
    }
    function fieldValue(identity, field) {
        if (identity.values && identity.values[field.apiField] != null) return clean(identity.values[field.apiField]);
        if (field.apiField === "date_of_birth") return identity.dateIso || "";
        return clean(identity[field.apiField]);
    }
    function comparableValue(value, field) {
        return field.mode === "date" ? toIsoDate(value) : normalizeName(value);
    }
    function fieldMatches(value, expected, field) {
        if (!clean(value) || !clean(expected)) return false;
        if (field.mode === "fuzzy") return nameDistance(value, expected) <= field.maxDistance;
        const left = comparableValue(value, field), right = comparableValue(expected, field);
        return Boolean(left && right && left === right);
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: {
                fr: "Contrôle des doublons adhérents",
                en: "Patron duplicate check"
            },
            description: {
                fr: "Contrôle les doublons pendant l’inscription et vérifie automatiquement les fiches déjà existantes sur toutes les pages Koha affichant un encart adhérent.",
                en: "Checks duplicates during registration and automatically verifies existing patron records on every Koha page displaying a patron information block."
            },
            category: {
                fr: "Adhérents",
                en: "Patrons"
            },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULTS),
            normalize: normalizeConfig,
            validate: function (config) {
                const cfg = normalizeConfig(config);
                const active = cfg.comparison.fields.filter(field => field.enabled);
                if (!active.some(field => field.role === "candidate")) return {ok: false, message: 'Activez au moins un champ de recherche.'};
                const seen = new Set();
                for (const field of active) {
                    if (!/^[a-z][a-z0-9_]*$/.test(field.apiField) || seen.has(field.apiField)) return {ok: false, message: 'Chaque propriété API doit être valide et unique.'};
                    seen.add(field.apiField);
                    if (!field.selector) return {ok: false, message: 'Choisissez la cible de chaque champ actif.'};
                    try { document.querySelector(field.selector); } catch (_) { return {ok: false, message: 'Sélecteur CSS invalide.'}; }
                }
                if (!String(cfg.labels.checkButton || "").trim()) {
                    return { ok: false, message: "Le libellé du bouton de contrôle ne peut pas être vide." };
                }
                return { ok: true };
            },
            schema: [
                {type: "section", id: "comparison", label: {fr: "Champs à comparer", en: "Comparison fields"}, fields: [
                    {key: "comparison.fields", type: "repeater", reorder: true, label: {fr: "Champs", en: "Fields"},
                    newItem: () => ({enabled: true, apiField: "", selector: "", mode: "exact", role: "candidate", maxDistance: 1}),
                    itemTitle: item => item.apiField || "Champ Koha", fields: [
                        {key: "enabled", type: "boolean", label: {fr: "Comparer ce champ", en: "Compare this field"}},
                        {key: "apiField", type: "text", label: {fr: "Propriété de l’API adhérents Koha", en: "Koha patrons API property"}, help: {fr: "Exemples : surname, firstname, date_of_birth, email, phone, cardnumber, postal_code.", en: "Examples: surname, firstname, date_of_birth, email, phone, cardnumber, postal_code."}},
                        {key: "selector", type: "elementPicker", allowManual: true, pick: pickComparisonField, label: {fr: "Champ dans le formulaire", en: "Form field"}},
                        {key: "mode", type: "select", label: {fr: "Comparaison", en: "Comparison"}, options: [
                            {value: "fuzzy", label: {fr: "Texte approchant", en: "Similar text"}},
                            {value: "exact", label: {fr: "Texte exact", en: "Exact text"}},
                            {value: "date", label: {fr: "Date", en: "Date"}}]},
                        {key: "maxDistance", type: "number", min: 0, max: 3, label: {fr: "Écarts tolérés — texte approchant", en: "Allowed edits — similar text"}},
                        {key: "role", type: "select", label: {fr: "Utilisation", en: "Use"}, options: [
                            {value: "candidate", label: {fr: "Rechercher des candidats", en: "Find candidates"}},
                            {value: "qualifier", label: {fr: "Qualifier le risque", en: "Qualify risk"}}]}
                    ]}
                ]},
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    description: {
                        fr: "Le module contrôle les doublons à l’inscription et peut aussi vérifier automatiquement les adhérents déjà existants dès qu’un bloc d’information adhérent est affiché.",
                        en: "The module checks duplicates during registration and can also automatically verify existing patrons whenever a patron information block is displayed."
                    },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer le contrôle des doublons", en: "Enable duplicate check" }
                        },
                        {
                            key: "page.enabled",
                            type: "boolean",
                            label: { fr: "Activer sur les pages d’inscription", en: "Enable on patron registration pages" }
                        },
                        {
                            key: "page.path",
                            type: "readonly",
                            advanced: true,
                            label: { fr: "Page Koha", en: "Koha page" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "existingPatron",
                    label: { fr: "Fiches adhérents existantes", en: "Existing patron records" },
                    description: {
                        fr: "Affiche un état très compact directement dans l’encart adhérent et lance automatiquement le contrôle en arrière-plan.",
                        en: "Shows a compact status directly in the patron information block and automatically runs the check in the background."
                    },
                    fields: [
                        {
                            key: "existingPatron.enabled",
                            type: "boolean",
                            label: {
                                fr: "Afficher le contrôle sur les fiches adhérents",
                                en: "Show the check on patron records"
                            }
                        },
                        {
                            key: "existingPatron.autoCheck",
                            type: "boolean",
                            label: {
                                fr: "Lancer automatiquement la vérification",
                                en: "Run the check automatically"
                            }
                        },
                        {
                            key: "existingPatron.showCandidates",
                            type: "boolean",
                            label: {
                                fr: "Afficher les fiches candidates lorsqu’un doublon est possible",
                                en: "Show candidate records when a duplicate is possible"
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "behavior",
                    label: { fr: "Comportement", en: "Behavior" },
                    fields: [
                        {
                            key: "behavior.requireCheckBeforeSave",
                            type: "boolean",
                            label: {
                                fr: "Exiger un contrôle avant l’enregistrement",
                                en: "Require a check before saving"
                            },
                            help: {
                                fr: "Si activé, Koha ne pourra pas enregistrer la nouvelle fiche tant que le contrôle n’aura pas été effectué ou explicitement contourné en cas d’erreur technique.",
                                en: "When enabled, the new patron cannot be saved until the duplicate check has been completed or explicitly bypassed after a technical error."
                            }
                        },
                        {
                            key: "behavior.requireBirthDate",
                            type: "boolean",
                            label: {
                                fr: "Exiger la date de naissance avant la recherche",
                                en: "Require birth date before search"
                            },
                            help: {
                                fr: "Le nom et le prénom peuvent chacun différer d’une lettre (ajout, retrait, remplacement ou inversion). La naissance renforce l’alerte ; chaque fiche doit être vérifiée.",
                                en: "Choose fields and their roles in Comparison fields."
                            }
                        },
                        {
                            key: "behavior.invalidateAfterIdentityChange",
                            type: "boolean",
                            label: {
                                fr: "Annuler la validation si l’identité est modifiée",
                                en: "Invalidate check when identity changes"
                            }
                        },
                        {
                            key: "behavior.allowContinueOnApiError",
                            type: "boolean",
                            label: {
                                fr: "Autoriser la poursuite si l’API Koha échoue",
                                en: "Allow continuing if the Koha API fails"
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "display",
                    label: { fr: "Affichage", en: "Display" },
                    description: {
                        fr: "Le mode compact est recommandé : une ligne de contrôle discrète et une liste dense uniquement lorsqu’une correspondance existe.",
                        en: "Compact mode is recommended: a discreet control row and a dense list only when matches are found."
                    },
                    fields: [
                        {
                            key: "display.density",
                            type: "select",
                            label: { fr: "Densité d’affichage", en: "Display density" },
                            options: [
                                { value: "compact", label: { fr: "Compact", en: "Compact" } },
                                { value: "detailed", label: { fr: "Détaillé", en: "Detailed" } }
                            ]
                        },
                        {
                            key: "display.showCardNumber",
                            type: "boolean",
                            label: { fr: "Afficher le numéro de carte", en: "Show card number" }
                        },
                        {
                            key: "display.showLibrary",
                            type: "boolean",
                            label: { fr: "Afficher la bibliothèque", en: "Show library" }
                        },
                        {
                            key: "display.showCategory",
                            type: "boolean",
                            label: { fr: "Afficher la catégorie", en: "Show category" }
                        },
                        {
                            key: "display.showAddress",
                            type: "boolean",
                            label: { fr: "Afficher l’adresse", en: "Show address" }
                        },
                        {
                            key: "display.showContact",
                            type: "boolean",
                            label: { fr: "Afficher le contact", en: "Show contact" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "labels",
                    label: { fr: "Libellés", en: "Labels" },
                    fields: [
                        {
                            key: "labels.title",
                            type: "text",
                            label: { fr: "Titre court", en: "Short title" }
                        },
                        {
                            key: "labels.checkButton",
                            type: "text",
                            label: { fr: "Bouton de contrôle", en: "Check button" }
                        },
                        {
                            key: "labels.noMatch",
                            type: "text",
                            label: { fr: "Aucun doublon", en: "No duplicate" }
                        },
                        {
                            key: "labels.continueButton",
                            type: "text",
                            label: { fr: "Continuer après vérification", en: "Continue after checking" }
                        },
                        {
                            key: "labels.openButton",
                            type: "text",
                            label: { fr: "Ouvrir dans un nouvel onglet", en: "Open in a new tab" }
                        },
                        {
                            key: "labels.useExistingButton",
                            type: "text",
                            label: { fr: "Utiliser la fiche existante", en: "Use existing patron record" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "advanced",
                    label: { fr: "Avancé", en: "Advanced" },
                    fields: [
                        {
                            key: "advanced.perPage",
                            type: "number",
                            min: 10,
                            max: 200,
                            advanced: true,
                            label: {
                                fr: "Nombre maximal de résultats interrogés",
                                en: "Maximum number of queried results"
                            }
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "activation";
                const section =
                    main.querySelector('[data-pmk-section-id="' + wanted + '"]') ||
                    main.querySelector('[data-pmk-section-id="activation"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    function registerWithPMK() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") {
            return false;
        }

        try {
            window.PMKConfig.registerModule(moduleDefinition());
            PMK144.pmkRegistered = true;

            if (!PMK144.subscribed && typeof window.PMKConfig.subscribe === "function") {
                PMK144.subscribed = true;
                window.PMKConfig.subscribe(MODULE_ID, function (config) {
                    applyConfig(config, { fromSubscription: true });
                });
            }

            return true;
        } catch (error) {
            console.warn("[PMK144] Impossible d’enregistrer le module dans PMKConfig.", error);
            return false;
        }
    }

    async function loadConfig() {
        registerWithPMK();

        if (
            window.PMKConfig &&
            typeof window.PMKConfig.getConfig === "function" &&
            PMK144.pmkRegistered
        ) {
            try {
                return normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID));
            } catch (error) {
                console.warn("[PMK144] Configuration PMK indisponible, valeurs par défaut utilisées.", error);
            }
        }

        return normalizeConfig(DEFAULTS);
    }

    function firstMatch(selectors) {
        for (const selector of selectors) {
            let el;
            try { el = document.querySelector(selector); } catch (_) { continue; }
            if (el) return el;
        }
        return null;
    }

    function clean(value) {
        return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    }

    function normalizeName(value) {
        return clean(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[’']/g, "'")
            .toLocaleUpperCase("fr-FR");
    }

    function toIsoDate(value) {
        const raw = clean(value);
        if (!raw) return "";

        let match = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
        if (match) return validateDateParts(+match[1], +match[2], +match[3]);

        match = raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
        if (match) return validateDateParts(+match[3], +match[2], +match[1]);

        return "";
    }

    function validateDateParts(year, month, day) {
        if (
            !Number.isInteger(year) ||
            !Number.isInteger(month) ||
            !Number.isInteger(day) ||
            year < 1800 ||
            month < 1 ||
            month > 12 ||
            day < 1 ||
            day > 31
        ) return "";

        const d = new Date(Date.UTC(year, month - 1, day));
        if (
            d.getUTCFullYear() !== year ||
            d.getUTCMonth() !== month - 1 ||
            d.getUTCDate() !== day
        ) return "";

        return (
            String(year).padStart(4, "0") + "-" +
            String(month).padStart(2, "0") + "-" +
            String(day).padStart(2, "0")
        );
    }

    function formatDateFr(value) {
        const iso = toIsoDate(value);
        if (!iso) return clean(value) || "—";
        const parts = iso.split("-");
        return parts[2] + "/" + parts[1] + "/" + parts[0];
    }

    function currentIdentity() {
        const fields = comparisonFields();
        const elements = fields.map(field => firstMatch([field.selector]));
        const configured = key => { const index = fields.findIndex(field => field.apiField === key); return index < 0 ? null : elements[index]; };
        const surnameEl = configured("surname") || elements.find(Boolean);
        const firstnameEl = configured("firstname") || elements.find(Boolean);
        const dobEl = configured("date_of_birth");
        const values = {};
        fields.forEach((field, index) => { values[field.apiField] = clean(elements[index] && elements[index].value); });

        return {
            values: values,
            fieldElements: elements,
            surnameEl: surnameEl,
            firstnameEl: firstnameEl,
            dobEl: dobEl,
            surname: clean(surnameEl && surnameEl.value),
            firstname: clean(firstnameEl && firstnameEl.value),
            dateRaw: clean(dobEl && dobEl.value),
            dateIso: toIsoDate(dobEl && dobEl.value)
        };
    }

    function signature(identity) {
        const data = identity || currentIdentity();
        return comparisonFields().map(field => field.apiField + ":" + comparableValue(fieldValue(data, field), field)).join("|");
    }

    function isNewPatronPage() {
        if (location.pathname !== PAGE_PATH) return false;

        const params = new URLSearchParams(location.search);
        const urlBorrower = clean(params.get("borrowernumber"));
        if (urlBorrower && urlBorrower !== "0") return false;

        const hiddenBorrower =
            document.querySelector('input[name="borrowernumber"]') ||
            document.querySelector('input[name="borrower_number"]');

        if (
            hiddenBorrower &&
            clean(hiddenBorrower.value) &&
            clean(hiddenBorrower.value) !== "0"
        ) return false;

        return true;
    }

    function isEnabledHere() {
        return (
            PMK144.config.enabled !== false &&
            PMK144.config.page &&
            PMK144.config.page.enabled !== false &&
            isNewPatronPage()
        );
    }

    function make(tag, options) {
        const children = Array.prototype.slice.call(arguments, 2);
        const el = document.createElement(tag);
        const opts = options || {};

        if (opts.className) el.className = opts.className;
        if (opts.id) el.id = opts.id;
        if (opts.type) el.type = opts.type;
        if (opts.title) el.title = opts.title;
        if (opts.href) el.href = opts.href;
        if (opts.target) el.target = opts.target;
        if (opts.rel) el.rel = opts.rel;

        children.flat().forEach(function (child) {
            if (child === null || child === undefined || child === false) return;
            el.appendChild(
                child instanceof Node ? child : document.createTextNode(String(child))
            );
        });

        return el;
    }

    function injectStyles() {
        if (document.getElementById("pmk144-style")) return;

        const style = document.createElement("style");
        style.id = "pmk144-style";
        style.textContent = `
            #${PMK144.id} {
                --pmk144-border: #d7ddd9;
                --pmk144-text-muted: #69736e;
                margin: .35rem 0 .55rem;
                max-width: 980px;
                font-size: .9rem;
            }

            #${PMK144.id} .pmk144-controlbar {
                display: flex;
                align-items: center;
                gap: .45rem;
                flex-wrap: wrap;
                min-height: 32px;
                padding: .3rem .45rem;
                border: 1px solid var(--pmk144-border);
                border-radius: 4px;
                background: #fafbfa;
            }

            #${PMK144.id}.pmk144-ok .pmk144-controlbar {
                border-color: #a9cdb8;
                background: #f5faf7;
            }

            #${PMK144.id}.pmk144-warning .pmk144-controlbar {
                border-color: #dec98d;
                background: #fffbf1;
            }

            #${PMK144.id}.pmk144-danger .pmk144-controlbar {
                border-color: #d8aaa6;
                background: #fff7f6;
            }

            #${PMK144.id}.pmk144-error .pmk144-controlbar {
                border-color: #ddb59f;
                background: #fff8f4;
            }

            #${PMK144.id} .pmk144-title {
                font-weight: 700;
                white-space: nowrap;
            }

            #${PMK144.id} .pmk144-status {
                min-width: 0;
                color: var(--pmk144-text-muted);
                line-height: 1.25;
            }

            #${PMK144.id}.pmk144-ok .pmk144-status {
                color: #2d6f4e;
                font-weight: 600;
            }

            #${PMK144.id}.pmk144-warning .pmk144-status,
            #${PMK144.id}.pmk144-danger .pmk144-status,
            #${PMK144.id}.pmk144-error .pmk144-status {
                color: #5c5141;
            }

            #${PMK144.id} .pmk144-btn {
                display: inline-flex;
                align-items: center;
                gap: .25rem;
                min-height: 28px;
                padding-top: .2rem;
                padding-bottom: .2rem;
                white-space: nowrap;
            }

            #${PMK144.id} .pmk144-results {
                display: none;
                margin-top: .35rem;
                border: 1px solid var(--pmk144-border);
                border-radius: 4px;
                overflow: hidden;
                background: #fff;
            }

            #${PMK144.id} .pmk144-results.has-results {
                display: block;
            }

            #${PMK144.id} .pmk144-result-row {
                display: flex;
                align-items: center;
                gap: .6rem;
                flex-wrap: wrap;
                padding: .38rem .5rem;
                border-bottom: 1px solid #ecefed;
            }

            #${PMK144.id} .pmk144-result-row:last-child {
                border-bottom: 0;
            }

            #${PMK144.id} .pmk144-result-row.is-exact {
                box-shadow: inset 3px 0 0 #b13b32;
            }

            #${PMK144.id} .pmk144-result-row.is-homonym {
                box-shadow: inset 3px 0 0 #c18a18;
            }

            #${PMK144.id} .pmk144-main {
                min-width: 180px;
                flex: 1 1 220px;
            }

            #${PMK144.id} .pmk144-name {
                font-weight: 700;
            }

            #${PMK144.id} .pmk144-meta {
                display: flex;
                align-items: center;
                gap: .25rem .6rem;
                flex-wrap: wrap;
                flex: 2 1 360px;
                color: #4d5752;
                font-size: .86rem;
            }

            #${PMK144.id} .pmk144-meta-item {
                white-space: nowrap;
            }

            #${PMK144.id} .pmk144-meta-long {
                white-space: normal;
            }
            #${PMK144.id} .pmk144-reasons { margin:.35rem 0 0;padding-left:1.2rem;font-size:.88em;color:#4f5963; }
            #${PMK144.id} .pmk144-reasons li { margin:.12rem 0; }

            #${PMK144.id} .pmk144-row-actions {
                display: flex;
                gap: .3rem;
                margin-left: auto;
                flex: 0 0 auto;
            }

            #${PMK144.id} .pmk144-badge {
                display: inline-block;
                margin-left: .35rem;
                padding: .05rem .35rem;
                border-radius: 999px;
                font-size: .72rem;
                font-weight: 700;
                vertical-align: 1px;
            }

            #${PMK144.id} .pmk144-badge.exact {
                color: #842029;
                background: #f8d7da;
            }

            #${PMK144.id} .pmk144-badge.homonym {
                color: #664d03;
                background: #fff3cd;
            }

            #${PMK144.id} .pmk144-footer {
                display: none;
                justify-content: flex-end;
                gap: .4rem;
                margin-top: .35rem;
            }

            #${PMK144.id} .pmk144-footer.has-actions {
                display: flex;
            }

            #${PMK144.id}.pmk144-density-detailed .pmk144-result-row {
                align-items: flex-start;
                padding-top: .55rem;
                padding-bottom: .55rem;
            }

            #${PMK144.id}.pmk144-density-detailed .pmk144-meta {
                line-height: 1.35;
            }


            .pmk144-existing-check {
                margin: .28rem 0 .42rem;
                border: 1px solid #d7ddd9;
                border-radius: 4px;
                background: #fafbfa;
                font-size: .84rem;
                line-height: 1.25;
                overflow: hidden;
            }

            .pmk144-existing-check .pmk144-existing-status {
                display: flex;
                align-items: center;
                gap: .4rem;
                min-height: 28px;
                padding: .28rem .45rem;
                font-weight: 600;
            }

            .pmk144-existing-check .pmk144-existing-status .pmk144-existing-text {
                min-width: 0;
                flex: 1 1 auto;
            }

            .pmk144-existing-check.is-loading {
                color: #58635e;
                background: #fafbfa;
            }

            .pmk144-existing-check.is-ok {
                color: #286846;
                border-color: #a9cdb8;
                background: #f5faf7;
            }

            .pmk144-existing-check.is-warning {
                color: #6b520d;
                border-color: #dec98d;
                background: #fffbf1;
            }

            .pmk144-existing-check.is-danger {
                color: #842029;
                border-color: #d8aaa6;
                background: #fff7f6;
            }

            .pmk144-existing-check.is-error {
                color: #87421f;
                border-color: #ddb59f;
                background: #fff8f4;
            }

            .pmk144-existing-check .pmk144-existing-action {
                margin-left: auto;
                white-space: nowrap;
            }

            .pmk144-existing-check .pmk144-existing-candidates {
                border-top: 1px solid rgba(0,0,0,.08);
                background: #fff;
            }

            .pmk144-existing-check .pmk144-existing-candidate {
                display: flex;
                align-items: center;
                gap: .45rem;
                padding: .3rem .45rem;
                border-bottom: 1px solid #ecefed;
            }

            .pmk144-existing-check .pmk144-existing-candidate:last-child {
                border-bottom: 0;
            }

            .pmk144-existing-check .pmk144-existing-candidate.is-exact {
                box-shadow: inset 3px 0 0 #b13b32;
            }

            .pmk144-existing-check .pmk144-existing-candidate.is-homonym {
                box-shadow: inset 3px 0 0 #c18a18;
            }

            .pmk144-existing-check .pmk144-existing-candidate-main {
                min-width: 0;
                flex: 1 1 auto;
            }

            .pmk144-existing-check .pmk144-existing-candidate-main strong {
                color: #2c3430;
            }

            .pmk144-existing-check .pmk144-existing-candidate-meta {
                color: #69736e;
                margin-left: .25rem;
            }

            .pmk144-existing-check .pmk144-existing-candidate a {
                flex: 0 0 auto;
                white-space: nowrap;
            }

            #${PMK144.id} .pmk144-spinner {
                display: inline-block;
                width: .85rem;
                height: .85rem;
                border: 2px solid rgba(0,0,0,.14);
                border-top-color: rgba(0,0,0,.55);
                border-radius: 50%;
                animation: pmk144-spin .7s linear infinite;
            }

            @keyframes pmk144-spin {
                to { transform: rotate(360deg); }
            }

            @media (max-width: 850px) {
                #${PMK144.id} .pmk144-result-row {
                    align-items: flex-start;
                }

                #${PMK144.id} .pmk144-row-actions {
                    width: 100%;
                    margin-left: 0;
                }
            }
        `;

        document.head.appendChild(style);
    }

    function buildPanel() {
        const existing = document.getElementById(PMK144.id);
        if (existing) {
            refreshLabelsAndDensity();
            return existing;
        }

        const identity = currentIdentity();
        if (!identity.surnameEl || !identity.firstnameEl) return null;

        const panel = make("div", {
            id: PMK144.id,
            className: "pmk144-density-" + PMK144.config.display.density
        });

        const title = make(
            "span",
            { className: "pmk144-title", id: "pmk144-title" },
            PMK144.config.labels.title
        );

        const checkButton = make(
            "button",
            {
                className: "btn btn-default btn-sm pmk144-btn",
                type: "button",
                id: "pmk144-check"
            },
            "🔎 ",
            PMK144.config.labels.checkButton
        );

        const status = make(
            "span",
            { className: "pmk144-status", id: "pmk144-status" },
            initialStatusText()
        );

        const controlBar = make(
            "div",
            { className: "pmk144-controlbar" },
            title,
            checkButton,
            status
        );

        const results = make(
            "div",
            { className: "pmk144-results", id: "pmk144-results" }
        );

        const footer = make(
            "div",
            { className: "pmk144-footer", id: "pmk144-footer" }
        );

        panel.append(controlBar, results, footer);

        const anchor = identity.dobEl || identity.firstnameEl;
        const row =
            anchor.closest("li") ||
            anchor.closest(".form-group") ||
            anchor.closest(".row") ||
            anchor.parentElement;

        if (row && row.parentNode) {
            if (row.tagName === "LI") {
                const wrapper = make("li", { className: "pmk144-wrapper" }, panel);
                row.insertAdjacentElement("afterend", wrapper);
            } else {
                row.insertAdjacentElement("afterend", panel);
            }
        } else {
            identity.firstnameEl.insertAdjacentElement("afterend", panel);
        }

        checkButton.addEventListener("click", runCheck);
        return panel;
    }

    function refreshLabelsAndDensity() {
        const panel = document.getElementById(PMK144.id);
        if (!panel) return;

        panel.classList.toggle(
            "pmk144-density-detailed",
            PMK144.config.display.density === "detailed"
        );
        panel.classList.toggle(
            "pmk144-density-compact",
            PMK144.config.display.density !== "detailed"
        );

        const title = document.getElementById("pmk144-title");
        if (title) title.textContent = PMK144.config.labels.title;

        const button = document.getElementById("pmk144-check");
        if (button && !PMK144.state.busy) {
            button.replaceChildren(
                document.createTextNode("🔎 " + PMK144.config.labels.checkButton)
            );
        }
    }

    function initialStatusText() {
        return PMK144.config.behavior.requireBirthDate
            ? "Recherche de doublons adhérents : nom, prénom et naissance puis contrôle."
            : "Recherche de doublons adhérents : nom et prénom puis contrôle.";
    }

    function setPanelMode(mode) {
        const panel = document.getElementById(PMK144.id);
        if (!panel) return;

        panel.classList.remove("pmk144-ok", "pmk144-warning", "pmk144-danger", "pmk144-error");
        if (mode) panel.classList.add("pmk144-" + mode);
    }

    function setStatus(value) {
        const status = document.getElementById("pmk144-status");
        if (!status) return;
        status.replaceChildren(
            value instanceof Node ? value : document.createTextNode(String(value))
        );
    }

    function clearResults() {
        const results = document.getElementById("pmk144-results");
        const footer = document.getElementById("pmk144-footer");
        if (results) {
            results.replaceChildren();
            results.classList.remove("has-results");
        }
        if (footer) {
            footer.replaceChildren();
            footer.classList.remove("has-actions");
        }
    }

    function setBusy(busy) {
        PMK144.state.busy = busy;
        const btn = document.getElementById("pmk144-check");
        if (!btn) return;

        btn.disabled = busy;
        btn.replaceChildren();

        if (busy) {
            btn.append(
                make("span", { className: "pmk144-spinner" }),
                document.createTextNode(" Recherche de doublons adhérents…")
            );
        } else {
            btn.textContent = "🔎 " + PMK144.config.labels.checkButton;
        }
    }

    function resetValidation(reason) {
        PMK144.state.checked = false;
        PMK144.state.checkedSignature = "";
        PMK144.state.lastResults = [];

        if (!document.getElementById(PMK144.id)) return;

        setPanelMode("");
        clearResults();
        setStatus(reason || initialStatusText());
    }

    // Une insertion, suppression, substitution ou inversion adjacente par champ.
    function comparableName(value) {
        return normalizeName(value).replace(/[\s'’\-‐‑–]/g, "");
    }

    function nameDistance(left, right) {
        const a = comparableName(left), b = comparableName(right);
        const rows = Array.from({ length: a.length + 1 }, function () {
            return new Array(b.length + 1).fill(0);
        });
        for (let i = 0; i <= a.length; i++) rows[i][0] = i;
        for (let j = 0; j <= b.length; j++) rows[0][j] = j;
        for (let i = 1; i <= a.length; i++) {
            for (let j = 1; j <= b.length; j++) {
                rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1,
                    rows[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
                if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
                    rows[i][j] = Math.min(rows[i][j], rows[i - 2][j - 2] + 1);
                }
            }
        }
        return rows[a.length][b.length];
    }

    function matchesIdentity(patron, identity) {
        const fields = comparisonFields("candidate");
        return fields.length > 0 && fields.every(field => fieldMatches(patron[field.apiField], fieldValue(identity, field), field));
    }

    function identityLabel(patron, identity) {
        return classifyPatron(patron, identity) === "exact" ? "Champs concordants" : "Identité proche · à vérifier";
    }

    // Les jokers élargissent la sélection côté Koha ; la distance filtre ensuite les résultats.
    function nameQuery(field, value, distance) {
        const name = comparableName(value);
        const patterns = new Set();
        function add(chars) { patterns.add("%" + chars.join("%") + "%"); }
        const depth = Math.min(3, Math.max(0, Number(distance) || 0));
        let variants = new Set([name]);
        for (let step = 0; step < depth; step++) {
            const next = new Set(variants);
            for (const text of variants) {
                for (let i = 0; i < text.length; i++) next.add(text.slice(0, i) + text.slice(i + 1));
                for (let i = 0; i < text.length - 1; i++) next.add(text.slice(0, i) + text[i + 1] + text[i] + text.slice(i + 2));
            }
            variants = next;
            if (variants.size > 500) { variants = new Set([""]); break; }
        }
        variants.forEach(text => add(Array.from(text)));
        return { "-or": Array.from(patterns, function (pattern) {
            return { [field]: { "-like": pattern } };
        }) };
    }

    async function fetchPatrons(identity) {
        const fields = comparisonFields("candidate");
        if (!fields.length || fields.some(field => !fieldValue(identity, field))) throw new Error("Champs de comparaison incomplets.");
        let query = { "-and": fields.map(field => {
            const value = fieldValue(identity, field);
            return field.mode === "fuzzy" ? nameQuery(field.apiField, value, field.maxDistance) : {[field.apiField]: field.mode === "date" ? toIsoDate(value) : value};
        }) };
        if (identity.dateIso && comparisonFields().some(field => field.apiField === "date_of_birth")) query = {"-or": [query, {date_of_birth: identity.dateIso}]};
        const perPage = Number(PMK144.config.advanced.perPage);
        const patrons = new Map();
        for (let page = 1; page <= 30; page++) {
            const params = new URLSearchParams({ q: JSON.stringify(query),
                _per_page: String(perPage), _page: String(page), _order_by: "patron_id" });
            const response = await fetch("/api/v1/patrons?" + params.toString(), {
                method: "GET", credentials: "same-origin", headers: { Accept: "application/json" }
            });
            if (!response.ok) throw new Error("Koha a répondu " + response.status + " pendant la recherche des identités proches.");
            const data = await response.json();
            if (!Array.isArray(data)) throw new Error("Réponse Koha inattendue : contrôle non terminé.");
            data.forEach(function (patron) {
                if (matchesIdentity(patron, identity)) patrons.set(patronIdOf(patron), patron);
            });
            const totalHeader = response.headers.get("X-Total-Count");
            const total = totalHeader === null ? NaN : Number(totalHeader);
            if (data.length < perPage || (Number.isFinite(total) && page * perPage >= total)) {
                return Array.from(patrons.values());
            }
        }
        throw new Error("Trop de candidats : contrôle incomplet. Aucun résultat négatif ne peut être confirmé.");
    }


    async function fetchPatronById(patronId) {
        const response = await fetch(
            "/api/v1/patrons/" + encodeURIComponent(patronId),
            {
                method: "GET",
                credentials: "same-origin",
                headers: { Accept: "application/json" }
            }
        );

        if (!response.ok) {
            let detail = "";
            try {
                const payload = await response.json();
                detail = payload && (payload.error || payload.error_code)
                    ? " — " + (payload.error || payload.error_code)
                    : "";
            } catch (_) {
                detail = "";
            }
            throw new Error("Koha a répondu " + response.status + detail);
        }

        return response.json();
    }

    function patronIdOf(patron) {
        return String(
            patron && (
                patron.patron_id ??
                patron.borrowernumber ??
                patron.borrower_number ??
                ""
            )
        );
    }

    function classifyPatron(patron, identity) {
        const fields = comparisonFields("qualifier");
        return fields.every(field => fieldMatches(patron[field.apiField], fieldValue(identity, field), field)) ? "exact" : "homonym";
    }

    function comparisonExplanation(patron, identity) {
        const details = [];
        let exactCandidates = 0;
        let candidateCount = 0;
        let qualifierMatches = 0;
        let qualifierCount = 0;
        comparisonFields().forEach(function (field) {
            const expected = fieldValue(identity, field);
            const actual = clean(patron && patron[field.apiField]);
            const label = field.apiField === "surname" ? "Nom" : field.apiField === "firstname" ? "Prénom" : field.apiField === "date_of_birth" ? "Naissance" : field.apiField;
            if (field.role === "candidate") candidateCount += 1; else qualifierCount += 1;
            if (!actual || !expected) {
                details.push(label + " : donnée absente, non concluante.");
                return;
            }
            if (field.mode === "fuzzy") {
                const distance = nameDistance(actual, expected);
                if (field.role === "candidate" && distance === 0) exactCandidates += 1;
                if (field.role === "qualifier" && distance <= field.maxDistance) qualifierMatches += 1;
                details.push(label + " : " + (distance === 0 ? "identique" : distance + " écart(s) sur " + field.maxDistance + " toléré(s)") + ".");
                return;
            }
            const matches = fieldMatches(actual, expected, field);
            if (field.role === "candidate" && matches) exactCandidates += 1;
            if (field.role === "qualifier" && matches) qualifierMatches += 1;
            details.push(label + " : " + (matches ? "identique" : "différent ou non confirmé") + ".");
        });
        let degree = "Modérée";
        if (candidateCount && exactCandidates === candidateCount && (!qualifierCount || qualifierMatches === qualifierCount)) degree = "Très forte";
        else if (qualifierCount && qualifierMatches === qualifierCount) degree = "Forte";
        return { degree: degree, details: details };
    }

    function patronUrl(patron) {
        const id = patron.patron_id != null ? patron.patron_id : patron.borrowernumber;
        return "/cgi-bin/koha/members/moremember.pl?borrowernumber=" + encodeURIComponent(id);
    }

    function addressText(patron) {
        return [
            patron.street_number,
            patron.street_type,
            patron.address,
            patron.address2,
            patron.postal_code,
            patron.city
        ]
            .filter(Boolean)
            .join(" ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function contactText(patron) {
        return patron.email || patron.phone || patron.mobile || "";
    }

    function metaItem(label, value, longValue) {
        if (!value) return null;
        return make(
            "span",
            { className: "pmk144-meta-item" + (longValue ? " pmk144-meta-long" : "") },
            make("strong", {}, label + " : "),
            value
        );
    }

    function renderPatronRow(patron, identity) {
        const kind = classifyPatron(patron, identity);
        const explanation = comparisonExplanation(patron, identity);
        const row = make("div", {
            className: "pmk144-result-row " + (kind === "exact" ? "is-exact" : "is-homonym")
        });

        const fullName = [patron.firstname, patron.surname]
            .filter(Boolean)
            .join(" ")
            .trim() || "Adhérent";

        const main = make(
            "div",
            { className: "pmk144-main" },
            make("span", { className: "pmk144-name" }, fullName),
            make(
                "span",
                { className: "pmk144-badge " + kind },
                "Suspicion " + explanation.degree.toLowerCase()
            )
        );

        const meta = make("div", { className: "pmk144-meta" });
        const items = [];

        items.push(metaItem("Naissance", formatDateFr(patron.date_of_birth)));

        if (PMK144.config.display.showCardNumber) {
            items.push(metaItem("Carte", patron.cardnumber || "—"));
        }

        if (PMK144.config.display.showLibrary) {
            items.push(metaItem("Site", patron.library_id || "—"));
        }

        if (PMK144.config.display.showCategory) {
            items.push(metaItem("Cat.", patron.category_id || "—"));
        }

        if (PMK144.config.display.showAddress) {
            items.push(metaItem("Adresse", addressText(patron) || "—", true));
        }

        if (PMK144.config.display.showContact) {
            items.push(metaItem("Contact", contactText(patron) || "—", true));
        }

        items.filter(Boolean).forEach(function (item) {
            meta.appendChild(item);
        });
        const reasons = make("ul", { className: "pmk144-reasons", "aria-label": "Raisons de la correspondance" });
        explanation.details.forEach(function (detail) { reasons.appendChild(make("li", {}, detail)); });

        const actions = make("div", { className: "pmk144-row-actions" });

        const openNewTab = make(
            "a",
            {
                className: "btn btn-default btn-xs pmk144-btn",
                href: patronUrl(patron),
                target: "_blank",
                rel: "noopener",
                title: "Ouvrir la fiche dans un nouvel onglet"
            },
            "↗ ",
            PMK144.config.labels.openButton
        );

        const useExisting = make(
            "a",
            {
                className: "btn btn-primary btn-xs pmk144-btn",
                href: patronUrl(patron),
                title: "Abandonner cette nouvelle inscription et utiliser la fiche existante"
            },
            "✓ ",
            PMK144.config.labels.useExistingButton
        );

        actions.append(openNewTab, useExisting);
        row.append(main, meta, reasons, actions);
        return row;
    }

    function markValidated(message) {
        PMK144.state.checked = true;
        PMK144.state.checkedSignature = signature();
        setPanelMode("ok");
        setStatus(message);
    }

    function renderNoMatch() {
        clearResults();
        markValidated("✓ Recherche de doublons adhérents : " + PMK144.config.labels.noMatch);
    }

    function renderMatches(patrons, identity) {
        clearResults();

        const results = document.getElementById("pmk144-results");
        const footer = document.getElementById("pmk144-footer");
        if (!results || !footer) return;

        const exactCount = patrons.filter(function (patron) {
            return classifyPatron(patron, identity) === "exact";
        }).length;

        const count = patrons.length;

        if (exactCount > 0) {
            setPanelMode("danger");
            setStatus(
                "⚠ Recherche de doublons adhérents : " +
                count +
                " correspondance" +
                (count > 1 ? "s" : "") +
                ", dont " +
                exactCount +
                " avec la même date de naissance."
            );
        } else {
            setPanelMode("warning");
            setStatus(
                "⚠ Recherche de doublons adhérents : " +
                count +
                " correspondance possible" +
                (count > 1 ? "s" : "") +
                " à vérifier."
            );
        }

        patrons.forEach(function (patron) {
            results.appendChild(renderPatronRow(patron, identity));
        });
        results.classList.add("has-results");

        const continueBtn = make(
            "button",
            {
                className: "btn btn-success btn-sm pmk144-btn",
                type: "button"
            },
            "✓ ",
            PMK144.config.labels.continueButton
        );

        continueBtn.addEventListener("click", function () {
            markValidated("✓ Recherche de doublons adhérents : vérification effectuée, poursuite de la saisie.");
            results.replaceChildren();
            results.classList.remove("has-results");
            footer.replaceChildren();
            footer.classList.remove("has-actions");
        });

        footer.appendChild(continueBtn);
        footer.classList.add("has-actions");
    }

    function renderError(error) {
        clearResults();
        setPanelMode("error");
        setStatus("Recherche de doublons adhérents : impossible — " + (error && error.message ? error.message : "erreur inconnue."));

        if (!PMK144.config.behavior.allowContinueOnApiError) return;

        const footer = document.getElementById("pmk144-footer");
        if (!footer) return;

        const override = make(
            "button",
            {
                className: "btn btn-warning btn-sm pmk144-btn",
                type: "button"
            },
            "Continuer malgré l’erreur"
        );

        override.addEventListener("click", function () {
            PMK144.state.checked = true;
            PMK144.state.checkedSignature = signature();
            setPanelMode("warning");
            setStatus("Recherche de doublons adhérents : non réalisée techniquement, poursuite validée manuellement.");
            footer.replaceChildren();
            footer.classList.remove("has-actions");
        });

        footer.appendChild(override);
        footer.classList.add("has-actions");
    }

    async function runCheck() {
        if (PMK144.state.busy || !isEnabledHere()) return;

        const identity = currentIdentity();

        const missing = comparisonFields("candidate").find(field => !fieldValue(identity, field) || (field.mode === "date" && !toIsoDate(fieldValue(identity, field))));
        const birthRequired = PMK144.config.behavior.requireBirthDate && comparisonFields().some(field => field.apiField === "date_of_birth");
        if (missing || (birthRequired && !identity.dateIso)) {
            setPanelMode("warning");
            setStatus("Renseignez les champs de comparaison et une date valide si nécessaire.");
            return;
        }

        resetValidation();
        setBusy(true);
        clearResults();
        setStatus("Recherche de doublons adhérents…");

        try {
            let patrons = await fetchPatrons(identity);

            patrons = patrons.filter(function (patron) {
                return (
                    matchesIdentity(patron, identity)
                );
            });

            PMK144.state.lastResults = patrons;

            if (!patrons.length) {
                renderNoMatch();
            } else {
                renderMatches(patrons, identity);
            }
        } catch (error) {
            console.error("[PMK144] Erreur contrôle doublons adhérents", error);
            renderError(error);
        } finally {
            setBusy(false);
        }
    }


    function getPatronIdFromBlock(block) {
        if (!block) return "";

        const hidden =
            block.querySelector("#hiddenborrowernumber") ||
            block.querySelector('input[name="borrowernumber"]') ||
            block.querySelector('input[name="borrower_number"]');

        if (hidden && clean(hidden.value)) {
            return clean(hidden.value);
        }

        const link = block.querySelector('a[href*="/members/moremember.pl?borrowernumber="]');
        if (link) {
            try {
                const url = new URL(link.href, location.origin);
                return clean(url.searchParams.get("borrowernumber"));
            } catch (_) {
                const match = String(link.getAttribute("href") || "").match(/[?&]borrowernumber=(\d+)/);
                if (match) return match[1];
            }
        }

        const globalHidden = document.querySelector("#hiddenborrowernumber");
        return globalHidden ? clean(globalHidden.value) : "";
    }

    function patronIdentityFromRecord(patron) {
        return {
            values: Object.assign({}, patron),
            surname: clean(patron && patron.surname),
            firstname: clean(patron && patron.firstname),
            dateRaw: clean(patron && patron.date_of_birth),
            dateIso: toIsoDate(patron && patron.date_of_birth)
        };
    }

    function existingCheckId(patronId) {
        return "pmk144-existing-" + String(patronId).replace(/[^a-zA-Z0-9_-]/g, "");
    }

    function existingStatusNode(patronId) {
        return document.getElementById(existingCheckId(patronId));
    }

    function buildExistingCheck(block, patronId) {
        let wrapper = existingStatusNode(patronId);
        if (wrapper) return wrapper;

        wrapper = make("div", {
            id: existingCheckId(patronId),
            className: "pmk144-existing-check is-loading"
        });

        const status = make(
            "div",
            { className: "pmk144-existing-status" },
            make("span", { className: "pmk144-existing-icon" }, "⟳"),
            make("span", { className: "pmk144-existing-text" }, "Recherche de doublons adhérents…")
        );

        wrapper.appendChild(status);

        const h5 = block.querySelector("h5");
        const container = block.querySelector(".patroninfo-container");

        if (h5 && h5.parentNode === block) {
            h5.insertAdjacentElement("afterend", wrapper);
        } else if (container && container.parentNode === block) {
            block.insertBefore(wrapper, container);
        } else {
            block.prepend(wrapper);
        }

        return wrapper;
    }

    function setExistingState(wrapper, mode, icon, textValue, action) {
        if (!wrapper) return;

        wrapper.classList.remove(
            "is-loading",
            "is-ok",
            "is-warning",
            "is-danger",
            "is-error"
        );
        wrapper.classList.add("is-" + mode);

        const status = wrapper.querySelector(".pmk144-existing-status");
        if (!status) return;

        status.replaceChildren(
            make("span", { className: "pmk144-existing-icon" }, icon),
            make("span", { className: "pmk144-existing-text" }, textValue)
        );

        if (action) status.appendChild(action);

        const oldCandidates = wrapper.querySelector(".pmk144-existing-candidates");
        if (oldCandidates) oldCandidates.remove();
    }

    function existingCandidateText(patron) {
        const bits = [];

        if (PMK144.config.display.showCardNumber && patron.cardnumber) {
            bits.push("carte " + patron.cardnumber);
        }
        if (patron.date_of_birth) {
            bits.push("né(e) le " + formatDateFr(patron.date_of_birth));
        }
        if (PMK144.config.display.showLibrary && patron.library_id) {
            bits.push(patron.library_id);
        }

        return bits.join(" · ");
    }

    function renderExistingCandidates(wrapper, patrons, identity) {
        if (
            !wrapper ||
            !PMK144.config.existingPatron ||
            PMK144.config.existingPatron.showCandidates === false ||
            !patrons.length
        ) return;

        const container = make("div", { className: "pmk144-existing-candidates" });

        patrons.forEach(function (patron) {
            const kind = classifyPatron(patron, identity);
            const explanation = comparisonExplanation(patron, identity);
            const name = [patron.firstname, patron.surname]
                .filter(Boolean)
                .join(" ")
                .trim() || "Fiche adhérent";

            const main = make(
                "div",
                { className: "pmk144-existing-candidate-main" },
                make("strong", {}, name + " — suspicion " + explanation.degree.toLowerCase())
            );
            const why = make("span", { className: "pmk144-existing-candidate-meta" }, "— " + explanation.details.join(" "));
            main.appendChild(why);

            const metaText = existingCandidateText(patron);
            if (metaText) {
                main.appendChild(
                    make("span", { className: "pmk144-existing-candidate-meta" }, "— " + metaText)
                );
            }

            const link = make(
                "a",
                {
                    className: "btn btn-default btn-xs",
                    href: patronUrl(patron),
                    target: "_blank",
                    rel: "noopener",
                    title: "Ouvrir cette fiche dans un nouvel onglet"
                },
                "Ouvrir ↗"
            );

            const row = make(
                "div",
                {
                    className:
                        "pmk144-existing-candidate " +
                        (kind === "exact" ? "is-exact" : "is-homonym")
                },
                main,
                link
            );

            container.appendChild(row);
        });

        wrapper.appendChild(container);
    }

    async function runExistingPatronCheck(block, force) {
        if (!block) return;

        const patronId = getPatronIdFromBlock(block);
        if (!patronId || patronId === "0") return;

        const wrapper = buildExistingCheck(block, patronId);

        if (!force && PMK144.existingCache.has(patronId)) {
            const cached = PMK144.existingCache.get(patronId);
            renderExistingCheckResult(wrapper, cached);
            return;
        }

        setExistingState(
            wrapper,
            "loading",
            "⟳",
            "Recherche de doublons adhérents…"
        );

        try {
            const currentPatron = await fetchPatronById(patronId);
            const identity = patronIdentityFromRecord(currentPatron);

            if (comparisonFields("candidate").some(field => !fieldValue(identity, field))) {
                const result = {
                    status: "error",
                    message: "Recherche de doublons adhérents : impossible — nom ou prénom non renseigné.",
                    patrons: [],
                    identity: identity
                };
                PMK144.existingCache.set(patronId, result);
                renderExistingCheckResult(wrapper, result);
                return;
            }

            let patrons = await fetchPatrons(identity);

            patrons = patrons.filter(function (patron) {
                return (
                    patronIdOf(patron) !== String(patronId) &&
                    matchesIdentity(patron, identity)
                );
            });

            patrons.sort(function (a, b) {
                const aExact = classifyPatron(a, identity) === "exact" ? 0 : 1;
                const bExact = classifyPatron(b, identity) === "exact" ? 0 : 1;
                return aExact - bExact;
            });

            const exactCount = patrons.filter(function (patron) {
                return classifyPatron(patron, identity) === "exact";
            }).length;

            const result = {
                status: exactCount > 0 ? "danger" : (patrons.length ? "warning" : "ok"),
                patrons: patrons,
                exactCount: exactCount,
                identity: identity
            };

            PMK144.existingCache.set(patronId, result);
            renderExistingCheckResult(wrapper, result);
        } catch (error) {
            console.error("[PMK144] Contrôle automatique fiche adhérent", error);

            const retry = make(
                "button",
                {
                    type: "button",
                    className: "btn btn-default btn-xs pmk144-existing-action"
                },
                "Réessayer"
            );

            retry.addEventListener("click", function () {
                PMK144.existingCache.delete(patronId);
                runExistingPatronCheck(block, true);
            });

            setExistingState(
                wrapper,
                "error",
                "!",
                "Recherche de doublons adhérents : impossible",
                retry
            );
        }
    }

    function renderExistingCheckResult(wrapper, result) {
        if (!wrapper || !result) return;

        if (result.status === "ok") {
            setExistingState(
                wrapper,
                "ok",
                "✓",
                "Recherche de doublons adhérents : aucun doublon détecté"
            );
            return;
        }

        if (result.status === "danger") {
            const total = result.patrons.length;
            const exact = result.exactCount || 0;
            const other = Math.max(0, total - exact);

            let textValue =
                "Recherche de doublons adhérents : " +
                exact +
                " doublon" +
                (exact > 1 ? "s" : "") +
                " probable" +
                (exact > 1 ? "s" : "");

            if (other) {
                textValue +=
                    " + " +
                    other +
                    " correspondance possible" +
                    (other > 1 ? "s" : "");
            }

            textValue += " — vérifier";

            setExistingState(wrapper, "danger", "⚠", textValue);
            renderExistingCandidates(wrapper, result.patrons, result.identity);
            return;
        }

        if (result.status === "warning") {
            const count = result.patrons.length;
            setExistingState(
                wrapper,
                "warning",
                "⚠",
                "Recherche de doublons adhérents : " +
                count +
                    " correspondance possible" +
                    (count > 1 ? "s" : "") +
                    " trouvé" +
                    (count > 1 ? "s" : "") +
                    " — vérifier"
            );
            renderExistingCandidates(wrapper, result.patrons, result.identity);
            return;
        }

        setExistingState(
            wrapper,
            "error",
            "!",
            result.message || "Recherche de doublons adhérents : impossible"
        );
    }

    function teardownExistingChecks() {
        document.querySelectorAll(".pmk144-existing-check").forEach(function (node) {
            node.remove();
        });
        document.querySelectorAll(".patroninfo[data-pmk144-existing-processed]").forEach(function (block) {
            delete block.dataset.pmk144ExistingProcessed;
        });
    }

    function scanExistingPatronBlocks() {
        if (
            PMK144.config.enabled === false ||
            !PMK144.config.existingPatron ||
            PMK144.config.existingPatron.enabled === false
        ) {
            teardownExistingChecks();
            return;
        }

        injectStyles();

        document.querySelectorAll(".patroninfo").forEach(function (block) {
            const patronId = getPatronIdFromBlock(block);
            if (!patronId || patronId === "0") return;

            if (block.dataset.pmk144ExistingProcessed === patronId) return;
            block.dataset.pmk144ExistingProcessed = patronId;

            const wrapper = buildExistingCheck(block, patronId);

            if (PMK144.config.existingPatron.autoCheck !== false) {
                runExistingPatronCheck(block, false);
            } else {
                const button = make(
                    "button",
                    {
                        type: "button",
                        className: "btn btn-default btn-xs pmk144-existing-action"
                    },
                    "Vérifier"
                );

                button.addEventListener("click", function () {
                    runExistingPatronCheck(block, true);
                });

                setExistingState(
                    wrapper,
                    "loading",
                    "🔎",
                    "Doublons non vérifiés",
                    button
                );
            }
        });
    }

    function startExistingObserver() {
        if (PMK144.existingObserver || !document.body) return;

        PMK144.existingObserver = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                return Array.prototype.some.call(mutation.addedNodes || [], function (node) {
                    return (
                        node &&
                        node.nodeType === 1 &&
                        (
                            (node.matches && node.matches(".patroninfo")) ||
                            (node.querySelector && node.querySelector(".patroninfo"))
                        )
                    );
                });
            });

            if (relevant) scanExistingPatronBlocks();
        });

        PMK144.existingObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    function attachIdentityListeners() {
        const identity = currentIdentity();

        (identity.fieldElements || [identity.surnameEl, identity.firstnameEl, identity.dobEl])
            .filter(Boolean)
            .forEach(function (input) {
                if (input.dataset.pmk144IdentityListener === "1") return;
                input.dataset.pmk144IdentityListener = "1";

                const handler = function () {
                    if (!PMK144.config.behavior.invalidateAfterIdentityChange) return;
                    if (!PMK144.state.checked && !PMK144.state.checkedSignature) return;

                    if (signature() !== PMK144.state.checkedSignature) {
                        resetValidation("Recherche de doublons adhérents : identité modifiée, relancez le contrôle.");
                    }
                };

                input.addEventListener("input", handler);
                input.addEventListener("change", handler);
            });
    }

    function findForm() {
        const identity = currentIdentity();
        return (
            (identity.surnameEl && identity.surnameEl.closest("form")) ||
            (identity.firstnameEl && identity.firstnameEl.closest("form")) ||
            document.querySelector("#entryform") ||
            document.querySelector('form[action*="memberentry.pl"]')
        );
    }

    function attachSaveGuard() {
        const form = findForm();
        if (!form || form.dataset.pmk144Guard === "1") return;

        form.dataset.pmk144Guard = "1";

        form.addEventListener(
            "submit",
            function (event) {
                if (!isEnabledHere()) return;
                if (!PMK144.config.behavior.requireCheckBeforeSave) return;

                if (
                    PMK144.config.behavior.invalidateAfterIdentityChange &&
                    PMK144.state.checked &&
                    signature() !== PMK144.state.checkedSignature
                ) {
                    resetValidation("Recherche de doublons adhérents : identité modifiée, relancez le contrôle.");
                }

                if (PMK144.state.checked) return;

                event.preventDefault();
                event.stopImmediatePropagation();

                setPanelMode("warning");
                setStatus("Recherche de doublons adhérents : contrôle requis avant l’enregistrement.");

                const panel = document.getElementById(PMK144.id);
                if (panel) {
                    panel.scrollIntoView({ behavior: "smooth", block: "center" });
                }

                const button = document.getElementById("pmk144-check");
                if (button) button.focus();
            },
            true
        );
    }

    function teardownPanel() {
        const panel = document.getElementById(PMK144.id);
        if (panel) {
            const wrapper = panel.closest("li.pmk144-wrapper");
            if (wrapper) wrapper.remove();
            else panel.remove();
        }

        PMK144.state.checked = false;
        PMK144.state.checkedSignature = "";
        PMK144.state.lastResults = [];
    }

    function ensureRuntimeUi() {
        if (!isEnabledHere()) {
            teardownPanel();
            return;
        }

        const identity = currentIdentity();
        if (!identity.surnameEl || !identity.firstnameEl) {
            console.warn("[PMK144] Champs nom/prénom introuvables sur cette page.");
            return;
        }

        injectStyles();
        buildPanel();
        refreshLabelsAndDensity();
        attachIdentityListeners();
        attachSaveGuard();
    }

    function applyConfig(config, options) {
        PMK144.config = normalizeConfig(config);
        window.PMKConfig?.elementPicker?.register(MODULE_ID, {});

        if (!PMK144.config.enabled) {
            teardownPanel();
            teardownExistingChecks();
            return;
        }

        if (isNewPatronPage()) {
            if (PMK144.config.page.enabled === false) {
                teardownPanel();
            } else {
                ensureRuntimeUi();

                if (options && options.fromSubscription) {
                    resetValidation("Configuration modifiée : relancez le contrôle.");
                    refreshLabelsAndDensity();
                }
            }
        }

        if (
            PMK144.config.existingPatron &&
            PMK144.config.existingPatron.enabled !== false
        ) {
            teardownExistingChecks();
            scanExistingPatronBlocks();
        } else {
            teardownExistingChecks();
        }
    }

    async function init() {
        if (PMK144.initialized) return;
        PMK144.initialized = true;

        PMK144.config = await loadConfig();

        if (isNewPatronPage()) {
            ensureRuntimeUi();
        }

        scanExistingPatronBlocks();
        startExistingObserver();

        console.info("[PMK144] Contrôle doublons adhérents chargé — v" + VERSION);
    }

    function onPmkReady() {
        const wasRegistered = PMK144.pmkRegistered;
        if (!registerWithPMK()) return;

        if (!wasRegistered && PMK144.initialized) {
            loadConfig().then(function (config) {
                applyConfig(config);
            });
        }
    }

    window.PMK144PatronDuplicateCheck = {
        version: VERSION,
        defaults: clone(DEFAULTS),
        get config() {
            return clone(PMK144.config);
        },
        state: PMK144.state,
        runCheck: runCheck,
        checkExistingPatrons: scanExistingPatronBlocks,
        clearExistingCache: function () {
            PMK144.existingCache.clear();
            teardownExistingChecks();
            scanExistingPatronBlocks();
        },
        reset: resetValidation,
        identity: currentIdentity,
        reloadConfig: async function () {
            const config = await loadConfig();
            applyConfig(config);
            return clone(PMK144.config);
        },
        init: init
    };

    window.addEventListener("pmk:config-ready", onPmkReady);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("144-controle-doublons-adherents.js");
} catch (error) { window.PMKNonPlugin.errors.push("144-controle-doublons-adherents.js: "+error.message); console.error("[PMK] 144-controle-doublons-adherents.js",error); };
