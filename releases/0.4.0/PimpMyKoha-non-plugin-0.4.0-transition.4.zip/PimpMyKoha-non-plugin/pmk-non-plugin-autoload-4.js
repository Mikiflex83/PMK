/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
/*
 Nom du fichier: 018-element-formatting.js
 Ancien nom: 018-underline-last-four-digits.js
 Dépendances: 000-pmk-config-firestore.js (facultatif : valeurs par défaut intégrées)
 Date de dernière modification: 2026-09-17
 Version: 018.6.0 — moteur visuel commun PMK / multi-éléments
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha
 Description: Moteur générique multi-règles de mise en forme ciblée d'éléments Koha.
              Chaque règle peut cibler un élément différent avec sa propre mise en forme.
              Le nombre de règles n'est pas limité par le module.
              Le comportement historique du 018 reste fourni comme règle par défaut.
*/
(function () {
    'use strict';

    const MODULE_ID = 'element-formatting';
    const STYLE_ID = 'pmk018-element-formatting-style';
    const MARK_ATTR = 'data-pmk018-format';
    const ORIGINAL_ATTR = 'data-pmk018-original-html';

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 80,
        rules: [
            {
                id: 'legacy-patron-last-four',
                enabled: true,
                label: '4 derniers chiffres carte lecteur',
                pages: ['circ/circulation.pl', 'members/moremember.pl'],
                selector: 'div.patroninfo.is-not-staff h5, .circ_barcode, .col-sm-12 h1, h4:has(.patron-title)',
                matchMode: 'regex',
                regex: '\\((\\d+)\\)',
                regexFlags: '',
                regexGroup: 1,
                portion: 'last',
                count: 4,
                offset: 0,
                start: 0,
                length: 0,
                trim: false,
                style: {
                    bold: true,
                    italic: false,
                    color: '#008000',
                    backgroundColor: '',
                    fontSize: '',
                    letterSpacing: '1px',
                    underline: true,
                    underlineStyle: 'dotted',
                    underlineThickness: '',
                    underlineColor: '',
                    strike: false,
                    textTransform: 'none',
                    opacity: 1
                }
            }
        ]
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function merge(target, source) {
        if (!source || typeof source !== 'object') return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) {
                target[key] = deepClone(value);
            } else if (value && typeof value === 'object') {
                if (!target[key] || typeof target[key] !== 'object' || Array.isArray(target[key])) target[key] = {};
                merge(target[key], value);
            } else {
                target[key] = value;
            }
        });
        return target;
    }

    function normalizeConfig(config) {
        const result = merge(deepClone(DEFAULTS), config || {});
        if (!Array.isArray(result.rules)) result.rules = deepClone(DEFAULTS.rules);
        result.rules = result.rules.map(function (rule, index) {
            const base = {
                id: 'rule-' + (index + 1), enabled: true, label: '', pages: [], selector: '',
                matchMode: 'whole', regex: '', regexFlags: '', regexGroup: 0,
                portion: 'whole', count: 4, offset: 0, start: 0, length: 0, trim: false,
                style: {
                    bold: false, italic: false, color: '', backgroundColor: '', fontSize: '',
                    letterSpacing: '', underline: false, underlineStyle: 'solid',
                    underlineThickness: '', underlineColor: '', strike: false,
                    textTransform: 'none', opacity: 1
                }
            };
            return merge(base, rule || {});
        });
        return result;
    }

    function pathMatches(rule) {
        const pages = Array.isArray(rule.pages) ? rule.pages : String(rule.pages || '').split(/[\n,;]+/);
        const clean = pages.map(function (v) { return String(v || '').trim(); }).filter(Boolean);
        if (!clean.length) return true;
        const pathname = window.location.pathname;
        return clean.some(function (page) {
            if (page === '*' || page === 'all') return true;
            return pathname.indexOf(page) !== -1;
        });
    }

    function safeRegex(pattern, flags) {
        try { return new RegExp(pattern, flags || ''); }
        catch (_) { return null; }
    }

    function portionBounds(text, portion, count, offset, start, length) {
        const total = text.length;
        switch (portion) {
            case 'first': {
                const n = Math.max(0, Math.min(total, Number(count) || 0));
                const o = Math.max(0, Math.min(total, Number(offset) || 0));
                const from = Math.min(total, o);
                return [from, Math.min(total, from + n)];
            }
            case 'last': {
                const n = Math.max(0, Math.min(total, Number(count) || 0));
                const o = Math.max(0, Math.min(total, Number(offset) || 0));
                const to = Math.max(0, total - o);
                return [Math.max(0, to - n), to];
            }
            case 'range': {
                const s = Math.max(0, Math.min(total, Number(start) || 0));
                const l = Math.max(0, Number(length) || 0);
                return [s, Math.min(total, s + l)];
            }
            default:
                return [0, total];
        }
    }

    function buildStyle(rule) {
        const s = rule.style || {};
        const declarations = [];
        if (s.bold) declarations.push('font-weight:700');
        if (s.italic) declarations.push('font-style:italic');
        if (String(s.color || '').trim()) declarations.push('color:' + String(s.color).trim());
        if (String(s.backgroundColor || '').trim()) declarations.push('background-color:' + String(s.backgroundColor).trim());
        if (String(s.fontSize || '').trim()) declarations.push('font-size:' + String(s.fontSize).trim());
        if (String(s.letterSpacing || '').trim()) declarations.push('letter-spacing:' + String(s.letterSpacing).trim());
        if (s.underline || s.strike) {
            const lines = [];
            if (s.underline) lines.push('underline');
            if (s.strike) lines.push('line-through');
            declarations.push('text-decoration-line:' + lines.join(' '));
            if (s.underline) {
                declarations.push('text-decoration-style:' + (s.underlineStyle || 'solid'));
                if (String(s.underlineThickness || '').trim()) declarations.push('text-decoration-thickness:' + String(s.underlineThickness).trim());
                if (String(s.underlineColor || '').trim()) declarations.push('text-decoration-color:' + String(s.underlineColor).trim());
            }
        }
        if (s.textTransform && s.textTransform !== 'none') declarations.push('text-transform:' + s.textTransform);
        if (s.opacity !== undefined && s.opacity !== null && s.opacity !== '') {
            const opacity = Math.max(0, Math.min(1, Number(s.opacity)));
            if (Number.isFinite(opacity) && opacity !== 1) declarations.push('opacity:' + opacity);
        }
        declarations.push('display:inline-block');
        return declarations.join(';');
    }

    function makeSpan(text, rule, ruleIndex) {
        const span = document.createElement('span');
        span.setAttribute(MARK_ATTR, String(ruleIndex));
        span.className = 'pmk018-formatted';
        span.style.cssText = buildStyle(rule);
        span.textContent = text;
        return span;
    }

    function replaceRangeInTextNode(textNode, start, end, rule, ruleIndex) {
        if (!textNode || start >= end) return false;
        const text = textNode.nodeValue || '';
        if (start < 0 || end > text.length) return false;
        const fragment = document.createDocumentFragment();
        if (start > 0) fragment.appendChild(document.createTextNode(text.slice(0, start)));
        fragment.appendChild(makeSpan(text.slice(start, end), rule, ruleIndex));
        if (end < text.length) fragment.appendChild(document.createTextNode(text.slice(end)));
        textNode.parentNode.replaceChild(fragment, textNode);
        return true;
    }

    function textNodes(root) {
        const out = [];
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode: function (node) {
                if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (parent.closest('script,style,textarea,input,select,option')) return NodeFilter.FILTER_REJECT;
                if (parent.closest('[' + MARK_ATTR + ']')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let node;
        while ((node = walker.nextNode())) out.push(node);
        return out;
    }

    function applyWholeElementText(element, rule, ruleIndex) {
        const nodes = textNodes(element);
        if (!nodes.length) return false;

        // Pour "whole", on applique la mise en forme à tous les nœuds texte sans détruire les liens/icônes enfants.
        if (rule.matchMode === 'whole' && rule.portion === 'whole') {
            let changed = false;
            nodes.forEach(function (node) {
                const t = node.nodeValue || '';
                if (!t) return;
                changed = replaceRangeInTextNode(node, 0, t.length, rule, ruleIndex) || changed;
            });
            return changed;
        }

        // Les autres modes travaillent sur le texte concaténé en conservant les éléments HTML existants.
        const chunks = [];
        let cursor = 0;
        nodes.forEach(function (node) {
            const value = node.nodeValue || '';
            chunks.push({ node: node, start: cursor, end: cursor + value.length });
            cursor += value.length;
        });
        const fullText = nodes.map(function (n) { return n.nodeValue || ''; }).join('');

        let baseStart = 0;
        let baseEnd = fullText.length;
        if (rule.matchMode === 'regex') {
            const re = safeRegex(rule.regex, String(rule.regexFlags || '').replace(/g/g, ''));
            if (!re) return false;
            const match = re.exec(fullText);
            if (!match) return false;
            const group = Math.max(0, Number(rule.regexGroup) || 0);
            const groupText = match[group];
            if (groupText === undefined) return false;
            if (group === 0) {
                baseStart = match.index;
            } else {
                const relative = match[0].indexOf(groupText);
                if (relative < 0) return false;
                baseStart = match.index + relative;
            }
            baseEnd = baseStart + groupText.length;
        }

        let source = fullText.slice(baseStart, baseEnd);
        if (rule.trim) {
            const leading = source.length - source.replace(/^\s+/, '').length;
            const trailing = source.length - source.replace(/\s+$/, '').length;
            baseStart += leading;
            baseEnd -= trailing;
            source = fullText.slice(baseStart, baseEnd);
        }

        // Pour les sélections partielles, ne pas compter les espaces/retours à la ligne
        // invisibles placés par le HTML autour du texte. Ainsi N = N caractères visibles.
        let countOffset = 0;
        let countSource = source;
        if (rule.portion !== 'whole') {
            const leadingInvisible = countSource.length - countSource.replace(/^\s+/, '').length;
            const trailingInvisible = countSource.length - countSource.replace(/\s+$/, '').length;
            countOffset = leadingInvisible;
            countSource = countSource.slice(leadingInvisible, Math.max(leadingInvisible, countSource.length - trailingInvisible));
        }

        const bounds = portionBounds(countSource, rule.portion, rule.count, rule.offset, rule.start, rule.length);
        const wantedStart = baseStart + countOffset + bounds[0];
        const wantedEnd = baseStart + countOffset + bounds[1];
        if (wantedStart >= wantedEnd) return false;

        // Appliquer de droite à gauche pour ne pas invalider les références aux nœuds précédents.
        let changed = false;
        chunks.slice().reverse().forEach(function (chunk) {
            const start = Math.max(wantedStart, chunk.start);
            const end = Math.min(wantedEnd, chunk.end);
            if (start >= end || !chunk.node.parentNode) return;
            changed = replaceRangeInTextNode(chunk.node, start - chunk.start, end - chunk.start, rule, ruleIndex) || changed;
        });
        return changed;
    }

    function restoreElement(element) {
        if (!element || !element.hasAttribute(ORIGINAL_ATTR)) return;
        // Unwrap only our spans: keep native elements, event handlers and later DOM updates.
        element.querySelectorAll('[' + MARK_ATTR + ']').forEach(function (span) {
            span.replaceWith(...span.childNodes);
        });
        element.normalize();
        element.removeAttribute(ORIGINAL_ATTR);
        element.removeAttribute('data-pmk018-applied');
    }

    function restoreAll() {
        document.querySelectorAll('[' + ORIGINAL_ATTR + ']').forEach(restoreElement);
    }

    function applyRule(rule, ruleIndex) {
        if (!rule || rule.enabled === false || !pathMatches(rule)) return;
        const selector = String(rule.selector || '').trim();
        if (!selector) return;
        let elements;
        try { elements = document.querySelectorAll(selector); }
        catch (_) { return; }

        elements.forEach(function (element) {
            if (!element || element.closest('#pmk-config-admin')) return;
            const token = String(rule.id || ruleIndex);
            const applied = String(element.getAttribute('data-pmk018-applied') || '').split(',').filter(Boolean);
            if (applied.indexOf(token) !== -1) return;
            if (!element.hasAttribute(ORIGINAL_ATTR)) element.setAttribute(ORIGINAL_ATTR, element.innerHTML);
            if (applyWholeElementText(element, rule, ruleIndex)) {
                applied.push(token);
                element.setAttribute('data-pmk018-applied', applied.join(','));
            }
        });
    }

    function applyAll() {
        if (!currentConfig || currentConfig.enabled === false) return;
        (currentConfig.rules || []).forEach(applyRule);
    }

    function refresh(config) {
        stopObserver();
        restoreAll();
        currentConfig = normalizeConfig(config);
        if (currentConfig.enabled !== false) {
            applyAll();
            if (currentConfig.observeDom !== false) startObserver();
        }
    }

    function startObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(function (mutations) {
            // Ignorer les mutations produites uniquement par le module lui-même.
            const external = mutations.some(function (mutation) {
                const target = mutation.target && mutation.target.nodeType === 1 ? mutation.target : mutation.target && mutation.target.parentElement;
                return !(target && target.closest && target.closest('[' + MARK_ATTR + ']'));
            });
            if (!external) return;
            clearTimeout(observerTimer);
            observerTimer = window.setTimeout(applyAll, Math.max(20, Number(currentConfig.observeDelay) || 80));
        });
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }

    function stopObserver() {
        clearTimeout(observerTimer);
        observerTimer = 0;
        if (observer) observer.disconnect();
        observer = null;
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return '\\' + c; });
    }

    function firstPickerPage(context) {
        const rootObject = context && context.rootObject ? context.rootObject : null;
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const pos = path.indexOf('rules');
        const index = pos >= 0 ? Number(path[pos + 1]) : -1;
        const rule = rootObject && Array.isArray(rootObject.rules) && Number.isInteger(index) ? rootObject.rules[index] : null;
        const pages = Array.isArray(rule && rule.pages) ? rule.pages : String(rule && rule.pages || '').split(/[\n,;]+/);
        for (let i = 0; i < pages.length; i += 1) {
            const raw = String(pages[i] || '').trim();
            if (!raw || raw === '*' || raw === 'all') continue;
            if (raw.startsWith('/')) return raw;
            return '/cgi-bin/koha/' + raw.replace(/^\/+/, '');
        }
        return window.location.pathname;
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== 'function') return false;
        service.register(MODULE_ID, {
            getOptions: function () {
                return {
                    bannerText: (window.PMKConfig && window.PMKConfig.getLanguage && window.PMKConfig.getLanguage() === 'en')
                        ? 'Click the element to format — Esc cancels'
                        : 'Clique sur l’élément à mettre en forme — Échap annule'
                };
            },
            applyPending: function (draft, pending, picked) {
                const path = pending && Array.isArray(pending.fieldPath) ? pending.fieldPath : [];
                const pos = path.indexOf('rules');
                const index = pos >= 0 ? Number(path[pos + 1]) : -1;
                if (!draft || !Array.isArray(draft.rules) || !Number.isInteger(index) || !draft.rules[index]) return draft;
                const rule = draft.rules[index];
                if (picked && picked.targetName) {
                    if (!String(rule.targetName || '').trim()) rule.targetName = picked.targetName;
                    if (!String(rule.label || '').trim()) rule.label = picked.targetName;
                }
                return draft;
            }
        });
        return true;
    }

    function stableSelector(element) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        return service && typeof service.stableSelector === 'function' ? service.stableSelector(element) : '';
    }

    function pickElement(context) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== 'function') {
            return Promise.reject(new Error('pmk_common_picker_unavailable'));
        }
        registerCommonPickerAdapter();
        const ctx = context || {};
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: firstPickerPage(ctx),
            rootObject: ctx.rootObject || {},
            fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath : [],
            adminContext: { sectionId: 'rules' }
        });
    }

    function visualRuleFromPath(rootObject, fieldPath) {
        const path = Array.isArray(fieldPath) ? fieldPath : [];
        const pos = path.indexOf('rules');
        const index = pos >= 0 ? Number(path[pos + 1]) : -1;
        return rootObject && Array.isArray(rootObject.rules) && Number.isInteger(index)
            ? rootObject.rules[index]
            : null;
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== 'function') return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: true,
                livePreview: true
            },
            previewModel: function (context) {
                const rule = visualRuleFromPath(context && context.rootObject, context && context.fieldPath) || {};
                const s = rule.style || {};
                let decoration = [];
                if (s.underline) decoration.push('underline');
                if (s.strike) decoration.push('line-through');
                return {
                    text: rule.targetName || rule.label || 'Aperçu 00000000000001',
                    style: {
                        fontWeight: s.bold ? '700' : '400',
                        fontStyle: s.italic ? 'italic' : 'normal',
                        color: s.color || '',
                        backgroundColor: s.backgroundColor || '',
                        fontSize: s.fontSize || '',
                        letterSpacing: s.letterSpacing || '',
                        textDecorationLine: decoration.join(' ') || 'none',
                        textDecorationStyle: s.underlineStyle || 'solid',
                        textDecorationColor: s.underlineColor || '',
                        textDecorationThickness: s.underlineThickness || '',
                        textTransform: s.textTransform || 'none',
                        opacity: s.opacity == null ? '1' : String(s.opacity)
                    }
                };
            },
            styleTargetUrl: function (context) {
                const rule = visualRuleFromPath(context && context.rootObject, context && context.fieldPath);
                if (!rule) return window.location.pathname;
                const pages = Array.isArray(rule.pages) ? rule.pages : String(rule.pages || '').split(/[\n,;]+/);
                for (let i = 0; i < pages.length; i += 1) {
                    const raw = String(pages[i] || '').trim();
                    if (!raw || raw === '*' || raw === 'all') continue;
                    if (raw.startsWith('/')) return raw;
                    return '/cgi-bin/koha/' + raw.replace(/^\/+/, '');
                }
                return window.location.pathname;
            },
            applyStyleSample: function (context) {
                const rule = visualRuleFromPath(context && context.rootObject, context && context.fieldPath);
                const sample = context && context.sample;
                if (!rule || !sample) return { rootObject: context && context.rootObject };
                const visual = window.PMKConfig && window.PMKConfig.visualEditor;
                const toHex = visual && typeof visual.colorToHex === 'function'
                    ? visual.colorToHex
                    : function () { return ''; };
                const style = rule.style || (rule.style = {});
                style.bold = (parseInt(sample.fontWeight, 10) || 0) >= 600 || /bold/i.test(String(sample.fontWeight || ''));
                style.italic = /italic|oblique/i.test(String(sample.fontStyle || ''));
                style.color = toHex(sample.color) || '';
                style.backgroundColor = toHex(sample.backgroundColor) || '';
                style.fontSize = String(sample.fontSize || '');
                style.letterSpacing = String(sample.letterSpacing || '');
                const lines = String(sample.textDecorationLine || sample.textDecoration || '');
                style.underline = /underline/i.test(lines);
                style.strike = /line-through/i.test(lines);
                if (sample.textDecorationStyle) style.underlineStyle = String(sample.textDecorationStyle);
                style.underlineColor = toHex(sample.textDecorationColor) || '';
                style.underlineThickness = String(sample.textDecorationThickness || '');
                style.textTransform = ['none','uppercase','lowercase','capitalize'].includes(String(sample.textTransform || ''))
                    ? String(sample.textTransform)
                    : 'none';
                const opacity = parseFloat(sample.opacity);
                if (Number.isFinite(opacity)) style.opacity = Math.max(0, Math.min(1, opacity));
                return { rootObject: context && context.rootObject };
            },
            previewDraft: function (draft) {
                const before = deepClone(currentConfig || DEFAULTS);
                refresh(draft);
                return function () {
                    refresh(before);
                };
            }
        });
        return true;
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') {
            return Promise.resolve(deepClone(DEFAULTS));
        }
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return cfg || deepClone(DEFAULTS); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function registerRuntimeConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function') return;
        // Le schéma complet est pré-enregistré par 000-pmk-config-firestore.js.
        // On ne remplace pas ici la définition centrale lorsqu'elle existe.
    }

    function start() {
        registerRuntimeConfig();
        registerCommonPickerAdapter();
        registerVisualEditorAdapter();
        loadConfig().then(refresh);
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === 'function') {
            try {
                window.PMKConfig.subscribe(MODULE_ID, function (cfg) { refresh(cfg); });
            } catch (_) {}
        }
    }

    window.PMK018ElementFormatting = {
        id: MODULE_ID,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        apply: applyAll,
        restore: restoreAll,
        pickElement: pickElement,
        stableSelector: stableSelector
    };

    if (!document.getElementById(STYLE_ID)) {
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = '.pmk018-formatted{box-decoration-break:clone;-webkit-box-decoration-break:clone;}';
        document.head.appendChild(style);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})();

;window.PMKNonPlugin.loaded.push("018-element-formatting.js");
} catch (error) { window.PMKNonPlugin.errors.push("018-element-formatting.js: "+error.message); console.error("[PMK] 018-element-formatting.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.awards;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 019-prix-search-links.js
 Dépendances: aucune
 Date de dernière modification: 2026-02-21
 Auteur: équipe PimpMyKoha
 Description: Ajoute un panneau latéral listant des recherches prédéfinies par prix littéraires pour faciliter la navigation.
*/

(function(){
  (function (callback) {
        if (document.readyState !== 'loading') callback.call(document);
        else document.addEventListener('DOMContentLoaded', callback, { once: true });
    })(function(){
  if (window.location.pathname.includes('search.pl')) {

  // Vérifie si le conteneur existe déjà
  if (!document.getElementById('drac-search-prices')) {

    const historicPrixList = [
      "Prix Goncourt","Prix Goncourt des lycéens","Prix Renaudot",
      "Grand prix du roman de l'Académie française","Prix Femina",
      "Prix Médicis","Prix Interallié","Prix du roman Fnac",
      "Prix des Cinq Continents de la Francophonie","Prix Sorcières",
      "Prix Décembre","Grand prix des lectrices de Elle","Prix des libraires",
      "Prix de Flore","Prix Jean Giono","Prix des libraires de Nancy Le Point",
      "Prix Anaïs Nin","Prix littéraire du Monde","Prix Blù Jean",
      "Prix Landerneau","Prix Vendredi","Prix Maison de la presse",
      "Prix du Livre Inter","Prix Landerneau polar","Prix du Polar en séries",
      "Prix du Salon Le livre sur la place","Prix Wepler","Prix Hennessy du livre",
      "Prix Transfuge du meilleur roman de langue française",
      "Prix des libraires de Nancy et des journalistes du Point",
      "Prix du roman des étudiants France Culture",
      "Prix littéraire de la vocation Marcel Bleustein","Prix Relay",
      "Prix Gouttes de sang d'encre","Prix Cezam inter","Prix des lecteurs Quais du polar",
      "Prix Locus","Prix Imaginales","Prix Page des libraires","Prix Orange du Livre",
      "Prix Trop Virilo","Prix Pierre Bottero","Prix Jules Rimet","Prix Arsène Lupin",
      "Prix Femina étranger","Prix Médicis essai","Prix du Style","Prix Le Vaudeville",
      "Prix Pulitzer","Prix du deuxième roman","Prix Stanislas","Prix Envoyé par la Poste",
      "Prix du public"
    ];

    const prixList=options.values.trim()?options.values.split(/\n/).map(x=>x.trim()).filter(Boolean):historicPrixList;
    // Injecte le style
    const style = document.createElement('style');
    style.innerHTML = `
      #drac-search-prices {
          border: 1px solid #408540;
          border-radius: 5px 5px 0 0;
          padding: 0.3em;
      }
      #drac-search-prices h4 {
          background-color: #408540;
          color: white;
          font-size: 90%;
          margin: 0 0 0.2em 0;
          padding: 0.4em 0.2em;
          border-radius: 5px 5px 0 0;
          text-align: center;
      }
      #drac-search-prices a {
          display: block;
          margin: 2px 0;
          color: #006400;
          text-decoration: none;
      }
      #drac-search-prices a:hover {
          text-decoration: underline;
      }
      #drac-toggle-btn {
          display: block;
          margin: 5px auto;
          padding: 5px 10px;
          background-color: #408540;
          color: white;
          border: none;
          border-radius: 5px;
          cursor: pointer;
      }
      #drac-toggle-btn:hover {
          background-color: #306b36;
      }
    `;
    document.head.appendChild(style);

    const aside = document.querySelector('aside');
    if (!aside) return;

    // Crée le conteneur principal
    const container = document.createElement('div');
    container.id = 'drac-search-prices';

    const header = document.createElement('h4');
    header.textContent = 'Recherche par Prix Littéraire :';
    container.appendChild(header);

    // Préparer les fragments
    const initialFragment = document.createDocumentFragment();
    const hiddenFragment = document.createDocumentFragment();

    prixList.forEach((prix, index) => {
      const link = document.createElement('a');
      link.href = `/cgi-bin/koha/catalogue/search.pl?idx=${encodeURIComponent(options.index)}&q=%22${encodeURIComponent(prix)}%22&sort_by=pubdate_dsc&count=25`;
      link.textContent = prix;
      link.target = '_blank';
      if (index < 15) {
        initialFragment.appendChild(link);
      } else {
        hiddenFragment.appendChild(link);
      }
    });

    container.appendChild(initialFragment);

    // Bouton "Afficher plus / moins"
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'drac-toggle-btn';
    toggleBtn.textContent = 'Afficher plus';
    let isExpanded = false;

    toggleBtn.addEventListener('click', () => {
      if (isExpanded) {
        // Retirer les prix supplémentaires
        while (container.children.length > 16) { // 15 prix + header
          container.removeChild(container.lastChild);
        }
        toggleBtn.textContent = 'Afficher plus';
      } else {
        // Ajouter les prix cachés
        container.appendChild(hiddenFragment.cloneNode(true));
        toggleBtn.textContent = 'Afficher moins';
      }
      isExpanded = !isExpanded;
    });

    aside.appendChild(container);
    aside.appendChild(toggleBtn);
  }
}
  });
})();
})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("019-prix-search-links.js");
} catch (error) { window.PMKNonPlugin.errors.push("019-prix-search-links.js: "+error.message); console.error("[PMK] 019-prix-search-links.js",error); };
try {
/* ============================================================
   PimpMyKoha - Pré-plugin
   Fichier : 021-code-collection-search-results.js
   Version : 2.3.0-isolated

   Module fonctionnel : Liens dynamiques

   Fonction :
   - rend un élément Koha cliquable à partir d'une valeur détectée ;
   - construit dynamiquement l'URL à partir d'un modèle contenant {value} ;
   - permet de choisir visuellement l'élément sur la page ;
   - prend en charge texte, attribut, valeur de formulaire et DataTables ;
   - conserve le comportement historique « code collection -> recherche ccode »
     comme configuration par défaut ;
   - FR/EN, responsive, idempotent et fail-safe ;
   - configuration partagée via 000-pmk-config-firestore.js ;
   - aucune dépendance directe à Firebase dans la logique métier.
   ============================================================ */
(function () {
    "use strict";

    if (window.__PMK_021_DYNAMIC_LINKS__) return;
    window.__PMK_021_DYNAMIC_LINKS__ = true;

    const MODULE_ID = "contextual-search-links"; // identifiant conservé pour ne pas perdre la configuration existante
    const MODULE_VERSION = "2.3.0-isolated";
    const MARK_ATTR = "data-pmk021-dynamic-link";
    const RULE_ATTR = "data-pmk021-rule";
    const ORIGINAL_HREF_ATTR = "data-pmk021-original-href";
    const ORIGINAL_TARGET_ATTR = "data-pmk021-original-target";
    const ORIGINAL_REL_ATTR = "data-pmk021-original-rel";
    const PICKER_STYLE_ID = "pmk021-picker-style";

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 100,
        rules: [
            {
                id: "legacy-search-ccode",
                enabled: true,
                label: "Code collection — résultats de recherche",
                engine: "dom",
                pagePath: "/cgi-bin/koha/catalogue/search.pl",
                selector: "span.ccode",
                targetName: "Code collection",
                exampleValue: "ROM",
                matchCount: null,
                valueSource: "text",
                attributeName: "",
                trim: true,
                extractRegex: "",
                regexFlags: "",
                regexGroup: 0,
                encodeValue: true,
                urlTemplate: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"",
                linkMode: "element",
                presentation: "legacy-ccode-block",
                legacyPrefixFr: "Code collection :",
                legacyPrefixEn: "Collection code:",
                legacySeparator: ", ",
                linkTextTemplate: "{value}",
                openInNewTab: false,
                tableSelector: "",
                columnName: "",
                dataField: "",
                previewUrl: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"ROM\""
            },
            {
                id: "detail-holdings-ccode",
                enabled: true,
                label: "Code collection — exemplaires",
                engine: "datatable-column",
                pagePath: "/cgi-bin/koha/catalogue/detail.pl",
                selector: "",
                targetName: "Code collection des exemplaires",
                exampleValue: "ROM",
                matchCount: null,
                valueSource: "datatable-field",
                attributeName: "",
                trim: true,
                extractRegex: "",
                regexFlags: "",
                regexGroup: 0,
                encodeValue: true,
                urlTemplate: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"",
                linkMode: "element",
                presentation: "element",
                legacyPrefixFr: "Code collection :",
                legacyPrefixEn: "Collection code:",
                legacySeparator: ", ",
                linkTextTemplate: "{value}",
                openInNewTab: true,
                tableSelector: "#holdings_table",
                columnName: "ccode",
                dataField: "collection_code",
                previewUrl: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"ROM\""
            },
            {
                id: "detail-otherholdings-ccode",
                enabled: true,
                label: "Code collection — autres exemplaires",
                engine: "datatable-column",
                pagePath: "/cgi-bin/koha/catalogue/detail.pl",
                selector: "",
                targetName: "Code collection des autres exemplaires",
                exampleValue: "ROM",
                matchCount: null,
                valueSource: "datatable-field",
                attributeName: "",
                trim: true,
                extractRegex: "",
                regexFlags: "",
                regexGroup: 0,
                encodeValue: true,
                urlTemplate: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"",
                linkMode: "element",
                presentation: "element",
                legacyPrefixFr: "Code collection :",
                legacyPrefixEn: "Collection code:",
                legacySeparator: ", ",
                linkTextTemplate: "{value}",
                openInNewTab: true,
                tableSelector: "#otherholdings_table",
                columnName: "ccode",
                dataField: "collection_code",
                previewUrl: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"ROM\""
            }
        ]
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;
    let unsubscribe = null;
    let coreRegistered = false;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) return Array.isArray(override) ? clone(override) : clone(base);
        if (!base || typeof base !== "object") return override === undefined ? clone(base) : clone(override);
        const out = clone(base) || {};
        if (!override || typeof override !== "object" || Array.isArray(override)) return out;
        Object.keys(override).forEach(function (key) {
            if (Array.isArray(override[key])) out[key] = clone(override[key]);
            else if (override[key] && typeof override[key] === "object" && out[key] && typeof out[key] === "object" && !Array.isArray(out[key])) {
                out[key] = deepMerge(out[key], override[key]);
            } else out[key] = clone(override[key]);
        });
        return out;
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") return window.PMKConfig.getLanguage();
        const lang = (document.documentElement.getAttribute("lang") || navigator.language || "").toLowerCase();
        return lang.startsWith("fr") ? "fr" : "en";
    }

    function normalizePath(path) {
        let value = String(path || "").trim();
        if (!value) return "";
        try {
            if (/^https?:\/\//i.test(value)) value = new URL(value).pathname;
        } catch (_) {}
        if (!value.startsWith("/")) {
            if (value.startsWith("cgi-bin/koha/")) value = "/" + value;
            else value = "/cgi-bin/koha/" + value.replace(/^\/+/, "");
        }
        return value.replace(/\/+$/, "") || "/";
    }

    function ruleAppliesHere(rule) {
        if (!rule || rule.enabled === false) return false;
        return normalizePath(rule.pagePath) === normalizePath(window.location.pathname);
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (character) { return "\\" + character; });
    }

    function selectorCount(selector) {
        if (!selector) return 0;
        try { return document.querySelectorAll(selector).length; } catch (_) { return 0; }
    }

    function isUsableClass(name) {
        return name && !/^(pmk|active$|selected$|hover$|focus$|show$|open$|collapsed$|odd$|even$)/i.test(name);
    }

    function reusableSelector(element) {
        if (!element || element.nodeType !== 1) return "";

        if (element.id) {
            const byId = "#" + cssEscape(element.id);
            if (selectorCount(byId) === 1) return byId;
        }

        const stableAttributes = ["data-colname", "name", "data-field", "data-column", "data-testid", "role"];
        for (const attribute of stableAttributes) {
            const value = element.getAttribute && element.getAttribute(attribute);
            if (!value) continue;
            const candidate = element.tagName.toLowerCase() + "[" + attribute + "=\"" + String(value).replace(/"/g, "\\\"") + "\"]";
            if (selectorCount(candidate) > 0) return candidate;
        }

        const classes = Array.from(element.classList || []).filter(isUsableClass);
        if (classes.length) {
            for (let take = Math.min(2, classes.length); take >= 1; take -= 1) {
                const candidate = element.tagName.toLowerCase() + "." + classes.slice(0, take).map(cssEscape).join(".");
                if (selectorCount(candidate) > 0) return candidate;
            }
        }

        const parts = [];
        let node = element;
        while (node && node !== document.body && parts.length < 5) {
            let part = node.tagName.toLowerCase();
            if (node.id) {
                part += "#" + cssEscape(node.id);
                parts.unshift(part);
                break;
            }
            const nodeClasses = Array.from(node.classList || []).filter(isUsableClass);
            if (nodeClasses.length) part += "." + cssEscape(nodeClasses[0]);
            else if (node.parentElement) {
                const peers = Array.from(node.parentElement.children).filter(function (candidate) { return candidate.tagName === node.tagName; });
                if (peers.length > 1) part += ":nth-of-type(" + (peers.indexOf(node) + 1) + ")";
            }
            parts.unshift(part);
            node = node.parentElement;
        }
        const candidate = parts.join(" > ");
        return selectorCount(candidate) > 0 ? candidate : "";
    }

    function elementExample(element) {
        if (!element) return "";
        if ((element.tagName === "INPUT" || element.tagName === "TEXTAREA" || element.tagName === "SELECT") && element.value != null) {
            return String(element.value).trim().slice(0, 160);
        }
        return String(element.textContent || "").replace(/\s+/g, " ").trim().slice(0, 160);
    }

    function visualElementPicker() {
        return new Promise(function (resolve, reject) {
            const admin = document.querySelector("#pmk-config-overlay, .pmk-admin-overlay, #pmk-config-admin");
            const oldDisplay = admin ? admin.style.display : "";
            if (admin) admin.style.display = "none";

            const oldStyle = document.getElementById(PICKER_STYLE_ID);
            if (oldStyle) oldStyle.remove();
            const style = document.createElement("style");
            style.id = PICKER_STYLE_ID;
            style.textContent = ".pmk021-picker-hover{outline:3px solid #2f7d32!important;outline-offset:2px!important;cursor:crosshair!important;}";
            document.head.appendChild(style);

            let hovered = null;
            function cleanup() {
                if (hovered) hovered.classList.remove("pmk021-picker-hover");
                document.removeEventListener("mouseover", over, true);
                document.removeEventListener("mouseout", out, true);
                document.removeEventListener("click", click, true);
                document.removeEventListener("keydown", key, true);
                style.remove();
                if (admin) admin.style.display = oldDisplay;
            }
            function over(event) {
                if (hovered) hovered.classList.remove("pmk021-picker-hover");
                hovered = event.target && event.target.nodeType === 1 ? event.target : null;
                if (hovered) hovered.classList.add("pmk021-picker-hover");
            }
            function out(event) {
                if (event.target && event.target.classList) event.target.classList.remove("pmk021-picker-hover");
            }
            function click(event) {
                event.preventDefault();
                event.stopPropagation();
                const element = event.target;
                const selector = reusableSelector(element);
                if (!selector) {
                    cleanup();
                    reject(new Error("selector_unavailable"));
                    return;
                }
                const example = elementExample(element);
                const result = {
                    value: selector,
                    selector: selector,
                    targetName: example || element.tagName.toLowerCase(),
                    exampleValue: example,
                    pagePath: window.location.pathname,
                    matchCount: selectorCount(selector)
                };
                cleanup();
                resolve(result);
            }
            function key(event) {
                if (event.key !== "Escape") return;
                event.preventDefault();
                cleanup();
                reject(new Error("picker_cancelled"));
            }
            document.addEventListener("mouseover", over, true);
            document.addEventListener("mouseout", out, true);
            document.addEventListener("click", click, true);
            document.addEventListener("keydown", key, true);
        });
    }

    function normalizeRule(rule, index) {
        const base = {
            id: "rule-" + (index + 1),
            enabled: true,
            label: "",
            engine: "dom",
            pagePath: window.location.pathname,
            selector: "",
            targetName: "",
            exampleValue: "",
            matchCount: null,
            valueElementMode: "target",
            valueSelector: "",
            valueTargetName: "",
            valueMatchCount: null,
            valuePairing: "auto",
            valueSource: "text",
            attributeName: "",
            trim: true,
            extractRegex: "",
            regexFlags: "",
            regexGroup: 0,
            encodeValue: true,
            urlTemplate: "",
            linkMode: "element",
            presentation: "element",
            legacyPrefixFr: "Code collection :",
            legacyPrefixEn: "Collection code:",
            legacySeparator: ", ",
            linkTextTemplate: "Ouvrir",
            openInNewTab: false,
            tableSelector: "",
            columnName: "",
            dataField: "",
            previewUrl: ""
        };
        return deepMerge(base, rule || {});
    }

    function normalizeConfig(config) {
        const merged = deepMerge(DEFAULTS, config || {});
        if (!Array.isArray(merged.rules) || !merged.rules.length) merged.rules = clone(DEFAULTS.rules);
        merged.rules = merged.rules.map(normalizeRule);
        return merged;
    }

    function extractValue(rawValue, rule) {
        let value = rawValue == null ? "" : String(rawValue);
        if (rule.trim !== false) value = value.trim();
        if (!value) return "";
        const pattern = String(rule.extractRegex || "").trim();
        if (pattern) {
            try {
                const flags = String(rule.regexFlags || "").replace(/[^dgimsuvy]/g, "");
                const match = value.match(new RegExp(pattern, flags));
                if (!match) return "";
                const group = Math.max(0, Number(rule.regexGroup) || 0);
                value = match[group] == null ? "" : String(match[group]);
            } catch (_) {
                return "";
            }
        }
        return rule.trim !== false ? value.trim() : value;
    }

    function readDomValue(element, rule) {
        if (!element) return "";
        if (rule.valueSource === "attribute") {
            const name = String(rule.attributeName || "").trim();
            if (!name) return "";
            return extractValue(element.getAttribute(name), rule);
        }
        if (rule.valueSource === "value") {
            return extractValue(element.value, rule);
        }
        return extractValue(element.textContent, rule);
    }

    function templateValue(value, encode) {
        return encode === false ? String(value) : encodeURIComponent(String(value));
    }

    function buildUrl(rule, value) {
        const template = String(rule.urlTemplate || "").trim();
        if (!template || template.indexOf("{value}") === -1) return "";
        if(window.PMKWorkbench) return window.PMKWorkbench.renderTemplate(template,{value:String(value),raw:String(value)},{encode:rule.encodeValue!==false,rawTokens:['raw'],protocols:['http:','https:','mailto:','tel:','ftp:']}) || '';
        const encoded = templateValue(value, rule.encodeValue !== false);
        const raw = String(value);
        const url = template
            .replace(/\{value\}/g, encoded)
            .replace(/\{raw\}/g, raw);
        if (/^\s*(javascript|data|vbscript):/i.test(url)) return "";
        return url;
    }

    function previewForRule(rule) {
        const example = String(rule.exampleValue || "").trim() || "EXEMPLE";
        return buildUrl(rule, example);
    }

    function getRuleIndex(fieldPath) {
        const index = Array.isArray(fieldPath) && fieldPath[0] === "rules" ? Number(fieldPath[1]) : NaN;
        return Number.isInteger(index) ? index : null;
    }

    function refreshRulePreview(rootObject, fieldPath) {
        const index = getRuleIndex(fieldPath);
        if (index === null || !rootObject || !Array.isArray(rootObject.rules) || !rootObject.rules[index]) return;
        rootObject.rules[index].previewUrl = previewForRule(rootObject.rules[index]);
    }

    function applyPickerResult(rootObject, fieldPath, result) {
        const index = getRuleIndex(fieldPath);
        if (index === null || !rootObject.rules || !rootObject.rules[index] || !result) return;
        const rule = rootObject.rules[index];
        rule.engine = "dom";
        rule.pagePath = result.pagePath || window.location.pathname;
        rule.targetName = result.targetName || rule.targetName || "Élément Koha";
        rule.matchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(result.selector || rule.selector);
        if ((rule.valueElementMode || "target") === "target") {
            rule.exampleValue = result.exampleValue || rule.exampleValue || "";
        }
        rule.previewUrl = previewForRule(rule);
    }

    function applyValuePickerResult(rootObject, fieldPath, result) {
        const index = getRuleIndex(fieldPath);
        if (index === null || !rootObject.rules || !rootObject.rules[index] || !result) return;
        const rule = rootObject.rules[index];
        rule.valueElementMode = "picked";
        rule.pagePath = result.pagePath || rule.pagePath || window.location.pathname;
        rule.valueTargetName = result.targetName || rule.valueTargetName || "Source de valeur";
        rule.valueMatchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(result.selector || rule.valueSelector);
        rule.exampleValue = result.exampleValue || rule.exampleValue || "";
        rule.previewUrl = previewForRule(rule);
    }

    function pickForRule(context, role) {
        const ctx = context || {};
        const index = getRuleIndex(ctx.fieldPath);
        const rule = index !== null && ctx.rootObject && Array.isArray(ctx.rootObject.rules) ? ctx.rootObject.rules[index] : null;
        const targetUrl = rule && rule.pagePath ? rule.pagePath : window.location.pathname;
        const common = window.PMKConfig && window.PMKConfig.elementPicker;
        if (common && typeof common.pickForConfig === "function") {
            return common.pickForConfig({
                moduleId: MODULE_ID,
                targetUrl: targetUrl,
                fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath.slice() : [],
                rootObject: ctx.rootObject || {},
                meta: { role: role || "target" },
                adminContext: { sectionId: "rules", pagePath: targetUrl },
                options: {
                    bannerText: role === "value"
                        ? (detectLanguage() === "en" ? "Click the element that supplies {value} — Esc cancels" : "Clique sur l’élément qui fournit {value} — Échap annule")
                        : (detectLanguage() === "en" ? "Click the element that will receive the link — Esc cancels" : "Clique sur l’élément qui recevra le lien — Échap annule")
                }
            });
        }
        return visualElementPicker();
    }

    function registerCommonPickerAdapter() {
        const common = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!common || typeof common.register !== "function") return;
        common.register(MODULE_ID, {
            buildResult: function (candidate, result) {
                result.exampleValue = elementExample(candidate);
                result.matchCount = selectorCount(result.selector);
                return result;
            },
            applyPending: function (draft, pending, picked) {
                const index = getRuleIndex(pending && pending.fieldPath);
                if (index === null || !draft || !Array.isArray(draft.rules) || !draft.rules[index] || !picked) return draft;
                const rule = draft.rules[index];
                const role = pending && pending.meta && pending.meta.role === "value" ? "value" : "target";
                rule.pagePath = picked.pagePath || rule.pagePath || window.location.pathname;
                if (role === "value") {
                    rule.valueElementMode = "picked";
                    rule.valueTargetName = picked.targetName || rule.valueTargetName || "Source de valeur";
                    rule.valueMatchCount = Number.isInteger(picked.matchCount) ? picked.matchCount : null;
                    rule.exampleValue = picked.exampleValue || rule.exampleValue || "";
                } else {
                    rule.engine = "dom";
                    rule.targetName = picked.targetName || rule.targetName || "Élément Koha";
                    rule.matchCount = Number.isInteger(picked.matchCount) ? picked.matchCount : null;
                    if ((rule.valueElementMode || "target") === "target") rule.exampleValue = picked.exampleValue || rule.exampleValue || "";
                }
                rule.previewUrl = previewForRule(rule);
                return draft;
            }
        });
    }

    function newRule() {
        const rule = normalizeRule({
            id: "rule-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7),
            label: detectLanguage() === "fr" ? "Nouveau lien dynamique" : "New dynamic link",
            pagePath: window.location.pathname,
            linkTextTemplate: detectLanguage() === "fr" ? "Ouvrir" : "Open"
        }, 0);
        return rule;
    }

    function validateConfig(config) {
        const lang = detectLanguage();
        const fail = function (fr, en) { return { ok: false, message: lang === "en" ? en : fr }; };
        if (!config || !Array.isArray(config.rules)) return fail("La liste des règles est invalide.", "The rule list is invalid.");
        const ids = new Set();
        for (let i = 0; i < config.rules.length; i += 1) {
            const rule = normalizeRule(config.rules[i], i);
            if (!rule.id || ids.has(rule.id)) return fail("Chaque règle doit avoir un identifiant unique.", "Each rule must have a unique identifier.");
            ids.add(rule.id);
            if (!rule.pagePath) return fail("Chaque règle doit indiquer une page Koha.", "Each rule must specify a Koha page.");
            if (!rule.urlTemplate || rule.urlTemplate.indexOf("{value}") === -1) {
                return fail("Chaque URL doit contenir la variable {value}.", "Each URL must contain the {value} variable.");
            }
            if (rule.engine === "dom" && !rule.selector) return fail("Une règle d'élément doit cibler un élément de la page.", "An element rule must target a page element.");
            if (rule.engine === "dom" && rule.valueElementMode === "picked" && !String(rule.valueSelector || "").trim()) {
                return fail("La source de {value} doit être sélectionnée sur la page.", "The {value} source must be selected on the page.");
            }
            if (rule.engine === "datatable-column" && (!rule.tableSelector || !rule.columnName || !rule.dataField)) {
                return fail("Une règle DataTables doit indiquer le tableau, la colonne et le champ de données.", "A DataTables rule must specify the table, column and data field.");
            }
            if (rule.valueSource === "attribute" && !String(rule.attributeName || "").trim()) {
                return fail("Le nom de l'attribut à lire est vide.", "The attribute name to read is empty.");
            }
        }
        return { ok: true };
    }

    function moduleDefinition() {
        const valueSourceOptions = [
            { value: "text", label: { fr: "Texte affiché dans l'élément", en: "Text displayed in the element" } },
            { value: "value", label: { fr: "Valeur d'un champ de formulaire", en: "Form field value" } },
            { value: "attribute", label: { fr: "Attribut HTML", en: "HTML attribute" } }
        ];

        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Liens dynamiques", en: "Dynamic links" },
            description: {
                fr: "Rend des éléments de Koha cliquables et construit leur destination à partir d'une URL dynamique utilisant la valeur détectée sur la page.",
                en: "Makes Koha elements clickable and builds their destination from a dynamic URL using the value detected on the page."
            },
            category: { fr: "Interface / navigation", en: "Interface / navigation" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULTS),
            normalize: normalizeConfig,
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "general",
                    label: { fr: "Fonctionnement", en: "Behaviour" },
                    description: {
                        fr: "Une règle choisit un élément sur une page, récupère sa valeur puis remplace {value} dans le modèle d'URL.",
                        en: "A rule chooses an element on a page, reads its value, then replaces {value} in the URL template."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Module actif", en: "Module enabled" } },
                        { key: "observeDom", type: "boolean", advanced: true, label: { fr: "Retraiter les éléments ajoutés dynamiquement", en: "Process dynamically added elements" } },
                        { key: "observeDelay", type: "number", advanced: true, label: { fr: "Délai de retraitement (ms)", en: "Reprocessing delay (ms)" } }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Règles de liens dynamiques", en: "Dynamic link rules" },
                    description: {
                        fr: "Ajoute une règle, choisis l'élément directement dans Koha puis indique la structure de l'URL. Exemple : /cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\".",
                        en: "Add a rule, choose the element directly in Koha, then define the URL structure. Example: /cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Liens configurés", en: "Configured links" },
                            addLabel: { fr: "Ajouter un lien dynamique", en: "Add dynamic link" },
                            reorder: true,
                            newItem: newRule,
                            liveTitleKey: "label",
                            itemTitle: function (item, index) {
                                return String(item && (item.label || item.targetName) || "").trim() || "Règle " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de la règle", en: "Rule name" } },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Élément à rendre cliquable", en: "Element to make clickable" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                                    allowManual: true,
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        return index === null || !rootObject.rules[index] || rootObject.rules[index].engine !== "datatable-column";
                                    },
                                    pick: function (context) { return pickForRule(context, "target"); },
                                    onPick: applyPickerResult
                                },
                                {
                                    key: "targetName",
                                    type: "readonly",
                                    label: { fr: "Élément détecté", en: "Detected element" }
                                },
                                {
                                    key: "pagePath",
                                    type: "text",
                                    label: { fr: "Page Koha", en: "Koha page" },
                                    help: {
                                        fr: "Renseignée automatiquement lors du choix sur la page. Une URL complète n'est pas nécessaire.",
                                        en: "Filled automatically when choosing on the page. A full URL is not required."
                                    }
                                },
                                {
                                    key: "valueElementMode",
                                    type: "select",
                                    label: { fr: "Source de {value}", en: "{value} source" },
                                    options: [
                                        { value: "target", label: { fr: "Même élément que celui qui reçoit le lien", en: "Same element that receives the link" } },
                                        { value: "picked", label: { fr: "Un autre élément choisi sur la page", en: "Another element selected on the page" } }
                                    ],
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        return index === null || !rootObject.rules[index] || rootObject.rules[index].engine !== "datatable-column";
                                    },
                                    refreshOnChange: true
                                },
                                {
                                    key: "valueSelector",
                                    type: "elementPicker",
                                    label: { fr: "Élément qui fournit {value}", en: "Element supplying {value}" },
                                    pickLabel: { fr: "Choisir la source sur la page", en: "Choose source on page" },
                                    emptyLabel: { fr: "Aucune source choisie", en: "No source selected" },
                                    allowManual: true,
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        const rule = index !== null && rootObject.rules ? rootObject.rules[index] : null;
                                        return Boolean(rule && rule.engine !== "datatable-column" && rule.valueElementMode === "picked");
                                    },
                                    pick: function (context) { return pickForRule(context, "value"); },
                                    onPick: applyValuePickerResult
                                },
                                {
                                    key: "valueTargetName",
                                    type: "readonly",
                                    label: { fr: "Source détectée", en: "Detected source" },
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        const rule = index !== null && rootObject.rules ? rootObject.rules[index] : null;
                                        return Boolean(rule && rule.engine !== "datatable-column" && rule.valueElementMode === "picked");
                                    }
                                },
                                {
                                    key: "valuePairing",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Association cible / source", en: "Target / source pairing" },
                                    options: [
                                        { value: "auto", label: { fr: "Automatique : même ligne/carte puis même index", en: "Automatic: same row/card then same index" } },
                                        { value: "same-index", label: { fr: "Même position dans les listes", en: "Same position in the lists" } },
                                        { value: "first", label: { fr: "Toujours la première source trouvée", en: "Always use the first matching source" } }
                                    ],
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        const rule = index !== null && rootObject.rules ? rootObject.rules[index] : null;
                                        return Boolean(rule && rule.engine !== "datatable-column" && rule.valueElementMode === "picked");
                                    }
                                },
                                {
                                    key: "valueSource",
                                    type: "select",
                                    label: { fr: "Comment lire la valeur source", en: "How to read the source value" },
                                    options: valueSourceOptions,
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        return index === null || !rootObject.rules[index] || rootObject.rules[index].engine !== "datatable-column";
                                    },
                                    refreshOnChange: true,
                                    onChange: refreshRulePreview
                                },
                                {
                                    key: "attributeName",
                                    type: "text",
                                    label: { fr: "Nom de l'attribut", en: "Attribute name" },
                                    placeholder: { fr: "ex. data-id, href, title", en: "e.g. data-id, href, title" },
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        const rule = index !== null && rootObject.rules ? rootObject.rules[index] : null;
                                        return Boolean(rule && rule.engine !== "datatable-column" && rule.valueSource === "attribute");
                                    }
                                },
                                {
                                    key: "urlTemplate",
                                    type: "textarea",
                                    rows: 2,
                                    label: { fr: "Structure de l'URL", en: "URL template" },
                                    placeholder: { fr: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"", en: "/cgi-bin/koha/catalogue/search.pl?q=ccode:\"{value}\"" },
                                    help: {
                                        fr: "{value} est remplacé par la valeur lue dans la source choisie ci-dessus. {raw} insère la même valeur sans encodage URL.",
                                        en: "{value} is replaced by the value read from the source selected above. {raw} inserts the same value without URL encoding."
                                    },
                                    refreshOnChange: true,
                                    onChange: refreshRulePreview
                                },
                                {
                                    key: "exampleValue",
                                    type: "text",
                                    label: { fr: "Valeur d'exemple", en: "Example value" },
                                    help: {
                                        fr: "Détectée automatiquement lors du choix ; modifiable pour tester l'URL.",
                                        en: "Detected automatically when choosing; editable to test the URL."
                                    },
                                    refreshOnChange: true,
                                    onChange: refreshRulePreview
                                },
                                {
                                    key: "previewUrl",
                                    type: "readonly",
                                    label: { fr: "Aperçu de l'URL produite", en: "Generated URL preview" }
                                },
                                {
                                    key: "linkMode",
                                    type: "select",
                                    label: { fr: "Comportement", en: "Behaviour" },
                                    options: [
                                        { value: "element", label: { fr: "Rendre l'élément lui-même cliquable", en: "Make the element itself clickable" } },
                                        { value: "after", label: { fr: "Ajouter un lien à côté", en: "Add a link next to it" } }
                                    ],
                                    refreshOnChange: true
                                },
                                {
                                    key: "linkTextTemplate",
                                    type: "text",
                                    label: { fr: "Texte du lien ajouté", en: "Added link text" },
                                    help: { fr: "Utilisé seulement avec « Ajouter un lien à côté ». {value} est accepté.", en: "Used only with “Add a link next to it”. {value} is supported." },
                                    when: function (rootObject, fieldPath) {
                                        const index = getRuleIndex(fieldPath);
                                        const rule = index !== null && rootObject.rules ? rootObject.rules[index] : null;
                                        return Boolean(rule && rule.linkMode === "after");
                                    }
                                },
                                { key: "openInNewTab", type: "boolean", label: { fr: "Ouvrir dans un nouvel onglet", en: "Open in a new tab" } },

                                { key: "encodeValue", type: "boolean", advanced: true, label: { fr: "Encoder {value} pour l'URL", en: "URL-encode {value}" }, onChange: refreshRulePreview, refreshOnChange: true },
                                { key: "trim", type: "boolean", advanced: true, label: { fr: "Supprimer les espaces au début et à la fin", en: "Trim leading and trailing whitespace" } },
                                { key: "extractRegex", type: "text", advanced: true, label: { fr: "Extraire la valeur avec une expression régulière", en: "Extract value with a regular expression" } },
                                { key: "regexFlags", type: "text", advanced: true, label: { fr: "Options RegExp", en: "RegExp flags" } },
                                { key: "regexGroup", type: "number", advanced: true, label: { fr: "Groupe RegExp utilisé", en: "RegExp group to use" } },
                                {
                                    key: "presentation",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Présentation spéciale", en: "Special presentation" },
                                    options: [
                                        { value: "element", label: { fr: "Présentation normale", en: "Normal presentation" } },
                                        { value: "legacy-ccode-block", label: { fr: "Bloc historique du code collection", en: "Historical collection-code block" } }
                                    ],
                                    refreshOnChange: true
                                },
                                { key: "legacyPrefixFr", type: "text", advanced: true, label: { fr: "Préfixe historique français", en: "Historical French prefix" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].presentation === "legacy-ccode-block"); } },
                                { key: "legacyPrefixEn", type: "text", advanced: true, label: { fr: "Préfixe historique anglais", en: "Historical English prefix" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].presentation === "legacy-ccode-block"); } },
                                { key: "legacySeparator", type: "text", advanced: true, label: { fr: "Séparateur historique", en: "Historical separator" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].presentation === "legacy-ccode-block"); } },
                                {
                                    key: "engine",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Moteur de ciblage", en: "Targeting engine" },
                                    options: [
                                        { value: "dom", label: { fr: "Élément de page", en: "Page element" } },
                                        { value: "datatable-column", label: { fr: "Colonne DataTables Koha", en: "Koha DataTables column" } }
                                    ],
                                    refreshOnChange: true
                                },
                                { key: "tableSelector", type: "text", advanced: true, label: { fr: "Tableau DataTables", en: "DataTables table" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].engine === "datatable-column"); } },
                                { key: "columnName", type: "text", advanced: true, label: { fr: "Nom technique de colonne", en: "Technical column name" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].engine === "datatable-column"); } },
                                { key: "dataField", type: "text", advanced: true, label: { fr: "Champ de données utilisé comme valeur", en: "Data field used as value" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].engine === "datatable-column"); } },
                                { key: "selector", type: "text", readOnly: true, advanced: true, label: { fr: "Sélecteur technique", en: "Technical selector" }, when: function (rootObject, fieldPath) { const i = getRuleIndex(fieldPath); return Boolean(i !== null && rootObject.rules[i] && rootObject.rules[i].engine === "datatable-column"); } },
                                { key: "matchCount", type: "readonly", advanced: true, label: { fr: "Correspondances lors de la sélection", en: "Matches when selected" } },
                                { key: "id", type: "text", readOnly: true, advanced: true, label: { fr: "Identifiant technique", en: "Technical identifier" } }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main) {
                if (!main) return;
                const section = main.querySelector('[data-pmk-section-id="rules"]');
                if (section) window.setTimeout(function () { section.scrollIntoView({ block: "start", behavior: "smooth" }); }, 0);
            }
        };
    }

    function safeQueryAll(selector) {
        if (!selector) return [];
        try { return Array.from(document.querySelectorAll(selector)); } catch (_) { return []; }
    }

    function storeOriginalAnchor(anchor) {
        if (!anchor || anchor.getAttribute(MARK_ATTR) === "1") return;
        anchor.dataset.pmk021OriginalTitle=anchor.hasAttribute('title')?anchor.title:'__PMK_NONE__';
        anchor.dataset.pmk021OriginalDescription=anchor.getAttribute('aria-description')??'__PMK_NONE__';
        anchor.setAttribute(ORIGINAL_HREF_ATTR, anchor.hasAttribute("href") ? anchor.getAttribute("href") : "__PMK_NONE__");
        anchor.setAttribute(ORIGINAL_TARGET_ATTR, anchor.hasAttribute("target") ? anchor.getAttribute("target") : "__PMK_NONE__");
        anchor.setAttribute(ORIGINAL_REL_ATTR, anchor.hasAttribute("rel") ? anchor.getAttribute("rel") : "__PMK_NONE__");
    }

    function configureAnchor(anchor, rule, href) {
        if (!anchor || !href) return false;
        anchor.setAttribute(MARK_ATTR, "1");
        anchor.setAttribute(RULE_ATTR, rule.id || "");
        anchor.setAttribute("href", href);
        window.PMKWorkbench?.describeLink(anchor);
        if (rule.openInNewTab === true) {
            anchor.setAttribute("target", "_blank");
            anchor.setAttribute("rel", "noopener noreferrer");
        } else {
            anchor.removeAttribute("target");
            anchor.removeAttribute("rel");
        }
        return true;
    }

    function restoreOwnChanges() {
        document.querySelectorAll('[data-pmk021-legacy-block="1"]').forEach(function (block) { block.remove(); });
        document.querySelectorAll('[data-pmk021-legacy-hidden="1"]').forEach(function (element) {
            element.hidden = element.getAttribute("data-pmk021-original-hidden") === "1";
            element.removeAttribute("data-pmk021-legacy-hidden");
            element.removeAttribute("data-pmk021-original-hidden");
        });
        document.querySelectorAll('a[' + MARK_ATTR + '="1"]').forEach(function (anchor) {
            if (anchor.hasAttribute(ORIGINAL_HREF_ATTR)) {
                for(const [key,attribute]of [['pmk021OriginalTitle','title'],['pmk021OriginalDescription','aria-description']]){const original=anchor.dataset[key];if(original==='__PMK_NONE__')anchor.removeAttribute(attribute);else if(original!==undefined)anchor.setAttribute(attribute,original);delete anchor.dataset[key];}
                delete anchor.dataset.pmkLinkTitle;
                const href = anchor.getAttribute(ORIGINAL_HREF_ATTR);
                const target = anchor.getAttribute(ORIGINAL_TARGET_ATTR);
                const rel = anchor.getAttribute(ORIGINAL_REL_ATTR);
                if (href === "__PMK_NONE__") anchor.removeAttribute("href"); else anchor.setAttribute("href", href);
                if (target === "__PMK_NONE__") anchor.removeAttribute("target"); else anchor.setAttribute("target", target);
                if (rel === "__PMK_NONE__") anchor.removeAttribute("rel"); else anchor.setAttribute("rel", rel);
                anchor.removeAttribute(MARK_ATTR);
                anchor.removeAttribute(RULE_ATTR);
                anchor.removeAttribute(ORIGINAL_HREF_ATTR);
                anchor.removeAttribute(ORIGINAL_TARGET_ATTR);
                anchor.removeAttribute(ORIGINAL_REL_ATTR);
                return;
            }
            if (anchor.getAttribute("data-pmk021-wrapper") === "1") {
                const parent = anchor.parentNode;
                if (!parent) return;
                while (anchor.firstChild) parent.insertBefore(anchor.firstChild, anchor);
                anchor.remove();
                return;
            }
            if (anchor.getAttribute("data-pmk021-added") === "1") anchor.remove();
        });
    }

    function linkText(rule, value) {
        const template = String(rule.linkTextTemplate || "").trim() || (detectLanguage() === "fr" ? "Ouvrir" : "Open");
        return template.replace(/\{value\}/g, String(value)).replace(/\{raw\}/g, String(value));
    }

    function applyLinkToElement(element, rule, value) {
        if (!element || !value) return;
        const href = buildUrl(rule, value);
        if (!href) return;

        if (rule.linkMode === "after") {
            const anchor = document.createElement("a");
            anchor.setAttribute("data-pmk021-added", "1");
            anchor.className = "pmk021-dynamic-link";
            anchor.textContent = linkText(rule, value);
            if (!configureAnchor(anchor, rule, href)) return;
            anchor.style.marginLeft = ".35em";
            element.insertAdjacentElement("afterend", anchor);
            return;
        }

        if (element.tagName === "A") {
            storeOriginalAnchor(element);
            configureAnchor(element, rule, href);
            return;
        }

        if (element.closest('a[' + MARK_ATTR + '="1"]')) return;
        if (element.querySelector("a, button, input, select, textarea")) return;
        const anchor = document.createElement("a");
        anchor.setAttribute("data-pmk021-wrapper", "1");
        if (!configureAnchor(anchor, rule, href)) return;
        while (element.firstChild) anchor.appendChild(element.firstChild);
        element.appendChild(anchor);
    }

    function applyLegacyCollectionBlock(rule) {
        if (normalizePath(window.location.pathname) !== "/cgi-bin/koha/catalogue/search.pl") return;
        document.querySelectorAll("span.item-itype-desc").forEach(function (itemTypeDesc) {
            const parent = itemTypeDesc.parentElement;
            if (!parent) return;
            let candidates = [];
            try { candidates = Array.from(parent.querySelectorAll(rule.selector)); } catch (_) { return; }
            const values = candidates.map(function (element) {
                return { element: element, value: readDomValue(element, rule) };
            }).filter(function (entry) { return Boolean(entry.value); });
            if (!values.length) return;

            const block = document.createElement("div");
            block.className = "ccode2 pmk021-dynamic-link-block";
            block.setAttribute("data-pmk021-legacy-block", "1");
            const prefix = detectLanguage() === "fr" ? String(rule.legacyPrefixFr || "") : String(rule.legacyPrefixEn || "");
            if (prefix) block.appendChild(document.createTextNode(prefix + (/\s$/.test(prefix) ? "" : " ")));
            const separator = String(rule.legacySeparator == null ? ", " : rule.legacySeparator);

            values.forEach(function (entry, index) {
                const href = buildUrl(rule, entry.value);
                if (!href) return;
                const anchor = document.createElement("a");
                anchor.className = "ccode-link pmk021-dynamic-link";
                anchor.textContent = entry.value;
                configureAnchor(anchor, rule, href);
                block.appendChild(anchor);
                if (index < values.length - 1) block.appendChild(document.createTextNode(separator));
                if (!entry.element.hasAttribute("data-pmk021-legacy-hidden")) {
                    entry.element.setAttribute("data-pmk021-original-hidden", entry.element.hidden ? "1" : "0");
                    entry.element.setAttribute("data-pmk021-legacy-hidden", "1");
                    entry.element.hidden = true;
                }
            });
            itemTypeDesc.insertAdjacentElement("afterend", block);
        });
    }

    function resolveValueElement(target, rule, targetIndex, targets, sources) {
        if (!target) return null;
        if ((rule.valueElementMode || "target") !== "picked") return target;
        const list = Array.isArray(sources) ? sources : safeQueryAll(rule.valueSelector);
        if (!list.length) return null;
        if (rule.valuePairing === "first" || list.length === 1) return list[0];
        if (rule.valuePairing === "same-index") return list[targetIndex] || null;

        const containerSelectors = [
            "tr", "li", "article", ".result", ".search-result", ".page-section", ".card", ".panel", ".accordion-item", "tbody"
        ];
        for (const containerSelector of containerSelectors) {
            const container = target.closest && target.closest(containerSelector);
            if (!container) continue;
            let local = [];
            try { local = Array.from(container.querySelectorAll(rule.valueSelector)); } catch (_) { local = []; }
            if (local.length === 1) return local[0];
            if (local.length > 1) {
                const targetPeers = targets.filter(function (candidate) { return container.contains(candidate); });
                const localIndex = targetPeers.indexOf(target);
                if (localIndex >= 0 && local[localIndex]) return local[localIndex];
            }
        }
        if (list.length === targets.length) return list[targetIndex] || null;
        return list[0];
    }

    function applyDomRule(rule) {
        if (rule.presentation === "legacy-ccode-block") {
            applyLegacyCollectionBlock(rule);
            return;
        }
        const targets = safeQueryAll(rule.selector);
        const sources = rule.valueElementMode === "picked" ? safeQueryAll(rule.valueSelector) : [];
        targets.forEach(function (element, index) {
            const valueElement = resolveValueElement(element, rule, index, targets, sources);
            const value = readDomValue(valueElement, rule);
            if (!value) return;
            applyLinkToElement(element, rule, value);
        });
    }

    function getDataTableApi(table) {
        if (!table || !window.jQuery || !window.jQuery.fn || !window.jQuery.fn.dataTable) return null;
        if (typeof window.jQuery.fn.dataTable.isDataTable !== "function") return null;
        if (!window.jQuery.fn.dataTable.isDataTable(table)) return null;
        try { return window.jQuery(table).DataTable(); } catch (_) { return null; }
    }

    function resolveDataTableColumn(api, table, columnName) {
        if (!api || !table || !columnName) return null;
        const header = table.querySelector('thead tr:first-child th[data-colname="' + String(columnName).replace(/"/g, "\\\"") + '"]');
        if (!header) return null;
        try {
            const index = api.column(header).index();
            return Number.isInteger(index) ? index : null;
        } catch (_) {
            const headers = Array.from(table.querySelectorAll("thead tr:first-child th"));
            const index = headers.indexOf(header);
            return index >= 0 ? index : null;
        }
    }

    function applyDataTableRule(rule) {
        const table = document.querySelector(rule.tableSelector);
        if (!table) return;
        const api = getDataTableApi(table);
        if (!api) return;
        const columnIndex = resolveDataTableColumn(api, table, rule.columnName);
        if (columnIndex === null) return;
        try {
            api.rows({ page: "current" }).every(function () {
                const rowData = this.data();
                if (!rowData || rowData[rule.dataField] == null) return;
                const value = extractValue(rowData[rule.dataField], rule);
                if (!value) return;
                let cell = null;
                try { cell = api.cell(this.index(), columnIndex).node(); } catch (_) { cell = null; }
                if (!cell || !cell.textContent.trim()) return;
                applyLinkToElement(cell, rule, value);
            });
        } catch (_) {}
    }

    function applyAll(config) {
        restoreOwnChanges();
        const normalized = normalizeConfig(config);
        currentConfig = normalized;
        if (normalized.enabled === false) return;
        normalized.rules.forEach(function (rule) {
            if (!ruleAppliesHere(rule)) return;
            if (rule.engine === "datatable-column") applyDataTableRule(rule);
            else applyDomRule(rule);
        });
    }

    function stopObserver() {
        if (observer) observer.disconnect();
        observer = null;
        if (observerTimer) window.clearTimeout(observerTimer);
        observerTimer = 0;
    }

    function startObserver(config) {
        stopObserver();
        if (!config || config.enabled === false || config.observeDom === false || !document.body) return;
        const delay = Math.max(25, Math.min(2000, Number(config.observeDelay) || 100));
        observer = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                return Array.from(mutation.addedNodes || []).some(function (node) {
                    return node && node.nodeType === 1 && !(node.matches && node.matches('a[' + MARK_ATTR + '="1"]'));
                });
            });
            if (!relevant) return;
            window.clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () { applyAll(currentConfig); }, delay);
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const activeRule = currentConfig && currentConfig.rules && currentConfig.rules.find(ruleAppliesHere);
        if (!activeRule) return;
        const anchor = document.querySelector("h1") || document.querySelector("h2") || document.querySelector("#breadcrumbs");
        if (!anchor) return;
        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: anchor,
            position: "after",
            contextKey: "dynamic-links-" + normalizePath(window.location.pathname),
            context: { sectionId: "rules", pagePath: window.location.pathname }
        });
    }

    function refresh(config) {
        const normalized = normalizeConfig(config || DEFAULTS);
        currentConfig = normalized;
        applyAll(normalized);
        startObserver(normalized);
        mountContextAccess();
    }

    async function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return clone(DEFAULTS);
        try { return await window.PMKConfig.getConfig(MODULE_ID); } catch (_) { return clone(DEFAULTS); }
    }

    async function startWithCore() {
        if (!window.PMKConfig) return;
        registerCommonPickerAdapter();
        if (!coreRegistered && typeof window.PMKConfig.registerModule === "function") {
            window.PMKConfig.registerModule(moduleDefinition());
            coreRegistered = true;
        }
        const config = await loadConfig();
        refresh(config);
        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (nextConfig) { refresh(nextConfig); });
        }
    }

    function startWithoutCore() {
        refresh(DEFAULTS);
    }

    window.PMK021DynamicLinks = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULTS),
        moduleDefinition: moduleDefinition,
        pickElement: function () { return pickForRule({}, "target"); },
        reusableSelector: reusableSelector,
        buildUrl: buildUrl,
        refresh: refresh,
        apply: applyAll,
        restore: restoreOwnChanges
    };

    function boot() {
        if (window.PMKConfig) startWithCore();
        else {
            startWithoutCore();
            window.addEventListener("pmk:config-ready", function () { startWithCore(); }, { once: true });
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
    else boot();
})();

;window.PMKNonPlugin.loaded.push("021-code-collection-search-results.js");
} catch (error) { window.PMKNonPlugin.errors.push("021-code-collection-search-results.js: "+error.message); console.error("[PMK] 021-code-collection-search-results.js",error); };
try {
/*
 Nom du fichier: 022-popup-deja-emprunte-circulation.js
 Dépendances: 000-pmk-config-firestore.js 0.4.12+ recommandé
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha
 Description: Runtime du module transversal "Remplacement de textes".
              Permet de cibler visuellement des éléments Koha et de remplacer
              des textes sans modifier leur HTML ni leurs gestionnaires d'événements.
              Le comportement historique du script 022 est conservé par défaut.
*/

(function () {
    "use strict";

    if (window.__PMK022TextReplacementLoaded) return;
    window.__PMK022TextReplacementLoaded = true;

    const MODULE_ID = "text-replacement";
    const MODULE_VERSION = "0.1.1";
    const PICKER_STYLE_ID = "pmk022-picker-style";
    const PENDING_PICK_KEY = "pmk022-pending-pick-v1";
    const ORIGINALS = new WeakMap();

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 120,
        rules: [
            {
                id: "legacy-already-borrowed-title",
                enabled: true,
                label: "Titre déjà emprunté",
                pages: "/cgi-bin/koha/circ/circulation.pl",
                selector: "#circ_needsconfirmation li.needsconfirm.previssue",
                targetName: "Avertissement « titre déjà emprunté »",
                searchText: "L'adhérent a déjà emprunté ce titre",
                replaceText: "Ce titre est déjà présent dans l'historique de prêt de cet adhérent",
                matchMode: "contains",
                caseSensitive: true,
                replaceAll: true
            }
        ]
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function merge(target, source) {
        if (!source || typeof source !== "object") return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) target[key] = deepClone(value);
            else if (value && typeof value === "object") {
                if (!target[key] || typeof target[key] !== "object" || Array.isArray(target[key])) {
                    target[key] = {};
                }
                merge(target[key], value);
            } else {
                target[key] = value;
            }
        });
        return target;
    }

    function normalizeConfig(config) {
        const result = merge(deepClone(DEFAULTS), config || {});
        if (!Array.isArray(result.rules)) result.rules = deepClone(DEFAULTS.rules);
        result.rules = result.rules.map(function (rule, index) {
            const normalizedRule = merge({
                id: "rule-" + (index + 1),
                enabled: true,
                label: "",
                pages: "*",
                selector: "",
                targetName: "",
                searchText: "",
                replaceText: "",
                matchMode: "contains",
                caseSensitive: true,
                replaceAll: true
            }, rule || {});

            // Migration 0.1.1 : les anciens champs de "contexte de sécurité"
            // sont définitivement abandonnés. Ils pouvaient rester dans Firestore
            // après disparition de l'UI et filtrer silencieusement de nouvelles règles.
            delete normalizedRule.contextText;
            delete normalizedRule.contextSelector;
            delete normalizedRule.contextMode;

            return normalizedRule;
        });
        return result;
    }

    function splitPages(value) {
        if (Array.isArray(value)) return value.map(String);
        return String(value || "")
            .split(/[\n,;]+/)
            .map(function (item) { return item.trim(); })
            .filter(Boolean);
    }

    function normalizePath(value) {
        let path = String(value || "").trim();
        if (!path) return "";
        try {
            if (/^https?:\/\//i.test(path)) path = new URL(path).pathname;
        } catch (_) {}
        if (path === "*" || path.toLowerCase() === "all") return "*";
        if (!path.startsWith("/")) path = "/" + path;
        if (!path.startsWith("/cgi-bin/koha/")) path = "/cgi-bin/koha" + path;
        return path.replace(/\/+/g, "/");
    }

    function pageMatches(rule) {
        const current = window.location.pathname;
        const pages = splitPages(rule.pages);
        if (!pages.length) return false;
        return pages.some(function (page) {
            const normalized = normalizePath(page);
            return normalized === "*" || normalized === current;
        });
    }

    function safeQueryAll(selector, root) {
        const scope = root || document;
        const value = String(selector || "").trim();
        if (!value) return [];
        try {
            return Array.prototype.slice.call(scope.querySelectorAll(value));
        } catch (_) {
            return [];
        }
    }

    function elementText(element) {
        return String(element && element.textContent || "").replace(/\s+/g, " ").trim();
    }

    function textContains(haystack, needle, caseSensitive) {
        const a = String(haystack || "");
        const b = String(needle || "");
        if (!b) return true;
        return caseSensitive === false
            ? a.toLocaleLowerCase().includes(b.toLocaleLowerCase())
            : a.includes(b);
    }

    function escapeRegExp(value) {
        return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function rememberOriginal(node) {
        if (!ORIGINALS.has(node)) ORIGINALS.set(node, node.nodeValue);
    }

    function replacementRegex(rule) {
        const search = String(rule.searchText || "");
        if (!search) return null;

        let source;
        if (String(rule.matchMode || "contains") === "exact") {
            source = "^" + escapeRegExp(search) + "$";
        } else {
            source = escapeRegExp(search);
        }

        let flags = rule.caseSensitive === false ? "i" : "";
        if (rule.replaceAll !== false && String(rule.matchMode || "contains") !== "exact") flags += "g";

        try {
            return new RegExp(source, flags);
        } catch (_) {
            return null;
        }
    }

    function replaceInTextNode(node, rule) {
        if (!node || typeof node.nodeValue !== "string") return false;

        const before = node.nodeValue;
        const search = String(rule.searchText || "");
        if (!search) return false;

        const regex = replacementRegex(rule);
        if (!regex) return false;

        let after = before;

        if (String(rule.matchMode || "contains") === "exact") {
            const lhs = rule.caseSensitive === false ? before.toLocaleLowerCase() : before;
            const rhs = rule.caseSensitive === false ? search.toLocaleLowerCase() : search;
            if (lhs !== rhs) return false;
            after = String(rule.replaceText || "");
        } else {
            if (!textContains(before, search, rule.caseSensitive)) return false;
            after = before.replace(regex, String(rule.replaceText || ""));
        }

        if (after === before) return false;
        rememberOriginal(node);
        node.nodeValue = after;
        return true;
    }

    function processElement(element, rule) {
        if (!element) return false;

        const walker = document.createTreeWalker(
            element,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode: function (node) {
                    if (!node.parentElement) return NodeFilter.FILTER_REJECT;
                    if (node.parentElement.closest("script, style, textarea, input, select, option")) {
                        return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                }
            }
        );

        let changed = false;
        let node;
        while ((node = walker.nextNode())) {
            if (replaceInTextNode(node, rule)) changed = true;
        }

        return changed;
    }

    function applyRule(rule) {
        if (!rule || rule.enabled === false || !pageMatches(rule)) return false;

        const selector = String(rule.selector || "").trim();
        if (!selector) return false;

        const targets = selector === "body"
            ? [document.body].filter(Boolean)
            : safeQueryAll(selector, document);

        if (!targets.length) return false;

        let changed = false;
        targets.forEach(function (target) {
            if (processElement(target, rule)) changed = true;
        });
        return changed;
    }

    function applyAll() {
        if (!currentConfig || currentConfig.enabled === false) return;
        (currentConfig.rules || []).forEach(applyRule);
    }

    function stopObserver() {
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        if (observerTimer) {
            clearTimeout(observerTimer);
            observerTimer = 0;
        }
    }

    function startObserver() {
        stopObserver();
        if (!currentConfig || currentConfig.enabled === false || currentConfig.observeDom === false) return;

        observer = new MutationObserver(function () {
            if (observerTimer) clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                observerTimer = 0;
                applyAll();
            }, Math.max(25, Number(currentConfig.observeDelay) || 120));
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            characterData: true
        });
    }

    function refresh(config) {
        currentConfig = normalizeConfig(config || DEFAULTS);
        applyAll();
        startObserver();
        return currentConfig;
    }

    function getCssPath(element) {
        if (!(element instanceof Element)) return "";
        if (element.id) return "#" + CSS.escape(element.id);

        const parts = [];
        let current = element;

        while (current && current.nodeType === 1 && current !== document.body && parts.length < 7) {
            let part = current.tagName.toLowerCase();

            const stableClasses = Array.prototype.slice.call(current.classList || [])
                .filter(function (name) {
                    return name &&
                        !/^active$|^show$|^open$|^selected$|^focus$|^hover$/i.test(name) &&
                        !/^pmk/.test(name);
                })
                .slice(0, 2);

            if (stableClasses.length) {
                part += stableClasses.map(function (name) { return "." + CSS.escape(name); }).join("");
            }

            const parent = current.parentElement;
            if (parent) {
                const siblings = Array.prototype.filter.call(parent.children, function (child) {
                    return child.tagName === current.tagName;
                });
                if (siblings.length > 1 && !stableClasses.length) {
                    part += ":nth-of-type(" + (siblings.indexOf(current) + 1) + ")";
                }
            }

            parts.unshift(part);
            const candidate = parts.join(" > ");
            try {
                if (document.querySelectorAll(candidate).length === 1) return candidate;
            } catch (_) {}

            current = current.parentElement;
        }

        return parts.join(" > ");
    }

    function ensurePickerStyle() {
        if (document.getElementById(PICKER_STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = PICKER_STYLE_ID;
        style.textContent = `
            .pmk022-pick-hover {
                outline: 3px solid #0d6efd !important;
                outline-offset: 2px !important;
                cursor: crosshair !important;
            }
            #pmk022-picker-banner {
                position: fixed;
                z-index: 2147483647;
                left: 50%;
                top: 12px;
                transform: translateX(-50%);
                max-width: min(760px, calc(100vw - 24px));
                background: #fff;
                border: 1px solid #adb5bd;
                border-radius: .35rem;
                box-shadow: 0 .35rem 1rem rgba(0,0,0,.22);
                padding: .55rem .75rem;
                font-size: .9rem;
                color: #212529;
            }
        `;
        document.head.appendChild(style);
    }

    function pickElementOnCurrentPage() {
        ensurePickerStyle();

        return new Promise(function (resolve, reject) {
            let hovered = null;
            let done = false;

            const banner = document.createElement("div");
            banner.id = "pmk022-picker-banner";
            banner.innerHTML = '<strong>Sélection PimpMyKoha</strong> — clique sur le texte à modifier. Échap pour annuler.';
            document.body.appendChild(banner);

            function cleanup() {
                if (done) return;
                done = true;
                if (hovered) hovered.classList.remove("pmk022-pick-hover");
                document.removeEventListener("mouseover", onOver, true);
                document.removeEventListener("mouseout", onOut, true);
                document.removeEventListener("click", onClick, true);
                document.removeEventListener("keydown", onKey, true);
                banner.remove();
            }

            function allowedTarget(target) {
                if (!(target instanceof Element)) return null;
                if (target.closest("#pmk022-picker-banner, #pmk-config-overlay, .pmk-config-overlay")) return null;
                return target;
            }

            function onOver(event) {
                const target = allowedTarget(event.target);
                if (!target) return;
                if (hovered && hovered !== target) hovered.classList.remove("pmk022-pick-hover");
                hovered = target;
                hovered.classList.add("pmk022-pick-hover");
            }

            function onOut(event) {
                if (hovered && event.target === hovered) {
                    hovered.classList.remove("pmk022-pick-hover");
                    hovered = null;
                }
            }

            function onClick(event) {
                const target = allowedTarget(event.target);
                if (!target) return;

                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();

                const selector = getCssPath(target);
                const targetName = elementText(target).slice(0, 160) ||
                    target.getAttribute("aria-label") ||
                    target.getAttribute("title") ||
                    target.tagName.toLowerCase();

                cleanup();

                if (!selector) {
                    reject(new Error("picker_selector_unavailable"));
                    return;
                }

                resolve({
                    value: selector,
                    selector: selector,
                    targetName: targetName,
                    text: elementText(target)
                });
            }

            function onKey(event) {
                if (event.key !== "Escape") return;
                event.preventDefault();
                cleanup();
                reject(new Error("picker_cancelled"));
            }

            document.addEventListener("mouseover", onOver, true);
            document.addEventListener("mouseout", onOut, true);
            document.addEventListener("click", onClick, true);
            document.addEventListener("keydown", onKey, true);
        });
    }

    function resolveRuleIndexFromFieldPath(fieldPath) {
        if (!Array.isArray(fieldPath)) return -1;
        const pos = fieldPath.indexOf("rules");
        if (pos === -1) return -1;
        const index = Number(fieldPath[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function firstConcretePage(rule) {
        const pages = splitPages(rule && rule.pages);
        for (let i = 0; i < pages.length; i += 1) {
            const path = normalizePath(pages[i]);
            if (path && path !== "*") return path;
        }
        return "";
    }

    function pickForConfig(context) {
        const rootObject = context && context.rootObject ? context.rootObject : null;
        const fieldPath = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const index = resolveRuleIndexFromFieldPath(fieldPath);
        const rule = rootObject && Array.isArray(rootObject.rules) && index >= 0
            ? rootObject.rules[index]
            : null;
        const wantedPage = firstConcretePage(rule);

        if (wantedPage && wantedPage !== window.location.pathname) {
            const pending = {
                moduleId: MODULE_ID,
                ruleIndex: index,
                page: wantedPage,
                draft: deepClone(rootObject || DEFAULTS),
                startedAt: Date.now()
            };
            try {
                sessionStorage.setItem(PENDING_PICK_KEY, JSON.stringify(pending));
            } catch (_) {}

            window.location.href = window.location.origin + wantedPage;
            return new Promise(function () {});
        }

        /*
         * Si le picker est lancé depuis l'administration PMK sur la page
         * courante, on masque temporairement l'overlay sans appeler
         * PMKConfig.closeAdmin(). Ainsi le brouillon et adminState restent
         * intacts pendant que l'utilisateur clique dans la page Koha.
         */
        const overlay = document.getElementById("pmk-config-overlay");
        const overlayWasOpen = Boolean(overlay && overlay.classList.contains("pmk-open"));
        const bodyWasLocked = document.body.classList.contains("pmk-config-open");

        if (overlayWasOpen) overlay.classList.remove("pmk-open");
        if (bodyWasLocked) document.body.classList.remove("pmk-config-open");

        function restoreAdminOverlay() {
            if (overlayWasOpen && overlay) overlay.classList.add("pmk-open");
            if (bodyWasLocked) document.body.classList.add("pmk-config-open");
        }

        return pickElementOnCurrentPage().then(function (result) {
            restoreAdminOverlay();
            return result;
        }).catch(function (error) {
            restoreAdminOverlay();
            throw error;
        });
    }

    async function resumePendingPick() {
        let pending = null;
        try {
            const raw = sessionStorage.getItem(PENDING_PICK_KEY);
            if (raw) pending = JSON.parse(raw);
        } catch (_) {}

        if (!pending || pending.moduleId !== MODULE_ID) return false;

        if (Date.now() - Number(pending.startedAt || 0) > 15 * 60 * 1000) {
            try { sessionStorage.removeItem(PENDING_PICK_KEY); } catch (_) {}
            return false;
        }

        if (normalizePath(pending.page) !== window.location.pathname) return false;

        try { sessionStorage.removeItem(PENDING_PICK_KEY); } catch (_) {}

        window.setTimeout(async function () {
            try {
                const picked = await pickElementOnCurrentPage();
                const draft = normalizeConfig(pending.draft || DEFAULTS);
                const index = Number(pending.ruleIndex);

                if (!Array.isArray(draft.rules) || !draft.rules[index]) return;

                const rule = draft.rules[index];
                rule.selector = String(picked.value || picked.selector || "").trim();
                rule.targetName = picked.targetName || "";
                if (!String(rule.label || "").trim()) rule.label = picked.targetName || ("Règle " + (index + 1));

                // Quand on sélectionne un élément, on préremplit le texte recherché
                // avec son contenu si le champ est encore vide.
                if (!String(rule.searchText || "").trim() && picked.text) {
                    rule.searchText = String(picked.text).trim();
                }

                if (window.PMKConfig && typeof window.PMKConfig.saveConfig === "function") {
                    await window.PMKConfig.saveConfig(MODULE_ID, draft);
                    refresh(draft);

                    if (typeof window.PMKConfig.openAdmin === "function") {
                        await window.PMKConfig.openAdmin(MODULE_ID, {
                            ruleIndex: index,
                            resumedPicker: true
                        });
                    }
                } else {
                    // Repli local si le socle de configuration n'est pas disponible.
                    refresh(draft);
                }
            } catch (error) {
                if (!error || error.message !== "picker_cancelled") {
                    // fail-safe : aucune modification si la sélection échoue
                }
            }
        }, 250);

        return true;
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (window.location.pathname !== "/cgi-bin/koha/circ/circulation.pl") return;

        const anchor =
            document.querySelector("#circ_circulation_issue") ||
            document.querySelector("main h1") ||
            document.querySelector("h1");

        if (!anchor) return;

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: anchor,
            contextKey: "circulation-text-replacement",
            title: {
                fr: "Configurer les remplacements de textes",
                en: "Configure text replacements"
            }
        });
    }

    function registerRuntimeModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        // La définition complète se trouve dans 000-pmk-config-firestore.js.
        // Ici on n'écrase rien si elle y est déjà enregistrée.
        return true;
    }

    async function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return deepClone(DEFAULTS);
        }

        try {
            const value = await window.PMKConfig.getConfig(MODULE_ID);
            return value || deepClone(DEFAULTS);
        } catch (_) {
            return deepClone(DEFAULTS);
        }
    }

    async function init() {
        registerRuntimeModule();

        const cfg = await loadConfig();
        refresh(cfg);

        if (window.PMKConfig && typeof window.PMKConfig.onConfigChanged === "function") {
            window.PMKConfig.onConfigChanged(MODULE_ID, function (nextConfig) {
                refresh(nextConfig);
            });
        }

        mountContextAccess();
        resumePendingPick();
    }

    window.PMK022TextReplacement = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        apply: applyAll,
        pickElement: pickElementOnCurrentPage,
        pickForConfig: pickForConfig,
        resumePendingPick: resumePendingPick
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("022-popup-deja-emprunte-circulation.js");
} catch (error) { window.PMKNonPlugin.errors.push("022-popup-deja-emprunte-circulation.js: "+error.message); console.error("[PMK] 022-popup-deja-emprunte-circulation.js",error); };
try {
(async function(){
 const cfg=await PMKLegacyOptions.ready,options=cfg.concern;
 if(cfg.enabled===false||!options.enabled||!location.pathname.endsWith('/detail.pl'))return;
 const move=()=>{const source=document.querySelector(options.source),target=document.querySelector(options.after);if(!source||!target||source===target)return;source.textContent=options.label;source.classList.add('btn','btn-default');target.after(source);};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',move,{once:true});else move();
})().catch(console.error);

;window.PMKNonPlugin.loaded.push("023-deplacer-bouton-signaler-probleme.js");
} catch (error) { window.PMKNonPlugin.errors.push("023-deplacer-bouton-signaler-probleme.js: "+error.message); console.error("[PMK] 023-deplacer-bouton-signaler-probleme.js",error); };
try {
/*
 Nom du fichier: 025-deplacer-grille-technique.js
 Dépendances: 000-pmk-config-firestore.js 0.4.41+ recommandé
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha
 Description:
 - moteur générique de placement d'éléments Koha avec picker visuel ;
 - reprend les comportements historiques du 025 ;
 - absorbe les placements de couvertures des anciens 054 / 090 / 096 / 121 ;
 - gère les images 856 comme couverture de secours sans concurrencer
   les couvertures valides fournies par Koha / Electre / autres fournisseurs ;
 - évite les correctifs géométriques répétés : la colonne de couverture
   est organisée proprement en pile lorsque la section technique y est déplacée.
*/
(function () {
    "use strict";

    if (window.__PMK025ElementPlacementLoaded) return;
    window.__PMK025ElementPlacementLoaded = true;

    const MODULE_ID = "element-placement";
    const MODULE_VERSION = "1.3.1";
    const MOVED_ATTR = "data-pmk025-moved";
    const COVER_CONTROL_ATTR = "data-pmk025-cover-controlled";
    const COVER_STYLE_ID = "pmk025-cover-layout-style";

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 120,
        presets: {
            technicalSectionUnderCover: true,
            frameworkAfterInfotech: true,
            detail856Fallback: true,
            search856Fallback: true,
            searchThumbnailBeforeTitle: true
        },
        coverOptions: {
            hide856WhenOtherCover: true,
            minNaturalSize: 20,
            detailMaxWidth: 140,
            searchMaxWidth: 0
        },
        rules: []
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;
    let coverSyncQueued = false;
    const originals = new Map();

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function merge(target, source) {
        if (!source || typeof source !== "object") return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) target[key] = deepClone(value);
            else if (value && typeof value === "object") {
                if (!target[key] || typeof target[key] !== "object" || Array.isArray(target[key])) target[key] = {};
                merge(target[key], value);
            } else target[key] = value;
        });
        return target;
    }

    function normalizeConfig(config) {
        const incoming = deepClone(config || {});
        const legacyRules = Array.isArray(incoming.rules) ? incoming.rules.slice() : [];
        const result = merge(deepClone(DEFAULTS), incoming);

        if (!result.presets || typeof result.presets !== "object") result.presets = deepClone(DEFAULTS.presets);
        if (!result.coverOptions || typeof result.coverOptions !== "object") result.coverOptions = deepClone(DEFAULTS.coverOptions);

        // Migration transparente depuis les valeurs par défaut de la v1.2.x :
        // les deux anciennes règles natives deviennent des presets lisibles,
        // sans apparaître deux fois dans le repeater des règles personnalisées.
        legacyRules.forEach(function (rule) {
            if (!rule || !rule.id) return;
            if (rule.id === "legacy-technical-section-under-cover") {
                result.presets.technicalSectionUnderCover = rule.enabled !== false;
            }
            if (rule.id === "legacy-framework-after-infotech") {
                result.presets.frameworkAfterInfotech = rule.enabled !== false;
            }
        });

        if (!Array.isArray(result.rules)) result.rules = [];
        result.rules = result.rules
            .filter(function (rule) {
                return rule
                    && rule.id !== "legacy-technical-section-under-cover"
                    && rule.id !== "legacy-framework-after-infotech";
            })
            .map(function (rule, index) {
                return merge({
                    id: "rule-" + (index + 1),
                    enabled: true,
                    label: "",
                    pages: "*",
                    sourceSelector: "",
                    sourceName: "",
                    destinationSelector: "",
                    destinationName: "",
                    position: "after",
                    wrapperTag: "none",
                    newLabelFr: "",
                    newLabelEn: "",
                    addLegacyTechnicalStyle: false
                }, rule || {});
            });

        result.observeDelay = Math.max(30, Number(result.observeDelay) || DEFAULTS.observeDelay);
        result.coverOptions.minNaturalSize = Math.max(1, Number(result.coverOptions.minNaturalSize) || DEFAULTS.coverOptions.minNaturalSize);
        result.coverOptions.detailMaxWidth = Math.max(0, Number(result.coverOptions.detailMaxWidth) || 0);
        result.coverOptions.searchMaxWidth = Math.max(0, Number(result.coverOptions.searchMaxWidth) || 0);

        return result;
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        return (document.documentElement.lang || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function splitPages(value) {
        if (Array.isArray(value)) return value.map(String);
        return String(value || "")
            .split(/[\n,;]+/)
            .map(function (v) { return v.trim(); })
            .filter(Boolean);
    }

    function normalizePath(value) {
        const raw = String(value || "").trim();
        if (!raw || raw === "*" || raw === "all") return raw;
        try {
            if (/^https?:\/\//i.test(raw)) return new URL(raw).pathname;
        } catch (_) {}
        if (raw.startsWith("/cgi-bin/koha/")) return raw;
        if (raw.startsWith("/")) return raw;
        return "/cgi-bin/koha/" + raw.replace(/^\/+/, "");
    }

    function pageMatches(rule) {
        const pages = splitPages(rule && rule.pages);
        if (!pages.length) return true;
        return pages.some(function (page) {
            const wanted = normalizePath(page);
            return !wanted || wanted === "*" || wanted === "all" || window.location.pathname === wanted;
        });
    }

    function firstConcretePage(rule) {
        const pages = splitPages(rule && rule.pages);
        for (let i = 0; i < pages.length; i += 1) {
            const path = normalizePath(pages[i]);
            if (path && path !== "*" && path !== "all") return path;
        }
        return "";
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return "\\" + c; });
    }

    function localStableSelector(element) {
        if (!element || element.nodeType !== 1) return "";

        if (element.id) {
            try {
                const byId = "#" + cssEscape(element.id);
                if (document.querySelectorAll(byId).length === 1) return byId;
            } catch (_) {}
        }

        const dataAttrs = ["data-tabname", "data-bs-target", "name", "role"];
        for (let i = 0; i < dataAttrs.length; i += 1) {
            const attr = dataAttrs[i];
            const value = element.getAttribute && element.getAttribute(attr);
            if (!value) continue;
            const escaped = String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            const selector = element.tagName.toLowerCase() + "[" + attr + '=\"' + escaped + '\"]';
            try { if (document.querySelectorAll(selector).length === 1) return selector; } catch (_) {}
        }

        const classes = Array.from(element.classList || []).filter(function (name) {
            return !/^pmk|^active$|^selected$|^hover$|^focus$|^show$|^open$/.test(name);
        });
        if (classes.length) {
            const candidate = element.tagName.toLowerCase() + "." + classes.slice(0, 2).map(cssEscape).join(".");
            try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
        }

        const parts = [];
        let node = element;
        while (node && node !== document.body && parts.length < 6) {
            let part = node.tagName.toLowerCase();
            if (node.id) {
                part += "#" + cssEscape(node.id);
                parts.unshift(part);
                break;
            }
            const usable = Array.from(node.classList || []).filter(function (name) {
                return !/^pmk|^active$|^selected$|^hover$|^focus$|^show$|^open$/.test(name);
            });
            if (usable.length) part += "." + cssEscape(usable[0]);
            const parent = node.parentElement;
            if (parent && !usable.length) {
                const peers = Array.from(parent.children).filter(function (x) { return x.tagName === node.tagName; });
                if (peers.length > 1) part += ":nth-of-type(" + (peers.indexOf(node) + 1) + ")";
            }
            parts.unshift(part);
            node = parent;
        }
        return parts.join(" > ");
    }

    function saveOriginal(element) {
        if (!element || originals.has(element)) return;
        originals.set(element, {
            parent: element.parentNode,
            nextSibling: element.nextSibling,
            className: element.className,
            style: element.getAttribute("style"),
            labelText: (function () {
                const label = element.querySelector && element.querySelector(".label");
                return label ? label.textContent : null;
            })(),
            wrapper: null
        });
    }

    function restoreAll() {
        originals.forEach(function (original, element) {
            if (!element) return;
            try {
                const wrapper = original.wrapper;
                if (wrapper && wrapper.isConnected && wrapper.contains(element)) {
                    wrapper.parentNode.insertBefore(element, wrapper);
                    wrapper.remove();
                }
                if (original.parent && original.parent.isConnected) {
                    if (original.nextSibling && original.nextSibling.parentNode === original.parent) {
                        original.parent.insertBefore(element, original.nextSibling);
                    } else {
                        original.parent.appendChild(element);
                    }
                }
                if (original.style === null) element.removeAttribute("style");
                else element.setAttribute("style", original.style);
                element.className = original.className;
                const label = element.querySelector && element.querySelector(".label");
                if (label && original.labelText !== null) label.textContent = original.labelText;
                element.removeAttribute(MOVED_ATTR);
            } catch (_) {}
        });
        originals.clear();
    }

    function applyOptionalLabel(element, rule) {
        const replacement = detectLanguage() === "en"
            ? String(rule.newLabelEn || "").trim()
            : String(rule.newLabelFr || "").trim();
        if (!replacement) return;
        const label = element.querySelector && element.querySelector(".label");
        if (!label) return;
        const original = String(label.textContent || "");
        const suffix = /\s*:\s*$/.test(original) ? " :" : "";
        label.textContent = replacement + suffix;
    }

    function ensureLegacyTechnicalStyle(element, rule) {
        if (!rule.addLegacyTechnicalStyle || !element) return;
        element.classList.add("koha-technique-moved");
        element.style.display = "block";
        element.style.width = "100%";
        element.style.marginTop = "12px";
        element.style.boxSizing = "border-box";
        element.style.background = "#fff";
        element.style.padding = "15px";
        element.style.textAlign = "left";
        const content = element.querySelector(".content");
        if (content) content.style.display = "block";
    }

    function wrapSourceIfNeeded(source, rule) {
        const tag = String(rule.wrapperTag || "none").toLowerCase();
        if (tag === "none" || !/^(li|div|section|span)$/.test(tag)) return source;
        const original = originals.get(source);
        const wrapper = document.createElement(tag);
        wrapper.setAttribute("data-pmk025-wrapper", String(rule.id || "1"));
        source.parentNode.insertBefore(wrapper, source);
        wrapper.appendChild(source);
        if (original) original.wrapper = wrapper;
        return wrapper;
    }

    function performPlacement(movable, destination, position) {
        if (!movable || !destination || movable === destination) return false;
        if (movable.contains && movable.contains(destination)) return false;

        switch (position) {
            case "before":
                if (!destination.parentNode) return false;
                destination.parentNode.insertBefore(movable, destination);
                return true;
            case "after":
                if (!destination.parentNode) return false;
                destination.parentNode.insertBefore(movable, destination.nextSibling);
                return true;
            case "inside-start":
                destination.insertBefore(movable, destination.firstChild);
                return true;
            case "inside-end":
            default:
                destination.appendChild(movable);
                return true;
        }
    }


    function pageIsDetail() {
        return window.location.pathname === "/cgi-bin/koha/catalogue/detail.pl";
    }

    function pageIsSearch() {
        return window.location.pathname === "/cgi-bin/koha/catalogue/search.pl";
    }

    function ensureCoverLayoutStyle() {
        if (document.getElementById(COVER_STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = COVER_STYLE_ID;
        style.textContent = `
            .bookcoverimg.pmk025-cover-stack {
                display: flex;
                flex-direction: column;
                align-items: stretch;
                gap: 12px;
                overflow: visible !important;
            }
            .bookcoverimg.pmk025-cover-stack > #biblio-cover-slider,
            .bookcoverimg.pmk025-cover-stack > .cover-slides {
                position: relative;
                display: block;
                max-width: 100%;
                margin: 0 auto;
                flex: 0 0 auto;
            }
            .bookcoverimg.pmk025-cover-stack > #biblio-cover-slider img,
            .bookcoverimg.pmk025-cover-stack > .cover-slides img {
                max-width: 100%;
                height: auto;
            }
            .bookcoverimg.pmk025-cover-stack > .technique,
            .bookcoverimg.pmk025-cover-stack > .koha-technique-moved {
                clear: both;
                position: relative;
                z-index: auto;
                width: 100%;
                box-sizing: border-box;
                margin-top: 0 !important;
                flex: 0 0 auto;
            }
            .bookcoverimg .imgcouv[data-pmk025-cover-controlled="detail"],
            .bookcoverimg .imgcouvlist[data-pmk025-cover-controlled="search"] {
                height: auto;
                object-fit: contain;
                align-self: center;
            }
        `;
        document.head.appendChild(style);
    }

    function getBestImgSource(img) {
        if (!img) return "";
        return String(img.currentSrc || img.getAttribute("src") || img.src || "").trim();
    }

    function isLikelyPlaceholder(src) {
        return /no[-_ ]?cover|nocover|placeholder|cover_unavailable|no[-_ ]?image|spacer|transparent/i.test(src || "");
    }

    function isLikelyObsolete856Url(src) {
        return /electre\.com\/GetBlob\.ashx\?Ean=.*,/i.test(src || "");
    }

    function isElementVisible(element) {
        if (!element || !element.isConnected) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(element) : null;
        if (style) {
            if (style.display === "none" || style.visibility === "hidden") return false;
            if (parseFloat(style.opacity || "1") <= 0) return false;
        }
        return true;
    }

    function isUsableImage(img, options) {
        if (!img) return false;
        const opts = options || {};
        const src = getBestImgSource(img);
        if (!src || isLikelyPlaceholder(src)) return false;
        if (opts.rejectObsolete856 && isLikelyObsolete856Url(src)) return false;
        if (!img.complete) return false;
        const minSize = Math.max(1, Number(currentConfig && currentConfig.coverOptions && currentConfig.coverOptions.minNaturalSize) || 20);
        return (img.naturalWidth || 0) > minSize && (img.naturalHeight || 0) > minSize;
    }

    function setDisplay(element, visible) {
        if (!element) return;
        const wanted = visible ? "" : "none";
        if (element.style.display !== wanted) element.style.display = wanted;
    }

    function markCoverControlled(img, kind) {
        if (!img) return;
        saveOriginal(img);
        img.setAttribute(COVER_CONTROL_ATTR, kind);
    }

    function providerCoverBlocks(container) {
        if (!container) return [];
        return Array.from(container.querySelectorAll(".cover-image")).filter(function (block) {
            return !block.classList.contains("koha-856-cover-image")
                && !block.classList.contains("pmk025-856-cover-image");
        });
    }

    function hasValidProviderCover(container, visibleOnly) {
        return providerCoverBlocks(container).some(function (block) {
            if (visibleOnly && !isElementVisible(block)) return false;
            const img = block.querySelector("img");
            return isUsableImage(img);
        });
    }

    function chooseBest856Image(images) {
        const list = Array.from(images || []);
        const usable = list.find(function (img) {
            return isUsableImage(img, { rejectObsolete856: false });
        });
        if (usable) return usable;

        // Tant que les images sont encore en chargement, on garde la première
        // comme candidate ; l'événement load/error relancera l'arbitrage.
        return list.find(function (img) {
            const src = getBestImgSource(img);
            return src && !isLikelyPlaceholder(src) && !img.complete;
        }) || null;
    }

    function styleFallbackImage(img, kind) {
        if (!img) return;
        const opts = currentConfig && currentConfig.coverOptions || DEFAULTS.coverOptions;
        if (kind === "detail") {
            img.style.float = "none";
            img.style.marginRight = "0";
            img.style.marginBottom = "8px";
            if (Number(opts.detailMaxWidth) > 0) img.style.maxWidth = Number(opts.detailMaxWidth) + "px";
        } else {
            img.style.float = "none";
            img.style.marginRight = "0";
            if (Number(opts.searchMaxWidth) > 0) img.style.maxWidth = Number(opts.searchMaxWidth) + "px";
        }
        img.style.height = "auto";
    }

    function applyDetailTechnicalPreset() {
        if (!pageIsDetail()) return;
        const tech = document.querySelector(".technique");
        const coverCol = document.querySelector(".bookcoverimg")
            || (document.getElementById("biblio-cover-slider") && document.getElementById("biblio-cover-slider").closest(".bookcoverimg"));
        if (!tech || !coverCol || tech === coverCol || tech.contains(coverCol)) return;

        saveOriginal(tech);
        saveOriginal(coverCol);
        ensureCoverLayoutStyle();

        coverCol.classList.add("pmk025-cover-stack");
        tech.classList.add("koha-technique-moved");
        tech.style.display = "block";
        tech.style.width = "100%";
        tech.style.boxSizing = "border-box";
        tech.style.background = "#fff";
        tech.style.padding = "15px";
        tech.style.textAlign = "left";
        tech.style.clear = "both";
        tech.style.position = "relative";
        tech.style.zIndex = "auto";
        const content = tech.querySelector(".content");
        if (content) {
            saveOriginal(content);
            content.style.display = "block";
        }

        if (!coverCol.contains(tech) || coverCol.lastElementChild !== tech) {
            coverCol.appendChild(tech);
        }
        tech.setAttribute(MOVED_ATTR, "preset-technical-section-under-cover");
    }

    function applyFrameworkPreset() {
        if (!pageIsDetail()) return;
        const source = document.querySelector("#catalogue_detail_framework");
        const destination = document.querySelector("strong.infotech");
        if (!source || !destination || !destination.parentNode) return;

        saveOriginal(source);
        const rule = {
            id: "preset-framework-after-infotech",
            wrapperTag: "li",
            newLabelFr: "Grille utilisée",
            newLabelEn: "Framework used",
            addLegacyTechnicalStyle: false
        };
        applyOptionalLabel(source, rule);
        const movable = wrapSourceIfNeeded(source, rule);
        if (performPlacement(movable, destination, "after")) {
            source.setAttribute(MOVED_ATTR, "preset-framework-after-infotech");
        }
    }

    function detail856Images() {
        return Array.from(document.querySelectorAll(".imgcouv"));
    }

    function applyDetail856FallbackPreset() {
        if (!pageIsDetail()) return;

        const images = detail856Images();
        if (!images.length) return;

        const slider = document.getElementById("biblio-cover-slider")
            || document.querySelector(".bookcoverimg .cover-slides");
        const coverCol = document.querySelector(".bookcoverimg")
            || (slider && slider.closest(".bookcoverimg"))
            || document.querySelector("#catalogue_detail_biblio");
        if (!coverCol) return;

        ensureCoverLayoutStyle();
        const candidate = chooseBest856Image(images);
        const hideWhenOther = !currentConfig.coverOptions || currentConfig.coverOptions.hide856WhenOtherCover !== false;
        const visibleOther = slider ? hasValidProviderCover(slider, true) : false;

        images.forEach(function (img) {
            markCoverControlled(img, "detail");
            styleFallbackImage(img, "detail");

            if (!coverCol.contains(img)) {
                const insertBefore = slider && slider.parentNode === coverCol ? slider : coverCol.firstChild;
                coverCol.insertBefore(img, insertBefore || null);
            }

            if (img !== candidate) {
                setDisplay(img, false);
                return;
            }

            const usable = isUsableImage(img, { rejectObsolete856: false });
            if (img.complete && !usable) {
                setDisplay(img, false);
                return;
            }

            // Les anciennes URL Electre 856 restent utilisables comme fallback brut
            // si le navigateur réussit réellement à charger l'image, mais ne sont
            // jamais injectées comme slide supplémentaire.
            const showFallback = !hideWhenOther || !visibleOther;
            setDisplay(img, showFallback);
        });
    }

    function resultContainers() {
        const rows = Array.from(document.querySelectorAll("#searchresults tr[id^='row'], #searchresults tr, tr[id^='row']"));
        if (rows.length) return rows;
        return Array.from(document.querySelectorAll(".result"));
    }

    function applySearch856FallbackPreset() {
        if (!pageIsSearch()) return;

        resultContainers().forEach(function (row) {
            const coverCol = row.querySelector(".bookcoverimg");
            const images = Array.from(row.querySelectorAll(".imgcouvlist"));
            if (!coverCol || !images.length) return;

            const slider = coverCol.querySelector(".cover-slides");
            const candidate = chooseBest856Image(images);
            const hideWhenOther = !currentConfig.coverOptions || currentConfig.coverOptions.hide856WhenOtherCover !== false;
            const visibleOther = slider ? hasValidProviderCover(slider, true) : false;

            images.forEach(function (img) {
                markCoverControlled(img, "search");
                styleFallbackImage(img, "search");
                if (!coverCol.contains(img)) coverCol.appendChild(img);

                if (img !== candidate) {
                    setDisplay(img, false);
                    return;
                }

                const usable = isUsableImage(img, { rejectObsolete856: false });
                if (img.complete && !usable) {
                    setDisplay(img, false);
                    return;
                }

                setDisplay(img, !hideWhenOther || !visibleOther);
            });
        });
    }

    function applySearchThumbnailPreset() {
        if (!pageIsSearch()) return;
        document.querySelectorAll(".result").forEach(function (result) {
            const thumb = result.querySelector(".thumbimg");
            const title = result.querySelector(".title");
            if (!thumb || !title || !title.parentNode) return;
            saveOriginal(thumb);
            if (thumb.nextSibling !== title) title.parentNode.insertBefore(thumb, title);
            thumb.setAttribute(MOVED_ATTR, "preset-search-thumbnail-before-title");
        });
    }

    function applyPresets() {
        if (!currentConfig || !currentConfig.presets) return;
        const presets = currentConfig.presets;

        if (presets.technicalSectionUnderCover !== false) applyDetailTechnicalPreset();
        if (presets.frameworkAfterInfotech !== false) applyFrameworkPreset();
        if (presets.detail856Fallback !== false) applyDetail856FallbackPreset();
        if (presets.search856Fallback !== false) applySearch856FallbackPreset();
        if (presets.searchThumbnailBeforeTitle !== false) applySearchThumbnailPreset();
    }

    function applyRule(rule, index) {
        if (!rule || rule.enabled === false || !pageMatches(rule)) return;
        const sourceSelector = String(rule.sourceSelector || "").trim();
        const destinationSelector = String(rule.destinationSelector || "").trim();
        if (!sourceSelector || !destinationSelector) return;

        let sources = [];
        let destinations = [];
        try { sources = Array.from(document.querySelectorAll(sourceSelector)); } catch (_) { return; }
        try { destinations = Array.from(document.querySelectorAll(destinationSelector)); } catch (_) { return; }
        if (!sources.length || !destinations.length) return;

        sources.forEach(function (source, sourceIndex) {
            const destination = destinations[Math.min(sourceIndex, destinations.length - 1)];
            if (!source || !destination) return;
            saveOriginal(source);
            applyOptionalLabel(source, rule);
            ensureLegacyTechnicalStyle(source, rule);
            const movable = wrapSourceIfNeeded(source, rule);
            if (performPlacement(movable, destination, rule.position || "after")) {
                source.setAttribute(MOVED_ATTR, String(rule.id || index));
            }
        });
    }

    function applyAll() {
        if (!currentConfig || currentConfig.enabled === false) return;
        applyPresets();
        (currentConfig.rules || []).forEach(applyRule);
    }

    function queueCoverSync() {
        if (coverSyncQueued || !currentConfig || currentConfig.enabled === false) return;
        coverSyncQueued = true;
        const run = function () {
            coverSyncQueued = false;
            if (!currentConfig || currentConfig.enabled === false) return;
            if (pageIsDetail() && currentConfig.presets && currentConfig.presets.detail856Fallback !== false) {
                applyDetail856FallbackPreset();
            }
            if (pageIsSearch() && currentConfig.presets && currentConfig.presets.search856Fallback !== false) {
                applySearch856FallbackPreset();
            }
        };
        if (typeof window.requestAnimationFrame === "function") window.requestAnimationFrame(run);
        else window.setTimeout(run, 0);
    }

    function isInternalMutationTarget(target) {
        if (!target || !target.closest) return false;
        return !!target.closest("[" + COVER_CONTROL_ATTR + "], [" + MOVED_ATTR + "]");
    }

    function stopObserver() {
        clearTimeout(observerTimer);
        observerTimer = 0;
        if (observer) observer.disconnect();
        observer = null;
    }

    function startObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(function (mutations) {
            const external = mutations.some(function (mutation) {
                const target = mutation.target && mutation.target.nodeType === 1
                    ? mutation.target
                    : mutation.target && mutation.target.parentElement;
                if (isInternalMutationTarget(target)) return false;

                // Les insertions/suppressions peuvent concerner n'importe quelle
                // règle personnalisée. En revanche les attributs ne sont utiles
                // ici que pour les sliders/couvertures ; cela évite de retraiter
                // toute la page à chaque changement de classe Bootstrap/DataTables.
                if (mutation.type === "attributes") {
                    return !!(
                        target
                        && target.matches
                        && (
                            target.matches(".imgcouv, .imgcouvlist, .cover-image, .cover-slides, #biblio-cover-slider")
                            || target.closest(".cover-slides, #biblio-cover-slider, .bookcoverimg")
                        )
                    );
                }
                return true;
            });
            if (!external) return;

            clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                stopObserver();
                restoreAll();
                applyAll();
                if (currentConfig && currentConfig.enabled !== false && currentConfig.observeDom !== false) startObserver();
            }, Math.max(30, Number(currentConfig && currentConfig.observeDelay) || 120));
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["style", "class", "src"]
        });
    }

    function refresh(config) {
        stopObserver();
        restoreAll();
        currentConfig = normalizeConfig(config);
        if (currentConfig.enabled !== false) {
            applyAll();
            if (currentConfig.observeDom !== false) startObserver();
        }
    }

    function pickerBannerText(kind) {
        const en = detectLanguage() === "en";
        if (kind === "destination") {
            return en ? "Click the destination element — Esc cancels" : "Clique sur l’élément de destination — Échap annule";
        }
        return en ? "Click the element to move — Esc cancels" : "Clique sur l’élément à déplacer — Échap annule";
    }

    function ruleIndexFromFieldPath(path) {
        if (!Array.isArray(path)) return -1;
        const pos = path.indexOf("rules");
        if (pos === -1) return -1;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function pickerKindFromFieldPath(path) {
        const last = Array.isArray(path) ? String(path[path.length - 1] || "") : "";
        return last === "destinationSelector" ? "destination" : "source";
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== "function") return false;
        service.register(MODULE_ID, {
            getOptions: function (request) {
                const kind = request && request.meta && request.meta.kind === "destination" ? "destination" : "source";
                return { bannerText: pickerBannerText(kind) };
            },
            applyPending: function (draft, pending, picked) {
                const index = ruleIndexFromFieldPath(pending && pending.fieldPath || []);
                if (!draft || !Array.isArray(draft.rules) || index < 0 || !draft.rules[index]) return draft;
                const rule = draft.rules[index];
                const kind = pending && pending.meta && pending.meta.kind === "destination" ? "destination" : "source";
                if (kind === "destination") {
                    rule.destinationName = picked && (picked.targetName || picked.selector) || rule.destinationName;
                } else {
                    rule.sourceName = picked && (picked.targetName || picked.selector) || rule.sourceName;
                    if (!String(rule.label || "").trim()) rule.label = rule.sourceName;
                }
                return draft;
            }
        });
        return true;
    }

    function stableSelector(element) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (service && typeof service.stableSelector === "function") return service.stableSelector(element);
        return localStableSelector(element);
    }

    function pickElementOnCurrentPage(kind) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pick !== "function") return Promise.reject(new Error("pmk_common_picker_unavailable"));
        registerCommonPickerAdapter();
        return service.pick({ moduleId: MODULE_ID, meta: { kind: kind || "source" } });
    }

    function pickForConfig(context) {
        const rootObject = context && context.rootObject ? context.rootObject : null;
        const fieldPath = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const index = ruleIndexFromFieldPath(fieldPath);
        const kind = pickerKindFromFieldPath(fieldPath);
        const rule = rootObject && Array.isArray(rootObject.rules) && index >= 0 ? rootObject.rules[index] : null;
        const wantedPage = firstConcretePage(rule) || window.location.pathname;
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== "function") return Promise.reject(new Error("pmk_common_picker_unavailable"));
        registerCommonPickerAdapter();
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: wantedPage,
            rootObject: rootObject || {},
            fieldPath: fieldPath,
            meta: { ruleIndex: index, kind: kind },
            adminContext: { ruleIndex: index }
        });
    }

    async function resumePendingPick() {
        registerCommonPickerAdapter();
        return true;
    }

    function newRule() {
        return {
            id: "rule-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7),
            enabled: true,
            label: "",
            pages: window.location.pathname || "*",
            sourceSelector: "",
            sourceName: "",
            destinationSelector: "",
            destinationName: "",
            position: "after",
            wrapperTag: "none",
            newLabelFr: "",
            newLabelEn: "",
            addLegacyTechnicalStyle: false
        };
    }

    function onSourcePick(rootObject, fieldPath, result) {
        const index = ruleIndexFromFieldPath(fieldPath);
        if (!rootObject || !Array.isArray(rootObject.rules) || index < 0 || !rootObject.rules[index] || !result) return;
        rootObject.rules[index].sourceName = result.targetName || result.selector || "";
        if (!String(rootObject.rules[index].label || "").trim()) rootObject.rules[index].label = rootObject.rules[index].sourceName;
    }

    function onDestinationPick(rootObject, fieldPath, result) {
        const index = ruleIndexFromFieldPath(fieldPath);
        if (!rootObject || !Array.isArray(rootObject.rules) || index < 0 || !rootObject.rules[index] || !result) return;
        rootObject.rules[index].destinationName = result.targetName || result.selector || "";
    }

    function validate(config) {
        const lang = detectLanguage();
        const fail = function (fr, en) { return { ok: false, message: lang === "en" ? en : fr }; };
        if (!config || !Array.isArray(config.rules)) return fail("La liste des déplacements est invalide.", "The placement rule list is invalid.");

        const options = config.coverOptions || {};
        if (options.minNaturalSize !== undefined && Number(options.minNaturalSize) < 1) {
            return fail("La taille minimale d'une couverture doit être supérieure à 0.", "Minimum cover size must be greater than 0.");
        }
        if (options.detailMaxWidth !== undefined && Number(options.detailMaxWidth) < 0) {
            return fail("La largeur maximale de la couverture détail ne peut pas être négative.", "Detail cover maximum width cannot be negative.");
        }
        if (options.searchMaxWidth !== undefined && Number(options.searchMaxWidth) < 0) {
            return fail("La largeur maximale de la couverture de résultat ne peut pas être négative.", "Search cover maximum width cannot be negative.");
        }

        for (let i = 0; i < config.rules.length; i += 1) {
            const rule = config.rules[i];
            if (!rule || rule.enabled === false) continue;
            if (!String(rule.pages || "").trim()) return fail("La règle " + (i + 1) + " doit avoir une page Koha.", "Rule " + (i + 1) + " must have a Koha page.");
            if (!String(rule.sourceSelector || "").trim()) return fail("La règle " + (i + 1) + " doit avoir un élément à déplacer.", "Rule " + (i + 1) + " must have an element to move.");
            if (!String(rule.destinationSelector || "").trim()) return fail("La règle " + (i + 1) + " doit avoir une destination.", "Rule " + (i + 1) + " must have a destination.");
            if (["before", "after", "inside-start", "inside-end"].indexOf(rule.position) === -1) return fail("La position de la règle " + (i + 1) + " est invalide.", "Rule " + (i + 1) + " has an invalid position.");
        }
        return { ok: true };
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                livePreview: true
            },
            previewDraft: function (draft) {
                const before = deepClone(currentConfig || DEFAULTS);
                refresh(draft);
                return function () {
                    refresh(before);
                };
            }
        });
        return true;
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return;
        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Placement d'éléments", en: "Element placement" },
            description: {
                fr: "Déplace visuellement des éléments Koha et centralise les placements historiques de couvertures. Les préréglages 856/Electre évitent les doublons et utilisent le 856 uniquement comme secours lorsqu'aucune autre couverture valide n'est disponible.",
                en: "Moves Koha interface elements and centralizes legacy cover placement. 856/provider presets avoid duplicates and use 856 only as a fallback when no other valid cover is available."
            },
            category: { fr: "Interface / mise en page", en: "Interface / layout" },
            supportedPages: ["catalogue.detail", "catalogue.search", "custom"],
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULTS),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation générale", en: "General activation" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        {
                            key: "observeDom",
                            type: "boolean",
                            label: { fr: "Suivre les changements dynamiques de Koha", en: "Track dynamic Koha changes" },
                            help: {
                                fr: "Recommandé pour les couvertures chargées après l'affichage initial, notamment Electre et les sliders Koha.",
                                en: "Recommended for covers loaded after initial rendering, including provider covers and Koha sliders."
                            }
                        },
                        { key: "observeDelay", type: "number", advanced: true, label: { fr: "Délai de retraitement du DOM (ms)", en: "DOM reprocessing delay (ms)" } }
                    ]
                },
                {
                    type: "section",
                    id: "presets",
                    label: { fr: "Préréglages Koha", en: "Koha presets" },
                    description: {
                        fr: "Organisez la fiche notice et ses couvertures : informations techniques sous l’image, grille après les informations de notice, image du champ 856 en couverture de secours. Activez uniquement les déplacements souhaités.",
                        en: "Arrange record information and covers: technical details below the image, framework after record information, and a field 856 image as a fallback cover. Enable the changes you need."
                    },
                    fields: [
                        {
                            key: "presets.technicalSectionUnderCover",
                            type: "boolean",
                            label: { fr: "Fiche détail — section technique sous la couverture", en: "Detail page — technical section below cover" },
                            help: {
                                fr: "Place la section technique dans la colonne de couverture et organise proprement la colonne en pile.",
                                en: "Places the technical section in the cover column and stacks the column cleanly."
                            }
                        },
                        {
                            key: "presets.frameworkAfterInfotech",
                            type: "boolean",
                            label: { fr: "Fiche détail — grille utilisée après Infos notice", en: "Detail page — framework after record info" }
                        },
                        {
                            key: "presets.detail856Fallback",
                            type: "boolean",
                            label: { fr: "Fiche détail — image 856 comme couverture de secours", en: "Detail page — use 856 image as fallback cover" },
                            help: {
                                fr: "Déplace l'image 856 dans la zone de couverture et la masque dès qu'une autre couverture réellement chargée est disponible.",
                                en: "Moves the 856 image into the cover area and hides it as soon as another genuinely loaded cover is available."
                            }
                        },
                        {
                            key: "presets.search856Fallback",
                            type: "boolean",
                            label: { fr: "Résultats — image 856 comme couverture de secours", en: "Results — use 856 image as fallback cover" },
                            help: {
                                fr: "Remplace l'ancien 054 : une seule image 856 valide est conservée par résultat et elle disparaît lorsqu'une couverture Koha/Electre valide est visible.",
                                en: "Replaces legacy 054: only one valid 856 image is kept per result and it is hidden when a valid Koha/provider cover is visible."
                            }
                        },
                        {
                            key: "presets.searchThumbnailBeforeTitle",
                            type: "boolean",
                            label: { fr: "Résultats — miniature avant le titre", en: "Results — thumbnail before title" },
                            help: {
                                fr: "Conserve la branche search.pl de l'ancien 096 lorsqu'une miniature .thumbimg existe.",
                                en: "Preserves the search.pl branch of legacy 096 when a .thumbimg thumbnail exists."
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "cover-options",
                    label: { fr: "Couvertures — réglages avancés", en: "Covers — advanced settings" },
                    description: {
                        fr: "Ces réglages ne sont généralement pas à modifier. Ils pilotent l'arbitrage des couvertures, pas leur fournisseur.",
                        en: "These settings normally do not need changing. They control cover arbitration, not the cover provider."
                    },
                    fields: [
                        {
                            key: "coverOptions.hide856WhenOtherCover",
                            type: "boolean",
                            advanced: true,
                            label: { fr: "Masquer le 856 lorsqu'une autre couverture valide existe", en: "Hide 856 when another valid cover exists" }
                        },
                        {
                            key: "coverOptions.minNaturalSize",
                            type: "number",
                            advanced: true,
                            label: { fr: "Taille minimale d'une image valide (px)", en: "Minimum valid image size (px)" }
                        },
                        {
                            key: "coverOptions.detailMaxWidth",
                            type: "number",
                            advanced: true,
                            label: { fr: "Largeur maximale du fallback 856 sur la fiche (px, 0 = CSS Koha)", en: "Maximum detail 856 fallback width (px, 0 = Koha CSS)" }
                        },
                        {
                            key: "coverOptions.searchMaxWidth",
                            type: "number",
                            advanced: true,
                            label: { fr: "Largeur maximale du fallback 856 dans les résultats (px, 0 = CSS Koha)", en: "Maximum result 856 fallback width (px, 0 = Koha CSS)" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Déplacements personnalisés", en: "Custom placements" },
                    description: {
                        fr: "Ajoutez autant de déplacements que nécessaire. Les comportements historiques de couverture ci-dessus ne sont pas dupliqués ici.",
                        en: "Add as many placements as needed. The legacy cover behaviors above are not duplicated here."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Règles de déplacement", en: "Placement rules" },
                            addLabel: { fr: "Ajouter un déplacement", en: "Add placement" },
                            emptyLabel: { fr: "Aucun déplacement personnalisé.", en: "No custom placement." },
                            reorder: true,
                            newItem: newRule,
                            itemTitle: function (item, index) {
                                return String(item && (item.label || item.sourceName || item.sourceSelector) || "").trim() || "Règle " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de la règle", en: "Rule name" } },
                                {
                                    key: "pages",
                                    type: "textarea",
                                    label: { fr: "Pages Koha actives", en: "Active Koha pages" },
                                    help: { fr: "Un chemin par ligne. Le picker navigue automatiquement vers la première page indiquée si nécessaire.", en: "One path per line. The picker automatically navigates to the first configured page when needed." }
                                },
                                {
                                    key: "sourceSelector",
                                    type: "elementPicker",
                                    label: { fr: "Élément à déplacer", en: "Element to move" },
                                    pickLabel: { fr: "Choisir l'élément sur la page", en: "Choose element on page" },
                                    emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                                    allowManual: true,
                                    pick: pickForConfig,
                                    onPick: onSourcePick
                                },
                                { key: "sourceName", type: "text", readOnly: true, advanced: true, label: { fr: "Élément détecté", en: "Detected element" } },
                                {
                                    key: "destinationSelector",
                                    type: "elementPicker",
                                    label: { fr: "Destination", en: "Destination" },
                                    pickLabel: { fr: "Choisir la destination sur la page", en: "Choose destination on page" },
                                    emptyLabel: { fr: "Aucune destination choisie", en: "No destination selected" },
                                    allowManual: true,
                                    pick: pickForConfig,
                                    onPick: onDestinationPick
                                },
                                { key: "destinationName", type: "text", readOnly: true, advanced: true, label: { fr: "Destination détectée", en: "Detected destination" } },
                                {
                                    key: "position",
                                    type: "select",
                                    label: { fr: "Position", en: "Position" },
                                    options: [
                                        { value: "before", label: { fr: "Avant la destination", en: "Before destination" } },
                                        { value: "after", label: { fr: "Après la destination", en: "After destination" } },
                                        { value: "inside-start", label: { fr: "Dans la destination — au début", en: "Inside destination — at start" } },
                                        { value: "inside-end", label: { fr: "Dans la destination — à la fin", en: "Inside destination — at end" } }
                                    ]
                                },
                                {
                                    key: "wrapperTag",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Conteneur ajouté autour de la source", en: "Wrapper added around source" },
                                    options: [
                                        { value: "none", label: { fr: "Aucun", en: "None" } },
                                        { value: "li", label: { fr: "Élément de liste (li)", en: "List item (li)" } },
                                        { value: "div", label: { fr: "Bloc (div)", en: "Block (div)" } },
                                        { value: "section", label: { fr: "Section", en: "Section" } },
                                        { value: "span", label: { fr: "Élément inline (span)", en: "Inline element (span)" } }
                                    ]
                                },
                                { key: "newLabelFr", type: "text", advanced: true, label: { fr: "Nouveau libellé français du bloc (optionnel)", en: "French block label (optional)" } },
                                { key: "newLabelEn", type: "text", advanced: true, label: { fr: "Nouveau libellé anglais du bloc (optionnel)", en: "English block label (optional)" } },
                                { key: "addLegacyTechnicalStyle", type: "boolean", advanced: true, label: { fr: "Appliquer le style historique de la section technique", en: "Apply legacy technical-section presentation" } }
                            ]
                        }
                    ]
                }
            ]
        });
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return cfg || deepClone(DEFAULTS); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;

        let anchor = null;
        let contextKey = "";
        let page = "";

        if (pageIsDetail()) {
            anchor = document.querySelector(".technique") || document.querySelector(".bookcoverimg") || document.querySelector("h1");
            contextKey = "catalogue-detail-layout";
            page = "catalogue.detail";
        } else if (pageIsSearch()) {
            // Ne jamais ancrer le bouton de configuration directement après une cellule <td>.
            // Un bouton enfant direct de <tr> peut créer une colonne anonyme dans le tableau Koha.
            anchor = document.querySelector("#searchheader")
                || document.querySelector("#searchresults h1")
                || document.querySelector("#searchresults")
                || document.querySelector("h1");
            contextKey = "catalogue-search-layout";
            page = "catalogue.search";
        } else {
            return;
        }

        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: contextKey,
                context: { page: page }
            });
        } catch (_) {}
    }

    function bindCoverImageEvents() {
        document.addEventListener("load", function (event) {
            const target = event.target;
            if (!target || target.tagName !== "IMG") return;
            if (
                target.matches(".imgcouv, .imgcouvlist")
                || target.closest(".cover-slides, #biblio-cover-slider")
            ) queueCoverSync();
        }, true);

        document.addEventListener("error", function (event) {
            const target = event.target;
            if (!target || target.tagName !== "IMG") return;
            if (
                target.matches(".imgcouv, .imgcouvlist")
                || target.closest(".cover-slides, #biblio-cover-slider")
            ) queueCoverSync();
        }, true);
    }

    function start() {
        ensureCoverLayoutStyle();
        registerVisualEditorAdapter();
        registerModule();
        loadConfig().then(refresh);
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, function (config) { refresh(config); }); } catch (_) {}
        }
        mountContextAccess();
        resumePendingPick();
        bindCoverImageEvents();
    }

    window.PMK025ElementPlacement = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        apply: applyAll,
        restore: restoreAll,
        syncCovers: queueCoverSync,
        pickElement: pickElementOnCurrentPage,
        pickForConfig: pickForConfig,
        stableSelector: stableSelector
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
})();

;window.PMKNonPlugin.loaded.push("025-deplacer-grille-technique.js");
} catch (error) { window.PMKNonPlugin.errors.push("025-deplacer-grille-technique.js: "+error.message); console.error("[PMK] 025-deplacer-grille-technique.js",error); };
try {
/*
 Nom du fichier: 027-genre-icons-detail.js
 Dépendances: 000-pmk-config-firestore.js recommandé (fallback autonome inclus)
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha
 Description: Affiche des repères visuels configurables à partir de textes présents dans un bloc de la notice.
              Le bloc analysé et la destination sont sélectionnables visuellement depuis la configuration PMK.
*/
(function () {
    'use strict';

    const MODULE_ID = 'bibliographic-markers';
    const MODULE_VERSION = '2026.09.18.2';
    const PAGE_PATH = '/cgi-bin/koha/catalogue/detail.pl';
    const OWNER_ATTR = 'data-pmk027-owner';

    const DEFAULT_RULES = [
        { id: 'films-se-detendre', enabled: true, label: 'Films-Se détendre', searchText: 'Sujet - Indexation: Films-Se détendre', iconUrl: '' },
        { id: 'film-drame', enabled: true, label: 'Film-Drame', searchText: 'Sujet - Indexation: Film-Drame', iconUrl: '' },
        { id: 'films-aventure', enabled: true, label: 'Films-Aventure', searchText: 'Sujet - Indexation: Films-Aventure', iconUrl: '' },
        { id: 'film-vintage', enabled: true, label: 'Film-Vintage', searchText: 'Sujet - Indexation: Film-Vintage', iconUrl: '' },
        { id: 'film-famille', enabled: true, label: 'Film Famille', searchText: 'Sujet - Indexation: Film Famille', iconUrl: '' },
        { id: 'films-historiques', enabled: true, label: 'Films historiques', searchText: 'Sujet - Indexation: Films historiques', iconUrl: '' },
        { id: 'films-regards-de-femmes', enabled: true, label: 'Films-Regards de femmes', searchText: 'Sujet - Indexation: Films-Regards de femmes', iconUrl: '' },
        { id: 'films-muets', enabled: true, label: 'Films muets', searchText: 'Sujet - Indexation: Films muets', iconUrl: '' },
        { id: 'films-musicaux', enabled: true, label: 'Films musicaux', searchText: 'Sujet - Indexation: Films musicaux', iconUrl: '' },
        { id: 'films-noirs', enabled: true, label: 'Films noirs', searchText: 'Sujet - Indexation: Films noirs', iconUrl: '' },
        { id: 'films-grands-classiques', enabled: true, label: 'Films-Grands classiques', searchText: 'Sujet - Indexation: Films-Grands classiques', iconUrl: '' },
        { id: 'films-japanimation', enabled: true, label: 'Japanimation', searchText: 'Sujet - Indexation: Films-Japanimation', iconUrl: '' },
        { id: 'films-science-fiction', enabled: true, label: 'Science-fiction', searchText: 'Sujet - Indexation: Films-Science-fiction', iconUrl: '' },
        { id: 'films-western', enabled: true, label: 'Western', searchText: 'Sujet - Indexation: Films-Western', iconUrl: '' },
        { id: 'series-courtes', enabled: true, label: 'Séries courtes', searchText: 'Sujet - Indexation: Séries courtes', iconUrl: '' },
        { id: 'films-vintage', enabled: true, label: 'Films-Vintage', searchText: 'Sujet - Indexation: Films-Vintage', iconUrl: '' },
        { id: 'comics', enabled: true, label: 'Comics', searchText: 'Sujet - Indexation: Comics', iconUrl: '' },
        { id: 'films-action', enabled: true, label: 'Films-Action', searchText: 'Sujet - Indexation: Films-Action', iconUrl: '' },
        { id: 'films-courts-metrages', enabled: true, label: 'Court metrage', searchText: 'Sujet - Indexation: Films-Courts métrages', iconUrl: '' },
        { id: 'films-horreur', enabled: true, label: 'Horreur', searchText: "Sujet - Indexation: Films d'horreur", iconUrl: '' }
    ];

    const DEFAULTS = {
        enabled: true,
        pagePath: PAGE_PATH,
        sourceSelector: '#catalogue_detail_biblio',
        sourceName: 'Bloc principal de la notice',
        destinationSelector: 'strong.titlebib',
        destinationName: 'Titre de la notice',
        destinationPosition: 'prepend',
        showLabel: true,
        iconSize: 30,
        maxIcons: 1,
        caseSensitive: true,
        normalizeWhitespace: true,
        rules: DEFAULT_RULES
    };

    let currentConfig = null;

    function deepClone(value) {
        try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
    }

    function normalizePath(path) {
        let value = String(path || '').trim();
        if (!value) return '';
        try {
            if (/^https?:\/\//i.test(value)) value = new URL(value).pathname;
        } catch (_) {}
        if (!value.startsWith('/')) value = '/' + value;
        return value.replace(/\/{2,}/g, '/');
    }

    function normalizeConfig(raw) {
        const cfg = Object.assign({}, deepClone(DEFAULTS), raw || {});
        cfg.enabled = cfg.enabled !== false;
        cfg.pagePath = normalizePath(cfg.pagePath || PAGE_PATH) || PAGE_PATH;
        cfg.sourceSelector = String(cfg.sourceSelector || DEFAULTS.sourceSelector).trim();
        cfg.sourceName = String(cfg.sourceName || '').trim();
        cfg.destinationSelector = String(cfg.destinationSelector || DEFAULTS.destinationSelector).trim();
        cfg.destinationName = String(cfg.destinationName || '').trim();
        cfg.destinationPosition = ['prepend', 'append', 'before', 'after'].includes(cfg.destinationPosition) ? cfg.destinationPosition : 'prepend';
        cfg.showLabel = cfg.showLabel !== false;
        cfg.iconSize = Math.max(12, Math.min(160, Number(cfg.iconSize) || 30));
        cfg.maxIcons = Math.max(0, Math.floor(Number(cfg.maxIcons) || 0));
        cfg.caseSensitive = cfg.caseSensitive !== false;
        cfg.normalizeWhitespace = cfg.normalizeWhitespace !== false;
        cfg.rules = Array.isArray(raw && raw.rules) ? raw.rules.map(function (rule, index) {
            return {
                id: String(rule && rule.id || ('rule-' + (index + 1))).trim(),
                enabled: !rule || rule.enabled !== false,
                label: String(rule && rule.label || '').trim(),
                searchText: String(rule && rule.searchText || ''),
                iconUrl: String(rule && rule.iconUrl || '').trim()
            };
        }) : deepClone(DEFAULT_RULES);
        return cfg;
    }

    function normalizeText(value, cfg) {
        let out = String(value || '');
        if (cfg.normalizeWhitespace) out = out.replace(/\s+/g, ' ').trim();
        if (!cfg.caseSensitive) out = out.toLocaleLowerCase();
        return out;
    }

    function matchesText(haystack, needle, cfg) {
        const wanted = normalizeText(needle, cfg);
        if (!wanted) return false;
        return normalizeText(haystack, cfg).includes(wanted);
    }

    function getSourceText(cfg) {
        if (!cfg.sourceSelector) return '';
        let nodes = [];
        try { nodes = Array.from(document.querySelectorAll(cfg.sourceSelector)); } catch (_) { return ''; }
        return nodes.map(function (node) { return node.innerText || node.textContent || ''; }).join('\n');
    }

    function findDestination(cfg) {
        if (!cfg.destinationSelector) return null;
        try { return document.querySelector(cfg.destinationSelector); } catch (_) { return null; }
    }

    function clearRendered() {
        document.querySelectorAll('[' + OWNER_ATTR + '="' + MODULE_ID + '"]').forEach(function (node) {
            node.remove();
        });
    }

    function ensureStyles() {
        if (document.getElementById('pmk027-runtime-style')) return;
        const style = document.createElement('style');
        style.id = 'pmk027-runtime-style';
        style.textContent = [
            '.pmk027-marker-group{display:inline-flex;align-items:flex-start;flex-wrap:wrap;gap:.45rem;vertical-align:middle}',
            '.pmk027-marker{display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-start;max-width:7rem;text-align:center;line-height:1.05}',
            '.pmk027-marker img{display:block;max-width:100%;height:auto;object-fit:contain}',
            '.pmk027-marker-label{display:block;margin-top:.12rem;font-size:.58em;line-height:1.1;overflow-wrap:anywhere}',
            '@media (max-width:767.98px){.pmk027-marker-group{gap:.3rem}.pmk027-marker-label{font-size:.64em}}'
        ].join('');
        document.head.appendChild(style);
    }

    function createMarker(rule, cfg) {
        const marker = document.createElement('span');
        marker.className = 'pmk027-marker';
        marker.dataset.pmk027RuleId = rule.id;
        const label = rule.label || rule.searchText || rule.id;
        const en = (window.PMKConfig?.getLanguage?.() || document.documentElement.lang || 'fr').startsWith('en');
        marker.title = label + (en ? ' — Matched in the record: ' : ' — Texte repéré dans la notice : ') + rule.searchText;
        marker.setAttribute('role','img');
        marker.setAttribute('aria-label',marker.title);

        if (rule.iconUrl) {
            const img = document.createElement('img');
            img.src = rule.iconUrl;
            img.alt = label;
            img.width = cfg.iconSize;
            img.height = cfg.iconSize;
            img.style.width = cfg.iconSize + 'px';
            img.style.height = cfg.iconSize + 'px';
            img.loading = 'lazy';
            img.addEventListener('error', function () {
                img.style.display = 'none';
                marker.classList.add('pmk027-icon-error');
                if(!marker.querySelector('.pmk027-marker-label')) {
                    const fallback=document.createElement('span');
                    fallback.className='pmk027-marker-label';fallback.textContent=label;marker.appendChild(fallback);
                }
            }, { once: true });
            marker.appendChild(img);
        }

        if (cfg.showLabel && rule.label) {
            const caption = document.createElement('span');
            caption.className = 'pmk027-marker-label';
            caption.textContent = rule.label;
            marker.appendChild(caption);
        }
        return marker;
    }

    function insertGroup(destination, group, position) {
        if (position === 'append') destination.appendChild(group);
        else if (position === 'before') destination.parentNode && destination.parentNode.insertBefore(group, destination);
        else if (position === 'after') destination.parentNode && destination.parentNode.insertBefore(group, destination.nextSibling);
        else destination.prepend(group);
    }

    function apply(config) {
        const cfg = normalizeConfig(config);
        currentConfig = cfg;
        clearRendered();

        if (!cfg.enabled) return { ok: false, reason: 'disabled' };
        if (window.location.pathname !== cfg.pagePath) return { ok: false, reason: 'wrong_page' };

        const destination = findDestination(cfg);
        if (!destination) return { ok: false, reason: 'destination_missing' };

        const sourceText = getSourceText(cfg);
        if (!sourceText) return { ok: false, reason: 'source_missing' };

        const found = [];
        const seenIds = new Set();

        for (let i = 0; i < cfg.rules.length; i += 1) {
            const rule = cfg.rules[i];
            if (!rule || rule.enabled === false || !rule.searchText) continue;
            if (seenIds.has(rule.id)) continue;
            if (!matchesText(sourceText, rule.searchText, cfg)) continue;

            seenIds.add(rule.id);
            found.push(rule);

            if (cfg.maxIcons > 0 && found.length >= cfg.maxIcons) break;
        }

        if (!found.length) return { ok: false, reason: 'no_match' };

        ensureStyles();

        const group = document.createElement('span');
        group.className = 'pmk027-marker-group';
        group.setAttribute(OWNER_ATTR, MODULE_ID);
        group.dataset.pmk027Version = MODULE_VERSION;

        found.forEach(function (rule) {
            group.appendChild(createMarker(rule, cfg));
        });

        insertGroup(destination, group, cfg.destinationPosition);

        return {
            ok: true,
            reason: 'rendered',
            count: found.length
        };
    }

    function refresh(config) {
        const result = apply(config || currentConfig || DEFAULTS);
        mountContextAccess();
        return result;
    }

    let readinessObserver = null;
    let readinessTimer = null;
    let readinessDeadlineTimer = null;

    function stopReadinessObserver() {
        if (readinessObserver) {
            readinessObserver.disconnect();
            readinessObserver = null;
        }
        if (readinessTimer) {
            window.clearTimeout(readinessTimer);
            readinessTimer = null;
        }
        if (readinessDeadlineTimer) {
            window.clearTimeout(readinessDeadlineTimer);
            readinessDeadlineTimer = null;
        }
    }

    function scheduleReadinessRefresh() {
        if (readinessTimer) window.clearTimeout(readinessTimer);
        readinessTimer = window.setTimeout(function () {
            readinessTimer = null;
            const result = refresh(currentConfig || DEFAULTS);
            if (result && result.ok) stopReadinessObserver();
        }, 80);
    }

    function watchUntilReady() {
        stopReadinessObserver();

        const first = refresh(currentConfig || DEFAULTS);
        if (first && first.ok) return;

        readinessObserver = new MutationObserver(function () {
            scheduleReadinessRefresh();
        });

        readinessObserver.observe(document.documentElement, {
            childList: true,
            subtree: true,
            characterData: true
        });

        readinessDeadlineTimer = window.setTimeout(function () {
            stopReadinessObserver();
            refresh(currentConfig || DEFAULTS);
        }, 12000);
    }

    function fieldKind(context) {
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const key = path[path.length - 1];
        return key === 'sourceSelector' ? 'source' : 'destination';
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== 'function') return false;
        service.register(MODULE_ID, {
            getOptions: function (request) {
                const kind = request && request.meta && request.meta.kind === 'source' ? 'source' : 'destination';
                return {
                    bannerText: kind === 'source'
                        ? 'Cliquez sur le bloc dans lequel le module doit rechercher les textes — Échap annule'
                        : 'Cliquez sur l’élément qui doit recevoir les icônes — Échap annule'
                };
            },
            applyPending: function (draft, pending, picked) {
                const kind = pending && pending.meta && pending.meta.kind === 'source' ? 'source' : 'destination';
                if (kind === 'source') draft.sourceName = picked && (picked.targetName || picked.selector) || draft.sourceName;
                else draft.destinationName = picked && (picked.targetName || picked.selector) || draft.destinationName;
                return draft;
            }
        });
        return true;
    }

    function stableSelector(element) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        return service && typeof service.stableSelector === 'function' ? service.stableSelector(element) : '';
    }

    function pickElementOnCurrentPage(kind) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pick !== 'function') return Promise.reject(new Error('pmk_common_picker_unavailable'));
        registerCommonPickerAdapter();
        return service.pick({ moduleId: MODULE_ID, meta: { kind: kind === 'source' ? 'source' : 'destination' } });
    }

    function pickForConfig(context) {
        const rootObject = context && context.rootObject ? context.rootObject : null;
        const kind = fieldKind(context);
        const wantedPage = normalizePath(rootObject && rootObject.pagePath || PAGE_PATH) || PAGE_PATH;
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== 'function') return Promise.reject(new Error('pmk_common_picker_unavailable'));
        registerCommonPickerAdapter();
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: wantedPage,
            rootObject: rootObject || {},
            fieldPath: context && Array.isArray(context.fieldPath) ? context.fieldPath : [],
            meta: { kind: kind },
            adminContext: { sectionId: 'placement' }
        });
    }

    async function resumePendingPick() {
        registerCommonPickerAdapter();
        return true;
    }

    function mountContextAccess() {
        if (window.location.pathname !== PAGE_PATH) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
        const anchor = document.querySelector('strong.titlebib') || document.querySelector('#catalogue_detail_biblio h1') || document.querySelector('h1');
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: 'after',
                contextKey: 'catalogue-detail-bibliographic-markers',
                context: { page: 'catalogue.detail', sectionId: 'placement' }
            });
        } catch (_) {}
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== 'function') return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                livePreview: true
            },
            canPreview: function () { return window.location.pathname === PAGE_PATH; },
            previewModel: function (context) {
                const cfg = normalizeConfig(context && context.rootObject || currentConfig || DEFAULTS);
                const first = (cfg.rules || []).find(function (rule) {
                    return rule && rule.enabled !== false;
                }) || {};
                return {
                    text: cfg.showLabel === false
                        ? 'Repère bibliographique'
                        : (first.label || first.searchText || 'Repère bibliographique'),
                    icon: first.iconUrl ? {
                        type: 'image',
                        url: first.iconUrl,
                        size: Number(cfg.iconSize) || 30,
                        position: 'before'
                    } : null
                };
            },
            previewDraft: function (draft) {
                if (window.location.pathname !== PAGE_PATH) throw new Error('visual_preview_wrong_page');
                const before = deepClone(currentConfig || DEFAULTS);
                refresh(draft);
                return function () {
                    refresh(before);
                };
            }
        });
        return true;
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') return Promise.resolve(deepClone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return cfg || deepClone(DEFAULTS); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function start() {
        registerVisualEditorAdapter();
        loadConfig().then(function (cfg) {
            currentConfig = normalizeConfig(cfg || DEFAULTS);
            watchUntilReady();
        });

        if (window.PMKConfig && typeof window.PMKConfig.subscribe === 'function') {
            try {
                window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                    currentConfig = normalizeConfig(cfg || DEFAULTS);
                    watchUntilReady();
                });
            } catch (_) {}
        }

        resumePendingPick();
        mountContextAccess();
    }

    window.PMK027BibliographicMarkers = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        apply: apply,
        clear: clearRendered,
        pickElement: pickElementOnCurrentPage,
        pickForConfig: pickForConfig,
        stableSelector: stableSelector,
        diagnose: function () {
            const cfg = normalizeConfig(currentConfig || DEFAULTS);
            const source = cfg.sourceSelector ? document.querySelector(cfg.sourceSelector) : null;
            const destination = cfg.destinationSelector ? document.querySelector(cfg.destinationSelector) : null;
            const sourceText = source ? (source.innerText || source.textContent || '') : '';
            const matches = cfg.rules.filter(function (rule) {
                return rule && rule.enabled !== false && rule.searchText && matchesText(sourceText, rule.searchText, cfg);
            }).map(function (rule) {
                return { id: rule.id, label: rule.label, searchText: rule.searchText };
            });
            return {
                page: window.location.pathname,
                expectedPage: cfg.pagePath,
                enabled: cfg.enabled,
                sourceSelector: cfg.sourceSelector,
                sourceFound: Boolean(source),
                destinationSelector: cfg.destinationSelector,
                destinationFound: Boolean(destination),
                matches: matches
            };
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("027-genre-icons-detail.js");
} catch (error) { window.PMKNonPlugin.errors.push("027-genre-icons-detail.js: "+error.message); console.error("[PMK] 027-genre-icons-detail.js",error); };
try {
/*
 Nom du fichier: 028-transfer-buttons-holdings.js
 Dépendances: KOHA_UTILS.waitForSelector (fallback included)
 Version: v3.0 — fiabilisation multi-installations Koha
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha

 Description:
 - Ajoute un bouton "Transférer" dans la table des exemplaires de detail.pl.
 - Transmet le code-barres vers branchtransfers.pl.
 - Préremplit le champ code-barres sans lancer automatiquement le transfert.
 - Détecte les colonnes via data-colname/id/headers plutôt que par position fixe.
 - Supporte les libellés FR/EN pour la détection de disponibilité.
 - Résiste mieux aux redraw DataTables et aux doubles injections.
*/

(function () {
  'use strict';

  if (window.__PMK028_TRANSFER_BUTTONS__) return;
  window.__PMK028_TRANSFER_BUTTONS__ = true;

  const MODULE_ID = 'transfer-button-holdings';
  const MODULE_VERSION = '2026.10.21.1';

  const PAGE_DETAIL = '/cgi-bin/koha/catalogue/detail.pl';
  const PAGE_TRANSFER = '/cgi-bin/koha/circ/branchtransfers.pl';

  // Navigation dans le même onglet : aucun code-barres partagé entre les postes ouverts.
  const STORAGE_KEY = 'pmk028.pendingTransfer';
  const STORAGE_MAX_AGE_MS = 5 * 60 * 1000;

  const DEFAULT_CONFIG = {
    enabled: true,
    pages: [
      {
        id: 'catalogue.detail',
        enabled: true,
        path: PAGE_DETAIL
      }
    ]
  };

  let currentConfig = { ...DEFAULT_CONFIG };
  let detailInitialized = false;

  function isDetailPageEnabled(config) {
    const cfg = config || currentConfig || DEFAULT_CONFIG;
    const pages = Array.isArray(cfg.pages) ? cfg.pages : DEFAULT_CONFIG.pages;
    const page = pages.find(item => item && item.id === 'catalogue.detail');
    return Boolean(page && page.enabled !== false);
  }


  /* ============================================================
     UTILITAIRES DOM
     ============================================================ */

  function localWaitForSelector(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);

      let timer = null;
      let done = false;

      const observer = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) finish(resolve, found);
      });

      function finish(callback, value) {
        if (done) return;
        done = true;
        observer.disconnect();
        if (timer) clearTimeout(timer);
        callback(value);
      }

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });

      timer = setTimeout(() => {
        finish(reject, new Error('timeout'));
      }, timeout);
    });
  }

  const waitForSelector =
    window.KOHA_UTILS &&
    typeof window.KOHA_UTILS.waitForSelector === 'function'
      ? window.KOHA_UTILS.waitForSelector
      : localWaitForSelector;

  function normalizeText(value) {
    return String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function safeQuery(root, selector) {
    try {
      return root ? root.querySelector(selector) : null;
    } catch (_) {
      return null;
    }
  }

  /* ============================================================
     STYLE
     ============================================================ */

  function installTransferStyles() {
    if (document.getElementById('pmk028-transfer-button-style')) return;

    const style = document.createElement('style');
    style.id = 'pmk028-transfer-button-style';

    style.textContent = `
      #holdings_table .pmk028-transfer-action-row {
        display: block;
        margin-top: 5px;
        line-height: 1;
      }

      #holdings_table .pmk028-transfer-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        min-height: 26px;
        padding: 3px 8px;
        vertical-align: middle;
        white-space: nowrap;
      }

      #holdings_table .pmk028-transfer-btn i {
        margin: 0;
        line-height: 1;
      }

      @media (max-width: 767px) {
        #holdings_table .pmk028-transfer-btn {
          min-height: 28px;
          padding: 4px 8px;
        }
      }
    `;

    (document.head || document.documentElement).appendChild(style);
  }

  /* ============================================================
     IDENTIFICATION DES COLONNES
     ============================================================ */

  function getColumnIndexByIdentity(table, identities) {
    if (!table || !Array.isArray(identities)) return -1;

    const headers = Array.from(table.querySelectorAll('thead th'));

    for (let i = 0; i < headers.length; i += 1) {
      const th = headers[i];

      const colname = normalizeText(th.getAttribute('data-colname')).toLowerCase();
      const id = normalizeText(th.id).toLowerCase();

      for (const identity of identities) {
        const value = String(identity || '').toLowerCase();

        if (!value) continue;

        if (colname === value) return i;
        if (id === value) return i;
        if (id === `holdings_${value}`) return i;
      }
    }

    return -1;
  }

  function getCellByColumn(table, row, identities) {
    if (!table || !row) return null;

    const index = getColumnIndexByIdentity(table, identities);
    if (index >= 0 && row.cells && row.cells[index]) {
      return row.cells[index];
    }

    for (const identity of identities) {
      const selectors = [
        `td.${identity}`,
        `td[data-colname="${identity}"]`,
        `td[headers="holdings_${identity}"]`,
        `td[headers="${identity}"]`
      ];

      for (const selector of selectors) {
        const found = safeQuery(row, selector);
        if (found) return found;
      }
    }

    return null;
  }

  /* ============================================================
     DÉTECTION DE DISPONIBILITÉ
     ============================================================ */

  function rowLooksAvailable(table, row) {
    const statusCell = getCellByColumn(table, row, ['status']);

    const statusText = normalizeText(
      statusCell ? statusCell.textContent : ''
    );

    const rowClasses = String(row.className || '').toLowerCase();

    // Priorité aux classes déjà ajoutées par Koha/scripts locaux quand elles existent.
    if (
      /\b(disponible|available|vc-disponible)\b/.test(rowClasses)
    ) {
      return true;
    }

    // Fallback FR / EN uniquement si aucune classe technique exploitable.
    if (
      /\bDisponible\b/i.test(statusText) ||
      /\bAvailable\b/i.test(statusText)
    ) {
      return true;
    }

    return false;
  }

  /* ============================================================
     EXTRACTION DU CODE-BARRES
     ============================================================ */

  function getBarcodeFromRow(table, row) {
    if (!row) return '';

    const barcodeCell = getCellByColumn(table, row, ['barcode']);

    if (barcodeCell) {
      const candidates = [
        barcodeCell.querySelector('a'),
        barcodeCell.querySelector('[data-barcode]'),
        barcodeCell
      ].filter(Boolean);

      for (const candidate of candidates) {
        const dataBarcode = normalizeText(
          candidate.getAttribute && candidate.getAttribute('data-barcode')
        );

        if (dataBarcode) return dataBarcode;

        const value = normalizeText(candidate.textContent);

        if (value) {
          const cleaned = value.replace(/\s+/g, '');
          if (cleaned) return cleaned;
        }
      }
    }

    // Repli historique sécurisé.
    const barcodeLink = row.querySelector(
      'a[href*="#item"], a[href*="itemnumber="]'
    );

    if (barcodeLink) {
      const value = normalizeText(barcodeLink.textContent);
      if (value) return value.replace(/\s+/g, '');
    }

    return '';
  }

  /* ============================================================
     STOCKAGE INTER-PAGES
     ============================================================ */

  function storePendingBarcode(barcode) {
    if (!barcode) return false;

    try {
      sessionStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          barcode: String(barcode),
          createdAt: Date.now(),
          source: window.location.pathname,
          version: MODULE_VERSION
        })
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  function readPendingBarcode() {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (!raw) return '';

      let payload = null;

      try {
        payload = JSON.parse(raw);
      } catch (_) {
        payload = null;
      }

      if (!payload || !payload.barcode || !payload.createdAt) {
        sessionStorage.removeItem(STORAGE_KEY);
        return '';
      }

      const age = Date.now() - Number(payload.createdAt);

      if (!Number.isFinite(age) || age < 0 || age > STORAGE_MAX_AGE_MS) {
        sessionStorage.removeItem(STORAGE_KEY);
        return '';
      }

      return normalizeText(payload.barcode);
    } catch (_) {
      return '';
    }
  }

  function clearPendingBarcode() {
    try {
      sessionStorage.removeItem(STORAGE_KEY);
    } catch (_) {}
  }

  /* ============================================================
     BRANCHTRANSFERS.PL
     ============================================================ */

  function initBranchTransfersPage() {
    const storedBarcode = readPendingBarcode();
    if (!storedBarcode) return;

    waitForSelector('#barcode', 5000)
      .then(input => {
        if (!input || input.value.trim()) return;

        try {
          input.value = storedBarcode;

          input.dispatchEvent(
            new Event('input', { bubbles: true })
          );

          input.dispatchEvent(
            new Event('change', { bubbles: true })
          );
        } catch (_) {}
      })
      .catch(() => {})
      .finally(() => {
        clearPendingBarcode();
      });
  }

  /* ============================================================
     CRÉATION DU BOUTON
     ============================================================ */

  function createTransferButton() {
    const button = document.createElement('button');

    button.type = 'button';
    button.className =
      'btn btn-default btn-xs pmk028-transfer-btn';

    button.setAttribute('data-pmk028-transfer', '1');
    button.setAttribute('data-pmk-module', MODULE_ID);
    button.setAttribute('data-pmk-version', MODULE_VERSION);

    button.title =
      document.documentElement.lang &&
      document.documentElement.lang.toLowerCase().startsWith('en')
        ? 'Transfer this item to another library'
        : 'Transférer cet exemplaire vers un autre site';

    button.setAttribute(
      'aria-label',
      document.documentElement.lang &&
      document.documentElement.lang.toLowerCase().startsWith('en')
        ? 'Transfer this item'
        : 'Transférer cet exemplaire'
    );

    const icon = document.createElement('i');
    icon.className = 'fa-solid fa-arrow-right-arrow-left';
    icon.setAttribute('aria-hidden', 'true');

    const label = document.createElement('span');
    label.textContent =
      document.documentElement.lang &&
      document.documentElement.lang.toLowerCase().startsWith('en')
        ? 'Transfer'
        : 'Transférer';

    button.append(icon, label);

    return button;
  }

  /* ============================================================
     INSERTION DANS LA COLONNE ACTIONS
     ============================================================ */

  function getActionCell(table, row) {
    return getCellByColumn(table, row, ['actions']) ||
      safeQuery(row, 'td.actions') ||
      safeQuery(row, 'td:last-child');
  }

  function applyTransferButtons(table) {
    if (!table || currentConfig.enabled === false || !isDetailPageEnabled(currentConfig)) return;

    const rows = table.querySelectorAll('tbody tr');

    rows.forEach(row => {
      if (!(row instanceof HTMLTableRowElement)) return;

      if (!rowLooksAvailable(table, row)) return;

      if (row.querySelector('[data-pmk028-transfer="1"]')) return;

      const barcode = getBarcodeFromRow(table, row);
      if (!barcode) return;

      const actionCell = getActionCell(table, row);
      if (!actionCell) return;

      let actionRow = actionCell.querySelector(
        '.pmk028-transfer-action-row'
      );

      if (!actionRow) {
        actionRow = document.createElement('div');
        actionRow.className = 'pmk028-transfer-action-row';
        actionRow.setAttribute('data-pmk028-owner', MODULE_ID);
        actionCell.appendChild(actionRow);
      }

      actionRow.appendChild(createTransferButton());
    });
  }

  /* ============================================================
     ÉVÉNEMENT DE CLIC
     ============================================================ */

  function bindTransferClick(table) {
    if (!table || table.dataset.pmk028ClickBound === '1') return;

    table.addEventListener('click', event => {
      const button = event.target.closest(
        '[data-pmk028-transfer="1"]'
      );

      if (!button || !table.contains(button)) return;

      event.preventDefault();
      event.stopPropagation();

      const row = button.closest('tr');
      if (!row) return;

      const barcode = getBarcodeFromRow(table, row);
      if (!barcode) return;

      if (!storePendingBarcode(barcode)) {
        window.alert('Le navigateur ne permet pas de préparer ce transfert. Copiez le code-barres puis utilisez la page Transferts de Koha.');
        return;
      }
      window.location.href = PAGE_TRANSFER;
    });

    table.dataset.pmk028ClickBound = '1';
  }

  /* ============================================================
     OBSERVATION DATATABLES
     ============================================================ */

  function observeTable(table) {
    if (!table) return;

    if (table.dataset.pmk028Observed === '1') return;

    let rerunTimer = null;

    const observer = new MutationObserver(() => {
      if (rerunTimer) clearTimeout(rerunTimer);

      rerunTimer = setTimeout(() => {
        applyTransferButtons(table);
      }, 100);
    });

    observer.observe(table, {
      childList: true,
      subtree: true
    });

    table.dataset.pmk028Observed = '1';
  }

  /* ============================================================
     INITIALISATION DETAIL.PL
     ============================================================ */

  function initDetailPage() {
    installTransferStyles();

    waitForSelector('#holdings_table', 6000)
      .then(table => {
        if (!table) return;

        bindTransferClick(table);

        // Koha peut remplir ou remplacer le tbody après une réponse API lente.
        // Observer immédiatement la table évite de manquer ce premier rendu.
        observeTable(table);
        applyTransferButtons(table);
      })
      .catch(() => {});
  }

  /* ============================================================
     CONFIGURATION PMK
     ============================================================ */

  function loadConfig() {
    if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') {
      return Promise.resolve({ ...DEFAULT_CONFIG });
    }

    return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
      .then(cfg => Object.assign({}, DEFAULT_CONFIG, cfg || {}))
      .catch(() => ({ ...DEFAULT_CONFIG }));
  }

  function removeTransferButtons() {
    document.querySelectorAll('[data-pmk028-transfer="1"]').forEach(el => el.remove());
    document.querySelectorAll('.pmk028-transfer-action-row').forEach(el => {
      if (!el.children.length) el.remove();
    });
  }

  function mountContextAccess() {
    if (window.location.pathname !== PAGE_DETAIL) return;
    if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;

    const anchor =
      document.querySelector('.holdings_table_table_controls') ||
      document.querySelector('#holdings_table_wrapper') ||
      document.querySelector('#holdings_table');

    if (!anchor) return;

    try {
      window.PMKConfig.mountContextButton({
        moduleId: MODULE_ID,
        anchor: anchor,
        position: 'after',
        contextKey: 'catalogue-detail-transfer-button',
        context: {
          page: 'catalogue.detail',
          sectionId: 'pages'
        }
      });
    } catch (_) {}
  }

  function applyConfig(cfg) {
    currentConfig = Object.assign({}, DEFAULT_CONFIG, cfg || {});
    if (!Array.isArray(currentConfig.pages)) {
      currentConfig.pages = DEFAULT_CONFIG.pages.map(page => ({ ...page }));
    }

    const detailEnabled =
      currentConfig.enabled !== false &&
      isDetailPageEnabled(currentConfig);

    if (!detailEnabled) {
      removeTransferButtons();
      if (window.location.pathname === PAGE_TRANSFER) {
        clearPendingBarcode();
      }
      return;
    }

    const path = window.location.pathname;

    if (path === PAGE_TRANSFER) {
      initBranchTransfersPage();
      return;
    }

    if (path === PAGE_DETAIL && !detailInitialized) {
      detailInitialized = true;
      initDetailPage();
    } else if (path === PAGE_DETAIL) {
      const table = document.querySelector('#holdings_table');
      if (table) applyTransferButtons(table);
    }

    mountContextAccess();
  }

  function start() {
    loadConfig().then(applyConfig);

    if (window.PMKConfig && typeof window.PMKConfig.subscribe === 'function') {
      try {
        window.PMKConfig.subscribe(MODULE_ID, applyConfig);
      } catch (_) {}
    }
  }

  start();
})();

;window.PMKNonPlugin.loaded.push("028-transfer-buttons-holdings.js");
} catch (error) { window.PMKNonPlugin.errors.push("028-transfer-buttons-holdings.js: "+error.message); console.error("[PMK] 028-transfer-buttons-holdings.js",error); };
try {
/*
 Nom du fichier: 029-subscription-periodiques.js
 Version: 4.2.12-preplugin
 Date de dernière modification: 2026-10-03
 Auteur: équipe PimpMyKoha

 Module PimpMyKoha (phase pré-plugin) : Gestion des périodiques

 Fonctions :
 - améliore la lisibilité des statuts de fascicules sans détruire le DOM Koha ;
 - calcule, pour chaque fascicule "Attendu / Expected", l'échéance de réclamation
   à partir de la période de grâce définie dans l'abonnement Koha ;
 - accepte une période de grâce égale à 0 ;
 - affiche un calendrier des fascicules sur desktop/tablette et une vue agenda sur mobile ;
 - prend en charge les principaux statuts FR/EN ;
 - évite les positions de colonnes fixes quand Koha expose des en-têtes exploitables ;
 - conserve des fallbacks historiques strictement contrôlés ;
 - résiste aux redraws de tableaux et aux doubles injections ;
 - lit sa configuration via window.PMKConfig lorsqu'il est disponible ;
 - reprend les fonctions utiles de l'ancien 030 sans cloner le DOM : mise en page de
   subscription-detail.pl, filtrage des liens de bulletinage et transport du prix fascicule ;
 - fonctionne aussi sur serials-search.pl et reste compatible avec l'ancien .tableau-fasci
   pendant la phase de recette ;
 - intègre désormais intégralement l'ancien 073-serials-bulletinage.js sur serials-edit.pl :
   remplissage assisté, prix fascicule, HS, préconfigurations d'exemplaire, signalement et protection.
 - les préconfigurations historiques d’origine sont conservées à l'identique comme valeurs par défaut,
   mais deviennent configurables, extensibles et désactivables individuellement.
 - absorbe la fonction utile de l'ancien 094 sur serials-collection.pl : tri naturel configurable
   de la colonne Numéro dans chaque tableau annuel, sans clic simulé et sans modification métier ;
 - absorbe l'ancien 104 sur subscription-add.pl : assistant explicite de calcul de la durée
   d'abonnement, sans table d'identifiants de périodicité codée en dur.

 Important :
 - le renommage historique "Date prévue" -> "Date de réception" est conservé par défaut
   comme option de compatibilité, afin de restituer le fonctionnement utilisé avant fusion ;
 - le comportement historique .bouton / .sectionz du 030 est également conservé par défaut ;
 - aucune action de réclamation Koha n'est lancée automatiquement ; le module affiche
   uniquement une aide visuelle calculée à partir des données présentes sur la page.
*/

(function () {
    "use strict";

    if (window.__PMK029_SERIALS_TRACKING__) return;
    window.__PMK029_SERIALS_TRACKING__ = true;

    const MODULE_ID = "serials-tracking";
    const MODULE_VERSION = "4.2.16-preplugin";
    const DETAIL_PAGE_ID = "serials.subscription_detail";
    const DETAIL_PAGE_PATH = "/cgi-bin/koha/serials/subscription-detail.pl";
    const SEARCH_PAGE_ID = "serials.serials_search";
    const SEARCH_PAGE_PATH = "/cgi-bin/koha/serials/serials-search.pl";
    const EDIT_PAGE_ID = "serials.serials_edit";
    const EDIT_PAGE_PATH = "/cgi-bin/koha/serials/serials-edit.pl";
    const COLLECTION_PAGE_ID = "serials.serials_collection";
    const COLLECTION_PAGE_PATH = "/cgi-bin/koha/serials/serials-collection.pl";
    const ADD_PAGE_ID = "serials.subscription_add";
    const ADD_PAGE_PATH = "/cgi-bin/koha/serials/subscription-add.pl";
    const CONTEXT_STORAGE_KEY = "pmk.serials.context";
    const LEGACY_PRICE_KEY = "selectedPrice";

    const DEFAULT_CONFIG = {
        enabled: true,
        search: { autoFocusTitle: true },
        pages: [
            { id: DETAIL_PAGE_ID, enabled: true, path: DETAIL_PAGE_PATH },
            { id: SEARCH_PAGE_ID, enabled: true, path: SEARCH_PAGE_PATH },
            { id: EDIT_PAGE_ID, enabled: true, path: EDIT_PAGE_PATH },
            { id: COLLECTION_PAGE_ID, enabled: true, path: COLLECTION_PAGE_PATH },
            { id: ADD_PAGE_ID, enabled: true, path: ADD_PAGE_PATH }
        ],
        layout: {
            enabled: true,
            mode: "historical-three-columns",
            hideNativeTabs: true,
            responsiveWrap: true,
            gap: 20,
            sections: [
                { key: "information", enabled: true, labelFr: "Information", labelEn: "Information" },
                { key: "planning", enabled: true, labelFr: "Calendrier", labelEn: "Planning" },
                { key: "issues", enabled: true, labelFr: "Fascicules", labelEn: "Issues" },
                { key: "summary", enabled: true, labelFr: "Résumé", labelEn: "Summary" }
            ]
        },
        display: {
            statusBadges: true,
            statusIcons: false
        },
        claims: {
            enabled: true,
            showOkState: true,
            showDaysLate: false,
            showIcons: true
        },
        calendar: {
            enabled: true,
            months: 6,
            navigationStep: 6,
            anchorMode: "current",
            collapsible: false,
            expandedByDefault: true
        },
        collectionItems: {
            enabled: true,
            openInNewTab: true,
            showItemLink: true,
            showEditLink: true,
            showItemStatus: true,
            showLostStatus: true,
            showCallnumber: true
        },
        loanRelease: {
            enabled: true,
            consultationStatus: 7,
            availableStatus: 0,
            clearLostStatus: true,
            requireSameSubscription: true,
            requireSameHomeLibrary: true,
            requireLaterAcquisitionDate: true,
            buttonLabelFr: "Rendre empruntable",
            buttonLabelEn: "Make available for loan"
        },
        weeding: {
            enabled: true,
            showPeriodicity: true,
            allowMark: true,
            allowDelete: true,
            notForLoanStatus: 1,
            lostStatus: 1,
            itemTypePrefix: "PERI",
            excludedBranches: ["ATP", "PATR"],
            excludedLocations: ["anim", "bureaux", "conservation", "Magasin", "reserv_adulte", "reserv_jeune", "tri"],
            periods: {
                mensuel: 400, hebdomadaire: 180, quotidien: 40,
                bihebdomadaire: 400, bimensuel: 400, bimestriel: 400,
                bisannuel: 400, deuxsem: 200, semestriel: 400,
                trimestriel: 400, troisparans: 400
            }
        },
        collectionSort: {
            enabled: true,
            direction: "desc"
        },
        subscriptionLength: {
            enabled: true,
            buttonLabelFr: "Calculer",
            buttonLabelEn: "Calculate",
            automatic: false,
            showDetails: true,
            issuesStartSource: "nextacquidate",
            fallbackToFirstPublication: true,
            fetchFrequencyDefinition: true,
            selectors: {
                startDate: "#acqui_date, [name=\"acqui_date\"]",
                endDate: "#to, [name=\"to\"]",
                nextIssueDate: "#nextacquidate, [name=\"nextacquidate\"]",
                frequency: "#frequency, [name=\"frequency\"]",
                subtype: "#subtype, [name=\"subtype\"]",
                length: "#sublength, [name=\"sublength\"]"
            }
        },
        bulletinage: {
            enabled: true,
            rewriteStatuses: true,
            statusCodes: "1,3,7,4,41,42,43,44,6"
        },
        priceContext: {
            enabled: true,
            ttlMinutes: 60,
            legacyMirror: true,
            storageKey: CONTEXT_STORAGE_KEY
        },
        receivingAssistant: {
            enabled: true,
            fill: {
                enabled: true,
                buttonLabelFr: "Remplir les champs",
                buttonLabelEn: "Fill fields",
                issueNumberEnabled: true,
                issueNumberFieldLabel: "v - Numéro de la revue",
                callNumberEnabled: true,
                callNumberFieldLabel: "k - Cote",
                priceEnabled: true,
                priceFieldLabel: "p - Prix",
                setPlannedDateToday: true,
                dateLocale: "fr-FR"
            },
            specialIssue: {
                enabled: true,
                buttonLabelFr: "Ajouter HS",
                buttonLabelEn: "Add special issue",
                marker: "HS"
            },
            duplicateIssue: {
                enabled: false,
                buttonLabelFr: "Ajouter Doublon",
                buttonLabelEn: "Add duplicate",
                marker: "(Doublon)"
            },
            presetsEnabled: true,
            presets: [
                {
                    id: "jeunesse-draguignan", legacyId: "exemplaire-jeunesse-button", enabled: true, labelFr: "Jeunesse Draguignan", labelEn: "Jeunesse Draguignan",
                    values: [
                        { enabled: true, fieldLabel: "q - Public", value: "j", mode: "legacy" },
                        { enabled: true, fieldLabel: "s - Etage", value: "RDC", mode: "legacy" },
                        { enabled: true, fieldLabel: "j - Sous localisation", value: "petit-kiosque", mode: "legacy" }
                    ]
                },
                {
                    id: "adulte-draguignan", legacyId: "exemplaire-adulte-button", enabled: true, labelFr: "Adulte Draguignan", labelEn: "Adulte Draguignan",
                    values: [
                        { enabled: true, fieldLabel: "q - Public", value: "a", mode: "legacy" },
                        { enabled: true, fieldLabel: "s - Etage", value: "RDC", mode: "legacy" },
                        { enabled: true, fieldLabel: "j - Sous localisation", value: "Le Kiosque", mode: "legacy" }
                    ]
                },
                {
                    id: "jeunesse-site-exterieur", legacyId: "exemplaire-jeunesse-site-exterieur-button", enabled: true, labelFr: "Jeunesse Site extérieur", labelEn: "Jeunesse Site extérieur",
                    values: [
                        { enabled: true, fieldLabel: "q - Public", value: "j", mode: "legacy" },
                        { enabled: true, fieldLabel: "s - Etage", value: "RDC", mode: "legacy" }
                    ]
                },
                {
                    id: "adulte-site-exterieur", legacyId: "exemplaire-adulte-site-exterieur-button", enabled: true, labelFr: "Adulte Site extérieur", labelEn: "Adulte Site extérieur",
                    values: [
                        { enabled: true, fieldLabel: "q - Public", value: "a", mode: "legacy" },
                        { enabled: true, fieldLabel: "s - Etage", value: "RDC", mode: "legacy" }
                    ]
                },
                {
                    id: "atp", legacyId: "ATP", enabled: true, labelFr: "ATP", labelEn: "ATP",
                    values: [
                        { enabled: true, fieldLabel: "q - Public", value: "a", mode: "legacy" },
                        { enabled: true, fieldLabel: "s - Etage", value: "2eme etage", mode: "legacy" }
                    ]
                }
            ],
            report: {
                enabled: true,
                buttonLabelFr: "Signaler un problème de bulletinage",
                buttonLabelEn: "Report a receiving problem",
                recipients: "",
                subjectTemplate: "Problème de Bulletinage : {SUBSCRIPTION} de {CALLNUMBER}",
                bodyTemplate: "Bonjour,\n\nJe vous signale un problème lors du bulletinage. Voici les informations présentes avant le bulletinage :\n\n- Nom de l'abonnement : {SUBSCRIPTION}\n- Côte : {CALLNUMBER}\n- Nom de l'utilisateur : {USER}\n- Numéro de fascicule : {ISSUE}\n- Date de publication : {DATE}\n- Code-barres : {BARCODE}\n\nMerci de renseigner ici les informations qui étaient attendues :\n\n- Nom de l'abonnement : {SUBSCRIPTION}\n- Côte : {CALLNUMBER}\n- Numéro de fascicule : ____________\n- Date de publication : ____________\n- Code-barres : ____________\n- Autres remarques :\n\n\nCordialement,"
            },
            protection: {
                enabled: true,
                overlayOnFascicleRows: true,
                requireAddItemLink: true,
                unlockShortcutEnabled: true,
                unlockKey: "U",
                shortcutScope: "all",
                fields: [
                    { enabled: true, label: "b - Site Propriétaire" },
                    { enabled: true, label: "c - Site actuel" },
                    { enabled: true, label: "s - Etage" },
                    { enabled: true, label: "e - Localisation" },
                    { enabled: true, label: "j - Sous localisation" },
                    { enabled: true, label: "k - Cote" },
                    { enabled: true, label: "r - Type de document" },
                    { enabled: true, label: "q - Public" },
                    { enabled: true, label: "t - Achat/don" },
                    { enabled: true, label: "A - Fournisseur" },
                    { enabled: true, label: "p - Prix" },
                    { enabled: true, label: "u - Note interne" },
                    { enabled: true, label: "v - Numéro de la revue" },
                    { enabled: true, label: "x - Note OPAC" }
                ]
            },
            buttons: {
                background: "#4CAF50",
                hoverBackground: "#45a049",
                color: "#ffffff"
            }
        },
        compatibility: {
            renamePlannedDate: true,
            legacySectionToggles: true
        },
        colors: {
            arrived: "#008000",
            expected: "#ffa500",
            late: "#ff0000",
            claimed: "#ff0000",
            missing: "#ff0000",
            other: "#ff0000"
        }
    };

    const STATUS_ALIASES = {
        arrived: ["arrivé", "arrive", "arrived", "received", "reçu", "recu"],
        expected: ["attendu", "expected"],
        late: ["en retard", "retard", "late", "overdue"],
        claimed: ["réclamé", "reclame", "claimed", "claim sent"],
        missing: ["manquant", "missing", "lost"],
        other: []
    };

    const STATUS_ICONS = {
        arrived: "✓",
        expected: "⌛",
        late: "!",
        claimed: "✉",
        missing: "?",
        other: "•"
    };

    const COLUMN_ALIASES = {
        title: [
            "titre", "title", "fascicule", "issue", "numéro", "numero", "number",
            "publication", "serial", "numéro de fascicule", "issue number"
        ],
        date: [
            "date prévue", "date prevue", "planned date", "expected date",
            "date de publication", "publication date", "date de réception",
            "date de reception", "receive date", "received date", "date"
        ],
        status: [
            "statut", "status", "état", "etat", "state"
        ]
    };

    const PRICE_COLUMN_ALIASES = [
        "prix fascicule", "prix du fascicule", "issue price", "price per issue", "unit price"
    ];

    const PRICE_LABEL_ALIASES = [
        "prix fascicule", "prix du fascicule", "prix par fascicule", "prix au fascicule",
        "prix unitaire", "issue price", "price per issue", "unit price"
    ];

    const SECTION_META = {
        information: { panelId: "subscription_info_panel", tabId: "subscription_info-tab" },
        planning: { panelId: "subscription_planning_panel", tabId: "subscription_planning-tab" },
        issues: { panelId: "subscription_issues_panel", tabId: "subscription_issues-tab" },
        summary: { panelId: "subscription_summary_panel", tabId: "subscription_summary-tab" }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let observers = [];
    let mutationTimer = null;
    let initialized = false;
    let renamedDateTextNodes = [];
    let collectionRetryTimer = null;
    const collectionOriginalOrders = new WeakMap();
    const frequencyDefinitionCache = new Map();
    const detailPriceFetches = new Map();
    let subscriptionLengthListeners = [];

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return Boolean(value) && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) {
            return Array.isArray(override) ? clone(override) : clone(base);
        }
        if (!isObject(base)) {
            return override === undefined ? clone(base) : clone(override);
        }
        const out = clone(base);
        if (!isObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            out[key] = key in base ? deepMerge(base[key], override[key]) : clone(override[key]);
        });
        return out;
    }

    function normalizeConfig(config) {
        const merged = deepMerge(DEFAULT_CONFIG, config || {});

        const storedPages = Array.isArray(merged.pages) ? merged.pages : [];
        merged.pages = DEFAULT_CONFIG.pages.map(function (defaultPage) {
            const existing = storedPages.find(function (page) { return page && page.id === defaultPage.id; });
            return Object.assign({}, defaultPage, existing || {});
        });

        const storedSections = merged.layout && Array.isArray(merged.layout.sections)
            ? merged.layout.sections
            : [];
        merged.layout = Object.assign({}, DEFAULT_CONFIG.layout, merged.layout || {});
        merged.layout.mode = "historical-three-columns";
        merged.layout.sections = DEFAULT_CONFIG.layout.sections.map(function (defaultSection) {
            const existing = storedSections.find(function (section) { return section && section.key === defaultSection.key; });
            return Object.assign({}, defaultSection, existing || {});
        });

        if (!merged.receivingAssistant || typeof merged.receivingAssistant !== "object") {
            merged.receivingAssistant = clone(DEFAULT_CONFIG.receivingAssistant);
        }
        if (!Array.isArray(merged.receivingAssistant.presets)) {
            merged.receivingAssistant.presets = clone(DEFAULT_CONFIG.receivingAssistant.presets);
        }
        if (!merged.receivingAssistant.protection || typeof merged.receivingAssistant.protection !== "object") {
            merged.receivingAssistant.protection = clone(DEFAULT_CONFIG.receivingAssistant.protection);
        }
        if (!Array.isArray(merged.receivingAssistant.protection.fields)) {
            merged.receivingAssistant.protection.fields = clone(DEFAULT_CONFIG.receivingAssistant.protection.fields);
        }

        merged.subscriptionLength = Object.assign(
            {},
            DEFAULT_CONFIG.subscriptionLength,
            merged.subscriptionLength || {}
        );
        merged.subscriptionLength.selectors = Object.assign(
            {},
            DEFAULT_CONFIG.subscriptionLength.selectors,
            merged.subscriptionLength.selectors || {}
        );
        if (!["nextacquidate", "acqui_date"].includes(merged.subscriptionLength.issuesStartSource)) {
            merged.subscriptionLength.issuesStartSource = DEFAULT_CONFIG.subscriptionLength.issuesStartSource;
        }

        return merged;
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            } catch (_) {}
        }
        const lang = String(document.documentElement.lang || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return detectLanguage() === "en" ? en : fr;
    }

    function currentPageDefinition() {
        if (window.location.pathname === DETAIL_PAGE_PATH) return { id: DETAIL_PAGE_ID, path: DETAIL_PAGE_PATH };
        if (window.location.pathname === SEARCH_PAGE_PATH) return { id: SEARCH_PAGE_ID, path: SEARCH_PAGE_PATH };
        if (window.location.pathname === EDIT_PAGE_PATH) return { id: EDIT_PAGE_ID, path: EDIT_PAGE_PATH };
        if (window.location.pathname === COLLECTION_PAGE_PATH) return { id: COLLECTION_PAGE_ID, path: COLLECTION_PAGE_PATH };
        if (window.location.pathname === ADD_PAGE_PATH) return { id: ADD_PAGE_ID, path: ADD_PAGE_PATH };
        return null;
    }

    function isPageEnabled(config, pageId) {
        const cfg = config || currentConfig;
        if (!cfg || cfg.enabled === false) return false;
        const current = currentPageDefinition();
        const wantedId = pageId || (current && current.id);
        if (!wantedId) return false;
        const pages = Array.isArray(cfg.pages) ? cfg.pages : [];
        const page = pages.find(function (item) { return item && item.id === wantedId; });
        if (!page || page.enabled === false) return false;
        if (wantedId === DETAIL_PAGE_ID) return page.path === DETAIL_PAGE_PATH;
        if (wantedId === SEARCH_PAGE_ID) return page.path === SEARCH_PAGE_PATH;
        if (wantedId === EDIT_PAGE_ID) return page.path === EDIT_PAGE_PATH;
        if (wantedId === COLLECTION_PAGE_ID) return page.path === COLLECTION_PAGE_PATH;
        if (wantedId === ADD_PAGE_ID) return page.path === ADD_PAGE_PATH;
        return false;
    }

    function safeQuery(root, selector) {
        try {
            return root ? root.querySelector(selector) : null;
        } catch (_) {
            return null;
        }
    }

    function localWaitForSelector(selector, timeout) {
        const max = Number(timeout) > 0 ? Number(timeout) : 5000;
        return new Promise(function (resolve, reject) {
            const immediate = document.querySelector(selector);
            if (immediate) {
                resolve(immediate);
                return;
            }

            let finished = false;
            let timer = null;
            const observer = new MutationObserver(function () {
                const found = document.querySelector(selector);
                if (!found) return;
                finish(resolve, found);
            });

            function finish(callback, value) {
                if (finished) return;
                finished = true;
                observer.disconnect();
                if (timer) clearTimeout(timer);
                callback(value);
            }

            observer.observe(document.documentElement, {
                childList: true,
                subtree: true
            });

            timer = window.setTimeout(function () {
                finish(reject, new Error("timeout"));
            }, max);
        });
    }

    const waitForSelector =
        window.KOHA_UTILS && typeof window.KOHA_UTILS.waitForSelector === "function"
            ? window.KOHA_UTILS.waitForSelector
            : localWaitForSelector;

    function installStyles() {
        if (document.getElementById("pmk029-serials-style")) return;

        const style = document.createElement("style");
        style.id = "pmk029-serials-style";
        style.textContent = `
            .pmk029-status-badge-target {
                display: inline-block !important;
                max-width: 100%;
                padding: 4px 8px !important;
                border-radius: 12px !important;
                background: var(--pmk029-status-bg) !important;
                color: var(--pmk029-status-fg) !important;
                font-weight: bold !important;
                line-height: 1.25 !important;
                white-space: normal;
            }
            .tableau-fasci .pmk029-status-badge-target {
                padding: 2px 5px !important;
                border-radius: 4px !important;
                font-size: .9em !important;
                font-weight: normal !important;
            }
            .pmk029-status-badge-target[data-pmk029-icon]::before {
                content: attr(data-pmk029-icon);
                flex: 0 0 auto;
                font-weight: 700;
            }
            .pmk029-claim-note {
                display: block;
                margin-top: .35rem;
                padding: .32rem .5rem;
                border-radius: .25rem;
                font-size: .875rem;
                line-height: 1.35;
                max-width: 32rem;
            }
            .pmk029-claim-note.is-due {
                border-left: 4px solid #dc3545;
                background: rgba(220, 53, 69, .08);
            }
            .pmk029-claim-note.is-ok {
                border-left: 4px solid #198754;
                background: rgba(25, 135, 84, .08);
            }
            .pmk029-calendar-panel {
                margin-top: 1rem;
                border: 1px solid #d7dce0;
                border-radius: .35rem;
                background: #fff;
                overflow: hidden;
            }
            .pmk029-calendar-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: .75rem;
                padding: .65rem .8rem;
                background: #f5f6f7;
                border-bottom: 1px solid #d7dce0;
            }
            .pmk029-calendar-title-wrap {
                display: flex;
                align-items: center;
                gap: .5rem;
                min-width: 0;
            }
            .pmk029-calendar-title {
                margin: 0;
                font-size: 1rem;
                font-weight: 600;
            }
            .pmk029-calendar-actions {
                display: flex;
                align-items: center;
                gap: .25rem;
                flex: 0 0 auto;
            }
            .pmk029-calendar-body {
                padding: .75rem;
            }
            .pmk029-calendar-navigation {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: .75rem;
                margin-bottom: .75rem;
            }
            .pmk029-calendar-range {
                margin: 0;
                text-align: center;
                font-size: .95rem;
                font-weight: 600;
            }
            .pmk029-calendar-months {
                display: grid;
                gap: 1rem;
            }
            .pmk029-month-block h4 {
                margin: 0 0 .4rem;
                font-size: .95rem;
            }
            .pmk029-calendar-grid {
                display: grid;
                grid-template-columns: repeat(7, minmax(0, 1fr));
                border-top: 1px solid #dee2e6;
                border-left: 1px solid #dee2e6;
            }
            .pmk029-calendar-weekday,
            .pmk029-calendar-day {
                min-width: 0;
                border-right: 1px solid #dee2e6;
                border-bottom: 1px solid #dee2e6;
                padding: .35rem;
            }
            .pmk029-calendar-weekday {
                background: #f8f9fa;
                text-align: center;
                font-weight: 600;
                font-size: .8rem;
            }
            .pmk029-calendar-day {
                min-height: 4.6rem;
            }
            .pmk029-calendar-day.is-empty {
                background: #fafafa;
            }
            .pmk029-day-number {
                display: block;
                margin-bottom: .25rem;
                font-weight: 600;
                font-size: .82rem;
            }
            .pmk029-event-list {
                margin: 0;
                padding: 0;
                list-style: none;
            }
            .pmk029-event {
                display: block;
                margin: 0 0 .2rem;
                padding: .18rem .3rem;
                border-radius: .2rem;
                background: var(--pmk029-event-bg);
                color: var(--pmk029-event-fg);
                font-size: .75rem;
                line-height: 1.25;
                overflow-wrap: anywhere;
            }
            .pmk029-calendar-warning {
                margin: 0 0 .75rem;
            }
            .pmk029-agenda {
                display: none;
            }
            .pmk029-agenda-month + .pmk029-agenda-month {
                margin-top: 1rem;
            }
            .pmk029-agenda-month h4 {
                margin: 0 0 .35rem;
                font-size: .95rem;
            }
            .pmk029-agenda-list {
                margin: 0;
                padding: 0;
                list-style: none;
                border-top: 1px solid #e5e7e9;
            }
            .pmk029-agenda-item {
                display: grid;
                grid-template-columns: minmax(5.5rem, auto) 1fr;
                gap: .65rem;
                padding: .5rem 0;
                border-bottom: 1px solid #e5e7e9;
            }
            .pmk029-agenda-date {
                font-weight: 600;
            }
            .pmk029-agenda-event {
                display: inline-flex;
                align-items: center;
                gap: .4rem;
                max-width: 100%;
                margin: 0 .25rem .2rem 0;
                padding: .18rem .38rem;
                border-radius: .25rem;
                background: var(--pmk029-event-bg);
                color: var(--pmk029-event-fg);
                font-size: .82rem;
                overflow-wrap: anywhere;
            }
            @media (max-width: 767.98px) {
                .pmk029-calendar-header,
                .pmk029-calendar-navigation {
                    align-items: stretch;
                }
                .pmk029-calendar-header {
                    flex-wrap: wrap;
                }
                .pmk029-calendar-title-wrap {
                    flex: 1 1 14rem;
                }
                .pmk029-calendar-actions {
                    margin-left: auto;
                }
                .pmk029-calendar-navigation {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                }
                .pmk029-calendar-range {
                    grid-column: 1 / -1;
                    grid-row: 1;
                }
                .pmk029-calendar-grid-wrap {
                    display: none;
                }
                .pmk029-agenda {
                    display: block;
                }
                .pmk029-agenda-item {
                    grid-template-columns: 1fr;
                    gap: .25rem;
                }
                .pmk029-status-badge-target {
                    border-radius: .3rem !important;
                }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function removeStyles() {
        const style = document.getElementById("pmk029-serials-style");
        if (style) style.remove();
    }

    function contrastColor(hex) {
        const value = String(hex || "").replace("#", "");
        if (!/^[0-9a-f]{6}$/i.test(value)) return "#ffffff";
        const r = parseInt(value.slice(0, 2), 16);
        const g = parseInt(value.slice(2, 4), 16);
        const b = parseInt(value.slice(4, 6), 16);
        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        return luminance > 0.62 ? "#212529" : "#ffffff";
    }

    function statusKeyFromText(value) {
        const normalized = normalizeText(value);
        if (!normalized) return "other";

        const keys = ["arrived", "expected", "late", "claimed", "missing"];
        for (const key of keys) {
            const aliases = STATUS_ALIASES[key];
            if (aliases.some(function (alias) {
                const n = normalizeText(alias);
                return normalized === n || normalized.indexOf(n) !== -1;
            })) {
                return key;
            }
        }
        return "other";
    }

    function getColor(key) {
        const colors = currentConfig && currentConfig.colors ? currentConfig.colors : DEFAULT_CONFIG.colors;
        const value = colors && colors[key] ? String(colors[key]) : DEFAULT_CONFIG.colors[key] || DEFAULT_CONFIG.colors.other;
        return /^#[0-9a-f]{6}$/i.test(value) ? value : DEFAULT_CONFIG.colors[key] || DEFAULT_CONFIG.colors.other;
    }

    function getHeaderRow(table) {
        if (!table) return null;

        // Koha peut rendre les en-têtes soit dans <thead>, soit directement
        // dans le premier <tr> du <tbody> (cas réel subscription-detail.pl
        // observé sur l'installation d’origine en Koha 25.11).
        const theadRow = safeQuery(table, "thead tr:last-child") || safeQuery(table, "thead tr");
        if (theadRow && theadRow.querySelector("th")) return theadRow;

        const rows = Array.from(table.rows || []);
        return rows.find(function (row) {
            const thCount = row.querySelectorAll("th").length;
            const tdCount = row.querySelectorAll("td").length;
            return thCount > 0 && tdCount === 0;
        }) || rows.find(function (row) {
            return Boolean(row.querySelector("th"));
        }) || null;
    }

    function getTableHeaders(table) {
        const row = getHeaderRow(table);
        return row ? Array.from(row.cells || []) : [];
    }

    function getDataRows(table) {
        if (!table) return [];
        return Array.from(table.querySelectorAll("tbody tr")).filter(function (row) {
            return Boolean(row.querySelector("td"));
        });
    }

    function headerIdentity(header) {
        if (!header) return "";
        return normalizeText([
            header.getAttribute("data-colname") || "",
            header.getAttribute("data-column") || "",
            header.id || "",
            header.className || "",
            header.textContent || ""
        ].join(" "));
    }

    function resolveColumnIndex(table, type) {
        const aliases = (COLUMN_ALIASES[type] || []).map(normalizeText);
        const headers = getTableHeaders(table);

        for (let i = 0; i < headers.length; i += 1) {
            const identity = headerIdentity(headers[i]);
            if (!identity) continue;
            const found = aliases.some(function (alias) {
                return identity === alias || identity.indexOf(alias) !== -1;
            });
            if (found) return i;
        }

        return historicalFallbackIndex(table, type);
    }

    function historicalFallbackIndex(table, type) {
        const firstRow = getDataRows(table)[0] || null;
        if (!firstRow || !firstRow.cells) return -1;
        const cells = firstRow.cells;
        const isYearTable = table.classList.contains("subscription-year-table");
        const isFascicleTable = isLikelyFascicleTable(table);

        if (isYearTable && type === "status" && cells.length >= 6) {
            // Parité legacy 029 : la sixième colonne était toujours traitée comme
            // colonne de statut, même pour une valeur inconnue (alors colorée en rouge).
            return 5;
        }

        if (isFascicleTable && cells.length >= 5) {
            if (type === "title") return 0;
            if (type === "date") {
                return parseDateText(cells[1].textContent) ? 1 : -1;
            }
            // Parité legacy 029 : la cinquième colonne de .tableau-fasci est le statut.
            if (type === "status") return 4;
        }

        return -1;
    }

    function getCell(row, index) {
        if (!row || !row.cells || index < 0 || !row.cells[index]) return null;
        return row.cells[index];
    }

    function getRawStatusText(cell) {
        if (!cell) return "";
        const cloneCell = cell.cloneNode(true);
        cloneCell.querySelectorAll(".pmk029-claim-note").forEach(function (node) { node.remove(); });
        return String(cloneCell.textContent || "").replace(/\s+/g, " ").trim();
    }

    function findBadgeTarget(cell, rawStatus) {
        if (!cell) return null;
        const candidates = Array.from(cell.querySelectorAll(".status-container, span, div"));
        const normalized = normalizeText(rawStatus);
        for (const candidate of candidates) {
            if (candidate.classList.contains("pmk029-status-generated")) return candidate;
            if (candidate.querySelector("button, a, input, select, textarea")) continue;
            if (normalizeText(candidate.textContent) === normalized) return candidate;
        }

        // Fallback prudent : si la cellule ne contient que du texte, on l'enveloppe
        // sans toucher à une éventuelle structure interactive Koha.
        if (!cell.querySelector("*")) {
            const generated = document.createElement("span");
            generated.className = "pmk029-status-generated";
            generated.textContent = rawStatus;
            cell.textContent = "";
            cell.appendChild(generated);
            return generated;
        }

        return null;
    }

    function decorateStatusCell(cell) {
        if (!cell) return "other";
        const raw = getRawStatusText(cell);
        const key = statusKeyFromText(raw);

        cell.dataset.pmk029StatusKey = key;
        const oldTarget = cell.querySelector(".pmk029-status-badge-target");
        if (oldTarget && oldTarget !== cell) {
            oldTarget.classList.remove("pmk029-status-badge-target");
            oldTarget.style.removeProperty("--pmk029-status-bg");
            oldTarget.style.removeProperty("--pmk029-status-fg");
            oldTarget.removeAttribute("data-pmk029-icon");
        }
        if (cell.classList.contains("pmk029-status-badge-target")) {
            cell.classList.remove("pmk029-status-badge-target");
            cell.style.removeProperty("--pmk029-status-bg");
            cell.style.removeProperty("--pmk029-status-fg");
            cell.removeAttribute("data-pmk029-icon");
        }

        if (!(currentConfig.display && currentConfig.display.statusBadges !== false)) {
            return key;
        }

        const target = findBadgeTarget(cell, raw);
        if (!target) return key;
        const bg = getColor(key);
        target.classList.add("pmk029-status-badge-target");
        target.style.setProperty("--pmk029-status-bg", bg);
        target.style.setProperty("--pmk029-status-fg", contrastColor(bg));

        if (currentConfig.display.statusIcons !== false) {
            target.setAttribute("data-pmk029-icon", STATUS_ICONS[key] || STATUS_ICONS.other);
        } else {
            target.removeAttribute("data-pmk029-icon");
        }

        return key;
    }

    function parseDateText(value) {
        const text = String(value || "").trim();
        if (!text) return null;

        let match = text.match(/\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b/);
        if (match) {
            return createDate(Number(match[1]), Number(match[2]), Number(match[3]));
        }

        match = text.match(/\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\b/);
        if (match) {
            const a = Number(match[1]);
            const b = Number(match[2]);
            const year = Number(match[3]);
            let day;
            let month;

            if (a > 12) {
                day = a;
                month = b;
            } else if (b > 12) {
                month = a;
                day = b;
            } else if (detectLanguage() === "en") {
                month = a;
                day = b;
            } else {
                day = a;
                month = b;
            }
            return createDate(year, month, day);
        }

        return null;
    }

    function createDate(year, month, day) {
        if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
        if (month < 1 || month > 12 || day < 1 || day > 31) return null;
        const date = new Date(year, month - 1, day, 12, 0, 0, 0);
        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) return null;
        return date;
    }

    function dateOnly(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
    }

    function addDays(date, days) {
        const result = dateOnly(date);
        result.setDate(result.getDate() + Number(days || 0));
        return result;
    }

    function dayDiff(later, earlier) {
        const ms = dateOnly(later).getTime() - dateOnly(earlier).getTime();
        return Math.round(ms / 86400000);
    }

    function formatDate(date) {
        try {
            return new Intl.DateTimeFormat(detectLanguage() === "en" ? "en-GB" : "fr-FR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric"
            }).format(date);
        } catch (_) {
            return [
                String(date.getDate()).padStart(2, "0"),
                String(date.getMonth() + 1).padStart(2, "0"),
                date.getFullYear()
            ].join("/");
        }
    }

    function getGracePeriod() {
        const candidates = Array.from(document.querySelectorAll(
            "div.rows ol li, div.rows ul li, .rows > ol > li, .rows > ul > li"
        ));
        const aliases = [
            "période de grâce", "periode de grace", "grace period"
        ].map(normalizeText);

        for (const item of candidates) {
            const label = safeQuery(item, ".label, .field-label, dt");
            const labelText = normalizeText(label ? label.textContent : item.textContent);
            const matches = aliases.some(function (alias) {
                return labelText.indexOf(alias) !== -1;
            });
            if (!matches) continue;

            const fullText = String(item.textContent || "");
            const numbers = fullText.match(/-?\d+/g);
            if (!numbers || !numbers.length) continue;
            const value = Number(numbers[numbers.length - 1]);
            if (Number.isFinite(value) && value >= 0) return value;
        }

        return null;
    }

    function removeClaimNotes(root) {
        (root || document).querySelectorAll(".pmk029-claim-note").forEach(function (node) {
            node.remove();
        });
    }

    function addClaimNote(cell, state, dueDate, overdueDays) {
        if (!cell) return;
        const note = document.createElement("div");
        note.className = "pmk029-claim-note " + (state === "due" ? "is-due" : "is-ok");
        note.setAttribute("data-pmk029-claim", "1");

        const showIcon = !(currentConfig.claims && currentConfig.claims.showIcons === false);
        if (state === "due") {
            const daysPart = currentConfig.claims.showDaysLate !== false && overdueDays > 0
                ? t(
                    " — échéance dépassée de " + overdueDays + " jour" + (overdueDays > 1 ? "s" : ""),
                    " — " + overdueDays + " day" + (overdueDays > 1 ? "s" : "") + " overdue"
                )
                : "";
            note.textContent = (showIcon ? "❌ " : "") + t("À réclamer", "Claim due") + daysPart;
        } else {
            note.textContent = (showIcon ? "✅ " : "") + t(
                "Aucune réclamation à faire — échéance le " + formatDate(dueDate),
                "No claim needed — due on " + formatDate(dueDate)
            );
        }

        cell.appendChild(note);
    }

    function processClaims(table, indexes, gracePeriod) {
        if (!(currentConfig.claims && currentConfig.claims.enabled !== false)) return;
        if (gracePeriod === null || gracePeriod === undefined) return;
        if (indexes.status < 0 || indexes.date < 0) return;

        const today = dateOnly(new Date());
        getDataRows(table).forEach(function (row) {
            const statusCell = getCell(row, indexes.status);
            const dateCell = getCell(row, indexes.date);
            if (!statusCell || !dateCell) return;

            const key = statusKeyFromText(getRawStatusText(statusCell));
            if (key !== "expected") return;

            const publicationDate = parseDateText(dateCell.textContent);
            if (!publicationDate) return;

            const dueDate = addDays(publicationDate, gracePeriod);
            const overdueDays = dayDiff(today, dueDate);

            if (today.getTime() > dueDate.getTime()) {
                addClaimNote(statusCell, "due", dueDate, overdueDays);
            } else if (currentConfig.claims.showOkState !== false) {
                addClaimNote(statusCell, "ok", dueDate, 0);
            }
        });
    }

    function processTable(table, gracePeriod) {
        if (!table || !table.tBodies || !table.tBodies.length) return null;

        const indexes = {
            title: resolveColumnIndex(table, "title"),
            date: resolveColumnIndex(table, "date"),
            status: resolveColumnIndex(table, "status")
        };

        if (indexes.status < 0) return indexes;

        getDataRows(table).forEach(function (row) {
            const statusCell = getCell(row, indexes.status);
            if (statusCell) decorateStatusCell(statusCell);
        });

        processClaims(table, indexes, gracePeriod);
        return indexes;
    }

    function isLikelyFascicleTable(table) {
        if (!(table instanceof HTMLTableElement)) return false;
        if (table.closest("#subscription_issues_panel, .tableau-fasci")) return true;
        if (table.classList.contains("subscription-year-table")) return false;
        const headers = getTableHeaders(table);
        const identities = headers.map(headerIdentity);
        const hasTitle = identities.some(function (identity) {
            return COLUMN_ALIASES.title.some(function (alias) { return identity.indexOf(normalizeText(alias)) !== -1; });
        });
        const hasDate = identities.some(function (identity) {
            return COLUMN_ALIASES.date.some(function (alias) { return identity.indexOf(normalizeText(alias)) !== -1; });
        });
        const hasStatus = identities.some(function (identity) {
            return COLUMN_ALIASES.status.some(function (alias) { return identity.indexOf(normalizeText(alias)) !== -1; });
        });
        return hasTitle && hasDate && hasStatus;
    }

    function addUniqueTable(found, table) {
        if (table instanceof HTMLTableElement && found.indexOf(table) === -1) found.push(table);
    }

    function getRelevantTables() {
        const found = [];
        document.querySelectorAll("#subscription_issues_panel table, .tableau-fasci table, table.subscription-year-table").forEach(function (table) {
            addUniqueTable(found, table);
        });
        if (!found.some(isLikelyFascicleTable)) {
            document.querySelectorAll("#subscription_info_panel table, .tab-content table").forEach(function (table) {
                if (isLikelyFascicleTable(table)) addUniqueTable(found, table);
            });
        }
        return found;
    }

    function getPrimaryFascicleTable() {
        const nativeTable = document.querySelector("#subscription_issues_panel table");
        if (nativeTable instanceof HTMLTableElement && isLikelyFascicleTable(nativeTable)) return nativeTable;
        const legacyTable = document.querySelector(".tableau-fasci table");
        if (legacyTable instanceof HTMLTableElement && isLikelyFascicleTable(legacyTable)) return legacyTable;
        return getRelevantTables().find(isLikelyFascicleTable) || null;
    }

    function extractEvents(table) {
        if (!table) return [];
        const indexes = {
            title: resolveColumnIndex(table, "title"),
            date: resolveColumnIndex(table, "date"),
            status: resolveColumnIndex(table, "status")
        };
        if (indexes.title < 0 || indexes.date < 0 || indexes.status < 0) return [];

        const events = [];
        getDataRows(table).forEach(function (row, rowIndex) {
            const titleCell = getCell(row, indexes.title);
            const dateCell = getCell(row, indexes.date);
            const statusCell = getCell(row, indexes.status);
            if (!titleCell || !dateCell || !statusCell) return;

            const date = parseDateText(dateCell.textContent);
            if (!date) return;

            const title = String(titleCell.textContent || "").replace(/\s+/g, " ").trim();
            if (!title) return;

            events.push({
                id: "pmk029-event-" + rowIndex + "-" + date.getTime(),
                title: title,
                date: dateOnly(date),
                status: statusKeyFromText(getRawStatusText(statusCell))
            });
        });
        return events;
    }

    function monthLabel(year, month) {
        return new Intl.DateTimeFormat(detectLanguage() === "en" ? "en-GB" : "fr-FR", {
            month: "long",
            year: "numeric"
        }).format(new Date(year, month, 1));
    }

    function weekdayLabels() {
        return detectLanguage() === "en"
            ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            : ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
    }

    function getWindowMonths(anchorYear, anchorMonth, count) {
        const months = [];
        for (let offset = 0; offset < count; offset += 1) {
            const cursor = new Date(anchorYear, anchorMonth - offset, 1);
            months.push({ year: cursor.getFullYear(), month: cursor.getMonth() });
        }
        return months;
    }

    function eventsForMonth(events, year, month) {
        return events.filter(function (event) {
            return event.date.getFullYear() === year && event.date.getMonth() === month;
        });
    }

    function eventChip(event, className) {
        const node = document.createElement("span");
        node.className = className;
        const bg = getColor(event.status);
        node.style.setProperty("--pmk029-event-bg", bg);
        node.style.setProperty("--pmk029-event-fg", contrastColor(bg));
        node.textContent = (currentConfig.display.statusIcons !== false ? (STATUS_ICONS[event.status] || STATUS_ICONS.other) + " " : "") + event.title;
        node.title = event.title;
        return node;
    }

    function renderCalendarMonth(container, events, year, month) {
        const block = document.createElement("section");
        block.className = "pmk029-month-block";

        const heading = document.createElement("h4");
        heading.textContent = monthLabel(year, month);
        block.appendChild(heading);

        const wrap = document.createElement("div");
        wrap.className = "pmk029-calendar-grid-wrap";

        const grid = document.createElement("div");
        grid.className = "pmk029-calendar-grid";
        weekdayLabels().forEach(function (label) {
            const day = document.createElement("div");
            day.className = "pmk029-calendar-weekday";
            day.textContent = label;
            grid.appendChild(day);
        });

        const first = new Date(year, month, 1);
        const firstDay = (first.getDay() + 6) % 7;
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        for (let i = 0; i < firstDay; i += 1) {
            const empty = document.createElement("div");
            empty.className = "pmk029-calendar-day is-empty";
            empty.setAttribute("aria-hidden", "true");
            grid.appendChild(empty);
        }

        for (let dayNumber = 1; dayNumber <= daysInMonth; dayNumber += 1) {
            const day = document.createElement("div");
            day.className = "pmk029-calendar-day";

            const number = document.createElement("span");
            number.className = "pmk029-day-number";
            number.textContent = String(dayNumber);
            day.appendChild(number);

            const list = document.createElement("ul");
            list.className = "pmk029-event-list";

            events.filter(function (event) {
                return event.date.getDate() === dayNumber;
            }).forEach(function (event) {
                const li = document.createElement("li");
                const chip = eventChip(event, "pmk029-event");
                li.appendChild(chip);
                list.appendChild(li);
            });

            day.appendChild(list);
            grid.appendChild(day);
        }

        wrap.appendChild(grid);
        block.appendChild(wrap);
        container.appendChild(block);
    }

    function renderAgendaMonth(container, events, year, month) {
        const block = document.createElement("section");
        block.className = "pmk029-agenda-month";

        const heading = document.createElement("h4");
        heading.textContent = monthLabel(year, month);
        block.appendChild(heading);

        const list = document.createElement("ul");
        list.className = "pmk029-agenda-list";

        if (!events.length) {
            const li = document.createElement("li");
            li.className = "pmk029-agenda-item";
            li.textContent = t("Aucun fascicule daté pour ce mois.", "No dated issue for this month.");
            list.appendChild(li);
        } else {
            const grouped = new Map();
            events.slice().sort(function (a, b) { return a.date - b.date; }).forEach(function (event) {
                const key = event.date.getFullYear() + "-" + event.date.getMonth() + "-" + event.date.getDate();
                if (!grouped.has(key)) grouped.set(key, []);
                grouped.get(key).push(event);
            });

            grouped.forEach(function (dayEvents) {
                const li = document.createElement("li");
                li.className = "pmk029-agenda-item";

                const date = document.createElement("div");
                date.className = "pmk029-agenda-date";
                date.textContent = new Intl.DateTimeFormat(detectLanguage() === "en" ? "en-GB" : "fr-FR", {
                    weekday: "short",
                    day: "2-digit",
                    month: "2-digit"
                }).format(dayEvents[0].date);

                const eventWrap = document.createElement("div");
                dayEvents.forEach(function (event) {
                    eventWrap.appendChild(eventChip(event, "pmk029-agenda-event"));
                });

                li.appendChild(date);
                li.appendChild(eventWrap);
                list.appendChild(li);
            });
        }

        block.appendChild(list);
        container.appendChild(block);
    }

    function buildCalendarPanel(table) {
        if (!(currentConfig.calendar && currentConfig.calendar.enabled !== false)) return;
        if (!table) return;

        const holder = table.closest("#subscription_issues_panel, .tableau-fasci") || table;
        if (!holder) return;

        let panel = document.getElementById("pmk029-calendar-panel");
        if (!panel) {
            panel = document.createElement("section");
            panel.id = "pmk029-calendar-panel";
            panel.className = "pmk029-calendar-panel";
            panel.setAttribute("data-pmk-module", MODULE_ID);
            panel.setAttribute("data-pmk-version", MODULE_VERSION);
            if (holder.id === "subscription_issues_panel" || holder.classList.contains("tableau-fasci")) {
                holder.appendChild(panel);
            } else if (holder.parentNode) {
                holder.parentNode.insertBefore(panel, holder.nextSibling);
            } else {
                return;
            }
        }

        const oldAnchor = panel.dataset.anchorDate;
        const initialEvents = extractEvents(table);
        let anchorDate;
        if (oldAnchor && /^\d{4}-\d{2}$/.test(oldAnchor)) {
            const parts = oldAnchor.split("-").map(Number);
            anchorDate = new Date(parts[0], parts[1] - 1, 1);
        } else if (currentConfig.calendar && currentConfig.calendar.anchorMode === "latest" && initialEvents.length) {
            const latest = initialEvents.reduce(function (best, event) {
                return !best || event.date > best.date ? event : best;
            }, null);
            anchorDate = new Date(latest.date.getFullYear(), latest.date.getMonth(), 1);
        } else {
            // Valeur historique : mois civil courant, puis les mois précédents.
            anchorDate = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        }

        panel.innerHTML = "";

        const header = document.createElement("div");
        header.className = "pmk029-calendar-header";

        const titleWrap = document.createElement("div");
        titleWrap.className = "pmk029-calendar-title-wrap";
        const title = document.createElement("h3");
        title.className = "pmk029-calendar-title";
        title.textContent = t("Calendrier des fascicules", "Issue calendar");
        titleWrap.appendChild(title);

        const actions = document.createElement("div");
        actions.className = "pmk029-calendar-actions";

        const body = document.createElement("div");
        body.className = "pmk029-calendar-body";
        body.id = "pmk029-calendar-body";

        const collapsible = currentConfig.calendar.collapsible !== false;
        let expanded = currentConfig.calendar.expandedByDefault !== false;
        if (panel.dataset.expanded === "0") expanded = false;
        if (panel.dataset.expanded === "1") expanded = true;

        if (collapsible) {
            const toggle = document.createElement("button");
            toggle.type = "button";
            toggle.className = "btn btn-default btn-sm";
            toggle.setAttribute("aria-controls", body.id);
            toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
            toggle.innerHTML = '<i class="fa fa-chevron-' + (expanded ? "up" : "down") + '" aria-hidden="true"></i> <span>' +
                (expanded ? t("Replier", "Collapse") : t("Déplier", "Expand")) + "</span>";
            toggle.addEventListener("click", function () {
                expanded = !expanded;
                panel.dataset.expanded = expanded ? "1" : "0";
                body.hidden = !expanded;
                toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
                toggle.innerHTML = '<i class="fa fa-chevron-' + (expanded ? "up" : "down") + '" aria-hidden="true"></i> <span>' +
                    (expanded ? t("Replier", "Collapse") : t("Déplier", "Expand")) + "</span>";
            });
            actions.appendChild(toggle);
        }

        header.appendChild(titleWrap);
        header.appendChild(actions);
        panel.appendChild(header);
        body.hidden = !expanded;
        panel.appendChild(body);

        const navigation = document.createElement("div");
        navigation.className = "pmk029-calendar-navigation";

        const previous = document.createElement("button");
        previous.type = "button";
        previous.className = "btn btn-default btn-sm";
        previous.innerHTML = '<i class="fa fa-chevron-left" aria-hidden="true"></i> ' + t("Précédent", "Previous");

        const range = document.createElement("p");
        range.className = "pmk029-calendar-range";

        const next = document.createElement("button");
        next.type = "button";
        next.className = "btn btn-default btn-sm";
        next.innerHTML = t("Suivant", "Next") + ' <i class="fa fa-chevron-right" aria-hidden="true"></i>';

        navigation.appendChild(previous);
        navigation.appendChild(range);
        navigation.appendChild(next);
        body.appendChild(navigation);

        const desktop = document.createElement("div");
        desktop.className = "pmk029-calendar-months";
        const agenda = document.createElement("div");
        agenda.className = "pmk029-agenda";
        body.appendChild(desktop);
        body.appendChild(agenda);

        function render() {
            const count = Math.min(12, Math.max(1, Number(currentConfig.calendar.months) || 6));
            const months = getWindowMonths(anchorDate.getFullYear(), anchorDate.getMonth(), count);
            const events = extractEvents(table);
            desktop.innerHTML = "";
            agenda.innerHTML = "";
            body.querySelectorAll(".pmk029-calendar-warning").forEach(function (node) { node.remove(); });

            if (!events.length && getDataRows(table).length) {
                const warning = document.createElement("div");
                warning.className = "alert alert-warning pmk029-calendar-warning";
                warning.textContent = t(
                    "Aucun fascicule daté n'a pu être lu dans le tableau. Vérifier la structure des colonnes après une mise à jour Koha.",
                    "No dated issue could be read from the table. Check the column structure after a Koha update."
                );
                body.insertBefore(warning, desktop);
            }

            months.forEach(function (monthInfo) {
                const monthEvents = eventsForMonth(events, monthInfo.year, monthInfo.month);
                renderCalendarMonth(desktop, monthEvents, monthInfo.year, monthInfo.month);
                renderAgendaMonth(agenda, monthEvents, monthInfo.year, monthInfo.month);
            });

            const oldest = months[months.length - 1];
            range.textContent = monthLabel(oldest.year, oldest.month) + " — " + monthLabel(months[0].year, months[0].month);
            panel.dataset.anchorDate = anchorDate.getFullYear() + "-" + String(anchorDate.getMonth() + 1).padStart(2, "0");
        }

        previous.addEventListener("click", function () {
            const step = Math.min(12, Math.max(1, Number(currentConfig.calendar.navigationStep) || 6));
            anchorDate = new Date(anchorDate.getFullYear(), anchorDate.getMonth() - step, 1);
            render();
        });

        next.addEventListener("click", function () {
            const step = Math.min(12, Math.max(1, Number(currentConfig.calendar.navigationStep) || 6));
            anchorDate = new Date(anchorDate.getFullYear(), anchorDate.getMonth() + step, 1);
            render();
        });

        render();
    }

    function restorePlannedDateLabels() {
        renamedDateTextNodes.forEach(function (entry) {
            if (entry && entry.node && entry.node.isConnected) entry.node.nodeValue = entry.original;
        });
        renamedDateTextNodes = [];
    }

    function applyPlannedDateLabelCompatibility() {
        restorePlannedDateLabels();
        const cfg = currentConfig.compatibility || {};
        if (cfg.renamePlannedDate === false) return;

        const replacements = [
            { from: "Date prévue", to: "Date de réception" },
            { from: "Planned date", to: "Received date" }
        ];
        document.querySelectorAll("#subscription_issues_panel th, .tableau-fasci th, table.subscription-year-table th").forEach(function (header) {
            const walker = document.createTreeWalker(header, NodeFilter.SHOW_TEXT);
            let node;
            while ((node = walker.nextNode())) {
                let value = String(node.nodeValue || "");
                let changed = value;
                replacements.forEach(function (rule) { changed = changed.split(rule.from).join(rule.to); });
                if (changed !== value) {
                    renamedDateTextNodes.push({ node: node, original: value });
                    node.nodeValue = changed;
                }
            }
        });
    }

    function installLegacySectionToggleCompatibility() {
        if (document.documentElement.dataset.pmk029SectionToggleDelegation === "1") return;
        document.documentElement.dataset.pmk029SectionToggleDelegation = "1";
        document.addEventListener("click", function (event) {
            const page = currentPageDefinition();
            if (!page || !isPageEnabled(currentConfig, page.id)) return;
            const cfg = currentConfig.compatibility || {};
            if (cfg.legacySectionToggles === false) return;

            const button = event.target.closest && event.target.closest(".bouton");
            const sections = Array.from(document.querySelectorAll(".sectionz"));
            if (!sections.length) return;

            if (button) {
                const section = button.parentElement && button.parentElement.nextElementSibling;
                if (!section || !section.classList || !section.classList.contains("sectionz")) return;
                sections.forEach(function (candidate) {
                    if (candidate !== section) candidate.style.display = "none";
                });
                section.style.display = section.style.display === "block" ? "none" : "block";
                return;
            }

            sections.forEach(function (section) { section.style.display = "none"; });
        });
    }

    let historicalLayoutState = null;

    function installManagementStyles() {
        if (document.getElementById("pmk029-management-style")) return;
        const style = document.createElement("style");
        style.id = "pmk029-management-style";
        style.textContent = `
            .three-column-container.pmk029-historical-layout { display: flex; flex-wrap: wrap; gap: var(--pmk029-layout-gap, 20px); }
            .three-column-container.pmk029-historical-layout > .column { flex: 1; min-width: 150px; }
            .three-column-container.pmk029-historical-layout .column-content { background-color: #f9f9f9; padding: 10px; }
            .three-column-container.pmk029-historical-layout .section-header { background-color: #408540; color: #ffffff; padding: 10px; }
            .pmk029-hidden-native-tab { display: none !important; }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function removeManagementStyles() {
        const style = document.getElementById("pmk029-management-style");
        if (style) style.remove();
    }

    function getLayoutSections() {
        const sections = currentConfig.layout && Array.isArray(currentConfig.layout.sections)
            ? currentConfig.layout.sections
            : DEFAULT_CONFIG.layout.sections;
        return DEFAULT_CONFIG.layout.sections.map(function (defaultItem) {
            const stored = sections.find(function (item) { return item && item.key === defaultItem.key; });
            return Object.assign({}, defaultItem, stored || {});
        });
    }

    function sectionLabel(section) {
        const fallback = DEFAULT_CONFIG.layout.sections.find(function (item) { return item.key === section.key; }) || section;
        const value = detectLanguage() === "en" ? section.labelEn : section.labelFr;
        const fallbackValue = detectLanguage() === "en" ? fallback.labelEn : fallback.labelFr;
        return String(value || fallbackValue || section.key);
    }

    function findTabItem(tabId) {
        const tab = document.getElementById(tabId);
        return tab ? tab.closest("li") : null;
    }

    function restoreHistoricalLayout() {
        if (!historicalLayoutState) {
            document.querySelectorAll(".pmk029-hidden-native-tab").forEach(function (node) { node.classList.remove("pmk029-hidden-native-tab"); });
            removeManagementStyles();
            return;
        }
        historicalLayoutState.sections.forEach(function (state) {
            if (!state.panel) return;
            while (state.content.firstChild) state.panel.appendChild(state.content.firstChild);
            state.panel.hidden = state.originalHidden;
        });
        if (historicalLayoutState.container) historicalLayoutState.container.remove();
        historicalLayoutState.hiddenTabs.forEach(function (item) { if (item) item.classList.remove("pmk029-hidden-native-tab"); });
        historicalLayoutState = null;
        removeManagementStyles();
    }

    function cleanupLayout() { restoreHistoricalLayout(); }

    function legacyLayoutAlreadyApplied() {
        const info = document.getElementById("subscription_info_panel");
        return Boolean(info && info.querySelector(":scope > .three-column-container"));
    }

    function makeHistoricalBlock(section, contentClass) {
        const spacer = document.createElement("div");
        spacer.className = "column-content";
        const heading = document.createElement("h2");
        heading.className = "section-header";
        heading.textContent = sectionLabel(section);
        const content = document.createElement("div");
        if (contentClass) content.className = contentClass;
        return { spacer: spacer, heading: heading, content: content };
    }

    function appendHistoricalBlock(column, block, enabled) {
        column.appendChild(block.spacer);
        column.appendChild(block.heading);
        column.appendChild(block.content);
        if (enabled === false) {
            block.spacer.hidden = true;
            block.heading.hidden = true;
            block.content.hidden = true;
        }
    }

    function applyDetailLayout() {
        cleanupLayout();
        const layout = currentConfig.layout || {};
        if (layout.enabled === false) return;

        const infoPanel = document.getElementById("subscription_info_panel");
        const planningPanel = document.getElementById("subscription_planning_panel");
        const issuesPanel = document.getElementById("subscription_issues_panel");
        const summaryPanel = document.getElementById("subscription_summary_panel");
        if (!infoPanel) return;

        const sections = getLayoutSections();
        const byKey = Object.fromEntries(sections.map(function (section) { return [section.key, section]; }));
        const container = document.createElement("div");
        container.className = "three-column-container pmk029-historical-layout";
        container.style.setProperty("--pmk029-layout-gap", Math.min(60, Math.max(0, Number(layout.gap) || 20)) + "px");

        const column1 = document.createElement("div"); column1.className = "column";
        const column2 = document.createElement("div"); column2.className = "column";
        const column3 = document.createElement("div"); column3.className = "column";

        const blockInfo = makeHistoricalBlock(byKey.information || DEFAULT_CONFIG.layout.sections[0]);
        const blockPlanning = makeHistoricalBlock(byKey.planning || DEFAULT_CONFIG.layout.sections[1]);
        const blockIssues = makeHistoricalBlock(byKey.issues || DEFAULT_CONFIG.layout.sections[2], "tableau-fasci");
        const blockSummary = makeHistoricalBlock(byKey.summary || DEFAULT_CONFIG.layout.sections[3]);

        appendHistoricalBlock(column1, blockInfo, !byKey.information || byKey.information.enabled !== false);
        appendHistoricalBlock(column2, blockPlanning, !byKey.planning || byKey.planning.enabled !== false);
        appendHistoricalBlock(column2, blockIssues, !byKey.issues || byKey.issues.enabled !== false);
        appendHistoricalBlock(column3, blockSummary, !byKey.summary || byKey.summary.enabled !== false);
        container.appendChild(column1);
        container.appendChild(column2);
        container.appendChild(column3);

        const sectionStates = [];
        [
            { panel: infoPanel, target: blockInfo.content },
            { panel: planningPanel, target: blockPlanning.content },
            { panel: issuesPanel, target: blockIssues.content },
            { panel: summaryPanel, target: blockSummary.content }
        ].forEach(function (entry) {
            if (!entry.panel) return;
            sectionStates.push({ panel: entry.panel, content: entry.target, originalHidden: entry.panel.hidden });
            while (entry.panel.firstChild) entry.target.appendChild(entry.panel.firstChild);
            if (entry.panel !== infoPanel) entry.panel.hidden = true;
        });

        infoPanel.appendChild(container);
        installManagementStyles();

        const hiddenTabs = [];
        ["planning", "issues", "summary"].forEach(function (key) {
            const meta = SECTION_META[key];
            const tabItem = meta ? findTabItem(meta.tabId) : null;
            if (tabItem && layout.hideNativeTabs !== false) {
                tabItem.classList.add("pmk029-hidden-native-tab");
                hiddenTabs.push(tabItem);
            }
        });
        historicalLayoutState = { container: container, sections: sectionStates, hiddenTabs: hiddenTabs };
    }

    function normalizedStatusCodes() {
        const raw = currentConfig.bulletinage && currentConfig.bulletinage.statusCodes;
        const seen = new Set();
        return String(raw || "")
            .split(/[;,\s]+/)
            .map(function (value) { return value.trim(); })
            .filter(function (value) {
                if (!/^\d+$/.test(value) || seen.has(value)) return false;
                seen.add(value);
                return true;
            });
    }

    function rewriteBulletinageLinks() {
        const cfg = currentConfig.bulletinage || {};
        if (cfg.enabled === false || cfg.rewriteStatuses === false) return;
        const codes = normalizedStatusCodes();
        if (!codes.length) return;
        document.querySelectorAll('a[href*="serials-edit.pl"]').forEach(function (link) {
            const href = link.getAttribute("href");
            if (!href || href.indexOf("subscriptionid=") === -1) return;
            try {
                const url = new URL(href, window.location.href);
                url.searchParams.set("serstatus", codes.join(","));
                const rendered = url.origin === window.location.origin
                    ? url.pathname + url.search + url.hash
                    : url.toString();
                link.setAttribute("href", rendered);
                link.dataset.pmk029Statuses = codes.join(",");
            } catch (_) {}
        });
    }

    function getPriceColumnIndex(table) {
        const headers = getTableHeaders(table);
        for (let i = 0; i < headers.length; i += 1) {
            const identity = headerIdentity(headers[i]);
            if (PRICE_COLUMN_ALIASES.some(function (alias) { return identity.indexOf(normalizeText(alias)) !== -1; })) return i;
        }
        return -1;
    }

    function subscriptionIdFromHref(href) {
        if (!href) return "";
        try {
            const url = new URL(href, window.location.href);
            return url.searchParams.get("subscriptionid") || url.searchParams.get("subscription_id") || "";
        } catch (_) { return ""; }
    }

    function subscriptionIdFromPage() {
        const query = new URLSearchParams(window.location.search);
        const fromQuery = query.get("subscriptionid") || query.get("subscription_id");
        if (fromQuery) return fromQuery;
        const items = Array.from(document.querySelectorAll("#subscription_info_panel li, .three-column-container li, div.rows li"));
        const labels = ["abonnement n", "subscription no", "subscription number"];
        for (const item of items) {
            const text = normalizeText(item.textContent);
            if (!labels.some(function (label) { return text.indexOf(label) !== -1; })) continue;
            const match = String(item.textContent || "").match(/\b(\d+)\b/);
            if (match) return match[1];
        }
        return "";
    }

    function priceLabelMatches(value) {
        const normalized = normalizeText(value);
        if (!normalized) return false;
        return PRICE_LABEL_ALIASES.some(function (alias) {
            return normalized.indexOf(normalizeText(alias)) !== -1;
        });
    }

    function cleanPriceText(value) {
        return String(value == null ? "" : value)
            .replace(/\u00a0/g, " ")
            .replace(/^\s*[:\-–—]\s*/, "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function findDetailPriceInDocument(rootDocument) {
        const scope = rootDocument && typeof rootDocument.querySelectorAll === "function"
            ? rootDocument
            : document;
        const roots = Array.from(scope.querySelectorAll(
            "#subscription_info_panel, .three-column-container, div.rows"
        ));
        if (!roots.length) roots.push(scope);

        for (const root of roots) {
            // Présentation Koha classique : <li><span class="label">Prix fascicule :</span> valeur</li>
            const items = Array.from(root.querySelectorAll("li, .form-group, .row"));
            for (const item of items) {
                const label = item.querySelector(".label, .field-label, label, strong");
                if (!label || !priceLabelMatches(label.textContent)) continue;
                const cloneItem = item.cloneNode(true);
                const cloneLabel = cloneItem.querySelector(".label, .field-label, label, strong");
                if (cloneLabel) cloneLabel.remove();
                const value = cleanPriceText(cloneItem.textContent);
                if (value) return value;
            }

            // Fallback pour les rendus <dl><dt>...</dt><dd>...</dd></dl>.
            const terms = Array.from(root.querySelectorAll("dt"));
            for (const term of terms) {
                if (!priceLabelMatches(term.textContent)) continue;
                const valueNode = term.nextElementSibling;
                if (valueNode && valueNode.matches("dd")) {
                    const value = cleanPriceText(valueNode.textContent);
                    if (value) return value;
                }
            }

            // Fallback pour une éventuelle présentation tabulaire.
            const rows = Array.from(root.querySelectorAll("tr"));
            for (const row of rows) {
                const cells = Array.from(row.cells || []);
                if (cells.length < 2 || !priceLabelMatches(cells[0].textContent)) continue;
                const value = cleanPriceText(cells.slice(1).map(function (cell) {
                    return cell.textContent;
                }).join(" "));
                if (value) return value;
            }
        }

        return "";
    }

    function findDetailPrice() {
        return findDetailPriceInDocument(document);
    }

    function detailUrlForSubscription(subscriptionId) {
        const id = String(subscriptionId || "").trim();
        if (!id) return "";
        try {
            const url = new URL(DETAIL_PAGE_PATH, window.location.origin);
            url.searchParams.set("subscriptionid", id);
            return url.pathname + url.search;
        } catch (_) {
            return DETAIL_PAGE_PATH + "?subscriptionid=" + encodeURIComponent(id);
        }
    }

    async function fetchDetailPriceForSubscription(subscriptionId, source) {
        const id = String(subscriptionId || "").trim();
        const cfg = currentConfig.priceContext || {};
        if (!id || cfg.enabled === false || typeof window.fetch !== "function") return "";

        // Si on est déjà sur la fiche de ce même abonnement, inutile de refaire une requête.
        if (window.location.pathname === DETAIL_PAGE_PATH && subscriptionIdFromPage() === id) {
            const localPrice = findDetailPrice();
            if (localPrice) {
                writePriceContext(localPrice, id, source || "subscription-detail-current");
                return localPrice;
            }
        }

        // Mutualise les requêtes si l'initialisation et un clic utilisateur demandent
        // le même abonnement simultanément.
        if (detailPriceFetches.has(id)) return detailPriceFetches.get(id);

        const request = (async function () {
            try {
                const url = detailUrlForSubscription(id);
                if (!url) return "";
                const response = await window.fetch(url, {
                    method: "GET",
                    credentials: "same-origin",
                    cache: "no-store"
                });
                if (!response.ok) return "";

                const html = await response.text();
                if (!html) return "";

                const parsed = new DOMParser().parseFromString(html, "text/html");
                const price = findDetailPriceInDocument(parsed);
                if (!price) return "";

                writePriceContext(price, id, source || "serials-edit-direct");
                return price;
            } catch (error) {
                try {
                    console.warn("[PMK029] Impossible de récupérer le prix fascicule de l'abonnement " + id, error);
                } catch (_) {}
                return "";
            } finally {
                detailPriceFetches.delete(id);
            }
        })();

        detailPriceFetches.set(id, request);
        return request;
    }

    function captureDetailPriceContext(source) {
        if (window.location.pathname !== DETAIL_PAGE_PATH) return "";
        const price = findDetailPrice();
        if (!price) return "";
        writePriceContext(price, subscriptionIdFromPage(), source || "subscription-detail");
        return price;
    }

    function writePriceContext(price, subscriptionId, source) {
        const cfg = currentConfig.priceContext || {};
        if (cfg.enabled === false || !String(price || "").trim()) return;
        const ttlMinutes = Math.min(1440, Math.max(5, Number(cfg.ttlMinutes) || 60));
        const now = Date.now();
        const context = {
            version: 1,
            price: String(price).trim(),
            subscriptionId: String(subscriptionId || ""),
            source: String(source || ""),
            capturedAt: now,
            expiresAt: now + ttlMinutes * 60000
        };
        const key = String(cfg.storageKey || CONTEXT_STORAGE_KEY);
        try { window.sessionStorage.setItem(key, JSON.stringify(context)); } catch (_) {}
        if (cfg.legacyMirror !== false) {
            try { window.localStorage.setItem(LEGACY_PRICE_KEY, context.price); } catch (_) {}
        }
    }

    function readPriceContext() {
        const cfg = currentConfig.priceContext || {};
        const key = String(cfg.storageKey || CONTEXT_STORAGE_KEY);
        try {
            const parsed = JSON.parse(window.sessionStorage.getItem(key) || "null");
            if (!parsed || !parsed.price) return null;
            if (Number(parsed.expiresAt) && Date.now() > Number(parsed.expiresAt)) {
                window.sessionStorage.removeItem(key);
                return null;
            }
            return parsed;
        } catch (_) { return null; }
    }

    function clearPriceContext() {
        const cfg = currentConfig.priceContext || {};
        const key = String(cfg.storageKey || CONTEXT_STORAGE_KEY);
        try { window.sessionStorage.removeItem(key); } catch (_) {}
    }

    function installSearchDelegation() {
        if (document.documentElement.dataset.pmk029SearchDelegation === "1") return;
        document.documentElement.dataset.pmk029SearchDelegation = "1";
        document.addEventListener("click", function (event) {
            if (window.location.pathname !== SEARCH_PAGE_PATH) return;
            if (!isPageEnabled(currentConfig, SEARCH_PAGE_ID)) return;
            const action = event.target.closest('a[href*="serials-edit.pl"], .btn-group a, .btn-group button');
            if (!action) return;
            const row = action.closest("tr");
            if (!row) return;
            const table = row.closest("table");
            if (!(table instanceof HTMLTableElement)) return;
            const index = getPriceColumnIndex(table);
            if (index < 0 || !row.cells[index]) return;
            const link = action.matches('a[href*="serials-edit.pl"]') ? action : row.querySelector('a[href*="serials-edit.pl"]');
            writePriceContext(row.cells[index].textContent, subscriptionIdFromHref(link && link.getAttribute("href")), "serials-search");
        }, true);
    }

    function installDetailDelegation() {
        if (document.documentElement.dataset.pmk029DetailDelegation === "1") return;
        document.documentElement.dataset.pmk029DetailDelegation = "1";

        function captureBeforeBulletinage(event) {
            if (window.location.pathname !== DETAIL_PAGE_PATH) return;
            if (!isPageEnabled(currentConfig, DETAIL_PAGE_ID)) return;
            const target = event.target instanceof Element ? event.target : null;
            if (!target) return;
            const action = target.closest(
                '#receive, a[href*="serials-edit.pl"], ' +
                'form[action*="serials-edit.pl"] button, form[action*="serials-edit.pl"] input[type="submit"]'
            );
            if (!action) return;
            captureDetailPriceContext("subscription-detail");
        }

        document.addEventListener("pointerdown", captureBeforeBulletinage, true);
        document.addEventListener("click", captureBeforeBulletinage, true);
    }

    function refreshSearchPage() {
        if (!isPageEnabled(currentConfig, SEARCH_PAGE_ID)) return;
        rewriteBulletinageLinks();
        installSearchDelegation();
    }

    function observeSearchPage() {
        if (observers.length) disconnectObservers();
        const root = document.querySelector("main") || document.body;
        if (!root) return;
        const observer = new MutationObserver(function () {
            if (mutationTimer) clearTimeout(mutationTimer);
            mutationTimer = window.setTimeout(function () {
                mutationTimer = null;
                refreshSearchPage();
            }, 180);
        });
        observer.observe(root, { childList: true, subtree: true });
        observers.push(observer);
    }

    let receivingShortcutInstalled = false;
    let receivingProtectionLocked = true;

    function receivingCfg() {
        return currentConfig.receivingAssistant || {};
    }

    function receivingButtonText(group, frFallback, enFallback) {
        const lang = detectLanguage();
        if (lang === "en") return String(group && group.buttonLabelEn || enFallback);
        return String(group && group.buttonLabelFr || frFallback);
    }

    function receivingStyleConfig() {
        const cfg = receivingCfg().buttons || {};
        return {
            background: String(cfg.background || "#4CAF50"),
            hoverBackground: String(cfg.hoverBackground || "#45a049"),
            color: String(cfg.color || "#ffffff")
        };
    }

    function applyReceivingButtonStyles(button) {
        const colors = receivingStyleConfig();
        button.style.backgroundColor = colors.background;
        button.style.border = "none";
        button.style.color = colors.color;
        button.style.padding = "5px 5px";
        button.style.textAlign = "center";
        button.style.textDecoration = "none";
        button.style.display = "inline-block";
        button.style.fontSize = "13px";
        button.style.margin = "2px 2px";
        button.style.cursor = "pointer";
        button.style.borderRadius = "5px";
        button.style.transition = "background-color 0.3s ease";
        button.addEventListener("mouseover", function () { button.style.backgroundColor = colors.hoverBackground; });
        button.addEventListener("mouseout", function () { button.style.backgroundColor = colors.background; });
    }

    function receivingItemSections() {
        const legends = Array.from(document.querySelectorAll("legend")).filter(function (legend) {
            const text = normalizeText(legend.textContent);
            return text.includes("exemplaire") || text.includes("item");
        });
        return legends.map(function (legend, index) {
            return { legend: legend, section: legend.closest("fieldset") || legend.parentElement, index: index };
        }).filter(function (entry) { return entry.section; });
    }

    function receivingFindField(section, labelText) {
        const wanted = normalizeText(labelText);
        if (!wanted || !section) return null;
        const label = Array.from(section.querySelectorAll("label")).find(function (candidate) {
            return normalizeText(candidate.textContent) === wanted;
        });
        if (!label) return null;
        const li = label.closest("li") || label.parentElement;
        if (!li) return null;
        return li.querySelector('input:not([type="hidden"]), select, textarea');
    }

    function receivingApplyField(section, fieldLabel, value, mode) {
        const input = receivingFindField(section, fieldLabel);
        if (!input) return false;
        const text = String(value == null ? "" : value);
        if (input.tagName === "SELECT") {
            const exact = Array.from(input.options).find(function (option) { return String(option.value) === text; });
            if (exact) {
                input.value = exact.value;
                input.dispatchEvent(new Event("change", { bubbles: true }));
                return true;
            }
            return false;
        }
        const selectedMode = String(mode || "legacy");
        if (selectedMode === "replace") input.value = text;
        else if (selectedMode === "append" || selectedMode === "legacy") input.value = input.value.trim() ? input.value.trim() + " " + text : text;
        else input.value = text;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
    }

    function receivingExtractNumber(text) {
        const patterns = [/N°\s*(\d+)(?:\s*-\s*(.*))?/i, /N°\s*(\d+)(?:-(\d+))?/i];
        for (const pattern of patterns) {
            const match = String(text || "").match(pattern);
            if (match) return { number: String(match[1]).trim(), fullText: match[2] ? String(match[2]).trim() : "" };
        }
        return null;
    }

    function receivingFormatDate(dateString) {
        if (!dateString) return "Invalid Date";
        const date = new Date(dateString);
        if (!(date instanceof Date) || Number.isNaN(date.getTime())) return "Invalid Date";
        const locale = String(receivingCfg().fill && receivingCfg().fill.dateLocale || "fr-FR");
        try { return date.toLocaleDateString(locale); } catch (_) { return date.toLocaleDateString("fr-FR"); }
    }

    function receivingPrice() {
        const structured = readPriceContext();
        const currentSubscriptionId = subscriptionIdFromPage();

        if (structured && structured.price) {
            const storedSubscriptionId = String(structured.subscriptionId || "");

            // Sur serials-edit.pl, un prix n'est considéré fiable que s'il appartient
            // explicitement à l'abonnement courant. Un ancien contexte ne doit jamais
            // contaminer le bulletinage d'un autre abonnement.
            if (currentSubscriptionId) {
                if (storedSubscriptionId && currentSubscriptionId === storedSubscriptionId) {
                    return String(structured.price);
                }
                return "";
            }

            // Sans identifiant d'abonnement exploitable, on conserve la compatibilité
            // historique avec le contexte structuré.
            return String(structured.price);
        }

        // Ancien 073/030 : ne servir de secours que lorsqu'on ne connaît pas
        // l'abonnement courant. Avec un subscriptionid présent, on préfère toujours
        // interroger directement la fiche Koha pour éviter un prix périmé.
        if (!currentSubscriptionId) {
            try { return String(window.localStorage.getItem(LEGACY_PRICE_KEY) || ""); } catch (_) {}
        }
        return "";
    }

    async function ensureReceivingPrice() {
        const currentSubscriptionId = subscriptionIdFromPage();
        let price = receivingPrice();
        if (price) return price;

        if (currentSubscriptionId) {
            price = await fetchDetailPriceForSubscription(currentSubscriptionId, "serials-edit-direct");
            if (price) return price;
        }

        return "";
    }

    async function receivingFillSection(entry) {
        const cfg = receivingCfg().fill || {};
        if (cfg.enabled === false) return;

        // Le prix est indépendant de la forme du numéro de fascicule :
        // même si serialseq n'est pas de type "N° 123", p - Prix doit être renseigné.
        if (cfg.priceEnabled !== false) {
            const price = String(await ensureReceivingPrice() || "").trim().replace(/,/g, ".");
            if (price) receivingApplyField(entry.section, cfg.priceFieldLabel || "p - Prix", price, "legacy");
        }

        const serialSeqInputs = document.querySelectorAll('input[name="serialseq"]');
        const plannedDateInputs = document.querySelectorAll('input[name="planneddate"]');
        const serialSeqInput = serialSeqInputs[entry.index];
        const plannedDateInput = plannedDateInputs[entry.index];

        if (!serialSeqInput || !plannedDateInput) return;

        const extracted = receivingExtractNumber(serialSeqInput.value);
        if (extracted) {
            const plannedDate = plannedDateInput.value;
            const formattedInitialDate = receivingFormatDate(plannedDate);
            const formattedValue = `${extracted.number} ${extracted.fullText} (${formattedInitialDate})`;

            if (cfg.issueNumberEnabled !== false) {
                receivingApplyField(entry.section, cfg.issueNumberFieldLabel || "v - Numéro de la revue", formattedValue, "legacy");
            }
            if (cfg.callNumberEnabled !== false) {
                receivingApplyField(entry.section, cfg.callNumberFieldLabel || "k - Cote", extracted.number, "legacy");
            }
        }

        if (cfg.setPlannedDateToday !== false) {
            plannedDateInput.value = new Date().toISOString().split("T")[0];
        }
    }

    function receivingAppendMarker(entry, marker) {
        const serialSeqInputs = document.querySelectorAll('input[name="serialseq"]');
        const serialSeqInput = serialSeqInputs[entry.index];
        if (serialSeqInput) serialSeqInput.value = `${serialSeqInput.value.trim()} ${marker}`;

        const cfg = receivingCfg().fill || {};
        const callField = receivingFindField(entry.section, cfg.callNumberFieldLabel || "k - Cote");
        if (callField && callField.tagName !== "SELECT") callField.value = `${String(callField.value || "").trim()} ${marker}`;
        const issueField = receivingFindField(entry.section, cfg.issueNumberFieldLabel || "v - Numéro de la revue");
        if (issueField && issueField.tagName !== "SELECT") {
            const currentValue = String(issueField.value || "").trim();
            const position = currentValue.indexOf("(");
            if (position !== -1) issueField.value = `${currentValue.slice(0, position)} ${marker} ${currentValue.slice(position)}`;
            else issueField.value = `${currentValue} ${marker}`;
        }
    }

    function receivingPresetLabel(preset) {
        return detectLanguage() === "en"
            ? String(preset.labelEn || preset.labelFr || preset.id || "Preset")
            : String(preset.labelFr || preset.labelEn || preset.id || "Préconfiguration");
    }

    function receivingApplyPreset(entry, preset) {
        const values = Array.isArray(preset.values) ? preset.values : [];
        values.forEach(function (setting) {
            if (!setting || setting.enabled === false) return;
            const label = String(setting.fieldLabel || "").trim();
            if (!label) return;
            receivingApplyField(entry.section, label, setting.value, setting.mode || "legacy");
        });
    }

    function receivingTemplate(template, values) {
        return String(template || "").replace(/\{([A-Z_]+)\}/g, function (_, key) {
            return Object.prototype.hasOwnProperty.call(values, key) ? String(values[key] == null ? "" : values[key]) : "{" + key + "}";
        });
    }

    function receivingReportContext() {
        const h1Em = document.querySelector("h1 em");
        const h1 = document.querySelector("h1");
        const h1Text = h1 ? h1.textContent : "";
        const coteMatch = h1Text.match(/:\s*([A-Z]{3})/);
        const user = document.querySelector(".loggedinusername");
        const issue = document.querySelector('input[name="serialseq"]');
        const plannedDate = document.querySelector('input[name="planneddate"]');
        const barcode = document.querySelector('input[name="barcode"]');
        return {
            SUBSCRIPTION: h1Em ? h1Em.textContent : "Nom non disponible",
            CALLNUMBER: coteMatch ? coteMatch[1] : "Côte non disponible",
            USER: user ? user.textContent : "Nom d'utilisateur non disponible",
            ISSUE: issue ? issue.value : "Numéro de fascicule non disponible",
            DATE: plannedDate ? plannedDate.value : "Date de publication non disponible",
            BARCODE: barcode ? barcode.value : "Code-barres non disponible"
        };
    }

    function receivingSendReport() {
        const cfg = receivingCfg().report || {};
        if (cfg.enabled === false) return;
        const values = receivingReportContext();
        const subject = receivingTemplate(cfg.subjectTemplate || DEFAULT_CONFIG.receivingAssistant.report.subjectTemplate, values);
        const body = receivingTemplate(cfg.bodyTemplate || DEFAULT_CONFIG.receivingAssistant.report.bodyTemplate, values);
        const recipients = String(cfg.recipients || DEFAULT_CONFIG.receivingAssistant.report.recipients).trim();
        window.location.href = "mailto:" + recipients + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
    }

    function receivingInstallProtectionStyles() {
        if (document.getElementById("pmk029-receiving-protection-style")) return;
        const style = document.createElement("style");
        style.id = "pmk029-receiving-protection-style";
        style.textContent = `.pmk029-receiving-overlay{position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.05);pointer-events:auto;visibility:visible;opacity:1;transition:visibility 0s,opacity .5s linear;z-index:10}.pmk029-receiving-overlay.hidden{visibility:hidden;opacity:0}.pmk029-receiving-blocked{background-color:#f5f5f5!important;pointer-events:none!important;opacity:.5!important}`;
        (document.head || document.documentElement).appendChild(style);
    }

    function receivingBlockConfiguredFields() {
        const cfg = receivingCfg().protection || {};
        if (cfg.enabled === false) return;
        receivingInstallProtectionStyles();
        const fields = Array.isArray(cfg.fields) ? cfg.fields : [];
        receivingItemSections().forEach(function (entry) {
            fields.forEach(function (field) {
                if (!field || field.enabled === false) return;
                const input = receivingFindField(entry.section, field.label);
                if (input) input.classList.add("pmk029-receiving-blocked");
            });
        });

        const needLink = cfg.requireAddItemLink !== false;
        const addButtonExists = Array.from(document.querySelectorAll("a")).some(function (link) {
            const text = normalizeText(link.textContent);
            return text.includes("ajouter un exemplaire") || text.includes("add item");
        });
        if (cfg.overlayOnFascicleRows !== false && (!needLink || addButtonExists)) {
            document.querySelectorAll("table tbody tr").forEach(function (row) {
                const text = normalizeText(row.textContent);
                if (!(text.includes("fascicule") || text.includes("issue"))) return;
                if (row.querySelector(":scope > .pmk029-receiving-overlay")) return;
                const overlay = document.createElement("div");
                overlay.className = "pmk029-receiving-overlay";
                row.style.position = "relative";
                row.appendChild(overlay);
                row.querySelectorAll("input, select").forEach(function (input) { input.classList.add("pmk029-receiving-blocked"); });
            });
        }
    }

    function receivingToggleProtection() {
        const cfg = receivingCfg().protection || {};
        if (cfg.enabled === false) return;
        const unlockNow = receivingProtectionLocked;
        document.querySelectorAll(".pmk029-receiving-overlay").forEach(function (overlay) {
            overlay.classList.toggle("hidden", unlockNow);
        });
        const scopeAll = String(cfg.shortcutScope || "all") === "all";
        const inputs = scopeAll
            ? document.querySelectorAll("input, select")
            : document.querySelectorAll(".pmk029-receiving-blocked, .pmk029-receiving-unlocked");
        inputs.forEach(function (input) {
            if (unlockNow) {
                input.classList.remove("pmk029-receiving-blocked");
                input.classList.add("pmk029-receiving-unlocked");
                input.style.pointerEvents = "auto";
                input.style.opacity = "1";
            } else {
                input.classList.remove("pmk029-receiving-unlocked");
                input.classList.add("pmk029-receiving-blocked");
                input.style.removeProperty("pointer-events");
                input.style.removeProperty("opacity");
            }
        });
        receivingProtectionLocked = !unlockNow;
    }

    function receivingInstallShortcut() {
        if (receivingShortcutInstalled) return;
        receivingShortcutInstalled = true;
        document.addEventListener("keydown", function (event) {
            if (window.location.pathname !== EDIT_PAGE_PATH) return;
            const cfg = receivingCfg().protection || {};
            if (cfg.enabled === false || cfg.unlockShortcutEnabled === false) return;
            const key = String(cfg.unlockKey || "U").toLowerCase();
            if (event.ctrlKey && event.shiftKey && !event.altKey && String(event.key || "").toLowerCase() === key) {
                event.preventDefault();
                receivingToggleProtection();
            }
        });
    }

    function cleanupReceivingAssistant() {
        document.querySelectorAll(".pmk029-receiving-generated").forEach(function (node) { node.remove(); });
        document.querySelectorAll(".pmk029-receiving-overlay").forEach(function (node) { node.remove(); });
        document.querySelectorAll(".pmk029-receiving-blocked").forEach(function (node) {
            node.classList.remove("pmk029-receiving-blocked", "pmk029-receiving-unlocked");
            node.style.removeProperty("pointer-events");
            node.style.removeProperty("opacity");
        });
        const style = document.getElementById("pmk029-receiving-protection-style");
        if (style) style.remove();
        receivingProtectionLocked = true;
    }

    function receivingAddButton(entry, text, action, legacyId, extraClass) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = text;
        button.className = "pmk029-receiving-generated" + (extraClass ? " " + extraClass : "");
        if (legacyId) button.id = legacyId;
        button.addEventListener("click", function (event) {
            event.preventDefault();
            try {
                const result = action();
                if (result && typeof result.catch === "function") {
                    result.catch(function (error) {
                        try { console.warn("[PMK029] Action de bulletinage en erreur", error); } catch (_) {}
                    });
                }
            } catch (error) {
                try { console.warn("[PMK029] Action de bulletinage en erreur", error); } catch (_) {}
            }
        });
        applyReceivingButtonStyles(button);
        entry.section.appendChild(button);
        return button;
    }

    function renderReceivingAssistant() {
        cleanupReceivingAssistant();
        if (window.location.pathname !== EDIT_PAGE_PATH) return;
        if (!isPageEnabled(currentConfig, EDIT_PAGE_ID)) return;
        const cfg = receivingCfg();
        if (cfg.enabled === false) return;

        const entries = receivingItemSections();
        entries.forEach(function (entry) {
            const fill = cfg.fill || {};
            if (fill.enabled !== false) {
                receivingAddButton(entry, receivingButtonText(fill, "Remplir les champs", "Fill fields"), function () {
                    receivingFillSection(entry);
                }, "exemplaire-button-fill");
            }

            const special = cfg.specialIssue || {};
            if (special.enabled !== false) {
                receivingAddButton(entry, receivingButtonText(special, "Ajouter HS", "Add special issue"), function () {
                    receivingAppendMarker(entry, String(special.marker || "HS"));
                }, "exemplaire-button-hs");
            }

            const duplicate = cfg.duplicateIssue || {};
            if (duplicate.enabled === true) {
                receivingAddButton(entry, receivingButtonText(duplicate, "Ajouter Doublon", "Add duplicate"), function () {
                    receivingAppendMarker(entry, String(duplicate.marker || "(Doublon)"));
                }, "exemplaire-button-duplicate");
            }

            if (cfg.presetsEnabled !== false) {
                const presets = Array.isArray(cfg.presets) ? cfg.presets : [];
                presets.forEach(function (preset) {
                    if (!preset || preset.enabled === false) return;
                    receivingAddButton(entry, receivingPresetLabel(preset), function () {
                        receivingApplyPreset(entry, preset);
                    }, preset.legacyId || null, "pmk029-receiving-preset");
                });
            }
        });

        const report = cfg.report || {};
        if (report.enabled !== false) {
            entries.forEach(function (entry, index) {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "pmk029-receiving-generated";
                button.textContent = receivingButtonText(report, "Signaler un problème de bulletinage", "Report a receiving problem");
                button.style.marginLeft = "10px";
                button.addEventListener("click", function (event) { event.preventDefault(); receivingSendReport(); });
                entry.legend.parentNode.insertBefore(button, entry.legend.nextSibling);
            });
        } else if (entries[0]) {
        }

        receivingBlockConfiguredFields();
        receivingInstallShortcut();
    }

    /* ============================================================
       COLLECTION DES FASCICULES — ABSORPTION DU 094
       ============================================================ */


    /* ============================================================
       EXEMPLAIRES DES FASCICULES — API KOHA / RÉGLAGES LOCAUX PMK
       Aucun rapprochement par numéro ou date, aucune écriture Koha.
       ============================================================ */
    let collectionItemsRun = 0;
    let collectionItemsController = null;
    let collectionItemsCache = null;
    const collectionItemsTables = new Map();

    // Tous les réglages proviennent de la configuration centralisée PMK.
    // Aucun réglage propre à un navigateur ni panneau sur les pages Koha.
    function collectionItemsConfig() {
        return Object.assign({}, DEFAULT_CONFIG.collectionItems, currentConfig.collectionItems || {});
    }

    // Parcourir toutes les lignes DataTables (y compris les pages non affichées)
    // et éviter tout accès direct à table.tBodies[0] : DataTables peut retirer
    // temporairement le tbody au cours d'une destruction / reconstruction.
    function collectionTableRows(table) {
        if (!table) return [];
        const api = collectionDataTable(table);
        if (api) {
            try { return api.rows().nodes().toArray().filter(Boolean); } catch (_) {}
        }
        return Array.from(table.querySelectorAll("tbody tr")).filter(row => row.cells && row.cells.length);
    }

    function ensureCollectionBody(table) {
        if (!table) return null;
        return (table.tBodies && table.tBodies[0]) || table.createTBody();
    }

    // DataTables ne permet pas d'ajouter une colonne après initialisation.
    // Reconstruire depuis toutes les lignes DOM, puis restaurer ordre et page.
    function changeCollectionItemColumn(table, add) {
        const api = collectionDataTable(table);
        const jq = window.jQuery || window.$;
        let init = {}, order = [], page = 0;
        if (api) {
            const settings = api.settings()[0];
            init = Object.assign({}, settings.oInit);
            order = api.order().map(function (pair) { return pair.slice(); });
            page = api.page();
            const rows = collectionTableRows(table);
            api.destroy();
            const tbody = ensureCollectionBody(table);
            rows.forEach(function (row) { tbody.appendChild(row); });
        }
        table.querySelectorAll('colgroup').forEach(function (node) { node.remove(); });
        const saved = collectionItemsTables.get(table);
        const headerRow = table.tHead.rows[0];
        let insertIndex = saved && saved.insertIndex;
        if (add) {
            insertIndex = Array.from(headerRow.cells).findIndex(function (cell) {
                return ["statut", "status"].includes(normalizeText(cell.textContent));
            });
            if (insertIndex < 0) insertIndex = headerRow.cells.length;
            if (saved) saved.insertIndex = insertIndex;
            const th = document.createElement("th");
            th.className = "pmk029-item-column no-sort";
            th.textContent = t("Exemplaire", "Item");
            headerRow.insertBefore(th, headerRow.cells[insertIndex] || null);
            collectionTableRows(table).forEach(function (row) {
                const td = document.createElement("td");
                td.className = "pmk029-item-column";
                td.textContent = t("Chargement…", "Loading…");
                row.insertBefore(td, row.cells[insertIndex] || null);
            });
        } else {
            table.querySelectorAll('.pmk029-item-column').forEach(function (node) { node.remove(); });
        }
        if (api && jq) {
            // Réutiliser les paramètres natifs sans réinjecter leurs anciennes données.
            delete init.data; delete init.aaData; delete init.retrieve; delete init.destroy;
            const baseColumns = saved && saved.columns;
            if (baseColumns) {
                init.columns = baseColumns.slice();
                if (add) init.columns.splice(insertIndex, 0, { orderable: false, searchable: true });
            }
            if (saved && saved.columnDefs) {
                init.columnDefs = saved.columnDefs.map(function (definition) {
                    const copy = Object.assign({}, definition);
                    const targets = Array.isArray(copy.targets) ? copy.targets : [copy.targets];
                    copy.targets = targets.map(function (target) {
                        if (!add || typeof target !== "number") return target;
                        const index = target < 0 ? baseColumns.length + target : target;
                        return index >= insertIndex ? index + 1 : index;
                    });
                    return copy;
                });
            }
            order = order.filter(function (pair) { return add || pair[0] !== insertIndex; }).map(function (pair) {
                return [add ? (pair[0] >= insertIndex ? pair[0] + 1 : pair[0]) : (pair[0] > insertIndex ? pair[0] - 1 : pair[0]), pair[1]];
            });
            delete init.aoColumns;
            init.order = order.filter(function (pair) { return pair[0] < table.tHead.rows[0].cells.length; });
            const next = jq(table).DataTable(init);
            next.page(Math.min(page, Math.max(0, next.page.info().pages - 1))).draw(false);
        }
    }

    function cleanupCollectionItems() {
        collectionItemsRun += 1;
        if (collectionItemsController) collectionItemsController.abort();
        collectionItemsController = null;
        collectionItemsTables.forEach(function (_, table) {
            if (document.contains(table)) changeCollectionItemColumn(table, false);
        });
        collectionItemsTables.clear();
    }

    async function fetchCollectionItems(biblioId, signal) {
        // Pas de _order_by : reproduire la requête validée sur le Koha hébergé.
        // En cas de 500 sur un lot, recommencer à la première page avec un lot
        // plus petit pour ne perdre ni décaler aucun exemplaire.
        for (const pageSize of [20, 1]) {
            const all = [];
            let retrySmaller = false;
            for (let page = 1; ; page += 1) {
                const url = new URL("/api/v1/biblios/" + encodeURIComponent(biblioId) + "/items", window.location.origin);
                url.searchParams.set("_page", page);
                url.searchParams.set("_per_page", pageSize);
                let response = await fetch(url.href, {
                    credentials: "same-origin", signal: signal,
                    headers: { Accept: "application/json", "x-koha-embed": "serial_item.serial,+strings" }
                });
                // Les libellés sont facultatifs : conserver le chargement validé
                // si l'installation refuse leur expansion.
                if (response.status === 400 || response.status === 500) {
                    response = await fetch(url.href, {
                        credentials: "same-origin", signal: signal,
                        headers: { Accept: "application/json", "x-koha-embed": "serial_item.serial" }
                    });
                }
                if (!response.ok) {
                    if (response.status === 500 && pageSize > 1) {
                        retrySmaller = true;
                        break;
                    }
                    let detail = "";
                    try {
                        const body = await response.json();
                        const message = body.error || body.message || body.error_code;
                        if (typeof message === "string") detail = " · " + message.slice(0, 250);
                    } catch (_) {}
                    throw new Error("HTTP " + response.status + " · " + t("page ", "page ") + page + " · " + pageSize + t(" exemplaire(s) par requête", " item(s) per request") + detail);
                }
                const batch = await response.json();
                if (!Array.isArray(batch)) throw new Error(t("Réponse API inattendue", "Unexpected API response"));
                all.push.apply(all, batch);
                const totalHeader = response.headers.get("X-Total-Count");
                const total = totalHeader !== null && /^\d+$/.test(totalHeader) ? Number(totalHeader) : null;
                // Éviter une page supplémentaire lorsque Koha fournit le total.
                if (!batch.length || (total !== null && all.length >= total)) break;
                if (page >= 10000) throw new Error("Pagination API excessive");
            }
            if (retrySmaller) continue;
            if (all.length && !all.some(function (item) { return Object.prototype.hasOwnProperty.call(item, "serial_item"); })) {
                throw new Error(t("L’API ne fournit pas le lien avec les fascicules", "API does not expose issue links"));
            }
            return all;
        }
        throw new Error(t("Chargement API impossible", "API loading failed"));
    }

    function installCollectionItemStyles() {
        if (document.getElementById("pmk029-collection-item-style")) return;
        const style = document.createElement("style");
        style.id = "pmk029-collection-item-style";
        style.textContent = `
            td.pmk029-item-column { vertical-align:top; }
            .pmk029-item-card { max-width:27rem; line-height:1.3; }
            .pmk029-item-card + .pmk029-item-card { margin-top:.35rem; padding-top:.35rem; border-top:1px solid #e2e6e9; }
            .pmk029-item-top { display:flex; align-items:center; flex-wrap:wrap; gap:.25rem .5rem; }
            .pmk029-item-barcode { font-family:ui-monospace,SFMono-Regular,Consolas,monospace; font-size:.95em; font-weight:600; white-space:nowrap; }
            .pmk029-item-actions { display:inline-flex; align-items:center; gap:.35rem; font-size:.85em; white-space:nowrap; }
            .pmk029-item-actions a { text-decoration:none; }
            .pmk029-item-actions a:hover, .pmk029-item-actions a:focus { text-decoration:underline; }
            .pmk029-item-edit { border:1px solid #ccd3d9; border-radius:3px; padding:1px 5px; background:#f7f8f9; }
            .pmk029-item-meta { display:flex; align-items:baseline; flex-wrap:wrap; gap:.2rem .35rem; margin-top:.2rem; font-size:.85em; }
            .pmk029-item-callnumber { color:#454e56; margin-right:.15rem; }
            .pmk029-item-label { color:#66717b; font-weight:normal; }
            .pmk029-item-chip { display:inline-block; padding:1px 5px; border-radius:3px; background:#f0f2f4; color:#49545e; }
            .pmk029-item-chip.is-alert { background:#fff1d5; color:#704600; }
            .pmk029-item-chip.is-lost { background:#fbe7e7; color:#922b2b; }
            .pmk029-item-empty { color:#737d85; font-size:.9em; }
            .pmk029-item-periodicity { color:#49545e; }
            .pmk029-item-periodicity.is-unconfigured { color:#8c651f; }
            .pmk029-loan-release { display:flex; align-items:center; flex-wrap:wrap; gap:.4rem; margin-top:.25rem; font-size:.85em; color:#246444; }
            .pmk029-loan-release button { padding:1px 6px; }
            .pmk029-weeding { display:flex; align-items:center; flex-wrap:wrap; gap:.35rem; margin-top:.25rem; color:#9a4c0a; font-size:.85em; }
        `;
        document.head.appendChild(style);
    }

    function collectionItemStatusLabel(item, field, legacyField, zeroLabel) {
        const code = item[field];
        if (code == null) return t("Non renseigné", "Not set");
        const strings = item._strings || {};
        const entry = strings[field] || strings[legacyField];
        if (typeof entry === "string" && entry.trim()) return entry;
        if (entry && typeof entry === "object") {
            const label = entry.str || entry.description || entry.lib;
            if (typeof label === "string" && label.trim()) return label;
        }
        return Number(code) === 0 ? zeroLabel : t("Code ", "Code ") + String(code);
    }

    /* Désherbage : politique centrale PMK, jamais de réglages dans Koha. */
    let collectionWeedingContext = null;
    async function loadWeedingPeriod(biblioId, signal) {
        const response = await fetch("/api/v1/biblios/" + encodeURIComponent(biblioId), {
            credentials: "same-origin", signal,
            headers: { Accept: "application/marcxml+xml" }
        });
        if (!response.ok) throw new Error("Lecture MARC 326$a impossible (HTTP " + response.status + ")");
        const xml = new DOMParser().parseFromString(await response.text(), "application/xml");
        if (xml.querySelector("parsererror")) throw new Error("MARCXML non interprétable");
        const fields = Array.from(xml.getElementsByTagName("datafield"));
        const f326 = fields.find(f => f.getAttribute("tag") === "326");
        if (!f326) return { key: "", label: "" };
        const sub = Array.from(f326.getElementsByTagName("subfield")).find(f => f.getAttribute("code") === "a");
        const label = sub ? String(sub.textContent || "").trim() : "";
        return { key: normalizeText(label).replace(/\s+/g, ""), label: label };
    }

    function weedingDecision(item, period, cfg) {
        if (!cfg.enabled) return null;
        const limit = Number(cfg.periods && cfg.periods[period]);
        if (!(limit > 0)) return null;
        const type = String(item.item_type_id || "");
        if (!type.startsWith(cfg.itemTypePrefix || "PERI")) return null;
        if ((cfg.excludedBranches || []).includes(item.home_library_id)) return null;
        if ((cfg.excludedLocations || []).includes(item.location)) return null;
        if (Number(item.lost_status || 0) === 1) return { state: "marked", limit };
        if (Number(item.lost_status || 0) !== 0) return null;
        if (item.checked_out_date || item.checkout || item.onloan) return null;
        const raw = String(item.acquisition_date || "").slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
        const acquired = new Date(raw + "T12:00:00");
        if (!Number.isFinite(acquired.getTime())) return null;
        const threshold = new Date();
        threshold.setDate(threshold.getDate() - limit);
        if (acquired >= threshold) return null;
        return { state: "due", limit, acquired: raw };
    }

    async function weedingRequest(path, method, body) {
        // Koha contrôle les permissions et peut refuser la suppression (réservation, prêt...).
        const headers = { Accept: "application/json" };
        if (body) headers["Content-Type"] = "application/json";
        const res = await fetch(path, { method, credentials: "same-origin", headers,
            body: body ? JSON.stringify(body) : undefined });
        if (!res.ok) {
            const result = await res.json().catch(() => ({}));
            throw new Error("HTTP " + res.status + " : " + (result.error || result.error_code || "Action refusée par Koha"));
        }
        return res;
    }

    async function weedingAction(item, biblioId, mode, button) {
        const cfg = currentConfig.weeding || DEFAULT_CONFIG.weeding;
        const id = item.item_id, barcode = item.external_id || String(id);
        if (!id) return;
        const confirmText = mode === "mark"
            ? "Marquer l'exemplaire " + barcode + " comme exclu du prêt (1) et Pilon (1) ?"
            : "SUPPRESSION DÉFINITIVE de l'exemplaire " + barcode + " ? Il doit déjà être marqué Pilon (1) et exclu du prêt (1).";
        if (!window.confirm(confirmText)) return;
        button.disabled = true;
        try {
            const latestResponse = await weedingRequest("/api/v1/items/" + encodeURIComponent(id), "GET");
            const latest = await latestResponse.json();
            const decision = weedingDecision(latest, collectionWeedingContext && collectionWeedingContext.period, cfg);
            if (mode === "mark") {
                if (!cfg.allowMark || !decision || decision.state !== "due") throw new Error("Exemplaire non éligible après vérification");
                // Endpoint de modification d'exemplaire de Koha : préserver les autres champs.
                await weedingRequest("/api/v1/biblios/" + encodeURIComponent(biblioId) + "/items/" + encodeURIComponent(id), "PUT", {
                    not_for_loan_status: Number(cfg.notForLoanStatus), lost_status: Number(cfg.lostStatus)
                });
                window.alert("Exemplaire marqué Pilon. Vérifiez son statut avant suppression.");
            } else {
                if (!cfg.allowDelete || Number(latest.not_for_loan_status) !== Number(cfg.notForLoanStatus)
                    || Number(latest.lost_status) !== Number(cfg.lostStatus)) {
                    throw new Error("Le passage préalable en Exclu du prêt / Pilon n'est pas confirmé.");
                }
                if (latest.checked_out_date || latest.checkout || latest.onloan) throw new Error("Exemplaire en prêt");
                if (!window.confirm("Confirmer une dernière fois la suppression irréversible de " + barcode + " ?")) return;
                await weedingRequest("/api/v1/items/" + encodeURIComponent(id), "DELETE");
                window.alert("Exemplaire supprimé de Koha.");
            }
            collectionItemsCache = null;
            refreshCollectionItems();
        } catch (error) {
            window.alert("Désherbage impossible : " + error.message);
        } finally { button.disabled = false; }
    }

    function renderWeedingInfo(line, item, biblioId, period) {
        const cfg = currentConfig.weeding || DEFAULT_CONFIG.weeding;
        if (!cfg.enabled) return;
        const decision = weedingDecision(item, period, cfg);
        if (!decision) return;
        const wrap = document.createElement("div");
        wrap.className = "pmk029-weeding";
        const label = document.createElement("strong");
        label.textContent = decision.state === "marked" ? "Pilon — prêt exclu à vérifier" : "À désherber (" + decision.limit + " jours)";
        wrap.appendChild(label);
        if (decision.state === "due" && cfg.allowMark) {
            const btn = document.createElement("button");
            btn.type = "button"; btn.textContent = "Marquer Pilon";
            btn.className = "btn btn-default btn-xs";
            btn.onclick = () => weedingAction(item, biblioId, "mark", btn);
            wrap.appendChild(btn);
        }
        if (decision.state === "marked" && cfg.allowDelete && Number(item.not_for_loan_status) === Number(cfg.notForLoanStatus)) {
            const btn = document.createElement("button");
            btn.type = "button"; btn.textContent = "Supprimer";
            btn.className = "btn btn-danger btn-xs";
            btn.onclick = () => weedingAction(item, biblioId, "delete", btn);
            wrap.appendChild(btn);
        }
        line.appendChild(wrap);
    }

    // Ancien fascicule en consultation sur place : rendre empruntable uniquement
    // si un autre fascicule, distinct, du même abonnement a été réceptionné après.
    // Aucune modification automatique : seule une action explicite écrit dans Koha.
    function itemSerial(item) {
        const relation = item && item.serial_item;
        return relation && relation.serial ? relation.serial : null;
    }

    function itemSerialId(item) {
        const relation = item && item.serial_item;
        const serial = itemSerial(item);
        const id = relation && (relation.serial_id || relation.serialid || (serial && (serial.serial_id || serial.serialid)));
        return id == null ? "" : String(id);
    }

    function subscriptionId(item) {
        const relation = item && item.serial_item;
        const serial = itemSerial(item);
        const id = (serial && (serial.subscription_id || serial.subscriptionid)) ||
            (relation && (relation.subscription_id || relation.subscriptionid));
        return id == null ? "" : String(id);
    }

    // Index de TOUS les fascicules de TOUS les tableaux annuels de l'abonnement.
    // Ne pas supposer qu'une ligne précédente à l'écran est chronologiquement
    // plus récente : le tri DataTables et les dates de publication peuvent différer.
    function collectionIssueIndex(tables) {
        const index = new Map();
        (tables || []).forEach(function (table) {
            if (!table || !document.contains(table)) return;
            const headers = Array.from((table.tHead && table.tHead.rows[0] && table.tHead.rows[0].cells) || []);
            const headingIndex = function (values) {
                return headers.findIndex(h => values.includes(normalizeText(h.textContent)));
            };
            const numberIndex = headingIndex(["numero", "number", "issue number"]);
            const publishedIndex = headingIndex(["publie le", "published on", "publication date"]);
            const receivedIndex = headingIndex(["date de reception", "received date", "date received"]);
            const statusIndex = headingIndex(["statut", "status"]);
            const branchIndex = headingIndex(["bibliotheque", "library", "branch"]);
            if (statusIndex < 0 || numberIndex < 0) return;
            collectionTableRows(table).forEach(function (row) {
                const input = row.querySelector('input[name="serialid"]');
                if (!input || !input.value) return;
                const getCell = idx => idx >= 0 ? row.cells[idx] : null;
                const rawNumber = String(getCell(numberIndex)?.textContent || "").trim();
                const numeric = rawNumber.match(/^n\s*[°ºo.]?\s*(\d+)\s*$/i) || rawNumber.match(/^(\d+)$/);
                const publishedCell = getCell(publishedIndex), receivedCell = getCell(receivedIndex);
                const dateOf = cell => {
                    const date = cell && (cell.getAttribute("data-order") || cell.textContent);
                    const parsed = date && parseDateText(date);
                    return parsed ? [parsed.getFullYear(), String(parsed.getMonth()+1).padStart(2,"0"), String(parsed.getDate()).padStart(2,"0")].join("-") : "";
                };
                const site = normalizeText(getCell(branchIndex)?.textContent || "");
                const status = statusKeyFromText(getCell(statusIndex)?.textContent || "");
                const serialId = String(input.value);
                const info = { serialId, number: rawNumber, numberValue: numeric ? Number(numeric[1]) : null,
                    publishedDate: dateOf(publishedCell), receivedDate: dateOf(receivedCell), site, status };
                if (!index.has(serialId)) index.set(serialId, []);
                index.get(serialId).push(info);
            });
        });
        return index;
    }

    function isNewerCollectionIssue(candidate, old) {
        if (!candidate || !old || candidate.serialId === old.serialId) return false;
        // La numérotation explicite prime : des dates de publication peuvent
        // être saisies hors séquence (cas des N°173 et N°174 constaté).
        if (candidate.numberValue !== null && old.numberValue !== null) {
            return candidate.numberValue > old.numberValue;
        }
        if (candidate.publishedDate && old.publishedDate && candidate.publishedDate !== old.publishedDate) {
            return candidate.publishedDate > old.publishedDate;
        }
        // Uniquement à défaut de date de publication : dates de réception.
        if (!candidate.publishedDate && !old.publishedDate && candidate.receivedDate && old.receivedDate) {
            return candidate.receivedDate > old.receivedDate;
        }
        return false; // Chronologie indéterminée : ne pas autoriser la modification.
    }

    // Une ligne du tableau ne suffit pas pour cibler un site : vérifier aussi
    // l'exemplaire lié du fascicule ultérieur, avec son home_library_id API.
    function newerReceivedIssue(item, allItems, config, issueIndex, groupedItems) {
        const cfg = config || currentConfig.loanRelease || DEFAULT_CONFIG.loanRelease;
        if (cfg.enabled === false || Number(item.not_for_loan_status) !== Number(cfg.consultationStatus)) return null;
        if (item.checked_out_date || item.checkout || item.onloan) return null;
        const oldSerialId = itemSerialId(item);
        if (!oldSerialId || !issueIndex || typeof issueIndex.get !== "function") return null;
        const oldHomeLibrary = String(item.home_library_id || "").trim();
        if (cfg.requireSameHomeLibrary !== false && !oldHomeLibrary) return null;
        const oldSubscription = subscriptionId(item);
        const lookup = groupedItems || groupCollectionItemsBySerial(allItems);
        const sourceRows = issueIndex.get(oldSerialId) || [];
        if (!sourceRows.length) return null;
        for (const oldRow of sourceRows) {
            for (const [serialId, candidateRows] of issueIndex) {
                if (serialId === oldSerialId) continue;
                for (const row of candidateRows) {
                    if (row.status !== "arrived" || !isNewerCollectionIssue(row, oldRow)) continue;
                    if (cfg.requireSameHomeLibrary !== false &&
                        (!oldRow.site || !row.site || oldRow.site !== row.site)) continue;
                    const possibleItems = lookup.get(serialId) || [];
                    for (const candidate of possibleItems) {
                        if (String(candidate.item_id) === String(item.item_id)) continue;
                        if (cfg.requireSameHomeLibrary !== false &&
                            String(candidate.home_library_id || "").trim() !== oldHomeLibrary) continue;
                        const otherSubscription = subscriptionId(candidate);
                        // Le tableau courant appartient au même abonnement ;
                        // ne pas exclure artificiellement si l'API omet un ID.
                        if (cfg.requireSameSubscription !== false && oldSubscription &&
                            otherSubscription && oldSubscription !== otherSubscription) continue;
                        if (Number(candidate.lost_status || 0) !== 0) continue;
                        const serial = itemSerial(candidate);
                        const apiStatus = serial && (serial.status ?? serial.serial_status);
                        if (apiStatus != null && String(apiStatus) !== "2") continue;
                        return { item: candidate, row, oldRow };
                    }
                }
            }
        }
        return null;
    }

    function groupCollectionItemsBySerial(items) {
        const index = new Map();
        (items || []).forEach(function (item) {
            const id = itemSerialId(item);
            if (!id) return;
            if (!index.has(id)) index.set(id, []);
            index.get(id).push(item);
        });
        return index;
    }

    function explainLoanReleaseMissing(item, issueIndex) {
        const old = (issueIndex.get(itemSerialId(item)) || [])[0];
        if (!old) return "Fascicule introuvable dans les tableaux";
        const laterSameSite = Array.from(issueIndex.values()).flat().filter(r =>
            r.site && old.site && r.site === old.site && isNewerCollectionIssue(r, old));
        if (!laterSameSite.length) return "Aucun numéro ultérieur dans ce site";
        if (!laterSameSite.some(r => r.status === "arrived")) return "Numéro(s) ultérieur(s) uniquement attendus / non reçus";
        return "Numéro plus récent reçu, mais concordance API (exemplaire, site ou statut) non vérifiable";
    }

    let loanReleaseDiagnostics = [];
    async function releaseConsultationItem(item, biblioId, button) {
        const cfg = currentConfig.loanRelease || DEFAULT_CONFIG.loanRelease;
        if (!window.confirm(t("Rendre cet ancien fascicule empruntable (statut 0) et réinitialiser son statut perdu à 0 si nécessaire ?", "Make this older issue available for loan (status 0) and clear its lost status if needed?"))) return;
        button.disabled = true;
        try {
            // Relire les exemplaires pour éviter d'agir sur des données anciennes.
            const freshItems = await fetchCollectionItems(biblioId);
            const freshItem = freshItems.find(x => String(x.item_id) === String(item.item_id));
            const freshIndex = collectionIssueIndex(Array.from(document.querySelectorAll("table.subscription-year-table")));
            const newer = freshItem && newerReceivedIssue(freshItem, freshItems, cfg, freshIndex);
            if (!newer) throw new Error(t("Aucun fascicule plus récent réceptionné et vérifiable, ou statut modifié.", "No verifiable newer received issue, or item status changed."));
            const latestResponse = await weedingRequest("/api/v1/items/" + encodeURIComponent(item.item_id), "GET");
            const latest = await latestResponse.json();
            if (Number(latest.not_for_loan_status) !== Number(cfg.consultationStatus) ||
                latest.checked_out_date || latest.checkout || latest.onloan) {
                throw new Error(t("L'exemplaire n'est plus éligible.", "Item is no longer eligible."));
            }
            const changes = { not_for_loan_status: Number(cfg.availableStatus) };
            if (cfg.clearLostStatus !== false && Number(latest.lost_status || 0) !== 0) {
                changes.lost_status = 0;
            }
            await weedingRequest("/api/v1/biblios/" + encodeURIComponent(biblioId) + "/items/" + encodeURIComponent(item.item_id), "PUT", changes);
            collectionItemsCache = null;
            refreshCollectionItems();
        } catch (error) {
            window.alert(t("Changement de statut impossible : ", "Status change failed: ") + error.message);
        } finally { button.disabled = false; }
    }

    function renderLoanRelease(line, item, biblioId, items, issueIndex, groupedItems) {
        const cfg = currentConfig.loanRelease || DEFAULT_CONFIG.loanRelease;
        const newer = newerReceivedIssue(item, items, cfg, issueIndex, groupedItems);
        if (Number(item.not_for_loan_status) === Number(cfg.consultationStatus)) {
            const oldRows = issueIndex.get(itemSerialId(item)) || [];
            loanReleaseDiagnostics.push({ barcode: String(item.external_id || ""), itemId: item.item_id,
                serialId: itemSerialId(item), numero: oldRows[0]?.number || "?",
                site: String(item.home_library_id || ""), bouton: Boolean(newer),
                nouveauNumero: newer ? newer.row.number : "",
                diagnostic: newer ? "Nouveau fascicule reçu, même site" : explainLoanReleaseMissing(item, issueIndex) });
            if (!newer) line.title = explainLoanReleaseMissing(item, issueIndex);
        }
        if (!newer) return;
        const wrap = document.createElement("div");
        wrap.className = "pmk029-loan-release";
        const label = document.createElement("span");
        label.textContent = t("Nouveau fascicule réceptionné", "Newer issue received");
        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn btn-default btn-xs";
        button.textContent = detectLanguage() === "en" ? (cfg.buttonLabelEn || "Make available for loan") : (cfg.buttonLabelFr || "Rendre empruntable");
        button.addEventListener("click", () => releaseConsultationItem(item, biblioId, button));
        wrap.append(label, button);
        line.appendChild(wrap);
    }

    async function refreshCollectionItems() {
        if (window.location.pathname !== COLLECTION_PAGE_PATH) return;
        installCollectionItemStyles();
        const cfg = collectionItemsConfig();
        if (!isPageEnabled(currentConfig, COLLECTION_PAGE_ID) || cfg.enabled === false) {
            cleanupCollectionItems(); return;
        }
        const run = ++collectionItemsRun;
        if (collectionItemsController) collectionItemsController.abort();
        collectionItemsController = new AbortController();
        const signal = collectionItemsController.signal;
        const tables = Array.from(document.querySelectorAll("table.subscription-year-table"));
        function visitCells(callback) {
            tables.forEach(function (table) {
                if (!document.contains(table)) return;
                const rows = collectionTableRows(table);
                rows.forEach(function (row) {
                    const cell = row.querySelector("td.pmk029-item-column");
                    if (cell) callback(cell, row);
                });
                const api = collectionDataTable(table);
                if (api) {
                    try { api.rows().invalidate("dom").draw(false); }
                    catch (error) { console.warn("[PMK029] Redessin DataTables différé :", error); }
                }
            });
        }
        try {
            tables.forEach(function (table) {
                if (collectionItemsTables.has(table)) return;
                const api = collectionDataTable(table);
                const settings = api && api.settings()[0];
                const columns = settings ? settings.aoColumns.map(function (col) {
                    return { orderable: col.bSortable, searchable: col.bSearchable, visible: col.bVisible, className: col.sClass || "" };
                }) : null;
                collectionItemsTables.set(table, { columns: columns, columnDefs: settings && (settings.oInit.columnDefs || settings.oInit.aoColumnDefs) });
                try { changeCollectionItemColumn(table, true); }
                catch (error) { collectionItemsTables.delete(table); throw error; }
            });
            const link = document.querySelector('#editbiblio[href], #edititems[href], a[href*="detail.pl?biblionumber="]');
            const biblioId = link && new URL(link.href, window.location.href).searchParams.get("biblionumber");
            if (!biblioId || !/^\d+$/.test(biblioId)) throw new Error(t("Notice introuvable sur cette page", "Record not found on this page"));
            visitCells(function (cell) { cell.textContent = t("Chargement…", "Loading…"); });
            const items = collectionItemsCache && collectionItemsCache.id === biblioId
                ? collectionItemsCache.items : await fetchCollectionItems(biblioId, signal);
            if (run !== collectionItemsRun || signal.aborted) return;
            collectionItemsCache = { id: biblioId, items: items };
            const weedingCfg = currentConfig.weeding || DEFAULT_CONFIG.weeding;
            let periodicity = null;
            if (weedingCfg.enabled || weedingCfg.showPeriodicity !== false) {
                try { periodicity = await loadWeedingPeriod(biblioId, signal); }
                catch (error) { console.warn("[PMK029] Périodicité 326$a indisponible :", error.message); }
            }
            const weedingPeriod = periodicity ? periodicity.key : "";
            collectionWeedingContext = { period: weedingPeriod };
            if (run !== collectionItemsRun || signal.aborted) return;
            const issueIndex = collectionIssueIndex(tables);
            loanReleaseDiagnostics = [];
            const bySerial = groupCollectionItemsBySerial(items);
            function makeLink(label, path) {
                const a = document.createElement("a"); a.textContent = label; a.href = path;
                if (cfg.openInNewTab !== false) { a.target = "_blank"; a.rel = "noopener"; }
                return a;
            }
            visitCells(function (cell, row) {
                cell.replaceChildren();
                const input = row.querySelector('input[name="serialid"]');
                if (!input) { cell.textContent = "—"; return; }
                const matched = bySerial.get(input.value) || [];
                if (!matched.length) { const empty = document.createElement("span"); empty.className = "pmk029-item-empty"; empty.textContent = t("Aucun exemplaire lié", "No linked item"); cell.appendChild(empty); return; }
                matched.forEach(function (item) {
                    const line = document.createElement("div");
                    line.className = "pmk029-item-card";
                    const top = document.createElement("div");
                    top.className = "pmk029-item-top";
                    const actions = document.createElement("span");
                    actions.className = "pmk029-item-actions";
                    const meta = document.createElement("div");
                    meta.className = "pmk029-item-meta";
                    const id = String(item.biblio_id || biblioId);
                    const barcode = makeLink(item.external_id || t("Sans code-barres", "No barcode"), "/cgi-bin/koha/catalogue/moredetail.pl?biblionumber=" + encodeURIComponent(id) + "&itemnumber=" + encodeURIComponent(item.item_id));
                    barcode.className = "pmk029-item-barcode";
                    barcode.title = t("Voir le détail de cet exemplaire", "View this item's details");
                    top.appendChild(barcode);
                    if (cfg.showItemLink !== false && item.item_id != null) {
                        actions.appendChild(makeLink(t("Notice", "Record"), "/cgi-bin/koha/catalogue/detail.pl?biblionumber=" + encodeURIComponent(id)));
                    }
                    if (cfg.showEditLink !== false && item.item_id != null) {
                        const edit = makeLink(t("Modifier", "Edit"), "/cgi-bin/koha/cataloguing/additem.pl?op=edititem&biblionumber=" + encodeURIComponent(id) + "&itemnumber=" + encodeURIComponent(item.item_id) + "#edititem");
                        edit.className = "pmk029-item-edit";
                        edit.title = t("Modifier cet exemplaire", "Edit this item");
                        actions.appendChild(edit);
                    }
                    if (actions.childNodes.length) top.appendChild(actions);
                    function addInfo(label, value, className) {
                        const info = document.createElement("span");
                        info.className = className;
                        info.title = label + " : " + value;
                        const caption = document.createElement("span");
                        caption.className = "pmk029-item-label";
                        caption.textContent = label + " : ";
                        info.append(caption, document.createTextNode(value));
                        meta.appendChild(info);
                    }
                    if (cfg.showCallnumber !== false) addInfo(t("Cote", "Call number"), item.callnumber || "—", "pmk029-item-callnumber");
                    if (cfg.showItemStatus !== false) addInfo(t("Statut", "Status"), collectionItemStatusLabel(item, "not_for_loan_status", "notforloan", t("Prêtable", "For loan")), "pmk029-item-chip" + (item.not_for_loan_status != null && Number(item.not_for_loan_status) !== 0 ? " is-alert" : ""));
                    if (cfg.showLostStatus !== false) addInfo(t("Perdu", "Lost"), collectionItemStatusLabel(item, "lost_status", "itemlost", t("Non", "No")), "pmk029-item-chip" + (item.lost_status != null && Number(item.lost_status) !== 0 ? " is-lost" : ""));
                    if (weedingCfg.showPeriodicity !== false && periodicity) {
                        const hasRule = Object.prototype.hasOwnProperty.call(weedingCfg.periods || {}, periodicity.key)
                            && Number(weedingCfg.periods[periodicity.key]) > 0;
                        const periodLabel = periodicity.label || t("Non renseignée", "Not specified");
                        const ruleText = periodicity.label && !hasRule
                            ? t(" (aucun délai de désherbage défini)", " (no weeding retention period defined)") : "";
                        addInfo(t("Périodicité", "Frequency"), periodLabel + ruleText,
                            "pmk029-item-periodicity" + (periodicity.label && !hasRule ? " is-unconfigured" : ""));
                    }
                    line.appendChild(top);
                    if (meta.childNodes.length) line.appendChild(meta);
                    renderWeedingInfo(line, item, id, weedingPeriod);
                    renderLoanRelease(line, item, id, items, issueIndex, bySerial);
                    cell.appendChild(line);
                });
            });
        } catch (error) {
            if (run !== collectionItemsRun || signal.aborted) return;
            visitCells(function (cell) { cell.textContent = t("Codes-barres indisponibles : ", "Barcodes unavailable: ") + error.message; });
        }
    }

    function collectionSortConfig() {
        const cfg = currentConfig && currentConfig.collectionSort;
        return cfg && typeof cfg === "object" ? cfg : DEFAULT_CONFIG.collectionSort;
    }

    function collectionNumberColumnIndex(table) {
        if (!table) return -1;
        const api = collectionDataTable(table);
        const headers = api ? api.columns().header().toArray() : Array.from(table.querySelectorAll("thead th"));
        const exact = ["numero", "number", "issue number", "numero de fascicule"];
        return headers.findIndex(function (header) {
            return exact.includes(normalizeText(header.textContent));
        });
    }

    function hideCollectionPublicationText() {
        if (!isPageEnabled(currentConfig, COLLECTION_PAGE_ID)) return;
        document.querySelectorAll("table.subscription-year-table").forEach(function (table) {
            const api = collectionDataTable(table);
            const headers = api ? api.columns().header().toArray() : Array.from(table.querySelectorAll("thead th"));
            const index = headers.findIndex(function (header) {
                return ["publie le (texte)", "published on (text)", "publication date (text)", "published date (text)"].includes(normalizeText(header.textContent));
            });
            if (index < 0) return;
            if (api) {
                if (api.column(index).visible()) api.column(index).visible(false);
            } else {
                // Attendre DataTables pour masquer sans fausser son initialisation.
                // Si DataTables n'est pas chargé, masquer uniquement l'affichage.
                const jq = window.jQuery || window.$;
                if (jq && jq.fn && jq.fn.dataTable) return;
                headers[index].style.display = "none";
                Array.from(table.tBodies || []).forEach(function (tbody) {
                    Array.from(tbody.rows).forEach(function (row) {
                        if (row.cells[index]) row.cells[index].style.display = "none";
                    });
                });
            }
        });
    }

    function collectionNaturalKey(value) {
        return normalizeText(value).replace(/\d+/g, function (digits) {
            return digits.padStart(20, "0");
        });
    }

    function prepareCollectionNaturalKeys(table, columnIndex) {
        if (!table || columnIndex < 0) return;
        Array.from(table.tBodies || []).forEach(function (tbody) {
            Array.from(tbody.rows || []).forEach(function (row) {
                const cell = row.cells && row.cells[columnIndex];
                if (!cell) return;
                if (!cell.hasAttribute("data-pmk029-natural-order")) {
                    cell.setAttribute("data-pmk029-had-order", cell.hasAttribute("data-order") ? "1" : "0");
                    cell.setAttribute("data-pmk029-original-order", cell.getAttribute("data-order") || "");
                }
                cell.setAttribute("data-order", collectionNaturalKey(cell.textContent || ""));
                cell.setAttribute("data-pmk029-natural-order", "1");
            });
        });
    }

    function collectionDataTable(table) {
        const jq = window.jQuery || window.$;
        if (!jq || !jq.fn || !jq.fn.dataTable || typeof jq.fn.dataTable.isDataTable !== "function") return null;
        if (!jq.fn.dataTable.isDataTable(table)) return null;
        try { return jq(table).DataTable(); } catch (_) { return null; }
    }

    function applyCollectionSortToTable(table) {
        if (!table || !table.matches("table.subscription-year-table")) return false;
        const cfg = collectionSortConfig();
        if (cfg.enabled === false) return true;
        const columnIndex = collectionNumberColumnIndex(table);
        if (columnIndex < 0) return false;

        prepareCollectionNaturalKeys(table, columnIndex);
        const api = collectionDataTable(table);
        if (!api) return false;

        if (!collectionOriginalOrders.has(table)) {
            try {
                const currentOrder = api.order();
                collectionOriginalOrders.set(table, Array.isArray(currentOrder) ? currentOrder.map(function (pair) { return pair.slice(); }) : []);
            } catch (_) {
                collectionOriginalOrders.set(table, []);
            }
        }

        try {
            api.rows().invalidate("dom");
            api.order([[columnIndex, cfg.direction === "asc" ? "asc" : "desc"]]).draw(false);
            table.setAttribute("data-pmk029-collection-sorted", "1");
            return true;
        } catch (_) {
            return false;
        }
    }

    function cleanupCollectionSort(restoreOrder) {
        if (collectionRetryTimer) {
            clearTimeout(collectionRetryTimer);
            collectionRetryTimer = null;
        }

        const jq = window.jQuery || window.$;
        if (jq) {
            try { jq(document).off("init.dt.pmk029CollectionSort"); } catch (_) {}
        }

        document.querySelectorAll('td[data-pmk029-natural-order="1"]').forEach(function (cell) {
            if (cell.getAttribute("data-pmk029-had-order") === "1") {
                cell.setAttribute("data-order", cell.getAttribute("data-pmk029-original-order") || "");
            } else {
                cell.removeAttribute("data-order");
            }
            cell.removeAttribute("data-pmk029-natural-order");
            cell.removeAttribute("data-pmk029-had-order");
            cell.removeAttribute("data-pmk029-original-order");
        });

        document.querySelectorAll('table.subscription-year-table[data-pmk029-collection-sorted="1"]').forEach(function (table) {
            table.removeAttribute("data-pmk029-collection-sorted");
            if (restoreOrder !== true) return;
            const api = collectionDataTable(table);
            const original = collectionOriginalOrders.get(table);
            if (!api || !Array.isArray(original) || !original.length) return;
            try { api.rows().invalidate("dom"); api.order(original).draw(false); } catch (_) {}
        });
    }

    function refreshCollectionSort() {
        if (window.location.pathname !== COLLECTION_PAGE_PATH) return;
        if (!isPageEnabled(currentConfig, COLLECTION_PAGE_ID) || collectionSortConfig().enabled === false) {
            cleanupCollectionSort(true);
            return;
        }

        const tables = Array.from(document.querySelectorAll("table.subscription-year-table"));
        tables.forEach(function (table) {
            const columnIndex = collectionNumberColumnIndex(table);
            if (columnIndex >= 0) prepareCollectionNaturalKeys(table, columnIndex);
        });

        const pending = tables.filter(function (table) { return !applyCollectionSortToTable(table); });
        if (!pending.length) return;

        let attempts = 0;
        const retry = function () {
            attempts += 1;
            const stillPending = pending.filter(function (table) { return document.contains(table) && !applyCollectionSortToTable(table); });
            if (stillPending.length && attempts < 40) collectionRetryTimer = window.setTimeout(retry, 100);
            else collectionRetryTimer = null;
        };
        collectionRetryTimer = window.setTimeout(retry, 50);
    }

    function initializeCollectionPage() {
        cleanupCollectionSort(false);
        if (!isPageEnabled(currentConfig, COLLECTION_PAGE_ID)) return;

        const jq = window.jQuery || window.$;
        if (jq) {
            try {
                jq(document)
                    .off("init.dt.pmk029CollectionSort")
                    .on("init.dt.pmk029CollectionSort", function (event, settings) {
                        const table = settings && settings.nTable;
                        if (table && table.matches && table.matches("table.subscription-year-table")) {
                            window.setTimeout(function () { applyCollectionSortToTable(table); hideCollectionPublicationText(); }, 0);
                        }
                    });
            } catch (_) {}
        }

        waitForSelector("table.subscription-year-table", 6000)
            .then(function () { refreshCollectionSort(); hideCollectionPublicationText(); refreshCollectionItems(); })
            .catch(function () { refreshCollectionSort(); hideCollectionPublicationText(); refreshCollectionItems(); });
    }

    function subscriptionLengthConfig() {
        const cfg = currentConfig && currentConfig.subscriptionLength;
        return cfg && typeof cfg === "object" ? cfg : DEFAULT_CONFIG.subscriptionLength;
    }

    function installSubscriptionLengthStyles() {
        if (document.getElementById("pmk029-subscription-length-style")) return;
        const style = document.createElement("style");
        style.id = "pmk029-subscription-length-style";
        style.textContent = `
            .pmk029-subscription-length-tools {
                display: inline-flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .4rem;
                margin: .45rem 0 .15rem .45rem;
                vertical-align: middle;
            }
            .pmk029-subscription-length-tools .pmk029-subscription-calc {
                display: inline-flex;
                align-items: center;
                gap: .35rem;
            }
            .pmk029-subscription-length-status {
                flex-basis: 100%;
                margin: .15rem 0 0;
                max-width: 52rem;
                font-size: .86rem;
                line-height: 1.35;
                color: #495057;
            }
            .pmk029-subscription-length-status.is-error { color: #b02a37; }
            .pmk029-subscription-length-status.is-success { color: #146c43; }
            .pmk029-subscription-length-status.is-info { color: #495057; }
            @media (max-width: 767.98px) {
                .pmk029-subscription-length-tools {
                    display: flex;
                    width: 100%;
                    margin-left: 0;
                    margin-top: .5rem;
                }
                .pmk029-subscription-length-tools .pmk029-subscription-calc {
                    width: auto;
                }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function removeSubscriptionLengthStyles() {
        const style = document.getElementById("pmk029-subscription-length-style");
        if (style) style.remove();
    }

    function removeSubscriptionLengthListeners() {
        subscriptionLengthListeners.forEach(function (entry) {
            try { entry.node.removeEventListener(entry.type, entry.handler); } catch (_) {}
        });
        subscriptionLengthListeners = [];
    }

    function addSubscriptionLengthListener(node, type, handler) {
        if (!node) return;
        node.addEventListener(type, handler);
        subscriptionLengthListeners.push({ node: node, type: type, handler: handler });
    }

    function subscriptionField(name) {
        const cfg = subscriptionLengthConfig();
        const selectors = cfg.selectors || DEFAULT_CONFIG.subscriptionLength.selectors;
        const selector = String(selectors[name] || DEFAULT_CONFIG.subscriptionLength.selectors[name] || "").trim();
        if (!selector) return null;
        try { return document.querySelector(selector); } catch (_) { return null; }
    }

    function parseKohaDate(value) {
        const raw = String(value || "").trim();
        if (!raw) return null;

        let match = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (match) {
            const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
            return Number.isNaN(date.getTime()) ? null : date;
        }

        match = raw.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
        if (match) {
            const first = Number(match[1]);
            const second = Number(match[2]);
            const year = Number(match[3]);
            const day = detectLanguage() === "en" && first <= 12 && second > 12 ? second : first;
            const month = detectLanguage() === "en" && first <= 12 && second > 12 ? first : second;
            const date = new Date(year, month - 1, day);
            return Number.isNaN(date.getTime()) ? null : date;
        }

        const nativeDate = new Date(raw);
        return Number.isNaN(nativeDate.getTime()) ? null : nativeDate;
    }

    function calendarDayDiff(start, end) {
        const a = Date.UTC(start.getFullYear(), start.getMonth(), start.getDate());
        const b = Date.UTC(end.getFullYear(), end.getMonth(), end.getDate());
        return Math.round((b - a) / 86400000);
    }

    function addCalendarMonthsClamped(date, months) {
        const targetMonthIndex = date.getMonth() + Number(months || 0);
        const year = date.getFullYear() + Math.floor(targetMonthIndex / 12);
        const month = ((targetMonthIndex % 12) + 12) % 12;
        const lastDay = new Date(year, month + 1, 0).getDate();
        return new Date(year, month, Math.min(date.getDate(), lastDay));
    }

    function calendarMonthsCeil(start, end) {
        if (end <= start) return 0;
        let months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
        if (months < 0) return 0;
        if (addCalendarMonthsClamped(start, months) < end) months += 1;
        return months;
    }

    function normalizedFrequencyUnit(value) {
        const unit = normalizeText(value);
        if (!unit || ["none", "aucune", "aucun", "irregular", "irregulier", "irrégulier"].includes(unit)) return "none";
        if (["day", "days", "jour", "jours"].includes(unit)) return "day";
        if (["week", "weeks", "semaine", "semaines"].includes(unit)) return "week";
        if (["month", "months", "mois"].includes(unit)) return "month";
        if (["year", "years", "annee", "annees", "année", "années", "an", "ans"].includes(unit)) return "year";
        return unit;
    }

    function finitePositive(value) {
        const number = Number(value);
        return Number.isFinite(number) && number > 0 ? number : null;
    }

    function dataValue(element, names) {
        if (!element) return "";
        for (const name of names) {
            if (element.dataset && element.dataset[name] != null && String(element.dataset[name]).trim()) {
                return String(element.dataset[name]).trim();
            }
            const dashed = name.replace(/[A-Z]/g, function (letter) { return "-" + letter.toLowerCase(); });
            const attr = element.getAttribute && element.getAttribute("data-" + dashed);
            if (attr != null && String(attr).trim()) return String(attr).trim();
        }
        return "";
    }

    function frequencyFromSelectedOption(select) {
        if (!select || !select.options || select.selectedIndex < 0) return null;
        const option = select.options[select.selectedIndex];
        if (!option) return null;

        const unit = dataValue(option, ["unit", "frequencyUnit"]);
        const issues = finitePositive(dataValue(option, ["issuesperunit", "issuesPerUnit"]));
        const units = finitePositive(dataValue(option, ["unitsperissue", "unitsPerIssue"]));
        if (!unit || !issues || !units) return null;

        return {
            id: String(option.value || ""),
            description: String(option.textContent || "").trim(),
            unit: normalizedFrequencyUnit(unit),
            issuesPerUnit: issues,
            unitsPerIssue: units,
            source: "page"
        };
    }

    function inputValueFromDocument(doc, selectors) {
        for (const selector of selectors) {
            const node = doc.querySelector(selector);
            if (!node) continue;
            if (node.type === "radio") {
                const checked = doc.querySelector(selector.replace(/:checked$/, "") + ":checked");
                if (checked) return String(checked.value || "").trim();
            }
            if (node.tagName === "SELECT") return String(node.value || "").trim();
            return String(node.value || node.textContent || "").trim();
        }
        return "";
    }

    function parseFrequencyDocument(doc, id) {
        if (!doc) return null;
        const unit = inputValueFromDocument(doc, [
            '#unit', 'select[name="unit"]', 'input[name="unit"]:checked', 'input[name="unit"]'
        ]);
        const issues = finitePositive(inputValueFromDocument(doc, [
            '#issuesperunit', '[name="issuesperunit"]', '[name="issues_per_unit"]'
        ]));
        const units = finitePositive(inputValueFromDocument(doc, [
            '#unitsperissue', '[name="unitsperissue"]', '[name="units_per_issue"]'
        ]));
        const description = inputValueFromDocument(doc, [
            '#description', '[name="description"]'
        ]);

        if (!unit || !issues || !units) return null;
        return {
            id: String(id || ""),
            description: description,
            unit: normalizedFrequencyUnit(unit),
            issuesPerUnit: issues,
            unitsPerIssue: units,
            source: "koha-frequency"
        };
    }

    function frequencyDefinitionUrl(id) {
        return "/cgi-bin/koha/serials/subscription-frequencies.pl?op=modify&frequencyid=" + encodeURIComponent(id);
    }

    async function fetchFrequencyDefinition(id) {
        const key = String(id || "").trim();
        if (!key) return null;
        if (frequencyDefinitionCache.has(key)) return frequencyDefinitionCache.get(key);

        const promise = (async function () {
            try {
                const response = await fetch(frequencyDefinitionUrl(key), {
                    method: "GET",
                    credentials: "same-origin",
                    headers: { "Accept": "text/html" },
                    cache: "no-store"
                });
                if (!response.ok) return null;
                const html = await response.text();
                const doc = new DOMParser().parseFromString(html, "text/html");
                return parseFrequencyDocument(doc, key);
            } catch (_) {
                return null;
            }
        })();

        frequencyDefinitionCache.set(key, promise);
        return promise;
    }

    async function resolveFrequencyDefinition() {
        const select = subscriptionField("frequency");
        if (!select) return null;

        const direct = frequencyFromSelectedOption(select);
        if (direct) return direct;

        const cfg = subscriptionLengthConfig();
        if (cfg.fetchFrequencyDefinition === false) return null;
        return fetchFrequencyDefinition(select.value);
    }

    function formatDateForMessage(date) {
        if (!date) return "";
        try {
            return new Intl.DateTimeFormat(detectLanguage() === "en" ? "en-GB" : "fr-FR").format(date);
        } catch (_) {
            return [String(date.getDate()).padStart(2, "0"), String(date.getMonth() + 1).padStart(2, "0"), date.getFullYear()].join("/");
        }
    }

    function frequencyHumanLabel(frequency) {
        if (!frequency) return "";
        const unitLabels = detectLanguage() === "en"
            ? { day: "day", week: "week", month: "month", year: "year" }
            : { day: "jour", week: "semaine", month: "mois", year: "année" };
        const unit = unitLabels[frequency.unit] || frequency.unit;
        if (detectLanguage() === "en") {
            return frequency.issuesPerUnit + " issue(s) every " + frequency.unitsPerIssue + " " + unit + "(s)";
        }
        return frequency.issuesPerUnit + " fascicule(s) pour " + frequency.unitsPerIssue + " " + unit + "(s)";
    }

    function countIssuesBetween(start, end, frequency) {
        if (!frequency) return { ok: false, reason: t("Périodicité introuvable.", "Frequency definition not found.") };
        if (frequency.unit === "none") {
            return { ok: false, reason: t("La périodicité est irrégulière : le nombre de fascicules ne peut pas être calculé automatiquement.", "The frequency is irregular: issue count cannot be calculated automatically.") };
        }
        if (end < start) return { ok: false, reason: t("La date de fin est antérieure à la date de départ.", "End date is before start date.") };

        const issuesPerUnit = finitePositive(frequency.issuesPerUnit);
        const unitsPerIssue = finitePositive(frequency.unitsPerIssue);
        if (!issuesPerUnit || !unitsPerIssue) {
            return { ok: false, reason: t("La définition de périodicité Koha est incomplète.", "Koha frequency definition is incomplete.") };
        }

        const diffDays = calendarDayDiff(start, end);
        if (frequency.unit === "day" || frequency.unit === "week") {
            const daysPerUnit = frequency.unit === "week" ? 7 : 1;
            const theoreticalInterval = (daysPerUnit * unitsPerIssue) / issuesPerUnit;
            if (!Number.isFinite(theoreticalInterval) || theoreticalInterval <= 0) {
                return { ok: false, reason: t("La périodicité ne permet pas un calcul fiable.", "The frequency cannot be calculated reliably.") };
            }
            const value = Math.floor((diffDays / theoreticalInterval) + 1e-9) + 1;
            return { ok: true, value: Math.max(1, value), estimated: issuesPerUnit > 1 };
        }

        if ((frequency.unit === "month" || frequency.unit === "year") && issuesPerUnit === 1) {
            const stepMonths = unitsPerIssue * (frequency.unit === "year" ? 12 : 1);
            let count = 0;
            let cursor = new Date(start.getFullYear(), start.getMonth(), start.getDate());
            while (cursor <= end && count < 10000) {
                count += 1;
                cursor = addCalendarMonthsClamped(cursor, stepMonths);
            }
            if (count >= 10000) {
                return { ok: false, reason: t("Le calcul dépasse la limite de sécurité.", "The calculation exceeds the safety limit.") };
            }
            return { ok: true, value: Math.max(1, count), estimated: false };
        }

        return {
            ok: false,
            reason: t(
                "Cette périodicité publie plusieurs fascicules par mois/année ; leur position exacte ne peut pas être déduite sans le prévisionnel Koha.",
                "This frequency publishes multiple issues per month/year; exact positions cannot be inferred without Koha's prediction pattern."
            )
        };
    }

    async function calculateSubscriptionLengthProposal() {
        const cfg = subscriptionLengthConfig();
        const subtypeNode = subscriptionField("subtype");
        const endNode = subscriptionField("endDate");
        const firstNode = subscriptionField("startDate");
        const nextNode = subscriptionField("nextIssueDate");

        if (!subtypeNode || !endNode || !firstNode) {
            return { ok: false, reason: t("Les champs nécessaires au calcul n'ont pas été trouvés dans cette version de Koha.", "Required fields were not found in this Koha version.") };
        }

        const subtype = String(subtypeNode.value || "").trim().toLowerCase();
        const end = parseKohaDate(endNode.value);
        const first = parseKohaDate(firstNode.value);
        if (!end) return { ok: false, reason: t("Renseigne une date de fin valide.", "Enter a valid end date.") };

        if (subtype === "weeks") {
            if (!first) return { ok: false, reason: t("Renseigne une date de début valide.", "Enter a valid start date.") };
            if (end < first) return { ok: false, reason: t("La date de fin est antérieure à la date de début.", "End date is before start date.") };
            const value = Math.ceil(calendarDayDiff(first, end) / 7);
            return {
                ok: true,
                value: Math.max(0, value),
                detail: t(
                    value + " semaine(s), du " + formatDateForMessage(first) + " au " + formatDateForMessage(end) + ".",
                    value + " week(s), from " + formatDateForMessage(first) + " to " + formatDateForMessage(end) + "."
                )
            };
        }

        if (subtype === "months") {
            if (!first) return { ok: false, reason: t("Renseigne une date de début valide.", "Enter a valid start date.") };
            if (end < first) return { ok: false, reason: t("La date de fin est antérieure à la date de début.", "End date is before start date.") };
            const value = calendarMonthsCeil(first, end);
            return {
                ok: true,
                value: Math.max(0, value),
                detail: t(
                    value + " mois calendaire(s), du " + formatDateForMessage(first) + " au " + formatDateForMessage(end) + ".",
                    value + " calendar month(s), from " + formatDateForMessage(first) + " to " + formatDateForMessage(end) + "."
                )
            };
        }

        if (subtype !== "issues") {
            return { ok: false, reason: t("Le type de durée sélectionné n'est pas reconnu.", "Selected subscription-length type is not recognized.") };
        }

        let start = null;
        let sourceLabel = "";
        if (cfg.issuesStartSource === "acqui_date") {
            start = first;
            sourceLabel = t("date du premier fascicule", "first issue date");
        } else {
            start = nextNode ? parseKohaDate(nextNode.value) : null;
            sourceLabel = t("prochaine date d'acquisition", "next acquisition date");
            if (!start && cfg.fallbackToFirstPublication !== false) {
                start = first;
                sourceLabel = t("date du premier fascicule (secours)", "first issue date (fallback)");
            }
        }

        if (!start) {
            return { ok: false, reason: t("La date servant de départ au calcul des fascicules n'est pas renseignée.", "The start date used for issue calculation is missing.") };
        }

        const frequency = await resolveFrequencyDefinition();
        if (!frequency) {
            return {
                ok: false,
                reason: t(
                    "Impossible de lire la définition réelle de la périodicité Koha. Aucune valeur n'a été écrite.",
                    "Could not read the real Koha frequency definition. No value was written."
                )
            };
        }

        const result = countIssuesBetween(start, end, frequency);
        if (!result.ok) return result;
        const frequencyLabel = frequency.description || frequencyHumanLabel(frequency);
        return {
            ok: true,
            value: result.value,
            detail: t(
                result.value + " fascicule(s), du " + formatDateForMessage(start) + " au " + formatDateForMessage(end) +
                    " — " + sourceLabel + " — " + (frequencyLabel || frequencyHumanLabel(frequency)) +
                    (result.estimated ? " (calcul proportionnel)" : "") + ".",
                result.value + " issue(s), from " + formatDateForMessage(start) + " to " + formatDateForMessage(end) +
                    " — " + sourceLabel + " — " + (frequencyLabel || frequencyHumanLabel(frequency)) +
                    (result.estimated ? " (proportional calculation)" : "") + "."
            )
        };
    }

    function subscriptionLengthStatusNode() {
        return document.getElementById("pmk029-subscription-length-status");
    }

    function setSubscriptionLengthStatus(kind, text) {
        const node = subscriptionLengthStatusNode();
        if (!node) return;
        node.className = "pmk029-subscription-length-status " + (kind ? "is-" + kind : "is-info");
        node.textContent = text || "";
        node.hidden = !text;
    }

    async function runSubscriptionLengthCalculation(options) {
        const opts = options || {};
        const lengthInput = subscriptionField("length");
        if (!lengthInput) {
            setSubscriptionLengthStatus("error", t("Champ Durée d'abonnement introuvable.", "Subscription length field not found."));
            return false;
        }

        const button = document.querySelector("#pmk029-subscription-length-tools .pmk029-subscription-calc");
        if (button) button.disabled = true;
        setSubscriptionLengthStatus("info", t("Calcul en cours…", "Calculating…"));

        try {
            const proposal = await calculateSubscriptionLengthProposal();
            if (!proposal.ok) {
                setSubscriptionLengthStatus("error", proposal.reason || t("Calcul impossible.", "Calculation unavailable."));
                return false;
            }

            lengthInput.value = String(proposal.value);
            try { lengthInput.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
            try { lengthInput.dispatchEvent(new Event("change", { bubbles: true })); } catch (_) {}

            const cfg = subscriptionLengthConfig();
            if (cfg.showDetails !== false) {
                setSubscriptionLengthStatus("success", proposal.detail || t("Durée calculée.", "Subscription length calculated."));
            } else {
                setSubscriptionLengthStatus("success", t("Durée calculée : ", "Calculated length: ") + proposal.value);
            }
            return true;
        } finally {
            if (button) button.disabled = false;
        }
    }

    function renderSubscriptionLengthAssistant() {
        cleanupSubscriptionLengthAssistant();
        if (window.location.pathname !== ADD_PAGE_PATH) return;
        if (!isPageEnabled(currentConfig, ADD_PAGE_ID)) return;

        const cfg = subscriptionLengthConfig();
        if (cfg.enabled === false) return;

        const lengthInput = subscriptionField("length");
        if (!lengthInput || !lengthInput.parentNode) return;
        installSubscriptionLengthStyles();

        const tools = document.createElement("span");
        tools.id = "pmk029-subscription-length-tools";
        tools.className = "pmk029-subscription-length-tools";

        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn btn-default btn-sm pmk029-subscription-calc";
        button.innerHTML = '<i class="fa fa-calculator" aria-hidden="true"></i><span></span>';
        button.querySelector("span").textContent = detectLanguage() === "en"
            ? String(cfg.buttonLabelEn || "Calculate")
            : String(cfg.buttonLabelFr || "Calculer");
        button.title = t("Calculer la durée à partir des dates et de la périodicité Koha", "Calculate length from dates and Koha frequency");
        addSubscriptionLengthListener(button, "click", function () { runSubscriptionLengthCalculation({ automatic: false }); });
        tools.appendChild(button);

        const status = document.createElement("small");
        status.id = "pmk029-subscription-length-status";
        status.className = "pmk029-subscription-length-status is-info";
        status.hidden = true;
        tools.appendChild(status);

        const host = lengthInput.closest("li, .form-group, .row, .col-sm-10, .col-md-10") || lengthInput.parentNode;
        host.appendChild(tools);

        if (cfg.automatic === true) {
            ["startDate", "endDate", "nextIssueDate", "frequency", "subtype"].forEach(function (fieldName) {
                const node = subscriptionField(fieldName);
                if (!node) return;
                addSubscriptionLengthListener(node, "change", function () {
                    runSubscriptionLengthCalculation({ automatic: true });
                });
            });
        }
    }

    function cleanupSubscriptionLengthAssistant() {
        removeSubscriptionLengthListeners();
        const tools = document.getElementById("pmk029-subscription-length-tools");
        if (tools) tools.remove();
        removeSubscriptionLengthStyles();
    }

    function initializeSubscriptionAddPage() {
        if (!isPageEnabled(currentConfig, ADD_PAGE_ID)) {
            cleanupSubscriptionLengthAssistant();
            return;
        }
        waitForSelector('#sublength, [name="sublength"]', 6000)
            .then(renderSubscriptionLengthAssistant)
            .catch(renderSubscriptionLengthAssistant);
    }

    function initializeEditPage() {
        if (!isPageEnabled(currentConfig, EDIT_PAGE_ID)) {
            cleanupReceivingAssistant();
            return;
        }

        // Précharge le prix depuis la fiche Koha de l'abonnement courant.
        // Ainsi serials-edit.pl fonctionne même lorsqu'on y arrive directement,
        // sans être passé auparavant par subscription-detail.pl ou serials-search.pl.
        const currentSubscriptionId = subscriptionIdFromPage();
        if (currentSubscriptionId) {
            fetchDetailPriceForSubscription(currentSubscriptionId, "serials-edit-preload");
        }

        waitForSelector('legend, input[name="serialseq"]', 6000)
            .then(renderReceivingAssistant)
            .catch(renderReceivingAssistant);
    }

    window.PMK029Serials = Object.freeze({
        version: MODULE_VERSION,
        getContext: readPriceContext,
        clearContext: clearPriceContext,
        inspectLoanRelease: function () { return loanReleaseDiagnostics.map(row => Object.assign({}, row)); },
        refreshPrice: function () {
            return fetchDetailPriceForSubscription(subscriptionIdFromPage(), "manual-refresh");
        },
        refresh: function () {
            if (window.location.pathname === DETAIL_PAGE_PATH) refreshPage(true);
            else if (window.location.pathname === SEARCH_PAGE_PATH) refreshSearchPage();
            else if (window.location.pathname === EDIT_PAGE_PATH) renderReceivingAssistant();
            else if (window.location.pathname === COLLECTION_PAGE_PATH) { refreshCollectionSort(); hideCollectionPublicationText(); refreshCollectionItems(); }
            else if (window.location.pathname === ADD_PAGE_PATH) renderSubscriptionLengthAssistant();
        }
    });

    function disconnectObservers() {
        observers.forEach(function (observer) {
            try { observer.disconnect(); } catch (_) {}
        });
        observers = [];
        if (mutationTimer) {
            clearTimeout(mutationTimer);
            mutationTimer = null;
        }
    }

    function observeTables(tables) {
        disconnectObservers();
        tables.forEach(function (table) {
            const tbody = table.tBodies && table.tBodies[0];
            if (!tbody) return;
            const observer = new MutationObserver(function (mutations) {
                const onlyPmk = mutations.every(function (mutation) {
                    return Array.from(mutation.addedNodes || []).every(function (node) {
                        return node.nodeType !== 1 ||
                            (node.matches && node.matches(".pmk029-claim-note, .pmk029-calendar-panel")) ||
                            (node.closest && node.closest(".pmk029-claim-note, .pmk029-calendar-panel"));
                    });
                });
                if (onlyPmk) return;

                if (mutationTimer) clearTimeout(mutationTimer);
                mutationTimer = window.setTimeout(function () {
                    mutationTimer = null;
                    refreshPage(false);
                }, 180);
            });
            observer.observe(tbody, { childList: true, subtree: true, characterData: true });
            observers.push(observer);
        });
    }

    function cleanupDecorations() {
        disconnectObservers();
        removeClaimNotes(document);

        document.querySelectorAll(".pmk029-status-badge-target").forEach(function (node) {
            node.classList.remove("pmk029-status-badge-target");
            node.style.removeProperty("--pmk029-status-bg");
            node.style.removeProperty("--pmk029-status-fg");
            node.removeAttribute("data-pmk029-icon");
        });

        document.querySelectorAll("[data-pmk029-status-key]").forEach(function (node) {
            node.removeAttribute("data-pmk029-status-key");
        });

        document.querySelectorAll(".pmk029-status-generated").forEach(function (node) {
            const textNode = document.createTextNode(node.textContent || "");
            node.replaceWith(textNode);
        });

        const panel = document.getElementById("pmk029-calendar-panel");
        if (panel) panel.remove();
        restorePlannedDateLabels();
        cleanupLayout();
        removeStyles();
    }

    function refreshPage(rebuildObservers) {
        if (window.location.pathname !== DETAIL_PAGE_PATH) return;
        if (!isPageEnabled(currentConfig, DETAIL_PAGE_ID)) {
            cleanupDecorations();
            return;
        }

        installStyles();
        applyDetailLayout();
        applyPlannedDateLabelCompatibility();
        installLegacySectionToggleCompatibility();
        installDetailDelegation();
        captureDetailPriceContext("subscription-detail-load");
        removeClaimNotes(document);
        const gracePeriod = getGracePeriod();
        const tables = getRelevantTables();
        tables.forEach(function (table) { processTable(table, gracePeriod); });

        const primary = getPrimaryFascicleTable();
        if (primary) {
            if (currentConfig.calendar && currentConfig.calendar.enabled !== false) {
                buildCalendarPanel(primary);
            } else {
                const panel = document.getElementById("pmk029-calendar-panel");
                if (panel) panel.remove();
            }
        }

        if (rebuildObservers !== false) observeTables(tables);
    }

    function initializeDetailPage() {
        if (initialized) {
            refreshPage(true);
            return;
        }
        initialized = true;

        waitForSelector("#subscription_info_panel, #subscription_issues_panel, .tableau-fasci, table.subscription-year-table", 6000)
            .then(function () { refreshPage(true); })
            .catch(function () {
                applyDetailLayout();
                refreshPage(true);
            });
    }

    function initializeSearchPage() {
        if (initialized) {
            refreshSearchPage();
            return;
        }
        initialized = true;
        installLegacySectionToggleCompatibility();
        installSearchDelegation();
        waitForSelector('a[href*="serials-edit.pl"], table.dataTable', 6000)
            .then(function () {
                refreshSearchPage();
                observeSearchPage();
            })
            .catch(function () { observeSearchPage(); });
    }

    // Recherche globale Koha : placer le curseur dans Titre, même après
    // les autofocus différés de Koha, sans contrarier une action de l'agent.
    // Réglage central PMKConfig : search.autoFocusTitle.
    let titleFocusObserver = null;
    let titleFocusUserInteracted = false;
    let titleFocusListenerInstalled = false;
    let titleFocusPending = false;

    function stopTitleFocusWatch() {
        if (titleFocusObserver) titleFocusObserver.disconnect();
        titleFocusObserver = null;
        if (titleFocusListenerInstalled) {
            document.removeEventListener("focusin", onSerialSearchFocusIn, true);
            titleFocusListenerInstalled = false;
        }
    }

    function canAutoFocusSerialTitle() {
        return !titleFocusUserInteracted &&
            currentConfig.enabled !== false &&
            currentConfig.search &&
            currentConfig.search.autoFocusTitle !== false &&
            window.location.pathname.startsWith("/cgi-bin/koha/serials/");
    }

    function tryFocusSerialTitle() {
        if (!canAutoFocusSerialTitle()) return false;
        const input = document.querySelector('#title_filter[name="title_filter"]');
        if (!input || input.disabled || input.readOnly || !input.getClientRects().length) return false;

        const active = document.activeElement;
        const noFocus = !active || active === document.body || active === document.documentElement;
        const kohaDefault = active && (active.id === "ISSN_filter" || active.id === "EAN_filter");
        if (!noFocus && !kohaDefault && active !== input) return false;

        if (active !== input) input.focus({ preventScroll: true });
        return document.activeElement === input;
    }

    function onSerialSearchFocusIn(event) {
        if (!canAutoFocusSerialTitle()) return;
        const target = event.target;
        if (!target || (target.id !== "ISSN_filter" && target.id !== "EAN_filter")) return;
        // Déférer très légèrement la correction pour passer après l'autofocus de Koha.
        if (titleFocusPending) return;
        titleFocusPending = true;
        window.setTimeout(function () {
            titleFocusPending = false;
            tryFocusSerialTitle();
        }, 0);
    }

    function initializeTitleSearchFocus() {
        if (!canAutoFocusSerialTitle()) {
            stopTitleFocusWatch();
            return;
        }
        if (!titleFocusListenerInstalled) {
            document.addEventListener("focusin", onSerialSearchFocusIn, true);
            titleFocusListenerInstalled = true;
        }
        tryFocusSerialTitle();
        if (!titleFocusObserver && document.documentElement) {
            titleFocusObserver = new MutationObserver(function () {
                if (tryFocusSerialTitle() && titleFocusObserver) {
                    titleFocusObserver.disconnect();
                    titleFocusObserver = null;
                }
            });
            titleFocusObserver.observe(document.documentElement, { childList: true, subtree: true });
        }
    }

    // Dès qu'un agent utilise le clavier, la souris ou le tactile,
    // on cesse définitivement de rediriger le curseur.
    ["pointerdown", "keydown", "touchstart"].forEach(function (eventName) {
        document.addEventListener(eventName, function () {
            titleFocusUserInteracted = true;
            stopTitleFocusWatch();
        }, { capture: true, once: true });
    });

    function applyConfig(config) {
        currentConfig = normalizeConfig(config);
        initializeTitleSearchFocus();
        const page = currentPageDefinition();
        if (!page) return;

        if (!isPageEnabled(currentConfig, page.id)) {
            if (page.id === DETAIL_PAGE_ID) cleanupDecorations();
            if (page.id === EDIT_PAGE_ID) cleanupReceivingAssistant();
            if (page.id === COLLECTION_PAGE_ID) {
                cleanupCollectionItems();
                cleanupCollectionSort(true);
            }
            if (page.id === ADD_PAGE_ID) cleanupSubscriptionLengthAssistant();
            disconnectObservers();
            return;
        }

        if (page.id === DETAIL_PAGE_ID) initializeDetailPage();
        else if (page.id === SEARCH_PAGE_ID) initializeSearchPage();
        else if (page.id === EDIT_PAGE_ID) initializeEditPage();
        else if (page.id === COLLECTION_PAGE_ID) initializeCollectionPage();
        else if (page.id === ADD_PAGE_ID) initializeSubscriptionAddPage();
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return Promise.resolve(clone(DEFAULT_CONFIG));
        }
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (config) { return normalizeConfig(config); })
            .catch(function () { return clone(DEFAULT_CONFIG); });
    }

    function start() {
        if (!window.location.pathname.startsWith("/cgi-bin/koha/serials/")) return;

        loadConfig().then(applyConfig);

        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
    }

    (function (callback) {
        if (document.readyState === 'complete') callback.call(window);
        else window.addEventListener('load', callback, { once: true });
    })(tryFocusSerialTitle);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }

})();

;window.PMKNonPlugin.loaded.push("029-subscription-periodiques.js");
} catch (error) { window.PMKNonPlugin.errors.push("029-subscription-periodiques.js: "+error.message); console.error("[PMK] 029-subscription-periodiques.js",error); };
try {
/*
 Nom du fichier: 031-alert-vide-champ-modif-lot.js
 Version: 3.0.0-preplugin
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha

 Module PimpMyKoha (phase pré-plugin) : Alerte avant vidage d'un champ

 Objectif :
 - sécuriser la suppression d'un sous-champ exemplaire via les cases Koha `disable_input` ;
 - intercepter l'intention AVANT le gestionnaire natif Koha ;
 - utiliser un dialogue HTML non bloquant ;
 - laisser Koha appliquer lui-même l'état de suppression après confirmation ;
 - restaurer exactement l'état initial après annulation ;
 - fonctionner en français et en anglais ;
 - rester fail-safe si la structure attendue n'est pas présente.

 Important :
 - le module ne supprime aucune donnée lui-même ;
 - aucune validation finale du formulaire n'est déclenchée automatiquement ;
 - aucune boîte `confirm()` native n'est utilisée.
*/
(function () {
    "use strict";

    if (window.__PMK031_BATCH_FIELD_CLEAR_WARNING__) return;
    window.__PMK031_BATCH_FIELD_CLEAR_WARNING__ = true;

    const MODULE_ID = "batchmod-empty-field-warning";
    const MODULE_VERSION = "3.0.0-preplugin";

    const PAGE_DEFINITIONS = [
        {
            id: "tools.batchmod",
            path: "/cgi-bin/koha/tools/batchMod.pl",
            enabled: true
        },
        {
            id: "cataloguing.additem",
            path: "/cgi-bin/koha/cataloguing/additem.pl",
            enabled: false
        }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: PAGE_DEFINITIONS,
        protection: {
            mode: "all"
        },
        fieldRules: [],
        dialog: {
            titleFr: "Confirmer le vidage de « {field} »",
            titleEn: "Confirm clearing “{field}”",
            messageFr: "Cette action demandera à Koha de supprimer la valeur de ce champ pour les exemplaires concernés par cette modification. La suppression ne sera effective qu'après l'enregistrement du formulaire.",
            messageEn: "This will ask Koha to clear this field for the items affected by this change. The deletion will only take effect after the form is saved.",
            showMarcReference: true,
            showItemCount: true
        }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let guardInstalled = false;
    let contextButtonMounted = false;

    const bypassOnce = new WeakSet();
    const pending = new WeakSet();

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return Boolean(value) && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) {
            return Array.isArray(override) ? clone(override) : clone(base);
        }
        if (!isObject(base)) {
            return override === undefined ? clone(base) : clone(override);
        }
        const out = clone(base);
        if (!isObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            out[key] = key in base ? deepMerge(base[key], override[key]) : clone(override[key]);
        });
        return out;
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            } catch (_) {}
        }
        const lang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function getCurrentPageConfig(config) {
        const path = window.location.pathname;
        const pages = Array.isArray(config && config.pages) ? config.pages : [];
        return pages.find(function (page) {
            return page && page.path === path;
        }) || null;
    }

    function isEnabledOnCurrentPage(config) {
        if (!config || config.enabled === false) return false;
        const page = getCurrentPageConfig(config);
        return Boolean(page && page.enabled !== false);
    }

    function isSupportedPath() {
        return PAGE_DEFINITIONS.some(function (page) {
            return page.path === window.location.pathname;
        });
    }

    function getSubfieldLine(checkbox) {
        return checkbox && checkbox.closest
            ? checkbox.closest(".subfield_line")
            : null;
    }

    function getHiddenValue(line, name) {
        if (!line) return "";
        const input = line.querySelector('input[name="' + name + '"]');
        return input ? String(input.value || "").trim() : "";
    }

    function getFieldInfo(checkbox) {
        const line = getSubfieldLine(checkbox);
        const labelNode = line ? line.querySelector("label") : null;
        const rawLabel = labelNode
            ? String(labelNode.textContent || "").replace(/\s+/g, " ").trim()
            : "";

        const label = rawLabel.replace(/^\s*[^-]{1,4}\s*-\s*/, "").trim() || rawLabel || checkbox.value || "Champ";
        const tag = getHiddenValue(line, "tag");
        const subfield = getHiddenValue(line, "subfield");
        const kohafield = getHiddenValue(line, "kohafield") || String(checkbox.value || "").trim();
        const importantRaw = getHiddenValue(line, "important");
        const important = ["1", "true", "yes", "on"].includes(normalizeText(importantRaw));

        return {
            line: line,
            label: label,
            rawLabel: rawLabel,
            tag: tag,
            subfield: subfield,
            marc: tag && subfield ? tag + "$" + subfield : "",
            kohafield: kohafield,
            important: important
        };
    }

    function ruleMatchesField(rule, info) {
        if (!rule || rule.enabled === false) return false;
        const match = normalizeText(rule.match);
        if (!match) return false;

        const candidates = [
            info.kohafield,
            info.marc,
            info.tag + info.subfield,
            info.tag + "$" + info.subfield,
            info.rawLabel,
            info.label
        ].map(normalizeText).filter(Boolean);

        return candidates.some(function (candidate) {
            return candidate === match || candidate.indexOf(match) !== -1;
        });
    }

    function shouldProtect(checkbox) {
        const protection = currentConfig.protection || {};
        const mode = protection.mode || "all";
        const info = getFieldInfo(checkbox);

        if (mode === "important") return info.important;
        if (mode === "custom") {
            const rules = Array.isArray(currentConfig.fieldRules) ? currentConfig.fieldRules : [];
            return rules.some(function (rule) {
                return ruleMatchesField(rule, info);
            });
        }
        return true;
    }

    function countAffectedItems(checkbox) {
        const form = checkbox && checkbox.form
            ? checkbox.form
            : (checkbox && checkbox.closest ? checkbox.closest("form") : null);
        if (!form) return 0;

        const values = new Set();
        form.querySelectorAll('input[name="itemnumber"]').forEach(function (input) {
            const value = String(input.value || "").trim();
            if (value) values.add(value);
        });
        return values.size;
    }

    function replaceTokens(template, values) {
        return String(template || "").replace(/\{([a-zA-Z0-9_]+)\}/g, function (_, key) {
            return Object.prototype.hasOwnProperty.call(values, key) ? String(values[key]) : "";
        });
    }

    function buildDialogCopy(checkbox) {
        const lang = detectLanguage();
        const info = getFieldInfo(checkbox);
        const count = countAffectedItems(checkbox);
        const dialog = currentConfig.dialog || DEFAULT_CONFIG.dialog;

        const values = {
            field: info.label || info.kohafield || info.marc || (lang === "en" ? "field" : "champ"),
            marc: info.marc,
            kohafield: info.kohafield,
            count: count
        };

        const title = replaceTokens(
            lang === "en" ? dialog.titleEn : dialog.titleFr,
            values
        );

        const parts = [
            replaceTokens(lang === "en" ? dialog.messageEn : dialog.messageFr, values)
        ];

        if (dialog.showMarcReference !== false && info.marc) {
            parts.push(
                lang === "en"
                    ? "MARC field: " + info.marc
                    : "Champ MARC : " + info.marc
            );
        }

        if (dialog.showItemCount !== false && count > 0) {
            parts.push(
                lang === "en"
                    ? count + " item" + (count > 1 ? "s" : "") + " detected in this batch."
                    : count + " exemplaire" + (count > 1 ? "s" : "") + " détecté" + (count > 1 ? "s" : "") + " dans ce lot."
            );
        }

        const form=checkbox.form || checkbox.closest('form');
        const selected=form?Array.from(form.querySelectorAll('input[name="disable_input"]:checked:not(:disabled)')):[];
        if(!selected.includes(checkbox))selected.push(checkbox);
        const recap=selected.slice(0,50).map(control=>{const field=getFieldInfo(control);return '• '+field.label+(field.marc?' ('+field.marc+')':'');});
        parts.push((lang==='en'?'Fields marked for clearing after confirmation:':'Champs marqués à vider après confirmation :')+'\n'+recap.join('\n'));
        if(selected.length>50)parts.push(lang==='en'?'First 50 fields shown; '+selected.length+' fields are marked.':'50 premiers champs affichés ; '+selected.length+' champs sont marqués.');

        parts.push(
            lang === "en"
                ? "Nothing is saved by this confirmation alone."
                : "Cette confirmation n'enregistre aucune modification à elle seule."
        );

        return {
            title: title,
            message: parts.filter(Boolean).join("\n\n"),
            confirmLabel: lang === "en" ? "Confirm clearing" : "Confirmer le vidage",
            cancelLabel: lang === "en" ? "Cancel" : "Annuler"
        };
    }

    function snapshotNativeState(checkbox) {
        const line = getSubfieldLine(checkbox);
        if (!line) return null;

        const controls = Array.from(line.querySelectorAll(".input_marceditor,.tag,.subfield,.mandatory")).map(function (node) {
            return {
                node: node,
                disabled: Boolean(node.disabled)
            };
        });

        const regexLinks = Array.from(line.querySelectorAll(".field_regex")).map(function (node) {
            return {
                node: node,
                display: node.style.display,
                hidden: Boolean(node.hidden)
            };
        });

        let hint = null;
        if (checkbox.id) {
            const hintId = checkbox.id.replace(/^row/, "hint");
            const hintNode = document.getElementById(hintId);
            if (hintNode) {
                hint = {
                    node: hintNode,
                    html: hintNode.innerHTML
                };
            }
        }

        return {
            controls: controls,
            regexLinks: regexLinks,
            hint: hint
        };
    }

    function restoreNativeState(checkbox, snapshot) {
        checkbox.checked = false;
        if (!snapshot) return;

        snapshot.controls.forEach(function (entry) {
            if (entry.node && entry.node.isConnected) entry.node.disabled = entry.disabled;
        });

        snapshot.regexLinks.forEach(function (entry) {
            if (!entry.node || !entry.node.isConnected) return;
            entry.node.style.display = entry.display;
            entry.node.hidden = entry.hidden;
        });

        if (snapshot.hint && snapshot.hint.node && snapshot.hint.node.isConnected) {
            snapshot.hint.node.innerHTML = snapshot.hint.html;
        }
    }

    function injectFallbackDialogStyles() {
        if (document.getElementById("pmk031-fallback-dialog-style")) return;

        const style = document.createElement("style");
        style.id = "pmk031-fallback-dialog-style";
        style.textContent = `
            .pmk031-dialog-backdrop {
                position: fixed;
                inset: 0;
                z-index: 1095;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 1rem;
                background: rgba(0,0,0,.48);
            }
            .pmk031-dialog {
                width: min(520px, 96vw);
                max-height: 90vh;
                overflow: auto;
                background: var(--bs-body-bg, #fff);
                color: var(--bs-body-color, #212529);
                border: 1px solid rgba(0,0,0,.2);
                border-radius: .6rem;
                box-shadow: 0 1rem 3rem rgba(0,0,0,.28);
            }
            .pmk031-dialog-head,
            .pmk031-dialog-body,
            .pmk031-dialog-actions {
                padding: .9rem 1rem;
            }
            .pmk031-dialog-head {
                border-bottom: 1px solid #dee2e6;
            }
            .pmk031-dialog-head h3 {
                margin: 0;
                font-size: 1.08rem;
            }
            .pmk031-dialog-body {
                white-space: pre-line;
                line-height: 1.5;
            }
            .pmk031-dialog-actions {
                display: flex;
                justify-content: flex-end;
                gap: .5rem;
                border-top: 1px solid #dee2e6;
            }
            @media (max-width: 576px) {
                .pmk031-dialog-actions {
                    flex-direction: column-reverse;
                }
                .pmk031-dialog-actions .btn {
                    width: 100%;
                }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function fallbackConfirmAction(options) {
        return new Promise(function (resolve) {
            injectFallbackDialogStyles();

            const opts = options || {};
            const previousFocus = document.activeElement;

            const backdrop = document.createElement("div");
            backdrop.className = "pmk031-dialog-backdrop";

            const dialog = document.createElement("div");
            dialog.className = "pmk031-dialog";
            dialog.setAttribute("role", "alertdialog");
            dialog.setAttribute("aria-modal", "true");

            const head = document.createElement("div");
            head.className = "pmk031-dialog-head";
            const title = document.createElement("h3");
            title.textContent = opts.title || "";
            head.appendChild(title);

            const body = document.createElement("div");
            body.className = "pmk031-dialog-body";
            body.textContent = opts.message || "";

            const actions = document.createElement("div");
            actions.className = "pmk031-dialog-actions";

            const cancel = document.createElement("button");
            cancel.type = "button";
            cancel.className = "btn btn-default";
            cancel.textContent = opts.cancelLabel || "Cancel";

            const confirmButton = document.createElement("button");
            confirmButton.type = "button";
            confirmButton.className = "btn btn-danger";
            confirmButton.textContent = opts.confirmLabel || "Confirm";

            actions.appendChild(cancel);
            actions.appendChild(confirmButton);
            dialog.appendChild(head);
            dialog.appendChild(body);
            dialog.appendChild(actions);
            backdrop.appendChild(dialog);
            document.body.appendChild(backdrop);

            let done = false;
            function finish(result) {
                if (done) return;
                done = true;
                document.removeEventListener("keydown", onKeyDown, true);
                backdrop.remove();
                if (previousFocus && typeof previousFocus.focus === "function") {
                    try { previousFocus.focus(); } catch (_) {}
                }
                resolve(Boolean(result));
            }

            function onKeyDown(event) {
                if (event.key === "Escape") {
                    event.preventDefault();
                    finish(false);
                }
            }

            cancel.addEventListener("click", function () { finish(false); });
            confirmButton.addEventListener("click", function () { finish(true); });
            backdrop.addEventListener("click", function (event) {
                if (event.target === backdrop) finish(false);
            });
            document.addEventListener("keydown", onKeyDown, true);

            window.setTimeout(function () {
                try { cancel.focus(); } catch (_) {}
            }, 0);
        });
    }

    function askConfirmation(copy) {
        if (window.PMKConfig && typeof window.PMKConfig.confirmAction === "function") {
            try {
                return Promise.resolve(window.PMKConfig.confirmAction({
                    title: copy.title,
                    message: copy.message,
                    confirmLabel: copy.confirmLabel,
                    cancelLabel: copy.cancelLabel,
                    danger: true
                })).then(Boolean).catch(function () { return false; });
            } catch (_) {}
        }
        return fallbackConfirmAction(copy);
    }

    function handleClickCapture(event) {
        if (!isEnabledOnCurrentPage(currentConfig)) return;

        const target = event.target;
        const checkbox = target && target.matches && target.matches('input[name="disable_input"]')
            ? target
            : null;
        if (!checkbox) return;

        if (bypassOnce.has(checkbox)) {
            bypassOnce.delete(checkbox);
            return;
        }

        /*
         * Sur les checkboxes, le navigateur expose déjà l'état proposé au moment
         * de l'événement click. checked=true signifie ici : tentative d'activer
         * la suppression. checked=false correspond au décochage et doit rester
         * entièrement géré par Koha, sans confirmation supplémentaire.
         */
        if (!checkbox.checked) return;
        if (!shouldProtect(checkbox)) return;

        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") {
            event.stopImmediatePropagation();
        }

        if (pending.has(checkbox)) return;

        const snapshot = snapshotNativeState(checkbox);
        pending.add(checkbox);

        window.setTimeout(function () {
            checkbox.checked = false;

            const copy = buildDialogCopy(checkbox);
            askConfirmation(copy).then(function (confirmed) {
                pending.delete(checkbox);

                if (!checkbox.isConnected) return;

                if (!confirmed) {
                    restoreNativeState(checkbox, snapshot);
                    return;
                }

                /*
                 * Rejoue exactement le clic natif Koha une seule fois.
                 * Le flag bypass empêche PMK de redemander confirmation sur ce clic.
                 */
                bypassOnce.add(checkbox);
                checkbox.click();
            }).catch(function () {
                pending.delete(checkbox);
                if (checkbox.isConnected) restoreNativeState(checkbox, snapshot);
            });
        }, 0);
    }

    function installGuard() {
        if (guardInstalled) return;
        window.addEventListener("click", handleClickCapture, true);
        guardInstalled = true;
    }

    function removeGuard() {
        if (!guardInstalled) return;
        window.removeEventListener("click", handleClickCapture, true);
        guardInstalled = false;
    }

    function mountContextAccess() {
        if (contextButtonMounted) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;

        const anchor =
            document.querySelector("#cataloguing_additem_newitem h2") ||
            document.querySelector("main h1, .main h1, h1");

        if (!anchor) return;

        try {
            const page = getCurrentPageConfig(currentConfig);
            const button = window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "batch-field-clear-warning",
                context: {
                    page: page ? page.id : "",
                    sectionId: "fields"
                }
            });
            if (button) contextButtonMounted = true;
        } catch (_) {}
    }

    function applyConfig(config) {
        currentConfig = deepMerge(DEFAULT_CONFIG, config || {});

        if (!isSupportedPath()) {
            removeGuard();
            return;
        }

        if (isEnabledOnCurrentPage(currentConfig)) {
            installGuard();
            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", mountContextAccess, { once: true });
            } else {
                mountContextAccess();
            }
        } else {
            removeGuard();
        }
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return Promise.resolve(clone(DEFAULT_CONFIG));
        }

        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (config) {
                return deepMerge(DEFAULT_CONFIG, config || {});
            })
            .catch(function () {
                return clone(DEFAULT_CONFIG);
            });
    }

    function start() {
        if (!isSupportedPath()) return;

        loadConfig().then(applyConfig);

        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try {
                window.PMKConfig.subscribe(MODULE_ID, applyConfig);
            } catch (_) {}
        }
    }

    window.PMK031FieldClearWarning = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        getFieldInfo: getFieldInfo
    };

    start();
})();

;window.PMKNonPlugin.loaded.push("031-alert-vide-champ-modif-lot.js");
} catch (error) { window.PMKNonPlugin.errors.push("031-alert-vide-champ-modif-lot.js: "+error.message); console.error("[PMK] 031-alert-vide-champ-modif-lot.js",error); };
try {
/*
 Nom du fichier: 033-mod-table-exemplaires.js
 Module PMK: holdings-table-presentation
 Version: 4.0.0-preplugin
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha

 Rôle:
 - remplace le legacy 033 sur catalogue/detail.pl et course_reserves/course-details.pl ;
 - absorbe la partie utile du legacy 032 pour l'affichage de la localisation ;
 - conserve les couleurs/comportements historiques d’origine comme valeurs par défaut ;
 - s'appuie en priorité sur les statuts structurés Koha (_status / classes item-status) ;
 - résiste aux redraw/reconstructions DataTables ;
 - ne masque PAS #catalogue_detail_elastic_record : cette fonction appartient au module
   transversal "conditional-visibility" ;
 - ne lance aucune action métier et ne modifie aucune donnée Koha.
*/

(function () {
  'use strict';

  if (window.__PMK033_HOLDINGS_TABLE_PRESENTATION__) return;
  window.__PMK033_HOLDINGS_TABLE_PRESENTATION__ = true;

  const MODULE_ID = 'holdings-table-presentation';
  const MODULE_VERSION = '4.2.0-preplugin';

  const PAGE_DETAIL = '/cgi-bin/koha/catalogue/detail.pl';
  const PAGE_COURSE = '/cgi-bin/koha/course_reserves/course-details.pl';

  const DETAIL_TABLES = ['#holdings_table', '#otherholdings_table'];
  const COURSE_TABLE = '#course_reserves_table';

  const DETAIL_STATUS_TARGETS = {
    checked_out: '.datedue',
    local_use: '',
    in_transit: '.intransit, .transitrequested',
    lost: '.lost',
    withdrawn: '.wdn',
    damaged: '.dmg',
    not_for_loan: '.notforloan',
    on_hold: '.waitingat, .holdonitem, .heldfor',
    recalled: '.recallwaiting, .recalledby',
    restricted: '.restricted',
    in_bundle: '.bundled',
    available: ''
  };

  const COURSE_STATUS_TARGETS = {
    available: '.item-status.available',
    checked_out: '.item-status.checkedout',
    local_use: '.item-status.checkedout',
    in_transit: '.item-status.intransit',
    lost: '.item-status.lost',
    withdrawn: '.item-status.withdrawn',
    damaged: '.item-status.damaged',
    not_for_loan: '.item-status.notforloan',
    on_hold: '.item-status.pendinghold, .item-status.holdwaiting, .item-status.itemhold, .item-status.holdfor',
    restricted: '.item-status.restricted'
  };

  const STRUCTURE_DEFAULTS = {"detail": {"tableSelector": "#holdings_table, #otherholdings_table", "rowSelector": "tbody tr", "statusCellSelector": "td.status", "locationCellSelector": "td.location", "locationSelector": ".shelvingloc"}, "course": {"tableSelector": "#course_reserves_table", "rowSelector": "tbody tr", "statusCellSelector": "td.status", "availableSelector": ".item-status.available"}, "library": {"codeSelector": ".logged-in-branch-code, #logged-in-branch-code, [data-branchcode], [data-branch-code]", "nameSelector": ".logged-in-branch-name, #logged-in-branch-name, [data-branch-name]", "codeAttribute": "data-branchcode, data-branch-code", "nameAttribute": "data-branch-name"}, "dataFields": {"statuses": "_status", "holdingLibrary": "holding_library_id", "holdingName": "_strings.holding_library_id.str", "location": "_strings.location.str", "rawLocation": "location"}};
  const DEFAULT_CONFIG = {
    enabled: true,
    pages: [
      { pageId: 'catalogue.detail', enabled: true, path: PAGE_DETAIL },
      { pageId: 'course_reserves.course-details', enabled: true, path: PAGE_COURSE }
    ],
    detail: {
      locationMode: 'current-only',
      columnLabels: [
        { id: 'copynumber', enabled: true, colname: 'copynumber', labelFr: 'Sous-localisation', labelEn: 'Sub-location' },
        { id: 'barcode', enabled: true, colname: 'barcode', labelFr: 'Code barres', labelEn: 'Barcode' },
        { id: 'enumchron', enabled: true, colname: 'enumchron', labelFr: 'Etage / Numéro', labelEn: 'Floor / Number' },
        { id: 'course_reserves', enabled: true, colname: 'course_reserves', labelFr: "Listes d'exemplaires", labelEn: 'Item lists' }
      ],
      statusRules: [
        { id: 'transfer', enabled: true, statusKey: 'in_transit', rowBackground: '#f7f1e9', textColor: '', bold: false },
        { id: 'hold', enabled: true, statusKey: 'on_hold', rowBackground: '#f7f1e9', textColor: '', bold: false },
        { id: 'available', enabled: true, statusKey: 'available', rowBackground: '#ebfaeb', textColor: '#008000', bold: true },
        { id: 'not-for-loan', enabled: true, statusKey: 'not_for_loan', rowBackground: '#fcd2d2', textColor: '#990000', bold: true },
        { id: 'checked-out', enabled: true, statusKey: 'checked_out', rowBackground: '#fff3cd', textColor: '', bold: false },
        { id: 'local-use', enabled: true, statusKey: 'local_use', rowBackground: '#fff3cd', textColor: '', bold: false },
        { id: 'lost', enabled: false, statusKey: 'lost', rowBackground: '', textColor: '', bold: false },
        { id: 'withdrawn', enabled: false, statusKey: 'withdrawn', rowBackground: '', textColor: '', bold: false },
        { id: 'damaged', enabled: false, statusKey: 'damaged', rowBackground: '', textColor: '', bold: false },
        { id: 'restricted', enabled: false, statusKey: 'restricted', rowBackground: '', textColor: '', bold: false },
        { id: 'recalled', enabled: false, statusKey: 'recalled', rowBackground: '', textColor: '', bold: false },
        { id: 'in-bundle', enabled: false, statusKey: 'in_bundle', rowBackground: '', textColor: '', bold: false }
      ],
      currentLibrary: {
        enabled: true,
        availableOnly: true,
        iconClass: 'fa fa-star',
        color: '#b8860b',
        titleFr: 'Disponible dans le site de connexion',
        titleEn: 'Available at the current library'
      }
    },
    course: {
      statusRules: [
        { id: 'available', enabled: true, statusKey: 'available', textColor: '#008000', bold: true },
        { id: 'checked-out', enabled: true, statusKey: 'checked_out', textColor: '#990000', bold: true }
      ],
      availableLabelFr: 'Non emprunté',
      availableLabelEn: 'Not checked out'
    },
    observerDelay: 70
  };

  let currentConfig = deepMerge(STRUCTURE_DEFAULTS,DEFAULT_CONFIG);
  let mutationObserver = null;
  let applyTimer = null;
  let jqueryEventsBound = false;

  function deepClone(value) {
    if (value === undefined) return undefined;
    return JSON.parse(JSON.stringify(value));
  }

  function isPlainObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value);
  }

  function deepMerge(base, override) {
    if (Array.isArray(base)) {
      return Array.isArray(override) ? deepClone(override) : deepClone(base);
    }
    if (!isPlainObject(base)) {
      return override === undefined ? deepClone(base) : deepClone(override);
    }
    const out = deepClone(base) || {};
    if (!isPlainObject(override)) return out;
    Object.keys(override).forEach(function (key) {
      if (Array.isArray(override[key])) out[key] = deepClone(override[key]);
      else if (isPlainObject(override[key]) && isPlainObject(out[key])) out[key] = deepMerge(out[key], override[key]);
      else out[key] = deepClone(override[key]);
    });
    return out;
  }

  function normalizedPath(path) { const value=String(path || '').trim();return value.startsWith('/cgi-bin/koha/')?value:'/cgi-bin/koha/'+value.replace(/^\/+/, ''); }
  function pageMode() { const page=(currentConfig.pages || []).find(entry=>normalizedPath(entry.path)===location.pathname);return page?.pageId==='course_reserves.course-details'?'course':page?'detail':null; }
  function tables(mode) { const result=[];try{result.push(...document.querySelectorAll(currentConfig[mode]?.tableSelector || STRUCTURE_DEFAULTS[mode].tableSelector))}catch(_){}return result; }
  function rows(table,mode) { try{return Array.from(table.querySelectorAll(currentConfig[mode]?.rowSelector || 'tbody tr'))}catch(_){return []} }
  function dataValue(value,path) { return String(path || '').split('.').reduce((node,key)=>node?.[key],value); }
  function configuredData(data,key) {return dataValue(data,currentConfig.dataFields?.[key] || STRUCTURE_DEFAULTS.dataFields[key]);}
  const originalTextNodes=new Map(),originalLocationNodes=new Map();
  function setLabel(element,label) {
    if(!element)return;
    let textNode=Array.from(element.childNodes).find(node=>node.nodeType===Node.TEXT_NODE && node.textContent.trim());
    if(!textNode){const inner=element.querySelector('.dt-column-title, .label');if(inner){setLabel(inner,label);return;}const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);textNode=walker.nextNode();}
    if(!textNode){textNode=document.createTextNode('');element.appendChild(textNode);}
    if(window.PMKWorkbench?.labels){
      const release=window.PMKWorkbench.labels.claim(textNode,label,{owner:MODULE_ID,priority:50,title:"Présentation du tableau des exemplaires"});
      if(release){originalTextNodes.set(textNode,release);return;}
    }
    if(!originalTextNodes.has(textNode))originalTextNodes.set(textNode,textNode.textContent);
    textNode.textContent=label;
  }
  function restoreLabels(root) { for(const [node,value]of originalTextNodes)if(!node.isConnected || !root || root.contains(node)){if(typeof value==='function')value();else node.textContent=value;originalTextNodes.delete(node)} }
  function matchesRule(statuses,statusCell,rule) {
    if(rule.enabled===false)return false;
    let matched=statuses.includes(String(rule.statusKey || ''));
    const target=rule.selector?safeQuery(statusCell,rule.selector):statusCell;
    if(rule.selector)matched=!!target;
    if(rule.matchText){try{matched=!!target && new RegExp(rule.matchText,'i').test(target.textContent || '')}catch(_){return false}}
    return matched;
  }

  function normalizeText(value) {
    return String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeComparable(value) {
    return normalizeText(value)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
  }

  function language() {
    const htmlLang = String(document.documentElement.getAttribute('lang') || '').toLowerCase();
    if (htmlLang.startsWith('fr')) return 'fr';
    if (htmlLang.startsWith('en')) return 'en';
    return String(navigator.language || '').toLowerCase().startsWith('fr') ? 'fr' : 'en';
  }

  function pageConfig(pageId) {
    const pages = Array.isArray(currentConfig.pages) ? currentConfig.pages : [];
    return pages.find(function (page) { return page && page.pageId === pageId; }) || null;
  }

  function pageEnabled(pageId) {
    const page = pageConfig(pageId);
    return currentConfig.enabled !== false && (!page || page.enabled !== false);
  }

  function safeQuery(root, selector) {
    if (!root || !selector) return null;
    try { return root.querySelector(selector); } catch (_) { return null; }
  }

  function getDataTableRowData(table, row) {
    try {
      if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.dataTable) return null;
      if (!window.jQuery.fn.dataTable.isDataTable(table)) return null;
      return window.jQuery(table).DataTable().row(row).data() || null;
    } catch (_) {
      return null;
    }
  }

  function getStatusCell(row) {
    return safeQuery(row, currentConfig[pageMode() || 'detail']?.statusCellSelector || 'td.status');
  }

  function inferDetailStatuses(statusCell) {
    const out = [];
    if (!statusCell) return out;

    const tests = [
      ['checked_out', '.datedue'],
      ['in_transit', '.intransit, .transitrequested'],
      ['lost', '.lost'],
      ['withdrawn', '.wdn'],
      ['damaged', '.dmg'],
      ['not_for_loan', '.notforloan'],
      ['on_hold', '.waitingat, .holdonitem, .heldfor'],
      ['recalled', '.recallwaiting, .recalledby'],
      ['restricted', '.restricted'],
      ['in_bundle', '.bundled']
    ];

    tests.forEach(function (entry) {
      if (safeQuery(statusCell, entry[1])) out.push(entry[0]);
    });

    if (!out.length) {
      const text = normalizeComparable(statusCell.textContent);
      if (/\b(disponible|available)\b/.test(text)) out.push('available');
      else if (/\b(prete|checked out|currently in local use|local use)\b/.test(text)) out.push('checked_out');
    }

    return out;
  }

  function detailStatuses(table, row, statusCell) {
    const data = getDataTableRowData(table, row);
    const statuses=data && Array.isArray(configuredData(data,'statuses'))?configuredData(data,'statuses').map(String):inferDetailStatuses(statusCell);
    (currentConfig.detail.statusRules || []).forEach(rule=>{if((rule.selector||rule.matchText)&&matchesRule([],statusCell,rule))statuses.push(String(rule.statusKey || ''));});
    return Array.from(new Set(statuses));
  }

  function courseStatuses(statusCell) {
    const out = [];
    if (!statusCell) return out;
    Object.keys(COURSE_STATUS_TARGETS).forEach(function (key) {
      const selector = COURSE_STATUS_TARGETS[key];
      if (selector && safeQuery(statusCell, selector)) out.push(key);
    });
    if(safeQuery(statusCell,currentConfig.course.availableSelector))out.push('available');
    (currentConfig.course.statusRules || []).forEach(rule=>{if((rule.selector||rule.matchText)&&matchesRule([],statusCell,rule))out.push(String(rule.statusKey || ''));});
    return Array.from(new Set(out));
  }

  function cleanupLegacy033Row(row) {
    if (!row) return;

    row.classList.remove('vc-disponible', 'vc-prete', 'vc-exclu', 'vc-prete-pret');
    row.removeAttribute('data-vc-row-colored');

    row.querySelectorAll('img.vc-star, img[src$="starred.png"]').forEach(function (el) { el.remove(); });

    const statusCell = getStatusCell(row);
    if (!statusCell) return;

    statusCell.querySelectorAll('span[style]').forEach(function (span) {
      const style = String(span.getAttribute('style') || '').replace(/\s+/g, '').toLowerCase();
      const isLegacy033 =
        !normalizeText(span.className) &&
        style.indexOf('font-weight:bold') !== -1 &&
        (style.indexOf('color:green') !== -1 || style.indexOf('color:#900') !== -1 || style.indexOf('color:#990000') !== -1);

      if (isLegacy033) {
        span.replaceWith(document.createTextNode(span.textContent || ''));
      }
    });
  }

  function clearRowPresentation(row) {
    if (!row) return;
    cleanupLegacy033Row(row);
    row.classList.remove('pmk033-row-state');
    row.style.removeProperty('--pmk033-row-background');

    row.querySelectorAll('[data-pmk033-status-styled="1"]').forEach(function (el) {
      el.removeAttribute('data-pmk033-status-styled');
      el.style.removeProperty('--pmk033-status-color');
      el.style.removeProperty('--pmk033-status-weight');
    });

    row.querySelectorAll('.pmk033-current-library-icon').forEach(function (el) { el.remove(); });
  }

  function statusTarget(statusCell, statusKey, courseMode) {
    const map = courseMode ? COURSE_STATUS_TARGETS : DETAIL_STATUS_TARGETS;
    const selector = map[statusKey];
    if (selector) return safeQuery(statusCell, selector);

    // Sur detail.pl, Koha rend "available" dans un span sans classe.
    if (!courseMode && statusKey === 'available') {
      const directSpan = Array.from(statusCell.children || []).find(function (child) {
        return child.tagName === 'SPAN' && !normalizeText(child.className);
      });
      if (directSpan) return directSpan;
    }

    return statusCell;
  }

  function applyStatusTextStyle(statusCell, rule, courseMode) {
    if (!statusCell || !rule) return;
    const target = rule.selector?safeQuery(statusCell,rule.selector):statusTarget(statusCell, rule.statusKey, courseMode);
    if (!target) return;

    const color = normalizeText(rule.textColor);
    const weight = rule.bold ? '700' : '';
    if (!color && !weight) return;

    target.setAttribute('data-pmk033-status-styled', '1');
    if (color) target.style.setProperty('--pmk033-status-color', color);
    if (weight) target.style.setProperty('--pmk033-status-weight', weight);
  }

  function applyRowRule(row, rule) {
    if (!row || !rule || rule.enabled === false) return;
    const background = normalizeText(rule.rowBackground);
    if (!background) return;
    row.classList.add('pmk033-row-state');
    row.style.setProperty('--pmk033-row-background', background);
  }

  function getLoggedInBranchName() {
    const cfg=currentConfig.library || STRUCTURE_DEFAULTS.library;
    let elements=[];try{elements=Array.from(document.querySelectorAll(cfg.nameSelector || STRUCTURE_DEFAULTS.library.nameSelector))}catch(_){}
    for(const element of elements){
      for(const attr of String(cfg.nameAttribute || '').split(',').map(value=>value.trim()).filter(Boolean)){const value=normalizeText(element.getAttribute(attr));if(value)return value;}
      const value=normalizeText(element.textContent);if(value)return value;
    }
    return '';
  }

  function getLoggedInBranchCode() {
    const cfg=currentConfig.library || STRUCTURE_DEFAULTS.library;
    let elements=[];try{elements=Array.from(document.querySelectorAll(cfg.codeSelector || STRUCTURE_DEFAULTS.library.codeSelector))}catch(_){}
    for(const element of elements){
      for(const attr of String(cfg.codeAttribute || '').split(',').map(value=>value.trim()).filter(Boolean)){const value=normalizeText(element.getAttribute(attr));if(value)return value;}
      const value=normalizeText(element.textContent);if(value)return value;
    }
    return '';
  }

  function rowIsCurrentLibrary(table, row, data) {
    const branchCode = getLoggedInBranchCode();
    if (branchCode && data && configuredData(data,'holdingLibrary')) {
      if (normalizeComparable(branchCode) === normalizeComparable(configuredData(data,'holdingLibrary'))) return true;
    }

    const branchName = getLoggedInBranchName();
    if (!branchName) return false;

    const locationCell = safeQuery(row,currentConfig.detail.locationCellSelector || 'td.location');
    const holdingName = normalizeText(
      data && configuredData(data,'holdingName')
        ? configuredData(data,'holdingName')
        : (locationCell ? locationCell.textContent : '')
    );

    return holdingName && normalizeComparable(holdingName) === normalizeComparable(branchName);
  }

  function mountCurrentLibraryIndicator(table, row, statuses, statusCell) {
    const cfg = currentConfig.detail && currentConfig.detail.currentLibrary || {};
    if (cfg.enabled === false || !statusCell) return;
    if (cfg.availableOnly !== false && !statuses.includes('available')) return;

    const data = getDataTableRowData(table, row);
    if (!rowIsCurrentLibrary(table, row, data)) return;
    if (statusCell.querySelector('.pmk033-current-library-icon')) return;

    const icon = document.createElement('i');
    icon.className = normalizeText(cfg.iconClass) || 'fa fa-star';
    icon.classList.add('pmk033-current-library-icon');
    icon.setAttribute('aria-hidden', 'true');
    icon.style.setProperty('--pmk033-current-library-color', normalizeText(cfg.color) || '#b8860b');
    icon.title = language() === 'fr'
      ? (normalizeText(cfg.titleFr) || 'Disponible dans le site de connexion')
      : (normalizeText(cfg.titleEn) || 'Available at the current library');

    statusCell.insertBefore(icon, statusCell.firstChild);
  }

  function applyDetailRow(table, row) {
    if (!row || !row.cells || !row.cells.length) return;
    clearRowPresentation(row);

    const statusCell = getStatusCell(row);
    if (!statusCell) return;

    const statuses = detailStatuses(table, row, statusCell);
    const rules = currentConfig.detail && Array.isArray(currentConfig.detail.statusRules)
      ? currentConfig.detail.statusRules
      : [];

    let rowRuleApplied = false;
    rules.forEach(function (rule) {
      if (!rule || rule.enabled === false || !matchesRule(statuses,statusCell,rule)) return;
      applyStatusTextStyle(statusCell, rule, false);
      if (!rowRuleApplied && normalizeText(rule.rowBackground)) {
        applyRowRule(row, rule);
        rowRuleApplied = true;
      }
    });

    mountCurrentLibraryIndicator(table, row, statuses, statusCell);
  }

  function restoreLocationElement(el) {
    if(!el)return;
    const original=originalLocationNodes.get(el);if(original){el.replaceChildren(...original);originalLocationNodes.delete(el);}
    el.removeAttribute('data-pmk033-location-current');
  }

  function currentLocationText(el, table, row) {
    const data = getDataTableRowData(table, row);
    if (data) {
      const fromStrings = configuredData(data,'location');
      const raw = fromStrings || configuredData(data,'rawLocation');
      if (normalizeText(raw)) return normalizeText(raw);
    }

    const original = normalizeText(el.dataset.pmk033NativeText || el.textContent);
    const match = original.match(/\(([^()]*)\)\s*$/);
    if (match && normalizeText(match[1])) return normalizeText(match[1]);
    return original;
  }

  function applyLocations(table) {
    const mode = currentConfig.detail && currentConfig.detail.locationMode || 'native';
    rows(table,'detail').forEach(function (row) {
      const el = safeQuery(row, currentConfig.detail.locationSelector || '.shelvingloc');
      if (!el) return;

      if (el.dataset.pmk033NativeText === undefined) {
        el.dataset.pmk033NativeText = normalizeText(el.textContent);
      }

      if (mode === 'current-only') {
        const value = currentLocationText(el, table, row);
        if(value){if(!originalLocationNodes.has(el))originalLocationNodes.set(el,Array.from(el.childNodes));if(el.textContent!==value || el.children.length)el.replaceChildren(document.createTextNode(value));}
        el.setAttribute('data-pmk033-location-current', '1');
      } else {
        restoreLocationElement(el);
      }
    });
  }

  function findHeader(table, colname) {
    const escaped = String(colname || '').replace(/"/g, '\\"');
    return safeQuery(table, 'thead th[data-colname="' + escaped + '"]') ||
      safeQuery(table, 'thead th#holdings_' + colname) ||
      safeQuery(table, 'thead th#otherholdings_' + colname);
  }

  function applyColumnLabels(table) {
    const rules = currentConfig.detail && Array.isArray(currentConfig.detail.columnLabels)
      ? currentConfig.detail.columnLabels
      : [];
    const lang = language();

    rules.forEach(function (rule) {
      if (!rule || (!normalizeText(rule.colname) && !rule.headerSelector)) return;
      const th = rule.headerSelector?safeQuery(table,rule.headerSelector):findHeader(table, rule.colname);
      if (!th) return;

      if (th.dataset.pmk033NativeLabel === undefined) {
        th.dataset.pmk033NativeLabel = normalizeText(th.textContent);
      }

      if (rule.enabled === false) {
        restoreLabels(th);
        return;
      }

      const label = lang === 'fr' ? normalizeText(rule.labelFr) : normalizeText(rule.labelEn);
      if(label)setLabel(th,label);else restoreLabels(th);
    });
  }

  function restoreColumnLabels(table) { restoreLabels(table); }

  function applyDetailTable(table) {
    if (!table) return;
    applyColumnLabels(table);
    applyLocations(table);
    rows(table,'detail').forEach(function (row) { applyDetailRow(table, row); });
  }

  function restoreCourseLabel(span) { restoreLabels(span); }

  function applyCourseAvailableLabel(statusCell) {
    const span = safeQuery(statusCell, currentConfig.course.availableSelector || '.item-status.available');
    if (!span) return;

    if (span.dataset.pmk033OriginalText === undefined) {
      span.dataset.pmk033OriginalText = normalizeText(span.textContent);
    }

    const label = language() === 'fr'
      ? normalizeText(currentConfig.course && currentConfig.course.availableLabelFr)
      : normalizeText(currentConfig.course && currentConfig.course.availableLabelEn);

    if(label)setLabel(span,label);else restoreCourseLabel(span);
  }

  function applyCourseRow(row) {
    if (!row) return;
    clearRowPresentation(row);
    const statusCell = getStatusCell(row);
    if (!statusCell) return;

    const available = safeQuery(statusCell, currentConfig.course.availableSelector || '.item-status.available');
    if (available) restoreCourseLabel(available);

    const statuses = courseStatuses(statusCell);
    const rules = currentConfig.course && Array.isArray(currentConfig.course.statusRules)
      ? currentConfig.course.statusRules
      : [];

    rules.forEach(function (rule) {
      if (!rule || rule.enabled === false || !matchesRule(statuses,statusCell,rule)) return;
      applyStatusTextStyle(statusCell, rule, true);
    });

    if (statuses.includes('available')) applyCourseAvailableLabel(statusCell);
  }

  function restoreDetailPage() {
    tables('detail').forEach(table=>{restoreColumnLabels(table);rows(table,'detail').forEach(clearRowPresentation)});
    for(const element of Array.from(originalLocationNodes.keys()))restoreLocationElement(element);
  }
  function restoreCoursePage() { tables('course').forEach(table=>{restoreLabels(table);rows(table,'course').forEach(clearRowPresentation)}); }
  function applyCurrentPage() {
    const mode=pageMode();if(!mode)return;
    const id=mode==='course'?'course_reserves.course-details':'catalogue.detail';
    if(!pageEnabled(id)){if(mode==='course')restoreCoursePage();else restoreDetailPage();return;}
    if(mode==='detail')tables(mode).forEach(applyDetailTable);
    else tables(mode).forEach(table=>rows(table,mode).forEach(applyCourseRow));
    mountContextAccess(id);
  }

  function scheduleApply() {
    clearTimeout(applyTimer);
    const delay = Math.max(0, Number(currentConfig.observerDelay || 70));
    applyTimer = window.setTimeout(applyCurrentPage, delay);
  }

  function installStyles() {
    const legacyStyle = document.getElementById('vc-holdings-row-styles');
    if (legacyStyle) legacyStyle.remove();
    if (document.getElementById('pmk033-holdings-presentation-style')) return;
    const style = document.createElement('style');
    style.id = 'pmk033-holdings-presentation-style';
    style.textContent = `
      tr.pmk033-row-state > td, tr.pmk033-row-state > th {
        background-color: var(--pmk033-row-background) !important;
      }

      [data-pmk033-status-styled="1"] {
        color: var(--pmk033-status-color, inherit) !important;
        font-weight: var(--pmk033-status-weight, inherit) !important;
      }

      .pmk033-current-library-icon {
        color: var(--pmk033-current-library-color, #b8860b);
        margin-right: 5px;
        vertical-align: baseline;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function bindDataTableEvents() {
    if (jqueryEventsBound || !window.jQuery) return;
    jqueryEventsBound = true;
    try {
      window.jQuery(document).on(
        'draw.dt.pmk033 column-visibility.dt.pmk033 responsive-display.dt.pmk033',
        function(event){if(tables(pageMode() || 'detail').includes(event.target))scheduleApply();}
      );
    } catch (_) {}
  }

  function observeRelevantDom() {
    if (mutationObserver) return;
    mutationObserver = new MutationObserver(function (mutations) {
      for (const mutation of mutations) {
        if (mutation.type !== 'childList' || !mutation.addedNodes || !mutation.addedNodes.length) continue;

        const relevant = Array.from(mutation.addedNodes).some(function (node) {
          if (!node || node.nodeType !== 1) return false;
          if (node.classList && node.classList.contains('pmk033-current-library-icon')) return false;
          const mode=pageMode() || 'detail',selector=(currentConfig[mode].tableSelector || STRUCTURE_DEFAULTS[mode].tableSelector)+', tbody, tr';
          try{return !!(node.matches?.(selector) || node.querySelector?.(selector))}catch(_){return false;}
        });

        if (relevant) {
          scheduleApply();
          return;
        }
      }
    });
    mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  function mountContextAccess(pageId) {
    if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;

    const anchor=tables(pageMode() || 'detail')[0];

    if (!anchor) return;

    try {
      window.PMKConfig.mountContextButton({
        moduleId: MODULE_ID,
        anchor: anchor,
        position: 'after',
        contextKey: 'holdings-table-presentation-' + pageId,
        context: {
          page: pageId,
          sectionId: pageId === 'catalogue.detail' ? 'detail-statuses' : 'course-statuses'
        }
      });
    } catch (_) {}
  }

  function loadConfig() {
    if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') {
      return Promise.resolve(deepClone(DEFAULT_CONFIG));
    }
    return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
      .then(function (cfg) { return deepMerge(DEFAULT_CONFIG, cfg || {}); })
      .catch(function () { return deepClone(DEFAULT_CONFIG); });
  }

  function applyConfig(config) {
    restoreDetailPage();restoreCoursePage();
    currentConfig = deepMerge(deepMerge(STRUCTURE_DEFAULTS,DEFAULT_CONFIG), config || {});

    if (currentConfig.enabled === false) {
      restoreDetailPage();
      restoreCoursePage();
      return;
    }

    installStyles();
    bindDataTableEvents();
    observeRelevantDom();
    scheduleApply();
  }

  function registerVisualEditorAdapter() {
    const editor = window.PMKConfig && window.PMKConfig.visualEditor;
    if (!editor || typeof editor.register !== 'function') return false;
    editor.register(MODULE_ID, {
      capabilities: { livePreview: true },
      canPreview: function () {
        return !!pageMode();
      },
      previewDraft: function (draft) {
        if (!pageMode()) throw new Error('visual_preview_wrong_page');
        const before = deepClone(currentConfig || DEFAULT_CONFIG);
        applyConfig(draft);
        clearTimeout(applyTimer);
        applyCurrentPage();
        return function () { applyConfig(before); clearTimeout(applyTimer); applyCurrentPage(); };
      }
    });
    return true;
  }

  function start() {
    registerVisualEditorAdapter();
    loadConfig().then(applyConfig);

    if (window.PMKConfig && typeof window.PMKConfig.subscribe === 'function') {
      try { window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
    }
  }

  window.addEventListener('pmk:config-ready', registerVisualEditorAdapter, { once: true });

  window.PMK033HoldingsTablePresentation = {
    version: MODULE_VERSION,
    moduleId: MODULE_ID,
    refresh: scheduleApply,
    applyConfig: applyConfig,
    getConfig: function () { return deepClone(currentConfig); }
  };

  start();
})();

;window.PMKNonPlugin.loaded.push("033-mod-table-exemplaires.js");
} catch (error) { window.PMKNonPlugin.errors.push("033-mod-table-exemplaires.js: "+error.message); console.error("[PMK] 033-mod-table-exemplaires.js",error); };
try {
/*
 Nom du fichier: 034-modif-dates-technique-detail.js
 Ancien rôle: reformater les dates techniques de catalogue/detail.pl
 Module PMK: date-display-formatting
 Version: 2.0.0-preplugin
 Date de dernière modification: 2026-09-17
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha

 Rôle:
 - moteur transversal de formatage de dates visibles dans l'interface Koha ;
 - règles illimitées, activables page par page ;
 - cible choisie avec le picker visuel PMK ;
 - format de date de sortie configurable ;
 - prise en charge de la date seule ET de la date + heure ;
 - heure: seulement si présente, toujours, ou jamais ;
 - format horaire Koha / 24 h / 24 h avec secondes / 12 h / personnalisé ;
 - traitement idempotent: aucune dégradation lors des réapplications ;
 - ne remplace que la sous-chaîne de date, sans vider le HTML de l'élément ;
 - valeurs historiques « Création notice » et « Modification notice » conservées par défaut ;
 - aucun effet sur les données Koha: présentation uniquement.
*/
(function () {
    "use strict";

    if (window.__PMK034DateDisplayFormattingLoaded) return;
    window.__PMK034DateDisplayFormattingLoaded = true;

    const MODULE_ID = "date-display-formatting";
    const MODULE_VERSION = "2.0.0-preplugin";
    const WRAP_CLASS = "pmk034-date-value";
    const RULE_ATTR = "data-pmk034-rule";
    const SOURCE_ATTR = "data-pmk034-source";
    const PICKER_STYLE_ID = "pmk034-picker-style";
    const PENDING_PICK_KEY = "pmk034-pending-pick-v1";

    const DEFAULT_OUTPUT = {
        dateFormat: "koha",
        customDateFormat: "DD/MM/YYYY",
        timeMode: "auto",
        timeFormat: "koha",
        customTimeFormat: "HH:mm",
        separator: " "
    };

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 90,
        rules: [
            {
                id: "legacy-record-creation",
                enabled: true,
                label: "Création notice",
                pages: "/cgi-bin/koha/catalogue/detail.pl",
                selector: "li.date-creation-tech, li.date-modif-tech",
                targetName: "Création notice",
                textContains: "Création notice\nRecord creation\nCreation date\nCreated",
                occurrence: "all",
                output: {
                    dateFormat: "koha",
                    customDateFormat: "DD/MM/YYYY",
                    timeMode: "auto",
                    timeFormat: "koha",
                    customTimeFormat: "HH:mm",
                    separator: " "
                }
            },
            {
                id: "legacy-record-modification",
                enabled: true,
                label: "Modification notice",
                pages: "/cgi-bin/koha/catalogue/detail.pl",
                selector: "li.date-modif-tech, li.date-creation-tech",
                targetName: "Modification notice",
                textContains: "Modification notice\nRecord modification\nModification date\nModified",
                occurrence: "all",
                output: {
                    dateFormat: "koha",
                    customDateFormat: "DD/MM/YYYY",
                    timeMode: "auto",
                    timeFormat: "koha",
                    customTimeFormat: "HH:mm",
                    separator: " "
                }
            }
        ]
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;
    let applying = false;

    function deepClone(value) {
        if (value === undefined) return undefined;
        return JSON.parse(JSON.stringify(value));
    }

    function isPlainObject(value) {
        return !!value && typeof value === "object" && !Array.isArray(value);
    }

    function merge(target, source) {
        if (!isPlainObject(source)) return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) {
                target[key] = deepClone(value);
            } else if (isPlainObject(value)) {
                if (!isPlainObject(target[key])) target[key] = {};
                merge(target[key], value);
            } else {
                target[key] = value;
            }
        });
        return target;
    }

    function normalizeConfig(config) {
        const out = merge(deepClone(DEFAULTS), config || {});
        if (!Array.isArray(out.rules)) out.rules = deepClone(DEFAULTS.rules);
        out.rules = out.rules.map(function (rule, index) {
            return merge({
                id: "rule-" + (index + 1),
                enabled: true,
                label: "",
                pages: "*",
                selector: "",
                targetName: "",
                textContains: "",
                occurrence: "all",
                output: deepClone(DEFAULT_OUTPUT)
            }, rule || {});
        });
        return out;
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const htmlLang = String(document.documentElement && document.documentElement.lang || "").toLowerCase();
        if (htmlLang.indexOf("en") === 0) return "en";
        if (htmlLang.indexOf("fr") === 0) return "fr";
        return String(navigator.language || "fr").toLowerCase().indexOf("en") === 0 ? "en" : "fr";
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function splitLines(value) {
        if (Array.isArray(value)) return value.map(String).map(function (v) { return v.trim(); }).filter(Boolean);
        return String(value || "")
            .split(/[\n;,]+/)
            .map(function (v) { return v.trim(); })
            .filter(Boolean);
    }

    function normalizePath(value) {
        let path = String(value || "").trim();
        if (!path) return "";
        try {
            if (/^https?:\/\//i.test(path)) path = new URL(path).pathname;
        } catch (_) {}
        if (path.charAt(0) !== "/" && path !== "*" && path !== "all") path = "/cgi-bin/koha/" + path.replace(/^\/+/, "");
        return path.replace(/[?#].*$/, "");
    }

    function pageMatches(rule) {
        const pages = splitLines(rule && rule.pages);
        if (!pages.length) return true;
        return pages.some(function (page) {
            const wanted = normalizePath(page);
            return !wanted || wanted === "*" || wanted === "all" || window.location.pathname === wanted;
        });
    }

    function firstConcretePage(rule) {
        const pages = splitLines(rule && rule.pages);
        for (let i = 0; i < pages.length; i += 1) {
            const path = normalizePath(pages[i]);
            if (path && path !== "*" && path !== "all") return path;
        }
        return "";
    }

    function ruleTextMatches(element, rule) {
        const filters = splitLines(rule && rule.textContains);
        if (!filters.length) return true;
        const haystack = normalizeText(element && element.textContent);
        return filters.some(function (value) {
            const needle = normalizeText(value);
            return needle && haystack.indexOf(needle) !== -1;
        });
    }

    function pad2(value) {
        return String(Math.max(0, Number(value) || 0)).padStart(2, "0");
    }

    function daysInMonth(year, month) {
        return new Date(year, month, 0).getDate();
    }

    function validParts(year, month, day, hour, minute, second) {
        if (!Number.isInteger(year) || year < 1000 || year > 9999) return false;
        if (!Number.isInteger(month) || month < 1 || month > 12) return false;
        if (!Number.isInteger(day) || day < 1 || day > daysInMonth(year, month)) return false;
        if (!Number.isInteger(hour) || hour < 0 || hour > 23) return false;
        if (!Number.isInteger(minute) || minute < 0 || minute > 59) return false;
        if (!Number.isInteger(second) || second < 0 || second > 59) return false;
        return true;
    }

    function inferKohaDateOrder() {
        try {
            if (typeof window.$date === "function") {
                const probe = String(window.$date("2001-02-03", { no_tz_adjust: true }) || "").trim();
                if (/^03\D02\D2001/.test(probe)) return "dmy";
                if (/^02\D03\D2001/.test(probe)) return "mdy";
                if (/^2001\D02\D03/.test(probe)) return "ymd";
            }
        } catch (_) {}
        return detectLanguage() === "en" ? "mdy" : "dmy";
    }

    function parseNumericDate(a, b, year, separator) {
        const first = Number(a);
        const second = Number(b);
        const y = Number(year);
        let day;
        let month;

        if (first > 12 && second <= 12) {
            day = first;
            month = second;
        } else if (second > 12 && first <= 12) {
            month = first;
            day = second;
        } else {
            const order = separator === "." ? "dmy" : inferKohaDateOrder();
            if (order === "mdy") {
                month = first;
                day = second;
            } else {
                day = first;
                month = second;
            }
        }

        return { year: y, month: month, day: day };
    }

    function parseTime(hourText, minuteText, secondText, ampmText) {
        let hour = Number(hourText || 0);
        const minute = Number(minuteText || 0);
        const second = Number(secondText || 0);
        const ampm = String(ampmText || "").trim().toUpperCase();

        if (ampm === "AM" || ampm === "PM") {
            if (hour < 1 || hour > 12) return null;
            if (ampm === "AM" && hour === 12) hour = 0;
            if (ampm === "PM" && hour !== 12) hour += 12;
        }

        if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) return null;
        return { hour: hour, minute: minute, second: second };
    }

    function candidateRegex() {
        /*
         * 1. ISO / RFC3339 : 2026-09-17, 2026-09-17 14:35:20, 2026-09-17T14:35:20+02:00
         * 2. Numérique local : 17/09/2026, 09/17/2026, 17.09.2026, 17-09-2026 + heure facultative
         */
        return /\b(?:\d{4}[-\/]\d{1,2}[-\/]\d{1,2}(?:[T\s]+\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:\s*(?:Z|[+-]\d{2}:?\d{2}))?)?|\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{4}(?:[T\s]+\d{1,2}:\d{2}(?::\d{2})?(?:\s*(?:AM|PM))?)?)\b/gi;
    }

    function parseCandidate(source) {
        if(window.PMKDates){
            const raw=String(source||'').trim(),info=window.PMKDates.inspect(raw,{exact:true}),date=info.date;
            if(!date)return null;
            const time=raw.match(/[T\s]+(\d{1,2}:\d{2}(?::\d{2})?[^]*)$/);
            return {raw,year:date.getFullYear(),month:date.getMonth()+1,day:date.getDate(),hour:date.getHours(),minute:date.getMinutes(),second:date.getSeconds(),hasTime:!!time,hadSeconds:!!time&&/\d{1,2}:\d{2}:\d{2}/.test(time[1]),originalTime:time?time[1]:'',ambiguous:info.ambiguous};
        }
        const raw = String(source || "").trim();
        if (!raw) return null;

        let match = raw.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(?:\s*(Z|[+-]\d{2}:?\d{2}))?)?$/i);
        if (match) {
            const year = Number(match[1]);
            const month = Number(match[2]);
            const day = Number(match[3]);
            const hasTime = match[4] !== undefined;
            const time = parseTime(match[4], match[5], match[6], "");
            if (!time || !validParts(year, month, day, time.hour, time.minute, time.second)) return null;

            const timezone = String(match[7] || "");
            if (timezone) {
                try {
                    let iso = year + "-" + pad2(month) + "-" + pad2(day) + "T" + pad2(time.hour) + ":" + pad2(time.minute) + ":" + pad2(time.second);
                    iso += timezone === "Z" ? "Z" : timezone.replace(/([+-]\d{2})(\d{2})$/, "$1:$2");
                    const d = new Date(iso);
                    if (!Number.isNaN(d.getTime())) {
                        return {
                            raw: raw,
                            year: d.getFullYear(),
                            month: d.getMonth() + 1,
                            day: d.getDate(),
                            hour: d.getHours(),
                            minute: d.getMinutes(),
                            second: d.getSeconds(),
                            hasTime: hasTime,
                            hadSeconds: match[6] !== undefined,
                            originalTime: hasTime ? raw.substring(raw.search(/[T\s]+\d{1,2}:\d{2}/)).replace(/^[T\s]+/, "") : ""
                        };
                    }
                } catch (_) {}
            }

            return {
                raw: raw,
                year: year,
                month: month,
                day: day,
                hour: time.hour,
                minute: time.minute,
                second: time.second,
                hasTime: hasTime,
                hadSeconds: match[6] !== undefined,
                originalTime: hasTime ? raw.substring(raw.search(/[T\s]+\d{1,2}:\d{2}/)).replace(/^[T\s]+/, "") : ""
            };
        }

        match = raw.match(/^(\d{1,2})([\/.\-])(\d{1,2})\2(\d{4})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(AM|PM))?)?$/i);
        if (!match) return null;

        const date = parseNumericDate(match[1], match[3], match[4], match[2]);
        const hasTime = match[5] !== undefined;
        const time = parseTime(match[5], match[6], match[7], match[8]);
        if (!time || !validParts(date.year, date.month, date.day, time.hour, time.minute, time.second)) return null;

        return {
            raw: raw,
            year: date.year,
            month: date.month,
            day: date.day,
            hour: time.hour,
            minute: time.minute,
            second: time.second,
            hasTime: hasTime,
            hadSeconds: match[7] !== undefined,
            originalTime: hasTime ? [match[5] + ":" + match[6] + (match[7] !== undefined ? ":" + match[7] : ""), match[8] || ""].join(" ").trim() : ""
        };
    }

    function canonicalLocal(parsed) {
        return String(parsed.year).padStart(4, "0") + "-" + pad2(parsed.month) + "-" + pad2(parsed.day) +
            "T" + pad2(parsed.hour) + ":" + pad2(parsed.minute) + ":" + pad2(parsed.second);
    }

    function formatPattern(parsed, pattern) {
        const p = String(pattern || "");
        const canonical = canonicalLocal(parsed);
        if (window.dayjs && typeof window.dayjs === "function") {
            try {
                const d = window.dayjs(canonical);
                if (d && typeof d.isValid === "function" && d.isValid()) return d.format(p);
            } catch (_) {}
        }

        const hour12 = parsed.hour % 12 || 12;
        const replacements = {
            YYYY: String(parsed.year).padStart(4, "0"),
            MM: pad2(parsed.month),
            DD: pad2(parsed.day),
            HH: pad2(parsed.hour),
            mm: pad2(parsed.minute),
            ss: pad2(parsed.second),
            hh: pad2(hour12),
            A: parsed.hour >= 12 ? "PM" : "AM"
        };
        return p.replace(/YYYY|MM|DD|HH|mm|ss|hh|A/g, function (token) { return replacements[token]; });
    }

    function kohaDatePart(parsed) {
        const canonical = canonicalLocal(parsed);
        if (typeof window.$date === "function") {
            try {
                return String(window.$date(canonical, { withtime: false, no_tz_adjust: true }) || "").trim();
            } catch (_) {}
        }
        return detectLanguage() === "en"
            ? pad2(parsed.month) + "/" + pad2(parsed.day) + "/" + parsed.year
            : pad2(parsed.day) + "/" + pad2(parsed.month) + "/" + parsed.year;
    }

    function kohaTimePart(parsed) {
        const canonical = canonicalLocal(parsed);
        if (typeof window.$date === "function") {
            try {
                const full = String(window.$date(canonical, {
                    dateformat: "iso",
                    withtime: true,
                    no_tz_adjust: true
                }) || "").trim();
                if (full.length > 10) return full.substring(10).trim();
            } catch (_) {}
        }
        return pad2(parsed.hour) + ":" + pad2(parsed.minute);
    }

    function formatDatePart(parsed, output) {
        switch (output.dateFormat) {
            case "dmy-slash": return formatPattern(parsed, "DD/MM/YYYY");
            case "mdy-slash": return formatPattern(parsed, "MM/DD/YYYY");
            case "iso": return formatPattern(parsed, "YYYY-MM-DD");
            case "dmy-dot": return formatPattern(parsed, "DD.MM.YYYY");
            case "dmy-dash": return formatPattern(parsed, "DD-MM-YYYY");
            case "custom": return formatPattern(parsed, output.customDateFormat || "DD/MM/YYYY");
            case "koha":
            default: return kohaDatePart(parsed);
        }
    }

    function formatTimePart(parsed, output) {
        switch (output.timeFormat) {
            case "24h": return formatPattern(parsed, "HH:mm");
            case "24h-seconds": return formatPattern(parsed, "HH:mm:ss");
            case "12h": return formatPattern(parsed, "hh:mm A");
            case "source": return parsed.originalTime || formatPattern(parsed, parsed.hadSeconds ? "HH:mm:ss" : "HH:mm");
            case "custom": return formatPattern(parsed, output.customTimeFormat || "HH:mm");
            case "koha":
            default: return kohaTimePart(parsed);
        }
    }

    function formatParsed(parsed, outputConfig) {
        const output = merge(deepClone(DEFAULT_OUTPUT), outputConfig || {});
        const dateText = formatDatePart(parsed, output);
        const showTime = output.timeMode === "always" || (output.timeMode === "auto" && parsed.hasTime);
        if (!showTime) return dateText;
        const timeText = formatTimePart(parsed, output);
        if (!timeText) return dateText;
        return dateText + String(output.separator === undefined ? " " : output.separator) + timeText;
    }

    function restoreAll() {
        const spans = Array.from(document.querySelectorAll("." + WRAP_CLASS + "[" + SOURCE_ATTR + "]"));
        spans.forEach(function (span) {
            const source = span.getAttribute(SOURCE_ATTR);
            if (!span.parentNode) return;
            span.parentNode.replaceChild(document.createTextNode(source === null ? span.textContent : source), span);
        });
    }

    function updateWrappedSpan(span, rule) {
        const source = span.getAttribute(SOURCE_ATTR) || "";
        const parsed = parseCandidate(source);
        if (!parsed) return false;
        span.textContent = formatParsed(parsed, rule.output);
        if(parsed.ambiguous)span.title="Date interprétée jour/mois/année : format Koha non disponible.";else span.removeAttribute("title");
        return true;
    }

    function createFormattedSpan(source, rule) {
        const parsed = parseCandidate(source);
        if (!parsed) return null;
        const span = document.createElement("span");
        span.className = WRAP_CLASS;
        span.setAttribute(RULE_ATTR, String(rule.id || "rule"));
        span.setAttribute(SOURCE_ATTR, source);
        span.textContent = formatParsed(parsed, rule.output);
        if(parsed.ambiguous)span.title="Date interprétée jour/mois/année : format Koha non disponible.";else span.removeAttribute("title");
        return span;
    }

    function processTextNode(node, rule, remaining) {
        if (!node || node.nodeType !== 3 || !node.parentNode) return remaining;
        const parent = node.parentNode;
        if (parent.nodeType === 1 && parent.closest && parent.closest("." + WRAP_CLASS)) return remaining;
        if (parent.nodeType === 1 && /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|OPTION)$/i.test(parent.tagName || "")) return remaining;

        const text = node.nodeValue || "";
        const regex = candidateRegex();
        const matches = [];
        let match;
        while ((match = regex.exec(text))) {
            if (!parseCandidate(match[0])) continue;
            matches.push({ index: match.index, text: match[0] });
            if (rule.occurrence === "first" || remaining === 1) break;
        }
        if (!matches.length) return remaining;

        const fragment = document.createDocumentFragment();
        let cursor = 0;
        let used = 0;
        matches.forEach(function (entry) {
            if (remaining === 0) return;
            fragment.appendChild(document.createTextNode(text.slice(cursor, entry.index)));
            const span = createFormattedSpan(entry.text, rule);
            if (span) {
                fragment.appendChild(span);
                used += 1;
                if (remaining > 0) remaining -= 1;
            } else {
                fragment.appendChild(document.createTextNode(entry.text));
            }
            cursor = entry.index + entry.text.length;
        });
        fragment.appendChild(document.createTextNode(text.slice(cursor)));
        if (used) parent.replaceChild(fragment, node);
        return remaining;
    }

    function processElement(element, rule) {
        if (!element || !ruleTextMatches(element, rule)) return;

        const existing = Array.from(element.querySelectorAll("." + WRAP_CLASS + "[" + RULE_ATTR + '=\"' + cssEscapeAttr(String(rule.id || "rule")) + '\"]'));
        existing.forEach(function (span) { updateWrappedSpan(span, rule); });

        let remaining = rule.occurrence === "first" ? (existing.length ? 0 : 1) : -1;
        if (remaining === 0) return;

        const walker = document.createTreeWalker(
            element,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode: function (node) {
                    const parent = node.parentElement;
                    if (!parent) return NodeFilter.FILTER_REJECT;
                    if (parent.closest && parent.closest("." + WRAP_CLASS)) return NodeFilter.FILTER_REJECT;
                    if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|OPTION)$/i.test(parent.tagName || "")) return NodeFilter.FILTER_REJECT;
                    return candidateRegex().test(node.nodeValue || "") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                }
            }
        );

        const nodes = [];
        let current;
        while ((current = walker.nextNode())) nodes.push(current);
        nodes.forEach(function (node) {
            if (remaining === 0) return;
            remaining = processTextNode(node, rule, remaining);
        });
    }

    function cssEscapeAttr(value) {
        return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    }

    function applyRule(rule) {
        if (!rule || rule.enabled === false || !pageMatches(rule)) return;
        const selector = String(rule.selector || "").trim();
        if (!selector) return;
        let elements = [];
        try { elements = Array.from(document.querySelectorAll(selector)); } catch (_) { return; }
        elements.forEach(function (element) { processElement(element, rule); });
    }

    function applyAll() {
        if (!currentConfig || currentConfig.enabled === false) return;
        applying = true;
        try {
            restoreAll();
            (currentConfig.rules || []).forEach(applyRule);
        } finally {
            window.setTimeout(function () { applying = false; }, 0);
        }
    }

    function stopObserver() {
        if (observerTimer) window.clearTimeout(observerTimer);
        observerTimer = 0;
        if (observer) observer.disconnect();
        observer = null;
    }

    function startObserver() {
        if (observer || !document.body || !window.MutationObserver) return;
        observer = new MutationObserver(function (mutations) {
            if (applying) return;
            const relevant = mutations.some(function (mutation) {
                const target = mutation.target && mutation.target.nodeType === 1
                    ? mutation.target
                    : mutation.target && mutation.target.parentElement;
                if (target && target.closest && target.closest("." + WRAP_CLASS)) return false;
                return mutation.type === "childList" || mutation.type === "characterData";
            });
            if (!relevant) return;
            if (observerTimer) window.clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                stopObserver();
                applyAll();
                if (currentConfig && currentConfig.enabled !== false && currentConfig.observeDom !== false) startObserver();
            }, Math.max(40, Number(currentConfig && currentConfig.observeDelay) || 90));
        });
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }

    function refresh(config) {
        stopObserver();
        applying = true;
        try { restoreAll(); } finally { applying = false; }
        currentConfig = normalizeConfig(config);
        if (currentConfig.enabled !== false) {
            applyAll();
            if (currentConfig.observeDom !== false) startObserver();
            mountContextAccess();
        }
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return "\\" + c; });
    }

    function stableSelector(element) {
        if (!element || element.nodeType !== 1) return "";

        if (element.id) {
            try {
                const byId = "#" + cssEscape(element.id);
                if (document.querySelectorAll(byId).length === 1) return byId;
            } catch (_) {}
        }

        const dataAttrs = ["data-tabname", "data-bs-target", "name", "role"];
        for (let i = 0; i < dataAttrs.length; i += 1) {
            const attr = dataAttrs[i];
            const value = element.getAttribute && element.getAttribute(attr);
            if (!value) continue;
            const escaped = String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            const selector = element.tagName.toLowerCase() + "[" + attr + '=\"' + escaped + '\"]';
            try { if (document.querySelectorAll(selector).length === 1) return selector; } catch (_) {}
        }

        const classes = Array.from(element.classList || []).filter(function (name) {
            return !/^pmk|^active$|^selected$|^hover$|^focus$|^show$|^open$/.test(name);
        });
        if (classes.length) {
            const candidate = element.tagName.toLowerCase() + "." + classes.slice(0, 2).map(cssEscape).join(".");
            try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
        }

        const parts = [];
        let node = element;
        while (node && node !== document.body && parts.length < 6) {
            let part = node.tagName.toLowerCase();
            if (node.id) {
                part += "#" + cssEscape(node.id);
                parts.unshift(part);
                break;
            }
            const usable = Array.from(node.classList || []).filter(function (name) {
                return !/^pmk|^active$|^selected$|^hover$|^focus$|^show$|^open$/.test(name);
            });
            if (usable.length) part += "." + cssEscape(usable[0]);
            const parent = node.parentElement;
            if (parent && !usable.length) {
                const peers = Array.from(parent.children).filter(function (x) { return x.tagName === node.tagName; });
                if (peers.length > 1) part += ":nth-of-type(" + (peers.indexOf(node) + 1) + ")";
            }
            parts.unshift(part);
            node = parent;
        }
        return parts.join(" > ");
    }

    function pickerBannerText() {
        return detectLanguage() === "en"
            ? "Click the element containing the date — Escape to cancel"
            : "Clique sur l’élément contenant la date — Échap pour annuler";
    }

    function pickElementOnCurrentPage() {
        return new Promise(function (resolve, reject) {
            const overlay = document.getElementById("pmk-config-overlay");
            const previousDisplay = overlay ? overlay.style.display : "";
            if (overlay) overlay.style.display = "none";

            let style = document.getElementById(PICKER_STYLE_ID);
            if (!style) {
                style = document.createElement("style");
                style.id = PICKER_STYLE_ID;
                style.textContent = [
                    ".pmk034-picker-hover{outline:3px solid #0d6efd!important;outline-offset:2px!important;cursor:crosshair!important;}",
                    ".pmk034-picker-banner{position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#fff;border:1px solid #aaa;border-radius:5px;padding:9px 13px;box-shadow:0 2px 10px rgba(0,0,0,.28);font-size:14px;max-width:calc(100vw - 20px)}"
                ].join("");
                (document.head || document.documentElement).appendChild(style);
            }

            const banner = document.createElement("div");
            banner.className = "pmk034-picker-banner";
            banner.textContent = pickerBannerText();
            document.body.appendChild(banner);

            let hovered = null;
            function cleanup() {
                if (hovered) hovered.classList.remove("pmk034-picker-hover");
                document.removeEventListener("mouseover", over, true);
                document.removeEventListener("mouseout", out, true);
                document.removeEventListener("click", click, true);
                document.removeEventListener("keydown", key, true);
                if (banner.isConnected) banner.remove();
                if (overlay) overlay.style.display = previousDisplay;
            }
            function over(event) {
                if (hovered) hovered.classList.remove("pmk034-picker-hover");
                hovered = event.target && event.target.nodeType === 1 ? event.target : null;
                if (hovered && !hovered.closest(".pmk034-picker-banner")) hovered.classList.add("pmk034-picker-hover");
            }
            function out(event) {
                if (event.target && event.target.classList) event.target.classList.remove("pmk034-picker-hover");
            }
            function click(event) {
                if (event.target && event.target.closest && event.target.closest(".pmk034-picker-banner")) return;
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                const element = event.target;
                const selector = stableSelector(element);
                const targetName = String(element && element.textContent || "").replace(/\s+/g, " ").trim().slice(0, 120) ||
                    (element && element.tagName ? element.tagName.toLowerCase() : "element");
                cleanup();
                if (!selector) return reject(new Error("selector_unavailable"));
                resolve({ value: selector, selector: selector, targetName: targetName });
            }
            function key(event) {
                if (event.key !== "Escape") return;
                event.preventDefault();
                cleanup();
                reject(new Error("picker_cancelled"));
            }

            document.addEventListener("mouseover", over, true);
            document.addEventListener("mouseout", out, true);
            document.addEventListener("click", click, true);
            document.addEventListener("keydown", key, true);
        });
    }

    function ruleIndexFromFieldPath(path) {
        if (!Array.isArray(path)) return -1;
        const pos = path.indexOf("rules");
        if (pos === -1) return -1;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function pickForConfig(context) {
        const rootObject = context && context.rootObject ? context.rootObject : null;
        const fieldPath = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const index = ruleIndexFromFieldPath(fieldPath);
        const rule = rootObject && Array.isArray(rootObject.rules) && index >= 0 ? rootObject.rules[index] : null;
        const wantedPage = firstConcretePage(rule);

        if (wantedPage && window.location.pathname !== wantedPage) {
            try {
                sessionStorage.setItem(PENDING_PICK_KEY, JSON.stringify({
                    moduleId: MODULE_ID,
                    ruleIndex: index,
                    page: wantedPage,
                    draft: deepClone(rootObject || DEFAULTS),
                    startedAt: Date.now()
                }));
            } catch (_) {}
            window.location.href = window.location.origin + wantedPage;
            return new Promise(function () {});
        }

        return pickElementOnCurrentPage();
    }

    async function resumePendingPick() {
        let pending = null;
        try {
            const raw = sessionStorage.getItem(PENDING_PICK_KEY);
            if (raw) pending = JSON.parse(raw);
        } catch (_) {}
        if (!pending || pending.moduleId !== MODULE_ID) return false;
        if (Date.now() - Number(pending.startedAt || 0) > 15 * 60 * 1000) {
            try { sessionStorage.removeItem(PENDING_PICK_KEY); } catch (_) {}
            return false;
        }
        if (normalizePath(pending.page) !== window.location.pathname) return false;
        try { sessionStorage.removeItem(PENDING_PICK_KEY); } catch (_) {}

        window.setTimeout(async function () {
            try {
                const picked = await pickElementOnCurrentPage();
                const draft = normalizeConfig(pending.draft || DEFAULTS);
                const index = Number(pending.ruleIndex);
                if (!Number.isInteger(index) || !draft.rules[index]) return;
                draft.rules[index].selector = picked.selector;
                draft.rules[index].targetName = picked.targetName || picked.selector;
                if (!String(draft.rules[index].label || "").trim()) draft.rules[index].label = draft.rules[index].targetName;

                if (window.PMKConfig && typeof window.PMKConfig.saveConfig === "function") {
                    await window.PMKConfig.saveConfig(MODULE_ID, draft);
                    refresh(draft);
                    if (typeof window.PMKConfig.openAdmin === "function") {
                        await window.PMKConfig.openAdmin(MODULE_ID, { ruleIndex: index, sectionId: "rules" });
                    }
                } else {
                    refresh(draft);
                }
            } catch (_) {}
        }, 0);
        return true;
    }

    function newRule() {
        return {
            id: "rule-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7),
            enabled: true,
            label: "",
            pages: window.location.pathname || "*",
            selector: "",
            targetName: "",
            textContains: "",
            occurrence: "all",
            output: deepClone(DEFAULT_OUTPUT)
        };
    }

    function onTargetPick(rootObject, fieldPath, result) {
        const index = ruleIndexFromFieldPath(fieldPath);
        if (!rootObject || !Array.isArray(rootObject.rules) || index < 0 || !rootObject.rules[index] || !result) return;
        rootObject.rules[index].targetName = result.targetName || result.selector || "";
        if (!String(rootObject.rules[index].label || "").trim()) rootObject.rules[index].label = rootObject.rules[index].targetName;
    }

    function validate(config) {
        const lang = detectLanguage();
        const fail = function (fr, en) { return { ok: false, message: lang === "en" ? en : fr }; };
        if (!config || !Array.isArray(config.rules)) {
            return fail("La liste des règles de dates est invalide.", "The date rule list is invalid.");
        }
        const validDateFormats = ["koha", "dmy-slash", "mdy-slash", "iso", "dmy-dot", "dmy-dash", "custom"];
        const validTimeModes = ["auto", "always", "never"];
        const validTimeFormats = ["koha", "24h", "24h-seconds", "12h", "source", "custom"];
        const validOccurrences = ["first", "all"];

        for (let i = 0; i < config.rules.length; i += 1) {
            const rule = config.rules[i];
            if (!rule || rule.enabled === false) continue;
            if (!String(rule.pages || "").trim()) return fail("La règle " + (i + 1) + " doit avoir au moins une page Koha.", "Rule " + (i + 1) + " must have at least one Koha page.");
            if (!String(rule.selector || "").trim()) return fail("La règle " + (i + 1) + " doit avoir un élément cible.", "Rule " + (i + 1) + " must have a target element.");
            if (validOccurrences.indexOf(rule.occurrence || "all") === -1) return fail("Le mode d'occurrence de la règle " + (i + 1) + " est invalide.", "Rule " + (i + 1) + " has an invalid occurrence mode.");
            const output = merge(deepClone(DEFAULT_OUTPUT), rule.output || {});
            if (validDateFormats.indexOf(output.dateFormat) === -1) return fail("Le format de date de la règle " + (i + 1) + " est invalide.", "Rule " + (i + 1) + " has an invalid date format.");
            if (validTimeModes.indexOf(output.timeMode) === -1) return fail("Le mode d'affichage de l'heure de la règle " + (i + 1) + " est invalide.", "Rule " + (i + 1) + " has an invalid time display mode.");
            if (validTimeFormats.indexOf(output.timeFormat) === -1) return fail("Le format horaire de la règle " + (i + 1) + " est invalide.", "Rule " + (i + 1) + " has an invalid time format.");
            if (output.dateFormat === "custom" && !String(output.customDateFormat || "").trim()) return fail("Le format de date personnalisé de la règle " + (i + 1) + " est vide.", "Rule " + (i + 1) + " has an empty custom date format.");
            if (output.timeFormat === "custom" && !String(output.customTimeFormat || "").trim()) return fail("Le format horaire personnalisé de la règle " + (i + 1) + " est vide.", "Rule " + (i + 1) + " has an empty custom time format.");
        }
        return { ok: true };
    }

    function buildModuleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Formatage des dates affichées", en: "Displayed date formatting" },
            description: {
                fr: "Reformate des dates visibles dans Koha sans modifier les données. Chaque règle choisit une page, un élément, un format de date et le comportement de l'heure lorsqu'elle est présente.",
                en: "Reformats visible dates in Koha without changing data. Each rule selects a page, an element, a date format, and how time is displayed when present."
            },
            category: { fr: "Interface / présentation", en: "Interface / presentation" },
            supportedPages: ["catalogue.detail", "custom"],
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULTS),
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation générale", en: "General activation" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le formatage des dates", en: "Enable date formatting" } },
                        { key: "observeDom", type: "boolean", label: { fr: "Réappliquer après les mises à jour dynamiques de Koha", en: "Reapply after dynamic Koha updates" } },
                        { key: "observeDelay", type: "number", advanced: true, label: { fr: "Délai de retraitement du DOM (ms)", en: "DOM reprocessing delay (ms)" } }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Dates à formater", en: "Dates to format" },
                    description: {
                        fr: "Ajoutez autant de règles que nécessaire. Le format « Koha » suit le réglage date/heure de l'installation. En mode heure « Si présente », une date seule reste une date seule et une date+heure conserve son heure.",
                        en: "Add as many rules as needed. The “Koha” format follows the installation date/time settings. With “If present”, a date-only value stays date-only and a date+time value keeps its time."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Règles de formatage", en: "Formatting rules" },
                            addLabel: { fr: "Ajouter une date", en: "Add date" },
                            emptyLabel: { fr: "Aucune date configurée.", en: "No date configured." },
                            reorder: true,
                            newItem: newRule,
                            itemTitle: function (item, index) {
                                return String(item && (item.label || item.targetName || item.selector) || "").trim() || "Date " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de la règle", en: "Rule name" } },
                                {
                                    key: "pages",
                                    type: "textarea",
                                    label: { fr: "Pages Koha actives", en: "Active Koha pages" },
                                    help: { fr: "Un chemin par ligne. Le picker ouvre automatiquement la première page indiquée si nécessaire.", en: "One path per line. The picker automatically opens the first configured page when needed." }
                                },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Élément contenant la date", en: "Element containing the date" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                                    allowManual: true,
                                    pick: pickForConfig,
                                    onPick: onTargetPick
                                },
                                { key: "targetName", type: "text", readOnly: true, advanced: true, label: { fr: "Élément détecté", en: "Detected element" } },
                                {
                                    key: "textContains",
                                    type: "textarea",
                                    advanced: true,
                                    label: { fr: "Limiter aux éléments contenant l'un de ces textes", en: "Limit to elements containing one of these texts" },
                                    help: { fr: "Optionnel, un texte par ligne. Utile si un même sélecteur CSS correspond à plusieurs lignes différentes.", en: "Optional, one text per line. Useful when one CSS selector matches several different rows." }
                                },
                                {
                                    key: "occurrence",
                                    type: "select",
                                    label: { fr: "Dates à traiter dans l'élément", en: "Dates to process in the element" },
                                    options: [
                                        { value: "all", label: { fr: "Toutes les dates trouvées", en: "All dates found" } },
                                        { value: "first", label: { fr: "Première date seulement", en: "First date only" } }
                                    ]
                                },
                                {
                                    key: "output.dateFormat",
                                    type: "select",
                                    label: { fr: "Format de sortie de la date", en: "Output date format" },
                                    options: [
                                        { value: "koha", label: { fr: "Format configuré dans Koha", en: "Koha configured format" } },
                                        { value: "dmy-slash", label: { fr: "JJ/MM/AAAA — 31/12/2026", en: "DD/MM/YYYY — 31/12/2026" } },
                                        { value: "mdy-slash", label: { fr: "MM/JJ/AAAA — 12/31/2026", en: "MM/DD/YYYY — 12/31/2026" } },
                                        { value: "iso", label: { fr: "AAAA-MM-JJ — 2026-12-31", en: "YYYY-MM-DD — 2026-12-31" } },
                                        { value: "dmy-dot", label: { fr: "JJ.MM.AAAA — 31.12.2026", en: "DD.MM.YYYY — 31.12.2026" } },
                                        { value: "dmy-dash", label: { fr: "JJ-MM-AAAA — 31-12-2026", en: "DD-MM-YYYY — 31-12-2026" } },
                                        { value: "custom", label: { fr: "Format personnalisé", en: "Custom format" } }
                                    ]
                                },
                                {
                                    key: "output.customDateFormat",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Format de date personnalisé", en: "Custom date format" },
                                    help: { fr: "Jetons disponibles : YYYY, MM, DD. Exemple : DD/MM/YYYY.", en: "Available tokens: YYYY, MM, DD. Example: DD/MM/YYYY." }
                                },
                                {
                                    key: "output.timeMode",
                                    type: "select",
                                    label: { fr: "Affichage de l'heure", en: "Time display" },
                                    options: [
                                        { value: "auto", label: { fr: "Seulement si l'heure existe dans la valeur d'origine", en: "Only when time exists in the original value" } },
                                        { value: "always", label: { fr: "Toujours afficher l'heure", en: "Always show time" } },
                                        { value: "never", label: { fr: "Ne jamais afficher l'heure", en: "Never show time" } }
                                    ]
                                },
                                {
                                    key: "output.timeFormat",
                                    type: "select",
                                    label: { fr: "Format de sortie de l'heure", en: "Output time format" },
                                    options: [
                                        { value: "koha", label: { fr: "Format horaire configuré dans Koha", en: "Koha configured time format" } },
                                        { value: "24h", label: { fr: "24 h — 23:45", en: "24-hour — 23:45" } },
                                        { value: "24h-seconds", label: { fr: "24 h avec secondes — 23:45:30", en: "24-hour with seconds — 23:45:30" } },
                                        { value: "12h", label: { fr: "12 h — 11:45 PM", en: "12-hour — 11:45 PM" } },
                                        { value: "source", label: { fr: "Conserver le format horaire d'origine", en: "Keep original time format" } },
                                        { value: "custom", label: { fr: "Format personnalisé", en: "Custom format" } }
                                    ]
                                },
                                {
                                    key: "output.customTimeFormat",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Format horaire personnalisé", en: "Custom time format" },
                                    help: { fr: "Jetons : HH, hh, mm, ss, A. Exemple : HH:mm:ss.", en: "Tokens: HH, hh, mm, ss, A. Example: HH:mm:ss." }
                                },
                                {
                                    key: "output.separator",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Séparateur entre date et heure", en: "Separator between date and time" },
                                    help: { fr: "Par défaut : un espace. Exemple possible : « à ».", en: "Default: one space. Example: “ at ”." }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "compatibility",
                    label: { fr: "Compatibilité", en: "Compatibility" },
                    description: {
                        fr: "Le module reconnaît les dates ISO et les dates numériques locales avec ou sans heure. Il ne modifie jamais une valeur qu'il ne parvient pas à valider. Le formatage visuel n'est pas destiné à servir de source de données métier à d'autres modules.",
                        en: "The module recognizes ISO and local numeric dates with or without time. It never changes a value it cannot validate. Visual formatting is not intended to be used as a business-data source by other modules."
                    },
                    fields: []
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "rules";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') || main.querySelector('[data-pmk-section-id="rules"]');
                if (!section) return;
                window.setTimeout(function () { section.scrollIntoView({ block: "start", behavior: "smooth" }); }, 0);
            }
        };
    }

    function registerModuleIfNeeded() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return;
        let exists = false;
        try {
            exists = typeof window.PMKConfig.listModules === "function" &&
                window.PMKConfig.listModules().some(function (module) { return module && module.id === MODULE_ID; });
        } catch (_) {}
        if (!exists) window.PMKConfig.registerModule(buildModuleDefinition());
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (window.location.pathname !== "/cgi-bin/koha/catalogue/detail.pl") return;
        const anchor = document.querySelector("strong.infotech") || document.querySelector(".technique-text") || document.querySelector(".technique");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: "date-formatting-catalogue-detail",
                context: { sectionId: "rules", page: "catalogue.detail" }
            });
        } catch (_) {}
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return normalizeConfig(cfg || {}); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function start() {
        registerModuleIfNeeded();
        resumePendingPick();
        loadConfig().then(refresh);
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, refresh); } catch (_) {}
        }
    }

    window.PMK034DateDisplayFormatting = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        parseCandidate: parseCandidate,
        formatParsed: formatParsed,
        formatValue: function (value, output) {
            const parsed = parseCandidate(value);
            return parsed ? formatParsed(parsed, output || DEFAULT_OUTPUT) : value;
        },
        getConfig: function () { return deepClone(currentConfig); },
        moduleDefinition: buildModuleDefinition
    };

    start();
})();

;window.PMKNonPlugin.loaded.push("034-modif-dates-technique-detail.js");
} catch (error) { window.PMKNonPlugin.errors.push("034-modif-dates-technique-detail.js: "+error.message); console.error("[PMK] 034-modif-dates-technique-detail.js",error); };
try {
/*
 Nom du fichier : 035-resize-z3950.js
 Dépendances : 000-pmk-config-firestore.js 0.4.19+ recommandé (facultatif : valeurs par défaut intégrées)
 Date de dernière modification : 2026-09-17
 Version : 2.0.0-preplugin
 Auteur : équipe PimpMyKoha / refonte PimpMyKoha
 Description : Améliore le confort de la recherche Z39.50/SRU : hauteur adaptative,
               redimensionnement optionnel de la fenêtre et normalisation configurable
               des termes de recherche. Prépare un service de normalisation réutilisable
               par le futur module 048 sans modifier les données de Koha.
*/
(function () {
    "use strict";

    const MODULE_ID = "z3950-workspace";
    const MODULE_VERSION = "2.1.0-preplugin";
    const PAGE_PATH = "/cgi-bin/koha/cataloguing/z3950_search.pl";
    const STYLE_ID = "pmk035-z3950-style";
    const CONTEXT_KEY = "z3950-workspace-main";

    const DEFAULTS = {
        enabled: true,
        pages: [
            {
                id: "cataloguing.z3950-search",
                enabled: true,
                path: PAGE_PATH
            }
        ],
        layout: {
            enabled: true,
            adaptiveHeight: true,
            heightRatio: 0.75,
            minHeight: 260,
            maxHeight: 900,
            compactBreakpoint: 768,
            compactTargetMaxHeight: 320,
            criteriaSelector: "#cat_z3950_search .col-6 fieldset.rows, #cat_z3950_search .col-xs-6 .rows",
            targetsSelector: "#z3950_search_targets"
        },
        windowSizing: {
            enabled: true,
            widthRatio: 0.80,
            heightRatio: 0.80,
            position: "top-left",
            minViewportWidth: 900,
            runOncePerPage: true
        },
        normalization: {
            enabled: true,
            mode: "before-submit",
            normalizePrefilledOnLoad: false,
            trimSpaces: false,
            collapseSpaces: false,
            extraMappings: true,
            fields: [
                { id: "isbn", enabled: true, labelFr: "ISBN", labelEn: "ISBN", selector: "#isbn, input[name='isbn']" },
                { id: "issn", enabled: true, labelFr: "ISSN", labelEn: "ISSN", selector: "#issn, input[name='issn']" },
                { id: "title", enabled: true, labelFr: "Titre", labelEn: "Title", selector: "#title, input[name='title']" },
                { id: "author", enabled: true, labelFr: "Auteur", labelEn: "Author", selector: "#author, input[name='author']" },
                { id: "publicationyear", enabled: true, labelFr: "Année de publication", labelEn: "Publication year", selector: "#publicationyear, input[name='publicationyear']" },
                { id: "subject", enabled: true, labelFr: "Sujet", labelEn: "Subject", selector: "#subject, input[name='subject']" },
                { id: "srchany", enabled: true, labelFr: "Mot-clé", labelEn: "Keyword", selector: "#srchany, input[name='srchany']" },
                { id: "lccall", enabled: true, labelFr: "Cote LC", labelEn: "LC call number", selector: "#lccall, input[name='lccall']" },
                { id: "controlnumber", enabled: true, labelFr: "Numéro de contrôle", labelEn: "Control number", selector: "#controlnumber, input[name='controlnumber']" },
                { id: "dewey", enabled: true, labelFr: "Dewey", labelEn: "Dewey", selector: "#dewey, input[name='dewey']" },
                { id: "stdid", enabled: true, labelFr: "Identifiant standard", labelEn: "Standard ID", selector: "#stdid, input[name='stdid']" }
            ]
        }
    };

    let currentConfig = deepClone(DEFAULTS);
    let resizeHandler = null;
    let submitHandler = null;
    let inputHandler = null;
    let mutationObserver = null;
    let applyTimer = 0;
    let windowSizingAttempted = false;
    const originalInlineStyles = new Map();

    function deepClone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function isPlainObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) return Array.isArray(override) ? deepClone(override) : deepClone(base);
        if (!isPlainObject(base)) return override === undefined ? deepClone(base) : deepClone(override);
        const out = deepClone(base) || {};
        if (!isPlainObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            const value = override[key];
            if (Array.isArray(value)) out[key] = deepClone(value);
            else if (isPlainObject(value)) out[key] = deepMerge(isPlainObject(out[key]) ? out[key] : {}, value);
            else out[key] = value;
        });
        return out;
    }

    function clampNumber(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function normalizeConfig(config) {
        const out = deepMerge(DEFAULTS, config || {});
        out.enabled = out.enabled !== false;
        if (!Array.isArray(out.pages)) out.pages = deepClone(DEFAULTS.pages);
        out.layout.heightRatio = clampNumber(out.layout.heightRatio, 0.30, 1, 0.75);
        out.layout.minHeight = Math.max(80, Number(out.layout.minHeight) || 260);
        out.layout.maxHeight = Math.max(out.layout.minHeight, Number(out.layout.maxHeight) || 900);
        out.layout.compactBreakpoint = Math.max(320, Number(out.layout.compactBreakpoint) || 768);
        out.layout.compactTargetMaxHeight = Math.max(100, Number(out.layout.compactTargetMaxHeight) || 320);
        out.windowSizing.widthRatio = clampNumber(out.windowSizing.widthRatio, 0.30, 1, 0.80);
        out.windowSizing.heightRatio = clampNumber(out.windowSizing.heightRatio, 0.30, 1, 0.80);
        out.windowSizing.minViewportWidth = Math.max(320, Number(out.windowSizing.minViewportWidth) || 900);
        if (["none", "top-left", "center"].indexOf(out.windowSizing.position) === -1) out.windowSizing.position = "top-left";
        if (["none", "before-submit", "live"].indexOf(out.normalization.mode) === -1) out.normalization.mode = "before-submit";
        if (!Array.isArray(out.normalization.fields)) out.normalization.fields = deepClone(DEFAULTS.normalization.fields);
        return out;
    }

    function pageEnabled() {
        if (window.location.pathname !== PAGE_PATH) return false;
        const pages = Array.isArray(currentConfig.pages) ? currentConfig.pages : [];
        const page = pages.find(function (entry) {
            return entry && (entry.path === PAGE_PATH || entry.id === "cataloguing.z3950-search");
        });
        return !page || page.enabled !== false;
    }

    function installSharedNormalizationService() {
        if (window.PMKInputNormalization && typeof window.PMKInputNormalization.stripDiacritics === "function") return;

        function stripDiacritics(value, extraMappings) {
            let text = value == null ? "" : String(value);
            if (extraMappings !== false) {
                text = text
                    .replace(/œ/g, "oe").replace(/Œ/g, "OE")
                    .replace(/æ/g, "ae").replace(/Æ/g, "AE")
                    .replace(/ø/g, "o").replace(/Ø/g, "O")
                    .replace(/ð/g, "d").replace(/Ð/g, "D")
                    .replace(/þ/g, "th").replace(/Þ/g, "TH")
                    .replace(/ł/g, "l").replace(/Ł/g, "L");
            }
            try {
                text = text.normalize("NFD");
            } catch (_) {}
            try {
                return text.replace(/\p{M}+/gu, "");
            } catch (_) {
                return text.replace(/[\u0300-\u036f]/g, "");
            }
        }

        function normalizeText(value, options) {
            const opts = options || {};
            let text = stripDiacritics(value, opts.extraMappings);
            if (opts.collapseSpaces === true) text = text.replace(/\s+/g, " ");
            if (opts.trimSpaces === true) text = text.trim();
            return text;
        }

        window.PMKInputNormalization = {
            version: "1.0.0",
            stripDiacritics: stripDiacritics,
            normalizeText: normalizeText
        };
    }

    function normalizeText(value) {
        installSharedNormalizationService();
        return window.PMKInputNormalization.normalizeText(value, {
            extraMappings: currentConfig.normalization.extraMappings !== false,
            trimSpaces: currentConfig.normalization.trimSpaces === true,
            collapseSpaces: currentConfig.normalization.collapseSpaces === true
        });
    }

    function activeFieldRules() {
        if (!currentConfig.normalization || currentConfig.normalization.enabled === false) return [];
        return (Array.isArray(currentConfig.normalization.fields) ? currentConfig.normalization.fields : [])
            .filter(function (rule) {
                return rule && rule.enabled !== false && String(rule.selector || "").trim();
            });
    }

    function collectConfiguredInputs(root) {
        const scope = root && root.querySelectorAll ? root : document;
        const seen = new Set();
        const inputs = [];
        activeFieldRules().forEach(function (rule) {
            let found = [];
            try { found = Array.from(scope.querySelectorAll(rule.selector)); } catch (_) { found = []; }
            found.forEach(function (input) {
                if (!input || seen.has(input)) return;
                if (!(input instanceof HTMLInputElement) && !(input instanceof HTMLTextAreaElement)) return;
                seen.add(input);
                inputs.push(input);
            });
        });
        return inputs;
    }

    function inputMatchesConfiguredRule(input) {
        if (!input || !input.matches) return false;
        return activeFieldRules().some(function (rule) {
            try { return input.matches(rule.selector); } catch (_) { return false; }
        });
    }

    function normalizeInput(input) {
        if (!input || typeof input.value !== "string") return false;
        const before = input.value;
        const after = normalizeText(before);
        if (before === after) return false;

        const canSelect = typeof input.selectionStart === "number" && typeof input.selectionEnd === "number";
        const start = canSelect ? input.selectionStart : null;
        const end = canSelect ? input.selectionEnd : null;
        input.value = after;

        if (canSelect && typeof input.setSelectionRange === "function") {
            try {
                const newStart = normalizeText(before.slice(0, start)).length;
                const newEnd = normalizeText(before.slice(0, end)).length;
                input.setSelectionRange(newStart, newEnd);
            } catch (_) {}
        }
        return true;
    }

    function normalizeAllConfiguredInputs(root) {
        collectConfiguredInputs(root).forEach(normalizeInput);
    }

    function rememberStyle(element) {
        if (!element || originalInlineStyles.has(element)) return;
        originalInlineStyles.set(element, {
            height: element.style.height,
            minHeight: element.style.minHeight,
            maxHeight: element.style.maxHeight,
            overflowY: element.style.overflowY
        });
    }

    function restoreLayout() {
        originalInlineStyles.forEach(function (styles, element) {
            if (!element || !element.style) return;
            element.style.height = styles.height || "";
            element.style.minHeight = styles.minHeight || "";
            element.style.maxHeight = styles.maxHeight || "";
            element.style.overflowY = styles.overflowY || "";
            element.removeAttribute("data-pmk035-layout");
        });
        originalInlineStyles.clear();
    }

    function queryElements(selector) {
        if (!String(selector || "").trim()) return [];
        try { return Array.from(document.querySelectorAll(selector)); } catch (_) { return []; }
    }

    function applyLayout() {
        restoreLayout();
        if (!currentConfig.enabled || !pageEnabled() || currentConfig.layout.enabled === false) return;

        const layout = currentConfig.layout;
        const criteria = queryElements(layout.criteriaSelector);
        const targets = queryElements(layout.targetsSelector);
        const all = [];
        const seen = new Set();
        criteria.concat(targets).forEach(function (element) {
            if (!element || seen.has(element)) return;
            seen.add(element);
            all.push(element);
        });
        if (!all.length) return;

        const compact = window.innerWidth < Number(layout.compactBreakpoint || 768);
        if (compact) {
            criteria.forEach(function (element) {
                rememberStyle(element);
                element.style.height = "auto";
                element.style.minHeight = "";
                element.style.maxHeight = "none";
                element.style.overflowY = "visible";
                element.setAttribute("data-pmk035-layout", "compact-criteria");
            });
            targets.forEach(function (element) {
                rememberStyle(element);
                element.style.height = "auto";
                element.style.minHeight = "";
                element.style.maxHeight = String(layout.compactTargetMaxHeight || 320) + "px";
                element.style.overflowY = "auto";
                element.setAttribute("data-pmk035-layout", "compact-targets");
            });
            return;
        }

        if (layout.adaptiveHeight === false) return;
        const rawHeight = Math.round(window.innerHeight * Number(layout.heightRatio || 0.75));
        const height = Math.min(Number(layout.maxHeight || 900), Math.max(Number(layout.minHeight || 260), rawHeight));
        all.forEach(function (element) {
            rememberStyle(element);
            element.style.height = height + "px";
            element.style.maxHeight = height + "px";
            element.style.overflowY = "auto";
            element.setAttribute("data-pmk035-layout", "adaptive");
        });
    }

    function installStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = [
            "#cat_z3950_search [data-pmk035-layout='adaptive']{box-sizing:border-box;}",
            "#cat_z3950_search .pmk-context-config{vertical-align:middle;}",
            "@media (max-width:767.98px){#cat_z3950_search .row{row-gap:.75rem;}}"
        ].join("\n");
        (document.head || document.documentElement).appendChild(style);
    }

    function maybeResizeWindow() {
        const cfg = currentConfig.windowSizing || {};
        if (!currentConfig.enabled || !pageEnabled() || cfg.enabled === false) return;
        if (cfg.runOncePerPage !== false && windowSizingAttempted) return;
        if (window.innerWidth < Number(cfg.minViewportWidth || 900)) return;

        windowSizingAttempted = true;
        try {
            const availWidth = Number(window.screen && window.screen.availWidth) || Number(window.screen && window.screen.width) || window.innerWidth;
            const availHeight = Number(window.screen && window.screen.availHeight) || Number(window.screen && window.screen.height) || window.innerHeight;
            const width = Math.max(480, Math.round(availWidth * Number(cfg.widthRatio || 0.8)));
            const height = Math.max(420, Math.round(availHeight * Number(cfg.heightRatio || 0.8)));
            window.resizeTo(width, height);

            if (cfg.position === "top-left") {
                window.moveTo(0, 0);
            } else if (cfg.position === "center") {
                const left = Math.max(0, Math.round((availWidth - width) / 2));
                const top = Math.max(0, Math.round((availHeight - height) / 2));
                window.moveTo(left, top);
            }
        } catch (_) {
            /* Le navigateur peut légitimement refuser resizeTo/moveTo. */
        }
    }

    function detachRuntimeListeners() {
        if (resizeHandler) {
            window.removeEventListener("resize", resizeHandler);
            resizeHandler = null;
        }
        if (submitHandler) {
            document.removeEventListener("submit", submitHandler, true);
            submitHandler = null;
        }
        if (inputHandler) {
            document.removeEventListener("input", inputHandler, true);
            inputHandler = null;
        }
        if (mutationObserver) {
            mutationObserver.disconnect();
            mutationObserver = null;
        }
        window.clearTimeout(applyTimer);
        applyTimer = 0;
    }

    function scheduleApplyLayout() {
        window.clearTimeout(applyTimer);
        applyTimer = window.setTimeout(function () {
            applyTimer = 0;
            applyLayout();
            mountContextAccess();
        }, 60);
    }

    function attachRuntimeListeners() {
        detachRuntimeListeners();
        if (!currentConfig.enabled || !pageEnabled()) return;

        resizeHandler = function () { scheduleApplyLayout(); };
        window.addEventListener("resize", resizeHandler, { passive: true });

        const normalization = currentConfig.normalization || {};
        if (normalization.enabled !== false && normalization.mode === "before-submit") {
            submitHandler = function (event) {
                const form = event && event.target;
                if (!form || !form.matches || !form.matches("#cat_z3950_search form[name='f'], #cat_z3950_search form[action*='z3950_search.pl']")) return;
                normalizeAllConfiguredInputs(form);
            };
            document.addEventListener("submit", submitHandler, true);
        }

        if (normalization.enabled !== false && normalization.mode === "live") {
            inputHandler = function (event) {
                const input = event && event.target;
                if (!inputMatchesConfiguredRule(input)) return;
                normalizeInput(input);
            };
            document.addEventListener("input", inputHandler, true);
        }

        mutationObserver = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                if (mutation.type !== "childList" || !mutation.addedNodes || !mutation.addedNodes.length) return false;
                return Array.from(mutation.addedNodes).some(function (node) {
                    if (!node || node.nodeType !== 1) return false;
                    if (node.matches && node.matches("#z3950_search_targets, fieldset.rows, form[name='f']")) return true;
                    return Boolean(node.querySelector && node.querySelector("#z3950_search_targets, fieldset.rows, form[name='f']"));
                });
            });
            if (relevant) scheduleApplyLayout();
        });
        mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
    }

    function mountContextAccess() {
        if (!currentConfig.enabled || !pageEnabled()) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = document.querySelector("#cat_z3950_search h1") || document.querySelector("h1");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: CONTEXT_KEY,
                context: { page: "cataloguing.z3950-search", sectionId: "layout" }
            });
        } catch (_) {}
    }

    function newFieldRule() {
        return {
            id: "custom-" + Date.now().toString(36),
            enabled: true,
            labelFr: "Nouveau champ",
            labelEn: "New field",
            selector: ""
        };
    }

    function validateConfig(config) {
        const fail = function (fr, en) {
            const lang = window.PMKConfig && typeof window.PMKConfig.getLanguage === "function" ? window.PMKConfig.getLanguage() : "fr";
            return { ok: false, message: lang === "en" ? en : fr };
        };
        const cfg = normalizeConfig(config);
        if (!Array.isArray(cfg.pages)) return fail("La liste des pages du 035 est invalide.", "Module 035 page list is invalid.");
        if (cfg.layout.heightRatio < 0.30 || cfg.layout.heightRatio > 1) return fail("Le ratio de hauteur doit être compris entre 0,30 et 1.", "Height ratio must be between 0.30 and 1.");
        if (cfg.windowSizing.widthRatio < 0.30 || cfg.windowSizing.widthRatio > 1 || cfg.windowSizing.heightRatio < 0.30 || cfg.windowSizing.heightRatio > 1) {
            return fail("Les ratios de fenêtre doivent être compris entre 0,30 et 1.", "Window ratios must be between 0.30 and 1.");
        }
        const modes = ["none", "before-submit", "live"];
        if (modes.indexOf(cfg.normalization.mode) === -1) return fail("Le mode de normalisation est invalide.", "Normalization mode is invalid.");
        for (let i = 0; i < cfg.normalization.fields.length; i += 1) {
            const field = cfg.normalization.fields[i];
            if (!field || field.enabled === false) continue;
            if (!String(field.selector || "").trim()) return fail("Un champ de normalisation actif n'a pas de cible.", "An enabled normalization field has no target.");
            try { document.createDocumentFragment().querySelector(field.selector); } catch (_) {
                return fail("Un sélecteur de champ du 035 est invalide : " + field.selector, "A module 035 field selector is invalid: " + field.selector);
            }
        }
        return { ok: true };
    }

    function buildModuleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Confort de recherche Z39.50 / SRU", en: "Z39.50 / SRU search workspace" },
            description: {
                fr: "Adapte l'espace de travail Z39.50/SRU à la fenêtre et peut normaliser les termes envoyés aux serveurs externes. Le module ne modifie aucune notice ni donnée Koha.",
                en: "Adapts the Z39.50/SRU workspace to the window and can normalize search terms sent to external servers. The module changes no Koha record or stored data."
            },
            category: { fr: "Catalogage / interface", en: "Cataloging / interface" },
            supportedPages: ["cataloguing.z3950-search"],
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULTS),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation et page", en: "Activation and page" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        {
                            key: "pages",
                            type: "repeater",
                            reorder: false,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function () { return "Z39.50 / SRU"; },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Actif sur cette page", en: "Enabled on this page" } },
                                { key: "id", type: "readonly", advanced: true, label: { fr: "Identifiant", en: "Identifier" } },
                                { key: "path", type: "readonly", label: { fr: "Chemin Koha", en: "Koha path" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "layout",
                    label: { fr: "Confort d'affichage", en: "Display comfort" },
                    description: {
                        fr: "Sur grand écran, les critères et la liste des serveurs utilisent une part configurable de la hauteur disponible. Sur petite fenêtre, le module revient automatiquement à une présentation plus souple.",
                        en: "On large screens, criteria and target lists use a configurable share of available height. On small windows, the module automatically returns to a more flexible layout."
                    },
                    fields: [
                        { key: "layout.enabled", type: "boolean", label: { fr: "Améliorer la hauteur des zones", en: "Improve panel heights" } },
                        { key: "layout.adaptiveHeight", type: "boolean", label: { fr: "Adapter automatiquement à la hauteur de la fenêtre", en: "Automatically adapt to window height" } },
                        { key: "layout.heightRatio", type: "number", label: { fr: "Part de la hauteur de fenêtre (0,30 à 1)", en: "Share of window height (0.30 to 1)" } },
                        { key: "layout.minHeight", type: "number", label: { fr: "Hauteur minimale (px)", en: "Minimum height (px)" } },
                        { key: "layout.maxHeight", type: "number", label: { fr: "Hauteur maximale (px)", en: "Maximum height (px)" } },
                        { key: "layout.compactBreakpoint", type: "number", advanced: true, label: { fr: "Seuil petite fenêtre (px)", en: "Small-window breakpoint (px)" } },
                        { key: "layout.compactTargetMaxHeight", type: "number", advanced: true, label: { fr: "Hauteur maxi des serveurs sur petite fenêtre (px)", en: "Max target-list height on small windows (px)" } },
                        { key: "layout.criteriaSelector", type: "text", advanced: true, label: { fr: "Cible zone critères", en: "Criteria area target" } },
                        { key: "layout.targetsSelector", type: "text", advanced: true, label: { fr: "Cible liste des serveurs", en: "Target-list target" } }
                    ]
                },
                {
                    type: "section",
                    id: "window",
                    label: { fr: "Fenêtre Z39.50", en: "Z39.50 window" },
                    description: {
                        fr: "Le navigateur peut refuser le redimensionnement, notamment si la page n'est pas une fenêtre ouverte par script ou comporte plusieurs onglets. Le refus est silencieux et n'empêche pas le reste du module de fonctionner.",
                        en: "The browser may refuse resizing, especially when the page is not a script-opened window or has multiple tabs. Refusal is silent and does not prevent the rest of the module from working."
                    },
                    fields: [
                        { key: "windowSizing.enabled", type: "boolean", label: { fr: "Tenter d'agrandir la fenêtre", en: "Try to enlarge the window" } },
                        { key: "windowSizing.widthRatio", type: "number", label: { fr: "Largeur cible (0,30 à 1)", en: "Target width (0.30 to 1)" } },
                        { key: "windowSizing.heightRatio", type: "number", label: { fr: "Hauteur cible (0,30 à 1)", en: "Target height (0.30 to 1)" } },
                        {
                            key: "windowSizing.position",
                            type: "select",
                            label: { fr: "Position", en: "Position" },
                            options: [
                                { value: "none", label: { fr: "Ne pas déplacer", en: "Do not move" } },
                                { value: "top-left", label: { fr: "Coin supérieur gauche", en: "Top-left corner" } },
                                { value: "center", label: { fr: "Centrer", en: "Center" } }
                            ]
                        },
                        { key: "windowSizing.minViewportWidth", type: "number", advanced: true, label: { fr: "Ne pas redimensionner sous cette largeur (px)", en: "Do not resize below this width (px)" } },
                        { key: "windowSizing.runOncePerPage", type: "boolean", advanced: true, label: { fr: "Une seule tentative par chargement", en: "Only one attempt per page load" } }
                    ]
                },
                {
                    type: "section",
                    id: "normalization",
                    label: { fr: "Termes de recherche et accents", en: "Search terms and accents" },
                    description: {
                        fr: "Par défaut, les accents sont retirés juste avant l'envoi du formulaire afin de conserver une saisie naturelle à l'écran. Le mode direct permet de normaliser au fur et à mesure de la frappe et du collage.",
                        en: "By default, accents are removed just before form submission so typing remains natural on screen. Live mode normalizes as the user types or pastes."
                    },
                    fields: [
                        { key: "normalization.enabled", type: "boolean", label: { fr: "Activer la normalisation", en: "Enable normalization" } },
                        {
                            key: "normalization.mode",
                            type: "select",
                            label: { fr: "Moment de la normalisation", en: "When to normalize" },
                            options: [
                                { value: "none", label: { fr: "Aucune modification", en: "No modification" } },
                                { value: "before-submit", label: { fr: "Juste avant la recherche", en: "Just before search" } },
                                { value: "live", label: { fr: "Pendant la saisie et le collage", en: "While typing and pasting" } }
                            ]
                        },
                        { key: "normalization.normalizePrefilledOnLoad", type: "boolean", label: { fr: "Normaliser aussi les valeurs déjà présentes au chargement", en: "Also normalize prefilled values on load" } },
                        { key: "normalization.extraMappings", type: "boolean", advanced: true, label: { fr: "Convertir aussi œ, æ, ø, ł…", en: "Also convert œ, æ, ø, ł…" } },
                        { key: "normalization.trimSpaces", type: "boolean", advanced: true, label: { fr: "Supprimer les espaces en début et fin", en: "Trim leading and trailing spaces" } },
                        { key: "normalization.collapseSpaces", type: "boolean", advanced: true, label: { fr: "Réduire les espaces multiples", en: "Collapse repeated spaces" } },
                        {
                            key: "normalization.fields",
                            type: "repeater",
                            label: { fr: "Champs concernés", en: "Affected fields" },
                            addLabel: { fr: "Ajouter un champ", en: "Add field" },
                            reorder: true,
                            newItem: newFieldRule,
                            itemTitle: function (item, index, lang) {
                                const value = lang === "en" ? item && item.labelEn : item && item.labelFr;
                                return String(value || item && item.id || "").trim() || "Champ " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Champ actif", en: "Field enabled" } },
                                { key: "labelFr", type: "text", label: { fr: "Nom français", en: "French name" } },
                                { key: "labelEn", type: "text", label: { fr: "Nom anglais", en: "English name" } },
                                { key: "selector", type: "text", advanced: true, label: { fr: "Sélecteur du champ", en: "Field selector" } },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant interne", en: "Internal identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "compatibility",
                    label: { fr: "Compatibilité et futur 048", en: "Compatibility and future 048" },
                    description: {
                        fr: "La normalisation est isolée dans un petit service réutilisable (PMKInputNormalization). Lors de l'audit du 048, son contrôle des accents pourra utiliser le même moteur au lieu de maintenir deux implémentations concurrentes.",
                        en: "Normalization is isolated in a small reusable service (PMKInputNormalization). During the module 048 audit, its accent control can use the same engine instead of maintaining two competing implementations."
                    },
                    fields: []
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "layout";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') || main.querySelector('[data-pmk-section-id="layout"]');
                if (!section) return;
                window.setTimeout(function () { section.scrollIntoView({ block: "start", behavior: "smooth" }); }, 0);
            }
        };
    }

    function registerModuleIfNeeded() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return;
        let exists = false;
        try {
            exists = typeof window.PMKConfig.listModules === "function" &&
                window.PMKConfig.listModules().some(function (module) { return module && module.id === MODULE_ID; });
        } catch (_) {}
        if (!exists) window.PMKConfig.registerModule(buildModuleDefinition());
    }

    function loadConfig() {
        registerModuleIfNeeded();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return normalizeConfig(cfg); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config);
        restoreLayout();
        detachRuntimeListeners();

        if (!currentConfig.enabled || !pageEnabled()) return;

        installStyles();
        installSharedNormalizationService();
        applyLayout();
        maybeResizeWindow();
        attachRuntimeListeners();

        if (currentConfig.normalization.enabled !== false &&
            currentConfig.normalization.mode !== "none" &&
            currentConfig.normalization.normalizePrefilledOnLoad === true) {
            normalizeAllConfiguredInputs(document);
        }

        mountContextAccess();
    }

    function refresh() {
        loadConfig().then(applyConfig);
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: { livePreview: true },
            canPreview: function () { return window.location.pathname === PAGE_PATH; },
            previewDraft: function (draft) {
                if (window.location.pathname !== PAGE_PATH) throw new Error("visual_preview_wrong_page");
                const before = deepClone(currentConfig || DEFAULTS);
                applyConfig(draft);
                return function () { applyConfig(before); };
            }
        });
        return true;
    }

    function start() {
        registerModuleIfNeeded();
        registerVisualEditorAdapter();
        if (window.location.pathname !== PAGE_PATH) return;
        refresh();
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
    }

    window.addEventListener("pmk:config-ready", registerVisualEditorAdapter, { once: true });

    window.PMK035Z3950Workspace = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        applyLayout: applyLayout,
        normalizeText: function (value) { return normalizeText(value); },
        getConfig: function () { return deepClone(currentConfig); },
        destroy: function () {
            detachRuntimeListeners();
            restoreLayout();
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("035-resize-z3950.js");
} catch (error) { window.PMKNonPlugin.errors.push("035-resize-z3950.js: "+error.message); console.error("[PMK] 035-resize-z3950.js",error); };
try {
/*
 Nom du fichier : 036-clear-search-when-barcode.js
 Dépendances : 000-pmk-config-firestore.js 0.4.20+ recommandé (valeurs par défaut intégrées)
 Date de dernière modification : 2026-10-02
 Version : 2.1.5-preplugin
 Auteur : équipe PimpMyKoha / refonte PimpMyKoha
 Description : Gère le nettoyage visuel de la barre de recherche catalogue après une
               recherche reconnue comme code-barres. La reconnaissance repose sur une
               liste ordonnée de profils prédéfinis ou personnalisés (index Koha, formats
               numériques/alphanumériques, EAN/UPC/ISBN/ISSN, préfixes, regex, AIM).
               La valeur Koha localStorage.searchbox_value est conservée afin de ne pas
               casser les modules qui utilisent le contexte de la dernière recherche.
               Intègre aussi le bouton d'effacement manuel de l'ancien 053, sous une
               forme compacte et native dans la barre catalogue.
*/
(function () {
    "use strict";

    const MODULE_ID = "catalogue-search-behavior";
    const MODULE_VERSION = "2.1.5-preplugin";
    const TARGET_SELECTOR = "#cat-search-block #search-form";
    const FORM_SELECTOR = "#cat-search-block";
    const CONTEXT_KEY = "catalogue-search-behavior-main";
    const CLEAR_BUTTON_ATTR = "data-pmk036-clear-button";
    const STYLE_ID = "pmk036-catalogue-search-style";

    const DEFAULTS = {
        enabled: true,
        scope: {
            mode: "catalogue-searchbar",
            targetSelector: TARGET_SELECTOR,
            formSelector: FORM_SELECTOR
        },
        behavior: {
            preserveSearchContext: true,
            clearOnAction: "clear",
            onlyIfCurrentEmptyOrMatchesStored: true,
            dispatchInputEvent: true,
            dispatchChangeEvent: false,
            focusAfterClear: false
        },
        clearButton: {
            enabled: true,
            labelFr: "Effacer la recherche",
            labelEn: "Clear search"
        },
        scanner: {
            preferHistoricalSignatures: true,
            trimOuterSpaces: true,
            detectAimIdentifier: true,
            stripAimIdentifierBeforeMatch: true
        },
        profiles: [
            {
                id: "koha-barcode-index",
                enabled: true,
                preset: "any",
                nameFr: "Index Koha : Code à barres",
                nameEn: "Koha index: Barcode",
                action: "clear",
                indexMode: "include",
                indexValues: "bc",
                aimIdentifiers: "",
                minLength: 1,
                maxLength: 128,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "isbn13",
                enabled: true,
                preset: "isbn13",
                nameFr: "ISBN-13",
                nameEn: "ISBN-13",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 13,
                maxLength: 17,
                prefix: "",
                suffix: "",
                allowSeparators: true,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "isbn10",
                enabled: true,
                preset: "isbn10",
                nameFr: "ISBN-10",
                nameEn: "ISBN-10",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 10,
                maxLength: 13,
                prefix: "",
                suffix: "",
                allowSeparators: true,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "issn",
                enabled: true,
                preset: "issn",
                nameFr: "ISSN",
                nameEn: "ISSN",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 8,
                maxLength: 9,
                prefix: "",
                suffix: "",
                allowSeparators: true,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "ean13",
                enabled: true,
                preset: "ean13",
                nameFr: "EAN-13",
                nameEn: "EAN-13",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 13,
                maxLength: 13,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "upca",
                enabled: true,
                preset: "upca",
                nameFr: "UPC-A",
                nameEn: "UPC-A",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 12,
                maxLength: 12,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "ean8",
                enabled: true,
                preset: "ean8",
                nameFr: "EAN-8",
                nameEn: "EAN-8",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 8,
                maxLength: 8,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: true,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "dr-prefix",
                enabled: true,
                preset: "prefix-digits",
                nameFr: "Exemplaire préfixé DR",
                nameEn: "DR-prefixed item barcode",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 11,
                maxLength: 40,
                prefix: "DR",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "numeric-10",
                enabled: true,
                preset: "numeric",
                nameFr: "Exemplaire numérique — 10 chiffres",
                nameEn: "Numeric item barcode — 10 digits",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 10,
                maxLength: 10,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "numeric-14",
                enabled: true,
                preset: "numeric",
                nameFr: "Exemplaire numérique — 14 chiffres",
                nameEn: "Numeric item barcode — 14 digits",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 14,
                maxLength: 14,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "generic-numeric",
                enabled: false,
                preset: "numeric",
                nameFr: "Numérique générique",
                nameEn: "Generic numeric barcode",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 5,
                maxLength: 40,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "generic-alphanumeric",
                enabled: false,
                preset: "alphanumeric",
                nameFr: "Alphanumérique générique",
                nameEn: "Generic alphanumeric barcode",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "",
                minLength: 5,
                maxLength: 64,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "aim-code128",
                enabled: false,
                preset: "any",
                nameFr: "Scanner AIM — famille Code 128",
                nameEn: "AIM scanner — Code 128 family",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "]C*",
                minLength: 1,
                maxLength: 128,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "aim-code39",
                enabled: false,
                preset: "any",
                nameFr: "Scanner AIM — famille Code 39",
                nameEn: "AIM scanner — Code 39 family",
                action: "clear",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "]A*",
                minLength: 1,
                maxLength: 128,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            },
            {
                id: "aim-ean-upc",
                enabled: false,
                preset: "any",
                nameFr: "Scanner AIM — famille EAN / UPC",
                nameEn: "AIM scanner — EAN / UPC family",
                action: "keep",
                indexMode: "any",
                indexValues: "",
                aimIdentifiers: "]E*",
                minLength: 1,
                maxLength: 128,
                prefix: "",
                suffix: "",
                allowSeparators: false,
                validateChecksum: false,
                caseSensitive: false,
                regex: ""
            }
        ],
        test: {
            value: "0000549383",
            index: "bc",
            aimIdentifier: "",
            result: ""
        }
    };

    let currentConfig = deepClone(DEFAULTS);
    let observer = null;
    let clearButtonSyncTimers = [];
    let behaviorRetryTimers = [];

    function deepClone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function isPlainObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) return Array.isArray(override) ? deepClone(override) : deepClone(base);
        if (!isPlainObject(base)) return override === undefined ? deepClone(base) : deepClone(override);
        const out = deepClone(base) || {};
        if (!isPlainObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            const value = override[key];
            if (Array.isArray(value)) out[key] = deepClone(value);
            else if (isPlainObject(value)) out[key] = deepMerge(isPlainObject(out[key]) ? out[key] : {}, value);
            else out[key] = value;
        });
        return out;
    }

    function normalizeConfig(config) {
        const out = deepMerge(DEFAULTS, config || {});
        out.enabled = out.enabled !== false;
        if (!Array.isArray(out.profiles)) out.profiles = deepClone(DEFAULTS.profiles);
        out.profiles = out.profiles.map(normalizeProfile);

        /*
         * Migration des profils historiques déjà enregistrés dans PMK/Firestore.
         * Les tableaux de profils enregistrés remplacent les DEFAULTS : sans cette
         * migration, modifier uniquement DEFAULTS ne corrigerait pas les postes
         * qui ont déjà une configuration sauvegardée.
         */
        const defaultProfilesById = {};
        DEFAULTS.profiles.forEach(function (profile) {
            if (profile && profile.id) defaultProfilesById[profile.id] = profile;
        });

        const drProfile = out.profiles.find(function (profile) {
            return profile && profile.id === "dr-prefix";
        });
        if (drProfile &&
            String(drProfile.prefix || "").toUpperCase() === "DR" &&
            Number(drProfile.minLength) === 12) {
            drProfile.minLength = 11;
        }

        const hasNumeric14 = out.profiles.some(function (profile) {
            return profile && profile.id === "numeric-14";
        });
        if (!hasNumeric14 && defaultProfilesById["numeric-14"]) {
            const numeric14 = normalizeProfile(deepClone(defaultProfilesById["numeric-14"]));
            const numeric10Index = out.profiles.findIndex(function (profile) {
                return profile && profile.id === "numeric-10";
            });
            if (numeric10Index >= 0) out.profiles.splice(numeric10Index + 1, 0, numeric14);
            else out.profiles.push(numeric14);
        }

        if (!isPlainObject(out.test)) out.test = deepClone(DEFAULTS.test);
        return out;
    }

    function normalizeProfile(profile) {
        const p = Object.assign({
            id: "profile-" + Math.random().toString(36).slice(2, 9),
            enabled: true,
            preset: "numeric",
            nameFr: "Nouveau profil",
            nameEn: "New profile",
            action: "clear",
            indexMode: "any",
            indexValues: "",
            aimIdentifiers: "",
            minLength: 1,
            maxLength: 128,
            prefix: "",
            suffix: "",
            allowSeparators: false,
            validateChecksum: false,
            caseSensitive: false,
            regex: ""
        }, profile || {});

        if (["any", "numeric", "alphanumeric", "prefix-digits", "ean8", "ean13", "upca", "isbn10", "isbn13", "issn", "custom-regex"].indexOf(p.preset) === -1) {
            p.preset = "numeric";
        }
        if (["clear", "keep"].indexOf(p.action) === -1) p.action = "clear";
        if (["any", "include", "exclude"].indexOf(p.indexMode) === -1) p.indexMode = "any";
        p.minLength = Math.max(0, Number(p.minLength) || 0);
        p.maxLength = Math.max(p.minLength || 0, Number(p.maxLength) || 128);
        return p;
    }

    function splitRules(value) {
        return String(value || "")
            .split(/[;\n]+/)
            .map(function (item) { return item.trim(); })
            .filter(Boolean);
    }

    function detectAimIdentifier(raw) {
        const value = String(raw || "");
        if (value.length >= 3 && value.charAt(0) === "]" && /^[A-Za-z0-9]{2}$/.test(value.slice(1, 3))) {
            return value.slice(0, 3);
        }
        return "";
    }

    function aimMatches(ruleValue, actualIdentifier) {
        const rules = splitRules(ruleValue);
        if (!rules.length) return true;
        if (!actualIdentifier) return false;
        return rules.some(function (rule) {
            if (rule.endsWith("*")) return actualIdentifier.indexOf(rule.slice(0, -1)) === 0;
            return actualIdentifier === rule;
        });
    }

    function indexMatches(profile, index) {
        const mode = profile.indexMode || "any";
        if (mode === "any") return true;
        const rules = splitRules(profile.indexValues);
        const found = rules.indexOf(String(index || "")) !== -1;
        return mode === "include" ? found : !found;
    }

    function removeAllowedSeparators(value) {
        return String(value || "").replace(/[\s\u00A0\-._]/g, "");
    }

    function compareText(value, expected, caseSensitive, fromEnd) {
        if (!expected) return true;
        let a = String(value || "");
        let b = String(expected || "");
        if (!caseSensitive) {
            a = a.toUpperCase();
            b = b.toUpperCase();
        }
        return fromEnd ? a.endsWith(b) : a.startsWith(b);
    }

    function stripPrefixSuffix(value, profile) {
        let text = String(value || "");
        const prefix = String(profile.prefix || "");
        const suffix = String(profile.suffix || "");
        const caseSensitive = profile.caseSensitive === true;

        if (prefix) {
            if (!compareText(text, prefix, caseSensitive, false)) return null;
            text = text.slice(prefix.length);
        }
        if (suffix) {
            if (!compareText(text, suffix, caseSensitive, true)) return null;
            text = text.slice(0, Math.max(0, text.length - suffix.length));
        }
        return text;
    }

    function validMod10Ean(digits) {
        if (!/^\d+$/.test(digits) || digits.length < 2) return false;
        const body = digits.slice(0, -1);
        const expected = Number(digits.slice(-1));
        let sum = 0;
        for (let i = 0; i < body.length; i += 1) {
            const digit = Number(body.charAt(body.length - 1 - i));
            sum += digit * (i % 2 === 0 ? 3 : 1);
        }
        const check = (10 - (sum % 10)) % 10;
        return check === expected;
    }

    function validIsbn10(value) {
        const compact = removeAllowedSeparators(value).toUpperCase();
        if (!/^\d{9}[\dX]$/.test(compact)) return false;
        let sum = 0;
        for (let i = 0; i < 10; i += 1) {
            const char = compact.charAt(i);
            const digit = char === "X" ? 10 : Number(char);
            sum += digit * (10 - i);
        }
        return sum % 11 === 0;
    }

    function validIssn(value) {
        const compact = removeAllowedSeparators(value).toUpperCase();
        if (!/^\d{7}[\dX]$/.test(compact)) return false;
        let sum = 0;
        for (let i = 0; i < 8; i += 1) {
            const char = compact.charAt(i);
            const digit = char === "X" ? 10 : Number(char);
            sum += digit * (8 - i);
        }
        return sum % 11 === 0;
    }

    function standardValue(rawValue, profile) {
        let value = String(rawValue || "");
        if (profile.allowSeparators === true || ["isbn10", "isbn13", "issn"].indexOf(profile.preset) !== -1) {
            value = removeAllowedSeparators(value);
        }
        return value;
    }

    function lengthMatches(value, profile) {
        const len = String(value || "").length;
        return len >= Number(profile.minLength || 0) && len <= Number(profile.maxLength || 128);
    }

    function matchPreset(value, profile) {
        const preset = profile.preset;
        const caseSensitive = profile.caseSensitive === true;
        const stripped = stripPrefixSuffix(value, profile);
        if (stripped === null) return false;

        if (!lengthMatches(value, profile)) return false;

        if (preset === "any") {
            return stripped.length > 0;
        }

        if (preset === "numeric") {
            return /^\d+$/.test(stripped);
        }

        if (preset === "alphanumeric") {
            return /^[A-Za-z0-9]+$/.test(stripped);
        }

        if (preset === "prefix-digits") {
            if (!String(profile.prefix || "")) return false;
            return /^\d+$/.test(stripped);
        }

        if (preset === "custom-regex") {
            const source = String(profile.regex || "");
            if (!source) return false;
            try {
                return new RegExp(source, caseSensitive ? "" : "i").test(value);
            } catch (_) {
                return false;
            }
        }

        const compact = standardValue(value, profile).toUpperCase();

        if (preset === "ean8") {
            return /^\d{8}$/.test(compact) &&
                (profile.validateChecksum === false || validMod10Ean(compact));
        }

        if (preset === "ean13") {
            return /^\d{13}$/.test(compact) &&
                (profile.validateChecksum === false || validMod10Ean(compact));
        }

        if (preset === "upca") {
            return /^\d{12}$/.test(compact) &&
                (profile.validateChecksum === false || validMod10Ean(compact));
        }

        if (preset === "isbn13") {
            return /^97[89]\d{10}$/.test(compact) &&
                (profile.validateChecksum === false || validMod10Ean(compact));
        }

        if (preset === "isbn10") {
            return /^\d{9}[\dX]$/.test(compact) &&
                (profile.validateChecksum === false || validIsbn10(compact));
        }

        if (preset === "issn") {
            return /^\d{7}[\dX]$/.test(compact) &&
                (profile.validateChecksum === false || validIssn(compact));
        }

        return false;
    }

    function evaluateValue(value, index, explicitAimIdentifier, config) {
        const cfg = normalizeConfig(config || currentConfig);
        let raw = value == null ? "" : String(value);
        if (cfg.scanner.trimOuterSpaces !== false) raw = raw.trim();
        if (!raw) return { matched: false, value: raw, index: String(index || ""), aimIdentifier: "" };

        const detectedAim = cfg.scanner.detectAimIdentifier !== false ? detectAimIdentifier(raw) : "";
        const aimIdentifier = String(explicitAimIdentifier || detectedAim || "");
        let valueForMatch = raw;

        if (cfg.scanner.stripAimIdentifierBeforeMatch !== false && detectedAim) {
            valueForMatch = raw.slice(detectedAim.length);
        }

        /*
         * Priorité réseau initiale :
         * les codes-barres exemplaires internes suivent le format 0000 + 6 chiffres.
         * Cette signature est suffisamment spécifique pour être reconnue avant
         * ISBN/EAN et indépendamment de l'index Koha mémorisé.
         *
         * Exemples :
         *   0000544086
         *   0000549383
         *   0000641894
         *
         * On s'appuie toujours sur le profil "numeric-10" afin de respecter son
         * activation et son action configurée dans PMK, mais on ignore volontairement
         * son filtre d'index pour cette signature réseau : un ancien index "nb"
         * conservé dans localStorage ne doit pas empêcher l'effacement du code-barres.
         */
        const normalizedIndex = String(index || "").trim().toLowerCase();

        /*
         * Formats exemplaires observés sur le réseau :
         * - 0000 + 6 chiffres : ex. 0000596498
         * - 14 chiffres       : ex. 00000000000001 / 00000000000002
         * - DR + chiffres     : ex. DR100002740
         *
         * Ces signatures sont prioritaires sur les formats bibliographiques.
         */
        let priorityProfileId = "";
        if (/^0000\d{6}$/.test(valueForMatch)) priorityProfileId = "numeric-10";
        else if (/^\d{14}$/.test(valueForMatch)) priorityProfileId = "numeric-14";
        else if (/^DR\d{9,}$/i.test(valueForMatch)) priorityProfileId = "dr-prefix";

        if (priorityProfileId && cfg.scanner.preferHistoricalSignatures !== false) {
            for (let i = 0; i < cfg.profiles.length; i += 1) {
                const profile = normalizeProfile(cfg.profiles[i]);
                if (profile.id !== priorityProfileId) continue;
                if (profile.enabled === false) continue;
                if (!aimMatches(profile.aimIdentifiers, aimIdentifier)) continue;
                if (!matchPreset(valueForMatch, profile)) continue;

                return {
                    matched: true,
                    profile: deepClone(profile),
                    profileIndex: i,
                    action: profile.action,
                    value: raw,
                    normalizedValue: valueForMatch,
                    index: String(index || ""),
                    aimIdentifier: aimIdentifier
                };
            }
        }

        /*
         * Pour les autres valeurs numériques de 10 chiffres, conserver l'arbitrage
         * précédent : priorité au profil exemplaire sauf lorsqu'une recherche ISBN
         * est explicitement portée par l'index Koha "nb".
         */
        if (cfg.scanner.preferHistoricalSignatures !== false && normalizedIndex !== "nb" && /^\d{10}$/.test(valueForMatch)) {
            for (let i = 0; i < cfg.profiles.length; i += 1) {
                const profile = normalizeProfile(cfg.profiles[i]);
                if (profile.id !== "numeric-10") continue;
                if (profile.enabled === false) continue;
                if (!indexMatches(profile, index)) continue;
                if (!aimMatches(profile.aimIdentifiers, aimIdentifier)) continue;
                if (!matchPreset(valueForMatch, profile)) continue;

                return {
                    matched: true,
                    profile: deepClone(profile),
                    profileIndex: i,
                    action: profile.action,
                    value: raw,
                    normalizedValue: valueForMatch,
                    index: String(index || ""),
                    aimIdentifier: aimIdentifier
                };
            }
        }

        for (let i = 0; i < cfg.profiles.length; i += 1) {
            const profile = normalizeProfile(cfg.profiles[i]);
            if (profile.enabled === false) continue;

            // Une recherche explicitement lancée sur l'index ISBN ne doit jamais
            // être captée par le profil exemplaire numérique 10 chiffres.
            if (cfg.scanner.preferHistoricalSignatures !== false && profile.id === "numeric-10" && normalizedIndex === "nb") continue;

            if (!indexMatches(profile, index)) continue;
            if (!aimMatches(profile.aimIdentifiers, aimIdentifier)) continue;
            if (!matchPreset(valueForMatch, profile)) continue;

            return {
                matched: true,
                profile: deepClone(profile),
                profileIndex: i,
                action: profile.action,
                value: raw,
                normalizedValue: valueForMatch,
                index: String(index || ""),
                aimIdentifier: aimIdentifier
            };
        }

        return {
            matched: false,
            value: raw,
            normalizedValue: valueForMatch,
            index: String(index || ""),
            aimIdentifier: aimIdentifier
        };
    }

    function inspectValue(value, index, aimIdentifier, config) {
        const cfg = normalizeConfig(config || currentConfig);
        const result = evaluateValue(value, index, aimIdentifier, cfg);
        const matches = cfg.profiles.map(function (profile, profileIndex) {
            const candidate = evaluateValue(value, index, aimIdentifier, Object.assign({}, cfg, { profiles: [profile] }));
            return candidate.matched ? { profile: candidate.profile, profileIndex: profileIndex, action: candidate.action } : null;
        }).filter(Boolean);
        return Object.assign({}, result, {
            matches: matches,
            ambiguous: matches.some(function (candidate) { return result.matched && candidate.action !== result.action; }),
            historicalPriority: cfg.scanner.preferHistoricalSignatures !== false && result.matched && matches.length > 0 && result.profileIndex !== matches[0].profileIndex
        });
    }

    function profileLabel(profile, lang) {
        if (!profile) return "";
        const preferred = lang === "en" ? profile.nameEn : profile.nameFr;
        return String(preferred || profile.nameFr || profile.nameEn || profile.id || "").trim();
    }

    function resultText(result, lang) {
        if (!result || !result.matched) {
            return lang === "en"
                ? "No active profile recognized this value."
                : "Aucun profil actif ne reconnaît cette valeur.";
        }
        const action = result.action === "clear"
            ? (lang === "en" ? "clear the visible search bar" : "vider la barre visible")
            : (lang === "en" ? "keep the visible search" : "conserver la recherche visible");
        const aim = result.aimIdentifier ? " · AIM " + result.aimIdentifier : "";
        const index = result.index ? " · index " + result.index : "";
        const alternatives = (result.matches || []).filter(function (candidate) { return candidate.profileIndex !== result.profileIndex; });
        const detail = alternatives.length ? (lang === "en" ? " · Also matches: " : " · Correspond aussi à : ") + alternatives.map(function (candidate) { return profileLabel(candidate.profile, lang); }).join(", ") : "";
        const conflict = result.ambiguous ? (lang === "en" ? " · Conflicting actions: check profile order or historical priority." : " · Actions différentes : vérifiez l’ordre des profils ou la priorité historique.") : "";
        return (lang === "en" ? "Recognized: " : "Reconnu : ") +
            profileLabel(result.profile, lang) +
            " · " + action + index + aim + detail + conflict;
    }

    function safeStorageGet(key) {
        try {
            return window.localStorage ? window.localStorage.getItem(key) : null;
        } catch (_) {
            return null;
        }
    }

    function getStoredContext() {
        return {
            value: safeStorageGet("searchbox_value") || "",
            index: safeStorageGet("cat_search_pulldown_selection") || "",
            source: "localStorage"
        };
    }

    function getUrlSearchContext() {
        try {
            const params = new URLSearchParams(window.location.search || "");
            const value = params.get("q") || params.get("q_0") || "";
            const index = params.get("idx") || params.get("idx_0") || "";
            return {
                value: String(value || ""),
                index: String(index || ""),
                source: "url"
            };
        } catch (_) {
            return { value: "", index: "", source: "url" };
        }
    }

    function getSearchContext() {
        const stored = getStoredContext();
        if (String(stored.value || "").trim()) return stored;

        const fromUrl = getUrlSearchContext();
        if (String(fromUrl.value || "").trim()) return fromUrl;

        return stored;
    }

    function findSearchInput() {
        try {
            return document.querySelector(currentConfig.scope.targetSelector || TARGET_SELECTOR);
        } catch (_) {
            return document.querySelector(TARGET_SELECTOR);
        }
    }

    function fieldValueMatchesStored(input, storedValue) {
        if (!input || typeof input.value !== "string") return true;
        const current = input.value.trim();
        if (!current) return true;
        const stored = String(storedValue || "").trim();
        if (!stored) return false;
        if (current === stored) return true;

        const currentAim = detectAimIdentifier(current);
        const storedAim = detectAimIdentifier(stored);
        const currentBare = currentAim ? current.slice(currentAim.length) : current;
        const storedBare = storedAim ? stored.slice(storedAim.length) : stored;
        return currentBare === storedBare;
    }

    function interfaceLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try {
                const value = String(window.PMKConfig.getLanguage() || "").toLowerCase();
                if (value.indexOf("en") === 0) return "en";
                if (value.indexOf("fr") === 0) return "fr";
            } catch (_) {}
        }
        const htmlLang = String(document.documentElement && document.documentElement.lang || "").toLowerCase();
        return htmlLang.indexOf("en") === 0 ? "en" : "fr";
    }

    function clearButtonLabel() {
        const cfg = currentConfig && currentConfig.clearButton || {};
        const fr = String(cfg.labelFr || DEFAULTS.clearButton.labelFr || "Effacer la recherche").trim();
        const en = String(cfg.labelEn || DEFAULTS.clearButton.labelEn || "Clear search").trim();
        return interfaceLanguage() === "en" ? (en || fr) : (fr || en);
    }

    function injectClearButtonStyle() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
#cat-search-block .pmk036-clear-search {
    align-items: center;
    align-self: stretch;
    background: transparent;
    border: 0;
    border-left: 1px solid var(--bs-border-color, #e0e0e0);
    box-shadow: none;
    color: inherit;
    cursor: pointer;
    display: inline-flex;
    flex: 0 0 31px;
    height: 31px;
    justify-content: center;
    margin: 0;
    min-width: 31px;
    opacity: .42;
    padding: 0;
    position: relative;
    text-shadow: none;
    transition: opacity .12s ease, background-color .12s ease;
}
#cat-search-block .pmk036-clear-search:hover,
#cat-search-block .pmk036-clear-search:focus {
    background: rgba(0, 0, 0, .035);
    opacity: .9;
}
#cat-search-block .pmk036-clear-search:focus-visible {
    outline: 2px solid currentColor;
    outline-offset: -4px;
}
#cat-search-block .pmk036-clear-search i {
    font-size: .82rem;
    line-height: 1;
    margin: 0;
    pointer-events: none;
}
#cat-search-block .pmk036-clear-search[hidden] {
    display: none !important;
}
@media (prefers-reduced-motion: reduce) {
    #cat-search-block .pmk036-clear-search {
        transition: none;
    }
}
`;
        (document.head || document.documentElement).appendChild(style);
    }

    function clearButtonVisible(input) {
        return Boolean(input && typeof input.value === "string" && input.value.trim() !== "");
    }

    function syncClearButton(input, button) {
        if (!input || !button || !button.isConnected) return;
        const label = clearButtonLabel();
        button.hidden = !clearButtonVisible(input);
        button.setAttribute("aria-label", label);
        button.setAttribute("title", label);
    }

    function cancelClearButtonSyncTimers() {
        clearButtonSyncTimers.forEach(function (id) {
            try { window.clearTimeout(id); } catch (_) {}
        });
        clearButtonSyncTimers = [];
    }

    function cancelBehaviorRetryTimers() {
        behaviorRetryTimers.forEach(function (id) {
            try { window.clearTimeout(id); } catch (_) {}
        });
        behaviorRetryTimers = [];
    }

    function removeClearButtons() {
        cancelClearButtonSyncTimers();
        document.querySelectorAll("[" + CLEAR_BUTTON_ATTR + "]").forEach(function (button) {
            try {
                const input = button.__pmk036Input;
                const handler = button.__pmk036SyncHandler;
                if (input && handler) {
                    input.removeEventListener("input", handler);
                    input.removeEventListener("change", handler);
                }
                button.remove();
            } catch (_) {}
        });
    }

    function clearVisibleSearch(input, options) {
        if (!input || typeof input.value !== "string") return false;
        const opts = options && typeof options === "object" ? options : {};

        /*
         * Vider à la fois la valeur courante et la valeur HTML par défaut.
         * Koha (ou un reset du formulaire) ne doit pas pouvoir restaurer
         * immédiatement la valeur affichée après notre nettoyage.
         *
         * Le localStorage Koha searchbox_value n'est PAS modifié : le contexte
         * de la dernière recherche reste donc disponible pour les autres modules.
         */
        input.value = "";
        try { input.defaultValue = ""; } catch (_) {}
        try { input.setAttribute("value", ""); } catch (_) {}

        /*
         * Pour l'effacement automatique après reconnaissance d'un code-barres,
         * ne pas émettre input/change : certains gestionnaires Koha ou scripts
         * tiers peuvent réagir à ces événements et restaurer la dernière valeur.
         * Le bouton manuel conserve le comportement configuré.
         */
        const dispatchEvents = opts.dispatchEvents !== false;

        if (dispatchEvents && currentConfig.behavior.dispatchInputEvent !== false) {
            try { input.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
        }
        if (dispatchEvents && currentConfig.behavior.dispatchChangeEvent === true) {
            try { input.dispatchEvent(new Event("change", { bubbles: true })); } catch (_) {}
        }

        const shouldFocus = opts.focus === true || currentConfig.behavior.focusAfterClear === true;
        if (shouldFocus && typeof input.focus === "function") {
            try { input.focus({ preventScroll: true }); } catch (_) {
                try { input.focus(); } catch (_) {}
            }
        }
        return input.value === "";
    }

    function ensureClearButton(input) {
        const target = input || findSearchInput();
        if (!currentConfig.enabled || !currentConfig.clearButton || currentConfig.clearButton.enabled === false) {
            removeClearButtons();
            return null;
        }
        if (!target) return null;

        let form = null;
        try {
            form = target.closest(currentConfig.scope.formSelector || FORM_SELECTOR);
        } catch (_) {
            form = target.closest(FORM_SELECTOR);
        }
        const container = target.closest(".form-content");
        if (!form || !container || !form.contains(target)) return null;

        injectClearButtonStyle();

        let button = container.querySelector("[" + CLEAR_BUTTON_ATTR + "]");
        if (!button) {
            button = document.createElement("button");
            button.type = "button";
            button.className = "pmk036-clear-search";
            button.setAttribute(CLEAR_BUTTON_ATTR, "1");

            const icon = document.createElement("i");
            icon.className = "fa-solid fa-xmark";
            icon.setAttribute("aria-hidden", "true");
            button.appendChild(icon);

            const sync = function () { syncClearButton(target, button); };
            button.__pmk036Input = target;
            button.__pmk036SyncHandler = sync;

            button.addEventListener("click", function (event) {
                event.preventDefault();
                clearVisibleSearch(target, { focus: true, source: "manual-button" });
                sync();
            });
            target.addEventListener("input", sync);
            target.addEventListener("change", sync);

            target.insertAdjacentElement("afterend", button);
        }

        syncClearButton(target, button);
        cancelClearButtonSyncTimers();
        [0, 120, 500].forEach(function (delay) {
            clearButtonSyncTimers.push(window.setTimeout(function () {
                syncClearButton(target, button);
            }, delay));
        });
        return button;
    }

    function dispatchRecognition(result) {
        if (!result || !result.matched) return;
        try {
            window.dispatchEvent(new CustomEvent("pmk:catalogue-search-recognized", {
                detail: {
                    moduleId: MODULE_ID,
                    profileId: result.profile && result.profile.id,
                    action: result.action,
                    index: result.index,
                    aimIdentifier: result.aimIdentifier
                }
            }));
        } catch (_) {}
    }

    function applyBehavior() {
        if (!currentConfig.enabled) return { applied: false, reason: "disabled" };

        const input = findSearchInput();
        if (!input) return { applied: false, reason: "no-search-input" };

        const context = getSearchContext();
        if (!context.value) return { applied: false, reason: "no-search-context" };

        const result = evaluateValue(context.value, context.index, "", currentConfig);
        if (!result.matched) return { applied: false, reason: "not-recognized", result: result };

        dispatchRecognition(result);

        if (result.action !== currentConfig.behavior.clearOnAction) {
            return { applied: true, cleared: false, result: result };
        }

        if (currentConfig.behavior.onlyIfCurrentEmptyOrMatchesStored !== false &&
            !fieldValueMatchesStored(input, context.value)) {
            return { applied: true, cleared: false, protectedCurrentValue: true, result: result };
        }

        const cleared = clearVisibleSearch(input, {
            dispatchEvents: false,
            source: "automatic-barcode"
        });
        return { applied: true, cleared: cleared, result: result };
    }

    function scheduleBehaviorRetries(input) {
        cancelBehaviorRetryTimers();

        /*
         * Koha peut restaurer la valeur de la barre après DOMContentLoaded.
         * On rejoue donc le comportement pendant une courte fenêtre.
         * fieldValueMatchesStored() protège une éventuelle nouvelle saisie :
         * une valeur différente de la recherche mémorisée ne sera pas effacée.
         */
        [60, 180, 450, 900, 1600].forEach(function (delay) {
            behaviorRetryTimers.push(window.setTimeout(function () {
                const target = input && input.isConnected ? input : findSearchInput();
                if (!target) return;
                applyBehavior();
                ensureClearButton(target);
            }, delay));
        });
    }

    function stopObserver() {
        if (observer) {
            try { observer.disconnect(); } catch (_) {}
            observer = null;
        }
    }

    function ensureRuntime() {
        stopObserver();
        if (!currentConfig.enabled) {
            removeClearButtons();
            return;
        }

        const input = findSearchInput();
        if (input) {
            applyBehavior();
            ensureClearButton(input);
            scheduleBehaviorRetries(input);
            return;
        }

        observer = new MutationObserver(function () {
            const found = findSearchInput();
            if (!found) return;
            applyBehavior();
            ensureClearButton(found);
            scheduleBehaviorRetries(found);
            mountContextAccess();
            stopObserver();
        });
        try {
            observer.observe(document.documentElement, { childList: true, subtree: true });
        } catch (_) {
            stopObserver();
        }
    }

    function mountContextAccess() {
        if (!currentConfig.enabled) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const input = findSearchInput();
        const anchor = input && (input.closest(".form-content") || input.parentElement);
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: CONTEXT_KEY,
                context: { sectionId: "profiles" }
            });
        } catch (_) {}
    }

    function presetPatch(preset) {
        const common = {
            prefix: "",
            suffix: "",
            regex: "",
            aimIdentifiers: "",
            caseSensitive: false
        };
        const patches = {
            any: Object.assign({}, common, { minLength: 1, maxLength: 128, allowSeparators: false, validateChecksum: false }),
            numeric: Object.assign({}, common, { minLength: 5, maxLength: 40, allowSeparators: false, validateChecksum: false }),
            alphanumeric: Object.assign({}, common, { minLength: 5, maxLength: 64, allowSeparators: false, validateChecksum: false }),
            "prefix-digits": Object.assign({}, common, { minLength: 11, maxLength: 40, prefix: "DR", allowSeparators: false, validateChecksum: false }),
            ean8: Object.assign({}, common, { minLength: 8, maxLength: 8, allowSeparators: false, validateChecksum: true }),
            ean13: Object.assign({}, common, { minLength: 13, maxLength: 13, allowSeparators: false, validateChecksum: true }),
            upca: Object.assign({}, common, { minLength: 12, maxLength: 12, allowSeparators: false, validateChecksum: true }),
            isbn10: Object.assign({}, common, { minLength: 10, maxLength: 13, allowSeparators: true, validateChecksum: true }),
            isbn13: Object.assign({}, common, { minLength: 13, maxLength: 17, allowSeparators: true, validateChecksum: true }),
            issn: Object.assign({}, common, { minLength: 8, maxLength: 9, allowSeparators: true, validateChecksum: true }),
            "custom-regex": Object.assign({}, common, { minLength: 1, maxLength: 128, regex: "^.+$", allowSeparators: false, validateChecksum: false })
        };
        return patches[preset] || patches.numeric;
    }

    function newProfile() {
        return {
            id: "custom-" + Date.now().toString(36),
            enabled: true,
            preset: "numeric",
            nameFr: "Nouveau profil",
            nameEn: "New profile",
            action: "clear",
            indexMode: "any",
            indexValues: "",
            aimIdentifiers: "",
            minLength: 5,
            maxLength: 40,
            prefix: "",
            suffix: "",
            allowSeparators: false,
            validateChecksum: false,
            caseSensitive: false,
            regex: ""
        };
    }

    function updateTestResult(rootObject) {
        if (!rootObject || !rootObject.test) return;
        const lang = window.PMKConfig && typeof window.PMKConfig.getLanguage === "function"
            ? window.PMKConfig.getLanguage()
            : "fr";
        rootObject.test.result = resultText(
            inspectValue(
                rootObject.test.value,
                rootObject.test.index,
                rootObject.test.aimIdentifier,
                rootObject
            ),
            lang
        );
    }

    function validateConfig(config) {
        const lang = window.PMKConfig && typeof window.PMKConfig.getLanguage === "function"
            ? window.PMKConfig.getLanguage()
            : "fr";
        const fail = function (fr, en) {
            return { ok: false, message: lang === "en" ? en : fr };
        };

        const cfg = normalizeConfig(config);
        if (!Array.isArray(cfg.profiles) || !cfg.profiles.length) {
            return fail("Le 036 doit conserver au moins un profil de reconnaissance.", "Module 036 must keep at least one recognition profile.");
        }

        const ids = new Set();
        for (let i = 0; i < cfg.profiles.length; i += 1) {
            const p = cfg.profiles[i];
            if (!p || p.enabled === false) continue;
            const id = String(p.id || "").trim();
            if (!id) return fail("Un profil actif n'a pas d'identifiant.", "An enabled profile has no identifier.");
            if (ids.has(id)) return fail("Deux profils utilisent le même identifiant : " + id, "Two profiles use the same identifier: " + id);
            ids.add(id);

            if (p.maxLength < p.minLength) {
                return fail("La longueur maximale d'un profil est inférieure à sa longueur minimale.", "A profile maximum length is lower than its minimum length.");
            }

            if (p.preset === "prefix-digits" && !String(p.prefix || "")) {
                return fail("Un profil « préfixe + chiffres » doit définir un préfixe.", "A prefix + digits profile must define a prefix.");
            }

            if (p.preset === "custom-regex") {
                if (!String(p.regex || "")) return fail("Un profil regex actif doit contenir une expression.", "An enabled regex profile must contain an expression.");
                try { new RegExp(p.regex, p.caseSensitive === true ? "" : "i"); } catch (_) {
                    return fail("Expression régulière invalide dans le profil : " + profileLabel(p, "fr"), "Invalid regular expression in profile: " + profileLabel(p, "en"));
                }
            }
        }

        return { ok: true };
    }

    function buildModuleDefinition() {
        const presetOptions = [
            { value: "any", label: { fr: "Toute valeur non vide", en: "Any non-empty value" } },
            { value: "numeric", label: { fr: "Numérique", en: "Numeric" } },
            { value: "alphanumeric", label: { fr: "Alphanumérique", en: "Alphanumeric" } },
            { value: "prefix-digits", label: { fr: "Préfixe + chiffres", en: "Prefix + digits" } },
            { value: "ean8", label: { fr: "EAN-8", en: "EAN-8" } },
            { value: "ean13", label: { fr: "EAN-13", en: "EAN-13" } },
            { value: "upca", label: { fr: "UPC-A", en: "UPC-A" } },
            { value: "isbn10", label: { fr: "ISBN-10", en: "ISBN-10" } },
            { value: "isbn13", label: { fr: "ISBN-13", en: "ISBN-13" } },
            { value: "issn", label: { fr: "ISSN", en: "ISSN" } },
            { value: "custom-regex", label: { fr: "Expression régulière personnalisée", en: "Custom regular expression" } }
        ];

        return {
            id: MODULE_ID,
            schemaVersion: 3,
            name: { fr: "Barre de recherche catalogue", en: "Catalogue search bar" },
            description: {
                fr: "Pilote la barre de recherche catalogue : reconnaissance des codes-barres, nettoyage automatique sécurisé et bouton d'effacement manuel intégré. La dernière recherche Koha reste conservée pour les autres modules.",
                en: "Controls the catalogue search bar: barcode recognition, safe automatic clearing and an integrated manual clear button. Koha's last-search context remains available to other modules."
            },
            category: { fr: "Catalogue / recherche", en: "Catalogue / search" },
            supportedPages: ["Toutes les pages contenant #cat-search-block #search-form"],
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULTS),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation et portée", en: "Activation and scope" },
                    description: {
                        fr: "Le module ne touche qu'à la barre « Recherche catalogue ». Les champs de prêt, retour, lecteur, renouvellement et Z39.50 ne sont pas concernés.",
                        en: "The module only targets the Catalogue search bar. Checkout, check-in, patron, renewal and Z39.50 fields are not affected."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        { key: "scope.targetSelector", type: "text", advanced: true, label: { fr: "Cible de la barre catalogue", en: "Catalogue search target" } },
                        { key: "scope.formSelector", type: "text", advanced: true, label: { fr: "Formulaire catalogue", en: "Catalogue form" } }
                    ]
                },
                {
                    type: "section",
                    id: "profiles",
                    label: { fr: "Profils de codes-barres", en: "Barcode profiles" },
                    description: {
                        fr: "Le premier profil correspondant décide de l’action, sauf si la priorité initiale est active. Le test signale les formats concurrents ; désactivez cette priorité pour respecter strictement votre ordre.",
                        en: "The first matching profile decides the action, unless original priority is active. The test shows competing formats; disable this priority to strictly follow your order."
                    },
                    fields: [
                        {key:"scanner.preferHistoricalSignatures",type:"boolean",label:{fr:"Priorité aux formats initiaux",en:"Prefer original formats"},description:{fr:"Activée par défaut : formats 0000 + 6 chiffres, 14 chiffres, DR + chiffres et arbitrage numérique/ISBN. Désactivez pour appliquer uniquement l’ordre et les index de vos profils.",en:"Enabled by default: 0000 + 6 digits, 14 digits, DR + digits and numeric/ISBN arbitration. Disable to use only your profile order and indexes."}},
                        {
                            key: "profiles",
                            type: "repeater",
                            label: { fr: "Profils actifs et disponibles", en: "Active and available profiles" },
                            addLabel: { fr: "Ajouter un type de code-barres", en: "Add barcode type" },
                            reorder: true,
                            newItem: newProfile,
                            itemTitle: function (item, index, lang) {
                                return profileLabel(item, lang) || "Profil " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Profil actif", en: "Profile enabled" } },
                                { key: "nameFr", type: "text", label: { fr: "Nom français", en: "French name" } },
                                { key: "nameEn", type: "text", label: { fr: "Nom anglais", en: "English name" } },
                                {
                                    key: "action",
                                    type: "select",
                                    label: { fr: "Après reconnaissance", en: "After recognition" },
                                    options: [
                                        { value: "clear", label: { fr: "Vider la barre visible", en: "Clear the visible search bar" } },
                                        { value: "keep", label: { fr: "Conserver la recherche visible", en: "Keep the visible search" } }
                                    ]
                                },
                                {
                                    key: "preset",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Type de reconnaissance", en: "Recognition type" },
                                    options: presetOptions,
                                    onChange: function (rootObject, fieldPath, value) {
                                        const index = fieldPath[fieldPath.length - 2];
                                        if (!Array.isArray(rootObject.profiles) || !rootObject.profiles[index]) return;
                                        Object.assign(rootObject.profiles[index], presetPatch(value));
                                    }
                                },
                                { key: "minLength", type: "number", label: { fr: "Longueur minimale", en: "Minimum length" } },
                                { key: "maxLength", type: "number", label: { fr: "Longueur maximale", en: "Maximum length" } },
                                { key: "prefix", type: "text", label: { fr: "Préfixe requis", en: "Required prefix" } },
                                { key: "suffix", type: "text", label: { fr: "Suffixe requis", en: "Required suffix" } },
                                { key: "allowSeparators", type: "boolean", label: { fr: "Tolérer espaces / tirets / points dans les standards", en: "Allow spaces / hyphens / dots in standards" } },
                                { key: "validateChecksum", type: "boolean", label: { fr: "Vérifier la clé de contrôle quand le standard le permet", en: "Validate check digit when supported" } },
                                { key: "caseSensitive", type: "boolean", advanced: true, label: { fr: "Respecter la casse", en: "Case sensitive" } },
                                {
                                    key: "indexMode",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Filtre sur l'index Koha", en: "Koha index filter" },
                                    options: [
                                        { value: "any", label: { fr: "Tous les index", en: "Any index" } },
                                        { value: "include", label: { fr: "Seulement les index indiqués", en: "Only listed indexes" } },
                                        { value: "exclude", label: { fr: "Tous sauf les index indiqués", en: "All except listed indexes" } }
                                    ]
                                },
                                {
                                    key: "indexValues",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Index Koha techniques", en: "Technical Koha indexes" },
                                    help: {
                                        fr: "Séparer plusieurs valeurs par « ; ». Exemples Koha : bc = code-barres, nb = ISBN, ns = ISSN. Les valeurs comme kw,phr restent possibles.",
                                        en: "Separate multiple values with ';'. Koha examples: bc = barcode, nb = ISBN, ns = ISSN. Values such as kw,phr are supported."
                                    }
                                },
                                {
                                    key: "aimIdentifiers",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Identifiants AIM du scanner", en: "Scanner AIM identifiers" },
                                    help: {
                                        fr: "Optionnel. Séparer par « ; ». Le joker final * est accepté, ex. ]C* pour une famille AIM. Nécessite un scanner configuré pour transmettre cet identifiant.",
                                        en: "Optional. Separate with ';'. A trailing * wildcard is supported, e.g. ]C* for an AIM family. Requires a scanner configured to transmit the identifier."
                                    }
                                },
                                {
                                    key: "regex",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Expression régulière personnalisée", en: "Custom regular expression" },
                                    help: {
                                        fr: "Utilisée uniquement avec le type « Expression régulière personnalisée ». Exemple : ^ABC\\d{8}$",
                                        en: "Used only with the Custom regular expression type. Example: ^ABC\\d{8}$"
                                    }
                                },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant interne", en: "Internal identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "scanner",
                    label: { fr: "Scanner et lecture", en: "Scanner and input" },
                    fields: [
                        { key: "scanner.trimOuterSpaces", type: "boolean", label: { fr: "Ignorer les espaces au début et à la fin", en: "Ignore leading/trailing spaces" } },
                        { key: "scanner.detectAimIdentifier", type: "boolean", label: { fr: "Détecter les identifiants de symbologie AIM", en: "Detect AIM symbology identifiers" } },
                        { key: "scanner.stripAimIdentifierBeforeMatch", type: "boolean", label: { fr: "Retirer l'identifiant AIM avant de tester la valeur", en: "Strip AIM identifier before matching the value" } }
                    ]
                },
                {
                    type: "section",
                    id: "clear-button",
                    label: { fr: "Bouton d'effacement manuel", en: "Manual clear button" },
                    description: {
                        fr: "Fonction issue de l'ancien 053. Une icône discrète apparaît dans la barre uniquement lorsqu'elle contient du texte. Le clic vide la barre visible, conserve searchbox_value et remet immédiatement le focus dans le champ.",
                        en: "Function inherited from former module 053. A discreet icon appears inside the bar only when it contains text. Clicking clears the visible field, preserves searchbox_value and immediately restores focus to the input."
                    },
                    fields: [
                        { key: "clearButton.enabled", type: "boolean", label: { fr: "Afficher le bouton d'effacement", en: "Show the clear button" } },
                        { key: "clearButton.labelFr", type: "text", advanced: true, label: { fr: "Info-bulle / libellé accessible FR", en: "French tooltip / accessible label" } },
                        { key: "clearButton.labelEn", type: "text", advanced: true, label: { fr: "Info-bulle / libellé accessible EN", en: "English tooltip / accessible label" } }
                    ]
                },
                {
                    type: "section",
                    id: "behavior",
                    label: { fr: "Comportement après reconnaissance", en: "Behavior after recognition" },
                    description: {
                        fr: "Le contexte Koha searchbox_value est toujours conservé : seul l'affichage de la barre est éventuellement vidé. Cela protège les modules qui utilisent la dernière recherche.",
                        en: "Koha's searchbox_value context is always preserved: only the visible search bar may be cleared. This protects modules that use the last search."
                    },
                    fields: [
                        { key: "behavior.onlyIfCurrentEmptyOrMatchesStored", type: "boolean", label: { fr: "Ne jamais effacer une nouvelle saisie différente", en: "Never clear a different new value" } },
                        { key: "behavior.dispatchInputEvent", type: "boolean", advanced: true, label: { fr: "Émettre l'événement input après effacement", en: "Dispatch input event after clearing" } },
                        { key: "behavior.dispatchChangeEvent", type: "boolean", advanced: true, label: { fr: "Émettre aussi l'événement change", en: "Also dispatch change event" } },
                        { key: "behavior.focusAfterClear", type: "boolean", label: { fr: "Remettre le focus dans la barre après effacement", en: "Focus the search bar after clearing" } }
                    ]
                },
                {
                    type: "section",
                    id: "test",
                    label: { fr: "Tester un code", en: "Test a code" },
                    description: {
                        fr: "Saisissez ou scannez une valeur. Le test utilise les profils dans leur ordre actuel et n'effectue aucune recherche Koha.",
                        en: "Enter or scan a value. The test uses profiles in their current order and does not run a Koha search."
                    },
                    fields: [
                        {
                            key: "test.value",
                            type: "text",
                            refreshOnChange: true,
                            label: { fr: "Valeur à tester", en: "Value to test" },
                            onChange: function (rootObject) { updateTestResult(rootObject); }
                        },
                        {
                            key: "test.index",
                            type: "text",
                            refreshOnChange: true,
                            label: { fr: "Index Koha simulé", en: "Simulated Koha index" },
                            help: { fr: "Exemples : bc, nb, ns, kw.", en: "Examples: bc, nb, ns, kw." },
                            onChange: function (rootObject) { updateTestResult(rootObject); }
                        },
                        {
                            key: "test.aimIdentifier",
                            type: "text",
                            refreshOnChange: true,
                            label: { fr: "Identifiant AIM simulé", en: "Simulated AIM identifier" },
                            help: { fr: "Laisser vide si le scanner n'envoie pas d'identifiant AIM.", en: "Leave blank if the scanner does not send an AIM identifier." },
                            onChange: function (rootObject) { updateTestResult(rootObject); }
                        },
                        {
                            key: "test.result",
                            type: "text",
                            readOnly: true,
                            label: { fr: "Résultat", en: "Result" }
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "profiles";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') ||
                    main.querySelector('[data-pmk-section-id="profiles"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return;
        try { window.PMKConfig.registerModule(buildModuleDefinition()); } catch (_) {}
    }

    function loadConfig() {
        registerModule();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return Promise.resolve(deepClone(DEFAULTS));
        }
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return normalizeConfig(cfg); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config);
        if (currentConfig.test) updateTestResult(currentConfig);
        ensureRuntime();
        mountContextAccess();
    }

    function refresh() {
        return loadConfig().then(applyConfig);
    }

    function start() {
        registerModule();
        refresh();
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
    }

    window.PMK036CatalogueSearch = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        evaluateValue: function (value, index, aimIdentifier, config) {
            return evaluateValue(value, index, aimIdentifier, config || currentConfig);
        },
        testValue: function (value, index, aimIdentifier, config) {
            const result = inspectValue(value, index, aimIdentifier, config || currentConfig);
            return Object.assign({}, result, {
                textFr: resultText(result, "fr"),
                textEn: resultText(result, "en")
            });
        },
        applyBehavior: applyBehavior,
        debug: function () {
            const input = findSearchInput();
            const stored = getStoredContext();
            const urlContext = getUrlSearchContext();
            const chosen = getSearchContext();
            return {
                inputFound: Boolean(input),
                inputValue: input && typeof input.value === "string" ? input.value : null,
                inputDefaultValue: input && typeof input.defaultValue === "string" ? input.defaultValue : null,
                inputValueAttribute: input ? input.getAttribute("value") : null,
                currentMatchesChosen: input ? fieldValueMatchesStored(input, chosen.value) : null,
                storedContext: stored,
                urlContext: urlContext,
                chosenContext: chosen,
                evaluation: chosen.value ? evaluateValue(chosen.value, chosen.index, "", currentConfig) : null
            };
        },
        getConfig: function () { return deepClone(currentConfig); },
        destroy: function () {
            stopObserver();
            cancelBehaviorRetryTimers();
            removeClearButtons();
            const style = document.getElementById(STYLE_ID);
            if (style) style.remove();
        }
    };

    if (typeof document !== "undefined") {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", start, { once: true });
        } else {
            start();
        }
    }
})();

;window.PMKNonPlugin.loaded.push("036-clear-search-when-barcode.js");
} catch (error) { window.PMKNonPlugin.errors.push("036-clear-search-when-barcode.js: "+error.message); console.error("[PMK] 036-clear-search-when-barcode.js",error); };
try {
/* ============================================================
   Nom du fichier : 038-tooltips-contextuels.js
   Module PMK      : contextual-tooltips
   Version         : 2.1.0
   Mise à jour     : 2026-09-18
   Auteur          : équipe PimpMyKoha / refonte PimpMyKoha

   Fusionne et remplace :
   - 038-tooltips-adherents-I.js
   - 039-tooltips-adherents-AS.js

   Fonction :
   - info-bulles contextuelles configurables sur n'importe quelle page Koha ;
   - règles illimitées : page/URL + élément + texte FR/EN ;
   - utilise exclusivement le sélecteur visuel commun de PMK ;
   - affiche une tooltip accessible, responsive et intégrée à Koha ;
   - conserve exactement les textes historiques 038/039 dans les valeurs par défaut.
   ============================================================ */
(function () {
    "use strict";

    if (window.__PMK038ContextualTooltipsLoaded) return;
    window.__PMK038ContextualTooltipsLoaded = true;

    const MODULE_ID = "contextual-tooltips";
    const MODULE_VERSION = "2.1.0";
    const TOOLTIP_ID = "pmk-contextual-tooltip";
    const STYLE_ID = "pmk-contextual-tooltip-style";
    const OWNER_ATTR = "data-pmk038-tooltip";

    const DEFAULTS = {
        enabled: true,
        appearance: {
            theme: "koha",
            position: "auto",
            maxWidth: 420,
            fontSize: 14,
            borderRadius: 7,
            offset: 10,
            showDelay: 120,
            hideDelay: 80,
            shadow: true,
            arrow: true,
            backgroundColor: "#ffffff",
            textColor: "#212529",
            borderColor: "#b7c2cc",
            accentColor: "#408540"
        },
        rules: [
            { id: "legacy-I-surname", enabled: true, label: "Catégorie I — Nom", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=I", selector: "#surname", targetName: "Nom", textFr: "Saisissez le nom de la personne faisant la carte", textEn: "Enter the name of the person for whom the card is being created", position: "inherit" },
            { id: "legacy-I-othernames", enabled: true, label: "Catégorie I — Autres noms", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=I", selector: "#othernames", targetName: "Autres noms", textFr: "Saisissez la nature de la collectivité ou du service, indiquez le libellé exact (ex. : Service culture, direction des sports…) en précisant la collectivité. Pour les classes, indiquez la classe et l'école (Ex. : École Truc, CM1)", textEn: "Enter the type of organisation or department and its exact name, including the parent authority. For classes, enter the school and class (for example: Example School, CM1).", position: "inherit" },
            { id: "legacy-I-address", enabled: true, label: "Catégorie I — Adresse", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=I", selector: "#address", targetName: "Adresse", textFr: "Saisissez l'adresse de la personne faisant la carte", textEn: "Enter the address of the person for whom the card is being created", position: "inherit" },
            { id: "legacy-AS-surname", enabled: true, label: "Catégorie AS — Nom", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=AS", selector: "#surname", targetName: "Nom", textFr: "Saisissez le nom de la personne faisant la carte", textEn: "Enter the name of the person for whom the card is being created", position: "inherit" },
            { id: "legacy-AS-address", enabled: true, label: "Catégorie AS — Adresse", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=AS", selector: "#address", targetName: "Adresse", textFr: "Saisissez l'adresse de la personne faisant la carte", textEn: "Enter the address of the person for whom the card is being created", position: "inherit" },
            { id: "legacy-AS-othernames", enabled: true, label: "Catégorie AS — Association", pageUrl: "/cgi-bin/koha/members/memberentry.pl?op=add_form&categorycode=AS", selector: "#othernames", targetName: "Autres noms", textFr: "Indiquer le nom de l'association", textEn: "Enter the name of the association", position: "inherit" }
        ]
    };

    let currentConfig = deepClone(DEFAULTS);
    let activeRules = [];
    let activeTarget = null;
    let activeRule = null;
    let previousDescribedBy = null;
    let showTimer = 0;
    let hideTimer = 0;
    let listenersMounted = false;

    function deepClone(value) { return JSON.parse(JSON.stringify(value)); }

    function merge(target, source) {
        if (!source || typeof source !== "object") return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) target[key] = deepClone(value);
            else if (value && typeof value === "object") {
                if (!target[key] || typeof target[key] !== "object" || Array.isArray(target[key])) target[key] = {};
                merge(target[key], value);
            } else target[key] = value;
        });
        return target;
    }

    function normalizeConfig(config) {
        const result = merge(deepClone(DEFAULTS), config || {});
        if (!Array.isArray(result.rules)) result.rules = deepClone(DEFAULTS.rules);
        result.rules = result.rules.map(function (rule, index) {
            return merge({
                id: "tooltip-" + (index + 1), enabled: true, label: "", pageUrl: "*", selector: "",
                targetName: "", textFr: "", textEn: "", position: "inherit"
            }, rule || {});
        });
        return result;
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        return (document.documentElement.lang || "").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function normalizeTargetUrl(value) {
        if (window.PMKConfig && window.PMKConfig.elementPicker && typeof window.PMKConfig.elementPicker.normalizeTargetUrl === "function") {
            return window.PMKConfig.elementPicker.normalizeTargetUrl(value);
        }
        const raw = String(value || "").trim();
        if (!raw || raw === "*" || raw === "all") return "";
        return raw.startsWith("/") ? raw : "/cgi-bin/koha/" + raw.replace(/^\/+/, "");
    }

    function pageMatches(pageUrl) {
        const target = normalizeTargetUrl(pageUrl);
        if (!target) return true;
        let wanted;
        try { wanted = new URL(target, window.location.origin); } catch (_) { return false; }
        if (wanted.pathname !== window.location.pathname) return false;
        const current = new URL(window.location.href);
        let ok = true;
        wanted.searchParams.forEach(function (v, k) {
            if (current.searchParams.get(k) !== v) ok = false;
        });
        return ok;
    }

    function safeSelector(selector) {
        const value = String(selector || "").trim();
        if (!value) return false;
        try { document.createDocumentFragment().querySelector(value); return true; }
        catch (_) { return false; }
    }

    function compileRules(config) {
        return (config.rules || []).filter(function (rule) {
            return rule && rule.enabled !== false && pageMatches(rule.pageUrl) && safeSelector(rule.selector) &&
                String(rule.textFr || rule.textEn || "").trim();
        });
    }

    function injectStyle() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #${TOOLTIP_ID} {
                position: fixed;
                z-index: 2147483000;
                box-sizing: border-box;
                opacity: 0;
                visibility: hidden;
                transform: translateY(2px);
                transition: opacity .12s ease, transform .12s ease, visibility 0s linear .12s;
                pointer-events: none;
                white-space: normal;
                overflow-wrap: anywhere;
            }
            #${TOOLTIP_ID}.is-visible {
                opacity: 1;
                visibility: visible;
                pointer-events: auto;
                transform: translateY(0);
                transition: opacity .12s ease, transform .12s ease;
            }
            #${TOOLTIP_ID}::after {
                content: "";
                position: absolute;
                width: 10px;
                height: 10px;
                background: var(--pmk-tooltip-bg, #fff);
                transform: rotate(45deg);
                display: var(--pmk-tooltip-arrow, block);
            }
            #${TOOLTIP_ID}[data-position="bottom"]::after { top: -6px; left: calc(50% - 5px); border-left: 1px solid var(--pmk-tooltip-border); border-top: 1px solid var(--pmk-tooltip-border); }
            #${TOOLTIP_ID}[data-position="top"]::after { bottom: -6px; left: calc(50% - 5px); border-right: 1px solid var(--pmk-tooltip-border); border-bottom: 1px solid var(--pmk-tooltip-border); }
            #${TOOLTIP_ID}[data-position="right"]::after { left: -6px; top: calc(50% - 5px); border-left: 1px solid var(--pmk-tooltip-border); border-bottom: 1px solid var(--pmk-tooltip-border); }
            #${TOOLTIP_ID}[data-position="left"]::after { right: -6px; top: calc(50% - 5px); border-right: 1px solid var(--pmk-tooltip-border); border-top: 1px solid var(--pmk-tooltip-border); }
            @media (prefers-reduced-motion: reduce) {
                #${TOOLTIP_ID}, #${TOOLTIP_ID}.is-visible { transition: none; transform: none; }
            }
            @media (max-width: 576px) {
                #${TOOLTIP_ID} { max-width: calc(100vw - 24px) !important; }
            }
        `;
        document.head.appendChild(style);
    }

    function tooltipNode() {
        injectStyle();
        let node = document.getElementById(TOOLTIP_ID);
        if (node) return node;
        node = document.createElement("div");
        node.id = TOOLTIP_ID;
        node.setAttribute("role", "tooltip");
        node.setAttribute("aria-hidden", "true");
        document.body.appendChild(node);
        return node;
    }

    function effectiveColors(appearance) {
        const a = appearance || {};
        if (a.theme === "dark") {
            return { bg: "#2f3439", text: "#ffffff", border: "#1f2428", accent: a.accentColor || "#7ab67a" };
        }
        if (a.theme === "custom") {
            return {
                bg: a.backgroundColor || "#ffffff",
                text: a.textColor || "#212529",
                border: a.borderColor || "#b7c2cc",
                accent: a.accentColor || "#408540"
            };
        }
        return { bg: "#ffffff", text: "#212529", border: "#b7c2cc", accent: a.accentColor || "#408540" };
    }

    function applyAppearance(node, config) {
        const a = config.appearance || {};
        const c = effectiveColors(a);
        node.style.setProperty("--pmk-tooltip-bg", c.bg);
        node.style.setProperty("--pmk-tooltip-border", c.border);
        node.style.setProperty("--pmk-tooltip-arrow", a.arrow === false ? "none" : "block");
        node.style.background = c.bg;
        node.style.color = c.text;
        node.style.border = "1px solid " + c.border;
        node.style.borderLeft = "3px solid " + c.accent;
        node.style.borderRadius = Math.max(0, Number(a.borderRadius) || 7) + "px";
        node.style.padding = "10px 12px";
        node.style.fontSize = Math.max(11, Number(a.fontSize) || 14) + "px";
        node.style.lineHeight = "1.45";
        node.style.maxWidth = Math.max(180, Number(a.maxWidth) || 420) + "px";
        node.style.boxShadow = a.shadow === false ? "none" : "0 .35rem 1rem rgba(0,0,0,.18)";
        node.style.textAlign = "left";
    }

    function ruleText(rule) {
        const en = language() === "en";
        return String(en ? (rule.textEn || rule.textFr || "") : (rule.textFr || rule.textEn || "")).trim();
    }

    function findMatch(start) {
        if (!start || start.nodeType !== 1) return null;
        for (let i = 0; i < activeRules.length; i += 1) {
            const rule = activeRules[i];
            let target = null;
            try { target = start.closest(rule.selector); } catch (_) { target = null; }
            if (target) return { rule: rule, target: target };
        }
        return null;
    }

    function choosePosition(targetRect, tipRect, wanted, offset) {
        const margin = 8;
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const fits = {
            bottom: targetRect.bottom + offset + tipRect.height <= vh - margin,
            top: targetRect.top - offset - tipRect.height >= margin,
            right: targetRect.right + offset + tipRect.width <= vw - margin,
            left: targetRect.left - offset - tipRect.width >= margin
        };
        if (wanted && wanted !== "auto" && fits[wanted]) return wanted;
        if (fits.bottom) return "bottom";
        if (fits.top) return "top";
        if (fits.right) return "right";
        if (fits.left) return "left";
        return wanted && wanted !== "auto" ? wanted : "bottom";
    }

    function positionTooltip() {
        if (!activeTarget || !activeRule) return;
        const node = tooltipNode();
        const rect = activeTarget.getBoundingClientRect();
        node.style.setProperty("--pmk-tooltip-arrow", currentConfig.appearance?.arrow === false ? "none" : "block");
        node.style.maxHeight = "";
        node.style.overflowY = "";
        node.removeAttribute("tabindex");
        const tip = node.getBoundingClientRect();
        const a = currentConfig.appearance || {};
        const offset = Math.max(4, Number(a.offset) || 10);
        const wanted = activeRule.position && activeRule.position !== "inherit" ? activeRule.position : (a.position || "auto");
        let position = choosePosition(rect, tip, wanted, offset);
        const below = Math.max(0, window.innerHeight - rect.bottom - offset - 8);
        const above = Math.max(0, rect.top - offset - 8);
        const fitsSide = position === "left" ? rect.left - offset - tip.width >= 8
            : position === "right" ? rect.right + offset + tip.width <= window.innerWidth - 8 : false;
        if ((fitsSide && tip.height > window.innerHeight - 16) || (!fitsSide && tip.height > (position === "top" ? above : below))) {
            if (!fitsSide) position = above > below ? "top" : "bottom";
            const space = fitsSide ? window.innerHeight - 16 : position === "top" ? above : below;
            // A huge target can leave no readable area: dismiss instead of covering its controls.
            if (space < 40) { hideNow(); return; }
            node.style.maxHeight = Math.floor(space) + "px";
            node.style.overflowY = "auto";
            node.setAttribute("tabindex", "0");
            node.style.setProperty("--pmk-tooltip-arrow", "none");
            const bounded = node.getBoundingClientRect();
            tip.height = bounded.height; tip.width = bounded.width;
        }
        let left = 0, top = 0;
        if (position === "top") {
            left = rect.left + (rect.width - tip.width) / 2;
            top = rect.top - tip.height - offset;
        } else if (position === "left") {
            left = rect.left - tip.width - offset;
            top = rect.top + (rect.height - tip.height) / 2;
        } else if (position === "right") {
            left = rect.right + offset;
            top = rect.top + (rect.height - tip.height) / 2;
        } else {
            left = rect.left + (rect.width - tip.width) / 2;
            top = rect.bottom + offset;
        }
        left = Math.max(8, Math.min(window.innerWidth - tip.width - 8, left));
        top = Math.max(8, Math.min(window.innerHeight - tip.height - 8, top));
        node.style.left = Math.round(left) + "px";
        node.style.top = Math.round(top) + "px";
        node.dataset.position = position;
    }

    function restoreAria() {
        if (!activeTarget) return;
        if (previousDescribedBy === null) activeTarget.removeAttribute("aria-describedby");
        else activeTarget.setAttribute("aria-describedby", previousDescribedBy);
        previousDescribedBy = null;
    }

    function hideNow() {
        clearTimeout(showTimer); showTimer = 0;
        clearTimeout(hideTimer); hideTimer = 0;
        const node = document.getElementById(TOOLTIP_ID);
        if (node) {
            node.classList.remove("is-visible");
            node.setAttribute("aria-hidden", "true");
        }
        restoreAria();
        activeTarget = null;
        activeRule = null;
    }

    function scheduleHide() {
        clearTimeout(showTimer); showTimer = 0;
        clearTimeout(hideTimer);
        const delay = Math.max(0, Number(currentConfig.appearance && currentConfig.appearance.hideDelay) || 0);
        hideTimer = window.setTimeout(hideNow, delay);
    }

    function showNow(match) {
        if (!match || !match.target || !match.rule) return;
        clearTimeout(hideTimer); hideTimer = 0;
        const sameTarget = activeTarget === match.target;
        if (activeTarget && !sameTarget) restoreAria();
        activeTarget = match.target;
        activeRule = match.rule;
        const node = tooltipNode();
        applyAppearance(node, currentConfig);
        node.textContent = ruleText(match.rule);
        if (!sameTarget) previousDescribedBy = activeTarget.getAttribute("aria-describedby");
        const ids = String(activeTarget.getAttribute("aria-describedby") || previousDescribedBy || "").split(/\s+/).filter(Boolean);
        if (!ids.includes(TOOLTIP_ID)) ids.push(TOOLTIP_ID);
        activeTarget.setAttribute("aria-describedby", ids.join(" "));
        node.setAttribute("aria-hidden", "false");
        node.classList.add("is-visible");
        positionTooltip();
        window.requestAnimationFrame(positionTooltip);
    }

    function scheduleShow(match) {
        if (!match || !ruleText(match.rule)) return;
        clearTimeout(hideTimer); hideTimer = 0;
        clearTimeout(showTimer);
        const delay = Math.max(0, Number(currentConfig.appearance && currentConfig.appearance.showDelay) || 0);
        showTimer = window.setTimeout(function () { showNow(match); }, delay);
    }

    function onMouseOver(event) {
        if (document.getElementById(TOOLTIP_ID)?.contains(event.target)) { clearTimeout(hideTimer); return; }
        const match = findMatch(event.target);
        if (!match) return;
        if (activeTarget === match.target && activeRule === match.rule) return;
        scheduleShow(match);
    }

    function onMouseOut(event) {
        if (!activeTarget) return;
        if (event.relatedTarget && (activeTarget.contains(event.relatedTarget) || document.getElementById(TOOLTIP_ID)?.contains(event.relatedTarget))) return;
        scheduleHide();
    }

    function onFocusIn(event) {
        if (document.getElementById(TOOLTIP_ID)?.contains(event.target)) { clearTimeout(hideTimer); return; }
        const match = findMatch(event.target);
        if (match) scheduleShow(match);
    }

    function onFocusOut(event) {
        if (!activeTarget) return;
        if (event.relatedTarget && (activeTarget.contains(event.relatedTarget) || document.getElementById(TOOLTIP_ID)?.contains(event.relatedTarget))) return;
        scheduleHide();
    }

    function onClick(event) {
        if (document.getElementById(TOOLTIP_ID)?.contains(event.target)) return;
        const match = findMatch(event.target);
        if (match) {
            if (activeTarget === match.target && activeRule === match.rule) showNow(match);
            else scheduleShow(match);
        } else if (activeTarget) {
            scheduleHide();
        }
    }

    function onKeyDown(event) {
        if (event.key === "Escape" && activeTarget) {
            const target = activeTarget;
            if (document.getElementById(TOOLTIP_ID)?.contains(document.activeElement)) target.focus({ preventScroll: true });
            hideNow();
        }
    }

    function onViewportChange(event) {
        if (event?.type === "scroll" && document.getElementById(TOOLTIP_ID)?.contains(event.target)) return;
        if (activeTarget) positionTooltip();
    }

    function mountListeners() {
        if (listenersMounted) return;
        listenersMounted = true;
        document.addEventListener("mouseover", onMouseOver, true);
        document.addEventListener("mouseout", onMouseOut, true);
        document.addEventListener("focusin", onFocusIn, true);
        document.addEventListener("focusout", onFocusOut, true);
        document.addEventListener("click", onClick, true);
        document.addEventListener("keydown", onKeyDown, true);
        window.addEventListener("resize", onViewportChange, { passive: true });
        window.addEventListener("scroll", onViewportChange, true);
    }

    function unmountListeners() {
        if (!listenersMounted) return;
        listenersMounted = false;
        document.removeEventListener("mouseover", onMouseOver, true);
        document.removeEventListener("mouseout", onMouseOut, true);
        document.removeEventListener("focusin", onFocusIn, true);
        document.removeEventListener("focusout", onFocusOut, true);
        document.removeEventListener("click", onClick, true);
        document.removeEventListener("keydown", onKeyDown, true);
        window.removeEventListener("resize", onViewportChange, { passive: true });
        window.removeEventListener("scroll", onViewportChange, true);
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (!activeRules.length) return;
        const anchor = document.querySelector("h1") || document.querySelector("main h2") || document.querySelector("#main h2");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: "contextual-tooltips-" + window.location.pathname.replace(/[^a-z0-9]+/gi, "-"),
                context: { sectionId: "rules" }
            });
        } catch (_) {}
    }

    function refresh(config) {
        hideNow();
        currentConfig = normalizeConfig(config || DEFAULTS);
        activeRules = currentConfig.enabled === false ? [] : compileRules(currentConfig);
        if (currentConfig.enabled === false) {
            unmountListeners();
            return;
        }
        mountListeners();
        mountContextAccess();
    }

    function ruleIndex(fieldPath) {
        if (!Array.isArray(fieldPath)) return -1;
        const pos = fieldPath.indexOf("rules");
        if (pos === -1) return -1;
        const index = Number(fieldPath[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== "function") return false;
        service.register(MODULE_ID, {
            getOptions: function () {
                return {
                    bannerText: language() === "en"
                        ? "Click the element that should display this tooltip — Esc cancels"
                        : "Clique sur l’élément qui doit afficher cette info-bulle — Échap annule"
                };
            },
            applyPending: function (draft, pending, picked) {
                const index = ruleIndex(pending && pending.fieldPath || []);
                if (!draft || !Array.isArray(draft.rules) || index < 0 || !draft.rules[index]) return draft;
                const rule = draft.rules[index];
                rule.targetName = String(picked && (picked.targetName || picked.selector) || rule.targetName || "");
                if (!String(rule.pageUrl || "").trim() && picked && picked.pageUrl) rule.pageUrl = String(picked.pageUrl);
                if (!String(rule.label || "").trim()) rule.label = rule.targetName || ("Info-bulle " + (index + 1));
                return draft;
            },
            afterPendingSave: function (draft) { refresh(draft); }
        });
        return true;
    }

    function pickForConfig(context) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== "function") return Promise.reject(new Error("pmk_common_picker_unavailable"));
        registerCommonPickerAdapter();
        const rootObject = context && context.rootObject ? context.rootObject : {};
        const fieldPath = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const index = ruleIndex(fieldPath);
        const rule = rootObject && Array.isArray(rootObject.rules) && index >= 0 ? rootObject.rules[index] : null;
        const targetUrl = String(rule && rule.pageUrl || window.location.pathname + window.location.search);
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: targetUrl,
            rootObject: rootObject,
            fieldPath: fieldPath,
            meta: { ruleIndex: index },
            adminContext: { sectionId: "rules", ruleIndex: index }
        });
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: true,
                livePreview: true
            },
            previewModel: function (context) {
                const cfg = normalizeConfig(context && context.rootObject || currentConfig || DEFAULTS);
                const a = cfg.appearance || {};
                const c = effectiveColors(a);
                const first = (cfg.rules || []).find(function (rule) {
                    return rule && rule.enabled !== false;
                }) || {};
                return {
                    text: ruleText(first) || (language() === "en" ? "Tooltip preview" : "Aperçu de l’info-bulle"),
                    style: {
                        fontSize: Math.max(11, Number(a.fontSize) || 14) + "px",
                        color: c.text,
                        backgroundColor: c.bg,
                        borderColor: c.border,
                        borderWidth: "1px",
                        borderStyle: "solid",
                        borderRadius: Math.max(0, Number(a.borderRadius) || 7) + "px",
                        boxShadow: a.shadow === false ? "none" : "0 .35rem 1rem rgba(0,0,0,.18)",
                        lineHeight: "1.45"
                    }
                };
            },
            styleTargetUrl: function (context) {
                const cfg = normalizeConfig(context && context.rootObject || currentConfig || DEFAULTS);
                const first = (cfg.rules || []).find(function (rule) {
                    return rule && rule.enabled !== false && String(rule.pageUrl || "").trim();
                });
                return first ? first.pageUrl : (window.location.pathname + window.location.search);
            },
            applyStyleSample: function (context) {
                const cfg = context && context.rootObject;
                const sample = context && context.sample;
                if (!cfg || !sample) return { rootObject: cfg };
                if (!cfg.appearance || typeof cfg.appearance !== "object") cfg.appearance = {};
                const a = cfg.appearance;
                const visual = window.PMKConfig && window.PMKConfig.visualEditor;
                const toHex = visual && typeof visual.colorToHex === "function"
                    ? visual.colorToHex
                    : function () { return ""; };
                const px = visual && typeof visual.pxNumber === "function"
                    ? visual.pxNumber
                    : function (v) { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
                a.theme = "custom";
                const fs = px(sample.fontSize, null);
                if (Number.isFinite(fs)) a.fontSize = Math.max(11, Math.min(32, Math.round(fs)));
                const radius = px(sample.borderRadius, null);
                if (Number.isFinite(radius)) a.borderRadius = Math.max(0, Math.min(48, Math.round(radius)));
                a.backgroundColor = toHex(sample.backgroundColor) || a.backgroundColor || "#ffffff";
                a.textColor = toHex(sample.color) || a.textColor || "#212529";
                a.borderColor = toHex(sample.borderColor) || a.borderColor || "#b7c2cc";
                if (a.borderColor) a.accentColor = a.borderColor;
                a.shadow = Boolean(sample.boxShadow && sample.boxShadow !== "none");
                return { rootObject: cfg };
            },
            previewDraft: function (draft) {
                const before = deepClone(currentConfig || DEFAULTS);
                refresh(draft);
                return function () {
                    refresh(before);
                };
            }
        });
        return true;
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return cfg || deepClone(DEFAULTS); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function start() {
        registerCommonPickerAdapter();
        registerVisualEditorAdapter();
        loadConfig().then(refresh);
        if (window.PMKConfig && typeof window.PMKConfig.subscribe === "function") {
            try { window.PMKConfig.subscribe(MODULE_ID, refresh); } catch (_) {}
        }
    }

    function boot() {
        if (window.PMKConfig) start();
        else {
            window.addEventListener("pmk:config-ready", start, { once: true });
            // fonctionnement autonome si le socle PMK n'est pas chargé
            window.setTimeout(function () {
                if (!window.PMKConfig) refresh(DEFAULTS);
            }, 1200);
        }
    }

    window.PMK038ContextualTooltips = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        pickForConfig: pickForConfig,
        getActiveRules: function () { return deepClone(activeRules); }
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
    else boot();
})();

;window.PMKNonPlugin.loaded.push("038-tooltips-contextuels.js");
} catch (error) { window.PMKNonPlugin.errors.push("038-tooltips-contextuels.js: "+error.message); console.error("[PMK] 038-tooltips-contextuels.js",error); };
try {
/*
 Nom du fichier: 041+042-course-list-fields-labels.js
 Version: 3.0.0-preplugin
 Date de dernière modification: 2026-09-18
 Auteur: équipe PimpMyKoha

 Module PimpMyKoha (phase pré-plugin) : Réserves de cours modifiées

 Objectif :
 - adapter le module natif Koha « Réserves de cours » en gestion de listes d'exemplaires ;
 - conserver les personnalisations historiques des anciens 041 / 042 ;
 - cibler les éléments Koha par leur structure réelle plutôt que parcourir tout le DOM ;
 - rester compatible français / anglais ;
 - couvrir le parcours staff complet : liste, fiche, création, ajout et retrait d'exemplaires ;
 - rester fail-safe si Koha change sa structure.

 Important :
 - aucune donnée Koha n'est modifiée par ce script ;
 - les valeurs des champs masqués restent présentes et sont soumises normalement par Koha ;
 - aucun remplacement global de mots n'est effectué dans les contenus utilisateur.
*/
(function () {
    "use strict";

    if (window.__PMK041042_COURSE_LIST_UI__) return;
    window.__PMK041042_COURSE_LIST_UI__ = true;

    const MODULE_ID = "course-list-ui";
    const MODULE_VERSION = "3.0.0-preplugin";

    const PAGE_DEFINITIONS = [
        {
            id: "course_reserves.list",
            path: "/cgi-bin/koha/course_reserves/course-reserves.pl",
            enabled: true
        },
        {
            id: "course_reserves.course",
            path: "/cgi-bin/koha/course_reserves/course.pl",
            enabled: true
        },
        {
            id: "course_reserves.details",
            path: "/cgi-bin/koha/course_reserves/course-details.pl",
            enabled: true
        },
        {
            id: "course_reserves.add-items",
            path: "/cgi-bin/koha/course_reserves/add_items.pl",
            enabled: true
        },
        {
            id: "course_reserves.batch-add-items",
            path: "/cgi-bin/koha/course_reserves/batch_add_items.pl",
            enabled: true
        },
        {
            id: "course_reserves.batch-rm-items",
            path: "/cgi-bin/koha/course_reserves/batch_rm_items.pl",
            enabled: true
        }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: PAGE_DEFINITIONS,
        labels: {
            moduleTitleFr: "Listes d'exemplaires",
            moduleTitleEn: "Item lists",
            listNameFr: "Nom de la liste",
            listNameEn: "List name",
            departmentFr: "Pôle",
            departmentEn: "Unit",
            listTypeFr: "Type de liste",
            listTypeEn: "List type",
            endDateFr: "Date de fin liste",
            endDateEn: "List end date",
            responsiblesFr: "Responsable(s)",
            responsiblesEn: "Responsible person(s)",
            responsibleSearchFr: "Rechercher responsable liste",
            responsibleSearchEn: "Search list manager"
        },
        display: {
            hideSection: true,
            hideStudentsCount: true,
            updatePlaceholders: true
        }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let tableObserver = null;
    let contextButton = null;
    let pmkReadyListenerInstalled = false;
    let pmkSubscribed = false;

    const textSnapshots = new Map();
    const attributeSnapshots = new Map();
    const styleSnapshots = new Map();
    let titleSnapshot = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return Boolean(value) && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) {
            return Array.isArray(override) ? clone(override) : clone(base);
        }
        if (!isObject(base)) {
            return override === undefined ? clone(base) : clone(override);
        }
        const out = clone(base);
        if (!isObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            out[key] = Object.prototype.hasOwnProperty.call(base, key)
                ? deepMerge(base[key], override[key])
                : clone(override[key]);
        });
        return out;
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            } catch (_) {}
        }
        const lang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function label(key) {
        const lang = detectLanguage();
        const labels = currentConfig.labels || DEFAULT_CONFIG.labels;
        const suffix = lang === "en" ? "En" : "Fr";
        const value = labels[key + suffix];
        if (String(value || "").trim()) return String(value).trim();
        return String(DEFAULT_CONFIG.labels[key + suffix] || "").trim();
    }

    function copy(fr, en) {
        return detectLanguage() === "en" ? en : fr;
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[’'`]/g, "")
            .replace(/[.:?#]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function currentPage() {
        const path = window.location.pathname;
        return PAGE_DEFINITIONS.find(function (page) {
            return page.path === path;
        }) || null;
    }

    function configuredPage(pageId) {
        const pages = Array.isArray(currentConfig.pages) ? currentConfig.pages : [];
        return pages.find(function (page) {
            return page && page.id === pageId;
        }) || null;
    }

    function isEnabledForPage(pageId) {
        if (!currentConfig || currentConfig.enabled === false) return false;
        const page = configuredPage(pageId);
        return Boolean(page && page.enabled !== false);
    }

    function snapshotTextNode(node) {
        if (!node || node.nodeType !== Node.TEXT_NODE) return;
        if (!textSnapshots.has(node)) textSnapshots.set(node, node.nodeValue);
    }

    function setTextNode(node, value) {
        if (!node || node.nodeType !== Node.TEXT_NODE) return;
        snapshotTextNode(node);
        const original = String(node.nodeValue || "");
        const leading = (original.match(/^\s*/) || [""])[0];
        const trailing = (original.match(/\s*$/) || [""])[0];
        node.nodeValue = leading + String(value || "") + trailing;
    }

    function directTextNodes(element) {
        if (!element) return [];
        return Array.from(element.childNodes || []).filter(function (node) {
            return node.nodeType === Node.TEXT_NODE && String(node.nodeValue || "").trim();
        });
    }

    function setDirectText(element, value) {
        if (!element) return false;
        const nodes = directTextNodes(element);
        if (!nodes.length) return false;
        setTextNode(nodes[nodes.length - 1], value);
        return true;
    }

    function replaceDirectText(element, replacements) {
        if (!element) return false;
        let changed = false;
        directTextNodes(element).forEach(function (node) {
            let text = String(node.nodeValue || "");
            let next = text;
            replacements.forEach(function (entry) {
                (entry.aliases || []).forEach(function (alias) {
                    if (!alias || next.indexOf(alias) === -1) return;
                    next = next.split(alias).join(entry.value);
                });
            });
            if (next !== text) {
                snapshotTextNode(node);
                node.nodeValue = next;
                changed = true;
            }
        });
        return changed;
    }

    function snapshotAttribute(element, name) {
        if (!element) return;
        if (!attributeSnapshots.has(element)) attributeSnapshots.set(element, new Map());
        const attrs = attributeSnapshots.get(element);
        if (!attrs.has(name)) {
            attrs.set(name, element.hasAttribute(name) ? element.getAttribute(name) : null);
        }
    }

    function setAttributeValue(element, name, value) {
        if (!element) return;
        snapshotAttribute(element, name);
        element.setAttribute(name, String(value || ""));
    }

    function snapshotDisplay(element) {
        if (!element || styleSnapshots.has(element)) return;
        styleSnapshots.set(element, element.style.display);
    }

    function hideElement(element) {
        if (!element) return;
        snapshotDisplay(element);
        element.style.display = "none";
        element.setAttribute("data-pmk-course-list-hidden", "1");
    }

    function hideFieldRow(fieldId) {
        const field = document.getElementById(fieldId);
        if (!field) return;
        const row = field.closest("li") || field;
        hideElement(row);
    }

    function rememberTitle() {
        if (titleSnapshot === null) titleSnapshot = document.title;
    }

    function replaceDocumentTitle(replacements) {
        rememberTitle();
        let next = document.title;
        replacements.forEach(function (entry) {
            (entry.aliases || []).forEach(function (alias) {
                if (!alias || next.indexOf(alias) === -1) return;
                next = next.split(alias).join(entry.value);
            });
        });
        document.title = next;
    }

    function restoreUi() {
        disconnectDynamicBindings();

        textSnapshots.forEach(function (value, node) {
            if (node && node.isConnected) node.nodeValue = value;
        });
        textSnapshots.clear();

        attributeSnapshots.forEach(function (attrs, element) {
            if (!element || !element.isConnected) return;
            attrs.forEach(function (value, name) {
                if (value === null) element.removeAttribute(name);
                else element.setAttribute(name, value);
            });
        });
        attributeSnapshots.clear();

        styleSnapshots.forEach(function (value, element) {
            if (!element || !element.isConnected) return;
            element.style.display = value;
            element.removeAttribute("data-pmk-course-list-hidden");
        });
        styleSnapshots.clear();

        document.querySelectorAll(".pmk-course-list-column-hidden").forEach(function (element) {
            element.classList.remove("pmk-course-list-column-hidden");
        });

        if (titleSnapshot !== null) {
            document.title = titleSnapshot;
            titleSnapshot = null;
        }
    }

    function ensureStyle() {
        if (document.getElementById("pmk-course-list-ui-style")) return;
        const style = document.createElement("style");
        style.id = "pmk-course-list-ui-style";
        style.textContent = `
            .pmk-course-list-column-hidden { display: none !important; }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function setLabelFor(fieldId, value) {
        const element = document.querySelector('label[for="' + fieldId + '"]');
        if (element) setDirectText(element, value + ":");
    }

    function setSpanLabelByAliases(root, aliases, value) {
        if (!root) return null;
        const targets = root.querySelectorAll("span.label");
        const normalizedAliases = aliases.map(normalizeText);
        for (const span of targets) {
            if (normalizedAliases.includes(normalizeText(span.textContent))) {
                setDirectText(span, value + ":");
                return span;
            }
        }
        return null;
    }

    function findTableHeader(table, aliases, currentValue) {
        if (!table) return null;
        const wanted = aliases.concat(currentValue ? [currentValue] : []).map(normalizeText);
        const headers = Array.from(table.querySelectorAll("thead tr:first-child > th"));
        return headers.find(function (header) {
            return wanted.includes(normalizeText(header.textContent));
        }) || null;
    }

    function renameTableHeader(table, aliases, value) {
        const header = findTableHeader(table, aliases, value);
        if (header) setDirectText(header, value);
        return header;
    }

    function hideTableColumn(table, aliases) {
        const header = findTableHeader(table, aliases, "");
        if (!header || !header.parentElement) return false;
        const headers = Array.from(header.parentElement.children);
        const index = headers.indexOf(header);
        if (index < 0) return false;

        Array.from(table.querySelectorAll("tr")).forEach(function (row) {
            const cells = Array.from(row.children || []);
            if (cells[index]) cells[index].classList.add("pmk-course-list-column-hidden");
        });
        return true;
    }

    function changeBreadcrumbRoot() {
        const rootLink = document.querySelector('.breadcrumbs a[href="/cgi-bin/koha/course_reserves/course-reserves.pl"], #breadcrumbs a[href="/cgi-bin/koha/course_reserves/course-reserves.pl"]');
        if (rootLink) setDirectText(rootLink, label("moduleTitle"));
    }

    function applyCourseForm() {
        const form = document.querySelector('form[action="/cgi-bin/koha/course_reserves/mod_course.pl"], form[action$="/course_reserves/mod_course.pl"]');
        if (!form) return;

        setLabelFor("department", label("department"));
        setLabelFor("course_number", label("endDate"));
        setLabelFor("course_name", label("listName"));
        setLabelFor("term", label("listType"));
        setLabelFor("find_instructor", label("responsibleSearch"));

        const termField = document.getElementById("term");
        if (termField && termField.tagName !== "SELECT") {
            const termRow = termField.closest("li");
            const termLabel = termRow ? termRow.querySelector("span.label") : null;
            if (termLabel) setDirectText(termLabel, label("listType") + ":");
        }

        const instructorLabel = Array.from(form.querySelectorAll("span.label")).find(function (span) {
            return ["instructors", "enseignants", "responsables", "responsable(s)"].includes(normalizeText(span.textContent));
        });
        if (instructorLabel) setDirectText(instructorLabel, label("responsibles") + ":");

        if (currentConfig.display && currentConfig.display.updatePlaceholders !== false) {
            const courseNumber = document.getElementById("course_number");
            const courseName = document.getElementById("course_name");
            const instructor = document.getElementById("find_instructor");
            if (courseNumber) setAttributeValue(courseNumber, "placeholder", label("endDate"));
            if (courseName) setAttributeValue(courseName, "placeholder", label("listName"));
            if (instructor) setAttributeValue(instructor, "placeholder", label("responsibleSearch"));
        }

        if (currentConfig.display && currentConfig.display.hideSection !== false) {
            hideFieldRow("section");
        }
        if (currentConfig.display && currentConfig.display.hideStudentsCount !== false) {
            hideFieldRow("students_count");
        }

        const emptyDepartment = document.querySelector('#department option[value=""]');
        if (emptyDepartment) {
            setDirectText(emptyDepartment, copy("Sélectionner un pôle", "Select a unit"));
        }

        const editing = Boolean(form.querySelector('input[name="course_id"]'));
        const heading = document.querySelector("main h1 span, .main h1 span, h1 span");
        const activeCrumb = document.querySelector(".breadcrumbs .breadcrumb-item.active span, #breadcrumbs .breadcrumb-item.active span, .breadcrumb .active span");
        const legend = form.querySelector("fieldset.rows > legend");

        if (editing) {
            if (heading) replaceDirectText(heading, [
                { aliases: ["Edit ", "Modifier "], value: copy("Modifier ", "Edit ") }
            ]);
            if (activeCrumb) replaceDirectText(activeCrumb, [
                { aliases: ["Edit ", "Modifier "], value: copy("Modifier ", "Edit ") }
            ]);
            if (legend) setDirectText(legend, copy("Modifier la liste", "Edit list"));
        } else {
            if (heading) setDirectText(heading, copy("Nouvelle liste", "New list"));
            if (activeCrumb) setDirectText(activeCrumb, copy("Nouvelle liste", "New list"));
            if (legend) setDirectText(legend, copy("Créer une liste", "Create list"));
        }

        changeBreadcrumbRoot();
        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") },
            { aliases: ["New course", "Nouveau cours"], value: copy("Nouvelle liste", "New list") }
        ]);
    }

    function applyCourseListTable() {
        const table = document.getElementById("course_reserves_table");
        if (!table) return;

        renameTableHeader(table, ["Name", "Nom"], label("listName"));
        renameTableHeader(table, ["Dept.", "Dept", "Department", "Département", "Dépt.", "Dépt"], label("department"));
        renameTableHeader(table, ["Course #", "Course number", "Numéro du cours", "Numéro de cours", "N° du cours", "N° de cours", "N° cours", "No de cours"], label("endDate"));
        renameTableHeader(table, ["Term", "Semester", "Terme", "Session", "Semestre", "Période"], label("listType"));
        renameTableHeader(table, ["Instructors", "Enseignants", "Enseignant(s)"], label("responsibles"));

        if (currentConfig.display && currentConfig.display.hideSection !== false) {
            hideTableColumn(table, ["Section"]);
        }
        if (currentConfig.display && currentConfig.display.hideStudentsCount !== false) {
            hideTableColumn(table, ["# of students", "Number of students", "Nombre d'étudiants", "Nb d'étudiants", "# d'étudiants"]);
        }
    }

    function applyCourseListPage() {
        const h1 = document.querySelector("main h1, .main h1, h1");
        if (h1) setDirectText(h1, label("moduleTitle"));

        const newCourse = document.getElementById("new_course");
        if (newCourse) setDirectText(newCourse, copy("Nouvelle liste", "New list"));

        const batchRemove = document.getElementById("batch_rm");
        if (batchRemove) setDirectText(batchRemove, copy("Suppression par lot de listes", "Batch remove from lists"));

        changeBreadcrumbRoot();
        applyCourseListTable();
        bindTableRefresh(applyCourseListTable);

        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") }
        ]);
    }

    function findSummaryRowByAliases(root, aliases) {
        if (!root) return null;
        const wanted = aliases.map(normalizeText);
        const labels = Array.from(root.querySelectorAll("li > span.label"));
        const span = labels.find(function (candidate) {
            return wanted.includes(normalizeText(candidate.textContent));
        });
        return span ? { label: span, row: span.closest("li") } : null;
    }

    function applyCourseDetailsTable() {
        const table = document.getElementById("course_reserves_table");
        if (!table) return;
        renameTableHeader(
            table,
            ["Other course reserves", "Autres réserves de cours"],
            copy("Autres listes d'exemplaires", "Other item lists")
        );
    }

    function applyCourseDetailsPage() {
        changeBreadcrumbRoot();

        const heading = document.querySelector("main h1, .main h1, h1");
        if (heading) {
            replaceDirectText(heading, [
                {
                    aliases: ["Course details for ", "Détails du cours ", "Détails du cours pour "],
                    value: copy("Détails de la liste ", "List details for ")
                }
            ]);
        }

        const activeCrumb = document.querySelector(".breadcrumbs .breadcrumb-item.active span, #breadcrumbs .breadcrumb-item.active span, .breadcrumb .active span");
        if (activeCrumb) {
            replaceDirectText(activeCrumb, [
                {
                    aliases: ["Course details for ", "Détails du cours ", "Détails du cours pour "],
                    value: copy("Détails de la liste ", "List details for ")
                }
            ]);
        }

        const toolbar = document.getElementById("toolbar");
        if (toolbar) {
            toolbar.querySelectorAll('a[href*="/course_reserves/add_items.pl"]').forEach(function (button) {
                setDirectText(button, copy("Ajouter un exemplaire", "Add item"));
            });
            toolbar.querySelectorAll('a[href*="/course_reserves/batch_add_items.pl"]').forEach(function (button) {
                setDirectText(button, copy("Ajouter par lot", "Batch add items"));
            });

            const removeAll = document.getElementById("rm_items_button");
            const edit = document.getElementById("edit_course");
            const removeCourse = document.getElementById("delete_course_button");
            if (removeAll) setDirectText(removeAll, copy("Retirer tous les exemplaires", "Remove all items"));
            if (edit) setDirectText(edit, copy("Modifier la liste", "Edit list"));
            if (removeCourse) setDirectText(removeCourse, copy("Supprimer la liste", "Delete list"));
        }

        const summaryRoot = document.querySelector(".page-section .rows") || document.querySelector(".rows");
        if (summaryRoot) {
            const mappings = [
                { aliases: ["Course name", "Nom du cours"], value: label("listName") },
                { aliases: ["Department", "Département"], value: label("department") },
                { aliases: ["Course number", "Numéro du cours", "Numéro de cours", "N° du cours", "N° de cours"], value: label("endDate") },
                { aliases: ["Term", "Semester", "Terme", "Session", "Semestre", "Période"], value: label("listType") },
                { aliases: ["Instructors", "Enseignants", "Enseignant(s)"], value: label("responsibles") }
            ];

            mappings.forEach(function (mapping) {
                const found = findSummaryRowByAliases(summaryRoot, mapping.aliases);
                if (found && found.label) setDirectText(found.label, mapping.value + ":");
            });

            if (currentConfig.display && currentConfig.display.hideSection !== false) {
                const section = findSummaryRowByAliases(summaryRoot, ["Section"]);
                if (section && section.row) hideElement(section.row);
            }

            if (currentConfig.display && currentConfig.display.hideStudentsCount !== false) {
                const students = findSummaryRowByAliases(summaryRoot, ["Student count", "Number of students", "Nombre d'étudiants"]);
                if (students && students.row) hideElement(students.row);
            }
        }

        applyCourseDetailsTable();
        bindTableRefresh(applyCourseDetailsTable);

        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") },
            {
                aliases: ["Course details for", "Détails du cours pour", "Détails du cours"],
                value: copy("Détails de la liste", "List details for")
            }
        ]);
    }

    function applyAddItemsPage() {
        changeBreadcrumbRoot();

        const bodyId = document.body ? document.body.id : "";
        const isStep2 = bodyId === "courses_add_items_step2";
        const activeCrumb = document.querySelector(".breadcrumbs .breadcrumb-item.active span, #breadcrumbs .breadcrumb-item.active span, .breadcrumb .active span");
        const heading = document.querySelector("main h1, .main h1, h1");

        if (!isStep2) {
            if (activeCrumb) setDirectText(activeCrumb, copy("Ajouter des exemplaires", "Add items"));
            if (heading) {
                replaceDirectText(heading, [
                    {
                        aliases: ["Add reserves for ", "Ajouter des réserves pour "],
                        value: copy("Ajouter des exemplaires à ", "Add items to ")
                    }
                ]);
            }

            const firstLegend = document.querySelector("form fieldset.rows legend");
            if (firstLegend) setDirectText(firstLegend, copy("Ajouter des exemplaires : scanner le code-barres", "Add items: scan barcode"));
        } else {
            if (activeCrumb) {
                replaceDirectText(activeCrumb, [
                    { aliases: ["Edit", "Modifier"], value: copy("Modifier", "Edit") },
                    { aliases: ["Reserve", "Réserver"], value: copy("Ajouter", "Add") }
                ]);
            }

            if (heading) {
                const mode = heading.querySelector("span");
                if (mode) {
                    const current = normalizeText(mode.textContent);
                    const isEdit = current === "edit" || current === "modifier";
                    setDirectText(mode, isEdit ? copy("Modifier", "Edit") : copy("Ajouter", "Add"));
                }
                replaceDirectText(heading, [
                    { aliases: [" for ", " pour "], value: copy(" dans la liste ", " in list ") }
                ]);
            }

            const already = document.getElementById("already_on_reserve_this");
            if (already) {
                setDirectText(already, copy(
                    "Cet exemplaire est déjà présent dans cette liste.",
                    "This item is already in this list."
                ));
            }

            const countInfo = document.getElementById("already_on_reserve");
            if (countInfo) {
                replaceDirectText(countInfo, [
                    {
                        aliases: [
                            "Number of courses reserving this item:",
                            "Nombre de cours réservant cet exemplaire :"
                        ],
                        value: copy("Nombre de listes contenant cet exemplaire :", "Number of lists containing this item:")
                    },
                    {
                        aliases: [
                            "Number of courses reserving this bibliographic record:",
                            "Nombre de cours réservant cette notice bibliographique :"
                        ],
                        value: copy("Nombre de listes contenant cette notice :", "Number of lists containing this record:")
                    }
                ]);
            }
        }

        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") },
            { aliases: ["Add reserves", "Ajouter des réserves"], value: copy("Ajouter des exemplaires", "Add items") },
            { aliases: ["Edit reserve", "Modifier une réserve"], value: copy("Modifier dans la liste", "Edit list item") }
        ]);
    }

    function applyBatchAddPage() {
        changeBreadcrumbRoot();

        const activeCrumb = document.querySelector(".breadcrumbs .breadcrumb-item.active span, #breadcrumbs .breadcrumb-item.active span, .breadcrumb .active span");
        if (activeCrumb) setDirectText(activeCrumb, copy("Ajout par lot", "Batch add items"));

        const heading = document.querySelector("main h1, .main h1, h1");
        if (heading) {
            replaceDirectText(heading, [
                {
                    aliases: ["Add reserves for ", "Ajouter des réserves pour "],
                    value: copy("Ajout par lot dans ", "Batch add items to ")
                }
            ]);
        }

        const firstLegend = document.querySelector("form fieldset.rows legend");
        if (firstLegend) setDirectText(firstLegend, copy("Ajouter des exemplaires : scanner les codes-barres", "Add items: scan barcodes"));

        const viewCourse = document.querySelector('a.btn[href*="course-details.pl"]');
        if (viewCourse) setDirectText(viewCourse, copy("Voir la liste", "View list"));

        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") },
            { aliases: ["Add reserves", "Ajouter des réserves"], value: copy("Ajout par lot", "Batch add items") }
        ]);
    }

    function applyBatchRemovePage() {
        changeBreadcrumbRoot();

        const batchLabel = copy("Suppression par lot de listes", "Batch remove from lists");
        const activeCrumb = document.querySelector(".breadcrumbs .breadcrumb-item.active span, #breadcrumbs .breadcrumb-item.active span, .breadcrumb .active span");
        const heading = document.querySelector("main h1, .main h1, h1");
        if (activeCrumb) setDirectText(activeCrumb, batchLabel);
        if (heading) setDirectText(heading, batchLabel);

        const legend = document.querySelector("form fieldset.rows legend");
        if (legend) setDirectText(legend, copy("Retirer des exemplaires : scanner les codes-barres", "Remove items: scan barcodes"));

        const warning = document.querySelector("fieldset.action p");
        if (warning) {
            setDirectText(warning, copy(
                "Les exemplaires seront retirés de toutes les listes auxquelles ils sont rattachés.",
                "Items will be removed from every list they are attached to."
            ));
        }

        const returnButton = document.querySelector('a.btn[href="/cgi-bin/koha/course_reserves/course-reserves.pl"]');
        if (returnButton) setDirectText(returnButton, copy("Retour aux listes", "Back to lists"));

        replaceDocumentTitle([
            { aliases: ["Course reserves", "Réserves de cours"], value: label("moduleTitle") },
            { aliases: ["Batch remove reserves", "Suppression par lot des réserves de cours", "Remove reserves", "Retirer des réserves"], value: batchLabel }
        ]);
    }

    function disconnectDynamicBindings() {
        if (tableObserver) {
            try { tableObserver.disconnect(); } catch (_) {}
            tableObserver = null;
        }

        if (window.jQuery) {
            try {
                window.jQuery("#course_reserves_table").off("draw.dt.pmkCourseListUi");
            } catch (_) {}
        }
    }

    function bindTableRefresh(callback) {
        const table = document.getElementById("course_reserves_table");
        if (!table || typeof callback !== "function") return;

        if (window.jQuery) {
            try {
                window.jQuery(table)
                    .off("draw.dt.pmkCourseListUi")
                    .on("draw.dt.pmkCourseListUi", function () {
                        window.setTimeout(callback, 0);
                    });
            } catch (_) {}
        }

        const tbody = table.tBodies && table.tBodies[0];
        if (tbody && typeof MutationObserver === "function") {
            let scheduled = false;
            tableObserver = new MutationObserver(function () {
                if (scheduled) return;
                scheduled = true;
                window.setTimeout(function () {
                    scheduled = false;
                    callback();
                }, 0);
            });
            tableObserver.observe(tbody, { childList: true, subtree: true });
        }
    }

    function mountContextAccess(pageId) {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (contextButton && contextButton.isConnected) return;

        const anchor = document.querySelector("main h1, .main h1, h1, #toolbar");
        if (!anchor) return;

        try {
            contextButton = window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "course-list-ui",
                context: {
                    page: pageId,
                    sectionId: "terminology"
                }
            }) || null;
        } catch (_) {}
    }

    function removeContextAccess() {
        if (contextButton && contextButton.isConnected) {
            try { contextButton.remove(); } catch (_) {}
        }
        contextButton = null;
    }

    function applyCurrentPage() {
        const page = currentPage();
        restoreUi();

        if (!page || !isEnabledForPage(page.id)) {
            removeContextAccess();
            return;
        }

        ensureStyle();

        switch (page.id) {
            case "course_reserves.course":
                applyCourseForm();
                break;
            case "course_reserves.list":
                applyCourseListPage();
                break;
            case "course_reserves.details":
                applyCourseDetailsPage();
                break;
            case "course_reserves.add-items":
                applyAddItemsPage();
                break;
            case "course_reserves.batch-add-items":
                applyBatchAddPage();
                break;
            case "course_reserves.batch-rm-items":
                applyBatchRemovePage();
                break;
            default:
                return;
        }

        mountContextAccess(page.id);
    }

    function applyConfig(config) {
        currentConfig = deepMerge(DEFAULT_CONFIG, config || {});
        applyCurrentPage();
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return Promise.resolve(clone(DEFAULT_CONFIG));
        }

        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (config) {
                return deepMerge(DEFAULT_CONFIG, config || {});
            })
            .catch(function () {
                return clone(DEFAULT_CONFIG);
            });
    }

    function connectPmkConfig() {
        if (!window.PMKConfig) return false;

        loadConfig().then(applyConfig);

        if (!pmkSubscribed && typeof window.PMKConfig.subscribe === "function") {
            try {
                window.PMKConfig.subscribe(MODULE_ID, applyConfig);
                pmkSubscribed = true;
            } catch (_) {}
        }
        return true;
    }

    function start() {
        if (!currentPage()) return;

        const launch = function () {
            if (!connectPmkConfig()) applyConfig(DEFAULT_CONFIG);
        };

        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", launch, { once: true });
        } else {
            launch();
        }

        if (!window.PMKConfig && !pmkReadyListenerInstalled) {
            pmkReadyListenerInstalled = true;
            window.addEventListener("pmk:config-ready", function () {
                connectPmkConfig();
            }, { once: true });
        }
    }

    window.PMK041042CourseListUI = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        pages: clone(PAGE_DEFINITIONS),
        refresh: applyCurrentPage
    };

    start();
})();

;window.PMKNonPlugin.loaded.push("041+042-course-list-fields-labels.js");
} catch (error) { window.PMKNonPlugin.errors.push("041+042-course-list-fields-labels.js: "+error.message); console.error("[PMK] 041+042-course-list-fields-labels.js",error); };
try {
/*
 Nom du fichier: 043-format-phone-numbers.js
 Dépendances: 000-pmk-config-firestore.js (optionnelle au runtime ; valeurs par défaut intégrées)
 Date de dernière modification: 2026-09-18
 Version: 043.2.1 — picker répétable tableaux / multi-règles / formats configurables
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha
 Description:
   Formate visuellement les numéros de téléphone dans Koha sans modifier les données
   ni casser les liens tel:. Le comportement historique du 043 est fourni comme valeur
   par défaut. Des règles supplémentaires peuvent être ajoutées sans limite via le
   picker commun PMK.
*/
(function () {
    'use strict';

    const MODULE_ID = 'phone-number-formatting';
    const DEFAULT_GROUPS = '2,2,2,2,2';

    const DEFAULTS = {
        enabled: true,
        observeDom: true,
        observeDelay: 80,
        rules: [
            {
                id: 'legacy-member-circulation-phones',
                enabled: true,
                label: 'Téléphones lecteur — fiche et circulation',
                targetName: 'Téléphones affichés sur la fiche lecteur et en circulation',
                pages: 'members/moremember.pl\ncirc/circulation.pl',
                selector: 'li.patronphone, a[href^="tel:"]',
                excludeSelector: '#issues-table, #issues-table *',
                format: 'space',
                groups: DEFAULT_GROUPS,
                customSeparator: ' ',
                preservePlus: true
            },
            {
                id: 'waiting-holds-phone',
                enabled: true,
                label: 'Téléphones — réservations en attente',
                targetName: 'Téléphone du lecteur dans les réservations en attente',
                pages: 'circ/waitingreserves.pl',
                selector: '.patron_phone',
                excludeSelector: '',
                format: 'space',
                groups: DEFAULT_GROUPS,
                customSeparator: ' ',
                preservePlus: true
            }
        ]
    };

    let currentConfig = null;
    let observer = null;
    let observerTimer = 0;
    let applying = false;

    // Les valeurs originales sont gardées par nœud texte : aucun innerHTML n'est réécrit.
    const originalText = new Map();
    const selfMutatedTextNodes = new WeakSet();

    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function merge(target, source) {
        if (!source || typeof source !== 'object') return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) {
                target[key] = deepClone(value);
            } else if (value && typeof value === 'object') {
                if (!target[key] || typeof target[key] !== 'object' || Array.isArray(target[key])) {
                    target[key] = {};
                }
                merge(target[key], value);
            } else {
                target[key] = value;
            }
        });
        return target;
    }

    function normalizeRule(rule, index) {
        const base = {
            id: 'rule-' + (index + 1),
            enabled: true,
            label: '',
            targetName: '',
            pages: '',
            selector: '',
            excludeSelector: '',
            format: 'space',
            groups: DEFAULT_GROUPS,
            customSeparator: ' ',
            preservePlus: true
        };
        return merge(base, rule || {});
    }

    function normalizeConfig(config) {
        const result = merge(deepClone(DEFAULTS), config || {});
        if (!Array.isArray(result.rules)) result.rules = deepClone(DEFAULTS.rules);
        result.rules = result.rules.map(normalizeRule);
        return result;
    }

    function cleanPath(path) {
        return String(path || '')
            .trim()
            .replace(/^https?:\/\/[^/]+/i, '')
            .replace(/^\/cgi-bin\/koha\//, '')
            .replace(/^\/+/, '');
    }

    function pathMatches(rule) {
        const rawPages = Array.isArray(rule.pages)
            ? rule.pages
            : String(rule.pages || '').split(/[\n,;]+/);
        const pages = rawPages.map(function (v) { return String(v || '').trim(); }).filter(Boolean);
        if (!pages.length) return true;

        const current = cleanPath(window.location.pathname);
        return pages.some(function (page) {
            if (page === '*' || String(page).toLowerCase() === 'all') return true;
            const wanted = cleanPath(page).split('?')[0];
            return Boolean(wanted && current === wanted);
        });
    }

    function parseGroups(value) {
        const parts = String(value || '')
            .trim()
            .split(/[^0-9]+/)
            .filter(Boolean)
            .map(function (v) { return Number(v); });

        if (!parts.length || parts.some(function (n) { return !Number.isInteger(n) || n < 1 || n > 32; })) {
            return null;
        }
        const total = parts.reduce(function (sum, n) { return sum + n; }, 0);
        if (total < 2 || total > 64) return null;
        return parts;
    }

    function separatorFor(rule) {
        switch (String(rule.format || 'space')) {
            case 'dot': return '.';
            case 'dash': return '-';
            case 'slash': return '/';
            case 'compact': return '';
            case 'custom': return String(rule.customSeparator === undefined ? '' : rule.customSeparator);
            case 'space':
            default: return ' ';
        }
    }

    function expectedDigits(rule) {
        const groups = parseGroups(rule.groups || DEFAULT_GROUPS);
        if (!groups) return null;
        return groups.reduce(function (sum, n) { return sum + n; }, 0);
    }

    function formatDigits(raw, rule) {
        const groups = parseGroups(rule.groups || DEFAULT_GROUPS);
        if (!groups) return null;

        const rawText = String(raw || '').trim();
        const digits = rawText.replace(/\D/g, '');
        const total = groups.reduce(function (sum, n) { return sum + n; }, 0);
        if (digits.length !== total) return null;

        let cursor = 0;
        const out = groups.map(function (size) {
            const group = digits.slice(cursor, cursor + size);
            cursor += size;
            return group;
        });

        const prefix = rule.preservePlus !== false && /^\s*\+/.test(rawText) ? '+' : '';
        return prefix + out.join(separatorFor(rule));
    }

    function candidateRegexFor(rule) {
        const count = expectedDigits(rule);
        if (!count) return null;

        // Lire le numéro entier : ne jamais reformater les dix premiers chiffres
        // d’un numéro international plus long, ni une partie d’un identifiant.
        return /(^|[^\p{L}\p{N}+])(\+?\d(?:[\d\s.\-\/()]*\d)?)(?![\p{L}\p{N}])/gu;
    }

    function formatTextValue(value, rule) {
        const source = String(value || '');
        if (!source.trim()) return source;

        const re = candidateRegexFor(rule);
        if (!re) return source;

        let changed = false;
        const output = source.replace(re, function (whole, before, candidate) {
            const formatted = formatDigits(candidate, rule);
            if (formatted === null) return whole;
            if (candidate === formatted) return whole;
            changed = true;
            return String(before || '') + formatted;
        });

        return changed ? output : source;
    }

    function textNodes(root) {
        const out = [];
        if (!root) return out;

        if (root.nodeType === Node.TEXT_NODE) {
            out.push(root);
            return out;
        }

        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode: function (node) {
                if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (parent.closest('script,style,textarea,input,select,option')) return NodeFilter.FILTER_REJECT;
                if (parent.closest('#pmk-config-overlay, #pmk-config-admin')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });

        let node;
        while ((node = walker.nextNode())) out.push(node);
        return out;
    }

    function carrierElements(element) {
        if (!element || element.nodeType !== 1) return [];

        if (element.matches('a[href^="tel:"]')) return [element];

        const phoneLinks = Array.from(element.querySelectorAll('a[href^="tel:"]'));
        if (phoneLinks.length) return phoneLinks;

        return [element];
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(String(value));
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return '\\' + c; });
    }

    function stableTableSelector(table) {
        if (!table || table.nodeType !== 1) return '';
        if (table.id && !/^pmk-/i.test(table.id)) return '#' + cssEscape(table.id);

        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (service && typeof service.stableSelector === 'function') {
            const selector = service.stableSelector(table);
            if (selector) return selector;
        }
        return '';
    }

    /*
     * Compatibilité avec les règles créées avant le picker répétable :
     * si un pick a enregistré une cellule unique de tableau
     * (ex. tr:nth-of-type(4) > td:nth-of-type(4)), on reconnaît sa colonne
     * et on traite toutes les cellules équivalentes du même tableau.
     * Cette généralisation est volontairement limitée aux <td> d'un <tbody>.
     */
    function repeatedTableColumnSelector(element, rule) {
        if (!element || !element.closest) return '';
        const cell = element.closest('td');
        if (!cell) return '';
        const tbody = cell.closest('tbody');
        const table = cell.closest('table');
        const row = cell.parentElement;
        if (!tbody || !table || !row || !tbody.contains(row)) return '';

        const cells = Array.from(row.children).filter(function (child) {
            return child && child.tagName === 'TD';
        });
        const index = cells.indexOf(cell);
        if (index < 0) return '';

        const tableSelector = stableTableSelector(table);
        if (!tableSelector) return '';

        const selector = tableSelector + ' tbody > tr > td:nth-child(' + (index + 1) + ')';
        let matches;
        try { matches = Array.from(document.querySelectorAll(selector)); }
        catch (_) { return ''; }
        if (matches.length < 2) return '';

        // Sécurité spécifique au module téléphone : on ne généralise la colonne
        // que si au moins deux cellules contiennent un candidat du bon nombre de chiffres.
        const digitCount = expectedDigits(rule);
        if (!digitCount) return '';
        const plausible = matches.filter(function (candidate) {
            const digits = String(candidate.textContent || '').replace(/\D/g, '');
            return digits.length === digitCount;
        });
        if (plausible.length < 2) return '';

        return selector;
    }

    function resolveRuleElements(selector, rule) {
        let elements;
        try { elements = Array.from(document.querySelectorAll(selector)); }
        catch (_) { return []; }

        if (elements.length === 1) {
            const repeatedSelector = repeatedTableColumnSelector(elements[0], rule);
            if (repeatedSelector) {
                try {
                    const repeated = Array.from(document.querySelectorAll(repeatedSelector));
                    if (repeated.length > 1) return repeated;
                } catch (_) {}
            }
        }
        return elements;
    }

    function excluded(element, rule) {
        const selector = String(rule.excludeSelector || '').trim();
        if (!selector || !element || !element.matches) return false;
        try {
            return element.matches(selector) || Boolean(element.closest(selector));
        } catch (_) {
            // Un sélecteur d'exclusion invalide ne doit jamais élargir le traitement.
            return true;
        }
    }

    function rememberOriginal(node) {
        if (!originalText.has(node)) originalText.set(node, node.nodeValue || '');
    }

    function applyToCarrier(carrier, rule) {
        if (!carrier || excluded(carrier, rule)) return false;
        let changed = false;

        textNodes(carrier).forEach(function (node) {
            const before = node.nodeValue || '';
            const after = formatTextValue(before, rule);
            if (after === before) return;
            rememberOriginal(node);
            selfMutatedTextNodes.add(node);
            node.nodeValue = after;
            changed = true;
        });

        return changed;
    }

    function applyRule(rule) {
        if (!rule || rule.enabled === false || !pathMatches(rule)) return;
        const selector = String(rule.selector || '').trim();
        if (!selector) return;

        const elements = resolveRuleElements(selector, rule);
        if (!elements.length) return;

        const seen = new Set();
        elements.forEach(function (element) {
            if (!element || element.closest('#pmk-config-overlay, #pmk-config-admin')) return;
            carrierElements(element).forEach(function (carrier) {
                if (!carrier || seen.has(carrier)) return;
                seen.add(carrier);
                applyToCarrier(carrier, rule);
            });
        });
    }

    function applyAll() {
        if (!currentConfig || currentConfig.enabled === false) return;
        applying = true;
        try {
            (currentConfig.rules || []).forEach(applyRule);
        } finally {
            applying = false;
        }
    }

    function restoreAll() {
        applying = true;
        try {
            originalText.forEach(function (value, node) {
                if (node && node.isConnected) node.nodeValue = value;
            });
            originalText.clear();
        } finally {
            applying = false;
        }
    }

    function stopObserver() {
        clearTimeout(observerTimer);
        observerTimer = 0;
        if (observer) observer.disconnect();
        observer = null;
    }

    function startObserver() {
        if (observer || !document.body) return;

        observer = new MutationObserver(function (mutations) {
            if (applying) return;

            let externalMutation = false;

            // Les mutations produites par le module sont ignorées. Si Koha modifie ensuite
            // un texte déjà suivi, cette nouvelle valeur devient la référence à restaurer.
            mutations.forEach(function (mutation) {
                if (mutation.type === 'characterData' && selfMutatedTextNodes.has(mutation.target)) {
                    selfMutatedTextNodes.delete(mutation.target);
                    return;
                }

                externalMutation = true;
                if (mutation.type === 'characterData' && originalText.has(mutation.target)) {
                    originalText.set(mutation.target, mutation.target.nodeValue || '');
                }
            });

            if (!externalMutation) return;

            clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                applyAll();
            }, Math.max(20, Number(currentConfig && currentConfig.observeDelay) || 80));
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true
        });
    }

    function refresh(config) {
        stopObserver();
        restoreAll();
        currentConfig = normalizeConfig(config);

        if (currentConfig.enabled !== false) {
            applyAll();
            if (currentConfig.observeDom !== false) startObserver();
        }
    }

    function ruleFromContext(context) {
        const root = context && context.rootObject;
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const pos = path.indexOf('rules');
        const index = pos >= 0 ? Number(path[pos + 1]) : -1;
        if (!root || !Array.isArray(root.rules) || !Number.isInteger(index)) return null;
        return root.rules[index] || null;
    }

    function firstPickerPage(context) {
        const rule = ruleFromContext(context);
        const pages = Array.isArray(rule && rule.pages)
            ? rule.pages
            : String(rule && rule.pages || '').split(/[\n,;]+/);

        for (let i = 0; i < pages.length; i += 1) {
            const raw = String(pages[i] || '').trim();
            if (!raw || raw === '*' || raw.toLowerCase() === 'all') continue;
            if (raw.startsWith('/')) return raw;
            return '/cgi-bin/koha/' + raw.replace(/^\/+/, '');
        }
        return window.location.pathname + window.location.search;
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== 'function') return false;

        service.register(MODULE_ID, {
            getOptions: function () {
                const lang = window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function'
                    ? window.PMKConfig.getLanguage()
                    : 'fr';
                return {
                    bannerText: lang === 'en'
                        ? 'Click the element containing the phone number — Esc cancels'
                        : 'Clique sur l’élément contenant le numéro de téléphone — Échap annule',
                    // Le moteur commun peut transformer un pick de cellule en colonne répétée.
                    generalizeTableColumn: true
                };
            },
            applyPending: function (draft, pending, picked) {
                const path = pending && Array.isArray(pending.fieldPath) ? pending.fieldPath : [];
                const pos = path.indexOf('rules');
                const index = pos >= 0 ? Number(path[pos + 1]) : -1;
                if (!draft || !Array.isArray(draft.rules) || !Number.isInteger(index) || !draft.rules[index]) {
                    return draft;
                }

                const rule = draft.rules[index];
                if (picked && picked.targetName) {
                    if (!String(rule.targetName || '').trim()) rule.targetName = picked.targetName;
                    if (!String(rule.label || '').trim()) rule.label = picked.targetName;
                }
                return draft;
            }
        });
        return true;
    }

    function pickElement(context) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== 'function') {
            return Promise.reject(new Error('pmk_common_picker_unavailable'));
        }

        registerCommonPickerAdapter();
        const ctx = context || {};
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: firstPickerPage(ctx),
            rootObject: ctx.rootObject || {},
            fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath : [],
            adminContext: { sectionId: 'rules' }
        });
    }

    function stableSelector(element) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        return service && typeof service.stableSelector === 'function'
            ? service.stableSelector(element)
            : '';
    }

    function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') {
            return Promise.resolve(deepClone(DEFAULTS));
        }

        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return cfg || deepClone(DEFAULTS); })
            .catch(function () { return deepClone(DEFAULTS); });
    }

    function start() {
        registerCommonPickerAdapter();
        loadConfig().then(refresh);

        if (window.PMKConfig && typeof window.PMKConfig.subscribe === 'function') {
            try {
                window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                    refresh(cfg);
                });
            } catch (_) {}
        }
    }

    window.PMK043PhoneNumberFormatting = {
        id: MODULE_ID,
        defaults: deepClone(DEFAULTS),
        refresh: refresh,
        apply: applyAll,
        restore: restoreAll,
        pickElement: pickElement,
        stableSelector: stableSelector,
        formatDigits: formatDigits,
        parseGroups: parseGroups
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("043-format-phone-numbers.js");
} catch (error) { window.PMKNonPlugin.errors.push("043-format-phone-numbers.js: "+error.message); console.error("[PMK] 043-format-phone-numbers.js",error); };
try {
/*
 Nom du fichier : 048-forbid-accents-batchmod.js
 Version : 1.1.2-preplugin
 Date de dernière modification : 2026-09-19
 Auteur : équipe PimpMyKoha / refonte PimpMyKoha

 Description :
 - remplace le 048 historique par un moteur transversal « Règles de saisie » ;
 - absorbe le périmètre du 131-saisie-prix.js sans toucher au 035 ;
 - active par défaut un contrôle des champs Koha items.price et items.replacementprice ;
 - pour le preset Prix : chiffres uniquement + point décimal, aucune virgule, 2 décimales par défaut ;
 - permet de cibler n'importe quel champ Koha via le picker commun PMK ;
 - règles illimitées : caractères autorisés ou interdits, presets ou liste personnalisée ;
 - casse automatique : aucune, MAJUSCULES, minuscules, première lettre en majuscule ;
 - information discrète près du champ lorsqu'une saisie est refusée ;
 - clavier, collage, glisser-déposer, mobile/IME et contenu dynamique pris en charge ;
 - aucun enregistrement Koha automatique et aucun console.*.

 Dépendance recommandée :
 - 000-pmk-config-firestore.js v0.4.35+ pour la configuration et le picker commun.

 Fusion :
 - 048-forbid-accents-batchmod.js : remplacé par ce fichier ;
 - 131-saisie-prix.js : ne doit plus être chargé séparément après activation de ce module ;
 - 035-resize-z3950.js : STRICTEMENT INCHANGE et indépendant.
*/
(function () {
    "use strict";

    if (window.__PMK048_INPUT_RULES__) return;
    window.__PMK048_INPUT_RULES__ = true;
    window.__PMK_131_MERGED_INTO_048__ = true;

    const MODULE_ID = "input-rules";
    const MODULE_VERSION = "1.1.2-preplugin";
    const STYLE_ID = "pmk048-input-rules-style";
    const CONTEXT_KEY = "input-rules";
    const BATCHMOD_PATH = "/cgi-bin/koha/tools/batchMod.pl";
    const PRICE_SELECTOR = '[name="items.price"], [name="items.replacementprice"]';
    const PRICE_DEFAULT_DECIMALS = 2;

    const LEGACY_048_ACCENTS = "éèêàâùûôîçï";

    const PRESETS = {
        custom: {
            fr: "Personnalisé",
            en: "Custom",
            characters: ""
        },
        legacy048: {
            fr: "Accents historiques du 048",
            en: "Legacy 048 accented characters",
            characters: LEGACY_048_ACCENTS
        },
        frenchAccents: {
            fr: "Accents et ligatures françaises",
            en: "French accents and ligatures",
            characters: "àâäæçéèêëîïôöœùûüÿÀÂÄÆÇÉÈÊËÎÏÔÖŒÙÛÜŸ"
        },
        digits: {
            fr: "Chiffres 0 à 9",
            en: "Digits 0 to 9",
            characters: "0123456789"
        },
        asciiLetters: {
            fr: "Lettres A-Z / a-z",
            en: "Letters A-Z / a-z",
            characters: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        },
        frenchLetters: {
            fr: "Lettres françaises",
            en: "French letters",
            characters: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzàâäæçéèêëîïôöœùûüÿÀÂÄÆÇÉÈÊËÎÏÔÖŒÙÛÜŸ"
        },
        alphanumeric: {
            fr: "Lettres françaises + chiffres",
            en: "French letters + digits",
            characters: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzàâäæçéèêëîïôöœùûüÿÀÂÄÆÇÉÈÊËÎÏÔÖŒÙÛÜŸ0123456789"
        },
        price: {
            fr: "Prix : chiffres + point",
            en: "Price: digits + dot",
            characters: "0123456789."
        },
        whitespace: {
            fr: "Espaces et tabulations",
            en: "Spaces and tabs",
            characters: " \t\n\r"
        }
    };

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function makeId(prefix) {
        const p = String(prefix || "rule").trim() || "rule";
        if (window.crypto && typeof window.crypto.randomUUID === "function") {
            return p + "-" + window.crypto.randomUUID();
        }
        return p + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const lang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function i18n(fr, en) {
        return language() === "en" ? en : fr;
    }

    function pageKey(path) {
        return String(path || "").trim().replace(/[?#].*$/, "");
    }

    function pageMatches(rule) {
        const configured = pageKey(rule && rule.pagePath);
        if (!configured || configured === "*") return true;
        return pageKey(window.location.pathname) === configured;
    }

    function targetUrl(rule) {
        const path = pageKey(rule && rule.pagePath);
        if (!path || path === "*") return window.location.pathname + window.location.search;
        return path;
    }

    function safeMatches(element, selector) {
        if (!element || element.nodeType !== 1 || !selector) return false;
        try {
            return element.matches(selector);
        } catch (_) {
            return false;
        }
    }

    function isEditableTarget(element) {
        if (!element || element.nodeType !== 1) return false;
        if (element.isContentEditable) return true;
        if (element.tagName === "TEXTAREA") return !element.disabled && !element.readOnly;
        if (element.tagName !== "INPUT") return false;
        if (element.disabled || element.readOnly) return false;
        const type = String(element.type || "text").toLowerCase();
        return ![
            "hidden", "checkbox", "radio", "button", "submit", "reset", "file",
            "range", "color", "date", "datetime-local", "month", "week", "time"
        ].includes(type);
    }

    function fieldValue(element) {
        if (!element) return "";
        return element.isContentEditable ? String(element.textContent || "") : String(element.value || "");
    }

    function setFieldValue(element, value) {
        if (!element) return;
        if (element.isContentEditable) element.textContent = value;
        else element.value = value;
    }

    function presetCharacters(rule) {
        if (!rule) return "";
        if (String(rule.preset || "custom") === "custom") return String(rule.characters || "");
        const preset = PRESETS[String(rule.preset || "")];
        return preset ? String(preset.characters || "") : String(rule.characters || "");
    }

    function charactersSet(rule) {
        return new Set(Array.from(presetCharacters(rule)));
    }

    function isPriceRule(rule) {
        return Boolean(rule && String(rule.preset || "") === "price" && String(rule.characterMode || "allowed") === "allowed");
    }

    function priceDecimals(rule) {
        const value = Number(rule && rule.priceDecimals);
        if (!Number.isFinite(value)) return PRICE_DEFAULT_DECIMALS;
        return Math.max(0, Math.min(6, Math.floor(value)));
    }

    function sanitizePriceValue(value, rule, finalPass) {
        const source = Array.from(String(value || "").replace(/\u00a0/g, " "));
        const decimals = priceDecimals(rule);
        let output = "";
        let separatorSeen = false;
        let decimalCount = 0;

        source.forEach(function (character) {
            if (/^[0-9]$/.test(character)) {
                if (!separatorSeen || decimalCount < decimals) {
                    output += character;
                    if (separatorSeen) decimalCount += 1;
                }
                return;
            }

            if (character === "." && decimals > 0 && !separatorSeen) {
                if (!output) output = "0";
                output += character;
                separatorSeen = true;
            }
        });

        if (finalPass && /\.$/.test(output)) {
            output = output.slice(0, -1);
        }
        return output;
    }

    function characterAllowed(character, rule) {
        const set = charactersSet(rule);
        const mode = String(rule && rule.characterMode || "forbidden");
        if (mode === "allowed") return set.has(character);
        return !set.has(character);
    }

    function applyCharacterRule(value, rule, finalPass) {
        if (isPriceRule(rule)) return sanitizePriceValue(value, rule, finalPass === true);
        return Array.from(String(value || "")).filter(function (character) {
            return characterAllowed(character, rule);
        }).join("");
    }

    function upperFirstLetter(value) {
        const chars = Array.from(String(value || ""));
        for (let i = 0; i < chars.length; i += 1) {
            const current = chars[i];
            if (current.toLocaleUpperCase() !== current.toLocaleLowerCase()) {
                chars[i] = current.toLocaleUpperCase();
                break;
            }
        }
        return chars.join("");
    }

    function applyCase(value, rule) {
        const mode = String(rule && rule.caseMode || "none");
        if (mode === "upper") return String(value || "").toLocaleUpperCase();
        if (mode === "lower") return String(value || "").toLocaleLowerCase();
        if (mode === "first-upper") return upperFirstLetter(value);
        return String(value || "");
    }

    function transformCharactersOnly(value, rules, finalPass) {
        let out = String(value || "");
        (rules || []).forEach(function (rule) {
            out = applyCharacterRule(out, rule, finalPass === true);
        });
        return out;
    }

    function transformValue(value, rules, finalPass) {
        let out = String(value || "");
        (rules || []).forEach(function (rule) {
            out = applyCharacterRule(out, rule, finalPass === true);
            out = applyCase(out, rule);
        });
        return out;
    }

    function candidateWithInsertedText(element, insertedText) {
        if (!element || element.isContentEditable) return null;
        const before = fieldValue(element);
        try {
            if (typeof element.selectionStart === "number" && typeof element.selectionEnd === "number") {
                return before.slice(0, element.selectionStart) + String(insertedText || "") + before.slice(element.selectionEnd);
            }
        } catch (_) {}
        return before + String(insertedText || "");
    }

    function defaultMessage(rule, rejected) {
        const custom = language() === "en"
            ? String(rule.messageEn || rule.messageFr || "").trim()
            : String(rule.messageFr || rule.messageEn || "").trim();
        if (custom) return custom;

        const shown = Array.from(new Set(Array.from(String(rejected || "")))).join(" ");
        if (language() === "en") {
            return shown
                ? "Character not allowed in this field: " + shown
                : "This entry is not allowed in this field.";
        }
        return shown
            ? "Caractère non autorisé dans ce champ : " + shown
            : "Cette saisie n’est pas autorisée dans ce champ.";
    }

    function ensureStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk048-input-feedback {
                display: block;
                width: fit-content;
                max-width: min(34rem, 100%);
                margin-top: .25rem;
                padding: .28rem .48rem;
                border: 1px solid rgba(176, 96, 0, .32);
                border-radius: .35rem;
                background: rgba(255, 193, 7, .12);
                color: #6d4700;
                font-size: .82rem;
                line-height: 1.3;
                overflow-wrap: anywhere;
            }
            .pmk048-input-feedback[hidden] { display: none !important; }
            .pmk048-field-invalid {
                outline: 2px solid rgba(220, 53, 69, .22);
                outline-offset: 1px;
            }
            @media (max-width: 576px) {
                .pmk048-input-feedback {
                    width: 100%;
                    max-width: 100%;
                    box-sizing: border-box;
                }
            }
        `;
        document.head.appendChild(style);
    }

    const feedbackTimers = new WeakMap();

    function feedbackContainerFor(element) {
        if (!element) return null;
        const id = element.getAttribute && element.getAttribute("data-pmk048-feedback-id");
        if (id) {
            const existing = document.getElementById(id);
            if (existing) return existing;
        }

        const box = document.createElement("span");
        box.id = "pmk048-feedback-" + makeId("f");
        box.className = "pmk048-input-feedback";
        box.setAttribute("role", "status");
        box.setAttribute("aria-live", "polite");
        box.hidden = true;

        const anchor = element.closest("li, .form-group, .mb-3, .row, td, th") || element.parentElement;
        if (anchor) anchor.appendChild(box);
        else element.insertAdjacentElement("afterend", box);

        if (element.setAttribute) {
            element.setAttribute("data-pmk048-feedback-id", box.id);
            const describedBy = String(element.getAttribute("aria-describedby") || "").trim();
            if (!describedBy.split(/\s+/).includes(box.id)) {
                element.setAttribute("aria-describedby", (describedBy ? describedBy + " " : "") + box.id);
            }
        }
        return box;
    }

    function showFeedback(element, rule, rejected) {
        if (!rule || rule.showMessage === false || !element) return;
        const box = feedbackContainerFor(element);
        if (!box) return;

        box.textContent = defaultMessage(rule, rejected);
        box.hidden = false;
        element.classList.add("pmk048-field-invalid");

        const previous = feedbackTimers.get(element);
        if (previous) window.clearTimeout(previous);
        const delay = Math.max(800, Number(rule.messageDurationMs || 2600));
        const timer = window.setTimeout(function () {
            box.hidden = true;
            element.classList.remove("pmk048-field-invalid");
            feedbackTimers.delete(element);
        }, delay);
        feedbackTimers.set(element, timer);
    }

    function activeRulesFor(element) {
        if (!currentConfig || currentConfig.enabled === false || !isEditableTarget(element)) return [];
        return (currentConfig.rules || []).filter(function (rule) {
            return rule && rule.enabled !== false && pageMatches(rule) && safeMatches(element, rule.targetSelector);
        });
    }

    function rejectedCharacters(text, rules) {
        const rejected = [];
        Array.from(String(text || "")).forEach(function (character) {
            if ((rules || []).some(function (rule) { return !characterAllowed(character, rule); })) {
                rejected.push(character);
            }
        });
        return rejected.join("");
    }

    function selectionSnapshot(element) {
        try {
            if (typeof element.selectionStart === "number" && typeof element.selectionEnd === "number") {
                return { start: element.selectionStart, end: element.selectionEnd };
            }
        } catch (_) {}
        return null;
    }

    function restoreCaretAfterTransform(element, before, after, selection) {
        if (!selection || !element || element.isContentEditable) return;
        try {
            const prefixBefore = String(before || "").slice(0, selection.start);
            const prefixAfter = transformValue(prefixBefore, activeRulesFor(element));
            const pos = Math.min(after.length, prefixAfter.length);
            element.setSelectionRange(pos, pos);
        } catch (_) {}
    }

    let internalMutation = false;
    let composingElement = null;

    function normalizeElement(element, notify) {
        const rules = activeRulesFor(element);
        if (!rules.length) return false;
        const before = fieldValue(element);
        const after = transformValue(before, rules);
        if (after === before) return false;

        const rejected = rejectedCharacters(before, rules);
        const selection = selectionSnapshot(element);
        internalMutation = true;
        setFieldValue(element, after);
        restoreCaretAfterTransform(element, before, after, selection);
        internalMutation = false;

        if (notify && rejected) {
            const culprit = rules.find(function (rule) {
                return Array.from(rejected).some(function (c) { return !characterAllowed(c, rule); });
            }) || rules[0];
            showFeedback(element, culprit, rejected);
        }
        return true;
    }

    function onBeforeInput(event) {
        const element = event.target;
        if (!isEditableTarget(element) || element === composingElement || event.isComposing) return;
        const rules = activeRulesFor(element);
        if (!rules.length) return;
        if (!String(event.inputType || "").startsWith("insert")) return;
        if (event.data == null || event.data === "") return;

        const candidate = candidateWithInsertedText(element, event.data);
        if (candidate == null) {
            const rejected = rejectedCharacters(event.data, rules);
            if (!rejected) return;
            event.preventDefault();
            const culprit = rules.find(function (rule) {
                return Array.from(rejected).some(function (c) { return !characterAllowed(c, rule); });
            }) || rules[0];
            showFeedback(element, culprit, rejected);
            return;
        }

        const filteredCandidate = transformCharactersOnly(candidate, rules, false);
        if (candidate === filteredCandidate) return;

        event.preventDefault();
        const rejected = event.data;
        const culprit = rules.find(function (rule) {
            return isPriceRule(rule) || Array.from(String(event.data || "")).some(function (c) { return !characterAllowed(c, rule); });
        }) || rules[0];
        showFeedback(element, culprit, rejected);
    }

    function onPaste(event) {
        const element = event.target;
        if (!isEditableTarget(element)) return;
        const rules = activeRulesFor(element);
        if (!rules.length) return;
        const clipboard = event.clipboardData;
        if (!clipboard || typeof clipboard.getData !== "function") return;
        const raw = clipboard.getData("text");
        if (raw == null) return;

        const candidate = candidateWithInsertedText(element, raw);
        if (candidate == null) {
            const transformed = transformValue(raw, rules, false);
            if (transformed === raw) return;
            event.preventDefault();
            try { document.execCommand("insertText", false, transformed); } catch (_) {}
            showFeedback(element, rules[0], raw);
            return;
        }

        const filteredCandidate = transformCharactersOnly(candidate, rules, false);
        if (candidate === filteredCandidate) return;

        event.preventDefault();
        const before = fieldValue(element);
        let start = before.length;
        let end = start;
        try {
            if (typeof element.selectionStart === "number") start = element.selectionStart;
            if (typeof element.selectionEnd === "number") end = element.selectionEnd;
        } catch (_) {}
        const acceptedFragment = transformValue(raw, rules, false);
        try {
            if (!element.isContentEditable && typeof element.setRangeText === "function") {
                internalMutation = true;
                element.setRangeText(acceptedFragment, start, end, "end");
                internalMutation = false;
                normalizeElement(element, false);
                element.dispatchEvent(new Event("input", { bubbles: true }));
            }
        } catch (_) {
            internalMutation = false;
        }
        showFeedback(element, rules.find(isPriceRule) || rules[0], raw);
    }

    function onInput(event) {
        if (internalMutation) return;
        const element = event.target;
        if (!isEditableTarget(element) || element === composingElement || event.isComposing) return;
        normalizeElement(element, true);
    }

    function onCompositionStart(event) {
        if (isEditableTarget(event.target)) composingElement = event.target;
    }

    function onCompositionEnd(event) {
        const element = event.target;
        if (composingElement === element) composingElement = null;
        if (isEditableTarget(element)) normalizeElement(element, true);
    }

    function finalizeElement(element, notify) {
        const rules = activeRulesFor(element);
        if (!rules.length) return false;
        const before = fieldValue(element);
        const after = transformValue(before, rules, true);
        if (after === before) return false;
        internalMutation = true;
        setFieldValue(element, after);
        internalMutation = false;
        if (notify) showFeedback(element, rules.find(isPriceRule) || rules[0], before);
        return true;
    }

    function onBlur(event) {
        if (isEditableTarget(event.target)) finalizeElement(event.target, false);
    }

    function onSubmit(event) {
        const form = event.target;
        if (!form || form.nodeType !== 1 || String(form.tagName || "").toUpperCase() !== "FORM") return;
        try {
            form.querySelectorAll("input, textarea, [contenteditable='true']").forEach(function (element) {
                if (isEditableTarget(element)) finalizeElement(element, false);
            });
        } catch (_) {}
    }

    function bindDelegatedEvents() {
        if (window.__PMK048_INPUT_RULES_EVENTS__) return;
        window.__PMK048_INPUT_RULES_EVENTS__ = true;
        document.addEventListener("beforeinput", onBeforeInput, true);
        document.addEventListener("paste", onPaste, true);
        document.addEventListener("input", onInput, true);
        document.addEventListener("compositionstart", onCompositionStart, true);
        document.addEventListener("compositionend", onCompositionEnd, true);
        document.addEventListener("blur", onBlur, true);
        document.addEventListener("submit", onSubmit, true);
    }

    function ruleIndex(path) {
        const idx = (path || []).indexOf("rules");
        if (idx < 0) return -1;
        const value = Number(path[idx + 1]);
        return Number.isInteger(value) ? value : -1;
    }

    function ruleAt(root, path) {
        const index = ruleIndex(path);
        return index >= 0 && root && Array.isArray(root.rules) ? root.rules[index] : null;
    }

    function applyPickerMetadata(root, path, result) {
        const rule = ruleAt(root, path);
        if (!rule || !result) return;
        rule.targetName = String(result.targetName || result.selector || rule.targetName || "");
        if (!String(rule.pagePath || "").trim() && result.pagePath) rule.pagePath = String(result.pagePath);
    }

    function pickTarget(context) {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }
        const root = context && context.rootObject ? context.rootObject : {};
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath.slice() : [];
        const rule = ruleAt(root, path);
        return picker.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: targetUrl(rule),
            rootObject: root,
            fieldPath: path,
            persistAfterPick: false,
            adminContext: { sectionId: "rules", ruleIndex: ruleIndex(path) },
            options: {
                bannerText: i18n(
                    "Clique sur le champ de saisie Koha à contrôler — Échap annule",
                    "Click the Koha input field to control — Esc cancels"
                )
            }
        });
    }

    function registerPickerAdapter() {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return false;
        picker.register(MODULE_ID, {
            applyPending: function (draft, pending, picked) {
                applyPickerMetadata(draft, pending && pending.fieldPath || [], picked);
                return draft;
            }
        });
        return true;
    }

    function newRule() {
        return {
            id: makeId("input-rule"),
            enabled: true,
            label: "Nouvelle règle de saisie",
            pagePath: window.location.pathname || "",
            targetSelector: "",
            targetName: "",
            characterMode: "forbidden",
            preset: "custom",
            characters: "",
            priceDecimals: PRICE_DEFAULT_DECIMALS,
            caseMode: "none",
            showMessage: true,
            messageFr: "",
            messageEn: "",
            messageDurationMs: 2600
        };
    }

    const DEFAULT_CONFIG = {
        enabled: true,
        rules: [
            {
                id: "legacy-048-batchmod-accents",
                enabled: true,
                label: "048 — accents interdits en modification par lot",
                pagePath: BATCHMOD_PATH,
                targetSelector: "#cataloguing_additem_newitem input[type='text'], #cataloguing_additem_newitem textarea",
                targetName: "Champs texte de modification des exemplaires",
                characterMode: "forbidden",
                preset: "legacy048",
                characters: LEGACY_048_ACCENTS,
                caseMode: "none",
                showMessage: true,
                messageFr: "Ce caractère accentué n’est pas autorisé dans ce champ.",
                messageEn: "This accented character is not allowed in this field.",
                messageDurationMs: 2600
            },
            {
                id: "legacy-131-price-entry",
                enabled: true,
                label: "Prix des exemplaires — contrôle de saisie",
                pagePath: "*",
                targetSelector: PRICE_SELECTOR,
                targetName: "Prix d'achat et prix de remplacement des exemplaires",
                characterMode: "allowed",
                preset: "price",
                characters: PRESETS.price.characters,
                priceDecimals: PRICE_DEFAULT_DECIMALS,
                caseMode: "none",
                showMessage: true,
                messageFr: "Saisir un prix avec des chiffres et, si nécessaire, un seul point décimal. La virgule est interdite.",
                messageEn: "Enter a price using digits and, if needed, a single decimal point. Commas are not allowed.",
                messageDurationMs: 2600
            }
        ]
    };

    function normalizeRule(rule, index) {
        const source = rule && typeof rule === "object" ? rule : {};
        const base = newRule();
        const out = Object.assign(base, clone(source));
        out.id = String(out.id || makeId("input-rule"));
        out.label = String(out.label || "Règle " + (index + 1));
        out.pagePath = String(out.pagePath || "").trim();
        out.targetSelector = String(out.targetSelector || "").trim();
        out.targetName = String(out.targetName || "").trim();
        out.characterMode = ["allowed", "forbidden"].includes(out.characterMode) ? out.characterMode : "forbidden";
        out.preset = PRESETS[out.preset] ? out.preset : "custom";
        out.characters = String(out.characters == null ? "" : out.characters);
        out.priceDecimals = priceDecimals(out);

        const legacyPricePlaceholder = out.id === "legacy-131-price-entry" &&
            !String(source.targetSelector || "").trim() &&
            (!String(source.pagePath || "").trim() || String(source.label || "").indexOf("à pointer") !== -1);
        if (legacyPricePlaceholder) {
            out.enabled = true;
            out.label = "Prix des exemplaires — contrôle de saisie";
            out.pagePath = "*";
            out.targetSelector = PRICE_SELECTOR;
            out.targetName = "Prix d'achat et prix de remplacement des exemplaires";
            out.characterMode = "allowed";
            out.preset = "price";
            out.characters = PRESETS.price.characters;
            out.priceDecimals = PRICE_DEFAULT_DECIMALS;
            out.messageFr = "Saisir un prix avec des chiffres et au maximum un séparateur décimal (virgule ou point).";
            out.messageEn = "Enter a price using digits and at most one decimal separator (comma or dot).";
        }

        out.caseMode = ["none", "upper", "lower", "first-upper"].includes(out.caseMode) ? out.caseMode : "none";
        out.messageFr = String(out.messageFr || "");
        out.messageEn = String(out.messageEn || "");
        out.messageDurationMs = Math.max(800, Math.min(10000, Number(out.messageDurationMs || 2600)));
        return out;
    }

    function normalizeConfig(config) {
        const source = config && typeof config === "object" ? config : {};
        const rules = Array.isArray(source.rules) ? source.rules : DEFAULT_CONFIG.rules;
        return {
            enabled: source.enabled !== false,
            rules: rules.map(normalizeRule)
        };
    }

    function validate(config) {
        const cfg = normalizeConfig(config);
        const ids = new Set();
        for (let i = 0; i < cfg.rules.length; i += 1) {
            const rule = cfg.rules[i];
            if (!rule.id || ids.has(rule.id)) {
                return { ok: false, message: i18n("Chaque règle doit avoir un identifiant unique.", "Each rule must have a unique identifier.") };
            }
            ids.add(rule.id);
            if (!String(rule.label || "").trim()) {
                return { ok: false, message: i18n("Chaque règle doit avoir un nom.", "Each rule must have a name.") };
            }
            if (rule.enabled !== false && !String(rule.targetSelector || "").trim()) {
                return { ok: false, message: i18n("Une règle active doit cibler un champ Koha.", "An enabled rule must target a Koha field.") };
            }
            if (rule.preset === "custom" && !String(rule.characters || "").length) {
                return { ok: false, message: i18n("Une règle personnalisée doit contenir au moins un caractère.", "A custom rule must contain at least one character.") };
            }
            if (rule.preset === "price" && (!Number.isInteger(Number(rule.priceDecimals)) || Number(rule.priceDecimals) < 0 || Number(rule.priceDecimals) > 6)) {
                return { ok: false, message: i18n("Le nombre de décimales du prix doit être compris entre 0 et 6.", "Price decimal places must be between 0 and 6.") };
            }
            if (rule.targetSelector) {
                try { document.querySelector(rule.targetSelector); } catch (_) {
                    return { ok: false, message: i18n("Un sélecteur de champ est invalide.", "A field selector is invalid.") };
                }
            }
        }
        return { ok: true };
    }

    function presetOptions() {
        return Object.keys(PRESETS).map(function (key) {
            const preset = PRESETS[key];
            return { value: key, label: { fr: preset.fr, en: preset.en } };
        });
    }

    function modeOptions() {
        return [
            { value: "forbidden", label: { fr: "Interdire les caractères de la liste", en: "Forbid characters in the list" } },
            { value: "allowed", label: { fr: "Autoriser uniquement les caractères de la liste", en: "Allow only characters in the list" } }
        ];
    }

    function caseOptions() {
        return [
            { value: "none", label: { fr: "Ne pas modifier la casse", en: "Do not change case" } },
            { value: "upper", label: { fr: "TOUT EN MAJUSCULES", en: "ALL UPPERCASE" } },
            { value: "first-upper", label: { fr: "Première lettre en majuscule", en: "First letter uppercase" } },
            { value: "lower", label: { fr: "tout en minuscules", en: "all lowercase" } }
        ];
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Règles de saisie", en: "Input rules" },
            description: {
                fr: "Aide à saisir des valeurs conformes dans les champs que vous choisissez : caractères acceptés, majuscules ou minuscules et format des prix. Chaque règle s’applique à une page et à un champ précis ; les prix d’achat et de remplacement des exemplaires sont préconfigurés.",
                en: "Helps staff enter consistent values in selected fields: allowed characters, letter case and price format. Each rule targets a page and a field; item purchase and replacement prices are preconfigured."
            },
            category: { fr: "Interface / saisie", en: "Interface / input" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer les règles de saisie", en: "Enable input rules" } }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Règles de saisie", en: "Input rules" },
                    description: {
                        fr: "Ajoute autant de règles que nécessaire. Pour chaque règle, indique la page puis choisis directement le champ Koha. Les règles sont appliquées dans l’ordre affiché.",
                        en: "Add as many rules as needed. For each rule, specify the page then select the Koha field directly. Rules are applied in the displayed order."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Règles", en: "Rules" },
                            addLabel: { fr: "Ajouter une règle", en: "Add rule" },
                            emptyLabel: { fr: "Aucune règle configurée.", en: "No configured rule." },
                            reorder: true,
                            newItem: newRule,
                            itemTitle: function (item, index) {
                                return String(item && (item.label || item.targetName || item.targetSelector) || "").trim() || "Règle " + (index + 1);
                            },
                            liveTitleKey: "label",
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de la règle", en: "Rule name" } },
                                {
                                    key: "pagePath",
                                    type: "text",
                                    label: { fr: "Page Koha", en: "Koha page" },
                                    help: {
                                        fr: "Chemin de la page, par exemple /cgi-bin/koha/tools/batchMod.pl. Laisser vide ou saisir * pour toutes les pages. Le picker ouvre cette page avant la sélection.",
                                        en: "Page path, for example /cgi-bin/koha/tools/batchMod.pl. Leave blank or use * for all pages. The picker opens this page before selection."
                                    }
                                },
                                {
                                    key: "targetSelector",
                                    type: "elementPicker",
                                    label: { fr: "Champ de saisie Koha", en: "Koha input field" },
                                    pickLabel: { fr: "Choisir le champ sur la page", en: "Choose the field on the page" },
                                    emptyLabel: { fr: "Aucun champ choisi", en: "No field selected" },
                                    allowManual: true,
                                    pick: pickTarget,
                                    onPick: applyPickerMetadata,
                                    help: {
                                        fr: "Choisis directement un input, textarea ou champ éditable. Le mode manuel reste disponible en avancé.",
                                        en: "Select an input, textarea or editable field directly. Manual selector entry remains available in advanced mode."
                                    }
                                },
                                { key: "targetName", type: "text", readOnly: true, advanced: true, label: { fr: "Champ détecté", en: "Detected field" } },
                                {
                                    key: "characterMode",
                                    type: "select",
                                    label: { fr: "Règle de caractères", en: "Character rule" },
                                    options: modeOptions()
                                },
                                {
                                    key: "preset",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Liste prédéfinie", en: "Preset list" },
                                    options: presetOptions(),
                                    help: {
                                        fr: "Le sens de la liste dépend de l’option précédente : interdite ou seule liste autorisée.",
                                        en: "The list is interpreted according to the previous option: forbidden, or the only allowed characters."
                                    }
                                },
                                {
                                    key: "characters",
                                    type: "textarea",
                                    label: { fr: "Caractères personnalisés", en: "Custom characters" },
                                    when: function (root, path) {
                                        const rule = ruleAt(root, path);
                                        return Boolean(rule && rule.preset === "custom");
                                    },
                                    help: {
                                        fr: "Saisis directement les caractères, sans séparateur. Exemple : 0123456789.-",
                                        en: "Enter characters directly, with no separator. Example: 0123456789.-"
                                    }
                                },
                                {
                                    key: "priceDecimals",
                                    type: "number",
                                    min: 0,
                                    max: 6,
                                    label: { fr: "Nombre maximal de décimales", en: "Maximum decimal places" },
                                    when: function (root, path) {
                                        const rule = ruleAt(root, path);
                                        return Boolean(rule && rule.preset === "price");
                                    },
                                    help: {
                                        fr: "Pour le preset Prix, seuls les chiffres et un unique point décimal sont acceptés. La virgule est refusée. Par défaut : 2 décimales.",
                                        en: "For the Price preset, only digits and a single decimal point are accepted. Commas are rejected. Default: 2 decimal places."
                                    }
                                },
                                {
                                    key: "caseMode",
                                    type: "select",
                                    label: { fr: "Casse automatique", en: "Automatic case" },
                                    options: caseOptions()
                                },
                                { key: "showMessage", type: "boolean", refreshOnChange: true, label: { fr: "Informer quand une saisie est refusée", en: "Show a message when input is rejected" } },
                                {
                                    key: "messageFr",
                                    type: "text",
                                    label: { fr: "Message — français", en: "Message — French" },
                                    when: function (root, path) {
                                        const rule = ruleAt(root, path);
                                        return Boolean(rule && rule.showMessage !== false);
                                    },
                                    help: { fr: "Laisser vide pour utiliser le message automatique.", en: "Leave blank to use the automatic message." }
                                },
                                {
                                    key: "messageEn",
                                    type: "text",
                                    label: { fr: "Message — anglais", en: "Message — English" },
                                    when: function (root, path) {
                                        const rule = ruleAt(root, path);
                                        return Boolean(rule && rule.showMessage !== false);
                                    },
                                    help: { fr: "Laisser vide pour utiliser le message automatique.", en: "Leave blank to use the automatic message." }
                                },
                                {
                                    key: "messageDurationMs",
                                    type: "number",
                                    advanced: true,
                                    label: { fr: "Durée du message (ms)", en: "Message duration (ms)" }
                                }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main) {
                if (!main) return;
                const section = main.querySelector('[data-pmk-section-id="rules"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    let currentConfig = normalizeConfig(DEFAULT_CONFIG);
    let unsubscribe = null;

    function refreshConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULT_CONFIG);
        mountContextAccess();
    }

    function registerDefinition() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        window.PMKConfig.registerModule(moduleDefinition());
        return true;
    }

    async function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            refreshConfig(DEFAULT_CONFIG);
            return;
        }
        try {
            const config = await window.PMKConfig.getConfig(MODULE_ID);
            refreshConfig(config);
        } catch (_) {
            refreshConfig(DEFAULT_CONFIG);
        }

        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, refreshConfig);
        }
    }

    function matchingElementsForCurrentPage() {
        const found = [];
        const seen = new Set();
        (currentConfig.rules || []).forEach(function (rule) {
            if (!rule || rule.enabled === false || !pageMatches(rule) || !rule.targetSelector) return;
            try {
                document.querySelectorAll(rule.targetSelector).forEach(function (element) {
                    if (!seen.has(element) && isEditableTarget(element)) {
                        seen.add(element);
                        found.push(element);
                    }
                });
            } catch (_) {}
        });
        return found;
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const elements = matchingElementsForCurrentPage();
        if (!elements.length) return;
        const first = elements[0];
        const anchor = first.closest("li, .form-group, .mb-3, .row") || first.parentElement || first;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: CONTEXT_KEY + "-" + pageKey(window.location.pathname),
                context: { sectionId: "rules" }
            });
        } catch (_) {}
    }

    function start() {
        ensureStyles();
        bindDelegatedEvents();
        registerDefinition();
        registerPickerAdapter();
        loadConfig();
        window.setTimeout(mountContextAccess, 0);
        window.setTimeout(mountContextAccess, 800);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }

    window.addEventListener("pmk:config-ready", function () {
        registerDefinition();
        registerPickerAdapter();
        loadConfig();
    });

    window.PMK048InputRules = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULT_CONFIG),
        presets: clone(PRESETS),
        normalize: normalizeConfig,
        refresh: function () { refreshConfig(currentConfig); },
        testValue: function (value, rule) {
            const normalized = normalizeRule(rule || newRule(), 0);
            return transformValue(value, [normalized], false);
        },
        diagnose: function () {
            return {
                version: MODULE_VERSION,
                enabled: currentConfig.enabled !== false,
                page: window.location.pathname,
                priceSelector: PRICE_SELECTOR,
                matchingPriceFields: document.querySelectorAll(PRICE_SELECTOR).length,
                matchingConfiguredFields: matchingElementsForCurrentPage().length,
                rules: (currentConfig.rules || []).map(function (rule) {
                    let matches = 0;
                    try { matches = pageMatches(rule) && rule.targetSelector ? document.querySelectorAll(rule.targetSelector).length : 0; } catch (_) {}
                    return { id: rule.id, enabled: rule.enabled !== false, label: rule.label, selector: rule.targetSelector, matches: matches };
                })
            };
        }
    };
})();

;window.PMKNonPlugin.loaded.push("048-forbid-accents-batchmod.js");
} catch (error) { window.PMKNonPlugin.errors.push("048-forbid-accents-batchmod.js: "+error.message); console.error("[PMK] 048-forbid-accents-batchmod.js",error); };
try {
/*
 Nom du fichier: 049-astrological-sign.js
 Version: 2.1.0-pmk-universal
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha
 Description:
   Affiche le signe astrologique occidental calculé depuis la date de naissance
   sur la fiche lecteur Koha (moremember.pl).

   Refonte préparatoire PimpMyKoha :
   - conserve les bornes historiques des 12 signes ;
   - s'appuie sur l'âge natif Koha (.age_years), sans recalculer l'âge ;
   - vrai affichage/masquage accessible au clavier ;
   - FR/EN ;
   - détection prudente des formats de date Koha courants ;
   - idempotent, sans doublon d'élément ni d'événement ;
   - MutationObserver limité au bloc lecteur ;
   - configuration via PMKConfig, avec valeurs par défaut locales en secours ;
   - aucun console.* et aucun appel réseau propre au module.
*/
(function () {
    "use strict";

    const MODULE_ID = "patron-astrological-sign";
    const PAGE_ID = "members.moremember";
    const PAGE_PATH = "/cgi-bin/koha/members/moremember.pl";
    const SCRIPT_GUARD = "__pmk049AstrologicalSignV2";
    const SIGN_ATTR = "data-koha-astro-sign";
    const TOGGLE_ATTR = "data-koha-astro-toggle";
    const BOUND_ATTR = "data-koha-astro-bound";
    const STYLE_ID = "pmk-049-astrological-sign-style";

    if (window[SCRIPT_GUARD]) return;

    /*
     * Important : sur une page non concernée, retour immédiat.
     * La définition d'administration du module est pré-enregistrée par le 000 PMK.
     */
    window[SCRIPT_GUARD] = true;

    const DEFAULTS = {
        enabled: true,
        page: {
            enabled: true,
            pageId: PAGE_ID,
            path: PAGE_PATH
        },
        displayMode: "toggle",
        language: "auto"
    };

    const SIGNS = [
        { key: "capricorn", fr: "Capricorne", en: "Capricorn" },
        { key: "aquarius", fr: "Verseau", en: "Aquarius" },
        { key: "pisces", fr: "Poissons", en: "Pisces" },
        { key: "aries", fr: "Bélier", en: "Aries" },
        { key: "taurus", fr: "Taureau", en: "Taurus" },
        { key: "gemini", fr: "Gémeaux", en: "Gemini" },
        { key: "cancer", fr: "Cancer", en: "Cancer" },
        { key: "leo", fr: "Lion", en: "Leo" },
        { key: "virgo", fr: "Vierge", en: "Virgo" },
        { key: "libra", fr: "Balance", en: "Libra" },
        { key: "scorpio", fr: "Scorpion", en: "Scorpio" },
        { key: "sagittarius", fr: "Sagittaire", en: "Sagittarius" }
    ];

    const SIGN_BY_KEY = SIGNS.reduce(function (map, sign) {
        map[sign.key] = sign;
        return map;
    }, Object.create(null));

    const boundElements = new Map();
    let observer = null;
    let currentTarget = null;
    let currentConfig = clone(DEFAULTS);
    let refreshQueued = false;
    let configRevision = 0;
    let subscriptionReceived = false;

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function mergeConfig(base, extra) {
        const out = clone(base);
        const src = extra && typeof extra === "object" ? extra : {};

        Object.keys(src).forEach(function (key) {
            if (
                src[key] &&
                typeof src[key] === "object" &&
                !Array.isArray(src[key]) &&
                out[key] &&
                typeof out[key] === "object" &&
                !Array.isArray(out[key])
            ) {
                out[key] = Object.assign({}, out[key], src[key]);
            } else {
                out[key] = src[key];
            }
        });

        return out;
    }

    function normalizeConfig(config) {
        const value = mergeConfig(DEFAULTS, config || {});
        value.enabled = value.enabled !== false;
        value.page = Object.assign({}, DEFAULTS.page, value.page || {});
        value.page.enabled = value.page.enabled !== false;
        value.page.pageId = PAGE_ID;
        value.page.path = PAGE_PATH;
        if (!["toggle", "always"].includes(value.displayMode)) value.displayMode = DEFAULTS.displayMode;
        if (!["auto", "fr", "en"].includes(value.language)) value.language = DEFAULTS.language;
        return value;
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function languageOf(config) {
        if (config.language === "fr" || config.language === "en") return config.language;

        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try {
                const detected = String(api.getLanguage() || "").toLowerCase();
                if (detected.startsWith("en")) return "en";
                if (detected.startsWith("fr")) return "fr";
            } catch (_) {}
        }

        const htmlLang = String(document.documentElement.getAttribute("lang") || "").toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function labels(config) {
        const lang = languageOf(config);
        return lang === "en"
            ? {
                title: "Show / hide astrological sign",
                show: "Show astrological sign",
                hide: "Hide astrological sign"
            }
            : {
                title: "Afficher / masquer le signe astrologique",
                show: "Afficher le signe astrologique",
                hide: "Masquer le signe astrologique"
            };
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk-astro049-toggle {
                cursor: pointer;
                text-decoration-line: underline;
                text-decoration-style: dotted;
                text-decoration-thickness: from-font;
                text-underline-offset: .14em;
            }
            .pmk-astro049-toggle:focus-visible {
                outline: 2px solid currentColor;
                outline-offset: 2px;
                border-radius: .2rem;
            }
            .pmk-astro049-sign {
                display: inline;
                margin-inline-start: .3rem;
                white-space: normal;
            }
            .pmk-astro049-sign[hidden] {
                display: none !important;
            }
        `;
        document.head.appendChild(style);
    }

    function removeStylesIfUnused() {
        if (document.querySelector("[" + SIGN_ATTR + "]")) return;
        const style = document.getElementById(STYLE_ID);
        if (style) style.remove();
    }

    function rawKohaDateFormat() {
        const candidates = [
            window.dateformat,
            window.DateFormat,
            window.kohaDateFormat,
            document.documentElement.getAttribute("data-dateformat"),
            document.body && document.body.getAttribute("data-dateformat")
        ];

        for (let i = 0; i < candidates.length; i += 1) {
            const value = String(candidates[i] == null ? "" : candidates[i]).trim().toLowerCase();
            if (value) return value;
        }
        return "";
    }

    function preferredDateOrder() {
        const value = rawKohaDateFormat();
        if (/(^|[^a-z])(us|mdy|mm[\/.-]dd)([^a-z]|$)/.test(value)) return "mdy";
        if (/(iso|rfc|ymd|yyyy)/.test(value)) return "ymd";
        if (/(metric|dmy|dd[\/.-]mm|dmydot)/.test(value)) return "dmy";
        return "dmy";
    }

    function makeValidatedDate(year, month, day) {
        year = Number(year);
        month = Number(month);
        day = Number(day);

        if (!Number.isInteger(year) || year < 1000 || year > 9999) return null;
        if (!Number.isInteger(month) || month < 1 || month > 12) return null;
        if (!Number.isInteger(day) || day < 1 || day > 31) return null;

        const date = new Date(year, month - 1, day);
        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) return null;

        return { year: year, month: month, day: day };
    }

    function parseDateFromText(text) {
        const source = String(text || "").replace(/\u00a0/g, " ");

        /* Formats année en premier : 2026-09-19, 2026/09/19, 2026.09.19 */
        let match = source.match(/(?:^|\D)(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})(?!\d)/);
        if (match) return makeValidatedDate(match[1], match[2], match[3]);

        /* Formats jour/mois ou mois/jour. */
        match = source.match(/(?:^|\D)(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})(?!\d)/);
        if (!match) return null;

        const first = Number(match[1]);
        const second = Number(match[2]);
        const year = Number(match[3]);
        let month;
        let day;

        if (first > 12 && second <= 12) {
            day = first;
            month = second;
        } else if (second > 12 && first <= 12) {
            month = first;
            day = second;
        } else if (preferredDateOrder() === "mdy") {
            month = first;
            day = second;
        } else {
            day = first;
            month = second;
        }

        return makeValidatedDate(year, month, day);
    }

    function birthDateForAge(ageSpan) {
        if (currentTarget && currentTarget.birthSelector) {
            try {
                const source = document.querySelector(currentTarget.birthSelector);
                return source ? parseDateFromText(source.value || source.getAttribute("datetime") || source.textContent || "") : null;
            } catch (_) { return null; }
        }
        const row = ageSpan.closest("li") || ageSpan.parentElement;
        if (!row) return null;

        const cloneNode = row.cloneNode(true);
        cloneNode.querySelectorAll(
            ".age_years, [" + SIGN_ATTR + "], .pmk-context-config"
        ).forEach(function (element) {
            element.remove();
        });

        return parseDateFromText(cloneNode.textContent || "");
    }

    function signKeyFor(day, month) {
        if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return "aquarius";
        if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return "pisces";
        if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return "aries";
        if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return "taurus";
        if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return "gemini";
        if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return "cancer";
        if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return "leo";
        if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return "virgo";
        if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return "libra";
        if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return "scorpio";
        if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return "sagittarius";
        if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return "capricorn";
        return null;
    }

    function signText(key, config) {
        const sign = SIGN_BY_KEY[key];
        if (!sign) return "";
        return languageOf(config) === "en" ? sign.en : sign.fr;
    }

    function uniqueSignId(ageSpan) {
        const existingId = ageSpan.getAttribute("data-pmk-astro-sign-id");
        if (existingId && !document.getElementById(existingId)) return existingId;

        const base = "pmk-astro049-sign";
        let n = 1;
        let candidate = base;
        while (document.getElementById(candidate)) {
            n += 1;
            candidate = base + "-" + n;
        }
        ageSpan.setAttribute("data-pmk-astro-sign-id", candidate);
        return candidate;
    }

    function setVisible(ageSpan, signSpan, visible, config) {
        const ui = labels(config);
        signSpan.hidden = !visible;
        signSpan.setAttribute("aria-hidden", visible ? "false" : "true");
        ageSpan.setAttribute("aria-expanded", visible ? "true" : "false");
        ageSpan.setAttribute("aria-label", visible ? ui.hide : ui.show);
        ageSpan.title = ui.title;
    }

    function restoreAttribute(element, name, value) {
        if (value == null) element.removeAttribute(name);
        else element.setAttribute(name, value);
    }

    function clearBinding(ageSpan) {
        const binding = boundElements.get(ageSpan);
        if (binding) {
            try { ageSpan.removeEventListener("click", binding.click); } catch (_) {}
            try { ageSpan.removeEventListener("keydown", binding.keydown); } catch (_) {}

            restoreAttribute(ageSpan, "role", binding.original.role);
            restoreAttribute(ageSpan, "tabindex", binding.original.tabindex);
            restoreAttribute(ageSpan, "aria-expanded", binding.original.ariaExpanded);
            restoreAttribute(ageSpan, "aria-controls", binding.original.ariaControls);
            restoreAttribute(ageSpan, "aria-label", binding.original.ariaLabel);
            restoreAttribute(ageSpan, "title", binding.original.title);
            boundElements.delete(ageSpan);
        } else if (ageSpan.hasAttribute(BOUND_ATTR)) {
            ageSpan.removeAttribute("role");
            ageSpan.removeAttribute("tabindex");
            ageSpan.removeAttribute("aria-expanded");
            ageSpan.removeAttribute("aria-controls");
            ageSpan.removeAttribute("aria-label");
            ageSpan.removeAttribute("title");
        }

        ageSpan.removeAttribute(TOGGLE_ATTR);
        ageSpan.removeAttribute(BOUND_ATTR);
        ageSpan.removeAttribute("data-pmk-astro-sign-id");
        ageSpan.classList.remove("pmk-astro049-toggle");
    }

    function removeExistingSign(ageSpan) {
        const row = ageSpan.closest("li") || ageSpan.parentElement;
        if (!row) return;
        row.querySelectorAll("[" + SIGN_ATTR + "]").forEach(function (sign) {
            sign.remove();
        });
    }

    function cleanup() {
        Array.from(boundElements.keys()).forEach(clearBinding);
        document.querySelectorAll("[" + TOGGLE_ATTR + "]").forEach(clearBinding);
        document.querySelectorAll("[" + SIGN_ATTR + "]").forEach(function (sign) {
            sign.remove();
        });
        removeStylesIfUnused();
    }

    function decorate(ageSpan, config) {
        if (!ageSpan || !(ageSpan instanceof Element)) return;

        clearBinding(ageSpan);
        removeExistingSign(ageSpan);

        const birth = birthDateForAge(ageSpan);
        if (!birth) return;

        const key = signKeyFor(birth.day, birth.month);
        const value = signText(key, config);
        if (!key || !value) return;

        injectStyles();

        const signSpan = document.createElement("span");
        const signId = uniqueSignId(ageSpan);
        signSpan.id = signId;
        signSpan.className = "pmk-astro049-sign";
        signSpan.setAttribute(SIGN_ATTR, "1");
        signSpan.setAttribute("data-koha-astro-key", key);
        signSpan.textContent = value;

        ageSpan.insertAdjacentElement("afterend", signSpan);

        if (config.displayMode === "always") {
            signSpan.hidden = false;
            signSpan.setAttribute("aria-hidden", "false");
            return;
        }

        // Capturer les attributs Koha AVANT toute modification pour une restitution fidèle.
        const original = {
            role: ageSpan.getAttribute("role"),
            tabindex: ageSpan.getAttribute("tabindex"),
            ariaExpanded: ageSpan.getAttribute("aria-expanded"),
            ariaControls: ageSpan.getAttribute("aria-controls"),
            ariaLabel: ageSpan.getAttribute("aria-label"),
            title: ageSpan.getAttribute("title")
        };

        ageSpan.setAttribute(TOGGLE_ATTR, "1");
        ageSpan.setAttribute(BOUND_ATTR, "1");
        ageSpan.setAttribute("role", "button");
        ageSpan.setAttribute("tabindex", "0");
        ageSpan.setAttribute("aria-controls", signId);
        ageSpan.classList.add("pmk-astro049-toggle");

        const toggle = function () {
            setVisible(ageSpan, signSpan, signSpan.hidden, config);
        };
        const keydown = function (event) {
            if (event.key !== "Enter" && event.key !== " ") return;
            event.preventDefault();
            toggle();
        };
        const click = function (event) {
            event.preventDefault();
            toggle();
        };

        ageSpan.addEventListener("click", click);
        ageSpan.addEventListener("keydown", keydown);
        boundElements.set(ageSpan, { click: click, keydown: keydown, original: original });
        setVisible(ageSpan, signSpan, false, config);
    }

    function refresh() {
        cleanup();

        if (!currentConfig.enabled) { stopObserver(); return; }
        const targets = Array.isArray(currentConfig.targets) ? currentConfig.targets : [];
        const applicable = targets.filter(target => target.enabled !== false && target.pagePath === window.location.pathname);
        if (currentConfig.page.enabled !== false && window.location.pathname === currentConfig.page.path) {
            applicable.unshift({targetSelector: ".age_years"});
        }
        const decorated = new Set();
        applicable.forEach(target => {
            currentTarget = target;
            let nodes = [];
            try { nodes = document.querySelectorAll(target.targetSelector); } catch (_) {}
            nodes.forEach(node => { if (!decorated.has(node)) { decorate(node, currentConfig); decorated.add(node); } });
        });
        currentTarget = null;
        if (!applicable.length) { stopObserver(); return; }

        startObserver();
    }

    function onBirthInput(event) {
        const source = event.target;
        if (!(source instanceof Element)) return;
        const relevant = (currentConfig.targets || []).some(target => {
            if (target.enabled === false || target.pagePath !== window.location.pathname) return false;
            try { return source.matches(target.birthSelector); } catch (_) { return false; }
        });
        if (relevant) scheduleRefresh();
    }
    document.addEventListener("input", onBirthInput, true);
    document.addEventListener("change", onBirthInput, true);

    function scheduleRefresh() {
        if (refreshQueued) return;
        refreshQueued = true;
        Promise.resolve().then(function () {
            refreshQueued = false;
            refresh();
        });
    }

    function startObserver() {
        if (observer) return;
        const root = document.getElementById("patron-information") || document.body;
        if (!root) return;

        observer = new MutationObserver(function (mutations) {
            let needsRefresh = false;

            for (let i = 0; i < mutations.length && !needsRefresh; i += 1) {
                const added = mutations[i].addedNodes;
                for (let j = 0; j < added.length; j += 1) {
                    const node = added[j];
                    if (!(node instanceof Element)) continue;
                    const selectors = [".age_years"].concat((currentConfig.targets || []).filter(t => t.enabled !== false && t.pagePath === window.location.pathname).map(t => t.targetSelector)).filter(Boolean);
                    if (selectors.some(selector => { try { return node.matches(selector) || node.querySelector(selector); } catch (_) { return false; } })) {
                        needsRefresh = true;
                        break;
                    }
                }
            }

            if (needsRefresh) scheduleRefresh();
        });

        observer.observe(root, { childList: true, subtree: true });
    }

    function stopObserver() {
        if (!observer) return;
        try { observer.disconnect(); } catch (_) {}
        observer = null;
    }

    function mountConfigShortcut() {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;

        const heading = document.querySelector("#patron-information .patroninfo-heading");
        if (!heading) return;

        api.mountContextButton({
            moduleId: MODULE_ID,
            anchor: heading,
            position: "append",
            contextKey: PAGE_ID,
            context: {
                sectionId: "display",
                pageId: PAGE_ID
            }
        });
    }

    function useConfig(config) {
        currentConfig = normalizeConfig(config);
        refresh();
        mountConfigShortcut();
    }

    function connectPmkConfig() {
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            useConfig(DEFAULTS);
            return false;
        }

        mountConfigShortcut();

        const initialRevision = configRevision;
        try {
            if (typeof api.subscribe === "function") {
                api.subscribe(MODULE_ID, function (config) {
                    subscriptionReceived = true;
                    configRevision += 1;
                    useConfig(config);
                });
            }
        } catch (_) {}

        Promise.resolve().then(function () { return api.getConfig(MODULE_ID); })
            .then(function (config) {
                // Une notification plus récente a priorité sur une lecture initiale tardive.
                if (subscriptionReceived || configRevision !== initialRevision) return;
                useConfig(config);
            })
            .catch(function () {
                // En cas de panne du stockage, ne pas écraser une configuration déjà reçue.
                if (!subscriptionReceived && configRevision === initialRevision) {
                    useConfig(DEFAULTS);
                }
            });

        return true;
    }

    function start() {
        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("049-astrological-sign.js");
} catch (error) { window.PMKNonPlugin.errors.push("049-astrological-sign.js: "+error.message); console.error("[PMK] 049-astrological-sign.js",error); };
try {
/*
 Nom du fichier: 050-line-counter.js
 Version: 3.2.0-pmk-isolated
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha / refonte préparatoire PimpMyKoha
 Description:
   Compteur compact pour les champs Koha contenant une liste multi-lignes.

   Refonte préparatoire PimpMyKoha :
   - conserve les deux usages historiques : batchMod.pl et guided_reports.pl ;
   - compte les lignes non vides, les valeurs uniques et les doublons ;
   - traite toutes les zones sql_params d'un rapport, pas seulement la première ;
   - ajoute deux adaptateurs préparés mais désactivés : inventaire et prêt par lot ;
   - permet d'ajouter librement d'autres pages Koha et d'autres zones multiligne depuis la configuration PMK ;
   - configuration via PMKConfig, avec valeurs par défaut locales en secours ;
   - affichage compact, responsive, FR/EN et intégré visuellement à Koha ;
   - idempotent : pas de compteur ni d'événement dupliqué ;
   - aucun console.* et aucun appel réseau propre au module.
*/
(function () {
    "use strict";

    const MODULE_ID = "multiline-list-counter";
    const SCRIPT_GUARD = "__pmk050MultilineListCounterV3";
    const STYLE_ID = "pmk050-line-counter-style";
    const COUNTER_ATTR = "data-pmk050-counter";
    const BOUND_ATTR = "data-pmk050-bound";
    const DESCRIBEDBY_ATTR = "data-pmk050-describedby-added";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const DEFAULTS = {
        enabled: true,
        display: {
            showTotal: true,
            showUnique: true,
            showDuplicates: true,
            hideZeroDuplicates: true
        },
        pages: [
            {
                id: "tools.batchmod",
                enabled: true,
                path: "/cgi-bin/koha/tools/batchMod.pl",
                query: "",
                labelFr: "Modification d'exemplaires par lot",
                labelEn: "Batch item modification",
                fields: [
                    {
                        id: "barcodelist",
                        enabled: true,
                        labelFr: "Liste de codes-barres",
                        labelEn: "Barcode list",
                        selector: "#barcodelist",
                        multiple: false
                    }
                ]
            },
            {
                id: "reports.guided_reports",
                enabled: true,
                path: "/cgi-bin/koha/reports/guided_reports.pl",
                query: "",
                labelFr: "Rapports",
                labelEn: "Reports",
                fields: [
                    {
                        id: "sql-list-parameters",
                        enabled: true,
                        labelFr: "Paramètres de type liste",
                        labelEn: "List parameters",
                        selector: "textarea[name=\"sql_params\"]",
                        multiple: true
                    }
                ]
            },
            {
                id: "tools.inventory",
                enabled: false,
                path: "/cgi-bin/koha/tools/inventory.pl",
                query: "",
                labelFr: "Inventaire",
                labelEn: "Inventory",
                fields: [
                    {
                        id: "barcodelist",
                        enabled: true,
                        labelFr: "Liste de codes-barres",
                        labelEn: "Barcode list",
                        selector: "#barcodelist",
                        multiple: false
                    }
                ]
            },
            {
                id: "circ.batch_checkouts",
                enabled: false,
                path: "/cgi-bin/koha/circ/circulation.pl",
                query: "batch=1",
                labelFr: "Prêt par lot",
                labelEn: "Batch checkout",
                fields: [
                    {
                        id: "barcodelist",
                        enabled: true,
                        labelFr: "Liste de codes-barres",
                        labelEn: "Barcode list",
                        selector: "#barcodelist",
                        multiple: false
                    }
                ]
            }
        ]
    };


    let currentConfig = clone(DEFAULTS);
    let observer = null;
    let observerTimer = 0;
    let configSubscribed = false;

    const bindings = new Map();

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function deepMerge(target, source) {
        const out = target && typeof target === "object" ? target : {};
        if (!source || typeof source !== "object") return out;

        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) {
                out[key] = clone(value);
            } else if (value && typeof value === "object") {
                const base = out[key] && typeof out[key] === "object" && !Array.isArray(out[key]) ? out[key] : {};
                out[key] = deepMerge(base, value);
            } else {
                out[key] = value;
            }
        });
        return out;
    }

    function normalizeField(field, pageIndex, fieldIndex) {
        const fallback = {
            id: "field-" + (pageIndex + 1) + "-" + (fieldIndex + 1),
            enabled: true,
            labelFr: "Champ de liste",
            labelEn: "List field",
            selector: "",
            multiple: false
        };
        const value = deepMerge(fallback, field && typeof field === "object" ? clone(field) : {});
        value.id = String(value.id || fallback.id);
        value.enabled = value.enabled !== false;
        value.labelFr = String(value.labelFr || "").trim();
        value.labelEn = String(value.labelEn || "").trim();
        value.selector = String(value.selector || "").trim();
        value.multiple = value.multiple === true;
        return value;
    }

    function normalizePage(page, index) {
        const fallback = DEFAULTS.pages[index] || {
            id: "page-" + (index + 1),
            enabled: false,
            path: "",
            query: "",
            labelFr: "Page Koha",
            labelEn: "Koha page",
            fields: []
        };
        const value = deepMerge(clone(fallback), page && typeof page === "object" ? clone(page) : {});
        value.id = String(value.id || fallback.id);
        value.enabled = value.enabled !== false;
        value.path = String(value.path || fallback.path || "").trim();
        value.query = String(value.query || "").trim();
        value.labelFr = String(value.labelFr || fallback.labelFr || "").trim();
        value.labelEn = String(value.labelEn || fallback.labelEn || "").trim();
        value.fields = Array.isArray(value.fields)
            ? value.fields.map(function (field, fieldIndex) { return normalizeField(field, index, fieldIndex); })
            : clone(fallback.fields || []).map(function (field, fieldIndex) { return normalizeField(field, index, fieldIndex); });
        return value;
    }

    function normalizeConfig(config) {
        const merged = deepMerge(clone(DEFAULTS), config && typeof config === "object" ? clone(config) : {});
        merged.enabled = merged.enabled !== false;
        merged.display = deepMerge(clone(DEFAULTS.display), merged.display || {});
        merged.display.showTotal = merged.display.showTotal !== false;
        merged.display.showUnique = merged.display.showUnique !== false;
        merged.display.showDuplicates = merged.display.showDuplicates !== false;
        merged.display.hideZeroDuplicates = merged.display.hideZeroDuplicates !== false;

        const incomingPages = Array.isArray(merged.pages) ? merged.pages : [];
        merged.pages = incomingPages.map(function (page, index) {
            const knownIndex = DEFAULTS.pages.findIndex(candidate=>candidate.id === page.id);
            return normalizePage(page,knownIndex < 0 ? DEFAULTS.pages.length + index : knownIndex);
        });

        return merged;
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try {
                const detected = String(api.getLanguage() || "").toLowerCase();
                if (detected.startsWith("en")) return "en";
                if (detected.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        return String(document.documentElement.getAttribute("lang") || "").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function labels() {
        if (language() === "en") {
            return {
                valueOne: "value",
                valueMany: "values",
                uniqueOne: "unique",
                uniqueMany: "unique",
                duplicateOne: "duplicate",
                duplicateMany: "duplicates"
            };
        }
        return {
            valueOne: "valeur",
            valueMany: "valeurs",
            uniqueOne: "unique",
            uniqueMany: "uniques",
            duplicateOne: "doublon",
            duplicateMany: "doublons"
        };
    }

    function pageMatches(page) {
        if (!page || page.enabled === false || page.path !== window.location.pathname) return false;
        if (!page.query) return true;

        try {
            const expected = new URLSearchParams(page.query);
            const actual = new URLSearchParams(window.location.search);
            for (const pair of expected.entries()) {
                if (actual.get(pair[0]) !== pair[1]) return false;
            }
            return true;
        } catch (_) {
            return false;
        }
    }

    function currentPageConfig(config) {
        if (!config || !Array.isArray(config.pages)) return null;
        return config.pages.find(pageMatches) || null;
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk050-counter {
                display: inline-flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .12rem .38rem;
                width: fit-content;
                max-width: 100%;
                margin: .22rem 0 .38rem;
                padding: .16rem .42rem;
                border: 1px solid rgba(0,0,0,.09);
                border-radius: .35rem;
                background: rgba(0,0,0,.025);
                color: var(--bs-secondary-color, #59636d);
                font-size: .79rem;
                line-height: 1.25;
                vertical-align: middle;
                box-sizing: border-box;
            }
            .pmk050-counter[hidden] {
                display: none !important;
            }
            .pmk050-stats {
                display: inline-flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .12rem .38rem;
                min-width: 0;
            }
            .pmk050-stat {
                display: inline-flex;
                align-items: baseline;
                gap: .18rem;
                min-width: 0;
                white-space: nowrap;
            }
            .pmk050-stat + .pmk050-stat::before {
                content: "·";
                margin-inline-end: .18rem;
                color: rgba(0,0,0,.35);
                font-weight: 400;
            }
            .pmk050-stat strong {
                color: var(--bs-body-color, #212529);
                font-size: .86rem;
                font-weight: 650;
            }
            .pmk050-stat.pmk050-duplicates.is-positive {
                color: var(--bs-warning-text-emphasis, #744c00);
            }
            .pmk050-stat.pmk050-duplicates.is-positive strong {
                color: inherit;
            }
            .pmk050-counter .pmk-context-config {
                margin: 0 0 0 .05rem !important;
                padding: 0 .12rem !important;
                min-width: 1.35rem;
                min-height: 1.35rem;
                line-height: 1.1;
                font-size: .76rem;
                opacity: .62;
                vertical-align: middle;
            }
            .pmk050-counter .pmk-context-config:hover,
            .pmk050-counter .pmk-context-config:focus-visible {
                opacity: 1;
            }
            @media (max-width: 768px) {
                .pmk050-counter {
                    display: flex;
                    width: 100%;
                    gap: .14rem .34rem;
                    font-size: .78rem;
                }
                .pmk050-stat {
                    white-space: normal;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function analyze(value) {
        const lines = String(value || "").split(/\r?\n/);
        let total = 0;
        const unique = new Map();

        lines.forEach(function (line) {
            const normalized = String(line || "").trim();
            if (!normalized) return;
            total += 1;
            unique.set(normalized,(unique.get(normalized)||0)+1);
        });

        const repeated=[];
        let repeatedValues=0;
        for(const [value,count] of unique)if(count>1){repeatedValues++;if(repeated.length<100)repeated.push({value,count});}

        return {
            total: total,
            unique: unique.size,
            duplicates: Math.max(0, total - unique.size),
            repeated, repeatedValues
        };
    }

    function word(count, singular, plural) {
        return count === 1 ? singular : plural;
    }

    function createStat(className) {
        const span = document.createElement("span");
        span.className = "pmk050-stat " + className;

        const count = document.createElement("strong");
        count.className = "pmk050-count";
        const text = document.createElement("span");
        text.className = "pmk050-label";

        span.append(count, text);
        return span;
    }

    function counterId(pageId, fieldId, index) {
        return "pmk050-counter-" + String(pageId + "-" + fieldId + "-" + index)
            .toLowerCase()
            .replace(/[^a-z0-9_-]+/g, "-")
            .replace(/^-+|-+$/g, "");
    }

    function ensureAriaDescription(textarea, counter) {
        if (!textarea || !counter || !counter.id) return;
        const current = String(textarea.getAttribute("aria-describedby") || "").split(/\s+/).filter(Boolean);
        const summaryId=counter.id+'-summary';
        if (!current.includes(summaryId)) {
            current.push(summaryId);
            textarea.setAttribute("aria-describedby", current.join(" "));
            textarea.setAttribute(DESCRIBEDBY_ATTR, summaryId);
        }
    }

    function removeAriaDescription(textarea) {
        if (!textarea) return;
        const added = textarea.getAttribute(DESCRIBEDBY_ATTR);
        if (!added) return;
        const current = String(textarea.getAttribute("aria-describedby") || "")
            .split(/\s+/)
            .filter(Boolean)
            .filter(function (id) { return id !== added; });
        if (current.length) textarea.setAttribute("aria-describedby", current.join(" "));
        else textarea.removeAttribute("aria-describedby");
        textarea.removeAttribute(DESCRIBEDBY_ATTR);
    }

    function renderCounter(binding) {
        if (!binding || !binding.textarea || !binding.counter) return;

        const counts = analyze(binding.textarea.value);
        const l = labels();
        const display = currentConfig.display || DEFAULTS.display;
        const counter = binding.counter;
        let stats = counter.querySelector(".pmk050-stats");
        if (!stats) {
            stats = document.createElement("span");
            stats.className = "pmk050-stats";
            stats.id=counter.id+'-summary';
            stats.setAttribute('role','status');
            counter.prepend(stats);
        }
        stats.replaceChildren();

        if (display.showTotal !== false) {
            const stat = createStat("pmk050-total");
            stat.querySelector(".pmk050-count").textContent = String(counts.total);
            stat.querySelector(".pmk050-label").textContent = word(counts.total, l.valueOne, l.valueMany);
            stats.appendChild(stat);
        }

        if (display.showUnique !== false) {
            const stat = createStat("pmk050-unique");
            stat.querySelector(".pmk050-count").textContent = String(counts.unique);
            stat.querySelector(".pmk050-label").textContent = word(counts.unique, l.uniqueOne, l.uniqueMany);
            stats.appendChild(stat);
        }

        if (display.showDuplicates !== false && !(display.hideZeroDuplicates !== false && counts.duplicates === 0)) {
            const stat = createStat("pmk050-duplicates" + (counts.duplicates > 0 ? " is-positive" : ""));
            stat.querySelector(".pmk050-count").textContent = String(counts.duplicates);
            stat.querySelector(".pmk050-label").textContent = word(counts.duplicates, l.duplicateOne, l.duplicateMany);
            stats.appendChild(stat);
        }

        if (!stats.children.length) {
            counter.hidden = true;
            return;
        }
        counter.hidden = false;

        let comparison=counter.querySelector('.pmk050-comparison');
        if(counts.duplicates>0 && display.showDuplicates!==false){
            if(!comparison){
                comparison=document.createElement('details');comparison.className='pmk050-comparison';
                const summary=document.createElement('summary');summary.textContent=language()==='en'?'Compare duplicates':'Comparer les doublons';comparison.appendChild(summary);counter.appendChild(comparison);
                comparison.addEventListener('toggle',()=>{if(comparison.open)renderComparison(comparison,binding.counts);});
            }
            binding.counts=counts;
            if(comparison.open)renderComparison(comparison,counts);
        }else comparison?.remove();

        mountContextShortcut(binding);
    }

    function renderComparison(details,counts){
        details.querySelector('.pmk050-comparison-body')?.remove();
        const body=document.createElement('div');body.className='pmk050-comparison-body';
        const note=document.createElement('p');note.textContent=language()==='en'?'Leading and trailing spaces are ignored. Case and accents are kept. The input is unchanged.':'Les espaces au début et à la fin sont ignorés. La casse et les accents sont conservés. La saisie reste intacte.';
        const list=document.createElement('ul');list.style.maxHeight='15rem';list.style.overflow='auto';list.style.overflowWrap='anywhere';
        for(const entry of counts.repeated){const row=document.createElement('li');row.textContent=entry.value+' × '+entry.count;list.appendChild(row);}
        body.append(note,list);
        if(counts.repeatedValues>100){const limit=document.createElement('p');limit.textContent=language()==='en'?'First 100 repeated values shown; counts cover the whole list.':'100 premières valeurs répétées affichées ; les compteurs couvrent toute la liste.';body.appendChild(limit);}
        details.appendChild(body);
    }

    function mountContextShortcut(binding) {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function" || !binding || !binding.counter) return;

        api.mountContextButton({
            moduleId: MODULE_ID,
            anchor: binding.counter,
            position: "append",
            contextKey: binding.contextKey,
            context: {
                sectionId: "pages",
                pageId: binding.pageId,
                fieldId: binding.fieldId
            }
        });
    }

    function unbindTextarea(textarea) {
        const binding = bindings.get(textarea);
        if (!binding) return;

        try { textarea.removeEventListener("input", binding.onInput); } catch (_) {}
        removeAriaDescription(textarea);
        textarea.removeAttribute(BOUND_ATTR);

        if (binding.counter && binding.counter.parentNode) {
            binding.counter.remove();
        }
        bindings.delete(textarea);
    }

    function clearBindings() {
        Array.from(bindings.keys()).forEach(unbindTextarea);
        document.querySelectorAll("[" + COUNTER_ATTR + "]").forEach(function (counter) {
            counter.remove();
        });
    }

    function bindTextarea(textarea, page, field, fieldIndex, targetIndex) {
        if (!(textarea instanceof HTMLTextAreaElement)) return;

        const existing = bindings.get(textarea);
        const key = page.id + "|" + field.id + "|" + targetIndex + "|" + (field.displaySelector || "") + "|" + (field.displayPosition || "after");
        if (existing && existing.bindingKey === key) {
            existing.pageId = page.id;
            existing.fieldId = field.id;
            renderCounter(existing);
            return;
        }
        if (existing) unbindTextarea(textarea);

        const counter = document.createElement("div");
        counter.id = counterId(page.id, field.id, targetIndex);
        counter.className = "pmk050-counter";
        counter.setAttribute(COUNTER_ATTR, "1");
        counter.setAttribute("aria-label", language() === "en" ? "List count" : "Comptage de la liste");

        let destination = textarea;
        if (field.displaySelector) { try { destination = document.querySelector(field.displaySelector); } catch (_) { destination = null; } }
        if (!destination || destination === counter || counter.contains(destination)) return;
        const positions = {after:'afterend',before:'beforebegin',append:'beforeend',prepend:'afterbegin'};
        destination.insertAdjacentElement(positions[field.displayPosition] || 'afterend', counter);
        textarea.setAttribute(BOUND_ATTR, key);
        ensureAriaDescription(textarea, counter);

        const binding = {
            textarea: textarea,
            counter: counter,
            bindingKey: key,
            pageId: page.id,
            fieldId: field.id,
            contextKey: page.id + "-" + field.id + "-" + targetIndex,
            onInput: null
        };

        binding.onInput = function () {
            renderCounter(binding);
        };

        textarea.addEventListener("input", binding.onInput);
        bindings.set(textarea, binding);
        renderCounter(binding);
    }

    function safeQueryAll(selector) {
        if (!selector) return [];
        try {
            return Array.from(document.querySelectorAll(selector));
        } catch (_) {
            return [];
        }
    }

    function applyPage(page) {
        if (!page || !Array.isArray(page.fields)) return;

        page.fields.forEach(function (field, fieldIndex) {
            if (!field || field.enabled === false || !field.selector) return;

            const targets = safeQueryAll(field.selector).filter(function (node) {
                return node instanceof HTMLTextAreaElement;
            });
            if (!targets.length) return;

            const selected = field.multiple === true ? targets : targets.slice(0, 1);
            selected.forEach(function (textarea, targetIndex) {
                bindTextarea(textarea, page, field, fieldIndex, targetIndex);
            });
        });
    }

    function refresh() {
        stopObserver();

        if (!currentConfig.enabled) {
            clearBindings();
            return;
        }

        const page = currentPageConfig(currentConfig);
        if (!page) {
            clearBindings();
            return;
        }

        injectStyles();

        /*
         * refresh() est appelé lors d'un changement de configuration : on
         * reconstruit alors les liaisons pour que désactivation, suppression
         * ou changement de cible soient pris en compte immédiatement.
         * Les simples mutations DOM utilisent scheduleRefresh() et ne passent
         * pas ici, ce qui évite le clignotement pendant l'usage normal.
         */
        clearBindings();
        applyPage(page);
        startObserver(page);
    }

    function scheduleRefresh() {
        window.clearTimeout(observerTimer);
        observerTimer = window.setTimeout(function () {
            observerTimer = 0;
            const page = currentPageConfig(currentConfig);
            if (!page || !currentConfig.enabled) return;
            applyPage(page);
        }, 80);
    }

    function startObserver(page) {
        if (!page || observer || typeof MutationObserver !== "function") return;

        const root = document.querySelector("main") || document.body;
        if (!root) return;

        observer = new MutationObserver(function (mutations) {
            let relevant = false;

            for (const mutation of mutations) {
                if (mutation.type !== "childList") continue;
                for (const node of mutation.addedNodes) {
                    if (!(node instanceof Element)) continue;
                    if (node.matches && node.matches("textarea")) {
                        relevant = true;
                        break;
                    }
                    if (node.querySelector && node.querySelector("textarea")) {
                        relevant = true;
                        break;
                    }
                }
                if (relevant) break;
            }

            if (relevant) scheduleRefresh();
        });

        observer.observe(root, { childList: true, subtree: true });
    }

    function stopObserver() {
        if (!observer) return;
        try { observer.disconnect(); } catch (_) {}
        observer = null;
    }

    function useConfig(config) {
        currentConfig = normalizeConfig(config);
        refresh();
    }

    function connectPmkConfig() {
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            useConfig(DEFAULTS);
            return false;
        }

        if (!configSubscribed && typeof api.subscribe === "function") {
            try {
                api.subscribe(MODULE_ID, function (config) {
                    useConfig(config);
                });
                configSubscribed = true;
            } catch (_) {}
        }

        api.getConfig(MODULE_ID)
            .then(useConfig)
            .catch(function () {
                useConfig(DEFAULTS);
            });

        return true;
    }

    function start() {
        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("050-line-counter.js");
} catch (error) { window.PMKNonPlugin.errors.push("050-line-counter.js: "+error.message); console.error("[PMK] 050-line-counter.js",error); };
try {
/*
 Nom du fichier: 051-alert-doc-retour-perdu.js
 Version: 3.0.0-pmk-isolated
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha
 Description:
   Contrôle le statut « non prêtable » d'un exemplaire lorsqu'un document
   précédemment perdu est retrouvé au retour (circ/returns.pl).

   Refonte préparatoire PimpMyKoha :
   - détecte l'événement Koha LOST -> retrouvé via .ret_checkedin ;
   - ne dépend plus d'une phrase française codée en dur ;
   - relit l'exemplaire via l'API REST Koha avant toute décision ;
   - tient compte du NOT_LOAN final, donc après la logique native Koha ;
   - règles configurables à partir des valeurs autorisées LOST / NOT_LOAN ;
   - modes par NOT_LOAN : conserver, demander, remettre disponible ;
   - remise disponible via l'API REST native Koha, avec relecture avant/après ;
   - repli vers l'édition native de l'exemplaire si la modification échoue ;
   - FR/EN, responsive, idempotent, sans console.* ;
   - Firestore n'est jamais appelé directement par ce module.
*/
(function () {
    "use strict";

    const MODULE_ID = "lost-found-checkin-status";
    const PAGE_ID = "circ.returns";
    const PAGE_PATH = "/cgi-bin/koha/circ/returns.pl";
    const SCRIPT_GUARD = "__pmk051LostFoundCheckinStatusV3";
    const CARD_ATTR = "data-pmk051-card";
    const STYLE_ID = "pmk-051-lost-found-style";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    if (window.location.pathname !== PAGE_PATH) return;

    const DEFAULTS = {
        enabled: true,
        page: {
            enabled: true,
            pageId: PAGE_ID,
            path: PAGE_PATH
        },
        lostStatuses: [],
        unknownLostAction: "handle",
        notLoanRules: [],
        unknownNotLoanAction: "ask",
        targets:{eventSelector:'.static_checkin_messages .ret_checkedin, .alert .ret_checkedin',messageSelector:'.alert',observerSelector:'.static_checkin_messages, main'}
    };

    let currentConfig = clone(DEFAULTS);
    let observer = null;
    let scanQueued = false;
    const handledNodes = new WeakSet();
    const updateLocks = new Map();
    const avCache = new Map();

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function merge(base, extra) {
        const out = clone(base);
        const src = extra && typeof extra === "object" ? extra : {};
        Object.keys(src).forEach(function (key) {
            const incoming = src[key];
            if (
                incoming && typeof incoming === "object" && !Array.isArray(incoming) &&
                out[key] && typeof out[key] === "object" && !Array.isArray(out[key])
            ) {
                out[key] = Object.assign({}, out[key], incoming);
            } else {
                out[key] = incoming;
            }
        });
        return out;
    }

    function normalizeRow(row, kind) {
        const value = row && typeof row === "object" ? Object.assign({}, row) : {};
        value.value = String(value.value == null ? "" : value.value).trim();
        value.description = String(value.description || value.value || "").trim();
        value.enabled = value.enabled !== false;
        if (kind === "notLoan" && !["ask", "keep", "available"].includes(value.action)) {
            value.action = "ask";
        }
        return value;
    }

    function normalizeConfig(config) {
        const value = merge(DEFAULTS, config || {});
        value.enabled = value.enabled !== false;
        value.page = Object.assign({}, DEFAULTS.page, value.page || {});
        value.page.enabled = value.page.enabled !== false;
        value.page.pageId = PAGE_ID;
        value.page.path = PAGE_PATH;
        value.lostStatuses = Array.isArray(value.lostStatuses)
            ? value.lostStatuses.map(function (row) { return normalizeRow(row, "lost"); }).filter(function (row) { return row.value !== ""; })
            : [];
        value.notLoanRules = Array.isArray(value.notLoanRules)
            ? value.notLoanRules.map(function (row) { return normalizeRow(row, "notLoan"); }).filter(function (row) { return row.value !== "" && row.value !== "0"; })
            : [];
        if (!["handle", "ignore"].includes(value.unknownLostAction)) value.unknownLostAction = "handle";
        if (!["ask", "keep"].includes(value.unknownNotLoanAction)) value.unknownNotLoanAction = "ask";
        return value;
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try {
                const lang = String(api.getLanguage() || "").toLowerCase();
                if (lang.startsWith("en")) return "en";
                if (lang.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        const htmlLang = String(document.documentElement.getAttribute("lang") || "").toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .replace(/\s+/g, " ")
            .trim()
            .toLocaleLowerCase();
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk051-card {
                margin-top: .65rem;
                margin-bottom: .65rem;
                padding: .75rem .9rem;
            }
            .pmk051-header {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: .35rem .55rem;
                margin-bottom: .3rem;
            }
            .pmk051-title {
                margin: 0;
                font-size: 1rem;
                line-height: 1.3;
            }
            .pmk051-meta {
                margin: .15rem 0 .55rem;
                color: inherit;
                overflow-wrap: anywhere;
            }
            .pmk051-actions {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .4rem;
            }
            .pmk051-actions .btn {
                white-space: normal;
            }
            .pmk051-status-name {
                font-weight: 700;
            }
            .pmk051-working {
                display: inline-flex;
                align-items: center;
                gap: .35rem;
            }
            .pmk051-trace { margin: .55rem 0 0; font-size: .9em; }
            .pmk051-trace summary { cursor: pointer; font-weight: 600; }
            .pmk051-trace ol { margin: .35rem 0 0; padding-left: 1.35rem; }
            @media (max-width: 576px) {
                .pmk051-card { padding: .7rem; }
                .pmk051-actions {
                    align-items: stretch;
                    flex-direction: column;
                }
                .pmk051-actions .btn,
                .pmk051-actions a.btn {
                    width: 100%;
                    text-align: center;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function csrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? String(meta.getAttribute("content") || "") : "";
    }

    async function fetchJson(url, options) {
        const opts = Object.assign({
            credentials: "same-origin",
            headers: {
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            }
        }, options || {});
        opts.headers = Object.assign({
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest"
        }, (options && options.headers) || {});

        const response = await fetch(url, opts);
        let payload = null;
        try { payload = await response.json(); } catch (_) {}
        if (!response.ok) {
            const error = new Error(payload && (payload.error || payload.message) ? (payload.error || payload.message) : (response.statusText || "HTTP " + response.status));
            error.status = response.status;
            error.payload = payload;
            throw error;
        }
        return payload;
    }

    async function getAuthorisedValues(category, force) {
        const key = String(category || "").toUpperCase();
        const cached = avCache.get(key);
        if (!force && cached && (Date.now() - cached.at) < 60000) return cached.values;

        const url = "/api/v1/authorised_value_categories/" + encodeURIComponent(key) + "/authorised_values?_per_page=-1";
        const payload = await fetchJson(url);
        const values = Array.isArray(payload) ? payload.map(function (row) {
            return {
                value: String(row && row.value != null ? row.value : "").trim(),
                description: String((row && (row.description || row.value)) || "").trim()
            };
        }).filter(function (row) { return row.value !== ""; }) : [];
        avCache.set(key, { at: Date.now(), values: values });
        return values;
    }

    function extractBiblioId(alertBox) {
        const link = alertBox.querySelector('a[href*="biblionumber="]');
        if (!link) return null;
        try {
            const url = new URL(link.href, window.location.origin);
            const id = Number(url.searchParams.get("biblionumber"));
            return Number.isInteger(id) && id > 0 ? id : null;
        } catch (_) {
            return null;
        }
    }

    function extractBarcode(alertBox) {
        const hidden = alertBox.querySelector('input[name="barcode"][value]');
        if (hidden && String(hidden.value || "").trim()) return String(hidden.value).trim();

        const link = alertBox.querySelector('a[href*="biblionumber="]');
        if (!link) return "";
        const text = String(link.textContent || "").trim();
        const colon = text.indexOf(":");
        if (colon > 0) return text.slice(0, colon).trim();
        return "";
    }

    async function resolveItem(alertBox) {
        const biblioId = extractBiblioId(alertBox);
        const barcode = extractBarcode(alertBox);
        if (!barcode) return null;

        const list = await fetchJson("/api/v1/items?external_id=" + encodeURIComponent(barcode) + "&_per_page=-1");
        const matches = (Array.isArray(list) ? list : []).filter(function (item) {
            if (!item) return false;
            if (String(item.external_id || "") !== barcode) return false;
            if (biblioId && Number(item.biblio_id) !== biblioId) return false;
            return true;
        });
        if (matches.length !== 1) return null;
        return getItem(matches[0].item_id);
    }

    async function getItem(itemId) {
        const id = Number(itemId);
        if (!Number.isInteger(id) || id <= 0) return null;
        return fetchJson("/api/v1/items/" + encodeURIComponent(String(id)));
    }

    async function updateNotForLoan(item, expectedStatus) {
        const lockKey = String(item && item.item_id || "");
        if (updateLocks.has(lockKey)) {
            const concurrent = new Error("concurrent_update");
            concurrent.pending = updateLocks.get(lockKey);
            throw concurrent;
        }
        const operation = { startedAt: Date.now(), expectedStatus: Number(expectedStatus) };
        updateLocks.set(lockKey, operation);
        try {
        const current = await getItem(item.item_id);
        if (!current) throw new Error("item_not_found");
        const currentStatus = Number(current.not_for_loan_status || 0);
        if (currentStatus === 0) return current;
        if (currentStatus !== Number(expectedStatus)) {
            const changed = new Error("status_changed");
            changed.currentStatus = currentStatus;
            throw changed;
        }

        const token = csrfToken();
        const updated = await fetchJson(
            "/api/v1/biblios/" + encodeURIComponent(String(current.biblio_id)) + "/items/" + encodeURIComponent(String(current.item_id)),
            {
                method: "PUT",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json;charset=utf-8",
                    "X-Requested-With": "XMLHttpRequest",
                    "CSRF-TOKEN": token
                },
                body: JSON.stringify({ not_for_loan_status: 0 })
            }
        );

        const verified = await getItem(current.item_id);
        if (!verified || Number(verified.not_for_loan_status || 0) !== 0) {
            throw new Error("verification_failed");
        }
        return updated || verified;
        } finally {
            if (updateLocks.get(lockKey) === operation) updateLocks.delete(lockKey);
        }
    }

    function editItemUrl(item) {
        if (!item) return "";
        return "/cgi-bin/koha/cataloguing/additem.pl?op=edititem&biblionumber=" +
            encodeURIComponent(String(item.biblio_id)) + "&itemnumber=" +
            encodeURIComponent(String(item.item_id)) + "#edititem";
    }

    function findStatusLabel(status, list, rules) {
        const code = String(status);
        const live = (list || []).find(function (row) { return String(row.value) === code; });
        if (live && live.description) return live.description;
        const saved = (rules || []).find(function (row) { return String(row.value) === code; });
        if (saved && saved.description) return saved.description;
        return t("Statut non prêtable n°", "Not-for-loan status #") + code;
    }

    async function evaluateLostEvent(retNode, config) {
        const rows = Array.isArray(config.lostStatuses) ? config.lostStatuses : [];
        if (!rows.length) return { allowed: true, identified: false, forceAsk: false };

        const enabledRows = rows.filter(function (row) { return row.enabled !== false; });
        if (!enabledRows.length) return { allowed: false, identified: true, forceAsk: false };
        if (enabledRows.length === rows.length) return { allowed: true, identified: false, forceAsk: false };

        let live = [];
        try { live = await getAuthorisedValues("LOST", false); } catch (_) {}

        const byValue = new Map();
        rows.forEach(function (row) { byValue.set(String(row.value), row); });
        const candidates = [];
        const seen = new Set();

        live.concat(rows).forEach(function (row) {
            const code = String(row && row.value != null ? row.value : "").trim();
            const description = String(row && row.description || "").trim();
            if (!code || !description) return;
            const key = code + "\u0000" + description;
            if (seen.has(key)) return;
            seen.add(key);
            candidates.push({ value: code, description: description });
        });

        candidates.sort(function (a, b) { return b.description.length - a.description.length; });
        const message = normalizeText(retNode.textContent);
        const matched = candidates.find(function (row) {
            return row.description && message.includes(normalizeText(row.description));
        });

        if (matched) {
            const configured = byValue.get(String(matched.value));
            if (!configured) {
                return {
                    allowed: config.unknownLostAction !== "ignore",
                    identified: true,
                    forceAsk: true,
                    lostValue: String(matched.value)
                };
            }
            return {
                allowed: configured.enabled !== false,
                identified: true,
                forceAsk: false,
                lostValue: String(matched.value)
            };
        }

        return {
            allowed: config.unknownLostAction !== "ignore",
            identified: false,
            forceAsk: true
        };
    }

    function decideNotLoan(status, config) {
        const code = String(status);
        const rule = (config.notLoanRules || []).find(function (row) { return String(row.value) === code; });
        if (rule) {
            if (rule.enabled === false) return { handle: false, action: "keep", configured: true, rule: rule };
            return { handle: true, action: rule.action || "ask", configured: true, rule: rule };
        }
        return {
            handle: config.unknownNotLoanAction !== "keep",
            action: config.unknownNotLoanAction === "keep" ? "keep" : "ask",
            configured: false,
            rule: null
        };
    }

    function removeCardFor(alertBox) {
        if (!alertBox) return;
        const next = alertBox.nextElementSibling;
        if (next && next.hasAttribute(CARD_ATTR)) next.remove();
    }

    function makeButton(className, icon, label) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = className;
        button.innerHTML = '<i class="' + icon + '" aria-hidden="true"></i> <span></span>';
        button.querySelector("span").textContent = label;
        return button;
    }

    function makeEditLink(item) {
        const link = document.createElement("a");
        link.className = "btn btn-sm btn-link";
        link.href = editItemUrl(item);
        link.innerHTML = '<i class="fa fa-pencil" aria-hidden="true"></i> <span></span>';
        link.querySelector("span").textContent = t("Modifier l’exemplaire", "Edit item");
        return link;
    }

    function mountConfigShortcut(card) {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;
        const anchor = card.querySelector(".pmk051-title");
        if (!anchor) return;
        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: PAGE_ID,
                context: {
                    sectionId: "status-rules",
                    pageId: PAGE_ID
                }
            });
        } catch (_) {}
    }

    function renderBaseCard(alertBox, item, statusLabel, type, titleText, messageText) {
        removeCardFor(alertBox);
        const card = document.createElement("div");
        card.className = "alert alert-" + type + " pmk051-card";
        card.setAttribute(CARD_ATTR, "1");
        card.setAttribute("role", "status");

        const header = document.createElement("div");
        header.className = "pmk051-header";
        const title = document.createElement("h3");
        title.className = "pmk051-title";
        title.textContent = titleText;
        header.appendChild(title);
        card.appendChild(header);

        const meta = document.createElement("p");
        meta.className = "pmk051-meta";
        const barcode = String(item && item.external_id || "").trim();
        meta.appendChild(document.createTextNode(messageText + (barcode ? " " + t("Code-barres : ", "Barcode: ") + barcode + ". " : "")));
        if (statusLabel) {
            meta.appendChild(document.createTextNode(t("Statut actuel : ", "Current status: ")));
            const strong = document.createElement("span");
            strong.className = "pmk051-status-name";
            strong.textContent = statusLabel;
            meta.appendChild(strong);
            meta.appendChild(document.createTextNode("."));
        }
        card.appendChild(meta);

        const actions = document.createElement("div");
        actions.className = "pmk051-actions";
        card.appendChild(actions);

        alertBox.insertAdjacentElement("afterend", card);
        mountConfigShortcut(card);
        return { card: card, actions: actions, meta: meta };
    }

    function appendDecisionTrace(card, steps) {
        if (!card || !Array.isArray(steps) || !steps.length) return;
        const details = document.createElement("details");
        details.className = "pmk051-trace";
        const summary = document.createElement("summary");
        summary.textContent = t("Pourquoi cette action est proposée", "Why this action is proposed");
        const list = document.createElement("ol");
        steps.forEach(function (step) {
            const row = document.createElement("li");
            row.textContent = String(step || "");
            list.appendChild(row);
        });
        details.append(summary, list);
        card.appendChild(details);
    }

    function renderPrompt(alertBox, item, status, statusLabel, trace) {
        const ui = renderBaseCard(
            alertBox,
            item,
            statusLabel,
            "warning",
            t("Document retrouvé — statut à confirmer", "Found item — status to confirm"),
            t(
                "Koha a traité le statut « perdu », mais l’exemplaire reste non prêtable.",
                "Koha processed the lost status, but the item is still not for loan."
            )
        );
        appendDecisionTrace(ui.card, trace);

        const keep = makeButton(
            "btn btn-sm btn-default",
            "fa fa-lock",
            t("Conserver ce statut", "Keep this status")
        );
        const available = makeButton(
            "btn btn-sm btn-primary",
            "fa fa-check",
            t("Remettre en circulation", "Make available for loan")
        );
        const edit = makeEditLink(item);

        keep.addEventListener("click", function () {
            ui.card.className = "alert alert-info pmk051-card";
            ui.meta.textContent = t(
                "Le statut « " + statusLabel + " » est conservé. Aucune donnée n’a été modifiée par PimpMyKoha.",
                "The “" + statusLabel + "” status is kept. PimpMyKoha did not change any data."
            );
            ui.actions.replaceChildren(makeEditLink(item));
        }, { once: true });

        available.addEventListener("click", async function () {
            keep.disabled = true;
            available.disabled = true;
            await performAvailabilityUpdate(ui, item, status, statusLabel);
        }, { once: true });

        ui.actions.appendChild(keep);
        ui.actions.appendChild(available);
        ui.actions.appendChild(edit);
    }

    async function performAvailabilityUpdate(ui, item, status, statusLabel) {
        ui.card.className = "alert alert-info pmk051-card";
        ui.meta.innerHTML = "";
        const working = document.createElement("span");
        working.className = "pmk051-working";
        working.innerHTML = '<i class="fa fa-spinner fa-spin" aria-hidden="true"></i><span></span>';
        working.querySelector("span").textContent = t(
            "Vérification de l’exemplaire avant modification…",
            "Checking item before update…"
        );
        ui.meta.appendChild(working);
        ui.actions.replaceChildren();

        try {
            await updateNotForLoan(item, status);
            ui.card.className = "alert alert-success pmk051-card";
            ui.meta.textContent = t(
                "L’exemplaire a été remis en circulation. Le statut « " + statusLabel + " » a été supprimé et Koha confirme maintenant un statut prêtable.",
                "The item is available for loan again. The “" + statusLabel + "” status was removed and Koha now confirms an available status."
            );
            ui.actions.replaceChildren(makeEditLink(item));
        } catch (error) {
            ui.card.className = "alert alert-warning pmk051-card";
            let message;
            if (error && error.status === 403) {
                message = t(
                    "La remise en circulation n’a pas été effectuée : votre compte Koha ne possède pas le droit de modifier cet exemplaire. Utilisez l’édition native Koha.",
                    "The item was not made available: your Koha account is not allowed to edit this item. Use Koha's native item editor."
                );
            } else if (error && error.message === "status_changed") {
                message = t(
                    "La remise en circulation a été annulée : le statut de l’exemplaire a changé depuis l’affichage de cette alerte. Aucune modification n’a été forcée.",
                    "The update was cancelled: the item status changed after this alert was displayed. No change was forced."
                );
            } else if (error && error.message === "concurrent_update") {
                message = t(
                    "Une autre correction de ce même exemplaire est déjà en cours. Attendez son résultat puis contrôlez le statut.",
                    "Another update of this item is already running. Wait for its result, then check the status."
                );
            } else {
                message = t(
                    "Koha n’a pas confirmé la remise en circulation. Aucune réussite n’est supposée : vérifiez l’exemplaire dans l’éditeur natif.",
                    "Koha did not confirm the update. No success is assumed: check the item in Koha's native editor."
                );
            }
            ui.meta.textContent = message;
            ui.actions.replaceChildren(makeEditLink(item));
        }
    }

    function renderResolutionFailure(alertBox, biblioId) {
        removeCardFor(alertBox);
        const card = document.createElement("div");
        card.className = "alert alert-warning pmk051-card";
        card.setAttribute(CARD_ATTR, "1");
        card.setAttribute("role", "status");
        const title = document.createElement("h3");
        title.className = "pmk051-title";
        title.textContent = t("Document retrouvé — vérification manuelle nécessaire", "Found item — manual check required");
        const text = document.createElement("p");
        text.className = "pmk051-meta";
        text.textContent = t(
            "PimpMyKoha a détecté le retour d’un document perdu mais n’a pas pu identifier l’exemplaire de façon suffisamment sûre. Aucune donnée n’a été modifiée.",
            "PimpMyKoha detected a lost item being returned but could not identify the item safely enough. No data was changed."
        );
        card.appendChild(title);
        card.appendChild(text);
        if (biblioId) {
            const actions = document.createElement("div");
            actions.className = "pmk051-actions";
            const link = document.createElement("a");
            link.className = "btn btn-sm btn-default";
            link.href = "/cgi-bin/koha/catalogue/detail.pl?biblionumber=" + encodeURIComponent(String(biblioId));
            link.textContent = t("Ouvrir la notice", "Open record");
            actions.appendChild(link);
            card.appendChild(actions);
        }
        alertBox.insertAdjacentElement("afterend", card);
        mountConfigShortcut(card);
    }

    async function processReturnMessage(retNode, config) {
        const alertBox = retNode.closest(config.targets.messageSelector);
        if (!alertBox) return;

        if (handledNodes.has(retNode)) return;
        handledNodes.add(retNode);

        const lostDecision = await evaluateLostEvent(retNode, config);
        if (!lostDecision.allowed) return;
        const trace = [t("Koha signale qu’un statut perdu vient d’être traité.", "Koha reports that a lost status was processed.")];
        trace.push(lostDecision.identified
            ? t("Le motif LOST est reconnu par les règles de cette installation.", "The LOST reason is recognised by this installation's rules.")
            : t("Le motif LOST n’est pas identifié : le mode prudent est appliqué.", "The LOST reason is not identified: cautious mode applies."));

        let item = null;
        try { item = await resolveItem(alertBox); } catch (_) {}
        if (!item) {
            renderResolutionFailure(alertBox, extractBiblioId(alertBox));
            return;
        }
        trace.push(t("L’exemplaire a été relu dans Koha après le retour.", "The item was read again from Koha after check-in."));

        const status = Number(item.not_for_loan_status || 0);
        if (!Number.isFinite(status) || status === 0) {
            removeCardFor(alertBox);
            return;
        }

        const ruleDecision = decideNotLoan(status, config);
        if (!ruleDecision.handle) {
            removeCardFor(alertBox);
            return;
        }

        let notLoanValues = [];
        try { notLoanValues = await getAuthorisedValues("NOT_LOAN", false); } catch (_) {}
        const statusLabel = findStatusLabel(status, notLoanValues, config.notLoanRules);
        trace.push(t("Statut final NOT_LOAN : ", "Final NOT_LOAN status: ") + statusLabel + " (" + String(status) + ").");

        let action = ruleDecision.action;
        if (lostDecision.forceAsk && action === "available") action = "ask";
        trace.push(t("Décision : ", "Decision: ") + (action === "available"
            ? t("remise en circulation automatique.", "make available automatically.")
            : action === "keep" ? t("conserver le statut.", "keep the status.") : t("demander à l’agent.", "ask the staff member.")));

        if (action === "keep") {
            removeCardFor(alertBox);
            return;
        }

        if (action === "available") {
            const ui = renderBaseCard(
                alertBox,
                item,
                statusLabel,
                "info",
                t("Document retrouvé — remise en circulation", "Found item — making available"),
                t("Ce statut est configuré pour être supprimé automatiquement après le retour d’un document perdu.", "This status is configured to be removed automatically after a lost item is returned.")
            );
            appendDecisionTrace(ui.card, trace);
            await performAvailabilityUpdate(ui, item, status, statusLabel);
            return;
        }

        renderPrompt(alertBox, item, status, statusLabel, trace);
    }

    function scan() {
        scanQueued = false;
        const config = currentConfig;
        if (!config.enabled || !config.page.enabled) {
            document.querySelectorAll("[" + CARD_ATTR + "]").forEach(function (card) { card.remove(); });
            return;
        }

        injectStyles();
        document.querySelectorAll(config.targets.eventSelector).forEach(function (retNode) {
            processReturnMessage(retNode, config).catch(function () {
                const alertBox = retNode.closest(config.targets.messageSelector);
                if (alertBox) renderResolutionFailure(alertBox, extractBiblioId(alertBox));
            });
        });
    }

    function queueScan() {
        if (scanQueued) return;
        scanQueued = true;
        window.requestAnimationFrame(scan);
    }

    function observeMessages() {
        if (observer) return;
        const root = document.querySelector(currentConfig.targets.observerSelector) || document.body;
        if (!root) return;
        observer = new MutationObserver(function (mutations) {
            if (mutations.some(function (mutation) { return mutation.addedNodes && mutation.addedNodes.length; })) {
                queueScan();
            }
        });
        observer.observe(root, { childList: true, subtree: true });
    }

    function useConfig(config) {
        currentConfig = normalizeConfig(config);
        if(observer){observer.disconnect();observer=null;}
        observeMessages();
        queueScan();
    }

    function connectPmkConfig() {
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            useConfig(DEFAULTS);
            return false;
        }

        try {
            if (typeof api.subscribe === "function") {
                api.subscribe(MODULE_ID, function (config) { useConfig(config); });
            }
        } catch (_) {}

        api.getConfig(MODULE_ID)
            .then(useConfig)
            .catch(function () { useConfig(DEFAULTS); });
        return true;
    }

    function start() {
        observeMessages();
        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }
        queueScan();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("051-alert-doc-retour-perdu.js");
} catch (error) { window.PMKNonPlugin.errors.push("051-alert-doc-retour-perdu.js: "+error.message); console.error("[PMK] 051-alert-doc-retour-perdu.js",error); };
