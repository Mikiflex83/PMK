/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
/*
 Nom du fichier : 052-modify-circulation-menu-links.js
 Module PMK      : Navigation personnalisée
 Version         : 3.1.0-pmk-isolated
 Date            : 2026-09-19
 Auteur          : équipe PimpMyKoha / refactorisation PimpMyKoha
 Dépendance      : 000-pmk-config-firestore.js recommandé (fonctionne avec les valeurs par défaut sans le socle)

 Fonction :
 - ajoute des éléments dans la navigation Koha ;
 - ou remplace uniquement l'URL cible d'un élément de navigation existant ;
 - utilise le moteur de pick commun PMK ;
 - utilise la pipette de style commune PMK ;
 - absorbe le comportement historique du 076 (file de réservations -> rapport 4904).

 Valeurs historiques livrées par défaut :
 - Transferts à recevoir -> rapport guidé 4639 ;
 - Transferts à envoyer -> rapport guidé 4344 ;
 - réajout des accès Koha natifs sur circulation-home.pl ;
 - File de réservations -> rapport guidé 4904.
*/

(function () {
    "use strict";

    const MODULE_ID = "custom-navigation";
    const MODULE_VERSION = "3.1.0-pmk-isolated";
    const SCRIPT_GUARD = "__pmk052CustomNavigationV31";
    const GENERATED_ATTR = "data-pmk-nav-generated";
    const ORIGINAL_HREF_ATTR = "data-pmk-nav-original-href";
    const RULE_ATTR = "data-pmk-nav-rule";
    const CONTEXT_KEY_PREFIX = "custom-navigation-";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const DEFAULT_CONFIG = {
        enabled: true,
        rules: [
            {
                id: "legacy-052-receive-report",
                enabled: true,
                name: "Transferts à recevoir → rapport 4639",
                action: "replace-url",
                allPages: false,
                pages: "/cgi-bin/koha/circ/circulation-home.pl\n/cgi-bin/koha/circ/circulation.pl",
                targetSelector: "",
                targetHref: "/cgi-bin/koha/circ/transferstoreceive.pl",
                targetName: "Transferts à recevoir",
                destinationKind: "report",
                reportId: "4639",
                destinationUrl: "",
                anchorSelector: "",
                anchorHref: "",
                anchorName: "",
                position: "after",
                textFr: "",
                textEn: "",
                showIcon: false,
                iconClass: "",
                styleMode: "auto",
                sampledStyle: null,
                sampledClasses: [],
                sampledParentClasses: []
            },
            {
                id: "legacy-052-receive-native",
                enabled: true,
                name: "Accès Koha natif — Transferts à recevoir",
                action: "add",
                allPages: false,
                pages: "/cgi-bin/koha/circ/circulation-home.pl",
                targetSelector: "",
                targetHref: "",
                targetName: "",
                destinationKind: "url",
                reportId: "",
                destinationUrl: "/cgi-bin/koha/circ/transferstoreceive.pl",
                anchorSelector: "",
                anchorHref: "/cgi-bin/koha/circ/transferstoreceive.pl",
                anchorName: "Transferts à recevoir",
                position: "after",
                textFr: "Transferts à recevoir",
                textEn: "Transfers to receive",
                showIcon: true,
                iconClass: "fa-solid fa-truck",
                styleMode: "auto",
                sampledStyle: null,
                sampledClasses: [],
                sampledParentClasses: []
            },
            {
                id: "legacy-052-send-report",
                enabled: true,
                name: "Transferts à envoyer → rapport 4344",
                action: "replace-url",
                allPages: false,
                pages: "/cgi-bin/koha/circ/circulation-home.pl\n/cgi-bin/koha/circ/circulation.pl",
                targetSelector: "",
                targetHref: "/cgi-bin/koha/circ/transfers_to_send.pl",
                targetName: "Transferts à envoyer",
                destinationKind: "report",
                reportId: "4344",
                destinationUrl: "",
                anchorSelector: "",
                anchorHref: "",
                anchorName: "",
                position: "after",
                textFr: "",
                textEn: "",
                showIcon: false,
                iconClass: "",
                styleMode: "auto",
                sampledStyle: null,
                sampledClasses: [],
                sampledParentClasses: []
            },
            {
                id: "legacy-052-send-native",
                enabled: true,
                name: "Accès Koha natif — Transferts à envoyer",
                action: "add",
                allPages: false,
                pages: "/cgi-bin/koha/circ/circulation-home.pl",
                targetSelector: "",
                targetHref: "",
                targetName: "",
                destinationKind: "url",
                reportId: "",
                destinationUrl: "/cgi-bin/koha/circ/transfers_to_send.pl",
                anchorSelector: "",
                anchorHref: "/cgi-bin/koha/circ/transfers_to_send.pl",
                anchorName: "Transferts à envoyer",
                position: "after",
                textFr: "Transferts à envoyer",
                textEn: "Transfers to send",
                showIcon: true,
                iconClass: "fa-solid fa-truck-ramp-box",
                styleMode: "auto",
                sampledStyle: null,
                sampledClasses: [],
                sampledParentClasses: []
            },
            {
                id: "legacy-076-holdsqueue-report",
                enabled: true,
                name: "File de réservations → rapport 4904",
                action: "replace-url",
                allPages: true,
                pages: "/cgi-bin/koha/circ/view_holdsqueue.pl",
                targetSelector: "",
                targetHref: "/cgi-bin/koha/circ/view_holdsqueue.pl",
                targetName: "File de réservations",
                destinationKind: "report",
                reportId: "4904",
                destinationUrl: "",
                anchorSelector: "",
                anchorHref: "",
                anchorName: "",
                position: "after",
                textFr: "",
                textEn: "",
                showIcon: false,
                iconClass: "",
                styleMode: "auto",
                sampledStyle: null,
                sampledClasses: [],
                sampledParentClasses: []
            }
        ]
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let observer = null;
    let applyTimer = null;
    let registered = false;
    let coreWaitTimer = null;

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function language() {
        const api = window.PMKConfig;
        if (api && typeof api.getLanguage === "function") {
            try {
                const value = clean(api.getLanguage()).toLowerCase();
                if (value.startsWith("en")) return "en";
                if (value.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        const html = clean(document.documentElement.getAttribute("lang")).toLowerCase();
        return html.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function uniqueId(prefix) {
        return String(prefix || "rule") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
    }

    function parsePages(value) {
        const raw = Array.isArray(value) ? value.join("\n") : String(value || "");
        const seen = new Set();
        return raw.split(/[\n,;]+/).map(function (entry) {
            return clean(entry);
        }).filter(function (entry) {
            if (!entry || seen.has(entry)) return false;
            seen.add(entry);
            return true;
        });
    }

    function pageMatchesPattern(path, pattern) {
        const p = clean(pattern);
        if (!p) return false;
        if (p === "*" || p.toLowerCase() === "all") return true;
        if (p.endsWith("*")) return path.startsWith(p.slice(0, -1));
        return path === p;
    }

    function ruleAppliesHere(rule) {
        if (rule && rule.allPages === true) return true;
        const pages = parsePages(rule && rule.pages);
        if (!pages.length) return false;
        return pages.some(function (pattern) {
            return pageMatchesPattern(window.location.pathname, pattern);
        });
    }

    function firstConcretePage(rule) {
        const pages = parsePages(rule && rule.pages);
        const page = pages.find(function (value) {
            return value && value !== "*" && value.toLowerCase() !== "all";
        });
        if (!page) return window.location.pathname + window.location.search;
        if (page.startsWith("/")) return page;
        return "/cgi-bin/koha/" + page.replace(/^\/+/, "");
    }

    function normalizeDestinationForStorage(href) {
        const raw = clean(href);
        if (!raw) return "";
        try {
            const url = new URL(raw, window.location.origin);
            if (url.origin === window.location.origin) {
                return url.pathname + url.search + url.hash;
            }
            return url.href;
        } catch (_) {
            return raw;
        }
    }

    function normalizeRule(rule) {
        const value = rule && typeof rule === "object" ? Object.assign({}, rule) : {};
        value.id = clean(value.id) || uniqueId("nav");
        value.enabled = value.enabled !== false;
        value.name = clean(value.name);
        value.action = value.action === "replace-url" ? "replace-url" : "add";
        value.pages = Array.isArray(value.pages) ? value.pages.join("\n") : String(value.pages || window.location.pathname || "");
        const normalizedPages = parsePages(value.pages);
        value.allPages = value.allPages === true || normalizedPages.some(function (page) {
            return page === "*" || page.toLowerCase() === "all";
        });
        if (value.allPages === true) {
            const concretePages = normalizedPages.filter(function (page) {
                return page !== "*" && page.toLowerCase() !== "all";
            });
            /*
             * La liste des pages reste mémorisée pour pouvoir revenir ensuite
             * à une portée limitée. Si l'ancienne configuration ne contenait
             * que "*", on conserve la page courante comme page de référence.
             */
            value.pages = concretePages.length ? concretePages.join("\n") : window.location.pathname;
        }
        value.targetSelector = clean(value.targetSelector);
        value.targetHref = clean(value.targetHref);
        value.targetName = clean(value.targetName);
        value.destinationKind = value.destinationKind === "report" ? "report" : "url";
        value.reportId = clean(value.reportId);
        value.destinationUrl = clean(value.destinationUrl);
        value.anchorSelector = clean(value.anchorSelector);
        value.anchorHref = clean(value.anchorHref);
        value.anchorName = clean(value.anchorName);
        value.position = ["before", "after", "inside-start", "inside-end"].includes(value.position)
            ? value.position
            : "after";
        value.textFr = String(value.textFr || "");
        value.textEn = String(value.textEn || "");
        value.showIcon = value.showIcon === true;
        value.iconClass = clean(value.iconClass);
        value.styleMode = value.styleMode === "sample" ? "sample" : "auto";
        value.sampledStyle = value.sampledStyle && typeof value.sampledStyle === "object"
            ? Object.assign({}, value.sampledStyle)
            : null;
        value.sampledClasses = Array.isArray(value.sampledClasses) ? value.sampledClasses.map(clean).filter(Boolean) : [];
        value.sampledParentClasses = Array.isArray(value.sampledParentClasses) ? value.sampledParentClasses.map(clean).filter(Boolean) : [];
        return value;
    }

    function normalizeConfig(config) {
        const src = config && typeof config === "object" ? config : {};
        return {
            enabled: src.enabled !== false,
            rules: Array.isArray(src.rules)
                ? src.rules.map(normalizeRule)
                : clone(DEFAULT_CONFIG.rules).map(normalizeRule)
        };
    }

    function ruleIndex(path) {
        const list = Array.isArray(path) ? path : [];
        for (let i = 0; i < list.length - 1; i += 1) {
            if (list[i] === "rules" && Number.isInteger(list[i + 1])) return list[i + 1];
        }
        return -1;
    }

    function ruleFromPath(root, path) {
        const index = ruleIndex(path);
        return root && Array.isArray(root.rules) && index >= 0 ? root.rules[index] : null;
    }

    function newRule() {
        return normalizeRule({
            id: uniqueId("nav"),
            enabled: true,
            name: "",
            action: "add",
            allPages: false,
            pages: window.location.pathname,
            targetSelector: "",
            targetHref: "",
            targetName: "",
            destinationKind: "url",
            reportId: "",
            destinationUrl: "",
            anchorSelector: "",
            anchorHref: "",
            anchorName: "",
            position: "after",
            textFr: "",
            textEn: "",
            showIcon: false,
            iconClass: "",
            styleMode: "auto",
            sampledStyle: null,
            sampledClasses: [],
            sampledParentClasses: []
        });
    }

    function destinationForRule(rule) {
        if (!rule) return "";
        if (rule.destinationKind === "report") {
            const id = clean(rule.reportId);
            if (!/^\d+$/.test(id)) return "";
            return "/cgi-bin/koha/reports/guided_reports.pl?id=" + encodeURIComponent(id) + "&op=run";
        }
        const value=clean(rule.destinationUrl);if(!value)return '';
        try{const url=window.PMKWorkbench?.safeUrl(value,{protocols:['http:','https:','mailto:','tel:','ftp:']})||new URL(value,location.href);if(!['http:','https:','mailto:','tel:','ftp:'].includes(url.protocol)||url.username||url.password)return '';return value;}catch(_){return '';}
    }

    function safeQueryAll(selector) {
        const value = clean(selector);
        if (!value) return [];
        try {
            return Array.from(document.querySelectorAll(value));
        } catch (_) {
            return [];
        }
    }

    function sameHrefIdentity(actualHref, identity) {
        const actual = clean(actualHref);
        const wanted = clean(identity);
        if (!actual || !wanted) return false;
        try {
            const actualUrl = new URL(actual, window.location.origin);
            const wantedUrl = new URL(wanted, window.location.origin);

            if (wantedUrl.origin !== window.location.origin) {
                return actualUrl.href === wantedUrl.href;
            }
            if (wantedUrl.search || wantedUrl.hash) {
                return actualUrl.pathname + actualUrl.search + actualUrl.hash ===
                    wantedUrl.pathname + wantedUrl.search + wantedUrl.hash;
            }
            return actualUrl.pathname === wantedUrl.pathname;
        } catch (_) {
            return actual === wanted || actual.indexOf(wanted) !== -1;
        }
    }

    function elementsByHref(identity) {
        if (!clean(identity)) return [];
        return Array.from(document.querySelectorAll("a[href]")).filter(function (link) {
            if (link.hasAttribute(GENERATED_ATTR)) return false;
            return sameHrefIdentity(link.getAttribute("href"), identity);
        });
    }

    function resolveRuleElements(rule, selectorKey, hrefKey) {
        /*
         * 3.1.1 — le sélecteur choisi par le picker est l'identité principale.
         * L'URL (href) n'est qu'un secours si ce sélecteur ne retrouve plus
         * aucun élément. On ne cumule surtout pas les deux résultats : une
         * même URL Koha peut exister à plusieurs endroits de la page
         * (menu « Plus », gros liens de l'accueil, barre latérale, etc.).
         * Le cumul provoquait alors plusieurs insertions d'une même règle.
         */
        const selector = clean(rule && rule[selectorKey]);
        const bySelector = safeQueryAll(selector).filter(function (node) {
            return node && !node.hasAttribute(GENERATED_ATTR);
        });

        if (bySelector.length) {
            return Array.from(new Set(bySelector));
        }

        return elementsByHref(rule && rule[hrefKey]);
    }

    function restoreRuntime() {
        document.querySelectorAll("[" + GENERATED_ATTR + "=\"1\"]").forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });

        document.querySelectorAll("[" + ORIGINAL_HREF_ATTR + "]").forEach(function (node) {
            try {
                const original = node.getAttribute(ORIGINAL_HREF_ATTR);
                if (original == null || original === "") node.removeAttribute("href");
                else node.setAttribute("href", original);
                window.PMKWorkbench?.restoreLinkDescription(node);
                node.removeAttribute(ORIGINAL_HREF_ATTR);
                node.removeAttribute(RULE_ATTR);
            } catch (_) {}
        });
    }

    function copyClassNames(element) {
        return Array.from(element && element.classList || []).filter(function (name) {
            return clean(name) !== "";
        });
    }

    function safeVisualClasses(classes) {
        const allowed = [];
        (classes || []).forEach(function (name) {
            const cls = clean(name);
            if (!cls) return;
            if (/^(pmk|active$|selected$|current$|disabled$|show$|open$|collapsed$|is-)/i.test(cls)) return;
            if (/^(transfers?-to-|holds-|recalls-|bookings-|curbside$|article-request$|overdues-|transfer$)/i.test(cls)) return;
            if (
                /^(circ-button|nav-link|dropdown-item|list-group-item|btn(?:-.+)?|link-.+|text-.+|fw-.+|small$|d-.+|align-.+|justify-.+|gap-.+)$/i.test(cls)
            ) {
                allowed.push(cls);
            }
        });
        return Array.from(new Set(allowed));
    }

    function clickableFrom(node) {
        if (!node || node.nodeType !== 1) return null;
        if (node.matches("a,button,[role='menuitem']")) return node;
        return node.querySelector("a,button,[role='menuitem']") || node;
    }

    function structuralUnitFor(anchor) {
        if (!anchor || anchor.nodeType !== 1) return null;
        const li = anchor.closest("li");
        return li || anchor;
    }

    function setClasses(element, classes) {
        (classes || []).forEach(function (name) {
            try { element.classList.add(name); } catch (_) {}
        });
    }

    function rgbaIsTransparent(value) {
        const v = clean(value).toLowerCase();
        return !v || v === "transparent" || /rgba\([^)]*,\s*0(?:\.0+)?\s*\)$/.test(v);
    }

    function applySampledStyle(link, rule) {
        if (!link || !rule || rule.styleMode !== "sample" || !rule.sampledStyle) return;
        const s = rule.sampledStyle;
        const properties = [
            "fontSize", "fontWeight", "fontStyle",
            "textDecoration", "textDecorationLine", "textDecorationStyle", "textDecorationColor",
            "borderRadius", "borderColor", "borderWidth", "borderStyle",
            "boxShadow", "lineHeight", "letterSpacing", "textTransform", "opacity"
        ];
        properties.forEach(function (prop) {
            if (clean(s[prop])) {
                try { link.style[prop] = s[prop]; } catch (_) {}
            }
        });

        if (s.copyColor === true && clean(s.color)) link.style.color = s.color;
        if (s.copyBackground === true && clean(s.backgroundColor) && !rgbaIsTransparent(s.backgroundColor)) {
            link.style.backgroundColor = s.backgroundColor;
        }
    }

    function effectiveText(rule) {
        if (!rule) return "";
        const fr = clean(rule.textFr);
        const en = clean(rule.textEn);
        return language() === "en" ? (en || fr) : (fr || en);
    }

    function buildLinkContent(link, rule) {
        while (link.firstChild) link.removeChild(link.firstChild);

        if (rule.showIcon === true && clean(rule.iconClass)) {
            const icon = document.createElement("i");
            icon.className = clean(rule.iconClass);
            icon.setAttribute("aria-hidden", "true");
            link.appendChild(icon);
            link.appendChild(document.createTextNode(" "));
        }

        const span = document.createElement("span");
        span.textContent = effectiveText(rule) || rule.name || t("Nouvel élément", "New item");
        link.appendChild(span);
    }

    function createGeneratedLink(rule, anchor) {
        const sourceClickable = clickableFrom(anchor);
        const link = document.createElement("a");
        link.setAttribute(GENERATED_ATTR, "1");
        link.setAttribute(RULE_ATTR, rule.id);
        link.href = destinationForRule(rule);
        window.PMKWorkbench?.describeLink(link);

        const classSource = rule.styleMode === "sample" && rule.sampledClasses.length
            ? rule.sampledClasses
            : safeVisualClasses(copyClassNames(sourceClickable));
        setClasses(link, classSource);

        buildLinkContent(link, rule);
        applySampledStyle(link, rule);
        return link;
    }

    function createWrapperForLink(rule, anchor, link) {
        const unit = structuralUnitFor(anchor);
        if (unit && unit.tagName && unit.tagName.toLowerCase() === "li") {
            const li = document.createElement("li");
            li.setAttribute(GENERATED_ATTR, "1");
            li.setAttribute(RULE_ATTR, rule.id);

            const parentClasses = rule.styleMode === "sample" && rule.sampledParentClasses.length
                ? rule.sampledParentClasses
                : safeVisualClasses(copyClassNames(unit));
            setClasses(li, parentClasses);
            li.appendChild(link);
            return li;
        }
        return link;
    }

    function insertGenerated(rule, anchor) {
        const destination = destinationForRule(rule);
        if (!destination || !anchor || !anchor.isConnected) return false;

        const link = createGeneratedLink(rule, anchor);
        const wrapper = createWrapperForLink(rule, anchor, link);
        const unit = structuralUnitFor(anchor);

        if (rule.position === "before") {
            if (!unit || !unit.parentNode) return false;
            unit.parentNode.insertBefore(wrapper, unit);
            return true;
        }

        if (rule.position === "after") {
            if (!unit || !unit.parentNode) return false;
            unit.parentNode.insertBefore(wrapper, unit.nextSibling);
            return true;
        }

        const target = anchor.matches && anchor.matches("ul,ol")
            ? anchor
            : (anchor.closest && anchor.closest("ul,ol")) || anchor;

        if (!target || !target.appendChild) return false;

        let insideNode = wrapper;
        if ((target.tagName || "").toLowerCase() !== "ul" && (target.tagName || "").toLowerCase() !== "ol") {
            insideNode = link;
        }

        if (rule.position === "inside-start") {
            target.insertBefore(insideNode, target.firstChild);
        } else {
            target.appendChild(insideNode);
        }
        return true;
    }

    function applyAddRule(rule) {
        const anchors = resolveRuleElements(rule, "anchorSelector", "anchorHref");
        if (!anchors.length) return;
        anchors.forEach(function (anchor) {
            try { insertGenerated(rule, anchor); } catch (_) {}
        });
    }

    function applyReplaceRule(rule) {
        const destination = destinationForRule(rule);
        if (!destination) return;

        const targets = resolveRuleElements(rule, "targetSelector", "targetHref");
        targets.forEach(function (target) {
            const link = target.matches && target.matches("a[href]") ? target : (target.querySelector && target.querySelector("a[href]"));
            if (!link || link.hasAttribute(GENERATED_ATTR)) return;
            try {
                if (!link.hasAttribute(ORIGINAL_HREF_ATTR)) {
                    link.setAttribute(ORIGINAL_HREF_ATTR, link.getAttribute("href") || "");
                }
                link.setAttribute("href", destination);
                window.PMKWorkbench?.describeLink(link);
                link.setAttribute(RULE_ATTR, rule.id);
            } catch (_) {}
        });
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULT_CONFIG);
        restoreRuntime();

        if (currentConfig.enabled === false) return;

        const active = currentConfig.rules.filter(function (rule) {
            return rule && rule.enabled !== false && ruleAppliesHere(rule);
        });

        /*
         * Les ajouts passent AVANT les redirections.
         * Ainsi une règle historique 052 peut se positionner par rapport au
         * lien Koha natif avant que son href soit remplacé par le rapport.
         */
        active.filter(function (rule) { return rule.action === "add"; }).forEach(applyAddRule);
        active.filter(function (rule) { return rule.action === "replace-url"; }).forEach(applyReplaceRule);
    }

    function mutationIsOnlyOurs(mutation) {
        if (!mutation || mutation.type !== "childList") return false;
        const nodes = Array.from(mutation.addedNodes || []).concat(Array.from(mutation.removedNodes || []));
        if (!nodes.length) return false;
        return nodes.every(function (node) {
            if (!node || node.nodeType !== 1) return true;
            if (node.hasAttribute && node.hasAttribute(GENERATED_ATTR)) return true;
            if (node.querySelector && node.querySelector("[" + GENERATED_ATTR + "=\"1\"]")) return true;
            return false;
        });
    }

    function scheduleApply() {
        if (applyTimer) window.clearTimeout(applyTimer);
        applyTimer = window.setTimeout(function () {
            applyTimer = null;
            applyConfig(currentConfig);
            mountContextAccess();
        }, 80);
    }

    function startObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(function (mutations) {
            if (mutations.length && mutations.every(mutationIsOnlyOurs)) return;
            scheduleApply();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function pickerService() {
        return window.PMKConfig && window.PMKConfig.elementPicker;
    }

    function pickerBanner(mode) {
        if (mode === "destination") {
            return t(
                "Clique sur le lien ou le bouton dont tu veux reprendre la destination — Échap annule",
                "Click the link or button whose destination you want to reuse — Esc cancels"
            );
        }
        if (mode === "anchor") {
            return t(
                "Clique sur l'élément de navigation qui servira de repère pour le nouvel élément — Échap annule",
                "Click the navigation item that will be used as the insertion reference — Esc cancels"
            );
        }
        return t(
            "Clique sur l'élément de navigation à modifier — Échap annule",
            "Click the navigation item to modify — Esc cancels"
        );
    }

    function pickForConfig(context, mode) {
        const service = pickerService();
        if (!service || typeof service.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }

        registerPickerAdapter();

        const root = context && context.rootObject ? context.rootObject : {};
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath.slice() : [];
        const index = ruleIndex(path);
        const rule = root && Array.isArray(root.rules) && index >= 0 ? root.rules[index] : null;

        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: firstConcretePage(rule || {}),
            rootObject: root,
            fieldPath: path,
            meta: {
                ruleIndex: index,
                pickMode: mode
            },
            adminContext: {
                sectionId: "rules",
                ruleIndex: index
            },
            options: {
                bannerText: pickerBanner(mode)
            },
            persistAfterPick: false
        });
    }

    function applyPickedCompanionData(root, path, result, mode) {
        const rule = ruleFromPath(root, path);
        if (!rule || !result) return;

        if (mode === "target") {
            rule.targetSelector = clean(result.selector || result.value);
            rule.targetHref = clean(result.href);
            rule.targetName = clean(result.targetName);
        } else if (mode === "anchor") {
            rule.anchorSelector = clean(result.selector || result.value);
            rule.anchorHref = clean(result.href);
            rule.anchorName = clean(result.targetName);
        } else if (mode === "destination") {
            const href = normalizeDestinationForStorage(result.href || result.value);
            if (href) {
                rule.destinationKind = "url";
                rule.destinationUrl = href;
            }
        }
    }

    function pickTarget(context) {
        return pickForConfig(context, "target");
    }

    function pickAnchor(context) {
        return pickForConfig(context, "anchor");
    }

    function pickDestination(context) {
        return pickForConfig(context, "destination");
    }

    function pickerResolveTarget(element, request) {
        const mode = request && request.meta && request.meta.pmkVisualEditorMode === "style-sample"
            ? "style-sample"
            : clean(request && request.meta && request.meta.pickMode);

        if (!element || element.nodeType !== 1) return null;

        if (mode === "destination") {
            return element.closest && element.closest("a[href]") || null;
        }

        if (mode === "style-sample") {
            return (element.closest && element.closest("a,button,[role='menuitem']")) || element;
        }

        return (element.closest && element.closest("a[href],button,[role='menuitem'],li")) || element;
    }

    function captureStyle(element) {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (editor && typeof editor.captureStyle === "function") {
            try { return editor.captureStyle(element); } catch (_) {}
        }
        if (!element || !window.getComputedStyle) return null;
        const cs = window.getComputedStyle(element);
        return {
            fontSize: cs.fontSize || "",
            color: cs.color || "",
            backgroundColor: cs.backgroundColor || "",
            fontWeight: cs.fontWeight || "",
            fontStyle: cs.fontStyle || "",
            textDecoration: cs.textDecoration || "",
            textDecorationLine: cs.textDecorationLine || "",
            textDecorationStyle: cs.textDecorationStyle || "",
            textDecorationColor: cs.textDecorationColor || "",
            borderRadius: cs.borderRadius || "",
            borderColor: cs.borderColor || "",
            borderWidth: cs.borderWidth || "",
            borderStyle: cs.borderStyle || "",
            boxShadow: cs.boxShadow || "",
            lineHeight: cs.lineHeight || "",
            letterSpacing: cs.letterSpacing || "",
            textTransform: cs.textTransform || "",
            opacity: cs.opacity || ""
        };
    }

    function pickerBuildResult(element, result, request) {
        const mode = request && request.meta && request.meta.pmkVisualEditorMode === "style-sample"
            ? "style-sample"
            : clean(request && request.meta && request.meta.pickMode);

        const clickable = clickableFrom(element);
        let href = clickable && clickable.getAttribute ? clean(clickable.getAttribute("href")) : "";

        /*
         * Si l'élément est déjà redirigé par ce module, un pick de cible ou
         * d'emplacement doit mémoriser l'identité Koha d'origine, pas l'URL
         * temporairement remplacée. Le pick « destination », lui, conserve
         * volontairement la destination actuellement visible.
         */
        if (
            mode !== "destination" &&
            clickable &&
            clickable.hasAttribute &&
            clickable.hasAttribute(ORIGINAL_HREF_ATTR)
        ) {
            href = clean(clickable.getAttribute(ORIGINAL_HREF_ATTR));
        }

        result.href = normalizeDestinationForStorage(href);

        if (mode === "destination") {
            result.value = result.href;
        }

        if (mode === "style-sample") {
            const parent = structuralUnitFor(clickable);
            result.sampledClasses = safeVisualClasses(copyClassNames(clickable));
            result.sampledParentClasses = safeVisualClasses(copyClassNames(parent));
            result.parentStyleSample = parent ? captureStyle(parent) : null;
        }

        return result;
    }

    function pickerApplyPending(draft, pending, picked) {
        const index = pending && pending.meta ? Number(pending.meta.ruleIndex) : -1;
        if (!draft || !Array.isArray(draft.rules) || !Number.isInteger(index) || index < 0 || !draft.rules[index]) {
            return draft;
        }
        const mode = clean(pending.meta && pending.meta.pickMode);
        const path = ["rules", index, mode === "anchor" ? "anchorSelector" : mode === "destination" ? "destinationUrl" : "targetSelector"];
        applyPickedCompanionData(draft, path, picked, mode);
        return draft;
    }

    function registerPickerAdapter() {
        const service = pickerService();
        if (!service || typeof service.register !== "function") return false;

        service.register(MODULE_ID, {
            resolveTarget: pickerResolveTarget,
            buildResult: pickerBuildResult,
            applyPending: pickerApplyPending
        });
        return true;
    }

    function sampledStyleForRule(sample, picked) {
        const style = sample && typeof sample === "object" ? Object.assign({}, sample) : {};
        const parent = picked && picked.parentStyleSample && typeof picked.parentStyleSample === "object"
            ? picked.parentStyleSample
            : null;

        /*
         * Les couleurs de menu sont souvent gérées par :hover / :focus.
         * On ne les fige en inline que si elles diffèrent réellement du parent.
         */
        style.copyColor = Boolean(parent && clean(style.color) && clean(style.color) !== clean(parent.color));
        style.copyBackground = Boolean(
            parent &&
            clean(style.backgroundColor) &&
            !rgbaIsTransparent(style.backgroundColor) &&
            clean(style.backgroundColor) !== clean(parent.backgroundColor)
        );
        return style;
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;

        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: true,
                livePreview: true
            },

            styleTargetUrl: function (context) {
                const rule = ruleFromPath(context && context.rootObject, context && context.fieldPath);
                return firstConcretePage(rule || {});
            },

            previewModel: function (context) {
                const rule = ruleFromPath(context && context.rootObject, context && context.fieldPath) || {};
                const s = rule.styleMode === "sample" && rule.sampledStyle ? rule.sampledStyle : {};
                const previewStyle = {};

                [
                    "fontSize", "fontWeight", "fontStyle", "textDecoration",
                    "textDecorationLine", "textDecorationStyle", "borderRadius",
                    "borderColor", "borderWidth", "borderStyle", "boxShadow",
                    "lineHeight", "letterSpacing", "textTransform", "opacity"
                ].forEach(function (prop) {
                    if (clean(s[prop])) previewStyle[prop] = s[prop];
                });

                if (s.copyColor === true && clean(s.color)) previewStyle.color = s.color;
                if (s.copyBackground === true && clean(s.backgroundColor)) previewStyle.backgroundColor = s.backgroundColor;

                return {
                    text: effectiveText(rule) || rule.name || t("Nouvel élément de navigation", "New navigation item"),
                    style: previewStyle,
                    icon: rule.showIcon === true && clean(rule.iconClass)
                        ? {
                            type: "fa",
                            className: rule.iconClass,
                            size: 14,
                            color: clean(s.color) || ""
                        }
                        : null
                };
            },

            applyStyleSample: function (context) {
                const rule = ruleFromPath(context && context.rootObject, context && context.fieldPath);
                if (!rule) return { rootObject: context && context.rootObject };

                rule.styleMode = "sample";
                rule.sampledStyle = sampledStyleForRule(context && context.sample, context && context.picked);
                rule.sampledClasses = Array.isArray(context && context.picked && context.picked.sampledClasses)
                    ? context.picked.sampledClasses.slice()
                    : [];
                rule.sampledParentClasses = Array.isArray(context && context.picked && context.picked.sampledParentClasses)
                    ? context.picked.sampledParentClasses.slice()
                    : [];

                return { rootObject: context && context.rootObject };
            },

            canPreview: function () {
                return currentConfig && currentConfig.rules.some(function (rule) {
                    return rule && rule.enabled !== false && ruleAppliesHere(rule);
                });
            },

            previewDraft: function (draft) {
                const before = clone(currentConfig || DEFAULT_CONFIG);
                applyConfig(draft);
                return function () {
                    applyConfig(before);
                };
            }
        });

        return true;
    }

    function validate(config) {
        const cfg = normalizeConfig(config);
        for (let i = 0; i < cfg.rules.length; i += 1) {
            const rule = cfg.rules[i];
            if (!rule || rule.enabled === false) continue;

            if (rule.allPages !== true && !parsePages(rule.pages).length) {
                return { ok: false, message: t("La règle " + (i + 1) + " doit avoir au moins une page Koha ou être appliquée à toutes les pages.", "Rule " + (i + 1) + " must have at least one Koha page or be applied to every page.") };
            }

            if (rule.action === "replace-url") {
                if (!rule.targetSelector && !rule.targetHref) {
                    return { ok: false, message: t("La règle " + (i + 1) + " doit cibler un élément de navigation.", "Rule " + (i + 1) + " must target a navigation item.") };
                }
            } else {
                if (!rule.anchorSelector && !rule.anchorHref) {
                    return { ok: false, message: t("La règle " + (i + 1) + " doit définir un emplacement d'insertion.", "Rule " + (i + 1) + " must define an insertion location.") };
                }
                if (!clean(rule.textFr) && !clean(rule.textEn)) {
                    return { ok: false, message: t("La règle " + (i + 1) + " doit avoir un libellé français ou anglais.", "Rule " + (i + 1) + " must have a French or English label.") };
                }
                if (rule.showIcon === true && !clean(rule.iconClass)) {
                    return { ok: false, message: t("La règle " + (i + 1) + " affiche une icône mais sa classe Font Awesome est vide.", "Rule " + (i + 1) + " shows an icon but its Font Awesome class is empty.") };
                }
            }

            if (rule.destinationKind === "report") {
                if (!/^\d+$/.test(clean(rule.reportId))) {
                    return { ok: false, message: t("La règle " + (i + 1) + " doit indiquer un identifiant de rapport valide.", "Rule " + (i + 1) + " must provide a valid report ID.") };
                }
            } else if (!destinationForRule(rule)) {
                return {ok:false,message:t('La destination est vide, contient des identifiants ou utilise un protocole non autorisé.','The destination is empty, contains credentials or uses an unsupported protocol.')};
            } else if (!clean(rule.destinationUrl)) {
                return { ok: false, message: t("La règle " + (i + 1) + " doit indiquer une destination.", "Rule " + (i + 1) + " must provide a destination.") };
            }
        }

        return { ok: true };
    }

    function ruleTitle(item, index) {
        if (item && clean(item.name)) return item.name;
        if (item && item.action === "replace-url") {
            return t("Redirection ", "Redirect ") + (index + 1);
        }
        return t("Nouvel élément ", "New item ") + (index + 1);
    }

    function isAction(root, path, action) {
        const rule = ruleFromPath(root, path);
        return Boolean(rule && rule.action === action);
    }

    function isUrlDestination(root, path) {
        const rule = ruleFromPath(root, path);
        return Boolean(rule && rule.destinationKind === "url");
    }

    function isReportDestination(root, path) {
        const rule = ruleFromPath(root, path);
        return Boolean(rule && rule.destinationKind === "report");
    }

    function isSampleStyle(root, path) {
        const rule = ruleFromPath(root, path);
        return Boolean(rule && rule.styleMode === "sample");
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Navigation personnalisée", en: "Custom navigation" },
            description: {
                fr: "Ajoute des éléments dans la navigation Koha ou remplace uniquement l'URL cible d'un élément existant. Les emplacements, destinations et apparences peuvent être choisis directement sur les pages Koha. Chaque règle peut être limitée à certaines pages ou appliquée à toutes les pages.",
                en: "Adds items to Koha navigation or replaces only the target URL of an existing item. Locations, destinations and appearance can be picked directly from Koha pages. Each rule can be limited to selected pages or applied to every page."
            },
            category: { fr: "Interface / navigation", en: "Interface / navigation" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "information",
                    label: { fr: "Fonctionnement", en: "How it works" },
                    description: {
                        fr: "Deux actions seulement : « Ajouter un élément » crée une nouvelle entrée de navigation ; « Remplacer l’URL cible » conserve l’élément Koha tel quel et ne change que sa destination. Le module ne copie jamais les événements, identifiants HTML ou comportements métier d’un élément prélevé.",
                        en: "Only two actions: “Add an item” creates a new navigation entry; “Replace target URL” keeps the Koha item unchanged and only changes its destination. The module never copies events, HTML IDs or business behaviour from a sampled element."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Module actif", en: "Module enabled" } }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Éléments de navigation", en: "Navigation items" },
                    description: {
                        fr: "Les cinq règles livrées reproduisent les comportements historiques des scripts 052 et 076. Elles peuvent être modifiées, désactivées, supprimées ou complétées.",
                        en: "The five default rules reproduce the historical behaviour of scripts 052 and 076. They can be edited, disabled, removed or extended."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Règles configurées", en: "Configured rules" },
                            addLabel: { fr: "Ajouter un élément ou une redirection", en: "Add an item or redirect" },
                            reorder: true,
                            newItem: newRule,
                            liveTitleKey: "name",
                            itemTitle: ruleTitle,
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                {
                                    key: "name",
                                    type: "text",
                                    label: { fr: "Nom de la règle", en: "Rule name" },
                                    placeholder: { fr: "Ex. Rapport des transferts à recevoir", en: "E.g. Transfers to receive report" }
                                },
                                {
                                    key: "action",
                                    type: "select",
                                    label: { fr: "Action", en: "Action" },
                                    options: [
                                        { value: "add", label: { fr: "Ajouter un élément de menu", en: "Add a menu item" } },
                                        { value: "replace-url", label: { fr: "Remplacer l’URL cible d’un élément existant", en: "Replace an existing item's target URL" } }
                                    ],
                                    refreshOnChange: true
                                },
                                {
                                    key: "allPages",
                                    type: "boolean",
                                    refreshOnChange: true,
                                    label: { fr: "Appliquer sur toutes les pages Koha", en: "Apply on every Koha page" },
                                    help: {
                                        fr: "La liste des pages reste mémorisée. Si vous décochez ensuite cette option, les pages sélectionnées réapparaissent.",
                                        en: "The page list remains stored. If you later disable this option, the selected pages reappear."
                                    }
                                },
                                {
                                    key: "pages",
                                    type: "textarea",
                                    rows: 2,
                                    label: { fr: "Pages Koha concernées", en: "Koha pages" },
                                    placeholder: { fr: "/cgi-bin/koha/circ/circulation-home.pl", en: "/cgi-bin/koha/circ/circulation-home.pl" },
                                    help: {
                                        fr: "Une page par ligne. Le premier chemin sert de page de référence aux outils de pick et à la pipette.",
                                        en: "One page per line. The first path is used as the picker and eyedropper reference page."
                                    },
                                    when: function (root, path) {
                                        const rule = ruleFromPath(root, path);
                                        return Boolean(rule && rule.allPages !== true);
                                    }
                                },

                                {
                                    key: "targetSelector",
                                    type: "elementPicker",
                                    label: { fr: "Élément de navigation à modifier", en: "Navigation item to modify" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    emptyLabel: { fr: "Aucun élément choisi visuellement", en: "No item visually selected" },
                                    allowManual: true,
                                    pick: pickTarget,
                                    onPick: function (root, path, result) {
                                        applyPickedCompanionData(root, path, result, "target");
                                    },
                                    when: function (root, path) { return isAction(root, path, "replace-url"); },
                                    help: {
                                        fr: "Le moteur de pick commun mémorise un sélecteur stable et, si possible, l'URL Koha d'origine comme solution de repli.",
                                        en: "The shared picker stores a stable selector and, when possible, the original Koha URL as a fallback."
                                    }
                                },
                                {
                                    key: "targetName",
                                    type: "readonly",
                                    label: { fr: "Élément détecté", en: "Detected item" },
                                    when: function (root, path) { return isAction(root, path, "replace-url"); }
                                },

                                {
                                    key: "anchorSelector",
                                    type: "elementPicker",
                                    label: { fr: "Emplacement : élément de référence", en: "Location: reference item" },
                                    pickLabel: { fr: "Choisir l’emplacement sur la page", en: "Choose location on page" },
                                    emptyLabel: { fr: "Aucun emplacement choisi visuellement", en: "No location visually selected" },
                                    allowManual: true,
                                    pick: pickAnchor,
                                    onPick: function (root, path, result) {
                                        applyPickedCompanionData(root, path, result, "anchor");
                                    },
                                    when: function (root, path) { return isAction(root, path, "add"); },
                                    help: {
                                        fr: "Clique sur un élément du menu près duquel le nouvel élément doit être inséré.",
                                        en: "Click a menu item near where the new item should be inserted."
                                    }
                                },
                                {
                                    key: "anchorName",
                                    type: "readonly",
                                    label: { fr: "Repère détecté", en: "Detected reference" },
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    key: "position",
                                    type: "select",
                                    label: { fr: "Position par rapport au repère", en: "Position relative to reference" },
                                    options: [
                                        { value: "before", label: { fr: "Avant", en: "Before" } },
                                        { value: "after", label: { fr: "Après", en: "After" } },
                                        { value: "inside-start", label: { fr: "À l’intérieur, au début", en: "Inside, at start" } },
                                        { value: "inside-end", label: { fr: "À l’intérieur, à la fin", en: "Inside, at end" } }
                                    ],
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    key: "textFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" },
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    key: "textEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" },
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    key: "showIcon",
                                    type: "boolean",
                                    label: { fr: "Afficher une icône Font Awesome", en: "Show a Font Awesome icon" },
                                    refreshOnChange: true,
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    key: "iconClass",
                                    type: "text",
                                    label: { fr: "Classe de l’icône", en: "Icon class" },
                                    placeholder: { fr: "fa-solid fa-link", en: "fa-solid fa-link" },
                                    when: function (root, path) {
                                        const rule = ruleFromPath(root, path);
                                        return Boolean(rule && rule.action === "add" && rule.showIcon === true);
                                    }
                                },

                                {
                                    key: "styleMode",
                                    type: "select",
                                    label: { fr: "Apparence", en: "Appearance" },
                                    options: [
                                        { value: "auto", label: { fr: "S’intégrer automatiquement à la navigation cible", en: "Automatically match target navigation" } },
                                        { value: "sample", label: { fr: "Utiliser une apparence prélevée avec la pipette", en: "Use appearance sampled with eyedropper" } }
                                    ],
                                    refreshOnChange: true,
                                    when: function (root, path) { return isAction(root, path, "add"); },
                                    help: {
                                        fr: "Le mode automatique reprend les classes visuelles sûres de l’élément voisin. La pipette permet de prendre une autre référence visuelle.",
                                        en: "Automatic mode reuses safe visual classes from the neighbouring item. The eyedropper lets you choose another visual reference."
                                    }
                                },
                                {
                                    type: "visualPreview",
                                    label: { fr: "Aperçu du nouvel élément", en: "New item preview" },
                                    when: function (root, path) { return isAction(root, path, "add"); }
                                },
                                {
                                    type: "styleEyedropper",
                                    label: { fr: "Pipette d’apparence", en: "Appearance eyedropper" },
                                    buttonLabel: { fr: "Prélever l’apparence d’un élément…", en: "Sample an item's appearance…" },
                                    iconClass: "fa fa-eyedropper",
                                    sectionId: "rules",
                                    when: function (root, path) { return isAction(root, path, "add"); },
                                    help: {
                                        fr: "La pipette reprend uniquement les classes visuelles sûres et quelques propriétés d’apparence. Elle ne copie jamais l’ID, l’URL, les événements ou les comportements Koha.",
                                        en: "The eyedropper only reuses safe visual classes and selected appearance properties. It never copies IDs, URLs, events or Koha behaviour."
                                    }
                                },
                                {
                                    type: "custom",
                                    when: function (root, path) {
                                        return isAction(root, path, "add") && isSampleStyle(root, path);
                                    },
                                    render: function (context) {
                                        const note = document.createElement("div");
                                        note.className = "alert alert-light border py-2 px-3 mb-0";
                                        note.textContent = t(
                                            "Une apparence a été prélevée. Pour revenir au comportement natif du menu cible, choisis « S’intégrer automatiquement ».",
                                            "An appearance has been sampled. To return to the target menu's native behaviour, choose “Automatically match target navigation”."
                                        );
                                        return note;
                                    }
                                },

                                {
                                    key: "destinationKind",
                                    type: "select",
                                    label: { fr: "Type de destination", en: "Destination type" },
                                    options: [
                                        { value: "url", label: { fr: "Page Koha / URL", en: "Koha page / URL" } },
                                        { value: "report", label: { fr: "Rapport guidé Koha", en: "Koha guided report" } }
                                    ],
                                    refreshOnChange: true
                                },
                                {
                                    key: "reportId",
                                    type: "number",
                                    min: 1,
                                    step: 1,
                                    label: { fr: "Identifiant du rapport", en: "Report ID" },
                                    when: isReportDestination,
                                    help: {
                                        fr: "Indique uniquement le numéro du rapport. PimpMyKoha construit l’URL.",
                                        en: "Enter only the report number. PimpMyKoha builds the URL."
                                    }
                                },
                                {
                                    key: "destinationUrl",
                                    type: "text",
                                    label: { fr: "Destination", en: "Destination" },
                                    placeholder: { fr: "/cgi-bin/koha/… ou https://…", en: "/cgi-bin/koha/… or https://…" },
                                    when: isUrlDestination
                                },
                                {
                                    key: "destinationUrl",
                                    type: "elementPicker",
                                    label: { fr: "Ou choisir la destination sur la page", en: "Or choose destination on page" },
                                    pickLabel: { fr: "Choisir la destination sur la page", en: "Choose destination on page" },
                                    emptyLabel: { fr: "Aucune destination choisie", en: "No destination selected" },
                                    clearable: false,
                                    pick: pickDestination,
                                    onPick: function (root, path, result) {
                                        applyPickedCompanionData(root, path, result, "destination");
                                    },
                                    when: isUrlDestination,
                                    help: {
                                        fr: "Clique sur un lien Koha existant : seule sa destination est récupérée. Son texte, son style et son comportement ne sont pas copiés.",
                                        en: "Click an existing Koha link: only its destination is captured. Its text, style and behaviour are not copied."
                                    }
                                }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function mountContextAccess() {
        const api = window.PMKConfig;
        if (!api || typeof api.mountContextButton !== "function") return;

        let anchor = document.querySelector(".transfers h3");
        if (!anchor) anchor = document.querySelector(".circ-nav-menu h5");
        if (!anchor) {
            const candidate = document.querySelector('a[href*="/cgi-bin/koha/circ/view_holdsqueue.pl"], a[href*="/cgi-bin/koha/circ/transferstoreceive.pl"], a[href*="/cgi-bin/koha/circ/transfers_to_send.pl"]');
            if (candidate) anchor = candidate;
        }
        if (!anchor) return;

        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: CONTEXT_KEY_PREFIX + window.location.pathname,
                context: {
                    sectionId: "rules",
                    pagePath: window.location.pathname
                }
            });
        } catch (_) {}
    }

    async function loadConfig() {
        const api = window.PMKConfig;
        if (!api || typeof api.getConfig !== "function") return clone(DEFAULT_CONFIG);
        try {
            const value = await api.getConfig(MODULE_ID);
            return normalizeConfig(value || DEFAULT_CONFIG);
        } catch (_) {
            return clone(DEFAULT_CONFIG);
        }
    }

    function registerModule() {
        const api = window.PMKConfig;
        if (!api || typeof api.registerModule !== "function") return false;

        registerPickerAdapter();
        registerVisualEditorAdapter();

        if (!registered) {
            api.registerModule(moduleDefinition());
            registered = true;
        }
        return true;
    }

    async function startWithCore() {
        if (!registerModule()) return false;

        const config = await loadConfig();
        applyConfig(config);
        startObserver();
        mountContextAccess();

        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (next) {
                applyConfig(next || DEFAULT_CONFIG);
                startObserver();
                mountContextAccess();
            });
        }
        return true;
    }

    function startWithoutCore() {
        applyConfig(DEFAULT_CONFIG);
        startObserver();

        let attempts = 0;
        if (coreWaitTimer) window.clearInterval(coreWaitTimer);
        coreWaitTimer = window.setInterval(function () {
            attempts += 1;
            if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
                startWithCore();
            } else if (attempts >= 100) {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
            }
        }, 100);
    }

    function init() {
        if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
            startWithCore();
        } else {
            startWithoutCore();
        }

        /*
         * Repassages défensifs : certaines zones de navigation peuvent être
         * injectées après DOMContentLoaded par Koha ou par un autre module.
         */
        window.setTimeout(scheduleApply, 300);
        window.setTimeout(scheduleApply, 1200);
    }

    window.PMK052Navigation = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULT_CONFIG),
        normalizeConfig: normalizeConfig,
        applyConfig: applyConfig,
        restore: restoreRuntime,
        reapply: scheduleApply
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("052-modify-circulation-menu-links.js");
} catch (error) { window.PMKNonPlugin.errors.push("052-modify-circulation-menu-links.js: "+error.message); console.error("[PMK] 052-modify-circulation-menu-links.js",error); };
try {
/*
 Nom du fichier: 055-facets-drawer.js
 Module PMK: Facettes de recherche
 Version: 3.8.2-pmk-quickfilters
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha / refactorisation PimpMyKoha

 Fonction:
 - transforme les catégories de facettes de catalogue/search.pl en tiroirs accessibles ;
 - permet de préparer plusieurs ajouts/retraits de facettes avant de relancer la recherche ;
 - distingue clairement l’annulation des modifications en attente de l’effacement de tous les filtres déjà appliqués ;
 - conserve les ouvertures/fermetures manuelles des tiroirs pendant les recalculs asynchrones ;
 - conserve les paramètres de recherche Koha (limit / nolimit) et utilise le préfixe mc- pour regrouper en OU les valeurs d’une même facette ;
 - recalcule les valeurs des familles de facettes actives en facettage disjonctif afin de conserver les autres choix possibles ;
 - signale visuellement les facettes déjà actives ;
 - reprend les deux boutons historiques du 064 sous forme de filtres rapides harmonisés avec Koha ;
 - « Disponibles uniquement » utilise le vrai filtre Koha limit=available ;
 - « Disponibles ici uniquement » reprend la logique historique : il identifie les notices ayant un exemplaire réellement disponible dans le site de connexion ;
 - les libellés des filtres rapides sont personnalisables pour leurs états inactif, actif et indisponible ;
 - les notices hors filtre local peuvent être masquées, atténuées, repliées ou atténuées et reléguées en bas ;
 - ce filtre local reste actif pendant la navigation entre les pages de résultats et se réapplique automatiquement ;
 - peut masquer la facette native « Disponible uniquement » lorsque le bouton rapide la remplace ;
 - permet de renommer les groupes de facettes via des règles FR/EN ;
 - permet de conserver le "Afficher plus / moins" natif ou d'afficher toutes les valeurs ;
 - ne dépend d'aucun texte anglais pour identifier une facette active ;
 - respecte le DOM Koha et restaure ses éléments natifs lors d'une reconfiguration ;
 - FR/EN, responsive, accessible, sans dépendance jQuery.
*/

(function () {
    "use strict";

    const MODULE_ID = "search-facets";
    const MODULE_VERSION = "3.8.0-pmk-quickfilters";
    const PAGE_ID = "catalogue.search.results";
    const PAGE_PATH = "/cgi-bin/koha/catalogue/search.pl";
    const SCRIPT_GUARD = "__pmk055SearchFacetsV3";
    const STYLE_ID = "pmk055-search-facets-style";
    const GENERATED_ATTR = "data-pmk055-generated";
    const NATIVE_TEXT_ATTR = "data-pmk055-native-text";
    const TEMP_ID_ATTR = "data-pmk055-temp-id";
    const LOCAL_HIDDEN_CLASS = "pmk055-local-availability-hidden";
    const LOCAL_DIMMED_CLASS = "pmk055-local-availability-dimmed";
    const LOCAL_COLLAPSED_CLASS = "pmk055-local-availability-collapsed";
    const LOCAL_COMPACT_CELL_CLASS = "pmk055-local-compact-cell";
    const LOCAL_ORIGINAL_CELL_CLASS = "pmk055-local-original-cell";
    const LOCAL_EXCLUDED_CLASS = "pmk055-local-availability-excluded";
    const LOCAL_ORIGINAL_INDEX_ATTR = "data-pmk055-local-original-index";
    const LOCAL_FILTER_STORAGE_KEY = "pmk055:local-availability";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    if (window.location.pathname !== PAGE_PATH) return;

    const DEFAULTS = {
        enabled: true,
        page: {
            enabled: true,
            pageId: PAGE_ID,
            path: PAGE_PATH
        },
        drawers: true,
        initialState: "closed",
        openActive: true,
        multiSelect: true,
        valuesMode: "all",
        recalculateActiveFacets: true,
        highlightActiveFacets: true,
        hideAvailabilityFacet: true,
        quickFilters: {
            availability: {
                enabled: true,
                labelFr: "Documents disponibles uniquement",
                labelEn: "Available records only",
                activeLabelFr: "✓ Documents disponibles uniquement",
                activeLabelEn: "✓ Available records only",
                unavailableLabelFr: "Filtre de disponibilité indisponible",
                unavailableLabelEn: "Availability filter unavailable"
            },
            local: {
                enabled: true,
                labelFr: "Disponibles ici uniquement",
                labelEn: "Available here only",
                activeLabelFr: "✓ Disponibles ici uniquement",
                activeLabelEn: "✓ Available here only",
                unavailableLabelFr: "Disponibilité locale indisponible",
                unavailableLabelEn: "Local availability unavailable",
                persistAcrossPages: true,
                resultDisplay: "dimmed"
            }
        },
        groupRenames: []
    };

    let currentConfig = clone(DEFAULTS);
    let unsubscribe = null;
    let startRetry = null;
    let tempIdCounter = 0;
    let facetRefreshInProgress = false;
    let lastFacetRefreshSignature = "";
    let localAvailabilityActive = false;
    let localAvailabilityHydrated = false;
    let localResultsObserver = null;
    let localFilterScheduled = false;
    let navigationRefreshTimer = null;
    let lastNavigationSearch = window.location.search;

    const pendingAdds = new Set();
    const pendingRemoves = new Set();
    const drawerStateOverrides = new Map();

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function merge(base, extra) {
        const out = clone(base);
        const src = extra && typeof extra === "object" ? extra : {};
        Object.keys(src).forEach(function (key) {
            const incoming = src[key];
            if (
                incoming && typeof incoming === "object" && !Array.isArray(incoming) &&
                out[key] && typeof out[key] === "object" && !Array.isArray(out[key])
            ) {
                out[key] = Object.assign({}, out[key], incoming);
            } else {
                out[key] = incoming;
            }
        });
        return out;
    }

    function normalizeConfig(config) {
        const value = merge(DEFAULTS, config || {});
        value.enabled = value.enabled !== false;
        value.page = Object.assign({}, DEFAULTS.page, value.page || {});
        value.page.enabled = value.page.enabled !== false;
        value.page.pageId = PAGE_ID;
        value.page.path = PAGE_PATH;
        value.drawers = value.drawers !== false;
        value.openActive = value.openActive !== false;
        value.multiSelect = value.multiSelect !== false;
        value.recalculateActiveFacets = value.recalculateActiveFacets !== false;
        value.highlightActiveFacets = value.highlightActiveFacets !== false;
        value.hideAvailabilityFacet = value.hideAvailabilityFacet !== false;

        const quick = value.quickFilters && typeof value.quickFilters === "object"
            ? value.quickFilters
            : {};
        value.quickFilters = {
            availability: Object.assign(
                {},
                DEFAULTS.quickFilters.availability,
                quick.availability && typeof quick.availability === "object" ? quick.availability : {}
            ),
            local: Object.assign(
                {},
                DEFAULTS.quickFilters.local,
                quick.local && typeof quick.local === "object" ? quick.local : {}
            )
        };
        ["availability", "local"].forEach(function (key) {
            const item = value.quickFilters[key];
            const fallback = DEFAULTS.quickFilters[key];
            item.enabled = item.enabled !== false;
            item.labelFr = String(item.labelFr || fallback.labelFr).trim() || fallback.labelFr;
            item.labelEn = String(item.labelEn || fallback.labelEn).trim() || fallback.labelEn;
            item.activeLabelFr = String(item.activeLabelFr || fallback.activeLabelFr).trim() || fallback.activeLabelFr;
            item.activeLabelEn = String(item.activeLabelEn || fallback.activeLabelEn).trim() || fallback.activeLabelEn;
            item.unavailableLabelFr = String(item.unavailableLabelFr || fallback.unavailableLabelFr || item.labelFr).trim() || fallback.unavailableLabelFr || item.labelFr;
            item.unavailableLabelEn = String(item.unavailableLabelEn || fallback.unavailableLabelEn || item.labelEn).trim() || fallback.unavailableLabelEn || item.labelEn;
            if (key === "local") {
                item.persistAcrossPages = item.persistAcrossPages !== false;
                if (!["hidden", "dimmed", "collapsed", "dimmed-bottom"].includes(item.resultDisplay)) {
                    item.resultDisplay = DEFAULTS.quickFilters.local.resultDisplay;
                }
            }
        });

        value.groupRenames = Array.isArray(value.groupRenames)
            ? value.groupRenames.map(function (rule) {
                const item = rule && typeof rule === "object" ? rule : {};
                return {
                    enabled: item.enabled !== false,
                    sourceLabel: String(item.sourceLabel || "").trim(),
                    groupKey: String(item.groupKey || "").trim(),
                    fr: String(item.fr || "").trim(),
                    en: String(item.en || "").trim()
                };
            })
            : [];
        if (!["closed", "open"].includes(value.initialState)) value.initialState = DEFAULTS.initialState;
        if (!["all", "koha"].includes(value.valuesMode)) value.valuesMode = DEFAULTS.valuesMode;
        return value;
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try {
                const lang = String(api.getLanguage() || "").toLowerCase();
                if (lang.startsWith("en")) return "en";
                if (lang.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        const htmlLang = String(document.documentElement.getAttribute("lang") || "").toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function directChild(parent, selector) {
        if (!parent) return null;
        return Array.from(parent.children || []).find(function (child) {
            try { return child.matches(selector); } catch (_) { return false; }
        }) || null;
    }

    function directChildren(parent, selector) {
        if (!parent) return [];
        return Array.from(parent.children || []).filter(function (child) {
            try { return child.matches(selector); } catch (_) { return false; }
        });
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #search-facets.pmk055-enhanced {
                --pmk055-border: var(--bs-border-color, #dee2e6);
                --pmk055-muted: var(--bs-secondary-color, #6c757d);
                --pmk055-soft: rgba(0, 0, 0, .035);
            }

            #search-facets.pmk055-enhanced .pmk055-native-heading,
            #search-facets.pmk055-enhanced [${NATIVE_TEXT_ATTR}="1"].pmk055-native-heading {
                display: none !important;
            }

            #search-facets.pmk055-drawers > ul > li {
                border-bottom: 1px solid var(--pmk055-border);
                padding-top: .08rem;
                padding-bottom: .08rem;
            }

            #search-facets.pmk055-drawers > ul > li:last-child {
                border-bottom: 0;
            }

            #search-facets .pmk055-renamed-heading {
                display: block;
                font-weight: 600;
                margin: .25rem 0 .35rem;
                line-height: 1.25;
            }

            #search-facets .pmk055-facet-toggle {
                appearance: none;
                width: 100%;
                border: 0;
                background: transparent;
                color: inherit;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: .5rem;
                margin: 0;
                padding: .42rem .15rem;
                font: inherit;
                font-weight: 600;
                line-height: 1.25;
                text-align: left;
                cursor: pointer;
                border-radius: .25rem;
            }

            #search-facets .pmk055-facet-toggle:hover,
            #search-facets .pmk055-facet-toggle:focus-visible {
                background: var(--pmk055-soft);
            }

            #search-facets .pmk055-facet-toggle:focus-visible {
                outline: 2px solid currentColor;
                outline-offset: 2px;
            }

            #search-facets .pmk055-facet-toggle-icon {
                flex: 0 0 auto;
                opacity: .7;
                transition: transform .14s ease;
            }

            #search-facets .pmk055-open > .pmk055-facet-toggle .pmk055-facet-toggle-icon {
                transform: rotate(90deg);
            }

            #search-facets.pmk055-drawers > ul > li > ul {
                display: none;
                margin-top: .05rem;
                padding-top: .15rem;
                padding-bottom: .35rem;
            }

            #search-facets.pmk055-drawers > ul > li.pmk055-open > ul {
                display: block;
            }

            #search-facets.pmk055-values-all .collapsible-facet {
                display: list-item !important;
            }

            #search-facets.pmk055-values-all li.moretoggle {
                display: none !important;
            }

            #search-facets.pmk055-multiselect .pmk055-native-choice {
                display: none !important;
            }

            #search-facets .pmk055-choice-ui {
                display: flex;
                align-items: flex-start;
                gap: .42rem;
                min-width: 0;
                padding: .16rem .08rem;
                font-weight: normal;
            }

            #search-facets .pmk055-choice-ui:hover {
                background: var(--pmk055-soft);
                border-radius: .25rem;
            }

            #search-facets .pmk055-choice-ui .form-check-input {
                -webkit-appearance: checkbox !important;
                appearance: auto !important;
                box-sizing: border-box !important;
                flex: 0 0 auto;
                width: 1.08rem !important;
                height: 1.08rem !important;
                min-width: 1.08rem !important;
                min-height: 1.08rem !important;
                margin: .12rem 0 0 0 !important;
                padding: 0 !important;
                opacity: 1 !important;
                visibility: visible !important;
                cursor: pointer;
                accent-color: var(--bs-primary, #0d6efd);
            }

            #search-facets .pmk055-choice-ui.pmk055-selected {
                background: var(--pmk055-soft);
                border-radius: .25rem;
            }

            #search-facets .pmk055-choice-ui.pmk055-active {
                background: rgba(var(--bs-primary-rgb, 13, 110, 253), .10);
                border-left: 3px solid var(--bs-primary, #0d6efd);
                border-radius: .25rem;
                padding-left: .35rem;
                font-weight: 600;
            }

            #search-facets .pmk055-active-badge,
            #search-facets .pmk055-group-active-count {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                flex: 0 0 auto;
                min-height: 1.25rem;
                padding: .08rem .38rem;
                border: 1px solid rgba(var(--bs-primary-rgb, 13, 110, 253), .35);
                border-radius: 999px;
                background: rgba(var(--bs-primary-rgb, 13, 110, 253), .08);
                color: var(--bs-primary, #0d6efd);
                font-size: .75em;
                font-weight: 600;
                line-height: 1.1;
                white-space: nowrap;
            }

            #search-facets .pmk055-facet-toggle-main {
                display: flex;
                align-items: center;
                gap: .4rem;
                min-width: 0;
            }

            #search-facets .pmk055-hidden-availability {
                display: none !important;
            }

            #search-facets .pmk055-actions.is-refreshing .pmk055-actions-status::before {
                content: "↻ ";
            }

            #search-facets .pmk055-choice-label {
                flex: 1 1 auto;
                min-width: 0;
                cursor: pointer;
                overflow-wrap: anywhere;
            }

            #search-facets .pmk055-choice-count {
                color: var(--pmk055-muted);
                white-space: nowrap;
                font-size: .92em;
            }

            #search-facets .pmk055-choice-ui.pmk055-pending {
                font-weight: 600;
            }

            #search-facets .pmk055-choice-ui.pmk055-pending .pmk055-choice-label::after {
                content: " •";
                color: var(--pmk055-muted);
            }

            #search-facets .pmk055-actions {
                margin: 0;
                padding: .5rem .55rem .55rem;
                border-bottom: 1px solid var(--pmk055-border);
                background: rgba(255,255,255,.32);
            }

            #search-facets .pmk055-actions-status {
                display: block;
                color: var(--pmk055-muted);
                font-size: .88em;
                line-height: 1.3;
                margin-bottom: .4rem;
            }

            #search-facets .pmk055-actions-buttons {
                display: flex;
                flex-wrap: wrap;
                gap: .35rem;
            }

            #search-facets .pmk055-actions-buttons .btn {
                flex: 1 1 auto;
                white-space: normal;
            }

            #pmk-search-quick-filters {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .35rem;
                margin: 0 0 .55rem;
                padding: .4rem .45rem;
                border: 1px solid var(--bs-border-color, #dee2e6);
                border-radius: .35rem;
                background: var(--bs-body-bg, #fff);
            }

            #pmk-search-quick-filters .pmk-search-quick-filter {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: .32rem;
                min-height: 2rem;
                margin: 0;
                padding: .28rem .55rem;
                line-height: 1.2;
                white-space: normal;
                text-align: center;
            }

            #pmk-search-quick-filters .pmk-search-quick-filter[aria-pressed="true"] {
                font-weight: 600;
                box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .18);
            }

            #pmk-search-quick-filters.pmk055-has-active-quick-filter {
                border-left: 3px solid var(--bs-primary, #0d6efd);
                background: rgba(var(--bs-primary-rgb, 13, 110, 253), .045);
            }

            #pmk-search-quick-filters .pmk055-quick-active-count {
                display: inline-flex;
                align-items: center;
                min-height: 1.8rem;
                padding: .14rem .48rem;
                border-radius: 999px;
                background: rgba(var(--bs-primary-rgb, 13, 110, 253), .10);
                color: var(--bs-primary, #0d6efd);
                font-size: .78rem;
                font-weight: 600;
                white-space: nowrap;
            }

            #pmk-search-quick-filters .pmk-search-quick-filter:disabled {
                cursor: not-allowed;
                opacity: .6;
            }

            #pmk-search-quick-filters .pmk-search-quick-status {
                display: inline-flex;
                align-items: center;
                min-height: 2rem;
                padding: .18rem .5rem;
                border-radius: .35rem;
                color: var(--bs-secondary-color, #6c757d);
                font-size: .82rem;
                line-height: 1.2;
            }

            #bookbag_form tbody tr.${LOCAL_HIDDEN_CLASS} {
                display: none !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_DIMMED_CLASS} {
                opacity: .46;
                filter: grayscale(.35);
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_DIMMED_CLASS}:hover {
                opacity: .72;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} {
                opacity: .78;
                font-size: .92em;
                background: rgba(108,117,125,.035);
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td {
                padding-top: .28rem !important;
                padding-bottom: .28rem !important;
                vertical-align: middle !important;
                border-top-color: rgba(108,117,125,.16) !important;
            }

            /* On conserve la vraie ligne Koha : couverture miniature + titre + auteur. */
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg {
                width: 48px !important;
                min-width: 48px !important;
                max-width: 48px !important;
                padding-left: .35rem !important;
                padding-right: .25rem !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg img {
                max-width: 34px !important;
                max-height: 48px !important;
                width: auto !important;
                height: auto !important;
                object-fit: contain !important;
                margin: 0 !important;
                float: none !important;
                filter: grayscale(.2);
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg .hint,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg .no-image {
                display: none !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td:nth-child(2) {
                width: 26px !important;
                min-width: 26px !important;
                padding-left: .15rem !important;
                padding-right: .2rem !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-cell {
                min-width: 0 !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-card {
                margin: 0 !important;
                padding: 0 !important;
                border: 0 !important;
                background: transparent !important;
                box-shadow: none !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-head {
                min-height: 0 !important;
                margin: 0 !important;
                padding: 0 !important;
                border: 0 !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-head-main {
                min-width: 0 !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .titlebibresult,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .titlemikaresult,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .firstresult {
                display: block !important;
                min-width: 0 !important;
                margin: 0 !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .titlebibresult a {
                display: block;
                max-width: 70ch;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-weight: 650;
                line-height: 1.2;
            }

            /* Tout ce qui alourdit la notice disparaît en vue repliée. */
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-head-tools,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-card .hold,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-card .btn-show-more,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-card .notice-details,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .copy-title-result,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-cell > .kx-biblio-line:not(.kx-notice-meta-author),
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kxri-panel,
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .availability {
                display: none !important;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-cell > .kx-notice-meta-author {
                display: block !important;
                margin: .08rem 0 0 !important;
                padding: 0 !important;
                border: 0 !important;
                color: var(--bs-secondary-color, #6c757d);
                font-size: .88em;
                line-height: 1.2;
                list-style: none !important;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kx-notice-cell > .kx-notice-meta-author strong {
                font-weight: 500;
            }

            /* La colonne exemplaires devient simplement un indicateur d'état. */
            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kxri-cell {
                width: 170px !important;
                min-width: 145px !important;
                text-align: right;
            }

            #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kxri-cell::before {
                content: attr(data-pmk055-local-status-label);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 1.55rem;
                padding: .12rem .48rem;
                border: 1px solid rgba(108,117,125,.30);
                border-radius: 999px;
                background: rgba(108,117,125,.08);
                color: var(--bs-secondary-color, #6c757d);
                font-size: .78rem;
                font-weight: 650;
                line-height: 1.15;
                white-space: nowrap;
            }

            @media (max-width: 768px) {
                #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg {
                    width: 40px !important;
                    min-width: 40px !important;
                }
                #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} > td.bookcoverimg img {
                    max-width: 28px !important;
                    max-height: 40px !important;
                }
                #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kxri-cell {
                    width: auto !important;
                    min-width: 0 !important;
                }
                #bookbag_form tbody tr.${LOCAL_EXCLUDED_CLASS}.${LOCAL_COLLAPSED_CLASS} .kxri-cell::before {
                    white-space: normal;
                    text-align: center;
                }
            }

            @media (max-width: 768px) {
                #pmk-search-quick-filters {
                    align-items: stretch;
                }

                #pmk-search-quick-filters .pmk-search-quick-filter {
                    flex: 1 1 12rem;
                }
                #search-facets .pmk055-facet-toggle {
                    min-height: 2.35rem;
                    padding: .52rem .2rem;
                }

                #search-facets .pmk055-choice-ui {
                    padding-top: .3rem;
                    padding-bottom: .3rem;
                }
            }

            @media (max-width: 575.98px) {
                #search-facets,
                #search-facets > ul,
                #search-facets > ul > li {
                    min-width: 0;
                    max-width: 100%;
                }

                #search-facets .pmk055-actions-buttons .btn,
                #pmk-search-quick-filters .pmk-search-quick-filter {
                    flex: 1 1 100%;
                    width: 100%;
                }

                #search-facets .pmk055-facet-toggle-main,
                #search-facets .pmk055-choice-label {
                    overflow-wrap: anywhere;
                }
            }

            @media (prefers-reduced-motion: reduce) {
                #search-facets .pmk055-facet-toggle-icon {
                    transition: none;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function effectiveLimitsFromUrl(input) {
        let url;
        try {
            url = input instanceof URL ? input : new URL(String(input || window.location.href), window.location.origin);
        } catch (_) {
            return [];
        }

        const limits = url.searchParams.getAll("limit");
        const noLimits = new Set(url.searchParams.getAll("nolimit"));
        return limits.filter(function (limit) {
            return !noLimits.has(limit);
        });
    }

    function currentEffectiveLimits() {
        return effectiveLimitsFromUrl(new URL(window.location.href));
    }

    function multisetDifference(left, right) {
        const counts = new Map();
        (right || []).forEach(function (value) {
            counts.set(value, (counts.get(value) || 0) + 1);
        });

        const diff = [];
        (left || []).forEach(function (value) {
            const count = counts.get(value) || 0;
            if (count > 0) counts.set(value, count - 1);
            else diff.push(value);
        });
        return diff;
    }

    function tokenToAddFromLink(link) {
        if (!link || !link.getAttribute) return "";
        try {
            const candidateUrl = new URL(link.getAttribute("href") || "", window.location.origin);
            const candidate = effectiveLimitsFromUrl(candidateUrl);
            const current = currentEffectiveLimits();
            const extras = multisetDifference(candidate, current);
            if (extras.length) return String(extras[extras.length - 1] || "");

            const rawLimits = candidateUrl.searchParams.getAll("limit");
            return rawLimits.length ? String(rawLimits[rawLimits.length - 1] || "") : "";
        } catch (_) {
            return "";
        }
    }

    function tokenToRemoveFromLink(link) {
        if (!link || !link.getAttribute) return "";
        try {
            const candidateUrl = new URL(link.getAttribute("href") || "", window.location.origin);
            const noLimits = candidateUrl.searchParams.getAll("nolimit");
            if (noLimits.length) return String(noLimits[noLimits.length - 1] || "");

            const current = currentEffectiveLimits();
            const candidate = effectiveLimitsFromUrl(candidateUrl);
            const removed = multisetDifference(current, candidate);
            return removed.length ? String(removed[removed.length - 1] || "") : "";
        } catch (_) {
            return "";
        }
    }

    function parseLimitToken(token) {
        const raw = String(token || "");
        const colon = raw.indexOf(":");
        if (colon <= 0) {
            return { raw: raw, valid: false, multi: false, index: "", qualifiers: [], operand: "" };
        }

        let head = raw.slice(0, colon);
        const operand = raw.slice(colon + 1);
        const multi = head.indexOf("mc-") === 0;
        if (multi) head = head.slice(3);

        const parts = head.split(",");
        const index = String(parts.shift() || "").trim();
        const qualifiers = parts
            .map(function (value) { return String(value || "").trim(); })
            .filter(Boolean);

        return {
            raw: raw,
            valid: Boolean(index && operand),
            multi: multi,
            index: index,
            qualifiers: qualifiers,
            operand: operand
        };
    }

    function facetGroupKey(token) {
        const parsed = parseLimitToken(token);
        return parsed.valid ? parsed.index : "";
    }

    function facetIdentity(token) {
        const parsed = parseLimitToken(token);
        if (!parsed.valid) return "";
        return parsed.index + ":" + parsed.operand;
    }

    function matchingCurrentLimit(token) {
        const identity = facetIdentity(token);
        if (!identity) return "";
        return currentEffectiveLimits().find(function (current) {
            return facetIdentity(current) === identity;
        }) || "";
    }

    function activeFacetGroupKeys() {
        const keys = new Set();
        currentEffectiveLimits().forEach(function (token) {
            const key = facetGroupKey(token);
            if (key) keys.add(key);
        });
        return Array.from(keys);
    }

    function toMultiChoiceLimit(token) {
        const parsed = parseLimitToken(token);
        if (!parsed.valid) return String(token || "");
        if (parsed.multi) return parsed.raw;

        const qualifiers = parsed.qualifiers.slice();

        // Les types de document sont historiquement transmis par Koha en
        // mc-itype,phr dans la recherche avancée. On conserve cette forme
        // lorsque le lien de facette natif ne porte pas déjà de qualificateur.
        if ((parsed.index === "itype" || parsed.index === "itemtype") && !qualifiers.length) {
            qualifiers.push("phr");
        }

        return "mc-" + parsed.index +
            (qualifiers.length ? "," + qualifiers.join(",") : "") +
            ":" + parsed.operand;
    }

    function normalizeMultiChoiceLimits(limits) {
        const unique = [];
        const seen = new Set();

        (limits || []).forEach(function (limit) {
            const token = String(limit || "");
            if (!token || seen.has(token)) return;
            seen.add(token);
            unique.push(token);
        });

        const groups = new Map();
        unique.forEach(function (token) {
            const key = facetGroupKey(token);
            if (!key) return;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(token);
        });

        const normalized = unique.map(function (token) {
            const key = facetGroupKey(token);
            const siblings = key ? (groups.get(key) || []) : [];
            return siblings.length > 1 ? toMultiChoiceLimit(token) : token;
        });

        const finalSeen = new Set();
        return normalized.filter(function (token) {
            if (finalSeen.has(token)) return false;
            finalSeen.add(token);
            return true;
        });
    }

    function buildResultUrl() {
        const url = new URL(window.location.href);
        let limits = effectiveLimitsFromUrl(url);

        limits = limits.filter(function (limit) {
            return !pendingRemoves.has(limit);
        });

        pendingAdds.forEach(function (limit) {
            if (!limits.includes(limit)) limits.push(limit);
        });

        // Dans une même facette, plusieurs valeurs élargissent le filtre (OU).
        // Des familles de facettes différentes restent combinées par Koha (ET).
        limits = normalizeMultiChoiceLimits(limits);

        url.searchParams.delete("limit");
        url.searchParams.delete("nolimit");

        limits.forEach(function (limit) {
            url.searchParams.append("limit", limit);
        });

        [
            "offset",
            "page",
            "searchid",
            "gotoPage",
            "gotoNumber"
        ].forEach(function (name) {
            url.searchParams.delete(name);
        });

        return url;
    }

    function buildClearFacetsUrl() {
        const url = new URL(window.location.href);

        // On retire uniquement les facettes. La requête catalogue, le tri et
        // les autres paramètres de recherche restent intacts.
        url.searchParams.delete("limit");
        url.searchParams.delete("nolimit");

        [
            "offset",
            "page",
            "searchid",
            "gotoPage",
            "gotoNumber"
        ].forEach(function (name) {
            url.searchParams.delete(name);
        });

        return url;
    }

    function loggedInBranchCode() {
        const element =
            document.querySelector(".logged-in-branch-code[data-logged-in-branch-code]") ||
            document.querySelector(".logged-in-branch-code");

        if (!element) return "";
        return String(
            element.getAttribute("data-logged-in-branch-code") ||
            element.dataset && element.dataset.loggedInBranchCode ||
            element.textContent ||
            ""
        ).trim();
    }

    function loggedInBranchName() {
        const element =
            document.querySelector(".logged-in-branch-name[data-logged-in-branch-name]") ||
            document.querySelector(".logged-in-branch-name");

        if (!element) return "";
        return String(
            element.getAttribute("data-logged-in-branch-name") ||
            element.dataset && element.dataset.loggedInBranchName ||
            element.textContent ||
            ""
        ).replace(/\s+/g, " ").trim();
    }

    function sameLimitIdentity(left, right) {
        const a = String(left || "");
        const b = String(right || "");
        if (!a || !b) return false;
        if (a === "available" || b === "available") return a === b;

        const aIdentity = facetIdentity(a);
        const bIdentity = facetIdentity(b);
        return Boolean(aIdentity && bIdentity && aIdentity === bIdentity);
    }

    function hasLimit(limits, token) {
        return (limits || []).some(function (current) {
            return sameLimitIdentity(current, token);
        });
    }

    function hydrateLocalAvailabilityState() {
        if (localAvailabilityHydrated) return;
        localAvailabilityHydrated = true;
        localAvailabilityActive = false;

        const localConfig = currentConfig.quickFilters && currentConfig.quickFilters.local
            ? currentConfig.quickFilters.local
            : DEFAULTS.quickFilters.local;

        if (!localConfig || localConfig.persistAcrossPages === false) {
            try { window.sessionStorage.removeItem(LOCAL_FILTER_STORAGE_KEY); } catch (_) {}
            return;
        }

        try {
            localAvailabilityActive = window.sessionStorage.getItem(LOCAL_FILTER_STORAGE_KEY) === "1";
        } catch (_) {
            localAvailabilityActive = false;
        }
    }

    function setLocalAvailabilityState(active) {
        localAvailabilityActive = Boolean(active);
        localAvailabilityHydrated = true;

        const localConfig = currentConfig.quickFilters && currentConfig.quickFilters.local
            ? currentConfig.quickFilters.local
            : DEFAULTS.quickFilters.local;

        try {
            if (localConfig && localConfig.persistAcrossPages !== false && localAvailabilityActive) {
                window.sessionStorage.setItem(LOCAL_FILTER_STORAGE_KEY, "1");
            } else {
                window.sessionStorage.removeItem(LOCAL_FILTER_STORAGE_KEY);
            }
        } catch (_) {}
    }

    function quickFilterState() {
        hydrateLocalAvailabilityState();
        const limits = currentEffectiveLimits();
        const hasAvailable = hasLimit(limits, "available");

        return {
            limits: limits,
            hasAvailable: hasAvailable,
            availabilityMode: hasAvailable,
            localAvailabilityMode: localAvailabilityActive
        };
    }

    function writeQuickFilterLimits(url, limits) {
        const normalized = normalizeMultiChoiceLimits(limits || []);

        url.searchParams.delete("limit");
        url.searchParams.delete("nolimit");
        normalized.forEach(function (limit) {
            url.searchParams.append("limit", limit);
        });

        ["offset", "page", "searchid", "gotoPage", "gotoNumber"].forEach(function (name) {
            url.searchParams.delete(name);
        });

        return url;
    }

    function withoutLimit(limits, token) {
        return (limits || []).filter(function (current) {
            return !sameLimitIdentity(current, token);
        });
    }

    function ensureLimit(limits, token) {
        const out = (limits || []).slice();
        if (token && !hasLimit(out, token)) out.push(token);
        return out;
    }

    function buildAvailabilityQuickFilterUrl(state) {
        const url = new URL(window.location.href);
        let limits = effectiveLimitsFromUrl(url);

        if (state.availabilityMode) {
            limits = withoutLimit(limits, "available");
        } else {
            limits = ensureLimit(limits, "available");
        }

        return writeQuickFilterLimits(url, limits);
    }

    function resultRows() {
        const form = document.getElementById("bookbag_form");
        if (!form) return [];
        return Array.from(form.querySelectorAll('tbody tr[id^="row"]'));
    }

    function normalizedText(value) {
        return String(value || "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function nativeAvailableItemMatchesLocal(item, branchCode, branchName) {
        if (!item) return false;

        if (branchCode) {
            try {
                if (item.classList && item.classList.contains(branchCode)) return true;
            } catch (_) {}

            const explicitCode = String(
                item.getAttribute("data-branchcode") ||
                item.getAttribute("data-branch-code") ||
                item.getAttribute("data-library-id") ||
                ""
            ).trim();
            if (explicitCode && explicitCode === branchCode) return true;
        }

        if (branchName) {
            const haystack = normalizedText(item.textContent);
            const needle = normalizedText(branchName);
            if (needle && haystack.includes(needle)) return true;
        }

        return false;
    }

    function rowHasLocalAvailableItem(row, branchCode, branchName) {
        if (!row) return false;

        // Fallback 129 : le moteur de présentation connaît déjà le statut et le site.
        if (row.querySelector(".kxri-item.is-local.is-available")) return true;

        // Source historique fiable : Koha place ici uniquement les exemplaires disponibles.
        // On vérifie ensuite que l'un de ces exemplaires appartient au site de connexion.
        const availableItems = Array.from(
            row.querySelectorAll("ul.available_items_loop_items li")
        );

        return availableItems.some(function (item) {
            return nativeAvailableItemMatchesLocal(item, branchCode, branchName);
        });
    }

    function ensureQuickFilterStatus(bar) {
        if (!bar) return null;
        let status = bar.querySelector(".pmk-search-quick-status");
        if (status) return status;

        status = document.createElement("span");
        status.className = "pmk-search-quick-status";
        status.setAttribute(GENERATED_ATTR, "1");
        status.setAttribute("aria-live", "polite");
        bar.appendChild(status);
        return status;
    }

    function updateLocalFilterStatus(bar, visible, total) {
        const status = ensureQuickFilterStatus(bar);
        if (!status) return;

        if (!localAvailabilityActive) {
            status.textContent = "";
            status.hidden = true;
            return;
        }

        status.hidden = false;
        status.textContent = language() === "en"
            ? visible + "/" + total + " record" + (total === 1 ? "" : "s") + " on this page · kept during pagination"
            : visible + "/" + total + " notice" + (total === 1 ? "" : "s") + " sur cette page · filtre conservé pendant la pagination";
    }

    function localResultDisplayMode() {
        const localConfig = currentConfig.quickFilters && currentConfig.quickFilters.local
            ? currentConfig.quickFilters.local
            : DEFAULTS.quickFilters.local;
        const mode = String((localConfig && localConfig.resultDisplay) || DEFAULTS.quickFilters.local.resultDisplay);
        return ["hidden", "dimmed", "collapsed", "dimmed-bottom"].includes(mode) ? mode : "dimmed";
    }

    function localCompactTitleLink(row) {
        if (!row) return null;
        return row.querySelector(
            'a.title[href], .title a[href], a[href*="/cgi-bin/koha/catalogue/detail.pl?biblionumber="], a[href*="catalogue/detail.pl?biblionumber="]'
        );
    }

    function localCompactAuthorText(row) {
        if (!row) return "";
        const selectors = [
            '.author',
            '.results_summary.author',
            '.results_summary .author',
            '[class*="author"]'
        ];
        for (const selector of selectors) {
            const node = row.querySelector(selector);
            if (!node) continue;
            const value = String(node.textContent || "")
                .replace(/^\s*(?:Auteur|Author)\s*:\s*/i, "")
                .replace(/\s+/g, " ")
                .trim();
            if (value) return value;
        }
        return "";
    }

    function ensureLocalCompactRow(row) {
        if (!row) return;
        let compactCell = directChild(row, "." + LOCAL_COMPACT_CELL_CLASS);
        if (compactCell) return;

        const originalCells = directChildren(row, "td");
        if (!originalCells.length) return;
        originalCells.forEach(function (cell) {
            cell.classList.add(LOCAL_ORIGINAL_CELL_CLASS);
        });

        compactCell = document.createElement("td");
        compactCell.className = LOCAL_COMPACT_CELL_CLASS;
        compactCell.setAttribute(GENERATED_ATTR, "1");
        compactCell.colSpan = Math.max(1, originalCells.reduce(function (sum, cell) {
            return sum + Math.max(1, Number(cell.colSpan) || 1);
        }, 0));

        const wrap = document.createElement("div");
        wrap.className = "pmk055-local-compact-wrap";

        const main = document.createElement("div");
        main.className = "pmk055-local-compact-main";

        const title = document.createElement("span");
        title.className = "pmk055-local-compact-title";
        const sourceLink = localCompactTitleLink(row);
        if (sourceLink) {
            const link = document.createElement("a");
            link.href = sourceLink.href;
            link.textContent = String(sourceLink.textContent || "").replace(/\s+/g, " ").trim() || t("Notice", "Record");
            title.appendChild(link);
        } else {
            const fallback = String(row.textContent || "").replace(/\s+/g, " ").trim();
            title.textContent = fallback.slice(0, 180) || t("Notice", "Record");
        }
        main.appendChild(title);

        const authorText = localCompactAuthorText(row);
        if (authorText) {
            const author = document.createElement("span");
            author.className = "pmk055-local-compact-author";
            author.textContent = authorText;
            main.appendChild(author);
        }

        const state = document.createElement("span");
        state.className = "pmk055-local-compact-state";
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-location-dot";
        icon.setAttribute("aria-hidden", "true");
        state.appendChild(icon);
        state.appendChild(document.createTextNode(t("Non disponible ici", "Not available here")));

        wrap.appendChild(main);
        wrap.appendChild(state);
        compactCell.appendChild(wrap);
        row.appendChild(compactCell);
    }

    function removeLocalCompactRow(row) {
        if (!row) return;
        directChildren(row, "." + LOCAL_COMPACT_CELL_CLASS).forEach(function (cell) { cell.remove(); });
        directChildren(row, "td." + LOCAL_ORIGINAL_CELL_CLASS).forEach(function (cell) {
            cell.classList.remove(LOCAL_ORIGINAL_CELL_CLASS);
        });
        const itemCell = row.querySelector(".kxri-cell") || directChildren(row, "td").slice(-1)[0];
        if (itemCell) itemCell.removeAttribute("data-pmk055-local-status-label");
    }

    function prepareLocalCollapsedRow(row) {
        if (!row) return;
        const itemCell = row.querySelector(".kxri-cell") || directChildren(row, "td").slice(-1)[0];
        if (itemCell) {
            itemCell.setAttribute(
                "data-pmk055-local-status-label",
                t("Non disponible ici", "Not available here")
            );
        }
    }

    function clearLocalRowPresentation(rows, restoreOrder) {
        (rows || []).forEach(function (row) {
            row.classList.remove(LOCAL_HIDDEN_CLASS, LOCAL_DIMMED_CLASS, LOCAL_COLLAPSED_CLASS, LOCAL_EXCLUDED_CLASS);
            removeLocalCompactRow(row);
        });

        if (restoreOrder) {
            const grouped = new Map();
            (rows || []).forEach(function (row) {
                const parent = row.parentNode;
                if (!parent) return;
                if (!grouped.has(parent)) grouped.set(parent, []);
                grouped.get(parent).push(row);
            });
            grouped.forEach(function (groupRows, parent) {
                groupRows
                    .slice()
                    .sort(function (a, b) {
                        return Number(a.getAttribute(LOCAL_ORIGINAL_INDEX_ATTR) || 0) - Number(b.getAttribute(LOCAL_ORIGINAL_INDEX_ATTR) || 0);
                    })
                    .forEach(function (row) { parent.appendChild(row); });
            });
        }
    }

    function applyLocalRowPresentation(row, keep, mode) {
        row.classList.remove(LOCAL_HIDDEN_CLASS, LOCAL_DIMMED_CLASS, LOCAL_COLLAPSED_CLASS, LOCAL_EXCLUDED_CLASS);
        removeLocalCompactRow(row);
        if (keep) return;
        row.classList.add(LOCAL_EXCLUDED_CLASS);
        if (mode === "hidden") {
            row.classList.add(LOCAL_HIDDEN_CLASS);
        } else if (mode === "collapsed") {
            prepareLocalCollapsedRow(row);
            row.classList.add(LOCAL_COLLAPSED_CLASS);
        } else {
            row.classList.add(LOCAL_DIMMED_CLASS);
        }
    }

    function applyLocalAvailabilityFilter() {
        const rows = resultRows();
        const bar = document.getElementById("pmk-search-quick-filters");

        if (!rows.length) {
            updateLocalFilterStatus(bar, 0, 0);
            return { visible: 0, total: 0 };
        }

        rows.forEach(function (row, index) {
            if (!row.hasAttribute(LOCAL_ORIGINAL_INDEX_ATTR)) {
                row.setAttribute(LOCAL_ORIGINAL_INDEX_ATTR, String(index));
            }
        });

        if (!localAvailabilityActive) {
            clearLocalRowPresentation(rows, true);
            updateLocalFilterStatus(bar, rows.length, rows.length);
            return { visible: rows.length, total: rows.length };
        }

        const branchCode = loggedInBranchCode();
        const branchName = loggedInBranchName();

        if (!branchCode && !branchName) {
            clearLocalRowPresentation(rows, true);
            setLocalAvailabilityState(false);
            updateLocalFilterStatus(bar, rows.length, rows.length);
            return { visible: rows.length, total: rows.length };
        }

        let visible = 0;
        const mode = localResultDisplayMode();
        const keptRows = [];
        const excludedRows = [];

        rows.forEach(function (row) {
            const keep = rowHasLocalAvailableItem(row, branchCode, branchName);
            applyLocalRowPresentation(row, keep, mode);
            if (keep) {
                visible += 1;
                keptRows.push(row);
            } else {
                excludedRows.push(row);
            }
        });

        if (mode === "dimmed-bottom" && rows.length) {
            const parent = rows[0].parentNode;
            if (parent) keptRows.concat(excludedRows).forEach(function (row) { parent.appendChild(row); });
        } else {
            clearLocalRowPresentation([], false);
        }

        updateLocalFilterStatus(bar, visible, rows.length);
        return { visible: visible, total: rows.length };
    }

    function scheduleLocalAvailabilityFilter() {
        if (localFilterScheduled) return;
        localFilterScheduled = true;
        window.requestAnimationFrame(function () {
            localFilterScheduled = false;
            applyLocalAvailabilityFilter();
        });
    }

    function installLocalResultsObserver() {
        if (localResultsObserver) return;
        const form = document.getElementById("bookbag_form");
        if (!form) return;

        localResultsObserver = new MutationObserver(function () {
            if (!localAvailabilityActive) return;
            scheduleLocalAvailabilityFilter();
        });

        localResultsObserver.observe(form, {
            childList: true,
            subtree: true
        });
    }

    function stopLocalResultsObserver() {
        if (localResultsObserver) {
            try { localResultsObserver.disconnect(); } catch (_) {}
            localResultsObserver = null;
        }
        localFilterScheduled = false;
    }

    function ensureQuickFiltersBar(root) {
        let bar = document.getElementById("pmk-search-quick-filters");
        if (bar) return bar;

        bar = document.createElement("div");
        bar.id = "pmk-search-quick-filters";
        bar.className = "pmk-search-quick-filters";
        bar.setAttribute("role", "group");
        bar.setAttribute("aria-label", t("Filtres rapides", "Quick filters"));

        if (root && root.parentNode) root.parentNode.insertBefore(bar, root);
        return bar;
    }

    function quickFilterLabel(kind, active, available) {
        const config = currentConfig.quickFilters && currentConfig.quickFilters[kind]
            ? currentConfig.quickFilters[kind]
            : DEFAULTS.quickFilters[kind];

        if (available === false) {
            return language() === "en" ? config.unavailableLabelEn : config.unavailableLabelFr;
        }
        if (language() === "en") {
            return active ? config.activeLabelEn : config.labelEn;
        }
        return active ? config.activeLabelFr : config.labelFr;
    }

    function createQuickFilterButton(bar, kind, active, options) {
        const config = currentConfig.quickFilters && currentConfig.quickFilters[kind]
            ? currentConfig.quickFilters[kind]
            : DEFAULTS.quickFilters[kind];
        if (!config || config.enabled === false) return null;

        const available = options.available !== false;
        const button = document.createElement("button");
        button.type = "button";
        button.className = "filter-button pmk-search-quick-filter btn btn-sm " +
            (active ? "btn-primary" : "btn-outline-secondary");
        button.setAttribute(GENERATED_ATTR, "1");
        button.setAttribute("data-pmk-quick-filter", kind);
        button.setAttribute("aria-pressed", active ? "true" : "false");

        const icon = document.createElement("i");
        icon.className = options.icon;
        icon.setAttribute("aria-hidden", "true");

        const text = document.createElement("span");
        text.textContent = quickFilterLabel(kind, active, available);

        button.appendChild(icon);
        button.appendChild(text);

        if (!available) {
            button.disabled = true;
            button.title = options.unavailableTitle || t(
                "Ce filtre n’est pas disponible sur cette page.",
                "This filter is not available on this page."
            );
        } else {
            button.title = active ? options.activeTitle : options.inactiveTitle;
            button.addEventListener("click", function () {
                if (button.disabled) return;

                if (typeof options.onClick === "function") {
                    options.onClick(button);
                    return;
                }

                button.disabled = true;
                const target = options.buildUrl();
                window.location.assign(target.toString());
            });
        }

        if (options.prepend && bar.firstChild) bar.insertBefore(button, bar.firstChild);
        else bar.appendChild(button);
        return button;
    }

    function mountQuickFilters(root) {
        const quick = currentConfig.quickFilters || DEFAULTS.quickFilters;
        if (
            (!quick.availability || quick.availability.enabled === false) &&
            (!quick.local || quick.local.enabled === false)
        ) return;

        const bar = ensureQuickFiltersBar(root);
        if (!bar) return;

        // La barre appartient entièrement au 055 : la reconstruire évite tout doublon.
        bar.replaceChildren();

        const branchCode = loggedInBranchCode();
        const branchName = loggedInBranchName();
        const localDetectionAvailable = Boolean(branchCode || branchName);
        let state = quickFilterState();

        if (!localDetectionAvailable && state.localAvailabilityMode) {
            setLocalAvailabilityState(false);
            state = quickFilterState();
        }

        const activeQuickFilterCount =
            (state.availabilityMode ? 1 : 0) +
            (state.localAvailabilityMode ? 1 : 0);
        bar.classList.toggle("pmk055-has-active-quick-filter", activeQuickFilterCount > 0);

        if (activeQuickFilterCount > 0) {
            const badge = document.createElement("span");
            badge.className = "pmk055-quick-active-count";
            badge.setAttribute(GENERATED_ATTR, "1");
            badge.textContent = language() === "en"
                ? activeQuickFilterCount + " quick filter" + (activeQuickFilterCount > 1 ? "s" : "") + " active"
                : activeQuickFilterCount + " filtre" + (activeQuickFilterCount > 1 ? "s" : "") + " rapide" + (activeQuickFilterCount > 1 ? "s" : "") + " actif" + (activeQuickFilterCount > 1 ? "s" : "");
            bar.appendChild(badge);
        }

        if (quick.availability && quick.availability.enabled !== false) {
            createQuickFilterButton(bar, "availability", state.availabilityMode, {
                prepend: true,
                icon: "fa-solid fa-circle-check",
                buildUrl: function () { return buildAvailabilityQuickFilterUrl(state); },
                inactiveTitle: t(
                    "Limiter la recherche complète aux notices ayant au moins un exemplaire disponible dans le réseau.",
                    "Limit the full search to records with at least one available item anywhere in the network."
                ),
                activeTitle: t(
                    "Retirer uniquement le filtre « Disponibles uniquement ».",
                    "Remove only the “Available only” filter."
                )
            });
        }

        if (quick.local && quick.local.enabled !== false) {
            createQuickFilterButton(bar, "local", state.localAvailabilityMode, {
                icon: "fa-solid fa-location-dot",
                available: localDetectionAvailable,
                onClick: function () {
                    setLocalAvailabilityState(!localAvailabilityActive);
                    applyLocalAvailabilityFilter();
                    mountQuickFilters(root);
                    applyLocalAvailabilityFilter();
                },
                inactiveTitle: branchName
                    ? t(
                        "Conserver uniquement les notices ayant un exemplaire réellement disponible à " + branchName + ". Le mode reste actif en changeant de page de résultats.",
                        "Keep only records with an actually available item at " + branchName + ". The mode stays active when moving through result pages."
                    )
                    : t(
                        "Conserver uniquement les notices ayant un exemplaire réellement disponible dans le site connecté. Le mode reste actif pendant la pagination.",
                        "Keep only records with an actually available item at the logged-in library. The mode stays active during pagination."
                    ),
                activeTitle: t(
                    "Retirer uniquement le filtre local « Disponibles ici uniquement ».",
                    "Remove only the local “Available here only” filter."
                ),
                unavailableTitle: t(
                    "Le site connecté n’a pas pu être détecté dans l’en-tête Koha.",
                    "The logged-in library could not be detected in the Koha header."
                )
            });
        }

        updateLocalFilterStatus(bar, 0, resultRows().length);
    }

    function cleanupQuickFiltersBar() {
        const bar = document.getElementById("pmk-search-quick-filters");
        if (bar && !bar.children.length) bar.remove();
    }

    function appliedFacetCount() {
        return currentEffectiveLimits().length;
    }

    function nativeLabelText(container) {
        if (!container) return "";
        const cloneNode = container.cloneNode(true);
        cloneNode.querySelectorAll("a").forEach(function (a) { a.remove(); });
        return String(cloneNode.textContent || "").replace(/\s+/g, " ").trim();
    }

    function analyzeChoiceLi(li) {
        if (!li || li.classList.contains("moretoggle")) return null;

        const anchors = Array.from(li.querySelectorAll("a[href]"));
        const removeLink = anchors.find(function (link) {
            try {
                const url = new URL(link.getAttribute("href") || "", window.location.origin);
                return url.searchParams.getAll("nolimit").length > 0;
            } catch (_) {
                return false;
            }
        });

        if (removeLink) {
            const token = tokenToRemoveFromLink(removeLink);
            if (!token) return null;

            const labelNode =
                li.querySelector(".facet-label") ||
                li.querySelector(".filter_label") ||
                li.querySelector("span");

            const label = nativeLabelText(labelNode) ||
                String((labelNode && labelNode.textContent) || "").replace(/\s+/g, " ").trim() ||
                token;

            const count = String((li.querySelector(".facet-count") || {}).textContent || "").trim();

            return {
                active: true,
                token: token,
                label: label.replace(/\[\s*x\s*\]\s*$/i, "").trim(),
                count: count
            };
        }

        const addLink =
            li.querySelector(".facet-label a[href]") ||
            li.querySelector(".filter_label a[href]") ||
            anchors.find(function (link) {
                return Boolean(tokenToAddFromLink(link));
            });

        if (!addLink) return null;

        const token = tokenToAddFromLink(addLink);
        if (!token) return null;

        const currentToken = matchingCurrentLimit(token);

        const labelNode =
            li.querySelector(".facet-label") ||
            li.querySelector(".filter_label");

        const label =
            String((labelNode && labelNode.textContent) || addLink.textContent || "")
                .replace(/\s+/g, " ")
                .trim();

        const count = String((li.querySelector(".facet-count") || {}).textContent || "").trim();

        return {
            active: Boolean(currentToken),
            token: currentToken || token,
            label: label || token,
            count: count
        };
    }

    function wrapDirectTextNodes(element, className) {
        Array.from(element.childNodes || []).forEach(function (node) {
            if (node.nodeType !== Node.TEXT_NODE) return;
            if (!String(node.nodeValue || "").trim()) return;

            const span = document.createElement("span");
            span.setAttribute(NATIVE_TEXT_ATTR, "1");
            span.className = className || "";
            span.textContent = node.nodeValue;
            node.replaceWith(span);
        });
    }

    function ensureListId(list) {
        if (list.id) return list.id;
        tempIdCounter += 1;
        list.id = "pmk055-facet-list-" + tempIdCounter;
        list.setAttribute(TEMP_ID_ATTR, "1");
        return list.id;
    }

    function groupLabel(group) {
        const nativeHeading = directChildren(group, "span,h5,h6,strong").find(function (node) {
            return !node.classList.contains("pmk055-choice-ui");
        });

        if (nativeHeading) {
            const label = String(nativeHeading.textContent || "").replace(/\s+/g, " ").trim();
            if (label) return label;
        }

        const textNode = Array.from(group.childNodes || []).find(function (node) {
            return node.nodeType === Node.TEXT_NODE && String(node.nodeValue || "").trim();
        });

        return textNode ? String(textNode.nodeValue || "").replace(/\s+/g, " ").trim() : "";
    }

    function normalizeComparableLabel(value) {
        return String(value || "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function groupTechnicalKey(group) {
        const identity = facetGroupIdentity(group);
        return identity.indexOf("facet:") === 0 ? identity.slice(6) : "";
    }

    function matchingRenameRule(group, nativeLabel) {
        const rules = Array.isArray(currentConfig.groupRenames) ? currentConfig.groupRenames : [];
        const labelKey = normalizeComparableLabel(nativeLabel);
        const technicalKey = groupTechnicalKey(group);

        return rules.find(function (rule) {
            if (!rule || rule.enabled === false) return false;

            const configuredKey = String(rule.groupKey || "").trim();
            const configuredLabel = normalizeComparableLabel(rule.sourceLabel);

            if (configuredKey && technicalKey && configuredKey === technicalKey) return true;
            return Boolean(configuredLabel && labelKey && configuredLabel === labelKey);
        }) || null;
    }

    function displayGroupLabel(group) {
        const nativeLabel = groupLabel(group);
        const rule = matchingRenameRule(group, nativeLabel);
        if (!rule) return { text: nativeLabel, renamed: false };

        const wanted = language() === "en"
            ? String(rule.en || rule.fr || "").trim()
            : String(rule.fr || rule.en || "").trim();

        return {
            text: wanted || nativeLabel,
            renamed: Boolean(wanted && wanted !== nativeLabel)
        };
    }

    function applyStandaloneRenamedHeading(group, label) {
        if (!group || !label) return;

        markNativeGroupHeading(group);

        const heading = document.createElement("span");
        heading.className = "pmk055-renamed-heading";
        heading.setAttribute(GENERATED_ATTR, "1");
        heading.textContent = label;

        const list = directChild(group, "ul");
        if (list) group.insertBefore(heading, list);
        else group.insertBefore(heading, group.firstChild);
    }

    function markNativeGroupHeading(group) {
        directChildren(group, "span,h5,h6,strong").forEach(function (node) {
            node.classList.add("pmk055-native-heading");
        });

        wrapDirectTextNodes(group, "pmk055-native-heading");
    }

    function groupHasActiveFacet(group) {
        if (!group) return false;
        if (group.id === "availability_facet") return currentEffectiveLimits().includes("available");
        const list = directChild(group, "ul");
        return list && directChildren(list, "li").some(function (li) {
            const choice = analyzeChoiceLi(li);
            return Boolean(choice && choice.active);
        });
    }

    function makeToggleButton(group, list, label, open) {
        const stateKey = facetGroupIdentity(group);
        const button = document.createElement("button");
        button.type = "button";
        button.className = "pmk055-facet-toggle";
        button.setAttribute(GENERATED_ATTR, "1");
        button.setAttribute("aria-expanded", open ? "true" : "false");
        button.setAttribute("aria-controls", ensureListId(list));

        const main = document.createElement("span");
        main.className = "pmk055-facet-toggle-main";

        const text = document.createElement("span");
        text.textContent = label || t("Filtre", "Filter");
        main.appendChild(text);
        button.appendChild(main);

        const icon = document.createElement("i");
        icon.className = "fa-solid fa-chevron-right pmk055-facet-toggle-icon";
        icon.setAttribute("aria-hidden", "true");
        button.appendChild(icon);

        button.addEventListener("click", function () {
            const nextOpen = !group.classList.contains("pmk055-open");
            group.classList.toggle("pmk055-open", nextOpen);
            button.setAttribute("aria-expanded", nextOpen ? "true" : "false");

            // Le choix explicite de l'agent prime sur l'état initial et sur
            // l'ouverture automatique des groupes actifs tant que la page
            // courante n'est pas réellement rechargée.
            if (stateKey) drawerStateOverrides.set(stateKey, nextOpen);
        });

        group.insertBefore(button, group.firstChild);
    }

    function markNativeChoice(li, generatedUi) {
        Array.from(li.childNodes || []).forEach(function (node) {
            if (node === generatedUi) return;

            if (node.nodeType === Node.TEXT_NODE) {
                if (!String(node.nodeValue || "").trim()) return;
                const span = document.createElement("span");
                span.setAttribute(NATIVE_TEXT_ATTR, "1");
                span.className = "pmk055-native-choice";
                span.textContent = node.nodeValue;
                node.replaceWith(span);
                return;
            }

            if (node.nodeType === Node.ELEMENT_NODE) {
                node.classList.add("pmk055-native-choice");
            }
        });
    }

    function setPendingState(ui, input, active, token) {
        const checked = input.checked;

        if (active) {
            if (checked) pendingRemoves.delete(token);
            else pendingRemoves.add(token);
            pendingAdds.delete(token);
        } else {
            if (checked) pendingAdds.add(token);
            else pendingAdds.delete(token);
            pendingRemoves.delete(token);
        }

        const changed = (active && !checked) || (!active && checked);
        ui.classList.toggle("pmk055-pending", changed);
        ui.classList.toggle("pmk055-selected", checked);

        if (currentConfig.multiSelect) {
            refreshPendingUi();
        } else if (changed) {
            window.location.assign(buildResultUrl().toString());
        }
    }

    function createChoiceUi(li, choice) {
        const ui = document.createElement("label");
        ui.className = "pmk055-choice-ui";
        ui.setAttribute(GENERATED_ATTR, "1");

        const input = document.createElement("input");
        input.type = "checkbox";
        input.className = "form-check-input";
        input.checked = choice.active === true;
        input.setAttribute("aria-label", choice.label || choice.token);
        ui.classList.toggle("pmk055-selected", input.checked);
        if (currentConfig.highlightActiveFacets) {
            ui.classList.toggle("pmk055-active", choice.active === true);
        }

        const text = document.createElement("span");
        text.className = "pmk055-choice-label";
        text.textContent = choice.label || choice.token;

        ui.appendChild(input);
        ui.appendChild(text);

        if (choice.count) {
            const count = document.createElement("span");
            count.className = "pmk055-choice-count";
            count.textContent = choice.count;
            ui.appendChild(count);
        }

        if (currentConfig.highlightActiveFacets && choice.active === true) {
            const badge = document.createElement("span");
            badge.className = "pmk055-active-badge";
            badge.textContent = t("Actif", "Active");
            ui.appendChild(badge);
        }

        input.addEventListener("change", function () {
            setPendingState(ui, input, choice.active === true, choice.token);
        });

        li.insertBefore(ui, li.firstChild);
        markNativeChoice(li, ui);
    }

    function updateGroupActiveIndicator(group) {
        if (!currentConfig.highlightActiveFacets || !group) return;
        const button = directChild(group, ".pmk055-facet-toggle");
        if (!button) return;

        const main = button.querySelector(".pmk055-facet-toggle-main");
        if (!main) return;

        const old = main.querySelector(".pmk055-group-active-count");
        if (old) old.remove();

        const count = group.querySelectorAll(".pmk055-choice-ui.pmk055-active").length;
        if (!count) return;

        const badge = document.createElement("span");
        badge.className = "pmk055-group-active-count";
        badge.textContent = language() === "en"
            ? count + " active"
            : count + " actif" + (count > 1 ? "s" : "");
        main.appendChild(badge);
    }

    function groupContainsFacetKey(group, key) {
        if (!group || !key) return false;
        return Array.from(group.querySelectorAll("a[href]")).some(function (link) {
            try {
                const url = new URL(link.getAttribute("href") || "", window.location.origin);
                const tokens = url.searchParams.getAll("limit").concat(url.searchParams.getAll("nolimit"));
                return tokens.some(function (token) {
                    return facetGroupKey(token) === key;
                });
            } catch (_) {
                return false;
            }
        });
    }

    function findFacetGroupByKey(root, key) {
        if (!root || !key) return null;
        const mainList = directChild(root, "ul");
        if (!mainList) return null;
        return directChildren(mainList, "li").find(function (group) {
            return groupContainsFacetKey(group, key);
        }) || null;
    }

    function normalizedGroupLabel(group) {
        return String(groupLabel(group) || "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function facetGroupIdentity(group) {
        if (!group) return "";

        if (group.id === "availability_facet") {
            return "id:availability_facet";
        }

        const keys = new Set();
        Array.from(group.querySelectorAll("a[href]")).forEach(function (link) {
            try {
                const url = new URL(link.getAttribute("href") || "", window.location.origin);
                url.searchParams.getAll("limit")
                    .concat(url.searchParams.getAll("nolimit"))
                    .forEach(function (token) {
                        const key = facetGroupKey(token);
                        if (key) keys.add(key);
                    });
            } catch (_) {}
        });

        if (keys.size === 1) {
            return "facet:" + Array.from(keys)[0];
        }

        const label = normalizedGroupLabel(group);
        return label ? "label:" + label : "";
    }

    function nativeChoiceIdentity(li) {
        if (!li || li.classList.contains("moretoggle")) return "";

        const choice = analyzeChoiceLi(li);
        if (choice && choice.token) {
            const identity = facetIdentity(choice.token);
            if (identity) return "facet:" + identity;
            return "token:" + String(choice.token);
        }

        return "text:" + String(li.textContent || "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function mergeDuplicateGroupInto(primary, duplicate) {
        if (!primary || !duplicate || primary === duplicate) return;

        const primaryList = directChild(primary, "ul");
        const duplicateList = directChild(duplicate, "ul");

        if (primaryList && duplicateList) {
            const known = new Set(
                directChildren(primaryList, "li")
                    .map(nativeChoiceIdentity)
                    .filter(Boolean)
            );

            directChildren(duplicateList, "li").forEach(function (li) {
                if (li.classList.contains("moretoggle")) return;
                const identity = nativeChoiceIdentity(li);
                if (identity && known.has(identity)) return;
                if (identity) known.add(identity);
                primaryList.appendChild(li.cloneNode(true));
            });
        }

        duplicate.remove();
    }

    function deduplicateFacetGroups(root) {
        if (!root) return 0;
        const mainList = directChild(root, "ul");
        if (!mainList) return 0;

        const seen = new Map();
        let removed = 0;

        directChildren(mainList, "li").forEach(function (group) {
            const identity = facetGroupIdentity(group);
            if (!identity) return;

            if (!seen.has(identity)) {
                seen.set(identity, group);
                return;
            }

            mergeDuplicateGroupInto(seen.get(identity), group);
            removed += 1;
        });

        return removed;
    }

    function buildFacetRefreshUrl(excludedKey) {
        const url = new URL(window.location.href);
        const limits = effectiveLimitsFromUrl(url).filter(function (token) {
            return facetGroupKey(token) !== excludedKey;
        });

        url.searchParams.delete("limit");
        url.searchParams.delete("nolimit");
        limits.forEach(function (token) {
            url.searchParams.append("limit", token);
        });

        ["offset", "page", "searchid", "gotoPage", "gotoNumber"].forEach(function (name) {
            url.searchParams.delete(name);
        });

        return url;
    }

    function setRefreshStatus(refreshing) {
        const root = document.getElementById("search-facets");
        if (!root) return;
        const bar = root.querySelector(".pmk055-actions");
        if (!bar) return;
        bar.classList.toggle("is-refreshing", Boolean(refreshing));
        const status = bar.querySelector(".pmk055-actions-status");
        if (refreshing && status) {
            status.textContent = t(
                "Recalcul des choix disponibles dans les facettes actives…",
                "Refreshing available choices in active facets…"
            );
        } else if (!refreshing) {
            refreshPendingUi();
        }
    }

    async function recalculateActiveFacetFamilies(root) {
        if (!currentConfig.multiSelect || !currentConfig.recalculateActiveFacets) return;
        if (!root || facetRefreshInProgress) return;

        const keys = activeFacetGroupKeys();
        if (!keys.length) return;

        const signature = window.location.href + "|" + keys.join(",");
        if (lastFacetRefreshSignature === signature) return;
        lastFacetRefreshSignature = signature;
        facetRefreshInProgress = true;
        setRefreshStatus(true);

        let changed = false;

        try {
            for (const key of keys) {
                const currentGroup = findFacetGroupByKey(root, key);
                if (!currentGroup) continue;

                try {
                    const response = await fetch(buildFacetRefreshUrl(key).toString(), {
                        credentials: "same-origin",
                        headers: { "X-Requested-With": "XMLHttpRequest" }
                    });
                    if (!response.ok) continue;

                    const html = await response.text();
                    const parsed = new DOMParser().parseFromString(html, "text/html");
                    const freshRoot = parsed.getElementById("search-facets");
                    if (!freshRoot) continue;

                    const freshGroup = findFacetGroupByKey(freshRoot, key);
                    if (!freshGroup) continue;

                    const currentList = directChild(currentGroup, "ul");
                    const freshList = directChild(freshGroup, "ul");
                    if (!currentList || !freshList) continue;

                    // On rafraîchit uniquement le contenu du groupe. Remplacer
                    // l'enveloppe <li> complète peut provoquer des groupes
                    // dupliqués lors d'un second passage du module.
                    const fragment = document.createDocumentFragment();
                    Array.from(freshList.childNodes || []).forEach(function (node) {
                        fragment.appendChild(document.importNode(node, true));
                    });
                    currentList.replaceChildren(fragment);
                    changed = true;
                } catch (_) {
                    // Une facette qui ne peut pas être recalculée conserve le rendu Koha courant.
                }
            }
        } finally {
            facetRefreshInProgress = false;
        }

        if (changed) {
            // On repart du DOM natif avant de reconstruire l'UI PMK, puis on
            // élimine toute éventuelle duplication de groupes.
            restore();
            const refreshedRoot = document.getElementById("search-facets");
            if (refreshedRoot) {
                deduplicateFacetGroups(refreshedRoot);
                enhanceRoot(refreshedRoot);
            }
        } else {
            setRefreshStatus(false);
        }
    }

    function enhanceAvailability(group, list) {
        const current = currentEffectiveLimits();
        const active = current.includes("available");

        const nativeLis = directChildren(list, "li");
        nativeLis.forEach(function (li) {
            li.classList.add("pmk055-native-choice");
        });

        const generatedLi = document.createElement("li");
        generatedLi.setAttribute(GENERATED_ATTR, "1");

        const choice = {
            active: active,
            token: "available",
            label: t("Disponibles uniquement", "Available items only"),
            count: ""
        };

        createChoiceUi(generatedLi, choice);
        list.insertBefore(generatedLi, list.firstChild);
    }

    function enhanceChoices(group, list) {
        if (!currentConfig.multiSelect) return;

        if (group.id === "availability_facet") {
            enhanceAvailability(group, list);
            return;
        }

        directChildren(list, "li").forEach(function (li) {
            if (li.classList.contains("moretoggle")) return;
            const choice = analyzeChoiceLi(li);
            if (!choice) return;
            createChoiceUi(li, choice);
        });
    }

    function restorePendingChoices(root) {
        pendingAdds.clear();
        pendingRemoves.clear();

        root.querySelectorAll(".pmk055-choice-ui").forEach(function (ui) {
            const input = ui.querySelector('input[type="checkbox"]');
            if (!input) return;

            const li = ui.closest("li");
            if (!li) return;

            if (li.parentElement && li.parentElement.parentElement &&
                li.parentElement.parentElement.id === "availability_facet") {
                input.checked = currentEffectiveLimits().includes("available");
            } else {
                const original = Array.from(li.querySelectorAll("a[href]"));
                const isActive = original.some(function (link) {
                    return Boolean(tokenToRemoveFromLink(link));
                });
                input.checked = isActive;
            }

            ui.classList.remove("pmk055-pending");
            ui.classList.toggle("pmk055-selected", input.checked);
        });

        refreshPendingUi();
    }

    function makeActionBar(root) {
        if (!currentConfig.multiSelect) return;

        const bar = document.createElement("div");
        bar.className = "pmk055-actions";
        bar.setAttribute(GENERATED_ATTR, "1");

        const status = document.createElement("span");
        status.className = "pmk055-actions-status";
        status.setAttribute("aria-live", "polite");

        const buttons = document.createElement("div");
        buttons.className = "pmk055-actions-buttons";

        const apply = document.createElement("button");
        apply.type = "button";
        apply.className = "btn btn-sm btn-primary pmk055-apply";
        apply.innerHTML = '<i class="fa-solid fa-filter" aria-hidden="true"></i> <span></span>';
        apply.querySelector("span").textContent = t("Appliquer", "Apply");
        apply.addEventListener("click", function () {
            if (!pendingAdds.size && !pendingRemoves.size) return;
            apply.disabled = true;
            apply.querySelector("span").textContent = t("Application…", "Applying…");
            window.location.assign(buildResultUrl().toString());
        });

        const cancelPending = document.createElement("button");
        cancelPending.type = "button";
        cancelPending.className = "btn btn-sm btn-default pmk055-cancel-pending";
        cancelPending.innerHTML = '<i class="fa-solid fa-rotate-left" aria-hidden="true"></i> <span></span>';
        cancelPending.querySelector("span").textContent = t(
            "Annuler les modifications",
            "Cancel changes"
        );
        cancelPending.title = t(
            "Rétablit les cases telles qu’elles sont réellement appliquées à la recherche.",
            "Restores the checkboxes to the filters actually applied to the search."
        );
        cancelPending.addEventListener("click", function () {
            restorePendingChoices(root);
        });

        const clearAll = document.createElement("button");
        clearAll.type = "button";
        clearAll.className = "btn btn-sm btn-default pmk055-clear-all";
        clearAll.innerHTML = '<i class="fa-solid fa-xmark" aria-hidden="true"></i> <span></span>';
        clearAll.querySelector("span").textContent = t(
            "Effacer les filtres",
            "Clear filters"
        );
        clearAll.title = t(
            "Retire toutes les facettes appliquées à cette recherche, y compris après rechargement.",
            "Removes all facets applied to this search, including after a page reload."
        );
        clearAll.addEventListener("click", function () {
            const hasApplied = appliedFacetCount() > 0;

            pendingAdds.clear();
            pendingRemoves.clear();

            if (!hasApplied) {
                restorePendingChoices(root);
                return;
            }

            clearAll.disabled = true;
            clearAll.querySelector("span").textContent = t("Effacement…", "Clearing…");
            window.location.assign(buildClearFacetsUrl().toString());
        });

        buttons.appendChild(apply);
        buttons.appendChild(cancelPending);
        buttons.appendChild(clearAll);
        bar.appendChild(status);
        bar.appendChild(buttons);

        const title = directChild(root, "h4,h3,h2");
        if (title) title.insertAdjacentElement("afterend", bar);
        else root.insertBefore(bar, root.firstChild);

        refreshPendingUi();
    }

    function refreshPendingUi() {
        const root = document.getElementById("search-facets");
        if (!root) return;

        const bar = root.querySelector(".pmk055-actions");
        if (!bar) return;

        const count = pendingAdds.size + pendingRemoves.size;
        const applied = appliedFacetCount();
        const status = bar.querySelector(".pmk055-actions-status");
        const apply = bar.querySelector(".pmk055-apply");
        const cancelPending = bar.querySelector(".pmk055-cancel-pending");
        const clearAll = bar.querySelector(".pmk055-clear-all");

        if (status) {
            if (!count) {
                if (applied) {
                    status.textContent = language() === "en"
                        ? applied + " active filter" + (applied > 1 ? "s" : "") + ". You can modify them or clear them all."
                        : applied + " filtre" + (applied > 1 ? "s" : "") + " actif" + (applied > 1 ? "s" : "") + ". Vous pouvez les modifier ou tout effacer.";
                } else {
                    status.textContent = t(
                        "Cochez plusieurs filtres puis appliquez-les en une seule fois.",
                        "Select several filters, then apply them all at once."
                    );
                }
            } else {
                status.textContent = language() === "en"
                    ? count + " pending change" + (count > 1 ? "s" : "") + (applied ? " · " + applied + " active" : "")
                    : count + " modification" + (count > 1 ? "s" : "") + " en attente" + (applied ? " · " + applied + " actif" + (applied > 1 ? "s" : "") : "");
            }
        }

        if (apply) apply.disabled = count === 0;
        if (cancelPending) cancelPending.disabled = count === 0;
        if (clearAll) clearAll.disabled = count === 0 && applied === 0;
    }

    function mountContextAccess(root) {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;

        const anchor = directChild(root, "h4,h3,h2") || root;
        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: PAGE_ID,
                context: {
                    sectionId: "multi-select",
                    pageId: PAGE_ID
                }
            });
        } catch (_) {}
    }

    function enhanceRoot(root) {
        if (!root || root.getAttribute("data-pmk055-enhanced") === "1") return;

        // Défense supplémentaire : un groupe de facettes ne doit exister
        // qu'une seule fois, même après un rafraîchissement asynchrone.
        deduplicateFacetGroups(root);

        root.setAttribute("data-pmk055-enhanced", "1");
        root.classList.add("pmk055-enhanced");

        if (currentConfig.drawers) root.classList.add("pmk055-drawers");
        if (currentConfig.multiSelect) root.classList.add("pmk055-multiselect");
        if (currentConfig.valuesMode === "all") root.classList.add("pmk055-values-all");

        pendingAdds.clear();
        pendingRemoves.clear();

        makeActionBar(root);
        mountQuickFilters(root);
        installLocalResultsObserver();
        scheduleLocalAvailabilityFilter();

        const mainList = directChild(root, "ul");
        if (!mainList) {
            mountContextAccess(root);
            return;
        }

        directChildren(mainList, "li").forEach(function (group) {
            const list = directChild(group, "ul");
            if (!list) return;

            if (group.id === "availability_facet" && currentConfig.hideAvailabilityFacet) {
                group.classList.add("pmk055-hidden-availability");
                return;
            }

            const labelInfo = displayGroupLabel(group);
            const label = labelInfo.text;

            if (currentConfig.drawers) {
                markNativeGroupHeading(group);

                const stateKey = facetGroupIdentity(group);
                const explicitState = stateKey && drawerStateOverrides.has(stateKey)
                    ? drawerStateOverrides.get(stateKey)
                    : null;

                const open = explicitState !== null
                    ? explicitState
                    : (
                        currentConfig.initialState === "open" ||
                        (currentConfig.openActive && groupHasActiveFacet(group))
                    );

                group.classList.toggle("pmk055-open", open);
                makeToggleButton(group, list, label, open);
            } else if (labelInfo.renamed) {
                applyStandaloneRenamedHeading(group, label);
            }

            enhanceChoices(group, list);
            updateGroupActiveIndicator(group);
        });

        mountContextAccess(root);

        window.setTimeout(function () {
            recalculateActiveFacetFamilies(root);
        }, 0);
    }

    function restore() {
        pendingAdds.clear();
        pendingRemoves.clear();
        stopLocalResultsObserver();

        clearLocalRowPresentation(resultRows(), true);
        document.querySelectorAll("[" + LOCAL_ORIGINAL_INDEX_ATTR + "]").forEach(function (row) {
            row.removeAttribute(LOCAL_ORIGINAL_INDEX_ATTR);
        });

        document.querySelectorAll("[" + NATIVE_TEXT_ATTR + '="1"]').forEach(function (span) {
            try {
                span.replaceWith(document.createTextNode(span.textContent || ""));
            } catch (_) {}
        });

        document.querySelectorAll("[" + GENERATED_ATTR + '="1"]').forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });

        document.querySelectorAll("[" + TEMP_ID_ATTR + '="1"]').forEach(function (node) {
            node.removeAttribute("id");
            node.removeAttribute(TEMP_ID_ATTR);
        });

        cleanupQuickFiltersBar();

        const root = document.getElementById("search-facets");
        if (!root) return;

        root.removeAttribute("data-pmk055-enhanced");
        root.classList.remove(
            "pmk055-enhanced",
            "pmk055-drawers",
            "pmk055-multiselect",
            "pmk055-values-all"
        );

        root.querySelectorAll(".pmk055-open").forEach(function (node) {
            node.classList.remove("pmk055-open");
        });

        root.querySelectorAll(".pmk055-native-heading").forEach(function (node) {
            node.classList.remove("pmk055-native-heading");
        });

        root.querySelectorAll(".pmk055-native-choice").forEach(function (node) {
            node.classList.remove("pmk055-native-choice");
        });

        root.querySelectorAll(".pmk055-hidden-availability").forEach(function (node) {
            node.classList.remove("pmk055-hidden-availability");
        });
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULTS);
        localAvailabilityHydrated = false;
        restore();

        if (!currentConfig.quickFilters.local.enabled) {
            setLocalAvailabilityState(false);
        } else {
            hydrateLocalAvailabilityState();
        }

        if (!currentConfig.enabled || !currentConfig.page.enabled) return;

        const root = document.getElementById("search-facets");
        if (!root) return;

        injectStyles();
        enhanceRoot(root);
    }

    function refreshAfterHistoryNavigation(event) {
        if (window.location.pathname !== PAGE_PATH) return;
        window.clearTimeout(navigationRefreshTimer);
        navigationRefreshTimer = window.setTimeout(function () {
            navigationRefreshTimer = null;
            if (window.location.search !== lastNavigationSearch) {
                drawerStateOverrides.clear();
                lastNavigationSearch = window.location.search;
            }
            // A page restored from the browser cache may retain generated nodes
            // but lose row classes or native table redraws. Rebuild from the
            // current URL and session state without writing any configuration.
            if (event && event.type === "pageshow") localAvailabilityHydrated = false;
            applyConfig(currentConfig);
        }, 0);
    }

    function handleFacetKeyboard(event) {
        if (event.key !== "Escape" || (!pendingAdds.size && !pendingRemoves.size)) return;
        const root = document.getElementById("search-facets");
        if (!root || !root.contains(event.target)) return;
        const returnTarget = event.target instanceof HTMLElement ? event.target : null;
        restorePendingChoices(root);
        event.preventDefault();
        event.stopPropagation();
        if (returnTarget && returnTarget.isConnected) returnTarget.focus();
    }

    function connectPmkConfig() {
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            applyConfig(DEFAULTS);
            return false;
        }

        api.getConfig(MODULE_ID)
            .then(function (config) {
                applyConfig(config || DEFAULTS);
            })
            .catch(function () {
                applyConfig(DEFAULTS);
            });

        if (!unsubscribe && typeof api.subscribe === "function") {
            try {
                unsubscribe = api.subscribe(MODULE_ID, function (config) {
                    applyConfig(config || DEFAULTS);
                });
            } catch (_) {}
        }

        return true;
    }

    function start() {
        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });

            let attempts = 0;
            startRetry = window.setInterval(function () {
                attempts += 1;
                if (connectPmkConfig() || attempts >= 50) {
                    window.clearInterval(startRetry);
                    startRetry = null;
                }
            }, 100);
        }

        window.setTimeout(function () { applyConfig(currentConfig); }, 250);
        window.setTimeout(function () { applyConfig(currentConfig); }, 900);
    }

    window.PMK055SearchFacets = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULTS),
        normalizeConfig: normalizeConfig,
        normalizeMultiChoiceLimits: normalizeMultiChoiceLimits,
        facetIdentity: facetIdentity,
        activeFacetGroupKeys: activeFacetGroupKeys,
        buildFacetRefreshUrl: function (key) { return buildFacetRefreshUrl(key).toString(); },
        applyConfig: applyConfig,
        restore: restore,
        getPending: function () {
            return {
                add: Array.from(pendingAdds),
                remove: Array.from(pendingRemoves)
            };
        },
        buildResultUrl: function () {
            return buildResultUrl().toString();
        },
        buildClearFacetsUrl: function () {
            return buildClearFacetsUrl().toString();
        },
        applyLocalAvailabilityFilter: applyLocalAvailabilityFilter,
        getLocalAvailabilityState: function () { return localAvailabilityActive; },
        normalizeMultiChoiceLimits: function (limits) {
            return normalizeMultiChoiceLimits(Array.isArray(limits) ? limits : []);
        },
        deduplicateFacetGroups: function () {
            const root = document.getElementById("search-facets");
            return root ? deduplicateFacetGroups(root) : 0;
        },
        getGroupDisplayLabel: function (group) {
            return displayGroupLabel(group);
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
    window.addEventListener("popstate", refreshAfterHistoryNavigation);
    window.addEventListener("pageshow", refreshAfterHistoryNavigation);
    document.addEventListener("keydown", handleFacetKeyboard);
})();

;window.PMKNonPlugin.loaded.push("055-facets-drawer.js");
} catch (error) { window.PMKNonPlugin.errors.push("055-facets-drawer.js: "+error.message); console.error("[PMK] 055-facets-drawer.js",error); };
try {
/*
 Nom du fichier : 057-member-pages-utils.js
 Module PMK      : Automatismes de saisie adhérent
 ID PMK          : patron-page-utils
 Version         : 4.0.1-pmk-isolated
 Date            : 2026-09-19
 Auteur          : équipe PimpMyKoha / refactorisation PimpMyKoha

 Objectif :
 - conserver STRICTEMENT tous les usages historiques du script 057 ;
 - séparer clairement les automatismes par fonction ;
 - rendre chaque fonction activable et paramétrable ;
 - rester centré sur la page Koha memberentry.pl ;
 - fonctionner avec ou sans le socle PMK (les valeurs historiques sont alors utilisées).

 Référence historique vérifiée (capture réseau HTTP 200 du 09/09/2026) :
 1. Civilité :
      M   -> 2e radio name="sex"
      Mme -> 1er radio name="sex"
      autre -> 3e radio name="sex"
    Déclenchement historique : blur de #btitle.
 2. Téléphone :
      #phone -> #SMSnumber
      validation /^(\+[0-9]{2}|0)[6-7][0-9]{8}$/
      conversion locale vers +33
      traitement sur input + change et au chargement.
 3. Préférences :
      #sms4 et #email4 cochés.
 4. Mot de passe :
      les 4 derniers caractères de #cardnumber alimentent
      #password et #password2 à chaque keyup, dès 4 caractères.
 5. Attribut adhérent :
      #patron_attr_6.selectedIndex = 1.
 6. Identifiant :
      si #othernames existe, #userid = prenom.nom
      en minuscules, sans accents, espaces, tirets, apostrophes ni parenthèses,
      à chaque input sur #firstname / #surname.

 IMPORTANT :
 Les valeurs par défaut ci-dessous reproduisent ces six comportements.
 Les options supplémentaires sont des extensions ; elles ne retirent aucun usage historique.
*/

(function () {
    "use strict";

    const MODULE_ID = "patron-page-utils";
    const MODULE_VERSION = "4.0.1-pmk-isolated";
    const SCRIPT_GUARD = "__pmk057PatronPageUtilsV4";
    const MEMBERENTRY_PATH = "/cgi-bin/koha/members/memberentry.pl";
    const HINT_ATTR = "data-pmk057-hint";
    const CONTEXT_KEY = "patron-page-utils-memberentry";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const DEFAULT_CONFIG = {
        enabled: true,

        titleSexEnabled: true,
        titleSexScope: "both",
        titleSelector: "#btitle",
        sexSelector: 'input[type="radio"][name="sex"]',
        titleSexTrigger: "blur",
        titleSexMappings: [
            {
                id: "legacy-mme",
                enabled: true,
                sourceValue: "Mme",
                targetMode: "index",
                targetIndex: 0,
                targetValue: ""
            },
            {
                id: "legacy-m",
                enabled: true,
                sourceValue: "M",
                targetMode: "index",
                targetIndex: 1,
                targetValue: ""
            }
        ],
        titleSexFallbackEnabled: true,
        titleSexFallbackMode: "index",
        titleSexFallbackIndex: 2,
        titleSexFallbackValue: "",

        phoneSmsEnabled: true,
        phoneSmsScope: "both",
        phoneSourceSelector: "#phone",
        smsTargetSelector: "#SMSnumber",
        phoneSmsPattern: "^(\\+[0-9]{2}|0)[6-7][0-9]{8}$",
        phoneSmsFlags: "",
        phoneSmsLocalPrefix: "0",
        phoneSmsInternationalPrefix: "+33",
        phoneSmsNormalizeLocal: true,
        phoneSmsCopySourceToTarget: true,
        phoneSmsOverwrite: "always",
        phoneSmsProcessOnLoad: true,
        phoneSmsListenInput: true,
        phoneSmsListenChange: true,
        smsNormalizeOwnValue: true,
        smsListenInput: true,
        smsListenChange: true,
        phoneSmsShowHints: true,
        phoneSmsCopiedTextFr: "Copié dans numéro SMS",
        phoneSmsCopiedTextEn: "Copied to SMS number",
        phoneSmsFormattedTextFr: "Formaté avec +33",
        phoneSmsFormattedTextEn: "Formatted with +33",
        phoneSmsInvalidTextFr: "Format de numéro invalide",
        phoneSmsInvalidTextEn: "Invalid phone number format",

        messagePrefsEnabled: true,
        messagePrefsScope: "both",
        messagePrefs: [
            {
                id: "legacy-sms4",
                enabled: true,
                name: "SMS 4",
                selector: "#sms4",
                checked: true,
                triggerChange: false
            },
            {
                id: "legacy-email4",
                enabled: true,
                name: "Email 4",
                selector: "#email4",
                checked: true,
                triggerChange: false
            }
        ],

        passwordEnabled: true,
        passwordScope: "both",
        passwordSourceSelector: "#cardnumber",
        passwordTrigger: "keyup",
        passwordMinSourceLength: 4,
        passwordExtractMode: "last",
        passwordExtractLength: 4,
        passwordExtractOffset: 0,
        passwordRegex: "",
        passwordRegexGroup: 0,
        passwordOverwrite: "always",
        passwordClearWhenTooShort: false,
        passwordTargets: [
            {
                id: "legacy-password",
                enabled: true,
                name: "Mot de passe",
                selector: "#password"
            },
            {
                id: "legacy-password2",
                enabled: true,
                name: "Confirmation du mot de passe",
                selector: "#password2"
            }
        ],

        attributeDefaultsEnabled: true,
        attributeDefaultsScope: "both",
        attributeDefaults: [
            {
                id: "legacy-patron-attr-6",
                enabled: true,
                name: "Attribut adhérent 6",
                selector: "#patron_attr_6",
                valueMode: "selected-index",
                selectedIndex: 1,
                value: "",
                checked: true,
                overwrite: "always",
                triggerChange: false
            }
        ],

        useridEnabled: true,
        useridScope: "both",
        useridFirstnameSelector: "#firstname",
        useridSurnameSelector: "#surname",
        useridTargetSelector: "#userid",
        useridRequiredPresenceSelector: "#othernames",
        useridTemplate: "{firstname}.{surname}",
        useridLowercase: true,
        useridStripDiacritics: true,
        useridRemoveSpaces: true,
        useridRemoveHyphens: true,
        useridRemoveApostrophes: true,
        useridRemoveParentheses: true,
        useridAdditionalRemoveRegex: "",
        useridOverwrite: "always",
        useridUpdateOnLoad: false,
        useridListenInput: true,
        useridListenChange: false
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let runtimeAbort = null;
    let applyGeneration = 0;
    let registered = false;
    let unsubscribe = null;
    let coreWaitTimer = null;

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function bool(value, fallback) {
        return typeof value === "boolean" ? value : fallback;
    }

    function num(value, fallback, min, max) {
        const n = Number(value);
        let out = Number.isFinite(n) ? n : fallback;
        if (Number.isFinite(min)) out = Math.max(min, out);
        if (Number.isFinite(max)) out = Math.min(max, out);
        return out;
    }

    function language() {
        const api = window.PMKConfig;
        if (api && typeof api.getLanguage === "function") {
            try {
                const value = clean(api.getLanguage()).toLowerCase();
                if (value.startsWith("en")) return "en";
                if (value.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        const html = clean(document.documentElement.getAttribute("lang")).toLowerCase();
        return html.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function uniqueId(prefix) {
        return String(prefix || "item") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
    }

    function isMemberEntryPage() {
        return window.location.pathname === MEMBERENTRY_PATH || /\/memberentry\.pl$/.test(window.location.pathname);
    }

    function safeQuery(selector) {
        const value = clean(selector);
        if (!value) return null;
        try {
            return document.querySelector(value);
        } catch (_) {
            return null;
        }
    }

    function safeQueryAll(selector) {
        const value = clean(selector);
        if (!value) return [];
        try {
            return Array.from(document.querySelectorAll(value));
        } catch (_) {
            return [];
        }
    }

    function waitForSelector(selector, timeout) {
        return new Promise(function (resolve, reject) {
            const first = safeQuery(selector);
            if (first) {
                resolve(first);
                return;
            }

            const root = document.documentElement || document.body;
            if (!root) {
                reject(new Error("no_dom_root"));
                return;
            }

            const observer = new MutationObserver(function () {
                const found = safeQuery(selector);
                if (found) {
                    observer.disconnect();
                    resolve(found);
                }
            });

            observer.observe(root, { childList: true, subtree: true });

            const ms = Number.isFinite(Number(timeout)) ? Number(timeout) : 3000;
            window.setTimeout(function () {
                observer.disconnect();
                reject(new Error("timeout"));
            }, ms);
        });
    }

    function currentFormMode() {
        try {
            const params = new URLSearchParams(window.location.search);
            const borrower = clean(params.get("borrowernumber"));
            if (borrower) return "edit";
        } catch (_) {}

        const hidden =
            safeQuery('input[name="borrowernumber"]') ||
            safeQuery("#borrowernumber");

        if (hidden && clean(hidden.value)) return "edit";
        return "create";
    }

    function scopeAllows(scope) {
        const value = ["create", "edit", "both"].includes(scope) ? scope : "both";
        if (value === "both") return true;
        return currentFormMode() === value;
    }

    function shouldWrite(element, overwrite) {
        if (!element) return false;
        if (overwrite !== "if-empty") return true;

        if (element.type === "checkbox" || element.type === "radio") {
            return element.checked === false;
        }

        return clean(element.value) === "";
    }

    function dispatch(element, type) {
        if (!element || !type) return;
        try {
            element.dispatchEvent(new Event(type, { bubbles: true }));
        } catch (_) {}
    }

    function normalizeTitleMapping(item) {
        const src = item && typeof item === "object" ? item : {};
        return {
            id: clean(src.id) || uniqueId("title-sex"),
            enabled: src.enabled !== false,
            sourceValue: String(src.sourceValue == null ? "" : src.sourceValue),
            targetMode: src.targetMode === "value" ? "value" : "index",
            targetIndex: Math.max(0, Math.trunc(num(src.targetIndex, 0, 0))),
            targetValue: String(src.targetValue == null ? "" : src.targetValue)
        };
    }

    function normalizeMessagePref(item) {
        const src = item && typeof item === "object" ? item : {};
        return {
            id: clean(src.id) || uniqueId("message-pref"),
            enabled: src.enabled !== false,
            name: clean(src.name),
            selector: clean(src.selector),
            checked: src.checked !== false,
            triggerChange: src.triggerChange === true
        };
    }

    function normalizePasswordTarget(item) {
        const src = item && typeof item === "object" ? item : {};
        return {
            id: clean(src.id) || uniqueId("password-target"),
            enabled: src.enabled !== false,
            name: clean(src.name),
            selector: clean(src.selector)
        };
    }

    function normalizeAttributeDefault(item) {
        const src = item && typeof item === "object" ? item : {};
        const allowedModes = ["selected-index", "value", "text", "checked"];
        return {
            id: clean(src.id) || uniqueId("attribute"),
            enabled: src.enabled !== false,
            name: clean(src.name),
            selector: clean(src.selector),
            valueMode: allowedModes.includes(src.valueMode) ? src.valueMode : "selected-index",
            selectedIndex: Math.max(0, Math.trunc(num(src.selectedIndex, 0, 0))),
            value: String(src.value == null ? "" : src.value),
            checked: src.checked !== false,
            overwrite: src.overwrite === "if-empty" ? "if-empty" : "always",
            triggerChange: src.triggerChange === true
        };
    }

    function normalizeConfig(config) {
        const src = config && typeof config === "object" ? config : {};

        return {
            enabled: bool(src.enabled, DEFAULT_CONFIG.enabled),

            titleSexEnabled: bool(src.titleSexEnabled, DEFAULT_CONFIG.titleSexEnabled),
            titleSexScope: ["create", "edit", "both"].includes(src.titleSexScope) ? src.titleSexScope : DEFAULT_CONFIG.titleSexScope,
            titleSelector: clean(src.titleSelector) || DEFAULT_CONFIG.titleSelector,
            sexSelector: clean(src.sexSelector) || DEFAULT_CONFIG.sexSelector,
            titleSexTrigger: ["blur", "change", "input"].includes(src.titleSexTrigger) ? src.titleSexTrigger : DEFAULT_CONFIG.titleSexTrigger,
            titleSexMappings: Array.isArray(src.titleSexMappings)
                ? src.titleSexMappings.map(normalizeTitleMapping)
                : clone(DEFAULT_CONFIG.titleSexMappings).map(normalizeTitleMapping),
            titleSexFallbackEnabled: bool(src.titleSexFallbackEnabled, DEFAULT_CONFIG.titleSexFallbackEnabled),
            titleSexFallbackMode: src.titleSexFallbackMode === "value" ? "value" : "index",
            titleSexFallbackIndex: Math.max(0, Math.trunc(num(src.titleSexFallbackIndex, DEFAULT_CONFIG.titleSexFallbackIndex, 0))),
            titleSexFallbackValue: String(src.titleSexFallbackValue == null ? DEFAULT_CONFIG.titleSexFallbackValue : src.titleSexFallbackValue),

            phoneSmsEnabled: bool(src.phoneSmsEnabled, DEFAULT_CONFIG.phoneSmsEnabled),
            phoneSmsScope: ["create", "edit", "both"].includes(src.phoneSmsScope) ? src.phoneSmsScope : DEFAULT_CONFIG.phoneSmsScope,
            phoneSourceSelector: clean(src.phoneSourceSelector) || DEFAULT_CONFIG.phoneSourceSelector,
            smsTargetSelector: clean(src.smsTargetSelector) || DEFAULT_CONFIG.smsTargetSelector,
            phoneSmsPattern: String(src.phoneSmsPattern == null ? DEFAULT_CONFIG.phoneSmsPattern : src.phoneSmsPattern),
            phoneSmsFlags: String(src.phoneSmsFlags == null ? DEFAULT_CONFIG.phoneSmsFlags : src.phoneSmsFlags).replace(/g/g, ""),
            phoneSmsLocalPrefix: String(src.phoneSmsLocalPrefix == null ? DEFAULT_CONFIG.phoneSmsLocalPrefix : src.phoneSmsLocalPrefix),
            phoneSmsInternationalPrefix: String(src.phoneSmsInternationalPrefix == null ? DEFAULT_CONFIG.phoneSmsInternationalPrefix : src.phoneSmsInternationalPrefix),
            phoneSmsNormalizeLocal: bool(src.phoneSmsNormalizeLocal, DEFAULT_CONFIG.phoneSmsNormalizeLocal),
            phoneSmsCopySourceToTarget: bool(src.phoneSmsCopySourceToTarget, DEFAULT_CONFIG.phoneSmsCopySourceToTarget),
            phoneSmsOverwrite: src.phoneSmsOverwrite === "if-empty" ? "if-empty" : "always",
            phoneSmsProcessOnLoad: bool(src.phoneSmsProcessOnLoad, DEFAULT_CONFIG.phoneSmsProcessOnLoad),
            phoneSmsListenInput: bool(src.phoneSmsListenInput, DEFAULT_CONFIG.phoneSmsListenInput),
            phoneSmsListenChange: bool(src.phoneSmsListenChange, DEFAULT_CONFIG.phoneSmsListenChange),
            smsNormalizeOwnValue: bool(src.smsNormalizeOwnValue, DEFAULT_CONFIG.smsNormalizeOwnValue),
            smsListenInput: bool(src.smsListenInput, DEFAULT_CONFIG.smsListenInput),
            smsListenChange: bool(src.smsListenChange, DEFAULT_CONFIG.smsListenChange),
            phoneSmsShowHints: bool(src.phoneSmsShowHints, DEFAULT_CONFIG.phoneSmsShowHints),
            phoneSmsCopiedTextFr: String(src.phoneSmsCopiedTextFr == null ? DEFAULT_CONFIG.phoneSmsCopiedTextFr : src.phoneSmsCopiedTextFr),
            phoneSmsCopiedTextEn: String(src.phoneSmsCopiedTextEn == null ? DEFAULT_CONFIG.phoneSmsCopiedTextEn : src.phoneSmsCopiedTextEn),
            phoneSmsFormattedTextFr: String(src.phoneSmsFormattedTextFr == null ? DEFAULT_CONFIG.phoneSmsFormattedTextFr : src.phoneSmsFormattedTextFr),
            phoneSmsFormattedTextEn: String(src.phoneSmsFormattedTextEn == null ? DEFAULT_CONFIG.phoneSmsFormattedTextEn : src.phoneSmsFormattedTextEn),
            phoneSmsInvalidTextFr: String(src.phoneSmsInvalidTextFr == null ? DEFAULT_CONFIG.phoneSmsInvalidTextFr : src.phoneSmsInvalidTextFr),
            phoneSmsInvalidTextEn: String(src.phoneSmsInvalidTextEn == null ? DEFAULT_CONFIG.phoneSmsInvalidTextEn : src.phoneSmsInvalidTextEn),

            messagePrefsEnabled: bool(src.messagePrefsEnabled, DEFAULT_CONFIG.messagePrefsEnabled),
            messagePrefsScope: ["create", "edit", "both"].includes(src.messagePrefsScope) ? src.messagePrefsScope : DEFAULT_CONFIG.messagePrefsScope,
            messagePrefs: Array.isArray(src.messagePrefs)
                ? src.messagePrefs.map(normalizeMessagePref)
                : clone(DEFAULT_CONFIG.messagePrefs).map(normalizeMessagePref),

            passwordEnabled: bool(src.passwordEnabled, DEFAULT_CONFIG.passwordEnabled),
            passwordScope: ["create", "edit", "both"].includes(src.passwordScope) ? src.passwordScope : DEFAULT_CONFIG.passwordScope,
            passwordSourceSelector: clean(src.passwordSourceSelector) || DEFAULT_CONFIG.passwordSourceSelector,
            passwordTrigger: ["keyup", "input", "change"].includes(src.passwordTrigger) ? src.passwordTrigger : DEFAULT_CONFIG.passwordTrigger,
            passwordMinSourceLength: Math.max(0, Math.trunc(num(src.passwordMinSourceLength, DEFAULT_CONFIG.passwordMinSourceLength, 0))),
            passwordExtractMode: ["last", "first", "range", "regex"].includes(src.passwordExtractMode) ? src.passwordExtractMode : DEFAULT_CONFIG.passwordExtractMode,
            passwordExtractLength: Math.max(0, Math.trunc(num(src.passwordExtractLength, DEFAULT_CONFIG.passwordExtractLength, 0))),
            passwordExtractOffset: Math.max(0, Math.trunc(num(src.passwordExtractOffset, DEFAULT_CONFIG.passwordExtractOffset, 0))),
            passwordRegex: String(src.passwordRegex == null ? DEFAULT_CONFIG.passwordRegex : src.passwordRegex),
            passwordRegexGroup: Math.max(0, Math.trunc(num(src.passwordRegexGroup, DEFAULT_CONFIG.passwordRegexGroup, 0))),
            passwordOverwrite: src.passwordOverwrite === "if-empty" ? "if-empty" : "always",
            passwordClearWhenTooShort: bool(src.passwordClearWhenTooShort, DEFAULT_CONFIG.passwordClearWhenTooShort),
            passwordTargets: Array.isArray(src.passwordTargets)
                ? src.passwordTargets.map(normalizePasswordTarget)
                : clone(DEFAULT_CONFIG.passwordTargets).map(normalizePasswordTarget),

            attributeDefaultsEnabled: bool(src.attributeDefaultsEnabled, DEFAULT_CONFIG.attributeDefaultsEnabled),
            attributeDefaultsScope: ["create", "edit", "both"].includes(src.attributeDefaultsScope) ? src.attributeDefaultsScope : DEFAULT_CONFIG.attributeDefaultsScope,
            attributeDefaults: Array.isArray(src.attributeDefaults)
                ? src.attributeDefaults.map(normalizeAttributeDefault)
                : clone(DEFAULT_CONFIG.attributeDefaults).map(normalizeAttributeDefault),

            useridEnabled: bool(src.useridEnabled, DEFAULT_CONFIG.useridEnabled),
            useridScope: ["create", "edit", "both"].includes(src.useridScope) ? src.useridScope : DEFAULT_CONFIG.useridScope,
            useridFirstnameSelector: clean(src.useridFirstnameSelector) || DEFAULT_CONFIG.useridFirstnameSelector,
            useridSurnameSelector: clean(src.useridSurnameSelector) || DEFAULT_CONFIG.useridSurnameSelector,
            useridTargetSelector: clean(src.useridTargetSelector) || DEFAULT_CONFIG.useridTargetSelector,
            useridRequiredPresenceSelector: String(
                src.useridRequiredPresenceSelector == null
                    ? DEFAULT_CONFIG.useridRequiredPresenceSelector
                    : src.useridRequiredPresenceSelector
            ),
            useridTemplate: String(src.useridTemplate == null ? DEFAULT_CONFIG.useridTemplate : src.useridTemplate),
            useridLowercase: bool(src.useridLowercase, DEFAULT_CONFIG.useridLowercase),
            useridStripDiacritics: bool(src.useridStripDiacritics, DEFAULT_CONFIG.useridStripDiacritics),
            useridRemoveSpaces: bool(src.useridRemoveSpaces, DEFAULT_CONFIG.useridRemoveSpaces),
            useridRemoveHyphens: bool(src.useridRemoveHyphens, DEFAULT_CONFIG.useridRemoveHyphens),
            useridRemoveApostrophes: bool(src.useridRemoveApostrophes, DEFAULT_CONFIG.useridRemoveApostrophes),
            useridRemoveParentheses: bool(src.useridRemoveParentheses, DEFAULT_CONFIG.useridRemoveParentheses),
            useridAdditionalRemoveRegex: String(src.useridAdditionalRemoveRegex == null ? DEFAULT_CONFIG.useridAdditionalRemoveRegex : src.useridAdditionalRemoveRegex),
            useridOverwrite: src.useridOverwrite === "if-empty" ? "if-empty" : "always",
            useridUpdateOnLoad: bool(src.useridUpdateOnLoad, DEFAULT_CONFIG.useridUpdateOnLoad),
            useridListenInput: bool(src.useridListenInput, DEFAULT_CONFIG.useridListenInput),
            useridListenChange: bool(src.useridListenChange, DEFAULT_CONFIG.useridListenChange)
        };
    }

    function removeHints() {
        document.querySelectorAll("[" + HINT_ATTR + "]").forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });
    }

    function addHint(afterElement, kind, message) {
        if (!afterElement || !afterElement.parentNode || !currentConfig.phoneSmsShowHints) return;
        removeHints();

        const node = document.createElement(kind === "invalid" ? "span" : "div");
        node.setAttribute(HINT_ATTR, "1");
        node.className = kind === "invalid" ? "required js2formatsmsnumber" : "hint js2formatsmsnumber";
        node.textContent = message;
        afterElement.insertAdjacentElement("afterend", node);
    }

    function compilePhonePattern(config) {
        try {
            return new RegExp(config.phoneSmsPattern, config.phoneSmsFlags || "");
        } catch (_) {
            try {
                return new RegExp(DEFAULT_CONFIG.phoneSmsPattern);
            } catch (_) {
                return null;
            }
        }
    }

    function isValidPhone(value, config) {
        const pattern = compilePhonePattern(config);
        if (!pattern) return false;
        pattern.lastIndex = 0;
        return pattern.test(String(value || ""));
    }

    function formatPhone(value, config) {
        const raw = String(value || "");
        if (
            config.phoneSmsNormalizeLocal === true &&
            clean(config.phoneSmsLocalPrefix) &&
            raw.startsWith(config.phoneSmsLocalPrefix) &&
            !raw.startsWith("+")
        ) {
            return String(config.phoneSmsInternationalPrefix || "") + raw.slice(config.phoneSmsLocalPrefix.length);
        }
        return raw;
    }

    function pickRadio(radios, mode, index, value) {
        if (!Array.isArray(radios) || !radios.length) return;

        let target = null;
        if (mode === "value") {
            target = radios.find(function (radio) {
                return String(radio.value) === String(value);
            }) || null;
        } else {
            target = radios[Math.max(0, Math.trunc(Number(index) || 0))] || null;
        }

        if (target) target.checked = true;
    }

    function setupTitleSex(config, generation, signal) {
        if (!config.titleSexEnabled || !scopeAllows(config.titleSexScope)) return;

        Promise.all([
            waitForSelector(config.titleSelector, 3000).catch(function () { return null; }),
            waitForSelector(config.sexSelector, 3000).catch(function () { return null; })
        ]).then(function (results) {
            if (generation !== applyGeneration || signal.aborted) return;

            const title = results[0];
            if (!title) return;

            function update() {
                const selectedValue = String(title.value == null ? "" : title.value);
                const radios = safeQueryAll(config.sexSelector).filter(function (node) {
                    return node && node.type === "radio";
                });
                if (!radios.length) return;

                const mapping = config.titleSexMappings.find(function (item) {
                    return item && item.enabled !== false && String(item.sourceValue) === selectedValue;
                });

                if (mapping) {
                    pickRadio(radios, mapping.targetMode, mapping.targetIndex, mapping.targetValue);
                } else if (config.titleSexFallbackEnabled) {
                    pickRadio(
                        radios,
                        config.titleSexFallbackMode,
                        config.titleSexFallbackIndex,
                        config.titleSexFallbackValue
                    );
                }
            }

            title.addEventListener(config.titleSexTrigger, update, { signal: signal });
        });
    }

    function setupPhoneSms(config, generation, signal) {
        if (!config.phoneSmsEnabled || !scopeAllows(config.phoneSmsScope)) return;

        Promise.all([
            waitForSelector(config.phoneSourceSelector, 3000).catch(function () { return null; }),
            waitForSelector(config.smsTargetSelector, 3000).catch(function () { return null; })
        ]).then(function (results) {
            if (generation !== applyGeneration || signal.aborted) return;

            const phone = results[0];
            const sms = results[1];
            if (!phone || !sms) return;

            function processPhoneNumber() {
                removeHints();
                const mobile = String(phone.value || "");

                if (!mobile) return;

                if (isValidPhone(mobile, config)) {
                    const formatted = formatPhone(mobile, config);

                    if (config.phoneSmsCopySourceToTarget && shouldWrite(sms, config.phoneSmsOverwrite)) {
                        sms.value = formatted;
                        dispatch(sms, "change");
                    }

                    addHint(
                        phone,
                        "ok",
                        t(config.phoneSmsCopiedTextFr, config.phoneSmsCopiedTextEn)
                    );
                } else {
                    addHint(
                        phone,
                        "invalid",
                        t(config.phoneSmsInvalidTextFr, config.phoneSmsInvalidTextEn)
                    );
                }
            }

            function processSmsNumber() {
                removeHints();
                const original = String(sms.value || "");
                if (!original) return;

                if (isValidPhone(original, config)) {
                    const formatted = formatPhone(original, config);
                    if (config.smsNormalizeOwnValue && formatted !== original) {
                        sms.value = formatted;
                        dispatch(sms, "change");
                        addHint(
                            sms,
                            "ok",
                            t(config.phoneSmsFormattedTextFr, config.phoneSmsFormattedTextEn)
                        );
                    }
                } else {
                    addHint(
                        sms,
                        "invalid",
                        t(config.phoneSmsInvalidTextFr, config.phoneSmsInvalidTextEn)
                    );
                }
            }

            if (config.phoneSmsListenChange) {
                phone.addEventListener("change", processPhoneNumber, { signal: signal });
            }
            if (config.phoneSmsListenInput) {
                phone.addEventListener("input", processPhoneNumber, { signal: signal });
            }
            if (config.smsListenChange) {
                sms.addEventListener("change", processSmsNumber, { signal: signal });
            }
            if (config.smsListenInput) {
                sms.addEventListener("input", processSmsNumber, { signal: signal });
            }

            if (config.phoneSmsProcessOnLoad && String(phone.value || "")) {
                processPhoneNumber();
            }
        });
    }

    function setupMessagePrefs(config, generation) {
        if (!config.messagePrefsEnabled || !scopeAllows(config.messagePrefsScope)) return;

        config.messagePrefs.forEach(function (rule) {
            if (!rule || rule.enabled === false || !rule.selector) return;

            waitForSelector(rule.selector, 2500).then(function (element) {
                if (generation !== applyGeneration || !element) return;
                element.checked = rule.checked === true;
                if (rule.triggerChange) dispatch(element, "change");
            }).catch(function () {});
        });
    }

    function extractPasswordValue(sourceValue, config) {
        const value = String(sourceValue || "");
        const length = Math.max(0, Math.trunc(config.passwordExtractLength || 0));
        const offset = Math.max(0, Math.trunc(config.passwordExtractOffset || 0));

        if (config.passwordExtractMode === "first") {
            return value.slice(offset, offset + length);
        }

        if (config.passwordExtractMode === "range") {
            return value.slice(offset, offset + length);
        }

        if (config.passwordExtractMode === "regex") {
            if (!clean(config.passwordRegex)) return "";
            try {
                const match = value.match(new RegExp(config.passwordRegex));
                if (!match) return "";
                return String(match[config.passwordRegexGroup] == null ? "" : match[config.passwordRegexGroup]);
            } catch (_) {
                return "";
            }
        }

        if (!length) return "";
        const end = Math.max(0, value.length - offset);
        const start = Math.max(0, end - length);
        return value.slice(start, end);
    }

    function setupPassword(config, generation, signal) {
        if (!config.passwordEnabled || !scopeAllows(config.passwordScope)) return;

        waitForSelector(config.passwordSourceSelector, 3000).then(function (source) {
            if (generation !== applyGeneration || signal.aborted || !source) return;

            function updatePassword() {
                const sourceValue = String(source.value || "");
                const tooShort = sourceValue.length < config.passwordMinSourceLength;

                config.passwordTargets.forEach(function (targetRule) {
                    if (!targetRule || targetRule.enabled === false || !targetRule.selector) return;
                    const target = safeQuery(targetRule.selector);
                    if (!target) return;

                    if (tooShort) {
                        if (config.passwordClearWhenTooShort && shouldWrite(target, config.passwordOverwrite)) {
                            target.value = "";
                        }
                        return;
                    }

                    if (!shouldWrite(target, config.passwordOverwrite)) return;
                    target.value = extractPasswordValue(sourceValue, config);
                });
            }

            source.addEventListener(config.passwordTrigger, updatePassword, { signal: signal });
        }).catch(function () {});
    }

    function applyAttributeDefault(element, rule) {
        if (!element || !rule) return;
        if (!shouldWrite(element, rule.overwrite)) return;

        if (rule.valueMode === "selected-index") {
            if ("selectedIndex" in element) {
                element.selectedIndex = rule.selectedIndex;
            }
        } else if (rule.valueMode === "checked") {
            if ("checked" in element) element.checked = rule.checked === true;
        } else if (rule.valueMode === "text") {
            if ("value" in element) element.value = String(rule.value || "");
            else element.textContent = String(rule.value || "");
        } else {
            if ("value" in element) element.value = String(rule.value || "");
        }

        if (rule.triggerChange) dispatch(element, "change");
    }

    function setupAttributeDefaults(config, generation) {
        if (!config.attributeDefaultsEnabled || !scopeAllows(config.attributeDefaultsScope)) return;

        config.attributeDefaults.forEach(function (rule) {
            if (!rule || rule.enabled === false || !rule.selector) return;

            waitForSelector(rule.selector, 2500).then(function (element) {
                if (generation !== applyGeneration || !element) return;
                applyAttributeDefault(element, rule);
            }).catch(function () {});
        });
    }

    function normalizeUseridPart(value, config) {
        let text = String(value || "");

        if (config.useridLowercase) text = text.toLowerCase();

        if (config.useridStripDiacritics) {
            try {
                text = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
            } catch (_) {}
        }

        if (config.useridRemoveSpaces) text = text.replace(/\s/g, "");
        if (config.useridRemoveHyphens) text = text.replace(/-/g, "");
        if (config.useridRemoveApostrophes) text = text.replace(/['’]/g, "");
        if (config.useridRemoveParentheses) text = text.replace(/[()]/g, "");

        if (clean(config.useridAdditionalRemoveRegex)) {
            try {
                text = text.replace(new RegExp(config.useridAdditionalRemoveRegex, "g"), "");
            } catch (_) {}
        }

        return text;
    }

    function setupUserid(config, generation, signal) {
        if (!config.useridEnabled || !scopeAllows(config.useridScope)) return;

        const requiredPresence = clean(config.useridRequiredPresenceSelector);

        Promise.all([
            requiredPresence
                ? waitForSelector(requiredPresence, 3000).catch(function () { return null; })
                : Promise.resolve(true),
            waitForSelector(config.useridFirstnameSelector, 3000).catch(function () { return null; }),
            waitForSelector(config.useridSurnameSelector, 3000).catch(function () { return null; }),
            waitForSelector(config.useridTargetSelector, 3000).catch(function () { return null; })
        ]).then(function (results) {
            if (generation !== applyGeneration || signal.aborted) return;

            const guard = results[0];
            const firstname = results[1];
            const surname = results[2];
            const target = results[3];

            if (!guard || !firstname || !surname || !target) return;

            function updateUserid() {
                if (!shouldWrite(target, config.useridOverwrite)) return;

                const first = normalizeUseridPart(firstname.value, config);
                const last = normalizeUseridPart(surname.value, config);

                target.value = String(config.useridTemplate || "")
                    .replace(/\{firstname\}/g, first)
                    .replace(/\{surname\}/g, last);
            }

            if (config.useridListenInput) {
                firstname.addEventListener("input", updateUserid, { signal: signal });
                surname.addEventListener("input", updateUserid, { signal: signal });
            }

            if (config.useridListenChange) {
                firstname.addEventListener("change", updateUserid, { signal: signal });
                surname.addEventListener("change", updateUserid, { signal: signal });
            }

            if (config.useridUpdateOnLoad) updateUserid();
        });
    }

    function stopRuntime() {
        applyGeneration += 1;

        if (runtimeAbort) {
            try { runtimeAbort.abort(); } catch (_) {}
            runtimeAbort = null;
        }

        removeHints();
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULT_CONFIG);
        stopRuntime();

        if (!currentConfig.enabled || !isMemberEntryPage()) {
            mountContextAccess();
            return;
        }

        const generation = applyGeneration;
        runtimeAbort = new AbortController();
        const signal = runtimeAbort.signal;

        setupTitleSex(currentConfig, generation, signal);
        setupPhoneSms(currentConfig, generation, signal);
        setupMessagePrefs(currentConfig, generation);
        setupPassword(currentConfig, generation, signal);
        setupAttributeDefaults(currentConfig, generation);
        setupUserid(currentConfig, generation, signal);
        mountContextAccess();
    }

    function titleMappingNew() {
        return normalizeTitleMapping({
            id: uniqueId("title-sex"),
            enabled: true,
            sourceValue: "",
            targetMode: "value",
            targetIndex: 0,
            targetValue: ""
        });
    }

    function messagePrefNew() {
        return normalizeMessagePref({
            id: uniqueId("message-pref"),
            enabled: true,
            name: "",
            selector: "",
            checked: true,
            triggerChange: false
        });
    }

    function passwordTargetNew() {
        return normalizePasswordTarget({
            id: uniqueId("password-target"),
            enabled: true,
            name: "",
            selector: ""
        });
    }

    function attributeDefaultNew() {
        return normalizeAttributeDefault({
            id: uniqueId("attribute"),
            enabled: true,
            name: "",
            selector: "",
            valueMode: "value",
            selectedIndex: 0,
            value: "",
            checked: true,
            overwrite: "if-empty",
            triggerChange: false
        });
    }

    function scopeOptions() {
        return [
            { value: "both", label: { fr: "Création et modification", en: "Create and edit" } },
            { value: "create", label: { fr: "Création uniquement", en: "Create only" } },
            { value: "edit", label: { fr: "Modification uniquement", en: "Edit only" } }
        ];
    }

    function overwriteOptions() {
        return [
            { value: "always", label: { fr: "Toujours remplacer — par défaut", en: "Always replace — default" } },
            { value: "if-empty", label: { fr: "Seulement si la cible est vide", en: "Only when target is empty" } }
        ];
    }

    function pathIndex(path, key) {
        const list = Array.isArray(path) ? path : [];
        for (let i = 0; i < list.length - 1; i += 1) {
            if (list[i] === key && Number.isInteger(list[i + 1])) return list[i + 1];
        }
        return -1;
    }

    function itemFromPath(root, path, key) {
        const index = pathIndex(path, key);
        return root && Array.isArray(root[key]) && index >= 0 ? root[key][index] : null;
    }

    function getAtPath(root, path) {
        let node = root;
        (Array.isArray(path) ? path : []).forEach(function (part) {
            if (node != null) node = node[part];
        });
        return node;
    }

    function setAtPath(root, path, value) {
        const parts = Array.isArray(path) ? path.slice() : [];
        if (!root || !parts.length) return root;

        let node = root;
        for (let i = 0; i < parts.length - 1; i += 1) {
            const part = parts[i];
            const next = parts[i + 1];

            if (node[part] == null) {
                node[part] = Number.isInteger(next) ? [] : {};
            }
            node = node[part];
        }

        node[parts[parts.length - 1]] = value;
        return root;
    }

    function cssEscapeString(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(String(value));
        return String(value).replace(/["\\]/g, "\\$&");
    }

    function pickerService() {
        return window.PMKConfig && window.PMKConfig.elementPicker;
    }

    function pickerTargetUrl() {
        return isMemberEntryPage()
            ? window.location.pathname + window.location.search
            : MEMBERENTRY_PATH;
    }

    function pickSelector(context, mode) {
        const service = pickerService();

        if (!service || typeof service.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }

        registerPickerAdapter();

        const path = context && Array.isArray(context.fieldPath)
            ? context.fieldPath.slice()
            : [];

        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: pickerTargetUrl(),
            rootObject: context && context.rootObject ? context.rootObject : {},
            fieldPath: path,
            meta: {
                pickMode: mode || "field",
                fieldPath: path
            },
            adminContext: {
                sectionId: "memberentry"
            },
            options: {
                bannerText: t(
                    "Clique sur le champ Koha à utiliser pour cet automatisme — Échap annule",
                    "Click the Koha field to use for this automation — Esc cancels"
                )
            },
            persistAfterPick: false
        });
    }

    function resolvePickedField(element, request) {
        if (!element || element.nodeType !== 1) return null;

        let candidate = element;

        if (candidate.tagName && candidate.tagName.toLowerCase() === "label") {
            const forId = clean(candidate.getAttribute("for"));
            if (forId) {
                const labelled = document.getElementById(forId);
                if (labelled) candidate = labelled;
            }
        }

        candidate =
            (candidate.closest && candidate.closest("input,select,textarea,button")) ||
            candidate.querySelector && candidate.querySelector("input,select,textarea,button") ||
            candidate;

        const mode = clean(request && request.meta && request.meta.pickMode);

        if (mode === "radio-group" && candidate && candidate.type === "radio" && candidate.name) {
            return candidate;
        }

        return candidate;
    }

    function pickerBuildResult(element, result, request) {
        const target = resolvePickedField(element, request) || element;
        const mode = clean(request && request.meta && request.meta.pickMode);

        if (mode === "radio-group" && target && target.type === "radio" && target.name) {
            result.selector = 'input[type="radio"][name="' + cssEscapeString(target.name) + '"]';
            result.value = result.selector;
        }

        result.targetName =
            clean(target && (target.getAttribute && target.getAttribute("name"))) ||
            clean(target && target.id) ||
            clean(target && target.getAttribute && target.getAttribute("aria-label")) ||
            "";

        return result;
    }

    function pickerApplyPending(draft, pending, picked) {
        const path =
            pending && pending.meta && Array.isArray(pending.meta.fieldPath)
                ? pending.meta.fieldPath
                : [];

        if (!draft || !path.length) return draft;

        const selector = clean(picked && (picked.selector || picked.value));
        if (selector) setAtPath(draft, path, selector);
        return draft;
    }

    function registerPickerAdapter() {
        const service = pickerService();
        if (!service || typeof service.register !== "function") return false;

        service.register(MODULE_ID, {
            resolveTarget: resolvePickedField,
            buildResult: pickerBuildResult,
            applyPending: pickerApplyPending
        });

        return true;
    }

    function isTitleMapValueMode(root, path) {
        const item = itemFromPath(root, path, "titleSexMappings");
        return Boolean(item && item.targetMode === "value");
    }

    function isTitleMapIndexMode(root, path) {
        const item = itemFromPath(root, path, "titleSexMappings");
        return Boolean(item && item.targetMode !== "value");
    }

    function isFallbackValueMode(root) {
        return root && root.titleSexFallbackMode === "value";
    }

    function isFallbackIndexMode(root) {
        return !root || root.titleSexFallbackMode !== "value";
    }

    function isPasswordRange(root) {
        return root && root.passwordExtractMode === "range";
    }

    function isPasswordRegex(root) {
        return root && root.passwordExtractMode === "regex";
    }

    function attributeItem(root, path) {
        return itemFromPath(root, path, "attributeDefaults");
    }

    function attributeMode(root, path, mode) {
        const item = attributeItem(root, path);
        return Boolean(item && item.valueMode === mode);
    }

    function validate(config) {
        const cfg = normalizeConfig(config);

        if (cfg.titleSexEnabled) {
            if (!cfg.titleSelector || !cfg.sexSelector) {
                return { ok: false, message: t("Civilité → sexe : les deux champs doivent être définis.", "Title → sex: both fields must be defined.") };
            }
        }

        if (cfg.phoneSmsEnabled) {
            try {
                new RegExp(cfg.phoneSmsPattern, cfg.phoneSmsFlags || "");
            } catch (_) {
                return { ok: false, message: t("Téléphone → SMS : l’expression de validation est invalide.", "Phone → SMS: validation expression is invalid.") };
            }

            if (!cfg.phoneSourceSelector || !cfg.smsTargetSelector) {
                return { ok: false, message: t("Téléphone → SMS : la source et la cible doivent être définies.", "Phone → SMS: source and target must be defined.") };
            }
        }

        if (cfg.passwordEnabled && !cfg.passwordSourceSelector) {
            return { ok: false, message: t("Mot de passe : le champ source doit être défini.", "Password: source field must be defined.") };
        }

        if (cfg.useridEnabled) {
            if (!cfg.useridFirstnameSelector || !cfg.useridSurnameSelector || !cfg.useridTargetSelector) {
                return { ok: false, message: t("Identifiant : prénom, nom et cible doivent être définis.", "User ID: firstname, surname and target must be defined.") };
            }
            if (!cfg.useridTemplate.includes("{firstname}") && !cfg.useridTemplate.includes("{surname}")) {
                return { ok: false, message: t("Identifiant : le modèle doit utiliser {firstname} ou {surname}.", "User ID: template must use {firstname} or {surname}.") };
            }
        }

        return { ok: true };
    }

    function renderAutomationPreview(context) {
        const config = normalizeConfig(context && context.rootObject || DEFAULT_CONFIG);
        const host = document.createElement("div");
        const intro = document.createElement("p");
        intro.textContent = t(
            "Lecture seule : cet aperçu examine le formulaire ouvert sans modifier ni déclencher aucun champ.",
            "Read only: this preview examines the open form without changing or triggering any field."
        );
        host.appendChild(intro);
        const table = document.createElement("table");
        table.className = "table table-sm table-striped";
        table.innerHTML = "<thead><tr><th>" + t("Automatisme", "Automation") + "</th><th>" + t("Cibles", "Targets") + "</th><th>" + t("Effet prévu", "Expected effect") + "</th></tr></thead>";
        const body = document.createElement("tbody");
        function add(name, selectors, effect) {
            const tr = document.createElement("tr");
            [name, selectors, effect].forEach(function (value) {
                const td = document.createElement("td");
                td.textContent = String(value || "");
                tr.appendChild(td);
            });
            body.appendChild(tr);
        }
        function targetState(selector) {
            const nodes = safeQueryAll(selector);
            return nodes.length ? nodes.length + " " + t("cible(s) trouvée(s)", "target(s) found") : t("Cible absente", "Missing target");
        }
        if (config.titleSexEnabled) {
            const source = safeQuery(config.titleSelector), value = source ? String(source.value || "") : "";
            const mapping = config.titleSexMappings.find(function (row) { return row.enabled !== false && String(row.sourceValue) === value; });
            add(t("Civilité → sexe", "Title → sex"), targetState(config.titleSelector) + " · " + targetState(config.sexSelector), mapping ? t("Correspondance : ", "Mapping: ") + value : config.titleSexFallbackEnabled ? t("Choix de repli", "Fallback option") : t("Aucun changement", "No change"));
        }
        if (config.phoneSmsEnabled) {
            const source = safeQuery(config.phoneSourceSelector), target = safeQuery(config.smsTargetSelector), mobile = source ? String(source.value || "") : "";
            const valid = mobile && isValidPhone(mobile, config), canWrite = target && shouldWrite(target, config.phoneSmsOverwrite);
            add(t("Téléphone → SMS", "Phone → SMS"), targetState(config.phoneSourceSelector) + " · " + targetState(config.smsTargetSelector), !valid ? t("Numéro absent ou invalide", "Missing or invalid number") : !canWrite ? t("Valeur manuelle conservée", "Manual value preserved") : t("Proposition : ", "Proposed: ") + formatPhone(mobile, config));
        }
        if (config.messagePrefsEnabled) add(t("Préférences de messages", "Messaging preferences"), config.messagePrefs.filter(function (r) { return r.enabled !== false && safeQuery(r.selector); }).length + "/" + config.messagePrefs.filter(function (r) { return r.enabled !== false; }).length, t("Cases configurées selon les règles actives", "Checkboxes set according to active rules"));
        if (config.passwordEnabled) {
            const source = safeQuery(config.passwordSourceSelector), targets = config.passwordTargets.filter(function (r) { return r.enabled !== false && safeQuery(r.selector); });
            const generated = source && String(source.value || "").length >= config.passwordMinSourceLength ? extractPasswordValue(source.value, config).length : 0;
            add(t("Mot de passe", "Password"), targetState(config.passwordSourceSelector) + " · " + targets.length + " " + t("cible(s)", "target(s)"), generated ? generated + " " + t("caractères seraient générés (valeur masquée)", "characters would be generated (value hidden)") : t("Source trop courte ou absente", "Source missing or too short"));
        }
        if (config.attributeDefaultsEnabled) config.attributeDefaults.filter(function (r) { return r.enabled !== false; }).forEach(function (rule) {
            const target = safeQuery(rule.selector), canWrite = target && shouldWrite(target, rule.overwrite);
            add(rule.name || t("Attribut adhérent", "Patron attribute"), targetState(rule.selector), !target ? t("Aucun effet", "No effect") : canWrite ? t("Valeur par défaut proposée", "Default value proposed") : t("Valeur manuelle conservée", "Manual value preserved"));
        });
        if (config.useridEnabled) {
            const first = safeQuery(config.useridFirstnameSelector), last = safeQuery(config.useridSurnameSelector), target = safeQuery(config.useridTargetSelector);
            const proposed = String(config.useridTemplate || "").replace(/\{firstname\}/g, normalizeUseridPart(first && first.value, config)).replace(/\{surname\}/g, normalizeUseridPart(last && last.value, config));
            add(t("Identifiant", "User ID"), targetState(config.useridTargetSelector), target && !shouldWrite(target, config.useridOverwrite) ? t("Identifiant manuel conservé", "Manual user ID preserved") : proposed ? t("Proposition : ", "Proposed: ") + proposed : t("Prénom ou nom absent", "Missing first or last name"));
        }
        table.appendChild(body); host.appendChild(table);
        return host;
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: {
                fr: "Automatismes de saisie adhérent",
                en: "Patron entry automations"
            },
            description: {
                fr: "Automatise certaines opérations sur la fiche d’inscription/modification d’un adhérent.",
                en: "Automates selected operations on the patron registration/edit form."
            },
            category: {
                fr: "Adhérents",
                en: "Patrons"
            },
            supportedPages: [MEMBERENTRY_PATH],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "preview",
                    label: { fr: "Aperçu sur le formulaire ouvert", en: "Preview on the open form" },
                    description: { fr: "Contrôle les cibles et montre les valeurs proposées avant d’enregistrer les réglages.", en: "Checks targets and shows proposed values before saving settings." },
                    fields: [
                        { type: "custom", label: { fr: "Simulation sans écriture", en: "Read-only simulation" }, render: renderAutomationPreview }
                    ]
                },
                {
                    type: "section",
                    id: "title-sex",
                    label: { fr: "Civilité → sexe", en: "Title → sex" },
                    description: {
                        fr: "Par défaut : Mme sélectionne le 1er choix de sexe, M le 2e, toute autre civilité le 3e, au blur de la civilité.",
                        en: "Default: Mme selects the 1st sex option, M the 2nd, any other title the 3rd, on title blur."
                    },
                    fields: [
                        { key: "titleSexEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "titleSexScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "titleSelector",
                            type: "elementPicker",
                            label: { fr: "Champ Civilité", en: "Title field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "sexSelector",
                            type: "elementPicker",
                            label: { fr: "Groupe Sexe", en: "Sex radio group" },
                            pickLabel: { fr: "Choisir un bouton du groupe", en: "Choose a radio in the group" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "radio-group"); },
                            help: {
                                fr: "En cliquant sur un bouton radio, PMK mémorise automatiquement tout le groupe portant le même nom.",
                                en: "Clicking a radio button makes PMK target the whole radio group with the same name."
                            }
                        },
                        {
                            key: "titleSexTrigger",
                            type: "select",
                            label: { fr: "Déclenchement", en: "Trigger" },
                            options: [
                                { value: "blur", label: { fr: "Quand on quitte le champ — par défaut", en: "When leaving the field — default" } },
                                { value: "change", label: { fr: "Quand la valeur change", en: "When the value changes" } },
                                { value: "input", label: { fr: "Pendant la saisie", en: "While editing" } }
                            ]
                        },
                        {
                            key: "titleSexMappings",
                            type: "repeater",
                            label: { fr: "Correspondances", en: "Mappings" },
                            addLabel: { fr: "Ajouter une correspondance", en: "Add mapping" },
                            reorder: true,
                            newItem: titleMappingNew,
                            itemTitle: function (item, index) {
                                return clean(item && item.sourceValue)
                                    ? t("Civilité : ", "Title: ") + item.sourceValue
                                    : t("Correspondance ", "Mapping ") + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Active", en: "Enabled" } },
                                { key: "sourceValue", type: "text", label: { fr: "Valeur de civilité", en: "Title value" } },
                                {
                                    key: "targetMode",
                                    type: "select",
                                    label: { fr: "Identifier le choix sexe par", en: "Identify sex option by" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "index", label: { fr: "Position dans la liste", en: "Position in list" } },
                                        { value: "value", label: { fr: "Valeur technique du choix", en: "Option value" } }
                                    ]
                                },
                                {
                                    key: "targetIndex",
                                    type: "number",
                                    min: 0,
                                    step: 1,
                                    label: { fr: "Position (0 = premier choix)", en: "Position (0 = first option)" },
                                    when: isTitleMapIndexMode
                                },
                                {
                                    key: "targetValue",
                                    type: "text",
                                    label: { fr: "Valeur cible", en: "Target value" },
                                    when: isTitleMapValueMode
                                }
                            ]
                        },
                        { key: "titleSexFallbackEnabled", type: "boolean", label: { fr: "Traiter toutes les autres civilités", en: "Handle every other title" }, refreshOnChange: true },
                        {
                            key: "titleSexFallbackMode",
                            type: "select",
                            label: { fr: "Choix sexe pour les autres civilités", en: "Sex option for other titles" },
                            refreshOnChange: true,
                            when: function (root) { return root && root.titleSexFallbackEnabled === true; },
                            options: [
                                { value: "index", label: { fr: "Par position", en: "By position" } },
                                { value: "value", label: { fr: "Par valeur", en: "By value" } }
                            ]
                        },
                        {
                            key: "titleSexFallbackIndex",
                            type: "number",
                            min: 0,
                            step: 1,
                            label: { fr: "Position (0 = premier choix)", en: "Position (0 = first option)" },
                            when: function (root) { return root && root.titleSexFallbackEnabled === true && isFallbackIndexMode(root); }
                        },
                        {
                            key: "titleSexFallbackValue",
                            type: "text",
                            label: { fr: "Valeur cible", en: "Target value" },
                            when: function (root) { return root && root.titleSexFallbackEnabled === true && isFallbackValueMode(root); }
                        }
                    ]
                },

                {
                    type: "section",
                    id: "phone-sms",
                    label: { fr: "Téléphone → numéro SMS", en: "Phone → SMS number" },
                    description: {
                        fr: "Par défaut : valide le téléphone principal, copie un mobile valide vers le numéro SMS, convertit 06/07 en +336/+337 et valide également le champ SMS.",
                        en: "Default: validates the main phone, copies a valid mobile to the SMS number, converts 06/07 to +336/+337 and validates the SMS field too."
                    },
                    fields: [
                        { key: "phoneSmsEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "phoneSmsScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "phoneSourceSelector",
                            type: "elementPicker",
                            label: { fr: "Téléphone source", en: "Source phone field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "smsTargetSelector",
                            type: "elementPicker",
                            label: { fr: "Champ numéro SMS", en: "SMS number field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "phoneSmsPattern",
                            type: "text",
                            label: { fr: "Expression de validation", en: "Validation expression" },
                            help: {
                                fr: "Valeur par défaut : ^(\\+[0-9]{2}|0)[6-7][0-9]{8}$",
                                en: "Default value: ^(\\+[0-9]{2}|0)[6-7][0-9]{8}$"
                            }
                        },
                        { key: "phoneSmsInternationalPrefix", type: "text", label: { fr: "Préfixe international ajouté", en: "International prefix to add" } },
                        { key: "phoneSmsLocalPrefix", type: "text", label: { fr: "Préfixe local remplacé", en: "Local prefix to replace" } },
                        { key: "phoneSmsNormalizeLocal", type: "boolean", label: { fr: "Convertir le format local vers l’international", en: "Convert local format to international" }, help: { fr: "Si le numéro commence par le préfixe local configuré (par défaut 0), il est converti vers le préfixe international (par défaut +33). Exemple : 06… devient +336…", en: "When the number starts with the configured local prefix (0 by default), it is converted to the international prefix (+33 by default). Example: 06… becomes +336…." } },
                        { key: "phoneSmsCopySourceToTarget", type: "boolean", label: { fr: "Copier le téléphone valide vers le numéro SMS", en: "Copy valid phone to SMS number" }, help: { fr: "Lorsqu’un téléphone principal correspond au format mobile accepté, sa valeur normalisée est recopiée dans le champ Numéro SMS.", en: "When the main phone matches the accepted mobile format, its normalized value is copied to the SMS number field." } },
                        { key: "phoneSmsOverwrite", type: "select", label: { fr: "Si le numéro SMS contient déjà une valeur", en: "If SMS number already has a value" }, options: overwriteOptions(), help: { fr: "« Toujours remplacer » maintient le SMS identique au téléphone mobile valide. « Seulement si la cible est vide » préserve une valeur SMS déjà saisie.", en: "“Always replace” keeps SMS synchronized with a valid mobile phone. “Only when target is empty” preserves an existing SMS value." } },
                        { key: "phoneSmsProcessOnLoad", type: "boolean", label: { fr: "Traiter le téléphone dès l’ouverture de la fiche — par défaut", en: "Process phone when form opens — default" }, help: { fr: "Dès l’ouverture de la fiche, contrôle le téléphone déjà présent et applique immédiatement la normalisation et la copie selon les autres options.", en: "As soon as the form opens, checks the existing phone and immediately applies normalization and copying according to the other options." } },
                        { key: "phoneSmsListenInput", type: "boolean", label: { fr: "Traiter pendant la saisie du téléphone — par défaut", en: "Process while typing phone — default" }, help: { fr: "Réagit à chaque frappe dans le champ Téléphone. Permet un contrôle immédiat pendant la saisie.", en: "Runs on each input event in the Phone field for immediate checking while typing." } },
                        { key: "phoneSmsListenChange", type: "boolean", label: { fr: "Traiter au changement du téléphone — par défaut", en: "Process on phone change — default" }, help: { fr: "Contrôle le téléphone lors de l’événement change, généralement après validation de la saisie ou sortie du champ.", en: "Checks the phone on the change event, usually after the value is committed or the field is left." } },
                        { key: "smsNormalizeOwnValue", type: "boolean", label: { fr: "Normaliser aussi la valeur saisie directement dans le numéro SMS", en: "Also normalize values typed directly in SMS number" }, help: { fr: "Applique les mêmes règles de formatage lorsque l’agent saisit directement un numéro dans le champ SMS.", en: "Applies the same formatting rules when the agent types directly in the SMS number field." } },
                        { key: "smsListenInput", type: "boolean", label: { fr: "Valider le numéro SMS pendant la saisie — par défaut", en: "Validate SMS number while typing — default" }, help: { fr: "Contrôle le format du Numéro SMS à chaque frappe et met à jour le message d’aide si les messages sont activés.", en: "Checks the SMS number format on each input and updates the hint when messages are enabled." } },
                        { key: "smsListenChange", type: "boolean", label: { fr: "Valider le numéro SMS au changement — par défaut", en: "Validate SMS number on change — default" }, help: { fr: "Contrôle le Numéro SMS lors de l’événement change, notamment quand l’agent quitte le champ après l’avoir modifié.", en: "Checks the SMS number on the change event, notably when the agent leaves the field after editing it." } },
                        { key: "phoneSmsShowHints", type: "boolean", label: { fr: "Afficher les messages sous les champs", en: "Show messages below fields" }, help: { fr: "Affiche sous Téléphone et Numéro SMS les messages de copie, conversion ou format invalide. Désactiver cette option masque uniquement les messages : les automatismes continuent de fonctionner.", en: "Shows copy, conversion and invalid-format messages below Phone and SMS number. Disabling it hides only the messages; the automations keep running." } },
                        { key: "phoneSmsCopiedTextFr", type: "text", label: { fr: "Message FR après copie", en: "FR message after copy" } },
                        { key: "phoneSmsCopiedTextEn", type: "text", label: { fr: "Message EN après copie", en: "EN message after copy" } },
                        { key: "phoneSmsFormattedTextFr", type: "text", label: { fr: "Message FR après formatage", en: "FR message after formatting" } },
                        { key: "phoneSmsFormattedTextEn", type: "text", label: { fr: "Message EN après formatage", en: "EN message after formatting" } },
                        { key: "phoneSmsInvalidTextFr", type: "text", label: { fr: "Message FR si invalide", en: "FR invalid message" } },
                        { key: "phoneSmsInvalidTextEn", type: "text", label: { fr: "Message EN si invalide", en: "EN invalid message" } }
                    ]
                },

                {
                    type: "section",
                    id: "message-prefs",
                    label: { fr: "Préférences de messages", en: "Messaging preferences" },
                    description: {
                        fr: "Positionne automatiquement des cases natives de Koha sur la fiche adhérent. Vous pouvez cibler plusieurs cases et définir pour chacune l’état attendu.",
                        en: "Automatically sets native Koha checkboxes on the patron form. You can target multiple checkboxes and define the expected state for each one."
                    },
                    fields: [
                        { key: "messagePrefsEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "messagePrefsScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "messagePrefs",
                            type: "repeater",
                            label: { fr: "Cases à positionner", en: "Checkboxes to set" },
                            help: { fr: "Chaque élément correspond à une case à cocher Koha que PMK doit positionner automatiquement. Ajoutez une ligne par préférence ou option à piloter.", en: "Each item targets one Koha checkbox that PMK should set automatically. Add one row per preference or option to control." },
                            addLabel: { fr: "Ajouter une case", en: "Add checkbox" },
                            reorder: true,
                            newItem: messagePrefNew,
                            liveTitleKey: "name",
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Actif", en: "Enabled" }, help: { fr: "Active ou désactive uniquement cette règle, sans supprimer sa configuration.", en: "Enables or disables only this rule without deleting its configuration." } },
                                { key: "name", type: "text", label: { fr: "Nom lisible", en: "Display name" }, help: { fr: "Nom affiché uniquement dans PimpMyKoha pour identifier la règle. Il ne modifie aucun libellé dans Koha.", en: "Name shown only in PimpMyKoha to identify the rule. It does not change any Koha label." } },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Case Koha", en: "Koha checkbox" },
                                    help: { fr: "Case réellement ciblée dans memberentry.pl. Utilisez « Choisir sur la page » pour sélectionner la bonne case sans connaître son sélecteur CSS.", en: "The actual checkbox targeted in memberentry.pl. Use “Choose on page” to select it without knowing its CSS selector." },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    allowManual: true,
                                    pick: function (context) { return pickSelector(context, "field"); }
                                },
                                { key: "checked", type: "boolean", label: { fr: "Case cochée", en: "Checked" }, help: { fr: "Oui : PMK coche la case. Non : PMK la décoche. C’est l’état final appliqué à cette case.", en: "Yes: PMK checks the box. No: PMK unchecks it. This is the final state applied to the checkbox." } },
                                { key: "triggerChange", type: "boolean", label: { fr: "Déclencher aussi l’événement change", en: "Also trigger change event" }, help: { fr: "Oui : après avoir positionné la case, PMK déclenche aussi l’événement JavaScript « change » pour que Koha ou un autre script réagisse comme après une modification manuelle. Non : seule la valeur cochée/décochée est modifiée.", en: "Yes: after setting the checkbox, PMK also fires the JavaScript “change” event so Koha or another script reacts as after a manual change. No: only the checked state is changed." } }
                            ]
                        }
                    ]
                },

                {
                    type: "section",
                    id: "password",
                    label: { fr: "Mot de passe depuis le numéro de carte", en: "Password from card number" },
                    description: {
                        fr: "Par défaut : dès 4 caractères saisis dans le numéro de carte, les 4 derniers sont copiés dans Mot de passe et Confirmation du mot de passe à chaque keyup.",
                        en: "Default: once 4 characters are present in the card number, the last 4 are copied to Password and Password confirmation on every keyup."
                    },
                    fields: [
                        { key: "passwordEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "passwordScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "passwordSourceSelector",
                            type: "elementPicker",
                            label: { fr: "Champ source", en: "Source field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "passwordTrigger",
                            type: "select",
                            label: { fr: "Déclenchement", en: "Trigger" },
                            options: [
                                { value: "keyup", label: { fr: "À chaque relâchement de touche — par défaut", en: "On every keyup — default" } },
                                { value: "input", label: { fr: "Pendant la saisie", en: "While editing" } },
                                { value: "change", label: { fr: "Au changement", en: "On change" } }
                            ]
                        },
                        { key: "passwordMinSourceLength", type: "number", min: 0, step: 1, label: { fr: "Longueur minimale de la source", en: "Minimum source length" } },
                        {
                            key: "passwordExtractMode",
                            type: "select",
                            label: { fr: "Portion à copier", en: "Part to copy" },
                            refreshOnChange: true,
                            options: [
                                { value: "last", label: { fr: "Derniers caractères — par défaut", en: "Last characters — default" } },
                                { value: "first", label: { fr: "Premiers caractères", en: "First characters" } },
                                { value: "range", label: { fr: "Portion à partir d’une position", en: "Range from a position" } },
                                { value: "regex", label: { fr: "Expression régulière", en: "Regular expression" } }
                            ]
                        },
                        {
                            key: "passwordExtractLength",
                            type: "number",
                            min: 0,
                            step: 1,
                            label: { fr: "Nombre de caractères", en: "Number of characters" },
                            when: function (root) { return root && root.passwordExtractMode !== "regex"; }
                        },
                        {
                            key: "passwordExtractOffset",
                            type: "number",
                            min: 0,
                            step: 1,
                            label: { fr: "Décalage", en: "Offset" },
                            when: function (root) { return root && (root.passwordExtractMode === "last" || isPasswordRange(root) || root.passwordExtractMode === "first"); },
                            help: {
                                fr: "0 = comportement normal. En mode « derniers », le décalage retire des caractères à la fin avant l’extraction.",
                                en: "0 = normal behaviour. In last mode, offset skips characters at the end before extraction."
                            }
                        },
                        {
                            key: "passwordRegex",
                            type: "text",
                            label: { fr: "Expression régulière", en: "Regular expression" },
                            when: isPasswordRegex
                        },
                        {
                            key: "passwordRegexGroup",
                            type: "number",
                            min: 0,
                            step: 1,
                            label: { fr: "Groupe capturé à utiliser", en: "Capture group to use" },
                            when: isPasswordRegex
                        },
                        { key: "passwordOverwrite", type: "select", label: { fr: "Si la cible contient déjà une valeur", en: "If target already has a value" }, options: overwriteOptions() },
                        { key: "passwordClearWhenTooShort", type: "boolean", label: { fr: "Vider la cible si la source devient trop courte", en: "Clear target if source becomes too short" } },
                        {
                            key: "passwordTargets",
                            type: "repeater",
                            label: { fr: "Champs à remplir", en: "Fields to fill" },
                            addLabel: { fr: "Ajouter une cible", en: "Add target" },
                            reorder: true,
                            newItem: passwordTargetNew,
                            liveTitleKey: "name",
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Active", en: "Enabled" } },
                                { key: "name", type: "text", label: { fr: "Nom lisible", en: "Display name" } },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Champ cible", en: "Target field" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    allowManual: true,
                                    pick: function (context) { return pickSelector(context, "field"); }
                                }
                            ]
                        }
                    ]
                },

                {
                    type: "section",
                    id: "attribute-defaults",
                    label: { fr: "Valeurs automatiques d’attributs adhérent", en: "Automatic patron attribute values" },
                    description: {
                        fr: "Par défaut : #patron_attr_6 est positionné sur selectedIndex = 1. Le moteur accepte maintenant plusieurs attributs et plusieurs modes de valeur.",
                        en: "Default: #patron_attr_6 is set to selectedIndex = 1. The engine now supports multiple attributes and value modes."
                    },
                    fields: [
                        { key: "attributeDefaultsEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "attributeDefaultsScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "attributeDefaults",
                            type: "repeater",
                            label: { fr: "Valeurs configurées", en: "Configured values" },
                            addLabel: { fr: "Ajouter un attribut", en: "Add attribute" },
                            reorder: true,
                            newItem: attributeDefaultNew,
                            liveTitleKey: "name",
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Active", en: "Enabled" } },
                                { key: "name", type: "text", label: { fr: "Nom lisible", en: "Display name" } },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Champ / attribut Koha", en: "Koha field / attribute" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    allowManual: true,
                                    pick: function (context) { return pickSelector(context, "field"); }
                                },
                                {
                                    key: "valueMode",
                                    type: "select",
                                    label: { fr: "Comment renseigner la valeur", en: "How to set the value" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "selected-index", label: { fr: "Position dans une liste déroulante — par défaut", en: "Select option position — default" } },
                                        { value: "value", label: { fr: "Valeur du champ / option", en: "Field / option value" } },
                                        { value: "text", label: { fr: "Texte", en: "Text" } },
                                        { value: "checked", label: { fr: "Case cochée / décochée", en: "Checked / unchecked" } }
                                    ]
                                },
                                {
                                    key: "selectedIndex",
                                    type: "number",
                                    min: 0,
                                    step: 1,
                                    label: { fr: "Position (0 = premier choix)", en: "Position (0 = first option)" },
                                    when: function (root, path) { return attributeMode(root, path, "selected-index"); }
                                },
                                {
                                    key: "value",
                                    type: "text",
                                    label: { fr: "Valeur", en: "Value" },
                                    when: function (root, path) {
                                        const item = attributeItem(root, path);
                                        return Boolean(item && (item.valueMode === "value" || item.valueMode === "text"));
                                    }
                                },
                                {
                                    key: "checked",
                                    type: "boolean",
                                    label: { fr: "Cochée", en: "Checked" },
                                    when: function (root, path) { return attributeMode(root, path, "checked"); }
                                },
                                { key: "overwrite", type: "select", label: { fr: "Si le champ possède déjà une valeur", en: "If field already has a value" }, options: overwriteOptions() },
                                { key: "triggerChange", type: "boolean", label: { fr: "Déclencher aussi l’événement change", en: "Also trigger change event" } }
                            ]
                        }
                    ]
                },

                {
                    type: "section",
                    id: "userid",
                    label: { fr: "Génération de l’identifiant utilisateur", en: "User ID generation" },
                    description: {
                        fr: "Par défaut : si le champ Autres noms existe, construit prenom.nom à chaque saisie du prénom ou du nom, en retirant accents, espaces, tirets, apostrophes et parenthèses.",
                        en: "Default: if Other names exists, builds firstname.surname whenever firstname or surname changes, removing diacritics, spaces, hyphens, apostrophes and parentheses."
                    },
                    fields: [
                        { key: "useridEnabled", type: "boolean", label: { fr: "Activer cet automatisme", en: "Enable this automation" } },
                        { key: "useridScope", type: "select", label: { fr: "Quand l’appliquer", en: "When to apply" }, options: scopeOptions() },
                        {
                            key: "useridFirstnameSelector",
                            type: "elementPicker",
                            label: { fr: "Champ prénom", en: "Firstname field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "useridSurnameSelector",
                            type: "elementPicker",
                            label: { fr: "Champ nom", en: "Surname field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "useridTargetSelector",
                            type: "elementPicker",
                            label: { fr: "Champ identifiant utilisateur", en: "User ID field" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            pick: function (context) { return pickSelector(context, "field"); }
                        },
                        {
                            key: "useridRequiredPresenceSelector",
                            type: "elementPicker",
                            label: { fr: "Champ dont la présence autorise l’automatisme", en: "Field whose presence enables automation" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            allowManual: true,
                            clearable: true,
                            pick: function (context) { return pickSelector(context, "field"); },
                            help: {
                                fr: "Valeur par défaut : #othernames. Laisser vide supprime cette condition.",
                                en: "Default value: #othernames. Clear it to remove this condition."
                            }
                        },
                        {
                            key: "useridTemplate",
                            type: "text",
                            label: { fr: "Modèle de l’identifiant", en: "User ID template" },
                            help: {
                                fr: "Variables disponibles : {firstname} et {surname}. Par défaut : {firstname}.{surname}",
                                en: "Available variables: {firstname} and {surname}. Default: {firstname}.{surname}"
                            }
                        },
                        { key: "useridLowercase", type: "boolean", label: { fr: "Passer en minuscules", en: "Lowercase" } },
                        { key: "useridStripDiacritics", type: "boolean", label: { fr: "Retirer les accents", en: "Remove diacritics" } },
                        { key: "useridRemoveSpaces", type: "boolean", label: { fr: "Retirer les espaces", en: "Remove spaces" } },
                        { key: "useridRemoveHyphens", type: "boolean", label: { fr: "Retirer les tirets", en: "Remove hyphens" } },
                        { key: "useridRemoveApostrophes", type: "boolean", label: { fr: "Retirer les apostrophes", en: "Remove apostrophes" } },
                        { key: "useridRemoveParentheses", type: "boolean", label: { fr: "Retirer les parenthèses", en: "Remove parentheses" } },
                        {
                            key: "useridAdditionalRemoveRegex",
                            type: "text",
                            label: { fr: "Autres caractères à retirer (expression régulière)", en: "Other characters to remove (regular expression)" }
                        },
                        { key: "useridOverwrite", type: "select", label: { fr: "Si l’identifiant contient déjà une valeur", en: "If User ID already has a value" }, options: overwriteOptions() },
                        { key: "useridUpdateOnLoad", type: "boolean", label: { fr: "Calculer aussi à l’ouverture de la fiche", en: "Also calculate when form opens" } },
                        { key: "useridListenInput", type: "boolean", label: { fr: "Recalculer pendant la saisie — par défaut", en: "Recalculate while editing — default" } },
                        { key: "useridListenChange", type: "boolean", label: { fr: "Recalculer au changement", en: "Recalculate on change" } }
                    ]
                }
            ]
        };
    }

    function mountContextAccess() {
        const api = window.PMKConfig;
        if (!api || typeof api.mountContextButton !== "function" || !isMemberEntryPage()) return;

        let anchor =
            safeQuery("#pat_memberentrygen legend") ||
            safeQuery("#pat_memberentrygen h1") ||
            safeQuery("main h1") ||
            safeQuery("h1");

        if (!anchor) return;

        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: CONTEXT_KEY,
                context: {
                    sectionId: "information",
                    pagePath: window.location.pathname
                }
            });
        } catch (_) {}
    }

    async function loadConfig() {
        const api = window.PMKConfig;
        if (!api || typeof api.getConfig !== "function") return clone(DEFAULT_CONFIG);

        try {
            const value = await api.getConfig(MODULE_ID);
            return normalizeConfig(value || DEFAULT_CONFIG);
        } catch (_) {
            return clone(DEFAULT_CONFIG);
        }
    }

    function registerModule() {
        const api = window.PMKConfig;
        if (!api || typeof api.registerModule !== "function") return false;

        registerPickerAdapter();

        if (!registered) {
            api.registerModule(moduleDefinition());
            registered = true;
        }

        return true;
    }

    async function startWithCore() {
        if (!registerModule()) return false;

        const config = await loadConfig();
        applyConfig(config);

        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (next) {
                applyConfig(next || DEFAULT_CONFIG);
            });
        }

        return true;
    }

    function startWithoutCore() {
        applyConfig(DEFAULT_CONFIG);

        let attempts = 0;
        if (coreWaitTimer) window.clearInterval(coreWaitTimer);

        coreWaitTimer = window.setInterval(function () {
            attempts += 1;

            if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
                startWithCore();
            } else if (attempts >= 100) {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
            }
        }, 100);
    }

    function init() {
        if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
            startWithCore();
        } else {
            startWithoutCore();
        }

        /*
         * Quelques repassages très légers uniquement pour l'accès contextuel.
         * Les automatismes eux-mêmes ne sont PAS réappliqués en boucle afin
         * de ne jamais écraser une saisie utilisateur à cause d'une mutation DOM.
         */
        window.setTimeout(mountContextAccess, 400);
        window.setTimeout(mountContextAccess, 1200);
    }

    window.PMK057PatronPageUtils = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULT_CONFIG),
        normalizeConfig: normalizeConfig,
        applyConfig: applyConfig,
        stop: stopRuntime,
        detectFormMode: currentFormMode
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("057-member-pages-utils.js");
} catch (error) { window.PMKNonPlugin.errors.push("057-member-pages-utils.js: "+error.message); console.error("[PMK] 057-member-pages-utils.js",error); };
try {
/*
 Nom du fichier : 060-grenouille.js
 Modules PMK :
   - Mascotte — Grenouilles  (mascot-frogs)
   - Mascotte — Agents       (mascot-agents)

 Version : 4.1.0-pmk-split-responsive
 Date    : 2026-09-19
 Auteur  : équipe PimpMyKoha / refactorisation PimpMyKoha

 Objectif :
 - conserver strictement les deux comportements historiques du 060 ;
 - les présenter comme deux modules PMK séparés ;
 - partager un seul moteur d'insertion pour éviter toute duplication ;
 - permettre de choisir visuellement l'emplacement avec le picker commun PMK ;
 - garder les emplacements historiques comme valeurs par défaut.

 Valeurs historiques conservées :
 1) Mascotte — Grenouilles
    - emplacement : après #logo ;
    - 8 images : grenouille2.png à grenouille9.png ;
    - clic sur l'image : joue un son aléatoire ;
    - 6 sons : SFB-frogs1.mp3 à SFB-frogs6.mp3.

 2) Mascotte — Agents
    - emplacement : au début de #header_search ;
    - 25 images : grenouilles1.png à grenouilles25.png ;
    - 25 noms historiques conservés ;
    - hauteur : 45 px ;
    - largeur : auto ;
    - le nom est affiché dans title au survol.

 Dépendance recommandée :
 - 000-pmk-config-firestore.js v0.4.43 ou ultérieur.
 - Le script reste fonctionnel avec ses valeurs historiques si le socle PMK
   n'est pas encore chargé.
*/

(function () {
    "use strict";

    const SCRIPT_GUARD = "__pmk060MascotsSplitV4";
    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const VERSION = "4.1.0-pmk-split-responsive";
    const BASE_URL = "";

    const FROG_MODULE_ID = "mascot-frogs";
    const AGENT_MODULE_ID = "mascot-agents";

    const ATTR_GENERATED = "data-pmk-060-mascot";
    const ATTR_MODULE = "data-pmk-060-module";

    const AGENT_NAMES = Array.from({length:25},(_,i)=>"Mascotte "+(i+1));

    const FROG_DEFAULTS = {
        enabled: false,
        pages: "*",
        locationSelector: "#logo",
        locationName: "Logo Koha",
        position: "after",
        altFr: "Grenouille",
        altEn: "Frog",
        imageHeight: 0,
        imageWidth: 0,
        responsiveEnabled: true,
        responsiveHideBelowPx: 640,
        responsiveFullSizeAtPx: 1100,
        responsiveMinScale: 0.65,
        soundEnabled: true,
        respectReducedMotion: true,
        images: Array.from({ length: 8 }, function (_, i) {
            const n = i + 2;
            return {
                id: "grenouille-" + n,
                enabled: true,
                name: "Grenouille " + n,
                url: BASE_URL + "grenouille" + n + ".png"
            };
        }),
        sounds: Array.from({ length: 6 }, function (_, i) {
            const n = i + 1;
            return {
                id: "frog-sound-" + n,
                enabled: true,
                name: "Son grenouille " + n,
                url: BASE_URL + "SFB-frogs" + n + ".mp3"
            };
        })
    };

    const AGENT_DEFAULTS = {
        enabled: false,
        pages: "*",
        locationSelector: "#header_search",
        locationName: "Barre de recherche Koha",
        position: "inside-start",
        altFr: "Grenouille",
        altEn: "Frog",
        imageHeight: 45,
        imageWidth: 0,
        responsiveEnabled: true,
        responsiveHideBelowPx: 640,
        responsiveFullSizeAtPx: 1100,
        responsiveMinScale: 0.65,
        showNameOnHover: true,
        images: AGENT_NAMES.map(function (name, i) {
            const n = i + 1;
            return {
                id: "agent-" + n,
                enabled: true,
                name: name,
                url: BASE_URL + "grenouilles" + n + ".png"
            };
        })
    };

    const states = {
        [FROG_MODULE_ID]: {
            config: clone(FROG_DEFAULTS),
            selectedImageId: "",
            selectedImageUrl: "",
            observer: null,
            applyTimer: null,
            unsubscribe: null,
            registered: false
        },
        [AGENT_MODULE_ID]: {
            config: clone(AGENT_DEFAULTS),
            selectedImageId: "",
            selectedImageUrl: "",
            observer: null,
            applyTimer: null,
            unsubscribe: null,
            registered: false
        }
    };

    let coreWaitTimer = null;
    let activeAudio = null;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)");

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function asBool(value, fallback) {
        if (value === undefined || value === null) return fallback;
        return value !== false;
    }

    function asNumber(value, fallback, min, max) {
        let n = Number(value);
        if (!Number.isFinite(n)) n = fallback;
        if (Number.isFinite(min)) n = Math.max(min, n);
        if (Number.isFinite(max)) n = Math.min(max, n);
        return n;
    }

    function language() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                const lang = clean(window.PMKConfig.getLanguage()).toLowerCase();
                if (lang.startsWith("en")) return "en";
                if (lang.startsWith("fr")) return "fr";
            }
        } catch (_) {}
        const htmlLang = clean(document.documentElement.getAttribute("lang")).toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function normalizePages(value) {
        if (Array.isArray(value)) return value.map(clean).filter(Boolean);
        return String(value == null ? "*" : value)
            .split(/[\n,;]+/)
            .map(clean)
            .filter(Boolean);
    }

    function pageMatches(config) {
        const patterns = normalizePages(config && config.pages);
        if (!patterns.length) return false;
        const path = window.location.pathname;
        return patterns.some(function (pattern) {
            if (pattern === "*" || pattern.toLowerCase() === "all") return true;
            if (pattern.endsWith("*")) return path.startsWith(pattern.slice(0, -1));
            return path === pattern;
        });
    }

    function normalizeImage(item, fallback, index, prefix) {
        const src = item && typeof item === "object" ? item : {};
        const fb = fallback && typeof fallback === "object" ? fallback : {};
        return {
            id: clean(src.id) || clean(fb.id) || prefix + "-" + (index + 1),
            enabled: src.enabled !== false,
            name: Object.prototype.hasOwnProperty.call(src, "name") ? String(src.name || "") : String(fb.name || ""),
            url: Object.prototype.hasOwnProperty.call(src, "url") ? clean(src.url) : clean(fb.url)
        };
    }

    function normalizeImages(raw, fallback, prefix) {
        if (!Array.isArray(raw)) return clone(fallback);
        return raw.map(function (item, index) {
            return normalizeImage(item, fallback[index], index, prefix);
        });
    }

    function normalizeSound(item, fallback, index) {
        const src = item && typeof item === "object" ? item : {};
        const fb = fallback && typeof fallback === "object" ? fallback : {};
        return {
            id: clean(src.id) || clean(fb.id) || "sound-" + (index + 1),
            enabled: src.enabled !== false,
            name: Object.prototype.hasOwnProperty.call(src, "name") ? String(src.name || "") : String(fb.name || ""),
            url: Object.prototype.hasOwnProperty.call(src, "url") ? clean(src.url) : clean(fb.url)
        };
    }

    function normalizeFrogConfig(raw) {
        const src = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: src.enabled !== false,
            pages: Object.prototype.hasOwnProperty.call(src, "pages") ? String(src.pages || "") : FROG_DEFAULTS.pages,
            locationSelector: clean(src.locationSelector) || FROG_DEFAULTS.locationSelector,
            locationName: Object.prototype.hasOwnProperty.call(src, "locationName") ? String(src.locationName || "") : FROG_DEFAULTS.locationName,
            position: ["before", "after", "inside-start", "inside-end"].includes(src.position) ? src.position : FROG_DEFAULTS.position,
            altFr: Object.prototype.hasOwnProperty.call(src, "altFr") ? String(src.altFr || "") : FROG_DEFAULTS.altFr,
            altEn: Object.prototype.hasOwnProperty.call(src, "altEn") ? String(src.altEn || "") : FROG_DEFAULTS.altEn,
            imageHeight: asNumber(src.imageHeight, FROG_DEFAULTS.imageHeight, 0, 1000),
            imageWidth: asNumber(src.imageWidth, FROG_DEFAULTS.imageWidth, 0, 1000),
            responsiveEnabled: src.responsiveEnabled !== false,
            responsiveHideBelowPx: asNumber(src.responsiveHideBelowPx, FROG_DEFAULTS.responsiveHideBelowPx, 320, 1200),
            responsiveFullSizeAtPx: asNumber(src.responsiveFullSizeAtPx, FROG_DEFAULTS.responsiveFullSizeAtPx, 641, 2500),
            responsiveMinScale: asNumber(src.responsiveMinScale, FROG_DEFAULTS.responsiveMinScale, 0.25, 1),
            soundEnabled: src.soundEnabled !== false,
            respectReducedMotion: src.respectReducedMotion !== false,
            images: normalizeImages(src.images, FROG_DEFAULTS.images, "grenouille"),
            sounds: Array.isArray(src.sounds)
                ? src.sounds.map(function (item, index) { return normalizeSound(item, FROG_DEFAULTS.sounds[index], index); })
                : clone(FROG_DEFAULTS.sounds)
        };
    }

    function normalizeAgentConfig(raw) {
        const src = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: src.enabled !== false,
            pages: Object.prototype.hasOwnProperty.call(src, "pages") ? String(src.pages || "") : AGENT_DEFAULTS.pages,
            locationSelector: clean(src.locationSelector) || AGENT_DEFAULTS.locationSelector,
            locationName: Object.prototype.hasOwnProperty.call(src, "locationName") ? String(src.locationName || "") : AGENT_DEFAULTS.locationName,
            position: ["before", "after", "inside-start", "inside-end"].includes(src.position) ? src.position : AGENT_DEFAULTS.position,
            altFr: Object.prototype.hasOwnProperty.call(src, "altFr") ? String(src.altFr || "") : AGENT_DEFAULTS.altFr,
            altEn: Object.prototype.hasOwnProperty.call(src, "altEn") ? String(src.altEn || "") : AGENT_DEFAULTS.altEn,
            imageHeight: asNumber(src.imageHeight, AGENT_DEFAULTS.imageHeight, 0, 1000),
            imageWidth: asNumber(src.imageWidth, AGENT_DEFAULTS.imageWidth, 0, 1000),
            responsiveEnabled: src.responsiveEnabled !== false,
            responsiveHideBelowPx: asNumber(src.responsiveHideBelowPx, AGENT_DEFAULTS.responsiveHideBelowPx, 320, 1200),
            responsiveFullSizeAtPx: asNumber(src.responsiveFullSizeAtPx, AGENT_DEFAULTS.responsiveFullSizeAtPx, 641, 2500),
            responsiveMinScale: asNumber(src.responsiveMinScale, AGENT_DEFAULTS.responsiveMinScale, 0.25, 1),
            showNameOnHover: src.showNameOnHover !== false,
            images: normalizeImages(src.images, AGENT_DEFAULTS.images, "agent")
        };
    }

    function normalizeFor(moduleId, raw) {
        return moduleId === FROG_MODULE_ID ? normalizeFrogConfig(raw) : normalizeAgentConfig(raw);
    }

    function activeItems(items) {
        return (Array.isArray(items) ? items : []).filter(function (item) {
            return item && item.enabled !== false && clean(item.url);
        });
    }

    function randomItem(items) {
        const list = activeItems(items);
        if (!list.length) return null;
        return list[Math.floor(Math.random() * list.length)];
    }

    function safeQuery(selector) {
        const value = clean(selector);
        if (!value) return null;
        try { return document.querySelector(value); } catch (_) { return null; }
    }

    function generatedSelector(moduleId) {
        return "[" + ATTR_GENERATED + "=\"1\"][" + ATTR_MODULE + "=\"" + moduleId + "\"]";
    }

    function currentGenerated(moduleId) {
        return document.querySelector(generatedSelector(moduleId));
    }

    function removeGenerated(moduleId) {
        if (moduleId === FROG_MODULE_ID) stopFrogSound();
        document.querySelectorAll(generatedSelector(moduleId)).forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });
    }

    function resetSelection(moduleId) {
        const state = states[moduleId];
        if (!state) return;
        state.selectedImageId = "";
        state.selectedImageUrl = "";
    }

    function selectedImage(moduleId, config) {
        const state = states[moduleId];
        if (!state) return null;

        const available = activeItems(config.images);
        if (!available.length) {
            resetSelection(moduleId);
            return null;
        }

        const existing = available.find(function (item) {
            return (state.selectedImageId && item.id === state.selectedImageId) ||
                   (state.selectedImageUrl && clean(item.url) === state.selectedImageUrl);
        });

        if (existing) return existing;

        const picked = available[Math.floor(Math.random() * available.length)];
        state.selectedImageId = clean(picked.id);
        state.selectedImageUrl = clean(picked.url);
        return picked;
    }

    function imageAlt(moduleId, config, item) {
        const configured = language() === "en" ? clean(config.altEn) : clean(config.altFr);
        if (configured) return configured;
        if (moduleId === AGENT_MODULE_ID && config.showNameOnHover !== false && item && clean(item.name)) return clean(item.name);
        return moduleId === FROG_MODULE_ID ? t("Grenouille", "Frog") : t("Mascotte agent", "Staff mascot");
    }

    function applyDimensions(img, config) {
        if (!img) return;
        const h = Number(config.imageHeight);
        const w = Number(config.imageWidth);
        const responsive = config.responsiveEnabled !== false;
        const hideBelow = Number(config.responsiveHideBelowPx) || 640;
        const fullAt = Math.max(hideBelow + 1, Number(config.responsiveFullSizeAtPx) || 1100);
        const minScale = Math.max(0.25, Math.min(1, Number(config.responsiveMinScale) || 0.65));
        const viewport = Math.max(0, window.innerWidth || document.documentElement.clientWidth || fullAt);

        if (responsive && viewport <= hideBelow) {
            img.style.display = "none";
            return;
        }
        img.style.removeProperty("display");

        let scale = 1;
        if (responsive && viewport < fullAt) {
            const progress = (viewport - hideBelow) / (fullAt - hideBelow);
            scale = minScale + Math.max(0, Math.min(1, progress)) * (1 - minScale);
        }

        if (Number.isFinite(h) && h > 0) img.style.height = Math.max(1, Math.round(h * scale)) + "px";
        else {
            img.style.removeProperty("height");
            img.style.maxHeight = responsive ? Math.round(100 * scale) + "%" : "";
        }

        if (Number.isFinite(w) && w > 0) img.style.width = Math.max(1, Math.round(w * scale)) + "px";
        else if (Number.isFinite(h) && h > 0) img.style.width = "auto";
        else {
            img.style.removeProperty("width");
            img.style.transformOrigin = "center center";
            img.style.transform = responsive && scale < 0.999 ? "scale(" + scale.toFixed(3) + ")" : "";
        }
    }

    function insertAt(target, node, position) {
        if (!target || !node) return false;
        try {
            if (position === "before") {
                if (!target.parentNode) return false;
                target.parentNode.insertBefore(node, target);
                return true;
            }
            if (position === "after") {
                if (!target.parentNode) return false;
                target.parentNode.insertBefore(node, target.nextSibling);
                return true;
            }
            if (position === "inside-end") {
                target.appendChild(node);
                return true;
            }
            target.insertBefore(node, target.firstChild);
            return true;
        } catch (_) {
            return false;
        }
    }

    function stopFrogSound() {
        if (activeAudio) { activeAudio.pause(); activeAudio = null; }
    }

    function soundAvailable(config) {
        return !!config && config.enabled !== false && config.soundEnabled !== false &&
            !(config?.respectReducedMotion !== false && reducedMotion?.matches);
    }

    function updateSoundControl(img, config) {
        const active = soundAvailable(config);
        img.style.cursor = active ? 'pointer' : '';
        if (active) {
            img.setAttribute('role', 'button'); img.tabIndex = 0;
            img.setAttribute('aria-label', imageAlt(FROG_MODULE_ID, config) + ' — ' + t('Jouer un son', 'Play a sound'));
        } else {
            img.removeAttribute('role'); img.removeAttribute('tabindex'); img.removeAttribute('aria-label');
            stopFrogSound();
        }
    }

    function playRandomFrogSound() {
        const cfg = states[FROG_MODULE_ID].config;
        if (!soundAvailable(cfg)) return;
        const sound = randomItem(cfg.sounds);
        if (!sound || !clean(sound.url)) return;

        try {
            stopFrogSound();
            const audio = new Audio();
            audio.preload = "none"; audio.src = clean(sound.url); activeAudio = audio;
            const promise = audio.play();
            if (promise && typeof promise.catch === "function") promise.catch(function () {});
        } catch (_) {}
    }

    function buildMascot(moduleId, config, item) {
        const img = document.createElement("img");
        img.setAttribute(ATTR_GENERATED, "1");
        img.setAttribute(ATTR_MODULE, moduleId);
        img.loading = "lazy";
        img.src = clean(item.url);
        img.alt = imageAlt(moduleId, config, item);
        img.decoding = "async";

        applyDimensions(img, config);

        if (moduleId === FROG_MODULE_ID) {
            img.id = "grenouille-logo-060";
            updateSoundControl(img, config);
            img.addEventListener("click", playRandomFrogSound);
            img.addEventListener('keydown', function (event) {
                if (!event.repeat && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); playRandomFrogSound(); }
            });
        } else {
            img.id = "grenouille-header-060";
            if (config.showNameOnHover !== false && clean(item.name)) {
                img.title = clean(item.name);
            }
        }

        return img;
    }

    function moduleShouldRun(moduleId, config) {
        return Boolean(config && config.enabled !== false && pageMatches(config) &&
            !(moduleId === FROG_MODULE_ID && config.respectReducedMotion !== false && reducedMotion?.matches));
    }

    function applyModule(moduleId) {
        const state = states[moduleId];
        if (!state) return;

        const config = state.config;
        const existing = currentGenerated(moduleId);

        if (!moduleShouldRun(moduleId, config)) {
            if (existing) removeGenerated(moduleId);
            return;
        }

        const target = safeQuery(config.locationSelector);
        if (!target) {
            if (existing && !existing.isConnected) removeGenerated(moduleId);
            return;
        }

        const item = selectedImage(moduleId, config);
        if (!item) {
            removeGenerated(moduleId);
            return;
        }

        if (existing && existing.isConnected) {
            const sameUrl = clean(existing.getAttribute("src")) === clean(item.url) ||
                (() => {
                    try {
                        return new URL(existing.src, window.location.origin).href === new URL(item.url, window.location.origin).href;
                    } catch (_) {
                        return false;
                    }
                })();

            if (sameUrl) {
                existing.alt = imageAlt(moduleId, config, item);
                applyDimensions(existing, config);

                if (moduleId === FROG_MODULE_ID) {
                    updateSoundControl(existing, config);
                } else if (config.showNameOnHover !== false && clean(item.name)) {
                    existing.title = clean(item.name);
                } else {
                    existing.removeAttribute("title");
                }

                return;
            }
        }

        removeGenerated(moduleId);
        const img = buildMascot(moduleId, config, item);
        insertAt(target, img, config.position);
    }

    function scheduleApply(moduleId) {
        const state = states[moduleId];
        if (!state) return;
        if (state.applyTimer) window.clearTimeout(state.applyTimer);
        state.applyTimer = window.setTimeout(function () {
            state.applyTimer = null;
            applyModule(moduleId);
            mountContextButton(moduleId);
        }, 40);
    }

    function applyConfig(moduleId, config, options) {
        const state = states[moduleId];
        if (!state) return;
        state.config = normalizeFor(moduleId, config);

        if (!options || options.resetSelection !== false) {
            resetSelection(moduleId);
        }

        scheduleApply(moduleId);
    }

    function startObserver(moduleId) {
        const state = states[moduleId];
        if (!state || state.observer) return;

        state.observer = new MutationObserver(function (mutations) {
            let relevant = false;
            for (const mutation of mutations) {
                if (mutation.type !== "childList") continue;

                const changedGenerated = Array.from(mutation.addedNodes || []).concat(Array.from(mutation.removedNodes || []))
                    .some(function (node) {
                        return node && node.nodeType === 1 &&
                            ((node.matches && node.matches(generatedSelector(moduleId))) ||
                             (node.querySelector && node.querySelector(generatedSelector(moduleId))));
                    });

                if (!changedGenerated) {
                    relevant = true;
                    break;
                }
            }
            if (relevant) scheduleApply(moduleId);
        });

        state.observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }

    function targetNameFromCandidate(candidate) {
        if (!candidate || candidate.nodeType !== 1) return "";
        return clean(candidate.getAttribute("aria-label")) ||
            clean(candidate.getAttribute("title")) ||
            clean(candidate.textContent).slice(0, 100) ||
            candidate.id ||
            candidate.tagName.toLowerCase();
    }

    function pickerFor(moduleId, context) {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }

        return picker.pickForConfig({
            moduleId: moduleId,
            targetUrl: window.location.pathname + window.location.search,
            rootObject: context && context.rootObject ? context.rootObject : {},
            fieldPath: context && Array.isArray(context.fieldPath) ? context.fieldPath.slice() : [],
            persistAfterPick: false,
            adminContext: {
                sectionId: "placement"
            },
            options: {
                bannerText: t(
                    "Clique sur l’emplacement de la mascotte — Échap annule",
                    "Click the mascot location — Esc cancels"
                )
            }
        });
    }

    function onLocationPick(rootObject, fieldPath, result) {
        if (!rootObject || !result) return;
        rootObject.locationName = String(result.targetName || result.selector || "");
    }

    function registerPickerAdapter(moduleId) {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return false;

        picker.register(moduleId, {
            buildResult: function (candidate, result) {
                result.targetName = targetNameFromCandidate(candidate);
                return result;
            },
            applyPending: function (draft, pending, picked) {
                if (draft && picked) draft.locationName = String(picked.targetName || picked.selector || "");
                return draft;
            }
        });

        return true;
    }

    function newFrogImage() {
        return {
            id: "grenouille-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6),
            enabled: true,
            name: "",
            url: ""
        };
    }

    function newAgentImage() {
        return {
            id: "agent-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6),
            enabled: true,
            name: "",
            url: ""
        };
    }

    function newSound() {
        return {
            id: "frog-sound-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6),
            enabled: true,
            name: "",
            url: ""
        };
    }

    function itemTitle(item, index, lang, fallbackFr, fallbackEn) {
        const name = clean(item && item.name);
        if (name) return name;
        const n = index + 1;
        return lang === "en" ? fallbackEn + " " + n : fallbackFr + " " + n;
    }

    function commonPlacementFields(moduleId, defaultDescriptionFr, defaultDescriptionEn) {
        return [
            {
                key: "pages",
                type: "textarea",
                rows: 2,
                label: { fr: "Pages Koha concernées", en: "Koha pages" },
                help: {
                    fr: "Par défaut « * » : la mascotte s’affiche partout où son emplacement existe. Une page par ligne si tu veux limiter son périmètre.",
                    en: "Default “*”: the mascot appears wherever its target exists. Use one path per line to restrict its scope."
                }
            },
            {
                key: "locationSelector",
                type: "elementPicker",
                label: { fr: "Emplacement", en: "Location" },
                pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                emptyLabel: { fr: "Aucun emplacement sélectionné", en: "No location selected" },
                allowManual: true,
                pick: function (context) { return pickerFor(moduleId, context); },
                onPick: onLocationPick,
                help: {
                    fr: defaultDescriptionFr,
                    en: defaultDescriptionEn
                }
            },
            {
                key: "locationName",
                type: "readonly",
                advanced: true,
                label: { fr: "Emplacement détecté", en: "Detected location" }
            },
            {
                key: "position",
                type: "select",
                label: { fr: "Position dans l’emplacement", en: "Position at location" },
                options: [
                    { value: "before", label: { fr: "Avant l’élément choisi", en: "Before selected element" } },
                    { value: "after", label: { fr: "Après l’élément choisi", en: "After selected element" } },
                    { value: "inside-start", label: { fr: "À l’intérieur, au début", en: "Inside, at start" } },
                    { value: "inside-end", label: { fr: "À l’intérieur, à la fin", en: "Inside, at end" } }
                ]
            }
        ];
    }

    function validateCommon(config, kindLabel) {
        const errors = [];
        if (!clean(config.locationSelector)) {
            errors.push(kindLabel + " : emplacement manquant.");
        }

        const ids = new Set();
        (config.images || []).forEach(function (item, index) {
            if (!item || item.enabled === false) return;
            const id = clean(item.id);
            if (!id) errors.push(kindLabel + " : image " + (index + 1) + " sans identifiant.");
            else if (ids.has(id)) errors.push(kindLabel + " : identifiant d’image dupliqué : " + id);
            else ids.add(id);
            if (!clean(item.url)) errors.push(kindLabel + " : image active " + (index + 1) + " sans URL.");
        });

        return errors;
    }

    function validateFrogs(config) {
        const cfg = normalizeFrogConfig(config);
        const errors = validateCommon(cfg, "Mascotte grenouilles");

        const soundIds = new Set();
        (cfg.sounds || []).forEach(function (item, index) {
            if (!item || item.enabled === false) return;
            const id = clean(item.id);
            if (!id) errors.push("Mascotte grenouilles : son " + (index + 1) + " sans identifiant.");
            else if (soundIds.has(id)) errors.push("Mascotte grenouilles : identifiant de son dupliqué : " + id);
            else soundIds.add(id);
            if (!clean(item.url)) errors.push("Mascotte grenouilles : son actif " + (index + 1) + " sans URL.");
        });

        return errors;
    }

    function validateAgents(config) {
        return validateCommon(normalizeAgentConfig(config), "Mascotte agents");
    }

    function frogDefinition() {
        return {
            id: FROG_MODULE_ID,
            schemaVersion: 1,
            name: { fr: "Mascotte — Grenouilles", en: "Mascot — Frogs" },
            description: {
                fr: "Affiche aléatoirement une grenouille dans l’interface Koha et peut jouer un son au clic. Les huit images et les six sons historiques du 060 sont conservés par défaut.",
                en: "Randomly displays a frog in Koha and can play a sound on click. The eight historical images and six sounds from script 060 are preserved by default."
            },
            category: { fr: "Interface / ambiance", en: "Interface / ambience" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(FROG_DEFAULTS),
            normalize: normalizeFrogConfig,
            validate: validateFrogs,
            schema: [
                {
                    type: "section",
                    id: "general",
                    label: { fr: "Fonctionnement", en: "Behaviour" },
                    description: {
                        fr: "Le préréglage reproduit strictement le comportement historique : une image choisie parmi grenouille2.png à grenouille9.png est insérée après le logo Koha ; un clic joue aléatoirement l’un des six sons SFB-frogs1.mp3 à SFB-frogs6.mp3.",
                        en: "The preset strictly reproduces the historical behaviour: one image from grenouille2.png to grenouille9.png is inserted after the Koha logo; clicking it randomly plays one of the six SFB-frogs1.mp3 to SFB-frogs6.mp3 sounds."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Module actif", en: "Module enabled" } },
                        { key: "soundEnabled", type: "boolean", label: { fr: "Jouer un son au clic ou au clavier", en: "Play sound on click or keyboard activation" } },
                        { key: "respectReducedMotion", type: "boolean", label: { fr: "Masquer la mascotte et couper son son lorsque le navigateur demande moins d’animations", en: "Hide the mascot and mute its sound when reduced motion is requested" } }
                    ]
                },
                {
                    type: "section",
                    id: "placement",
                    label: { fr: "Emplacement", en: "Location" },
                    description: {
                        fr: "L’emplacement historique reste sélectionné par défaut. Le bouton « Choisir sur la page » permet d’utiliser le moteur de pick commun PMK sans avoir à connaître un sélecteur CSS.",
                        en: "The historical location remains selected by default. “Choose on page” uses the shared PMK picker without requiring CSS selector knowledge."
                    },
                    fields: commonPlacementFields(
                        FROG_MODULE_ID,
                        "Valeur historique : #logo, avec insertion après le logo.",
                        "Historical value: #logo, inserted after the logo."
                    )
                },
                {
                    type: "section",
                    id: "appearance",
                    label: { fr: "Affichage", en: "Display" },
                    fields: [
                        {
                            key: "imageHeight",
                            type: "number",
                            min: 0,
                            max: 1000,
                            label: { fr: "Hauteur forcée (px)", en: "Forced height (px)" },
                            help: {
                                fr: "0 = taille naturelle, comme dans le 060 historique.",
                                en: "0 = natural size, matching the historical 060."
                            }
                        },
                        {
                            key: "imageWidth",
                            type: "number",
                            min: 0,
                            max: 1000,
                            label: { fr: "Largeur forcée (px)", en: "Forced width (px)" },
                            help: { fr: "0 = largeur naturelle.", en: "0 = natural width." }
                        },
                        { key: "responsiveEnabled", type: "boolean", label: { fr: "Adapter la taille à l’écran", en: "Scale with screen size" } },
                        { key: "responsiveHideBelowPx", type: "number", min: 320, max: 1200, label: { fr: "Masquer sous cette largeur (px)", en: "Hide below this width (px)" }, help: { fr: "Valeur par défaut : 640 px. Les mascottes sont entièrement masquées sur petit écran/mobile.", en: "Default: 640 px. Mascots are fully hidden on small/mobile screens." } },
                        { key: "responsiveFullSizeAtPx", type: "number", min: 641, max: 2500, label: { fr: "Taille historique atteinte à partir de (px)", en: "Reach historical size from (px)" }, help: { fr: "La taille diminue progressivement entre le seuil mobile et cette largeur.", en: "Size decreases progressively between the mobile threshold and this width." } },
                        { key: "responsiveMinScale", type: "number", min: 0.25, max: 1, step: 0.05, label: { fr: "Échelle minimale avant masquage", en: "Minimum scale before hiding" } },
                        { key: "altFr", type: "text", label: { fr: "Texte alternatif français", en: "French alt text" } },
                        { key: "altEn", type: "text", label: { fr: "Texte alternatif anglais", en: "English alt text" } }
                    ]
                },
                {
                    type: "section",
                    id: "images",
                    label: { fr: "Grenouilles", en: "Frogs" },
                    description: {
                        fr: "Les huit URL historiques sont préchargées. Tu peux en ajouter, en retirer ou en désactiver sans limite arbitraire.",
                        en: "The eight historical URLs are preloaded. You may add, remove or disable entries without an arbitrary limit."
                    },
                    fields: [
                        {
                            key: "images",
                            type: "repeater",
                            label: { fr: "Images disponibles", en: "Available images" },
                            addLabel: { fr: "Ajouter une grenouille", en: "Add a frog" },
                            reorder: true,
                            removable: true,
                            newItem: newFrogImage,
                            itemTitle: function (item, index, lang) {
                                return itemTitle(item, index, lang, "Grenouille", "Frog");
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Image active", en: "Image enabled" } },
                                { key: "name", type: "text", label: { fr: "Nom", en: "Name" } },
                                { key: "url", type: "text", label: { fr: "URL de l’image", en: "Image URL" } },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant", en: "Identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "sounds",
                    label: { fr: "Sons", en: "Sounds" },
                    description: {
                        fr: "Les six sons historiques sont préchargés et restent tous actifs par défaut.",
                        en: "The six historical sounds are preloaded and all remain enabled by default."
                    },
                    fields: [
                        {
                            key: "sounds",
                            type: "repeater",
                            label: { fr: "Sons disponibles", en: "Available sounds" },
                            addLabel: { fr: "Ajouter un son", en: "Add a sound" },
                            reorder: true,
                            removable: true,
                            newItem: newSound,
                            itemTitle: function (item, index, lang) {
                                return itemTitle(item, index, lang, "Son", "Sound");
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Son actif", en: "Sound enabled" } },
                                { key: "name", type: "text", label: { fr: "Nom", en: "Name" } },
                                { key: "url", type: "text", label: { fr: "URL du son", en: "Sound URL" } },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant", en: "Identifier" } }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function agentDefinition() {
        return {
            id: AGENT_MODULE_ID,
            schemaVersion: 1,
            name: { fr: "Mascotte — Agents", en: "Mascot — Staff" },
            description: {
                fr: "Affiche aléatoirement une mascotte agent dans la barre de recherche Koha. Les 25 images, les 25 noms et la hauteur historique de 45 px sont conservés par défaut.",
                en: "Randomly displays a staff mascot in the Koha search header. The 25 images and historical 45 px height are preserved by default."
            },
            category: { fr: "Interface / ambiance", en: "Interface / ambience" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(AGENT_DEFAULTS),
            normalize: normalizeAgentConfig,
            validate: validateAgents,
            schema: [
                {
                    type: "section",
                    id: "general",
                    label: { fr: "Fonctionnement", en: "Behaviour" },
                    description: {
                        fr: "Le préréglage reproduit strictement le comportement historique : une image choisie parmi grenouilles1.png à grenouilles25.png est insérée au début de #header_search, avec son nom historique en infobulle et une hauteur de 45 px.",
                        en: "The preset strictly reproduces the historical behaviour: one image from grenouilles1.png to grenouilles25.png is inserted at the start of #header_search, with its historical name as a tooltip and a height of 45 px."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Module actif", en: "Module enabled" } },
                        { key: "showNameOnHover", type: "boolean", label: { fr: "Afficher le nom au survol et aux lecteurs d’écran", en: "Expose the name on hover and to screen readers" } }
                    ]
                },
                {
                    type: "section",
                    id: "placement",
                    label: { fr: "Emplacement", en: "Location" },
                    description: {
                        fr: "L’emplacement historique reste sélectionné par défaut. Le picker commun permet de choisir un autre élément Koha.",
                        en: "The historical location remains selected by default. The shared picker can select another Koha element."
                    },
                    fields: commonPlacementFields(
                        AGENT_MODULE_ID,
                        "Valeur historique : #header_search, avec insertion à l’intérieur au début.",
                        "Historical value: #header_search, inserted inside at the start."
                    )
                },
                {
                    type: "section",
                    id: "appearance",
                    label: { fr: "Affichage", en: "Display" },
                    fields: [
                        {
                            key: "imageHeight",
                            type: "number",
                            min: 0,
                            max: 1000,
                            label: { fr: "Hauteur (px)", en: "Height (px)" },
                            help: {
                                fr: "Valeur historique : 45 px. 0 = taille naturelle.",
                                en: "Historical value: 45 px. 0 = natural size."
                            }
                        },
                        {
                            key: "imageWidth",
                            type: "number",
                            min: 0,
                            max: 1000,
                            label: { fr: "Largeur forcée (px)", en: "Forced width (px)" },
                            help: {
                                fr: "0 = largeur automatique, comportement historique.",
                                en: "0 = automatic width, matching historical behaviour."
                            }
                        },
                        { key: "responsiveEnabled", type: "boolean", label: { fr: "Adapter la taille à l’écran", en: "Scale with screen size" } },
                        { key: "responsiveHideBelowPx", type: "number", min: 320, max: 1200, label: { fr: "Masquer sous cette largeur (px)", en: "Hide below this width (px)" }, help: { fr: "Valeur par défaut : 640 px. Les mascottes sont entièrement masquées sur petit écran/mobile.", en: "Default: 640 px. Mascots are fully hidden on small/mobile screens." } },
                        { key: "responsiveFullSizeAtPx", type: "number", min: 641, max: 2500, label: { fr: "Taille historique atteinte à partir de (px)", en: "Reach historical size from (px)" } },
                        { key: "responsiveMinScale", type: "number", min: 0.25, max: 1, step: 0.05, label: { fr: "Échelle minimale avant masquage", en: "Minimum scale before hiding" } },
                        { key: "altFr", type: "text", label: { fr: "Texte alternatif français", en: "French alt text" } },
                        { key: "altEn", type: "text", label: { fr: "Texte alternatif anglais", en: "English alt text" } }
                    ]
                },
                {
                    type: "section",
                    id: "agents",
                    label: { fr: "Mascottes agents", en: "Staff mascots" },
                    description: {
                        fr: "Les 25 couples image/nom historiques sont préchargés. Le nom reste attaché à son image : supprimer ou déplacer une ligne ne peut donc plus décaler les correspondances.",
                        en: "The 25 historical image/name pairs are preloaded. Each name stays attached to its image, so removing or moving a row cannot shift the mapping."
                    },
                    fields: [
                        {
                            key: "images",
                            type: "repeater",
                            label: { fr: "Agents disponibles", en: "Available staff mascots" },
                            addLabel: { fr: "Ajouter une mascotte agent", en: "Add a staff mascot" },
                            reorder: true,
                            removable: true,
                            newItem: newAgentImage,
                            itemTitle: function (item, index, lang) {
                                return itemTitle(item, index, lang, "Agent", "Staff mascot");
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Mascotte active", en: "Mascot enabled" } },
                                { key: "name", type: "text", label: { fr: "Nom de l’agent", en: "Staff name" } },
                                { key: "url", type: "text", label: { fr: "URL de l’image", en: "Image URL" } },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant", en: "Identifier" } }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function contextAnchor(moduleId) {
        const generated = currentGenerated(moduleId);
        if (generated && generated.isConnected) return generated;

        const cfg = states[moduleId] && states[moduleId].config;
        if (cfg) {
            const target = safeQuery(cfg.locationSelector);
            if (target) return target;
        }
        return null;
    }

    function mountContextButton(moduleId) {
        const api = window.PMKConfig;
        if (!api || typeof api.mountContextButton !== "function") return;

        const anchor = contextAnchor(moduleId);
        if (!anchor) return;

        try {
            api.mountContextButton({
                moduleId: moduleId,
                anchor: anchor,
                position: "after",
                contextKey: "060-" + moduleId + "-" + window.location.pathname,
                context: { sectionId: "placement" }
            });
        } catch (_) {}
    }

    async function loadModuleConfig(moduleId) {
        const api = window.PMKConfig;
        const defaults = moduleId === FROG_MODULE_ID ? FROG_DEFAULTS : AGENT_DEFAULTS;
        if (!api || typeof api.getConfig !== "function") return clone(defaults);

        try {
            const value = await api.getConfig(moduleId);
            return normalizeFor(moduleId, value || defaults);
        } catch (_) {
            return clone(defaults);
        }
    }

    function definitionFor(moduleId) {
        return moduleId === FROG_MODULE_ID ? frogDefinition() : agentDefinition();
    }

    function registerModule(moduleId) {
        const api = window.PMKConfig;
        if (!api || typeof api.registerModule !== "function") return false;

        const state = states[moduleId];
        if (!state) return false;

        registerPickerAdapter(moduleId);

        if (!state.registered) {
            api.registerModule(definitionFor(moduleId));
            state.registered = true;
        }
        return true;
    }

    async function startModuleWithCore(moduleId) {
        if (!registerModule(moduleId)) return false;

        const state = states[moduleId];
        const cfg = await loadModuleConfig(moduleId);
        applyConfig(moduleId, cfg, { resetSelection: true });
        startObserver(moduleId);
        mountContextButton(moduleId);

        if (!state.unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            state.unsubscribe = window.PMKConfig.subscribe(moduleId, function (next) {
                applyConfig(moduleId, next || (moduleId === FROG_MODULE_ID ? FROG_DEFAULTS : AGENT_DEFAULTS), {
                    resetSelection: true
                });
                startObserver(moduleId);
                mountContextButton(moduleId);
            });
        }

        return true;
    }

    function startWithoutCore() {
        applyConfig(FROG_MODULE_ID, FROG_DEFAULTS, { resetSelection: true });
        applyConfig(AGENT_MODULE_ID, AGENT_DEFAULTS, { resetSelection: true });
        startObserver(FROG_MODULE_ID);
        startObserver(AGENT_MODULE_ID);

        let attempts = 0;
        if (coreWaitTimer) window.clearInterval(coreWaitTimer);

        coreWaitTimer = window.setInterval(function () {
            attempts += 1;
            if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
                startModuleWithCore(FROG_MODULE_ID);
                startModuleWithCore(AGENT_MODULE_ID);
            } else if (attempts >= 100) {
                window.clearInterval(coreWaitTimer);
                coreWaitTimer = null;
            }
        }, 100);
    }

    function init() {
        if (window.PMKConfig && typeof window.PMKConfig.registerModule === "function") {
            startModuleWithCore(FROG_MODULE_ID);
            startModuleWithCore(AGENT_MODULE_ID);
        } else {
            startWithoutCore();
        }

        window.setTimeout(function () {
            scheduleApply(FROG_MODULE_ID);
            scheduleApply(AGENT_MODULE_ID);
        }, 300);

        window.setTimeout(function () {
            scheduleApply(FROG_MODULE_ID);
            scheduleApply(AGENT_MODULE_ID);
        }, 1200);

        reducedMotion?.addEventListener('change', function () {
            if (states[FROG_MODULE_ID].config.respectReducedMotion !== false && reducedMotion.matches) stopFrogSound();
            scheduleApply(FROG_MODULE_ID);
        });
        let resizeTimer = null;
        window.addEventListener("resize", function () {
            if (resizeTimer) window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(function () {
                scheduleApply(FROG_MODULE_ID);
                scheduleApply(AGENT_MODULE_ID);
            }, 100);
        });
    }

    window.PMK060Mascots = {
        version: VERSION,
        modules: {
            frogs: {
                id: FROG_MODULE_ID,
                defaults: clone(FROG_DEFAULTS),
                normalize: normalizeFrogConfig,
                apply: function (config) { applyConfig(FROG_MODULE_ID, config, { resetSelection: true }); },
                reapply: function () { scheduleApply(FROG_MODULE_ID); }
            },
            agents: {
                id: AGENT_MODULE_ID,
                defaults: clone(AGENT_DEFAULTS),
                normalize: normalizeAgentConfig,
                apply: function (config) { applyConfig(AGENT_MODULE_ID, config, { resetSelection: true }); },
                reapply: function () { scheduleApply(AGENT_MODULE_ID); }
            }
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("060-grenouille.js");
} catch (error) { window.PMKNonPlugin.errors.push("060-grenouille.js: "+error.message); console.error("[PMK] 060-grenouille.js",error); };
try {
//-----------------------------------------------------------------------------------------------------------------------------
// 062-guided-reports-tools: kit autonome pour les résultats de rapports Koha + configuration PMK pré-plugin
//-----------------------------------------------------------------------------------------------------------------------------
(function(){
  'use strict';

  try {
    if (window.location.pathname.indexOf('guided_reports.pl') === -1) return;

    function localWaitForSelector(selector, timeout) {
      return new Promise(function(resolve, reject) {
        var el = document.querySelector(selector);
        if (el) return resolve(el);
        var obs = new MutationObserver(function() {
          var node = document.querySelector(selector);
          if (node) {
            obs.disconnect();
            resolve(node);
          }
        });
        obs.observe(document.documentElement || document.body, { childList: true, subtree: true });
        if (typeof timeout === 'number') {
          setTimeout(function() {
            obs.disconnect();
            reject(new Error('Timed out waiting for ' + selector));
          }, timeout);
        }
      });
    }

    var waitForSelector = (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitForSelector === 'function')
      ? window.KOHA_UTILS.waitForSelector
      : localWaitForSelector;

    // Configuration PMK pré-plugin : toutes les fonctions historiques restent actives par défaut.
    var MODULE_ID = 'guided-reports-tools';
    var pmkConfig = null;
    var externalConfig = window.GUIDED_REPORTS_TOOLS || {};

    var DEFAULT_FEATURES = {
      generalSearch: true,
      columnFilters: true,
      filterHighlight: true,
      sorting: true,
      visibleColumns: true,
      stickyHeader: true,
      rowHighlight: true,
      cellStatistics: true,
      columnReordering: true,
      report5191Preset: true
    };

    var FEATURES = Object.assign({}, DEFAULT_FEATURES);
    var CONFIG = { debounce: 250 };
    var SPECIAL_REPORT_IDS = ['5191'];

    function refreshRuntimeConfig() {
      /*
       * La configuration PMK est l'autorité lorsqu'elle est disponible.
       * L'ancien objet window.GUIDED_REPORTS_TOOLS n'est utilisé qu'en
       * secours lorsque PMK n'est réellement pas chargé. Cela évite
       * qu'une ancienne configuration globale à true réactive une option
       * explicitement désactivée dans PMK.
       */
      var featureOverrides = pmkConfig && pmkConfig.features
        ? pmkConfig.features
        : (externalConfig.features || {});

      FEATURES = Object.assign({}, DEFAULT_FEATURES, featureOverrides);

      var debounceValue = 250;
      try {
        if (pmkConfig && pmkConfig.debounce != null) {
          debounceValue = Number(pmkConfig.debounce);
        } else if (externalConfig.debounce != null) {
          debounceValue = Number(externalConfig.debounce);
        }
      } catch (e) {}
      if (!isFinite(debounceValue) || debounceValue < 0) debounceValue = 250;
      CONFIG.debounce = debounceValue;

      var presetId = pmkConfig && pmkConfig.presetReportId != null ? pmkConfig.presetReportId : (externalConfig.presetReportId != null ? externalConfig.presetReportId : 5191);
      SPECIAL_REPORT_IDS = /^\d+$/.test(String(presetId)) && Number(presetId)>0 ? [String(Number(presetId))] : [];
    }

    function getPmkApi() {
      try {
        if (
          window.PMKConfig &&
          typeof window.PMKConfig.getConfig === 'function'
        ) {
          return window.PMKConfig;
        }
      } catch (e) {}
      return null;
    }

    function waitForPmkApi(timeout) {
      var maxWait = typeof timeout === 'number' ? timeout : 6000;
      var startedAt = Date.now();

      return new Promise(function(resolve) {
        function check() {
          var api = getPmkApi();
          if (api) {
            resolve(api);
            return;
          }
          if ((Date.now() - startedAt) >= maxWait) {
            resolve(null);
            return;
          }
          window.setTimeout(check, 50);
        }
        check();
      });
    }

    function loadPmkConfig() {
      return waitForPmkApi(6000).then(function(api) {
        if (!api) return null;
        try {
          return Promise.resolve(api.getConfig(MODULE_ID, { force: true }))
            .catch(function() { return null; });
        } catch (e) {
          return null;
        }
      });
    }

    function subscribeToPmkChanges() {
      var api = getPmkApi();
      if (!api || typeof api.subscribe !== 'function') return;

      try {
        api.subscribe(MODULE_ID, function(nextConfig) {
          /*
           * Le 062 installe des listeners, des lignes de filtres, des styles
           * et peut réordonner/masquer des colonnes. Un rechargement contrôlé
           * est donc le moyen le plus sûr de garantir qu'une désactivation
           * retire réellement tout ce qui était déjà monté dans la page.
           */
          pmkConfig = nextConfig || null;
          refreshRuntimeConfig();
          window.location.reload();
        });
      } catch (e) {}
    }

    function begin() {
      refreshRuntimeConfig();

      if (pmkConfig && pmkConfig.enabled === false) return;
      if (pmkConfig && pmkConfig.page && pmkConfig.page.enabled === false) return;

    // Koha récent expose #report_results. On conserve le sélecteur historique en secours.
    var tableSelector = document.querySelector('#report_results') ? '#report_results' : '.pages + table';

    waitForSelector(tableSelector, 3000).then(function(table) {
      try {
        // Relecture tardive : si PMK a fini de charger après le 062, les interrupteurs sont tout de même pris en compte.
        refreshRuntimeConfig();
        if (!table) return;
        if (table.dataset.grtInited === '1') return;

        var headerRow = table.tHead && table.tHead.rows && table.tHead.rows[0]
          ? table.tHead.rows[0]
          : table.querySelector('tr');
        if (!headerRow || !headerRow.cells || !headerRow.cells.length) return;

        var tbody = table.tBodies && table.tBodies[0] ? table.tBodies[0] : null;
        if (!tbody) return;

        var originalRowOrder = Array.from(tbody.rows || []);
        var highlightedRows = [];
        var sortColumns = [];
        var columnVisibilityState = {};
        var filterRow = null;
        var searchInput = null;
        var toolsWrapper = null;
        var selectedCells = new Set();

        function debounce(fn, wait) {
          var t;
          return function() {
            var args = arguments;
            var ctx = this;
            clearTimeout(t);
            t = setTimeout(function() { fn.apply(ctx, args); }, wait);
          };
        }

        function escapeRegExp(s) {
          return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }

        function getBodyRows() {
          return Array.from(tbody.rows || []);
        }

        function getColumnIndexById(colId) {
          var headers = Array.from(headerRow.cells || []);
          for (var i = 0; i < headers.length; i++) {
            if (headers[i].dataset.grtColId === colId) return i;
          }
          return -1;
        }

        function getCellByColId(row, colId) {
          if (!row || !row.cells) return null;
          var idx = getColumnIndexById(colId);
          return idx >= 0 ? row.cells[idx] : null;
        }

        function cacheRow(row) {
          if (!row) return;
          try {
            row.dataset.grtText = Array.from(row.querySelectorAll('td')).map(function(cell) {
              return (cell && cell.innerText ? cell.innerText : '').toLowerCase();
            }).join('||');
          } catch (e) {}
        }

        function cacheAllRows() {
          getBodyRows().forEach(cacheRow);
        }

        function removeHighlights(root) {
          if (!root) return;
          var spans = root.querySelectorAll('span.grt-highlight');
          for (var i = 0; i < spans.length; i++) {
            var span = spans[i];
            span.replaceWith(document.createTextNode(span.textContent || ''));
          }
          try { root.normalize(); } catch (e) {}
        }

        // Surbrillance non destructive : on ne reconstruit jamais le innerHTML d'une cellule Koha.
        function highlightTextNodes(cell, term) {
          if (!cell || !term) return;
          var regex;
          try { regex = new RegExp(escapeRegExp(term), 'gi'); } catch (e) { return; }

          var nodes = [];
          var walker = document.createTreeWalker(
            cell,
            NodeFilter.SHOW_TEXT,
            {
              acceptNode: function(node) {
                if (!node || !node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                var parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (parent.closest('span.grt-highlight')) return NodeFilter.FILTER_REJECT;
                if (/^(SCRIPT|STYLE|TEXTAREA|OPTION)$/i.test(parent.tagName || '')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
              }
            }
          );

          var node;
          while ((node = walker.nextNode())) nodes.push(node);

          nodes.forEach(function(textNode) {
            var text = textNode.nodeValue || '';
            regex.lastIndex = 0;
            if (!regex.test(text)) return;
            regex.lastIndex = 0;

            var frag = document.createDocumentFragment();
            var last = 0;
            var match;
            while ((match = regex.exec(text))) {
              if (match.index > last) frag.appendChild(document.createTextNode(text.slice(last, match.index)));
              var mark = document.createElement('span');
              mark.className = 'grt-highlight';
              mark.textContent = match[0];
              frag.appendChild(mark);
              last = match.index + match[0].length;
              if (match[0].length === 0) regex.lastIndex++;
            }
            if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
            try { textNode.parentNode.replaceChild(frag, textNode); } catch (e) {}
          });
        }

        function detectDateFormat(dateString) {
          if (/^\d{2}-\d{2}-\d{4}$/.test(dateString)) return 'DD-MM-YYYY';
          if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) return 'YYYY-MM-DD';
          return null;
        }

        function parseDate(dateString, format) {
          if (format === 'DD-MM-YYYY') {
            var parts = dateString.split('-');
            return new Date(parts[2], parts[1] - 1, parts[0]);
          }
          if (format === 'YYYY-MM-DD') return new Date(dateString);
          return null;
        }

        function customCompare(a, b, asc) {
          a = (a || '').trim();
          b = (b || '').trim();
          if (!a && !b) return 0;
          if (!a) return asc ? -1 : 1;
          if (!b) return asc ? 1 : -1;

          var parseDuration = function(str) {
            var match = str.match(/(\d+)\s*mois.*?(\d+)\s*jours?/i);
            if (match) return parseInt(match[1], 10) * 30 + parseInt(match[2], 10);
            return null;
          };

          var durA = parseDuration(a);
          var durB = parseDuration(b);
          if (durA !== null && durB !== null) return asc ? durA - durB : durB - durA;

          var parseCote = function(str) {
            var match = str.match(/^(\d+(?:\.\d+)?)(?:\s+(.+))?$/);
            if (match) {
              return {
                type: 'dewey',
                number: parseFloat(match[1]),
                suffix: match[2] ? match[2].trim() : ''
              };
            }
            return { type: 'alpha', text: str };
          };

          var coteA = parseCote(a);
          var coteB = parseCote(b);
          if (coteA.type === 'dewey' && coteB.type === 'dewey') {
            if (coteA.number !== coteB.number) return asc ? coteA.number - coteB.number : coteB.number - coteA.number;
            return asc
              ? coteA.suffix.localeCompare(coteB.suffix, 'fr', { numeric: true })
              : coteB.suffix.localeCompare(coteA.suffix, 'fr', { numeric: true });
          }
          if (coteA.type === 'dewey' && coteB.type === 'alpha') return asc ? -1 : 1;
          if (coteA.type === 'alpha' && coteB.type === 'dewey') return asc ? 1 : -1;
          if (coteA.type === 'alpha' && coteB.type === 'alpha') {
            return asc
              ? coteA.text.localeCompare(coteB.text, 'fr', { numeric: true })
              : coteB.text.localeCompare(coteA.text, 'fr', { numeric: true });
          }

          var numA = parseFloat(a.replace(',', '.'));
          var numB = parseFloat(b.replace(',', '.'));
          if (!isNaN(numA) && !isNaN(numB)) return asc ? numA - numB : numB - numA;

          var parseDateGeneric = function(str) {
            var m;
            if ((m = str.match(/^(\d{2})[\/\-](\d{2})[\/\-](\d{4})$/))) return new Date(+m[3], m[2] - 1, +m[1]);
            if ((m = str.match(/^(\d{4})[\/\-](\d{2})[\/\-](\d{2})$/))) return new Date(+m[1], m[2] - 1, +m[3]);
            return null;
          };

          var dateA = parseDateGeneric(a);
          var dateB = parseDateGeneric(b);
          if (dateA && dateB) return asc ? dateA - dateB : dateB - dateA;

          return asc
            ? a.localeCompare(b, 'fr', { numeric: true })
            : b.localeCompare(a, 'fr', { numeric: true });
        }

        function assignColumnIds() {
          var headers = Array.from(headerRow.cells || []);
          headers.forEach(function(th, idx) {
            var colId = th.dataset.grtColId || ('grt-col-' + idx);
            th.dataset.grtColId = colId;
            if (!(colId in columnVisibilityState)) {
              columnVisibilityState[colId] = window.getComputedStyle(th).display !== 'none';
            }
          });

          getBodyRows().forEach(function(row) {
            headers.forEach(function(th, idx) {
              if (row.cells && row.cells[idx]) row.cells[idx].dataset.grtColId = th.dataset.grtColId;
            });
          });

          if (filterRow) {
            headers.forEach(function(th, idx) {
              if (filterRow.cells && filterRow.cells[idx]) filterRow.cells[idx].dataset.grtColId = th.dataset.grtColId;
            });
          }
        }

        function setColumnVisibility(colId, visible) {
          if (!colId) return;
          columnVisibilityState[colId] = !!visible;
          var cells = table.querySelectorAll('[data-grt-col-id="' + colId + '"]');
          cells.forEach(function(cell) {
            try {
              if (visible) {
                cell.style.display = '';
                if (cell.dataset) delete cell.dataset.grtHidden;
                if (cell.classList) cell.classList.remove('grt-hidden');
              } else {
                cell.style.display = 'none';
                if (cell.dataset) cell.dataset.grtHidden = '1';
                if (cell.classList) cell.classList.add('grt-hidden');
              }
            } catch (e) {}
          });

          var toggle = document.querySelector('input[data-grt-toggle-col="' + colId + '"]');
          try { if (toggle) toggle.checked = !!visible; } catch (e) {}
        }

        function isSpecialReport() {
          try {
            if (location.pathname !== '/cgi-bin/koha/reports/guided_reports.pl') return false;
            var params = new URLSearchParams(location.search);
            var urlId = String(params.get('id') || '');
            if (SPECIAL_REPORT_IDS.indexOf(urlId) !== -1) return true;

            var hiddenId = document.querySelector('#limitselect input[name="id"]');
            if (hiddenId && SPECIAL_REPORT_IDS.indexOf(String(hiddenId.value || '')) !== -1) return true;

            var sql = document.querySelector('#sql');
            if (sql && sql.value) {
              return SPECIAL_REPORT_IDS.some(function(id) {
                return new RegExp('saved_sql\\.id:\\s*' + id + '(?!\\d)').test(sql.value);
              });
            }
          } catch (e) {}
          return false;
        }

        function applyReport5191Preset() {
          if (!FEATURES.report5191Preset || !isSpecialReport()) return false;

          var DEFAULT_VISIBLE = new Set([
            'grt-col-0', 'grt-col-1', 'grt-col-2',
            'grt-col-6', 'grt-col-7', 'grt-col-8',
            'grt-col-9', 'grt-col-11'
          ]);

          Array.from(headerRow.cells || []).forEach(function(th, idx) {
            var headerText = (th.innerText || th.textContent || '').trim().toLowerCase();
            var colId = th.dataset.grtColId || ('grt-col-' + idx);
            if (headerText === 'code collection' || headerText === 'collection') DEFAULT_VISIBLE.add(colId);
          });

          Array.from(headerRow.cells || []).forEach(function(th, idx) {
            var colId = th.dataset.grtColId || ('grt-col-' + idx);
            setColumnVisibility(colId, DEFAULT_VISIBLE.has(colId));
          });
          return true;
        }

        function markExistingHiddenCols() {
          Array.from(headerRow.cells || []).forEach(function(th, idx) {
            try {
              var colId = th.dataset.grtColId || ('grt-col-' + idx);
              var hidden = window.getComputedStyle(th).display === 'none';
              if (hidden) setColumnVisibility(colId, false);
            } catch (e) {}
          });
        }

        function createFilterRow() {
          if (!FEATURES.columnFilters) return null;

          var row = document.createElement('tr');
          row.className = 'grt-filter-row';
          row.id = 'grt-filter-row';

          Array.from(headerRow.cells || []).forEach(function(headerCell, idx) {
            var filterName = (headerCell.innerText || headerCell.textContent || '').trim() || ('Colonne ' + (idx + 1));
            var cell = document.createElement('th');
            var colId = headerCell.dataset.grtColId || ('grt-col-' + idx);
            cell.dataset.grtColId = colId;

            var input = document.createElement('input');
            input.type = 'text';
            input.value = '';
            input.setAttribute('data-column-index', idx);
            input.placeholder = 'Filtrer...';
            input.setAttribute('aria-label', 'Filtrer ' + filterName);
            input.addEventListener('input', debounce(applyFilters, CONFIG.debounce));
            cell.appendChild(input);

            if (columnVisibilityState[colId] === false) cell.style.display = 'none';
            row.appendChild(cell);
          });

          if (headerRow.parentNode) headerRow.parentNode.appendChild(row);
          return row;
        }

        function currentFilterForIndex(idx) {
          if (!filterRow || !filterRow.cells || !filterRow.cells[idx]) return '';
          var input = filterRow.cells[idx].querySelector('input[data-column-index]');
          return input ? String(input.value || '').trim().toLowerCase() : '';
        }

        function applyFilters() {
          table.querySelectorAll('span.grt-highlight').forEach(function(span) {
            span.replaceWith(document.createTextNode(span.textContent || ''));
          });

          var searchTerm = FEATURES.generalSearch && searchInput
            ? String(searchInput.value || '').trim().toLowerCase()
            : '';

          getBodyRows().forEach(function(row) {
            var cells = Array.from(row.cells || []);
            var visible = true;

            if (searchTerm) {
              var rowText = row.dataset.grtText || cells.map(function(cell) {
                return (cell && cell.innerText ? cell.innerText : '').toLowerCase();
              }).join(' ');
              if (rowText.indexOf(searchTerm) === -1) visible = false;
            }

            if (visible && FEATURES.columnFilters && filterRow) {
              for (var j = 0; j < cells.length; j++) {
                var filterCell = filterRow.cells[j];
                if (!filterCell || window.getComputedStyle(filterCell).display === 'none') continue;
                var filterValue = currentFilterForIndex(j);
                if (filterValue && (cells[j].textContent || '').toLowerCase().indexOf(filterValue) === -1) {
                  visible = false;
                  break;
                }
              }
            }

            row.style.display = visible ? '' : 'none';

            if (visible && FEATURES.columnFilters && FEATURES.filterHighlight && filterRow) {
              for (var k = 0; k < cells.length; k++) {
                var visibleFilterCell = filterRow.cells[k];
                if (!visibleFilterCell || window.getComputedStyle(visibleFilterCell).display === 'none') continue;
                var visibleFilter = currentFilterForIndex(k);
                if (visibleFilter) highlightTextNodes(cells[k], visibleFilter);
              }
            }
          });
        }

        function updateScope() {
          var note=toolsWrapper && toolsWrapper.querySelector('.grt-scope');
          if(note){var text=getBodyRows().length+' ligne(s) chargée(s). Recherche, tri et statistiques limités à ces lignes ; les autres pages Koha ne sont pas incluses.';if(note.textContent!==text)note.textContent=text;}
        }

        function createToolsWrapper() {
          var needsTools = FEATURES.columnFilters || FEATURES.sorting || FEATURES.visibleColumns || FEATURES.generalSearch;
          try {
            if (
              window.PMKConfig &&
              typeof window.PMKConfig.canOpenAdmin === 'function' &&
              window.PMKConfig.canOpenAdmin()
            ) needsTools = true;
          } catch (e) {}
          if (!needsTools) return null;

          var wrapper = document.createElement('div');
          wrapper.className = 'grt-tools';
          var scope=document.createElement('small');scope.className='grt-scope';scope.style.flexBasis='100%';scope.setAttribute('aria-live','polite');wrapper.appendChild(scope);

          var limitSelectForm = document.getElementById('limitselect');
          if (limitSelectForm && limitSelectForm.parentNode) {
            limitSelectForm.parentNode.insertBefore(wrapper, limitSelectForm.nextSibling);
          } else if (table.parentNode) {
            // Koha récent n'a plus forcément le formulaire #limitselect : on garde les outils juste au-dessus du tableau.
            table.parentNode.insertBefore(wrapper, table);
          }
          return wrapper;
        }

        function createColumnToggleUI(buttonContainer) {
          if (!FEATURES.visibleColumns || !buttonContainer) return;

          var wrap = document.createElement('div');
          wrap.className = 'grt-columns-toggle';
          wrap.id = 'grt-columns-toggle';

          var title = document.createElement('div');
          title.className = 'grt-columns-title';
          title.textContent = 'Colonnes visibles';
          wrap.appendChild(title);

          var button = document.createElement('button');
          button.type = 'button';
          button.className = 'btn btn-default grt-columns-button';
          button.textContent = 'Colonnes visibles';
          button.setAttribute('aria-expanded', 'false');
          button.setAttribute('aria-controls', wrap.id);
          button.addEventListener('click', function() {
            var visible = window.getComputedStyle(wrap).display !== 'none';
            wrap.style.display = visible ? 'none' : 'block';
            button.setAttribute('aria-expanded', String(!visible));
          });

          var anchor = document.createElement('div');
          anchor.className = 'grt-columns-anchor';
          anchor.appendChild(button);

          document.addEventListener('click', function(event) {
            if (!anchor.contains(event.target) && window.getComputedStyle(wrap).display !== 'none') {
              wrap.style.display = 'none';
              button.setAttribute('aria-expanded', 'false');
            }
          });

          var grid = document.createElement('div');
          grid.className = 'grt-columns-grid';

          Array.from(headerRow.cells || []).forEach(function(th, idx) {
            var colId = th.dataset.grtColId || ('grt-col-' + idx);
            var label = document.createElement('label');
            var input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = columnVisibilityState[colId] !== false;
            input.dataset.grtToggleCol = colId;

            var text = document.createElement('span');
            var headerName = (th.innerText || th.textContent || '').trim();
            text.textContent = headerName || ('Colonne ' + (idx + 1));

            input.addEventListener('change', function() {
              setColumnVisibility(colId, input.checked);
              applyFilters();
            });

            label.appendChild(input);
            label.appendChild(text);
            grid.appendChild(label);
          });

          wrap.appendChild(grid);
          anchor.appendChild(wrap);
          buttonContainer.appendChild(anchor);
        }

        function sortTable() {
          if (!FEATURES.sorting || !sortColumns.length) return;
          var rowsArray = getBodyRows();
          var fragment = document.createDocumentFragment();

          rowsArray.sort(function(rowA, rowB) {
            for (var idx = 0; idx < sortColumns.length; idx++) {
              var col = sortColumns[idx];
              var cellA = getCellByColId(rowA, col.colId);
              var cellB = getCellByColId(rowB, col.colId);
              var textA = cellA && cellA.textContent ? cellA.textContent.trim() : '';
              var textB = cellB && cellB.textContent ? cellB.textContent.trim() : '';
              var comp = customCompare(textA, textB, col.asc);
              if (comp !== 0) return comp;
            }
            return 0;
          });

          requestAnimationFrame(function() {
            rowsArray.forEach(function(row) { fragment.appendChild(row); });
            tbody.appendChild(fragment);
          });
        }

        function renderSortIcons() {
          Array.from(headerRow.cells || []).forEach(function(cell) {
            cell.classList.remove('asc', 'desc');
            var old = cell.querySelector('.sort-icon');
            if (old) old.remove();
          });

          sortColumns.forEach(function(col) {
            var idx = getColumnIndexById(col.colId);
            if (idx < 0 || !headerRow.cells[idx]) return;
            var cell = headerRow.cells[idx];
            var sortIcon = document.createElement('span');
            sortIcon.className = 'sort-icon grt-sort-icon ' + (col.asc ? 'asc' : 'desc');
            sortIcon.innerHTML = col.asc ? '&#9650;' : '&#9660;';
            cell.classList.add(col.asc ? 'asc' : 'desc');
            cell.appendChild(sortIcon);
          });
        }

        function resetSorting() {
          sortColumns.length = 0;
          renderSortIcons();
          var fragment = document.createDocumentFragment();
          originalRowOrder.forEach(function(row) { fragment.appendChild(row); });
          tbody.appendChild(fragment);
          applyFilters();
        }

        function moveCell(row, sourceIndex, targetIndex) {
          if (!row || !row.children) return;
          var cells = Array.from(row.children);
          var source = cells[sourceIndex];
          var target = cells[targetIndex];
          if (!source || !target || source === target) return;

          if (sourceIndex < targetIndex) {
            row.insertBefore(source, target.nextSibling);
          } else {
            row.insertBefore(source, target);
          }
        }

        function refreshFilterIndexes() {
          if (!filterRow) return;
          Array.from(filterRow.cells || []).forEach(function(cell, idx) {
            var input = cell.querySelector('input[data-column-index]');
            if (input) input.setAttribute('data-column-index', idx);
          });
        }

        function setupColumnReordering() {
          if (!FEATURES.columnReordering) return;

          var isDragging = false;
          var sourceColumnIndex = null;
          var justDragged = false;

          function handleDragStart(event) {
            var th = event.currentTarget || event.target.closest('th');
            if (!th) return;
            isDragging = true;
            sourceColumnIndex = th.cellIndex;
            try {
              event.dataTransfer.effectAllowed = 'move';
              event.dataTransfer.setData('text/plain', String(sourceColumnIndex));
            } catch (e) {}
          }

          function handleDragOver(event) {
            event.preventDefault();
            try { event.dataTransfer.dropEffect = 'move'; } catch (e) {}
          }

          function handleDragEnd() {
            isDragging = false;
            sourceColumnIndex = null;
            justDragged = true;
            setTimeout(function() { justDragged = false; }, 50);
          }

          function handleDrop(event) {
            event.preventDefault();
            try {
              var th = event.currentTarget || event.target.closest('th');
              if (!th) return;
              var targetIndex = th.cellIndex;
              var src = parseInt(event.dataTransfer.getData('text/plain'), 10);
              if (isNaN(src)) src = sourceColumnIndex;
              if (isNaN(src) || src === targetIndex) return;

              moveCell(headerRow, src, targetIndex);
              if (filterRow) moveCell(filterRow, src, targetIndex);
              getBodyRows().forEach(function(row) { moveCell(row, src, targetIndex); });

              refreshFilterIndexes();
              renderSortIcons();
              cacheAllRows();
              applyFilters();
            } catch (e) {
            } finally {
              isDragging = false;
              sourceColumnIndex = null;
              justDragged = true;
              setTimeout(function() { justDragged = false; }, 50);
            }
          }

          Array.from(headerRow.querySelectorAll('th')).forEach(function(header) {
            try {
              header.setAttribute('draggable', 'true');
              header.addEventListener('dragstart', handleDragStart);
              header.addEventListener('dragover', handleDragOver);
              header.addEventListener('dragend', handleDragEnd);
              header.addEventListener('drop', handleDrop);
            } catch (e) {}
          });

          headerRow.dataset.grtDragEnabled = '1';
          headerRow.__grtJustDragged = function() { return justDragged; };
        }

        function parseNumericValue(text) {
          var normalized = String(text || '')
            .replace(/\u00a0/g, ' ')
            .trim()
            .replace(/\s+/g, '')
            .replace(',', '.');
          if (!normalized) return null;
          var value = parseFloat(normalized);
          return isNaN(value) ? null : value;
        }

        function calculerStats(cells) {
          var values = [];
          cells.forEach(function(cell) {
            var value = parseNumericValue(cell.textContent);
            if (value !== null) values.push(value);
          });

          if (!values.length) {
            return {
              somme: 0,
              moyenne: 'Calcul impossible',
              minimum: 'Calcul impossible',
              maximum: 'Calcul impossible'
            };
          }

          var somme = values.reduce(function(total, value) { return total + value; }, 0);
          return {
            somme: somme,
            moyenne: (somme / values.length).toFixed(2),
            minimum: Math.min.apply(Math, values),
            maximum: Math.max.apply(Math, values)
          };
        }

        function updateStatsDiv(event) {
          if (!FEATURES.cellStatistics) return;
          var statsDiv = document.getElementById('grt-stats');
          if (event.shiftKey) {
            if (!statsDiv) {
              statsDiv = document.createElement('div');
              statsDiv.id = 'grt-stats';
              document.body.appendChild(statsDiv);
            }
            var stats = calculerStats(selectedCells);
            statsDiv.innerHTML = '<p>Somme : ' + stats.somme + '</p>' +
              '<p>Moyenne : ' + stats.moyenne + '</p>' +
              '<p>Minimum : ' + stats.minimum + '</p>' +
              '<p>Maximum : ' + stats.maximum + '</p>';
            statsDiv.style.display = 'block';
          } else if (statsDiv) {
            statsDiv.style.display = 'none';
          }
        }

        function cellClickHandler(event) {
          if (!FEATURES.cellStatistics) return;
          var cell = event.target.closest('td');
          if (!cell) return;
          if (event.shiftKey) {
            selectedCells.add(cell);
            cell.classList.add('grt-stat-selected');
          }
          updateStatsDiv(event);
        }

        function shiftUpHandler() {
          if (!FEATURES.cellStatistics) return;
          selectedCells.forEach(function(cell) { cell.classList.remove('grt-stat-selected'); });
          selectedCells.clear();
          var statsDiv = document.getElementById('grt-stats');
          if (statsDiv) statsDiv.style.display = 'none';
        }

        function publishColumnsReady(is5191) {
          try {
            var detail = {
              tableSelector: table.id ? ('#' + table.id) : tableSelector
            };
            if (is5191) detail.report = Number(SPECIAL_REPORT_IDS[0]);

            window.GRT = window.GRT || {};
            window.GRT.columnsReady = true;
            window.GRT.columnsReadyPromise = Promise.resolve(detail);
            document.dispatchEvent(new CustomEvent('grt:columns-ready', { detail: detail }));
          } catch (e) {}
        }

        function setupObservers() {
          try {
            var debSetColumnVisibility = debounce(function(colId, visible) {
              if (columnVisibilityState[colId] !== visible) setColumnVisibility(colId, visible);
            }, 50);

            var headerObserver = new MutationObserver(function(mutations) {
              mutations.forEach(function(mutation) {
                try {
                  var th = mutation.target && mutation.target.closest ? mutation.target.closest('th') : null;
                  if (!th || !headerRow.contains(th)) return;
                  var colId = th.dataset.grtColId;
                  if (!colId) return;
                  var hidden = window.getComputedStyle(th).display === 'none';
                  debSetColumnVisibility(colId, !hidden);
                } catch (e) {}
              });
            });
            headerObserver.observe(headerRow, {
              attributes: true,
              subtree: true,
              attributeFilter: ['style', 'class']
            });

            var tableObserver = new MutationObserver(function(mutations) {
              mutations.forEach(function(mutation) {
                try {
                  var target = mutation.target;
                  if (mutation.type === 'attributes' && target && target.nodeName === 'TD') {
                    var colId = target.dataset.grtColId;
                    if (!colId) return;
                    var hidden = window.getComputedStyle(target).display === 'none';
                    if (columnVisibilityState[colId] !== !hidden) debSetColumnVisibility(colId, !hidden);
                  }
                } catch (e) {}
              });
            });
            tableObserver.observe(tbody, {
              attributes: true,
              subtree: true,
              attributeFilter: ['style', 'class']
            });

            var childListObserver = new MutationObserver(function(mutations) {
              // Highlight wrappers change text inside cells; only native table structure needs a refresh.
              if(!mutations.some(function(mutation){return /^(TABLE|TBODY|THEAD|TR)$/.test(mutation.target.nodeName) && !mutation.target.closest?.('.grt-filter-row');}))return;
              try {
                var nextBody=table.tBodies[0];if(!nextBody)return;
                if(nextBody!==tbody){tbody=nextBody;tableObserver.disconnect();tableObserver.observe(tbody,{attributes:true,subtree:true,attributeFilter:['style','class']});}
                var currentRows=getBodyRows(),changed=currentRows.length!==originalRowOrder.length || currentRows.some(function(row){return originalRowOrder.indexOf(row)===-1;});
                if(changed){
                  originalRowOrder=originalRowOrder.filter(function(row){return currentRows.indexOf(row)!==-1;}).concat(currentRows.filter(function(row){return originalRowOrder.indexOf(row)===-1;}));
                  highlightedRows=highlightedRows.filter(function(row){return currentRows.indexOf(row)!==-1;});
                  selectedCells.forEach(function(cell){if(!tbody.contains(cell))selectedCells.delete(cell);});
                }
                assignColumnIds();cacheAllRows();
                Object.keys(columnVisibilityState).forEach(function(colId){setColumnVisibility(colId,columnVisibilityState[colId]);});
                applyFilters();updateScope();
              } catch (e) {}
            });
            childListObserver.observe(table,{childList:true,subtree:true});
          } catch (e) {}
        }

        // Styles historiques, avec une classe dédiée à la sélection statistique.
        if (!document.getElementById('grt-styles')) {
          var style = document.createElement('style');
          style.id = 'grt-styles';
          style.type = 'text/css';
          style.textContent = '\n.grt-filter-row{display:none;}\n.grt-filter-row th{padding:6px 4px;background:#f6f8fb;}\n.grt-filter-row input[type="text"]{box-sizing:border-box;width:100%;height:32px;padding:5px 8px;border:1px solid #c7d1dc;border-radius:4px;background:#fff;color:#263746;}\n.grt-filter-row input[type="text"]:focus{outline:0;border-color:#287ea3;box-shadow:0 0 0 2px rgba(40,126,163,.15);}\n.grt-highlight{background:yellow;padding:0 2px;border-radius:2px;}\n.grt-highlighted td, .grt-highlighted{background:#fffbdd !important;}\n.grt-stat-selected{background:yellow !important;}\n.grt-sort-icon.asc, .grt-sort-icon.desc{margin-left:6px;font-size:0.9em;}\n.grt-sticky th{position:sticky;top:0;background:#fff;z-index:3;}\n.grt-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0;position:relative;z-index:10;}\n.grt-tools button{height:34px;padding:0 12px;border:1px solid #c7d1dc;border-radius:4px;background:#fff;color:#34495a;font-weight:600;cursor:pointer;transition:background .15s,border-color .15s,color .15s,box-shadow .15s;}\n.grt-tools button:hover{border-color:#287ea3;background:#eef7fb;color:#1d607e;}\n.grt-tools button:focus{outline:0;box-shadow:0 0 0 2px rgba(40,126,163,.15);}\n.grt-general-search{min-width:260px;height:34px;padding:6px 10px;border:1px solid #c7d1dc;border-radius:4px;}\n.grt-general-search:focus{outline:0;border-color:#287ea3;box-shadow:0 0 0 2px rgba(40,126,163,.15);}\n.grt-columns-anchor{position:relative;}\n.grt-columns-button[aria-expanded="true"]{border-color:#287ea3;background:#eaf5f9;color:#1d607e;}\n.grt-columns-toggle{display:none;position:absolute;top:calc(100% + 5px);left:0;min-width:220px;max-height:360px;overflow-y:auto;padding:11px;border:1px solid #d8e0e8;border-radius:6px;background:#fff;box-shadow:0 5px 16px rgba(30,45,60,.16);}\n.grt-columns-title{margin-bottom:8px;font-size:13px;font-weight:600;color:#526273;}\n.grt-columns-grid{display:flex;flex-direction:column;gap:2px;}\n.grt-columns-grid label{display:flex;align-items:center;gap:8px;padding:7px 8px;font-weight:400;border-radius:4px;cursor:pointer;}\n.grt-columns-grid label:hover{background:#f1f6f8;}\n.grt-columns-grid input{width:16px;height:16px;accent-color:#287ea3;}\n#grt-stats{position:fixed;right:10px;top:80px;background:white;border:1px solid #ccc;padding:8px;z-index:9999;}\n';
          document.head.appendChild(style);
        }

        var chartDiv = document.querySelector('.clearfix#chart');
        if (chartDiv) {
          var newParagraph = document.createElement('p');
          newParagraph.innerHTML = '';
          chartDiv.appendChild(newParagraph);
        }

        assignColumnIds();
        markExistingHiddenCols();
        var reportPresetApplied = applyReport5191Preset();

        filterRow = createFilterRow();
        assignColumnIds();

        if (FEATURES.stickyHeader) {
          try {
            headerRow.classList.add('grt-sticky');
            table.style.borderCollapse = 'separate';
          } catch (e) {}
        }

        if (FEATURES.rowHighlight) {
          table.addEventListener('click', function(event) {
            if(!tbody.contains(event.target))return;
            var tr = event.target.closest('tr');
            if (!tr) return;
            var index = highlightedRows.indexOf(tr);
            var isAltPressed = event.altKey;
            if (index === -1) {
              if (!isAltPressed) {
                highlightedRows.forEach(function(row) { row.classList.remove('grt-highlighted'); });
                highlightedRows = [];
              }
              tr.classList.add('grt-highlighted');
              highlightedRows.push(tr);
            } else if (!isAltPressed) {
              tr.classList.remove('grt-highlighted');
              highlightedRows.splice(index, 1);
            }
          });
        }

        toolsWrapper = createToolsWrapper();
        updateScope();

        // Accès contextuel discret à la configuration du 062 pour les superlibrarian.
        try {
          if (
            toolsWrapper &&
            window.PMKConfig &&
            typeof window.PMKConfig.mountContextButton === 'function'
          ) {
            window.PMKConfig.mountContextButton({
              moduleId: MODULE_ID,
              anchor: toolsWrapper,
              contextKey: 'report-results',
              context: { sectionId: 'features' }
            });
          }
        } catch (e) {}

        if (FEATURES.columnFilters && toolsWrapper && filterRow) {
          var filterToggleButton = document.createElement('button');
          filterToggleButton.type = 'button';
          filterToggleButton.textContent = 'Filtres';
          filterToggleButton.className = 'btn btn-default grt-filter-toggle';
          filterToggleButton.setAttribute('aria-expanded', 'false');
          filterToggleButton.setAttribute('aria-controls', 'grt-filter-row');
          toolsWrapper.appendChild(filterToggleButton);

          filterToggleButton.addEventListener('click', function() {
            var visible = filterRow.style.display !== 'table-row';
            filterRow.style.display = visible ? 'table-row' : 'none';
            Object.keys(columnVisibilityState).forEach(function(colId) {
              setColumnVisibility(colId, columnVisibilityState[colId]);
            });
            filterToggleButton.setAttribute('aria-expanded', String(visible));
          });

          var resetButton = document.createElement('button');
          resetButton.type = 'button';
          resetButton.textContent = 'Réinitialiser les filtres';
          resetButton.className = 'btn btn-default grt-reset';
          toolsWrapper.appendChild(resetButton);
          resetButton.addEventListener('click', function() {
            filterRow.querySelectorAll('input[data-column-index]').forEach(function(input) { input.value = ''; });
            applyFilters();
          });
        }

        if (FEATURES.sorting) {
          headerRow.addEventListener('click', function(event) {
            var th = event.target.closest('th');
            if (!th || !headerRow.contains(th)) return;
            if (headerRow.__grtJustDragged && headerRow.__grtJustDragged()) return;

            var colId = th.dataset.grtColId;
            if (!colId) return;
            var existingIndex = -1;
            for (var i = 0; i < sortColumns.length; i++) {
              if (sortColumns[i].colId === colId) {
                existingIndex = i;
                break;
              }
            }

            if (existingIndex !== -1) sortColumns[existingIndex].asc = !sortColumns[existingIndex].asc;
            else sortColumns.push({ colId: colId, asc: true });

            renderSortIcons();
            requestAnimationFrame(sortTable);
          });

          if (toolsWrapper) {
            var resetSortButton = document.createElement('button');
            resetSortButton.type = 'button';
            resetSortButton.textContent = 'Réinitialiser les tris';
            resetSortButton.className = 'btn btn-default grt-reset-sort';
            toolsWrapper.appendChild(resetSortButton);
            resetSortButton.addEventListener('click', resetSorting);
          }
        }

        createColumnToggleUI(toolsWrapper);

        if (FEATURES.generalSearch && toolsWrapper) {
          searchInput = document.createElement('input');
          searchInput.type = 'text';
          searchInput.placeholder = 'Rechercher dans toutes les colonnes...';
          searchInput.classList.add('grt-general-search');
          toolsWrapper.appendChild(searchInput);
          searchInput.addEventListener('input', debounce(applyFilters, CONFIG.debounce));
        }

        if (FEATURES.cellStatistics) {
          table.addEventListener('click', function(event) {
            if(!tbody.contains(event.target))return;
            if (event.target && event.target.closest('td')) cellClickHandler(event);
          });
          document.addEventListener('keydown', function(event) {
            if (event.key === 'Shift') document.body.classList.add('grt-shiftPressed');
          });
          document.addEventListener('keyup', function(event) {
            if (event.key === 'Shift') {
              document.body.classList.remove('grt-shiftPressed');
              shiftUpHandler();
            }
          });
        }

        setupColumnReordering();
        cacheAllRows();
        setupObservers();

        table.dataset.grtInited = '1';
        publishColumnsReady(reportPresetApplied);

      } catch (e) {
        (function(){})('062-guided-reports-tools inner error:', e);
      }
    }).catch(function() {
      /* table not present in time */
    });
    }

    loadPmkConfig().then(function(config) {
      pmkConfig = config;
      refreshRuntimeConfig();
      subscribeToPmkChanges();
      begin();
    }).catch(function() {
      pmkConfig = null;
      refreshRuntimeConfig();
      subscribeToPmkChanges();
      begin();
    });

  } catch (err) {
    (function(){})('062-guided-reports-tools error:', err);
  }
})();

;window.PMKNonPlugin.loaded.push("062-guided-reports-toolss.js");
} catch (error) { window.PMKNonPlugin.errors.push("062-guided-reports-toolss.js: "+error.message); console.error("[PMK] 062-guided-reports-toolss.js",error); };
try {
/*
 Nom du fichier: 063-mis-en-page-catalogue.js
 Version: 3.0.0
 Date de consolidation: 2026-09-20
 Auteur: équipe PimpMyKoha / consolidation PimpMyKoha

 Module PMK : Organisation des informations de la notice
 ID stable  : detail-bibliographic-groups

 Le module absorbe désormais les fonctions de présentation encore portées
 par le legacy 107-detail-layout-tweaks.js :
 - hover bibliographique (déjà absorbé auparavant) ;
 - séparateurs techniques avant Création notice / Acquisition ;
 - alignement du titre + actions ;
 - présentation du lien Statistiques détaillées.

 Principe important :
 les capacités de style ne sont PAS limitées aux éléments historiques du 107.
 Elles sont disponibles :
 - sur tous les groupes historiques ou futurs ;
 - sur toutes les informations historiques ou ajoutées par picker ;
 - via des règles de présentation génériques ajoutables par picker.
*/
(function () {
  'use strict';

  var MODULE_ID = 'detail-bibliographic-groups';
  var MODULE_VERSION = '3.0.0';
  var PAGE_PATH = '/cgi-bin/koha/catalogue/detail.pl';
  var PAGE_ID = 'catalogue.detail';
  var ROOT_ID = 'catalogue_detail_biblio';
  var CONTAINER_CLASS = 'catalogue-info';
  var STYLE_ID = 'pmk-063-style';
  var IS_TARGET_PAGE = window.location.pathname === PAGE_PATH;

  var currentConfig = null;
  var unsubscribe = null;
  var pmkInitialized = false;
  var moduleRegistered = false;
  var pickerRegistered = false;

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function isObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value);
  }

  function deepMerge(base, extra) {
    if (Array.isArray(base)) return Array.isArray(extra) ? clone(extra) : clone(base);
    if (!isObject(base)) return extra === undefined ? clone(base) : clone(extra);
    var out = clone(base);
    if (!isObject(extra)) return out;
    Object.keys(extra).forEach(function (key) {
      if (Array.isArray(extra[key])) out[key] = clone(extra[key]);
      else if (isObject(extra[key]) && isObject(out[key])) out[key] = deepMerge(out[key], extra[key]);
      else out[key] = clone(extra[key]);
    });
    return out;
  }

  function clean(value) {
    return String(value == null ? '' : value).trim();
  }

  function styleProfile(overrides) {
    return Object.assign({
      display: '',
      alignItems: '',
      justifyContent: '',
      flexWrap: '',
      gap: '',
      margin: '',
      padding: '',
      background: '',
      color: '',
      border: '',
      borderRadius: '',
      fontSize: '',
      fontWeight: '',
      textAlign: '',
      textDecoration: '',
      boxShadow: '',

      hoverBackground: '',
      hoverColor: '',
      hoverBorderColor: '',
      hoverBoxShadow: '',
      hoverTransform: '',

      separatorBefore: false,
      separatorAfter: false,
      separatorColor: '#e0e0e0',
      separatorWidth: '1px',
      separatorStyle: 'solid',
      separatorMargin: '6px 0',

      childSelector: '',
      childFlexShrink: '',
      childDisplay: ''
    }, overrides || {});
  }

  function item(id, labelFr, labelEn, aliasesFr, aliasesEn) {
    return {
      id: id,
      enabled: true,
      label: { fr: labelFr || id, en: labelEn || labelFr || id },
      selector: '',
      aliases: {
        fr: Array.isArray(aliasesFr) ? aliasesFr.join('\n') : String(aliasesFr || ''),
        en: Array.isArray(aliasesEn) ? aliasesEn.join('\n') : String(aliasesEn || '')
      },
      tooltip: { enabled: false, fr: '', en: '' },
      style: styleProfile(),
      order: 10
    };
  }

  function group(id, labelFr, labelEn, order, items) {
    return {
      id: id,
      enabled: true,
      label: { fr: labelFr, en: labelEn || labelFr },
      order: order,
      style: styleProfile(),
      items: items
    };
  }

  function presentationRule(id, labelFr, labelEn, selector, matchMode, matchFr, matchEn, style) {
    return {
      id: id,
      enabled: true,
      label: { fr: labelFr, en: labelEn || labelFr },
      selector: selector || '',
      targetName: '',
      matchMode: matchMode || 'contains',
      matchFr: matchFr || '',
      matchEn: matchEn || '',
      style: styleProfile(style)
    };
  }

  var DEFAULT_CONFIG = {
    enabled: true,
    page: {
      enabled: true,
      pageId: PAGE_ID,
      path: PAGE_PATH
    },
    hideMarcPreview: true,
    appearance: {
      showGroupTitles: false,
      hoverEnabled: true,
      hoverBackground: '#f5f7fa',
      hoverPadding: '2px 4px',
      groupGap: '0px'
    },
    groups: [
      group('identification', 'Identification', 'Identification', 10, [
        item('collection', 'Collection', 'Collection', ['Collection'], ['Collection']),
        item('serie', 'Série', 'Series', ['Série', 'Serie'], ['Series']),
        item('relie-avec', 'Relié avec', 'Bound with', ['Relié avec', 'Relie avec'], ['Bound with']),
        item('auteur-principal', 'Auteur principal', 'Main author', ['Auteur principal'], ['Main author', 'Primary author']),
        item('co-auteur', 'Co-auteur', 'Co-author', ['Co-auteur', 'Co auteur'], ['Co-author']),
        item('public', 'Public', 'Audience', ['Public'], ['Audience', 'Public']),
        item('auteur-secondaire', 'Auteur secondaire', 'Secondary author', ['Auteur secondaire'], ['Secondary author'])
      ]),
      group('details', 'Détails', 'Details', 20, [
        item('isbn', 'ISBN', 'ISBN', ['ISBN'], ['ISBN']),
        item('ean', 'EAN', 'EAN', ['EAN'], ['EAN']),
        item('creation', 'Création', 'Creation', ['Création', 'Creation'], ['Creation']),
        item('modification', 'Modification', 'Modification', ['Modification'], ['Modification']),
        item('type-document', 'Type de document', 'Document type', ['Type de document'], ['Document type', 'Material type']),
        item('pays-production', 'Pays de production', 'Country of production', ['Pays de production'], ['Country of production']),
        item('langue', 'Langue', 'Language', ['Langue'], ['Language']),
        item('edition', 'Édition', 'Edition', ['Édition', 'Edition'], ['Edition']),
        item('recompenses', 'Récompense(s)', 'Award(s)', ['Récompense(s)', 'Récompenses', 'Recompense(s)', 'Recompenses'], ['Award(s)', 'Awards']),
        item('description', 'Description', 'Description', ['Description'], ['Description'])
      ]),
      group('contenu', 'Contenu', 'Content', 30, [
        item('resume', 'Résumé', 'Summary', ['Résumé', 'Resume'], ['Summary', 'Abstract']),
        item('note-contenu', 'Note de contenu', 'Contents note', ['Note de contenu'], ['Contents note', 'Content note']),
        item('note-generale', 'Note générale', 'General note', ['Note générale', 'Note generale'], ['General note'])
      ]),
      group('classification', 'Classification', 'Classification', 40, [
        item('classement', 'Classement', 'Classification', ['Classement'], ['Classification', 'Call number']),
        item('sujet-nom-commun', 'Sujet - Nom commun', 'Subject - Topical term', ['Sujet - Nom commun'], ['Subject - Topical term', 'Subject - Common name']),
        item('sujet-indexation', 'Sujet - Indexation', 'Subject - Indexing', ['Sujet - Indexation'], ['Subject - Indexing']),
        item('historique-sudoc', 'Historique SUDOC du périodique', 'SUDOC serial history', ['Historique SUDOC du périodique', 'Historique SUDOC du periodique'], ['SUDOC serial history']),
        item('sujet-genre', 'Sujet - Genre littéraire', 'Subject - Literary genre', ['Sujet - Genre littéraire', 'Sujet - Genre litteraire'], ['Subject - Literary genre', 'Genre/Form']),
        item('personnages', 'Personnage(s)', 'Character(s)', ['Personnage(s)', 'Personnages'], ['Character(s)', 'Characters']),
        item('sujet-personne', 'Sujet - Nom de personne', 'Subject - Personal name', ['Sujet - Nom de personne'], ['Subject - Personal name']),
        item('categorie-sujet', 'Catégorie de sujet', 'Subject category', ['Catégorie de sujet', 'Categorie de sujet'], ['Subject category']),
        item('sujet-geographique', 'Sujet - Nom géographique', 'Subject - Geographic name', ['Sujet - Nom géographique', 'Sujet - Nom geographique'], ['Subject - Geographic name'])
      ]),
      group('ressources', 'Ressources', 'Resources', 50, [
        item('ressources', 'Ressources', 'Resources', ['Ressources'], ['Resources'])
      ])
    ],

    // Règles héritées du 107. Elles utilisent exactement le même moteur que
    // toutes les futures règles ajoutées par l'administrateur.
    presentationRules: [
      presentationRule(
        'legacy-107-title-actions',
        'En-tête notice — titre et actions',
        'Record header — title and actions',
        '#catalogue_detail_biblio p.first',
        'contains', '', '',
        {
          display: 'flex',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '10px',
          margin: '0 0 8px',
          childSelector: 'button',
          childFlexShrink: '0'
        }
      ),
      presentationRule(
        'legacy-107-separator-creation',
        'Séparateur avant Création notice',
        'Separator before record creation',
        '.technique .content li',
        'contains',
        'Création notice',
        'Record creation',
        {
          separatorBefore: true,
          separatorColor: '#e0e0e0',
          separatorWidth: '1px',
          separatorStyle: 'solid',
          separatorMargin: '6px 0'
        }
      ),
      presentationRule(
        'legacy-107-separator-acquisition',
        'Séparateur avant Acquisition',
        'Separator before Acquisition',
        '.technique .content li',
        'contains',
        'Acquisition',
        'Acquisition',
        {
          separatorBefore: true,
          separatorColor: '#e0e0e0',
          separatorWidth: '1px',
          separatorStyle: 'solid',
          separatorMargin: '6px 0'
        }
      ),
      presentationRule(
        'legacy-107-statistics-button',
        'Statistiques détaillées — rendu bouton',
        'Detailed statistics — button style',
        '.technique .content a[href*="guided_reports"]',
        'contains',
        'statistiques',
        'statistics',
        {
          display: 'inline-block',
          margin: '6px 0 0',
          padding: '5px 10px',
          background: '#e8f5e9',
          border: '1px solid #a5d6a7',
          borderRadius: '4px',
          color: '#2e7d32',
          fontSize: '0.80em',
          fontWeight: '600',
          textDecoration: 'none',
          hoverBackground: '#c8e6c9',
          hoverBorderColor: '#66bb6a'
        }
      )
    ]
  };

  DEFAULT_CONFIG.groups.forEach(function (g, gi) {
    g.order = (gi + 1) * 10;
    g.items.forEach(function (it, ii) { it.order = (ii + 1) * 10; });
  });

  currentConfig = clone(DEFAULT_CONFIG);

  function slug(value) {
    return String(value || '')
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'element';
  }

  function uniqueId(base, used) {
    base = base || 'element';
    var id = base, i = 2;
    while (used[id]) id = base + '-' + i++;
    used[id] = true;
    return id;
  }

  function lines(value) {
    if (Array.isArray(value)) return value.map(function (v) { return clean(v); }).filter(Boolean);
    return String(value || '').split(/\r?\n/).map(function (v) { return v.trim(); }).filter(Boolean);
  }

  function firstLine(value) {
    var xs = lines(value);
    return xs.length ? xs[0] : '';
  }

  function normalizeStyle(value) {
    return deepMerge(styleProfile(), isObject(value) ? value : {});
  }

  function normalizeRule(raw, index, usedIds) {
    raw = isObject(raw) ? raw : {};
    var labelFr = String(raw.label && raw.label.fr || raw.labelFr || ('Règle ' + (index + 1)));
    var labelEn = String(raw.label && raw.label.en || raw.labelEn || labelFr);
    return {
      id: uniqueId(slug(raw.id || labelFr || ('regle-' + (index + 1))), usedIds),
      enabled: raw.enabled !== false,
      label: { fr: labelFr, en: labelEn },
      selector: clean(raw.selector),
      targetName: clean(raw.targetName),
      matchMode: ['contains', 'exact', 'regex'].indexOf(raw.matchMode) >= 0 ? raw.matchMode : 'contains',
      matchFr: String(raw.matchFr || ''),
      matchEn: String(raw.matchEn || ''),
      style: normalizeStyle(raw.style)
    };
  }

  function normalizeConfig(config) {
    var cfg = deepMerge(DEFAULT_CONFIG, isObject(config) ? config : {});
    cfg.enabled = cfg.enabled !== false;
    cfg.page = deepMerge(DEFAULT_CONFIG.page, cfg.page || {});
    cfg.page.enabled = cfg.page.enabled !== false;
    cfg.page.pageId = PAGE_ID;
    cfg.page.path = PAGE_PATH;
    cfg.hideMarcPreview = cfg.hideMarcPreview !== false;
    cfg.appearance = deepMerge(DEFAULT_CONFIG.appearance, cfg.appearance || {});
    cfg.groups = Array.isArray(cfg.groups) ? cfg.groups : clone(DEFAULT_CONFIG.groups);

    var groupIds = Object.create(null);
    cfg.groups = cfg.groups.map(function (rawGroup, gi) {
      var g = isObject(rawGroup) ? rawGroup : {};
      var labelFr = String(g.label && g.label.fr || g.name || ('Groupe ' + (gi + 1)));
      var labelEn = String(g.label && g.label.en || labelFr);
      var gid = uniqueId(slug(g.id || labelFr || ('groupe-' + (gi + 1))), groupIds);
      var itemIds = Object.create(null);
      var items = Array.isArray(g.items) ? g.items : [];
      items = items.map(function (rawItem, ii) {
        var it = isObject(rawItem) ? rawItem : {};
        var itemLabelFr = String(it.label && it.label.fr || it.name || firstLine(it.aliases && it.aliases.fr) || ('Élément ' + (ii + 1)));
        var itemLabelEn = String(it.label && it.label.en || itemLabelFr);
        return {
          id: uniqueId(slug(it.id || itemLabelFr || ('element-' + (ii + 1))), itemIds),
          enabled: it.enabled !== false,
          label: { fr: itemLabelFr, en: itemLabelEn },
          selector: clean(it.selector),
          aliases: {
            fr: lines(it.aliases && it.aliases.fr).join('\n'),
            en: lines(it.aliases && it.aliases.en).join('\n')
          },
          tooltip: {
            enabled: Boolean(it.tooltip && it.tooltip.enabled),
            fr: String(it.tooltip && it.tooltip.fr || ''),
            en: String(it.tooltip && it.tooltip.en || '')
          },
          style: normalizeStyle(it.style),
          order: (ii + 1) * 10
        };
      });

      return {
        id: gid,
        enabled: g.enabled !== false,
        label: { fr: labelFr, en: labelEn },
        order: (gi + 1) * 10,
        style: normalizeStyle(g.style),
        items: items
      };
    });

    var ruleIds = Object.create(null);
    cfg.presentationRules = Array.isArray(cfg.presentationRules)
      ? cfg.presentationRules.map(function (rule, index) { return normalizeRule(rule, index, ruleIds); })
      : clone(DEFAULT_CONFIG.presentationRules);

    return cfg;
  }

  function detectLanguage() {
    if (window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function') {
      return window.PMKConfig.getLanguage() === 'en' ? 'en' : 'fr';
    }
    return String(document.documentElement.lang || '').toLowerCase().indexOf('en') === 0 ? 'en' : 'fr';
  }

  function normalizeText(value) {
    return String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
  }

  function directLabel(element) {
    if (!element) return '';
    var direct = null;
    try { direct = element.querySelector(':scope > strong, :scope > span.label, :scope > label'); } catch (_) {}
    if (direct) return clean(direct.textContent);

    var own = '';
    Array.prototype.forEach.call(element.childNodes || [], function (node) {
      if (node.nodeType === Node.TEXT_NODE) own += ' ' + node.textContent;
      else if (node.nodeType === Node.ELEMENT_NODE && /^(STRONG|B|SPAN|LABEL)$/i.test(node.tagName)) own += ' ' + node.textContent;
    });
    own = clean(own);
    var idx = own.indexOf(':');
    return idx >= 0 ? own.slice(0, idx).trim() : own;
  }

  function matchesAliases(li, aliases) {
    var label = normalizeText(directLabel(li));
    if (!label) return false;
    return aliases.some(function (entry) {
      var alias = normalizeText(entry);
      return alias && (label === alias || label.indexOf(alias) === 0);
    });
  }

  function safeQuery(root, selector) {
    if (!root || !selector) return [];
    try { return Array.prototype.slice.call(root.querySelectorAll(selector)); }
    catch (_) { return []; }
  }

  function resolveItemTargets(root, itemCfg, claimed) {
    var nodes = [];
    if (itemCfg.selector) nodes = safeQuery(root, itemCfg.selector);

    if (!nodes.length) {
      var aliases = lines(itemCfg.aliases && itemCfg.aliases.fr)
        .concat(lines(itemCfg.aliases && itemCfg.aliases.en));
      if (aliases.length) {
        nodes = Array.prototype.filter.call(root.querySelectorAll('li'), function (li) {
          if (li.closest('.technique')) return false;
          return matchesAliases(li, aliases);
        });
      }
    }

    return nodes.filter(function (node) {
      if (!(node instanceof Element)) return false;
      if (node.closest('.technique')) return false;
      if (claimed) {
        if (Array.from(claimed).some(function (other) { return other === node || other.contains(node) || node.contains(other); })) return false;
        claimed.add(node);
      }
      return true;
    });
  }

  function ensureStyle(cfg) {
    var style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      document.head.appendChild(style);
    }

    var hoverBg = clean(cfg.appearance.hoverBackground) || '#f5f7fa';
    var padding = clean(cfg.appearance.hoverPadding) || '2px 4px';
    var gap = clean(cfg.appearance.groupGap) || '0px';

    style.textContent = [
      '.' + CONTAINER_CLASS + '[data-pmk063="1"]{display:block;min-width:0;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-group{margin:0 0 ' + gap + ';min-width:0;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-group-list{margin:0;padding-left:0;list-style:none;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-group-title{font-size:.95em;font-weight:600;margin:.45rem 0 .2rem;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-item{border-radius:3px;padding:' + padding + ';transition:background .12s,color .12s,border-color .12s,box-shadow .12s,transform .12s;overflow-wrap:anywhere;}',
      cfg.appearance.hoverEnabled ? ('.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-item:hover{background:' + hoverBg + ';}') : '',
      '[data-pmk063-hover-style="1"]{transition:background .15s,color .15s,border-color .15s,box-shadow .15s,transform .12s;}',
      '[data-pmk063-hover-style="1"]:hover{background:var(--pmk063-hover-bg,inherit)!important;color:var(--pmk063-hover-color,inherit)!important;border-color:var(--pmk063-hover-border,currentColor)!important;box-shadow:var(--pmk063-hover-shadow,none)!important;transform:var(--pmk063-hover-transform,none)!important;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] [data-pmk063-tooltip]{position:relative;}',
      '.' + CONTAINER_CLASS + '[data-pmk063="1"] [data-pmk063-tooltip]:hover::after{content:attr(data-pmk063-tooltip);position:absolute;z-index:1080;left:0;top:100%;margin-top:3px;max-width:min(360px,80vw);padding:5px 8px;border-radius:4px;background:#343a40;color:#fff;font-size:.78rem;line-height:1.25;white-space:normal;box-shadow:0 2px 8px rgba(0,0,0,.18);pointer-events:none;}',
      '@media (max-width:767.98px){.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-item{padding:3px 2px;}.' + CONTAINER_CLASS + '[data-pmk063="1"] .pmk063-group-title{margin-top:.65rem;}}'
    ].join('\n');
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === 'function') return CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return '\\' + c; });
  }

  function cssAttr(value) {
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  function stableSelector(el) {
    if (!(el instanceof Element)) return '';
    if (el.id) return '#' + cssEscape(el.id);

    var attrs = ['data-colname', 'data-field', 'data-tag', 'name'];
    for (var i = 0; i < attrs.length; i++) {
      var val = el.getAttribute(attrs[i]);
      if (!val) continue;
      var sel = el.tagName.toLowerCase() + '[' + attrs[i] + '="' + cssAttr(val) + '"]';
      try { if (document.querySelectorAll(sel).length === 1) return sel; } catch (_) {}
    }

    var path = [];
    var cur = el;
    while (cur && cur.nodeType === 1 && cur.id !== ROOT_ID && path.length < 7) {
      var part = cur.tagName.toLowerCase();
      var classes = Array.prototype.filter.call(cur.classList || [], function (c) {
        return c && !/^pmk|^selected$|^active$|^hover$/i.test(c);
      }).slice(0, 2);
      if (classes.length) part += '.' + classes.map(cssEscape).join('.');
      var parent = cur.parentElement;
      if (parent) {
        var same = Array.prototype.filter.call(parent.children, function (x) { return x.tagName === cur.tagName; });
        if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(cur) + 1) + ')';
      }
      path.unshift(part);
      cur = parent;
    }

    var selector = '#' + ROOT_ID + ' ' + path.join(' > ');
    try { if (document.querySelectorAll(selector).length === 1) return selector; } catch (_) {}
    return '';
  }

  function rememberOriginalStyle(node) {
    if (!node || node.__pmk063StyleRemembered) return;
    node.__pmk063StyleRemembered = true;
    node.__pmk063OriginalStyle = node.getAttribute('style');
  }

  function restorePresentationStyles(root) {
    if (!root) return;

    root.querySelectorAll('[data-pmk063-style-managed="1"]').forEach(function (node) {
      if (node.__pmk063StyleRemembered) {
        if (node.__pmk063OriginalStyle === null) node.removeAttribute('style');
        else node.setAttribute('style', node.__pmk063OriginalStyle);
      }
      node.removeAttribute('data-pmk063-style-managed');
      node.removeAttribute('data-pmk063-hover-style');
      [
        '--pmk063-hover-bg', '--pmk063-hover-color', '--pmk063-hover-border',
        '--pmk063-hover-shadow', '--pmk063-hover-transform'
      ].forEach(function (name) { node.style.removeProperty(name); });
      node.__pmk063StyleRemembered = false;
      node.__pmk063OriginalStyle = null;
    });

    root.querySelectorAll('hr[data-pmk063-separator="1"]').forEach(function (node) { node.remove(); });
  }

  function makeSeparator(style, ruleId, where) {
    var hr = document.createElement('hr');
    hr.setAttribute('data-pmk063-separator', '1');
    hr.setAttribute('data-pmk063-rule', ruleId || '');
    hr.setAttribute('data-pmk063-side', where);
    hr.style.margin = clean(style.separatorMargin) || '6px 0';
    hr.style.border = 'none';
    hr.style.borderTop =
      (clean(style.separatorWidth) || '1px') + ' ' +
      (clean(style.separatorStyle) || 'solid') + ' ' +
      (clean(style.separatorColor) || '#e0e0e0');
    return hr;
  }

  function applyStyleProfile(node, rawStyle, ruleId) {
    if (!(node instanceof Element)) return;
    var style = normalizeStyle(rawStyle);
    rememberOriginalStyle(node);
    node.setAttribute('data-pmk063-style-managed', '1');

    var map = {
      display: 'display',
      alignItems: 'alignItems',
      justifyContent: 'justifyContent',
      flexWrap: 'flexWrap',
      gap: 'gap',
      margin: 'margin',
      padding: 'padding',
      background: 'background',
      color: 'color',
      border: 'border',
      borderRadius: 'borderRadius',
      fontSize: 'fontSize',
      fontWeight: 'fontWeight',
      textAlign: 'textAlign',
      textDecoration: 'textDecoration',
      boxShadow: 'boxShadow'
    };
    Object.keys(map).forEach(function (key) {
      var value = clean(style[key]);
      if (value) node.style[map[key]] = value;
    });

    if (
      clean(style.hoverBackground) || clean(style.hoverColor) ||
      clean(style.hoverBorderColor) || clean(style.hoverBoxShadow) ||
      clean(style.hoverTransform)
    ) {
      node.setAttribute('data-pmk063-hover-style', '1');
      if (clean(style.hoverBackground)) node.style.setProperty('--pmk063-hover-bg', clean(style.hoverBackground));
      if (clean(style.hoverColor)) node.style.setProperty('--pmk063-hover-color', clean(style.hoverColor));
      if (clean(style.hoverBorderColor)) node.style.setProperty('--pmk063-hover-border', clean(style.hoverBorderColor));
      if (clean(style.hoverBoxShadow)) node.style.setProperty('--pmk063-hover-shadow', clean(style.hoverBoxShadow));
      if (clean(style.hoverTransform)) node.style.setProperty('--pmk063-hover-transform', clean(style.hoverTransform));
    }

    if (style.separatorBefore && node.parentNode) {
      node.parentNode.insertBefore(makeSeparator(style, ruleId, 'before'), node);
    }
    if (style.separatorAfter && node.parentNode) {
      node.parentNode.insertBefore(makeSeparator(style, ruleId, 'after'), node.nextSibling);
    }

    var childSelector = clean(style.childSelector);
    if (childSelector) {
      var children = safeQuery(node, childSelector);
      children.forEach(function (child) {
        rememberOriginalStyle(child);
        child.setAttribute('data-pmk063-style-managed', '1');
        if (clean(style.childFlexShrink)) child.style.flexShrink = clean(style.childFlexShrink);
        if (clean(style.childDisplay)) child.style.display = clean(style.childDisplay);
      });
    }
  }

  function ruleMatches(node, rule) {
    if (!node || !rule) return false;
    var fr = clean(rule.matchFr);
    var en = clean(rule.matchEn);
    if (!fr && !en) return true;

    var text = normalizeText(node.textContent);
    var patterns = [fr, en].filter(Boolean);
    if (rule.matchMode === 'regex') {
      return patterns.some(function (pattern) {
        try { return new RegExp(pattern, 'i').test(node.textContent || ''); }
        catch (_) { return false; }
      });
    }
    if (rule.matchMode === 'exact') {
      return patterns.some(function (pattern) { return text === normalizeText(pattern); });
    }
    return patterns.some(function (pattern) { return text.indexOf(normalizeText(pattern)) !== -1; });
  }

  function applyPresentationRules(root, cfg) {
    (cfg.presentationRules || []).forEach(function (rule) {
      if (!rule || rule.enabled === false || !clean(rule.selector)) return;
      safeQuery(root, rule.selector).forEach(function (node) {
        if (ruleMatches(node, rule)) applyStyleProfile(node, rule.style, rule.id);
      });
    });
  }

  function markOrigin(node) {
    if (node.hasAttribute('data-pmk063-moved')) return;
    node.__pmk063OriginAnchor = document.createComment('pmk063-item-origin');
    node.parentNode.insertBefore(node.__pmk063OriginAnchor, node);
    node.__pmk063OriginParent = node.parentElement || null;
    node.__pmk063OriginNext = node.nextSibling || null;
    node.setAttribute('data-pmk063-moved', '1');
  }

  function restorePreviousLayout(root) {
    var old = root && root.querySelector('.' + CONTAINER_CLASS + '[data-pmk063="1"]');
    if (!old) return;

    old.querySelectorAll('[data-pmk063-moved="1"]').forEach(function (node) {
      var parent = node.__pmk063OriginParent;
      var next = node.__pmk063OriginNext;
      var origin = node.__pmk063OriginAnchor;
      if (origin && origin.parentNode) {
        origin.replaceWith(node);
      } else if (parent && document.documentElement.contains(parent)) {
        parent.insertBefore(node, next && next.parentNode === parent ? next : null);
      }
      node.__pmk063OriginAnchor = null;
      node.removeAttribute('data-pmk063-moved');
      node.removeAttribute('data-pmk063-tooltip');
      node.removeAttribute('data-pmk063-item');
      node.classList.remove('pmk063-item');
      node.__pmk063OriginParent = null;
      node.__pmk063OriginNext = null;
    });

    var anchor = old.__pmk063Anchor;
    old.remove();
    if (anchor && anchor.parentNode) anchor.remove();
  }

  function applyTooltip(node, itemCfg, lang) {
    node.removeAttribute('data-pmk063-tooltip');
    if (!itemCfg.tooltip || !itemCfg.tooltip.enabled) return;
    var value = clean(itemCfg.tooltip[lang] || itemCfg.tooltip.fr || itemCfg.tooltip.en);
    if (value) node.setAttribute('data-pmk063-tooltip', value);
  }

  function restoreMarc(root) {
    var marc = root && root.querySelector('#catalogue_detail_marc_preview');
    if (marc && marc.__pmk063OriginalDisplay !== undefined) {
      marc.style.display = marc.__pmk063OriginalDisplay;
      delete marc.__pmk063OriginalDisplay;
    }
  }

  function render() {
    if (!IS_TARGET_PAGE) return;

    var root = document.getElementById(ROOT_ID);
    if (!root) return;

    restorePresentationStyles(root);
    restorePreviousLayout(root);
    restoreMarc(root);

    var cfg = normalizeConfig(currentConfig || DEFAULT_CONFIG);
    if (!cfg.enabled || !cfg.page.enabled) return;

    ensureStyle(cfg);
    applyPresentationRules(root, cfg);

    var marc = root.querySelector('#catalogue_detail_marc_preview');
    if (marc) {
      marc.__pmk063OriginalDisplay = marc.style.display;
      if (cfg.hideMarcPreview) marc.style.display = 'none';
    }

    var lang = detectLanguage();
    var claimed = new Set();
    var resolvedGroups = [];

    cfg.groups.forEach(function (g) {
      if (!g || g.enabled === false) return;
      var resolved = [];
      (g.items || []).forEach(function (it) {
        if (!it || it.enabled === false) return;
        resolveItemTargets(root, it, claimed).forEach(function (node) {
          resolved.push({ node: node, item: it });
        });
      });
      if (resolved.length) resolvedGroups.push({ group: g, rows: resolved });
    });

    // Les règles de présentation du 107 doivent rester actives même si
    // aucune information bibliographique n'a été regroupée.
    if (!resolvedGroups.length) {
      document.dispatchEvent(new CustomEvent('pmk063:rendered', { detail: { groups: 0 } }));
      return;
    }

    var first = resolvedGroups[0].rows[0].node;
    if (!first || !first.parentNode) return;

    var anchor = document.createComment('pmk063-anchor');
    first.parentNode.insertBefore(anchor, first);

    var container = document.createElement('div');
    container.className = CONTAINER_CLASS;
    container.setAttribute('data-pmk063', '1');
    container.__pmk063Anchor = anchor;

    resolvedGroups.forEach(function (entry) {
      var groupDiv = document.createElement('section');
      groupDiv.className = 'pmk063-group';
      groupDiv.setAttribute('data-pmk063-group', entry.group.id);
      applyStyleProfile(groupDiv, entry.group.style, 'group-' + entry.group.id);

      if (cfg.appearance.showGroupTitles) {
        var title = document.createElement('div');
        title.className = 'pmk063-group-title';
        title.textContent = entry.group.label[lang] || entry.group.label.fr || entry.group.label.en || entry.group.id;
        groupDiv.appendChild(title);
      }

      var list = document.createElement('ul');
      list.className = 'pmk063-group-list';

      entry.rows.forEach(function (row) {
        markOrigin(row.node);
        row.node.classList.add('pmk063-item');
        row.node.setAttribute('data-pmk063-item', row.item.id);
        applyTooltip(row.node, row.item, lang);
        applyStyleProfile(row.node, row.item.style, 'item-' + row.item.id);
        list.appendChild(row.node);
      });

      groupDiv.appendChild(list);
      container.appendChild(groupDiv);
    });

    anchor.parentNode.insertBefore(container, anchor.nextSibling);

    document.dispatchEvent(new CustomEvent('pmk063:rendered', {
      detail: { groups: resolvedGroups.length }
    }));
  }

  function newGroup() {
    return {
      id: 'groupe-' + Date.now().toString(36),
      enabled: true,
      label: { fr: 'Nouveau groupe', en: 'New group' },
      order: 10,
      style: styleProfile(),
      items: []
    };
  }

  function newItem() {
    return {
      id: 'element-' + Date.now().toString(36),
      enabled: true,
      label: { fr: 'Nouvel élément', en: 'New element' },
      selector: '',
      aliases: { fr: '', en: '' },
      tooltip: { enabled: false, fr: '', en: '' },
      style: styleProfile(),
      order: 10
    };
  }

  function newPresentationRule() {
    return {
      id: 'presentation-' + Date.now().toString(36),
      enabled: true,
      label: { fr: 'Nouvelle règle', en: 'New rule' },
      selector: '',
      targetName: '',
      matchMode: 'contains',
      matchFr: '',
      matchEn: '',
      style: styleProfile()
    };
  }

  function pathIndex(path, key) {
    if (!Array.isArray(path)) return -1;
    var pos = path.indexOf(key);
    if (pos < 0 || pos + 1 >= path.length) return -1;
    var n = Number(path[pos + 1]);
    return Number.isInteger(n) ? n : -1;
  }

  function groupFromPath(root, path) {
    var gi = pathIndex(path, 'groups');
    return gi >= 0 && root && Array.isArray(root.groups) ? root.groups[gi] : null;
  }

  function itemFromPath(root, path) {
    var g = groupFromPath(root, path);
    var ii = pathIndex(path, 'items');
    return g && ii >= 0 && Array.isArray(g.items) ? g.items[ii] : null;
  }

  function ruleFromPath(root, path) {
    var ri = pathIndex(path, 'presentationRules');
    return ri >= 0 && root && Array.isArray(root.presentationRules) ? root.presentationRules[ri] : null;
  }

  function applyPickedMetadata(root, fieldPath, result) {
    if (!root || !result) return;

    var entry = itemFromPath(root, fieldPath);
    if (entry) {
      var targetName = clean(result.targetName);
      if (targetName) {
        if (!entry.label || typeof entry.label !== 'object') entry.label = { fr: '', en: '' };
        if (!clean(entry.label.fr) || /^Nouvel élément$/i.test(entry.label.fr)) entry.label.fr = targetName;
        if (!clean(entry.label.en) || /^New element$/i.test(entry.label.en)) entry.label.en = targetName;
        if (!entry.aliases || typeof entry.aliases !== 'object') entry.aliases = { fr: '', en: '' };
        if (!clean(entry.aliases.fr)) entry.aliases.fr = targetName;
        if (!clean(entry.aliases.en)) entry.aliases.en = targetName;
      }
      return;
    }

    var rule = ruleFromPath(root, fieldPath);
    if (rule) {
      var name = clean(result.targetName);
      rule.targetName = name || rule.targetName || result.selector || '';
      if (!rule.label || typeof rule.label !== 'object') rule.label = { fr: '', en: '' };
      if (!clean(rule.label.fr) || /^Nouvelle règle$/i.test(rule.label.fr)) rule.label.fr = name || 'Nouvelle règle';
      if (!clean(rule.label.en) || /^New rule$/i.test(rule.label.en)) rule.label.en = name || 'New rule';
    }
  }

  function pick(context) {
    var picker = window.PMKConfig && window.PMKConfig.elementPicker;
    if (!picker || typeof picker.pickForConfig !== 'function') {
      return Promise.reject(new Error('pmk_common_picker_unavailable'));
    }
    return picker.pickForConfig({
      moduleId: MODULE_ID,
      targetUrl: PAGE_PATH,
      fieldPath: context && Array.isArray(context.fieldPath) ? context.fieldPath.slice() : [],
      rootObject: context && context.rootObject ? context.rootObject : {},
      persistAfterPick: false,
      adminContext: {
        pageId: PAGE_ID,
        sectionId: Array.isArray(context && context.fieldPath) && context.fieldPath.indexOf('presentationRules') >= 0
          ? 'presentation-rules' : 'groups'
      },
      options: {
        rootSelector: '#' + ROOT_ID,
        bannerText: detectLanguage() === 'en'
          ? 'Click the Koha element to configure — Esc cancels'
          : 'Clique sur l’élément Koha à configurer — Échap annule'
      }
    });
  }

  function registerPicker() {
    if (pickerRegistered) return;
    var picker = window.PMKConfig && window.PMKConfig.elementPicker;
    if (!picker || typeof picker.register !== 'function') return;

    picker.register(MODULE_ID, {
      resolveTarget: function (candidate, request) {
        if (!candidate || !candidate.closest) return null;
        var root = document.getElementById(ROOT_ID);
        if (!root || !root.contains(candidate)) return null;
        var path = request && Array.isArray(request.fieldPath) ? request.fieldPath : [];

        if (path.indexOf('groups') >= 0 && path.indexOf('items') >= 0) {
          var li = candidate.closest('li');
          if (!li || !root.contains(li) || li.closest('.technique')) return null;
          return li;
        }

        if (candidate.closest('#pmk-config-overlay, #pmk-common-element-picker-banner')) return null;
        return candidate;
      },
      buildResult: function (candidate, result) {
        result.targetName = directLabel(candidate) || clean(candidate.getAttribute && candidate.getAttribute('title')) ||
          clean(candidate.textContent).slice(0, 120) || result.selector;
        return result;
      },
      applyPending: function (draft, pending, picked) {
        if (picked && pending && Array.isArray(pending.fieldPath)) {
          applyPickedMetadata(draft, pending.fieldPath, picked);
        }
        return normalizeConfig(draft);
      }
    });
    pickerRegistered = true;
  }

  function styleSchemaFields() {
    return [
      { key: 'style.display', type: 'text', label: { fr: 'Mode d’affichage CSS', en: 'CSS display' }, advanced: true, placeholder: { fr: 'ex. flex, block, inline-block', en: 'e.g. flex, block, inline-block' } },
      { key: 'style.alignItems', type: 'text', label: { fr: 'Alignement vertical', en: 'Align items' }, advanced: true },
      { key: 'style.justifyContent', type: 'text', label: { fr: 'Répartition horizontale', en: 'Justify content' }, advanced: true },
      { key: 'style.flexWrap', type: 'text', label: { fr: 'Retour à la ligne flex', en: 'Flex wrap' }, advanced: true },
      { key: 'style.gap', type: 'text', label: { fr: 'Espacement (gap)', en: 'Gap' }, advanced: true },
      { key: 'style.margin', type: 'text', label: { fr: 'Marges', en: 'Margin' }, advanced: true },
      { key: 'style.padding', type: 'text', label: { fr: 'Espacement interne', en: 'Padding' }, advanced: true },
      { key: 'style.background', type: 'text', label: { fr: 'Fond', en: 'Background' } },
      { key: 'style.color', type: 'color', label: { fr: 'Couleur du texte', en: 'Text color' } },
      { key: 'style.border', type: 'text', label: { fr: 'Bordure', en: 'Border' }, advanced: true },
      { key: 'style.borderRadius', type: 'text', label: { fr: 'Arrondi', en: 'Border radius' }, advanced: true },
      { key: 'style.fontSize', type: 'text', label: { fr: 'Taille du texte', en: 'Font size' } },
      { key: 'style.fontWeight', type: 'text', label: { fr: 'Graisse du texte', en: 'Font weight' }, advanced: true },
      { key: 'style.textAlign', type: 'text', label: { fr: 'Alignement du texte', en: 'Text alignment' }, advanced: true },
      { key: 'style.textDecoration', type: 'text', label: { fr: 'Décoration du texte', en: 'Text decoration' }, advanced: true },
      { key: 'style.boxShadow', type: 'text', label: { fr: 'Ombre', en: 'Box shadow' }, advanced: true },

      { key: 'style.hoverBackground', type: 'text', label: { fr: 'Fond au survol', en: 'Hover background' } },
      { key: 'style.hoverColor', type: 'color', label: { fr: 'Texte au survol', en: 'Hover text color' } },
      { key: 'style.hoverBorderColor', type: 'color', label: { fr: 'Bordure au survol', en: 'Hover border color' } },
      { key: 'style.hoverBoxShadow', type: 'text', label: { fr: 'Ombre au survol', en: 'Hover shadow' }, advanced: true },
      { key: 'style.hoverTransform', type: 'text', label: { fr: 'Transformation au survol', en: 'Hover transform' }, advanced: true, placeholder: { fr: 'ex. translateY(-1px)', en: 'e.g. translateY(-1px)' } },

      { key: 'style.separatorBefore', type: 'boolean', label: { fr: 'Ajouter un séparateur avant', en: 'Add separator before' } },
      { key: 'style.separatorAfter', type: 'boolean', label: { fr: 'Ajouter un séparateur après', en: 'Add separator after' } },
      { key: 'style.separatorColor', type: 'color', label: { fr: 'Couleur du séparateur', en: 'Separator color' }, advanced: true },
      { key: 'style.separatorWidth', type: 'text', label: { fr: 'Épaisseur du séparateur', en: 'Separator width' }, advanced: true },
      { key: 'style.separatorStyle', type: 'select', label: { fr: 'Style du séparateur', en: 'Separator style' }, advanced: true, options: [
        { value: 'solid', label: { fr: 'Continu', en: 'Solid' } },
        { value: 'dotted', label: { fr: 'Pointillé', en: 'Dotted' } },
        { value: 'dashed', label: { fr: 'Tirets', en: 'Dashed' } }
      ] },
      { key: 'style.separatorMargin', type: 'text', label: { fr: 'Marges du séparateur', en: 'Separator margin' }, advanced: true },

      { key: 'style.childSelector', type: 'text', label: { fr: 'Sous-élément à ajuster', en: 'Child element to adjust' }, advanced: true },
      { key: 'style.childFlexShrink', type: 'text', label: { fr: 'flex-shrink du sous-élément', en: 'Child flex-shrink' }, advanced: true },
      { key: 'style.childDisplay', type: 'text', label: { fr: 'display du sous-élément', en: 'Child display' }, advanced: true }
    ];
  }

  function moduleDefinition() {
    var groupItemFields = [
      { key: 'enabled', type: 'boolean', label: { fr: 'Information active', en: 'Information enabled' } },
      { key: 'label.fr', type: 'text', label: { fr: 'Nom français dans la configuration', en: 'French configuration name' } },
      { key: 'label.en', type: 'text', label: { fr: 'Nom anglais dans la configuration', en: 'English configuration name' } },
      {
        key: 'selector',
        type: 'elementPicker',
        label: { fr: 'Information à placer dans ce groupe', en: 'Information to place in this group' },
        pickLabel: { fr: 'Choisir sur la page', en: 'Choose on page' },
        emptyLabel: { fr: 'Détection par libellé / aucun élément choisi', en: 'Label detection / no element selected' },
        allowManual: true,
        pick: pick,
        onPick: applyPickedMetadata,
        help: {
          fr: 'Les valeurs historiques peuvent utiliser leurs alias FR/EN. Toute nouvelle information peut être choisie avec le picker.',
          en: 'Historical values can use FR/EN aliases. Any new information can be selected with the picker.'
        }
      },
      { key: 'aliases.fr', type: 'textarea', advanced: true, label: { fr: 'Alias français', en: 'French aliases' } },
      { key: 'aliases.en', type: 'textarea', advanced: true, label: { fr: 'Alias anglais', en: 'English aliases' } },
      { key: 'tooltip.enabled', type: 'boolean', refreshOnChange: true, label: { fr: 'Afficher une infobulle au survol', en: 'Show a tooltip on hover' } },
      { key: 'tooltip.fr', type: 'textarea', label: { fr: 'Infobulle française', en: 'French tooltip' } },
      { key: 'tooltip.en', type: 'textarea', label: { fr: 'Infobulle anglaise', en: 'English tooltip' } }
    ].concat(styleSchemaFields());

    var ruleFields = [
      { key: 'enabled', type: 'boolean', label: { fr: 'Règle active', en: 'Rule enabled' } },
      { key: 'label.fr', type: 'text', label: { fr: 'Nom français', en: 'French name' } },
      { key: 'label.en', type: 'text', label: { fr: 'Nom anglais', en: 'English name' } },
      {
        key: 'selector',
        type: 'elementPicker',
        label: { fr: 'Élément à mettre en forme', en: 'Element to style' },
        pickLabel: { fr: 'Choisir sur la page', en: 'Choose on page' },
        allowManual: true,
        pick: pick,
        onPick: applyPickedMetadata,
        help: {
          fr: 'Le même moteur s’applique aux règles historiques du 107 et aux règles ajoutées ultérieurement.',
          en: 'The same engine applies to historical 107 rules and any rules added later.'
        }
      },
      { key: 'targetName', type: 'readonly', advanced: true, label: { fr: 'Élément détecté', en: 'Detected element' } },
      {
        key: 'matchMode',
        type: 'select',
        label: { fr: 'Filtre de texte', en: 'Text filter' },
        options: [
          { value: 'contains', label: { fr: 'Contient', en: 'Contains' } },
          { value: 'exact', label: { fr: 'Correspond exactement', en: 'Exact match' } },
          { value: 'regex', label: { fr: 'Expression régulière', en: 'Regular expression' } }
        ]
      },
      { key: 'matchFr', type: 'text', label: { fr: 'Texte français à reconnaître (vide = tous)', en: 'French text to match (blank = all)' } },
      { key: 'matchEn', type: 'text', label: { fr: 'Texte anglais à reconnaître (vide = tous)', en: 'English text to match (blank = all)' } }
    ].concat(styleSchemaFields());

    return {
      id: MODULE_ID,
      schemaVersion: 4,
      name: { fr: 'Organisation des informations de la notice', en: 'Record information layout' },
      description: {
        fr: 'Regroupe les informations bibliographiques et permet de mettre en forme n’importe quel élément de detail.pl avec le même moteur. Les finitions historiques du 107 sont désormais des règles par défaut de ce module.',
        en: 'Groups bibliographic information and styles any detail.pl element using the same engine. Historical 107 finishing rules are now default rules in this module.'
      },
      category: { fr: 'Catalogue / présentation', en: 'Catalogue / presentation' },
      supportedPages: [PAGE_ID],
      prerequisites: [],
      dependencies: [],
      defaults: clone(DEFAULT_CONFIG),
      normalize: normalizeConfig,
      validate: function (config) {
        if (!config || typeof config !== 'object') {
          return { ok: false, message: detectLanguage() === 'en' ? 'Invalid module configuration.' : 'Configuration du module invalide.' };
        }
        return { ok: true };
      },
      schema: [
        { type:'custom', render:renderGroupDiagnostics },
        {
          type: 'section',
          id: 'activation',
          label: { fr: 'Activation', en: 'Activation' },
          fields: [
            { key: 'enabled', type: 'boolean', label: { fr: 'Activer le module', en: 'Enable module' } },
            { key: 'page.enabled', type: 'boolean', label: { fr: 'Activer sur catalogue/detail.pl', en: 'Enable on catalogue/detail.pl' } },
            { key: 'hideMarcPreview', type: 'boolean', label: { fr: 'Masquer l’aperçu MARC', en: 'Hide MARC preview' } }
          ]
        },
        {
          type: 'section',
          id: 'appearance',
          label: { fr: 'Présentation commune', en: 'Common presentation' },
          description: {
            fr: 'Réglages légers appliqués par défaut. Les styles propres à chaque groupe, information ou règle peuvent les compléter.',
            en: 'Lightweight common defaults. Per-group, per-item, and per-rule styles can extend them.'
          },
          fields: [
            { key: 'appearance.showGroupTitles', type: 'boolean', label: { fr: 'Afficher le titre des groupes', en: 'Show group titles' } },
            { key: 'appearance.hoverEnabled', type: 'boolean', label: { fr: 'Hover bibliographique commun', en: 'Common bibliographic hover' } },
            { key: 'appearance.hoverBackground', type: 'color', label: { fr: 'Couleur du hover commun', en: 'Common hover color' } },
            { key: 'appearance.hoverPadding', type: 'text', advanced: true, label: { fr: 'Espacement interne des lignes', en: 'Row inner spacing' } },
            { key: 'appearance.groupGap', type: 'text', advanced: true, label: { fr: 'Espace entre groupes', en: 'Space between groups' } }
          ]
        },
        {
          type: 'section',
          id: 'groups',
          label: { fr: 'Groupes et informations', en: 'Groups and information' },
          description: {
            fr: 'Tous les groupes et toutes les informations — historiques ou ajoutés plus tard — disposent des mêmes options de mise en forme.',
            en: 'Every group and information item — historical or added later — has the same styling options.'
          },
          fields: [
            {
              key: 'groups',
              type: 'repeater',
              label: { fr: 'Groupes', en: 'Groups' },
              addLabel: { fr: 'Ajouter un groupe', en: 'Add group' },
              emptyLabel: { fr: 'Aucun groupe configuré.', en: 'No group configured.' },
              reorder: true,
              newItem: newGroup,
              itemTitle: function (g, index, lang) {
                return clean(g && g.label && (g.label[lang] || g.label.fr || g.label.en)) || ('Groupe ' + (index + 1));
              },
              liveTitleKey: 'label.fr',
              fields: [
                { key: 'enabled', type: 'boolean', label: { fr: 'Groupe actif', en: 'Group enabled' } },
                { key: 'label.fr', type: 'text', label: { fr: 'Nom français', en: 'French name' } },
                { key: 'label.en', type: 'text', label: { fr: 'Nom anglais', en: 'English name' } }
              ].concat(styleSchemaFields()).concat([
                {
                  key: 'items',
                  type: 'repeater',
                  label: { fr: 'Informations placées dans ce groupe', en: 'Information placed in this group' },
                  addLabel: { fr: 'Ajouter une information', en: 'Add information' },
                  emptyLabel: { fr: 'Aucune information dans ce groupe.', en: 'No information in this group.' },
                  reorder: true,
                  newItem: newItem,
                  itemTitle: function (entry, index, lang) {
                    return clean(entry && entry.label && (entry.label[lang] || entry.label.fr || entry.label.en)) || ('Élément ' + (index + 1));
                  },
                  liveTitleKey: 'label.fr',
                  fields: groupItemFields
                }
              ])
            }
          ]
        },
        {
          type: 'section',
          id: 'presentation-rules',
          label: { fr: 'Mise en forme d’éléments de la page', en: 'Page element styling' },
          description: {
            fr: 'Moteur générique qui remplace les finitions du 107. Les quatre règles historiques sont préchargées, mais vous pouvez en ajouter autant que nécessaire avec le picker.',
            en: 'Generic engine replacing the finishing layer from 107. Four historical rules are preloaded, and any number of picker-based rules can be added.'
          },
          fields: [
            {
              key: 'presentationRules',
              type: 'repeater',
              label: { fr: 'Règles de présentation', en: 'Presentation rules' },
              addLabel: { fr: 'Ajouter une règle', en: 'Add rule' },
              emptyLabel: { fr: 'Aucune règle de présentation.', en: 'No presentation rule.' },
              reorder: true,
              newItem: newPresentationRule,
              itemTitle: function (entry, index, lang) {
                return clean(entry && entry.label && (entry.label[lang] || entry.label.fr || entry.label.en)) || ('Règle ' + (index + 1));
              },
              liveTitleKey: 'label.fr',
              fields: ruleFields
            }
          ]
        },
        {
          type: 'section',
          id: 'pages',
          label: { fr: 'Page configurée', en: 'Configured page' },
          fields: [
            { key: 'page.path', type: 'readonly', label: { fr: 'Chemin Koha', en: 'Koha path' } },
            { key: 'page.pageId', type: 'readonly', advanced: true, label: { fr: 'Identifiant fonctionnel', en: 'Functional identifier' } }
          ]
        }
      ],
      focusContext: function (main, context) {
        if (!main) return;
        var wanted = context && context.sectionId ? context.sectionId : 'groups';
        var section =
          main.querySelector('[data-pmk-section-id="' + wanted + '"]') ||
          main.querySelector('[data-pmk-section-id="groups"]');
        if (section) window.setTimeout(function () {
          section.scrollIntoView({ block: 'start', behavior: 'smooth' });
        }, 0);
      }
    };
  }

  function diagnoseGroups(config) {
    var root = document.getElementById(ROOT_ID), cfg = normalizeConfig(config || currentConfig || DEFAULT_CONFIG);
    var claimed = new Map(), rows = [], lang = detectLanguage();
    cfg.groups.forEach(function (g) {
      if (!g || g.enabled === false) return;
      (g.items || []).forEach(function (it) {
        if (!it || it.enabled === false) return;
        var label = (g.label[lang] || g.id) + ' / ' + (it.label[lang] || it.id);
        var nodes = root ? resolveItemTargets(root, it, null) : [];
        var conflicts = new Set();
        nodes.forEach(function (node) {
          var overlaps = false;
          claimed.forEach(function (owner, other) {
            if (node === other || node.contains(other) || other.contains(node)) { conflicts.add(owner); overlaps = true; }
          });
          if (!overlaps) claimed.set(node, label);
        });
        var invalid = false;
        try { if (it.selector) document.querySelector(it.selector); } catch (_) { invalid = true; }
        rows.push({label:label, count:nodes.length, conflicts:Array.from(conflicts),
          state:!IS_TARGET_PAGE || !root ? 'untested' : invalid ? 'invalid' : conflicts.size ? 'overlap' : nodes.length ? 'ok' : 'missing'});
      });
    });
    return rows;
  }

  function renderGroupDiagnostics(context) {
    var wrap = document.createElement('div'), button = document.createElement('button'), output = document.createElement('div');
    button.type = 'button'; button.className = 'btn btn-default btn-sm';
    button.textContent = 'Vérifier les informations sur cette notice';
    output.setAttribute('aria-live', 'polite');
    button.addEventListener('click', function () {
      output.replaceChildren();
      var intro = document.createElement('p');
      intro.textContent = 'Une information absente peut simplement manquer dans cette notice. En cas de concurrence, la première règle conserve la priorité. Aucun réglage n’est modifié.';
      output.appendChild(intro);
      diagnoseGroups(context.rootObject).forEach(function (row) {
        var text = row.state === 'untested' ? 'À vérifier sur une fiche détaillée de notice' :
          row.state === 'invalid' ? 'Sélecteur invalide' :
          row.state === 'missing' ? 'Information absente de cette notice' :
          row.state === 'overlap' ? 'Cible commune ou imbriquée avec ' + row.conflicts.join(', ') : row.count + ' information(s) trouvée(s)';
        var p = document.createElement('p'); p.textContent = row.label + ' : ' + text; output.appendChild(p);
      });
    });
    wrap.append(button, output); return wrap;
  }

  function registerPreview() {
    window.PMKConfig?.visualEditor?.register(MODULE_ID, {
      capabilities: {livePreview:true},
      canPreview: function () { return IS_TARGET_PAGE && !!document.getElementById(ROOT_ID); },
      previewDraft: function (draft) {
        if (!IS_TARGET_PAGE || !document.getElementById(ROOT_ID)) throw new Error('visual_preview_wrong_page');
        var before = clone(currentConfig || DEFAULT_CONFIG);
        currentConfig = normalizeConfig(deepMerge(DEFAULT_CONFIG, draft)); render();
        return function () { currentConfig = before; render(); };
      }
    });
  }

  function registerWithPMK() {
    if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function') return false;
    window.PMKConfig.registerModule(moduleDefinition());
    registerPicker();
    registerPreview();
    moduleRegistered = true;
    return true;
  }

  function mountContextButton() {
    if (!IS_TARGET_PAGE || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
    var root = document.getElementById(ROOT_ID);
    if (!root) return;
    var anchor = root.querySelector('p.first') || root.querySelector('.page-section') || root;
    window.PMKConfig.mountContextButton({
      moduleId: MODULE_ID,
      anchor: anchor,
      position: anchor === root ? 'append' : 'after',
      contextKey: 'catalogue-detail-groups',
      context: { pageId: PAGE_ID, sectionId: 'groups' }
    });
  }

  async function initializePmk() {
    if (pmkInitialized || !window.PMKConfig) return;
    pmkInitialized = true;
    registerWithPMK();

    if (!IS_TARGET_PAGE) return;

    try {
      var cfg = await window.PMKConfig.getConfig(MODULE_ID);
      currentConfig = normalizeConfig(deepMerge(DEFAULT_CONFIG, cfg || {}));
    } catch (_) {
      currentConfig = normalizeConfig(DEFAULT_CONFIG);
    }

    if (typeof window.PMKConfig.subscribe === 'function') {
      try {
        unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
          currentConfig = normalizeConfig(deepMerge(DEFAULT_CONFIG, cfg || {}));
          render();
          mountContextButton();
        });
      } catch (_) {}
    }

    render();
    mountContextButton();
  }

  function start() {
    registerWithPMK();
    if (!IS_TARGET_PAGE) return;

    currentConfig = normalizeConfig(DEFAULT_CONFIG);
    render();

    if (window.PMKConfig) initializePmk();
    else document.addEventListener('pmk:config-ready', initializePmk, { once: true });
  }

  window.PMK063 = {
    moduleId: MODULE_ID,
    version: MODULE_VERSION,
    defaults: clone(DEFAULT_CONFIG),
    getConfig: function () { return clone(currentConfig); },
    render: render,
    diagnoseGroups: diagnoseGroups,
    stableSelector: stableSelector,
    destroy: function () {
      if (!IS_TARGET_PAGE) return;
      var root = document.getElementById(ROOT_ID);
      if (root) {
        restorePresentationStyles(root);
        restorePreviousLayout(root);
        restoreMarc(root);
      }
      var style = document.getElementById(STYLE_ID);
      if (style) style.remove();
      if (typeof unsubscribe === 'function') {
        try { unsubscribe(); } catch (_) {}
        unsubscribe = null;
      }
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  window.addEventListener('pmk:config-ready', function () {
    if (!moduleRegistered) registerWithPMK();
    if (!pmkInitialized) initializePmk();
  }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("063-mis-en-page-catalogue.js");
} catch (error) { window.PMKNonPlugin.errors.push("063-mis-en-page-catalogue.js: "+error.message); console.error("[PMK] 063-mis-en-page-catalogue.js",error); };
try {
/*
 Nom du fichier: 065-gen-callnum-links.js
 Version: 2.0.1
 Date de consolidation: 2026-09-19
 Auteur: équipe PimpMyKoha / consolidation PimpMyKoha

 Description:
   Recherche progressive par cote.

   Le script conserve les deux usages historiques par défaut :
   - table des exemplaires sur catalogue/detail.pl : td.itemcallnumber ;
   - cotes des exemplaires dans catalogue/search.pl.

   Le clic natif Koha sur une cote reste intact lorsqu'il existe. Un petit
   déclencheur discret est ajouté à côté de la cote et ouvre un popover
   proposant plusieurs niveaux de recherche.

   Des cibles supplémentaires peuvent être ajoutées depuis PMK Config avec
   le picker commun « Choisir sur la page ». Le script ne possède aucun
   moteur de pick local parallèle.

   Fail-safe :
   - aucune action sur une page non configurée ;
   - sélecteur invalide ignoré ;
   - cible vide ignorée ;
   - idempotence (pas de double bouton / double listener) ;
   - MutationObserver optionnel pour les contenus ajoutés dynamiquement.
*/
(function () {
  'use strict';

  var MODULE_ID = 'callnumber-progressive-search';
  var STYLE_ID = 'pmk065-style';
  var POPOVER_ID = 'pmk065-popover';
  var PROCESSED_ATTR = 'data-pmk065-processed';
  var TRIGGER_CLASS = 'pmk065-trigger';
  var CONFIG_HOST_CLASS = 'pmk065-config-host';
  var SOURCE_ATTR = 'data-pmk065-source-value';

  var DEFAULT_CONFIG = {
    enabled: true,
    labels: {
      titleFr: 'Rechercher par cote',
      titleEn: 'Search by call number'
    },
    behavior: {
      splitMode: 'auto',
      includeFull: true,
      order: 'general-first',
      quoteQuery: false,
      observeDom: true,
      observeDelay: 120
    },
    targets: [
      {
        id: 'legacy-detail-itemcallnumber',
        enabled: true,
        labelFr: 'Cotes — table des exemplaires',
        labelEn: 'Call numbers — item table',
        pagePath: '/cgi-bin/koha/catalogue/detail.pl',
        selector: 'td.itemcallnumber',
        targetName: 'td.itemcallnumber',
        historical: true
      },
      {
        id: 'legacy-search-result-callnumber',
        enabled: true,
        labelFr: 'Cotes — résultats du catalogue',
        labelEn: 'Call numbers — catalogue results',
        pagePath: '/cgi-bin/koha/catalogue/search.pl',
        selector: 'li.result_itype_image a[href*="idx=callnum"]',
        targetName: 'Lien de cote dans les résultats',
        historical: true
      }
    ]
  };

  var currentConfig = clone(DEFAULT_CONFIG);
  var observer = null;
  var observerTimer = null;
  var activePopover = null;
  var activeTrigger = null;
  var outsideHandlerBound = false;

  function clone(value) {
    try { return JSON.parse(JSON.stringify(value)); }
    catch (_) { return value; }
  }

  function isObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value);
  }

  function merge(base, override) {
    if (Array.isArray(base)) return Array.isArray(override) ? clone(override) : clone(base);
    if (!isObject(base)) return override === undefined ? clone(base) : clone(override);
    var out = clone(base) || {};
    if (!isObject(override)) return out;
    Object.keys(override).forEach(function (key) {
      if (isObject(base[key]) && isObject(override[key])) out[key] = merge(base[key], override[key]);
      else out[key] = clone(override[key]);
    });
    return out;
  }

  function text(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function language() {
    try {
      if (window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function') {
        return window.PMKConfig.getLanguage() === 'en' ? 'en' : 'fr';
      }
      var html = String(document.documentElement.lang || '').toLowerCase();
      return html.indexOf('en') === 0 ? 'en' : 'fr';
    } catch (_) {
      return 'fr';
    }
  }

  function t(fr, en) {
    return language() === 'en' ? en : fr;
  }

  function safeSelectorAll(selector, root) {
    var value = text(selector);
    if (!value) return [];
    try { return Array.prototype.slice.call((root || document).querySelectorAll(value)); }
    catch (_) { return []; }
  }

  function targetMatchesPage(target) {
    var path = text(target && target.pagePath);
    if (!path) return false;
    return window.location.pathname === path;
  }

  function activeTargets(config) {
    var list = Array.isArray(config && config.targets) ? config.targets : [];
    return list.filter(function (target) {
      return target && target.enabled !== false && text(target.selector) && targetMatchesPage(target);
    });
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = [
      '.' + TRIGGER_CLASS + '{',
      '  display:inline-flex;align-items:center;justify-content:center;',
      '  margin-left:.12rem;padding:0 .12rem;min-width:1rem;min-height:1rem;',
      '  border:0;border-radius:.2rem;background:transparent;',
      '  color:currentColor;font-size:.78rem;line-height:1;vertical-align:baseline;cursor:pointer;',
      '  opacity:.34;transition:opacity .12s ease,background-color .12s ease;',
      '}',
      '.' + TRIGGER_CLASS + ':hover,.' + TRIGGER_CLASS + ':focus{',
      '  opacity:.9;color:currentColor;background:rgba(0,0,0,.055);text-decoration:none;outline:0;',
      '}',
      '.' + CONFIG_HOST_CLASS + '{display:inline-flex;align-items:center;margin-left:.08rem;vertical-align:middle;}',
      '.' + CONFIG_HOST_CLASS + ' .pmk-context-config{padding:.05rem .12rem!important;margin:0!important;min-width:auto!important;opacity:.32;font-size:.78rem;}',
      '.' + CONFIG_HOST_CLASS + ' .pmk-context-config:hover,.' + CONFIG_HOST_CLASS + ' .pmk-context-config:focus{opacity:.85;}',
      '#' + POPOVER_ID + '{',
      '  position:fixed;z-index:1065;display:none;box-sizing:border-box;',
      '  min-width:220px;max-width:min(360px,calc(100vw - 20px));max-height:min(70vh,520px);',
      '  overflow:auto;background:#fff;border:1px solid rgba(0,0,0,.18);border-radius:.35rem;',
      '  box-shadow:0 .25rem .75rem rgba(0,0,0,.16);color:#212529;',
      '}',
      '#' + POPOVER_ID + '.pmk065-open{display:block;}',
      '#' + POPOVER_ID + ' .pmk065-head{',
      '  display:flex;align-items:center;justify-content:space-between;gap:.6rem;',
      '  padding:.55rem .7rem;border-bottom:1px solid #e5e5e5;background:#f8f9fa;',
      '}',
      '#' + POPOVER_ID + ' .pmk065-title{font-weight:600;font-size:.95rem;}',
      '#' + POPOVER_ID + ' .pmk065-close{',
      '  border:0;background:transparent;color:#555;padding:.05rem .25rem;font-size:1.15rem;line-height:1;cursor:pointer;',
      '}',
      '#' + POPOVER_ID + ' .pmk065-list{list-style:none;margin:0;padding:.35rem 0;}',
      '#' + POPOVER_ID + ' .pmk065-list li{margin:0;padding:0;}',
      '#' + POPOVER_ID + ' .pmk065-list a{',
      '  display:flex;align-items:center;gap:.45rem;padding:.42rem .7rem;text-decoration:none;word-break:break-word;',
      '}',
      '#' + POPOVER_ID + ' .pmk065-list a:hover,#' + POPOVER_ID + ' .pmk065-list a:focus{',
      '  background:#f1f3f5;text-decoration:none;',
      '}',
      '#' + POPOVER_ID + ' .pmk065-empty{padding:.65rem .7rem;color:#6c757d;font-style:italic;}',
      '@media(max-width:575.98px){',
      '  .' + TRIGGER_CLASS + '{min-width:1.4rem;min-height:1.4rem;opacity:.58;}',
      '  #' + POPOVER_ID + '{max-width:calc(100vw - 16px);}',
      '}'
    ].join('\n');
    document.head.appendChild(style);
  }

  function ensurePopover() {
    var popover = document.getElementById(POPOVER_ID);
    if (popover) return popover;

    popover = document.createElement('div');
    popover.id = POPOVER_ID;
    popover.setAttribute('role', 'dialog');
    popover.setAttribute('aria-modal', 'false');
    popover.setAttribute('aria-hidden', 'true');
    document.body.appendChild(popover);
    return popover;
  }

  function normalizeSourceValue(value) {
    return text(value);
  }

  function sourceValueFromHref(element) {
    if (!element || !element.matches || !element.matches('a[href]')) return '';
    try {
      var url = new URL(element.getAttribute('href'), window.location.origin);
      if (url.searchParams.get('idx') !== 'callnum') return '';
      var value = normalizeSourceValue(url.searchParams.get('q') || '');
      if (value.length >= 2 && value.charAt(0) === '"' && value.charAt(value.length - 1) === '"') {
        value = value.slice(1, -1).trim();
      }
      return value;
    } catch (_) {
      return '';
    }
  }

  function sourceValueFromElement(element) {
    if (!element) return '';

    var stored = text(element.getAttribute && element.getAttribute(SOURCE_ATTR));
    if (stored) return stored;

    var fromHref = sourceValueFromHref(element);
    if (fromHref) {
      try { element.setAttribute(SOURCE_ATTR, fromHref); } catch (_) {}
      return fromHref;
    }

    try {
      var cloneNode = element.cloneNode(true);
      Array.prototype.slice.call(cloneNode.querySelectorAll('.' + TRIGGER_CLASS + ',#' + POPOVER_ID + ',.pmk-context-config,.' + CONFIG_HOST_CLASS)).forEach(function (node) {
        node.remove();
      });
      var value = normalizeSourceValue(cloneNode.textContent || '');
      if (value) element.setAttribute(SOURCE_ATTR, value);
      return value;
    } catch (_) {
      return normalizeSourceValue(element.textContent || '');
    }
  }

  function prefixesBySeparators(value, separators) {
    var source = normalizeSourceValue(value);
    if (!source) return [];
    var results = [];
    var seen = Object.create(null);

    function push(part) {
      part = normalizeSourceValue(part).replace(/[.\-/:]+$/g, '').trim();
      if (!part || seen[part]) return;
      seen[part] = true;
      results.push(part);
    }

    for (var i = 0; i < source.length; i += 1) {
      var char = source.charAt(i);
      if (separators(char)) push(source.slice(0, i));
    }
    return results;
  }

  function buildLevels(value, config) {
    var source = normalizeSourceValue(value);
    if (!source) return [];

    var behavior = (config && config.behavior) || {};
    var mode = text(behavior.splitMode) || 'auto';
    var levels = [];

    if (mode === 'full-only') {
      levels = [];
    } else if (mode === 'spaces') {
      levels = prefixesBySeparators(source, function (char) { return /\s/.test(char); });
    } else {
      levels = prefixesBySeparators(source, function (char) { return /\s/.test(char) || char === '.' || char === '/' || char === '-' || char === ':'; });
    }

    if (behavior.includeFull !== false) {
      if (levels.indexOf(source) === -1) levels.push(source);
    }

    if (!levels.length) levels.push(source);

    if (behavior.order === 'precise-first') levels.reverse();
    return levels;
  }

  function searchUrl(term, config) {
    var behavior = (config && config.behavior) || {};
    var query = normalizeSourceValue(term);
    if (behavior.quoteQuery === true) query = '"' + query.replace(/^"|"$/g, '') + '"';
    return '/cgi-bin/koha/catalogue/search.pl?idx=callnum&q=' + encodeURIComponent(query);
  }

  function closePopover(options) {
    var opts = options || {};
    var popover = activePopover || document.getElementById(POPOVER_ID);
    if (popover) {
      popover.classList.remove('pmk065-open');
      popover.setAttribute('aria-hidden', 'true');
      popover.innerHTML = '';
    }
    if (activeTrigger) activeTrigger.setAttribute('aria-expanded', 'false');
    var trigger = activeTrigger;
    activePopover = null;
    activeTrigger = null;
    if (opts.restoreFocus && trigger && typeof trigger.focus === 'function') {
      try { trigger.focus(); } catch (_) {}
    }
  }

  function positionPopover(popover, trigger) {
    if (!popover || !trigger) return;
    var rect = trigger.getBoundingClientRect();
    var margin = 8;
    var width = popover.offsetWidth || 260;
    var height = popover.offsetHeight || 180;
    var left = rect.left;
    var top = rect.bottom + 6;

    if (left + width > window.innerWidth - margin) left = Math.max(margin, window.innerWidth - width - margin);
    if (left < margin) left = margin;

    if (top + height > window.innerHeight - margin && rect.top - height - 6 >= margin) {
      top = rect.top - height - 6;
    }
    if (top < margin) top = margin;

    popover.style.left = Math.round(left) + 'px';
    popover.style.top = Math.round(top) + 'px';
  }

  function openPopover(trigger, sourceValue) {
    var levels = buildLevels(sourceValue, currentConfig);
    if (!levels.length) return;

    injectStyles();
    var popover = ensurePopover();
    closePopover();

    var head = document.createElement('div');
    head.className = 'pmk065-head';

    var title = document.createElement('div');
    title.className = 'pmk065-title';
    title.id = 'pmk065-popover-title';
    title.textContent = language() === 'en'
      ? text(currentConfig.labels && currentConfig.labels.titleEn) || 'Search by call number'
      : text(currentConfig.labels && currentConfig.labels.titleFr) || 'Rechercher par cote';
    head.appendChild(title);

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'pmk065-close';
    close.setAttribute('aria-label', t('Fermer', 'Close'));
    close.innerHTML = '<span aria-hidden="true">×</span>';
    close.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      closePopover({ restoreFocus: true });
    });
    head.appendChild(close);
    popover.appendChild(head);
    var explanation=document.createElement('p');
    explanation.className='pmk065-explanation';
    explanation.textContent=t('Cote lue : ','Read call number: ')+sourceValue+t(' — chaque lien recherche un préfixe dans l’index des cotes.',' — each link searches a prefix in the call-number index.');
    popover.appendChild(explanation);

    var list = document.createElement('ul');
    list.className = 'pmk065-list';
    levels.forEach(function (level) {
      var li = document.createElement('li');
      var link = document.createElement('a');
      link.href = searchUrl(level, currentConfig);
      link.textContent = level;
      link.title=t('Requête Koha : ','Koha query: ')+new URL(link.href).searchParams.get('q');
      link.setAttribute('data-pmk065-level', level);
      li.appendChild(link);
      list.appendChild(li);
    });
    popover.appendChild(list);

    popover.setAttribute('aria-labelledby', title.id);
    popover.setAttribute('aria-hidden', 'false');
    popover.classList.add('pmk065-open');
    trigger.setAttribute('aria-expanded', 'true');

    activePopover = popover;
    activeTrigger = trigger;
    positionPopover(popover, trigger);

    window.setTimeout(function () {
      var first = popover.querySelector('a');
      if (first && typeof first.focus === 'function') first.focus();
    }, 0);
  }

  function createTrigger(targetElement, targetConfig) {
    var sourceValue = sourceValueFromElement(targetElement);
    if (!sourceValue) return null;

    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn btn-link btn-sm ' + TRIGGER_CLASS;
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-label', t('Rechercher à partir de cette cote', 'Search from this call number'));
    button.title = t('Autres recherches par cote', 'More call-number searches');
    button.innerHTML = '<span aria-hidden="true">▾</span>';
    button.setAttribute('data-pmk065-target-id', text(targetConfig && targetConfig.id));

    button.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (activeTrigger === button && activePopover && activePopover.classList.contains('pmk065-open')) {
        closePopover({ restoreFocus: true });
        return;
      }
      openPopover(button, sourceValueFromElement(targetElement));
    });


    return button;
  }

  function attachTarget(element, targetConfig) {
    if (!element || element.nodeType !== 1) return;
    if (element.getAttribute(PROCESSED_ATTR) === '1') return;
    if (element.closest && element.closest('#' + POPOVER_ID + ',#pmk-config-overlay')) return;

    var source = sourceValueFromElement(element);
    if (!source) return;

    var trigger = createTrigger(element, targetConfig);
    if (!trigger) return;

    try {
      if (element.matches('a,button,input,select,textarea')) {
        element.insertAdjacentElement('afterend', trigger);
      } else {
        element.appendChild(trigger);
      }
      element.setAttribute(PROCESSED_ATTR, '1');
    } catch (_) {
      try { trigger.remove(); } catch (__){ }
    }
  }

  function removeContextButton() {
    safeSelectorAll('[id^="pmk-config-callnumber-progressive-search-"]').forEach(function (node) {
      try { node.remove(); } catch (_) {}
    });
    safeSelectorAll('.' + CONFIG_HOST_CLASS).forEach(function (node) {
      try { node.remove(); } catch (_) {}
    });
  }

  function cleanupInjected() {
    closePopover();
    removeContextButton();
    safeSelectorAll('.' + TRIGGER_CLASS).forEach(function (node) {
      try { node.remove(); } catch (_) {}
    });
    safeSelectorAll('[' + PROCESSED_ATTR + ']').forEach(function (node) {
      try {
        node.removeAttribute(PROCESSED_ATTR);
        node.removeAttribute(SOURCE_ATTR);
      } catch (_) {}
    });
  }

  function applyConfig() {
    cleanupInjected();
    stopObserver();

    if (!currentConfig || currentConfig.enabled === false) return;
    var targets = activeTargets(currentConfig);
    if (!targets.length) return;

    injectStyles();
    targets.forEach(function (target) {
      safeSelectorAll(target.selector).forEach(function (element) {
        attachTarget(element, target);
      });
    });

    if (currentConfig.behavior && currentConfig.behavior.observeDom !== false) startObserver();
    mountContextButton(targets);
  }

  function reprocessDynamic() {
    if (!currentConfig || currentConfig.enabled === false) return;
    activeTargets(currentConfig).forEach(function (target) {
      safeSelectorAll(target.selector).forEach(function (element) {
        if (element.getAttribute(PROCESSED_ATTR) !== '1') attachTarget(element, target);
      });
    });
  }

  function startObserver() {
    if (observer || !document.body) return;
    observer = new MutationObserver(function () {
      if (observerTimer) window.clearTimeout(observerTimer);
      var delay = Number(currentConfig && currentConfig.behavior && currentConfig.behavior.observeDelay);
      if (!Number.isFinite(delay)) delay = 120;
      delay = Math.max(30, Math.min(2000, delay));
      observerTimer = window.setTimeout(function () {
        observerTimer = null;
        reprocessDynamic();
      }, delay);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function stopObserver() {
    if (observer) {
      try { observer.disconnect(); } catch (_) {}
      observer = null;
    }
    if (observerTimer) {
      window.clearTimeout(observerTimer);
      observerTimer = null;
    }
  }

  function createContextHost(firstTarget) {
    if (!firstTarget || !firstTarget.parentNode) return null;

    var existing = null;
    if (firstTarget.matches && firstTarget.matches('td,th')) {
      existing = firstTarget.querySelector('.' + CONFIG_HOST_CLASS);
    } else if (firstTarget.parentNode && firstTarget.parentNode.querySelector) {
      existing = firstTarget.parentNode.querySelector('.' + CONFIG_HOST_CLASS + '[data-pmk065-context-host="1"]');
    }
    if (existing) return existing;

    var host = document.createElement('span');
    host.className = CONFIG_HOST_CLASS;
    host.setAttribute('data-pmk065-context-host', '1');

    try {
      // Surtout ne jamais insérer le bouton APRÈS un <td>/<th> : cela créerait
      // une cellule/colonne parasite. Le raccourci vit dans le contenu existant.
      if (firstTarget.matches && firstTarget.matches('td,th')) {
        firstTarget.appendChild(host);
      } else {
        firstTarget.insertAdjacentElement('afterend', host);
      }
      return host;
    } catch (_) {
      try { host.remove(); } catch (__){ }
      return null;
    }
  }

  function mountContextButton(targets) {
    if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
    if (!window.PMKConfig.canOpenAdmin || !window.PMKConfig.canOpenAdmin()) return;

    var firstTarget = null;
    for (var i = 0; i < targets.length && !firstTarget; i += 1) {
      var found = safeSelectorAll(targets[i].selector);
      if (found.length) firstTarget = found[0];
    }
    if (!firstTarget) return;

    var host = createContextHost(firstTarget);
    if (!host) return;

    try {
      window.PMKConfig.mountContextButton({
        moduleId: MODULE_ID,
        anchor: host,
        contextKey: 'page-' + window.location.pathname,
        context: {
          sectionId: 'targets',
          pagePath: window.location.pathname
        }
      });
    } catch (_) {}
  }

  function bindGlobalHandlers() {
    if (outsideHandlerBound) return;
    outsideHandlerBound = true;

    document.addEventListener('click', function (event) {
      if (!activePopover) return;
      if (activePopover.contains(event.target)) return;
      if (activeTrigger && activeTrigger.contains(event.target)) return;
      closePopover();
    }, true);

    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape' || !activePopover) return;
      event.preventDefault();
      closePopover({ restoreFocus: true });
    }, true);

    window.addEventListener('resize', function () {
      if (activePopover && activeTrigger) positionPopover(activePopover, activeTrigger);
    });
    window.addEventListener('scroll', function () {
      if (activePopover && activeTrigger) positionPopover(activePopover, activeTrigger);
    }, true);
  }

  function loadWithPMK() {
    if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') return false;

    window.PMKConfig.getConfig(MODULE_ID).then(function (config) {
      currentConfig = merge(DEFAULT_CONFIG, config || {});
      applyConfig();
    }).catch(function () {
      currentConfig = clone(DEFAULT_CONFIG);
      applyConfig();
    });

    if (typeof window.PMKConfig.subscribe === 'function') {
      window.PMKConfig.subscribe(MODULE_ID, function (config) {
        currentConfig = merge(DEFAULT_CONFIG, config || {});
        applyConfig();
      });
    }
    return true;
  }

  function boot() {
    bindGlobalHandlers();

    if (loadWithPMK()) return;

    // Mode dégradé : le script garde ses valeurs historiques si le socle PMK
    // n'est pas chargé. Dès que PMK Config devient disponible, on recharge la
    // configuration centrale et on remplace proprement ce rendu temporaire.
    currentConfig = clone(DEFAULT_CONFIG);
    applyConfig();

    window.addEventListener('pmk:config-ready', function () {
      loadWithPMK();
    }, { once: true });
  }

  window.PMK065 = {
    moduleId: MODULE_ID,
    defaults: clone(DEFAULT_CONFIG),
    refresh: function () { applyConfig(); },
    buildLevels: function (value) { return buildLevels(value, currentConfig); },
    getConfig: function () { return clone(currentConfig); }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();

;window.PMKNonPlugin.loaded.push("065-gen-callnum-links.js");
} catch (error) { window.PMKNonPlugin.errors.push("065-gen-callnum-links.js: "+error.message); console.error("[PMK] 065-gen-callnum-links.js",error); };
try {
/*
 Nom du fichier : 066-067-lists-manager-pmk-loader.js
 Version : 1.1.0
 Date : 2026-10-01

 Rôle :
 - pilote le chargement du module historique 066-067 ;
 - conserve l'activation/désactivation via PimpMyKoha ;
 - expose une passerelle stable PMKPersonalLists ;
 - relaie l'API runtime du gestionnaire pour les autres modules PMK,
   notamment 142 Bibliographies & publications.
*/
(function () {
    'use strict';

    if (window.__PMK_PERSONAL_LISTS_LOADER__) return;
    window.__PMK_PERSONAL_LISTS_LOADER__ = true;

    const MODULE_ID = 'personal-lists-manager';
    const RUNTIME_SCRIPT_ID = 'pmk-personal-lists-runtime-script';
    const DISABLED_STYLE_ID = 'pmk-personal-lists-disabled-style';
    const SCRIPT_URL = (window.PMKPlugin?.assetUrl ? window.PMKPlugin.assetUrl('066-067-lists-manager.js') : '/public/koha-scripts/066-067-lists-manager.js');

    let currentConfig = { enabled: true };
    let configRegistered = false;
    let loadingPromise = null;
    let unsubscribe = null;

    function runtime() {
        return window.PMKPersonalListsRuntime || null;
    }

    function dispatchState(extra) {
        try {
            window.dispatchEvent(new CustomEvent('pmk:personal-lists-state', {
                detail: Object.assign({
                    moduleId: MODULE_ID,
                    enabled: currentConfig.enabled !== false,
                    loaded: !!window.__KX_TEMP_LISTS_MANAGER__,
                    available: typeof window.toggleSidebar5 === 'function',
                    runtimeAvailable: !!runtime(),
                    runtimeVersion: runtime()?.version || ''
                }, extra || {})
            }));
        } catch (_) {}
    }

    function setDisabledMask(disabled) {
        let style = document.getElementById(DISABLED_STYLE_ID);
        if (!style) {
            style = document.createElement('style');
            style.id = DISABLED_STYLE_ID;
            style.textContent = `
                html.pmk-personal-lists-disabled #kx-temp-lists-panel,
                html.pmk-personal-lists-disabled #bottomActionBar #sidebar5,
                html.pmk-personal-lists-disabled .kx-temp-list-toggle,
                html.pmk-personal-lists-disabled .kx-temp-list-menu,
                html.pmk-personal-lists-disabled .kx-temp-lists-menu,
                html.pmk-personal-lists-disabled [data-kx-temp-list-action] {
                    display: none !important;
                }
            `;
            document.head.appendChild(style);
        }

        document.documentElement.classList.toggle('pmk-personal-lists-disabled', !!disabled);

        if (disabled) {
            const panel = document.getElementById('kx-temp-lists-panel');
            if (panel) {
                panel.classList.remove('is-open');
                panel.setAttribute('aria-hidden', 'true');
            }
        }
    }

    function existingRuntimeScript() {
        return document.getElementById(RUNTIME_SCRIPT_ID) ||
            Array.from(document.scripts || []).find(function (script) {
                return /(?:^|\/)066-067-lists-manager\.js(?:\?|$)/.test(String(script.src || ''));
            }) || null;
    }

    function waitForRuntime(timeoutMs) {
        if (runtime()) return Promise.resolve(runtime());

        return new Promise(function (resolve) {
            const started = Date.now();
            let timer = null;

            function finish(value) {
                if (timer) clearInterval(timer);
                window.removeEventListener('pmk:personal-lists-runtime-ready', onReady);
                resolve(value || null);
            }

            function onReady() {
                finish(runtime());
            }

            window.addEventListener('pmk:personal-lists-runtime-ready', onReady);

            timer = setInterval(function () {
                if (runtime()) return finish(runtime());
                if (Date.now() - started >= (timeoutMs || 12000)) finish(null);
            }, 60);
        });
    }

    function loadHistoricalModule() {
        if (currentConfig.enabled === false) {
            setDisabledMask(true);
            dispatchState({ reason: 'disabled' });
            return Promise.resolve(false);
        }

        setDisabledMask(false);

        if (window.__KX_TEMP_LISTS_MANAGER__) {
            dispatchState({ reason: 'already-loaded' });
            return Promise.resolve(true);
        }

        if (loadingPromise) return loadingPromise;

        const existing = existingRuntimeScript();
        if (existing && existing.id !== RUNTIME_SCRIPT_ID) {
            loadingPromise = new Promise(function (resolve) {
                let attempts = 0;
                const timer = window.setInterval(function () {
                    attempts += 1;
                    if (window.__KX_TEMP_LISTS_MANAGER__ || attempts >= 100) {
                        window.clearInterval(timer);
                        loadingPromise = null;
                        dispatchState({
                            reason: window.__KX_TEMP_LISTS_MANAGER__ ? 'legacy-direct-load' : 'legacy-load-timeout'
                        });
                        resolve(!!window.__KX_TEMP_LISTS_MANAGER__);
                    }
                }, 50);
            });
            return loadingPromise;
        }

        loadingPromise = new Promise(function (resolve) {
            const script = existing || document.createElement('script');
            script.id = RUNTIME_SCRIPT_ID;
            script.src = SCRIPT_URL;
            script.async = true;
            script.dataset.pmkControlled = '1';

            script.addEventListener('load', function () {
                loadingPromise = null;
                setDisabledMask(currentConfig.enabled === false);
                dispatchState({ reason: 'loaded' });
                resolve(true);
            }, { once: true });

            script.addEventListener('error', function () {
                loadingPromise = null;
                dispatchState({ reason: 'load-error' });
                resolve(false);
            }, { once: true });

            if (!script.isConnected) document.head.appendChild(script);
        });

        return loadingPromise;
    }

    async function ensureRuntime() {
        if (currentConfig.enabled === false) return null;
        const loaded = await loadHistoricalModule();
        if (!loaded) return null;
        return await waitForRuntime(12000);
    }

    async function openLists() {
        if (currentConfig.enabled === false) return false;
        const loaded = await loadHistoricalModule();
        if (!loaded) return false;

        if (typeof window.toggleSidebar5 === 'function') {
            window.toggleSidebar5();
            return true;
        }
        return false;
    }

    function applyConfig(config) {
        currentConfig = Object.assign({ enabled: true }, config || {});
        window.PMKPersonalListsOptions=currentConfig;
        const disabled = currentConfig.enabled === false;
        setDisabledMask(disabled);
        if (!disabled) loadHistoricalModule();
        dispatchState({ reason: 'config' });
    }

    function registerWithPMK() {
        if (!window.PMKConfig || configRegistered) return false;
        configRegistered = true;

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr: 'Listes de travail', en: 'Personal lists manager' },
            description: {
                fr: 'Profils nommés partagés, ou listes privées liées au compte Koha selon le mode choisi. Les bibliographies utilisent le même profil.',
                en: 'Enables or disables synchronized personal lists and exposes a data bridge to other PimpMyKoha modules.'
            },
            category: { fr: 'Outils', en: 'Tools' },
            defaults: { enabled: true, identityMode:'named' },
            schema: [{type:'section',id:'identity',label:{fr:'Propriété des listes',en:'List ownership'},fields:[{key:'identityMode',type:'select',label:{fr:'Identification — recharger après modification',en:'Identity — reload after changes'},help:{fr:'Historique : profils nommés partagés, accessibles aux agents. Compte Koha : profil privé imposé par le serveur. Les anciens profils sont conservés ; leur attribution se fait explicitement dans l’outil de migration.',en:'Historic named profiles are shared. Account profiles are private and enforced by the server. Existing profiles remain available in historic mode.'},options:[{value:'named',label:{fr:'Profils nommés partagés (historique)',en:'Shared named profiles (historic)'}},{value:'koha',label:{fr:'Compte Koha connecté — privé',en:'Authenticated Koha account — private'}}]}]}]
        });

        window.PMKConfig.getConfig(MODULE_ID)
            .then(applyConfig)
            .catch(function () { applyConfig({ enabled: true }); });

        if (typeof window.PMKConfig.subscribe === 'function') {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
        }
        return true;
    }

    window.PMKPersonalLists = {
        moduleId: MODULE_ID,
        scriptUrl: SCRIPT_URL,

        get enabled() { return currentConfig.enabled !== false; },
        get loaded() { return !!window.__KX_TEMP_LISTS_MANAGER__; },
        get runtimeAvailable() { return !!runtime(); },

        ensureLoaded: loadHistoricalModule,
        ensureRuntime: ensureRuntime,
        open: openLists,

        async getState() {
            const api = await ensureRuntime();
            return api?.getState?.() || null;
        },

        async getCurrentUser() {
            const api = await ensureRuntime();
            return api?.getCurrentUser?.() || null;
        },

        async getLists(type) {
            const api = await ensureRuntime();
            return api?.getLists?.(type) || [];
        },

        async getList(listId) {
            const api = await ensureRuntime();
            return api?.getList?.(listId) || null;
        },

        async getEntries(listId) {
            const api = await ensureRuntime();
            return api?.getEntries?.(listId) || [];
        },

        async getActiveList(type) {
            const api = await ensureRuntime();
            return api?.getActiveList?.(type) || null;
        },

        async getActiveEntries(type) {
            const api = await ensureRuntime();
            return api?.getActiveEntries?.(type) || [];
        },

        async getStorageContext() {
            const api=await ensureRuntime();
            return api?.getStorageContext?.() || null;
        },

        refreshState: function () {
            dispatchState({ reason: 'manual-refresh' });
        }
    };

    function bootstrap() {
        if (registerWithPMK()) return;

        window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });

        let tries = 0;
        const timer = window.setInterval(function () {
            tries += 1;
            if (registerWithPMK() || tries >= 100) {
                window.clearInterval(timer);
                if (!configRegistered) {
                    currentConfig = { enabled: true };
                    setDisabledMask(false);
                    loadHistoricalModule();
                }
            }
        }, 50);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    } else {
        bootstrap();
    }

    window.addEventListener('beforeunload', function () {
        if (typeof unsubscribe === 'function') {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("066-067-lists-manager-pmk-loader.js");
} catch (error) { window.PMKNonPlugin.errors.push("066-067-lists-manager-pmk-loader.js: "+error.message); console.error("[PMK] 066-067-lists-manager-pmk-loader.js",error); };
try {
/*
 Nom du fichier : 068-blinking-barcode.js
 Module PMK      : Repérage des codes-barres
 ID PMK          : barcode-highlights
 Version         : 3.0.0-pmk-isolated
 Date            : 2026-09-20

 Objectif :
 - conserver les usages historiques du 068 ;
 - fonctionner indépendamment du 036 ;
 - distinguer clairement :
   1) le dernier code-barres recherché ;
   2) les codes-barres mémorisés depuis une liste d'exemplaires ;
 - permettre pour chacun : couleurs, clignotement oui/non et vitesse ;
 - ne jamais réécrire innerHTML pour surligner du texte.
*/
(function (window, document) {
    "use strict";

    const MODULE_ID = "barcode-highlights";
    const VERSION = "3.0.0-pmk-isolated";
    const STYLE_ID = "pmk068-barcode-style";
    const GENERATED_ATTR = "data-pmk068-generated";
    const SEARCH_KEY = "searchbox_value";
    const CODES_KEY = "codesBarres";
    const NUMERIC_RX = /^\d{10,}$/;
    const DR_RX = /^DR\d{10,}$/i;
    const SEARCH_RX = /^(?:\d{6,}|DR\d{6,})$/i;

    const DEFAULTS = {
        enabled: true,
        lastSearch: {
            enabled: true,
            backgroundColor: "#fff36a",
            textColor: "#202020",
            blink: false,
            speedMs: 1050
        },
        remembered: {
            enabled: true,
            backgroundColor: "#ffae2b",
            textColor: "#111111",
            blink: true,
            speedMs: 1050,
            retentionHours: 24
        },
        exactMatch: true,
        selectors: {
            collectedTable: "#item_table",
            detailTable: "#holdings_table",
            holdsQueueTable: "#holds_table"
        }
    };

    let config = clone(DEFAULTS);
    let unsubscribe = null;
    const observers = new Map();

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function clamp(value, fallback, min, max) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.max(min, Math.min(max, n));
    }
    function merge(base, extra) {
        const out = clone(base);
        if (!extra || typeof extra !== "object") return out;
        Object.keys(extra).forEach(function (key) {
            const v = extra[key];
            if (v && typeof v === "object" && !Array.isArray(v) && out[key] && typeof out[key] === "object" && !Array.isArray(out[key])) {
                out[key] = merge(out[key], v);
            } else if (v !== undefined) out[key] = v;
        });
        return out;
    }
    function normalize(raw) {
        const cfg = merge(DEFAULTS, raw || {});
        cfg.enabled = cfg.enabled !== false;
        cfg.exactMatch = cfg.exactMatch !== false;
        ["lastSearch", "remembered"].forEach(function (key) {
            cfg[key].enabled = cfg[key].enabled !== false;
            cfg[key].blink = cfg[key].blink === true;
            cfg[key].speedMs = clamp(cfg[key].speedMs, 1050, 150, 10000);
            cfg[key].backgroundColor = String(cfg[key].backgroundColor || DEFAULTS[key].backgroundColor);
            cfg[key].textColor = String(cfg[key].textColor || DEFAULTS[key].textColor);
        });
        cfg.remembered.retentionHours = clamp(cfg.remembered.retentionHours, 24, 1, 8760);
        cfg.selectors = merge(DEFAULTS.selectors, cfg.selectors || {});
        return cfg;
    }
    function safeGet(key, fallback) {
        try { const v = localStorage.getItem(key); return v == null ? fallback : v; }
        catch (_) { return fallback; }
    }
    function safeSet(key, value) {
        try { localStorage.setItem(key, value); return true; }
        catch (_) { return false; }
    }
    function readCodeEntries() {
        try {
            const arr = JSON.parse(safeGet(CODES_KEY, "[]"));
            if (!Array.isArray(arr)) return [];
            const cutoff = Date.now() - config.remembered.retentionHours * 3600000;
            const entries = arr.map(function (entry) {
                if (entry && typeof entry === "object") return { code:String(entry.code || "").trim(), at:Number(entry.at) || 0, source:String(entry.source || "") };
                return { code:String(entry || "").trim(), at:0, source:"historique" };
            }).filter(function (entry) { return entry.code && (!entry.at || entry.at >= cutoff); });
            const unique = new Map(); entries.forEach(function (entry) { if (!unique.has(entry.code) || unique.get(entry.code).at < entry.at) unique.set(entry.code, entry); });
            const cleaned = Array.from(unique.values());
            if (cleaned.length !== arr.length || arr.some(function (entry) { return typeof entry === "string"; })) safeSet(CODES_KEY, JSON.stringify(cleaned));
            return cleaned;
        } catch (_) { return []; }
    }
    function readCodes() { return readCodeEntries().map(function (entry) { return entry.code; }); }
    function escapeRx(value) { return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

    function unwrapGenerated() {
        document.querySelectorAll("[" + GENERATED_ATTR + "]").forEach(function (span) {
            const parent = span.parentNode;
            if (!parent) return;
            parent.replaceChild(document.createTextNode(span.textContent || ""), span);
            parent.normalize();
        });
    }
    function textNodes(root) {
        if (!root) return [];
        const out = [];
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode: function (node) {
                if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                const p = node.parentElement;
                if (!p || p.closest("script,style,noscript,textarea,input,select,option,button,svg,[contenteditable='true'],[" + GENERATED_ATTR + "]")) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let n; while ((n = walker.nextNode())) out.push(n);
        return out;
    }
    function highlight(root, term, className, sourceLabel) {
        if (!root || !term) return 0;
        const rx = new RegExp(escapeRx(term), "gi");
        let count = 0;
        textNodes(root).forEach(function (node) {
            const text = node.nodeValue || "";
            if (!rx.test(text)) { rx.lastIndex = 0; return; }
            rx.lastIndex = 0;
            const frag = document.createDocumentFragment();
            let last = 0, match;
            while ((match = rx.exec(text))) {
                if (config.exactMatch && ((match.index > 0 && /[A-Za-z0-9]/.test(text.charAt(match.index - 1))) || (match.index + match[0].length < text.length && /[A-Za-z0-9]/.test(text.charAt(match.index + match[0].length))))) continue;
                if (match.index > last) frag.appendChild(document.createTextNode(text.slice(last, match.index)));
                const span = document.createElement("span");
                span.setAttribute(GENERATED_ATTR, "1");
                span.className = className;
                span.textContent = match[0];
                span.setAttribute("data-pmk068-source", sourceLabel || "");
                span.title = sourceLabel || "";
                frag.appendChild(span);
                last = match.index + match[0].length;
                count += 1;
                if (!match[0].length) rx.lastIndex += 1;
            }
            if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
            node.parentNode.replaceChild(frag, node);
            rx.lastIndex = 0;
        });
        return count;
    }

    function injectStyle() {
        let style = document.getElementById(STYLE_ID);
        if (!style) { style = document.createElement("style"); style.id = STYLE_ID; document.head.appendChild(style); }
        const l = config.lastSearch;
        const r = config.remembered;
        style.textContent = `
            @keyframes pmk068LastBlink { 0%,100%{opacity:1} 50%{opacity:.35} }
            @keyframes pmk068RememberedBlink { 0%,100%{opacity:1;box-shadow:0 0 0 1px rgba(0,0,0,.15)} 50%{opacity:.38;box-shadow:0 0 8px 2px rgba(0,0,0,.18)} }
            .pmk068-last-search { background:${l.backgroundColor}; color:${l.textColor}; border-radius:3px; padding:0 .16em; ${l.blink ? `animation:pmk068LastBlink ${l.speedMs}ms ease-in-out infinite;` : ""} }
            .pmk068-remembered { background:${r.backgroundColor}; color:${r.textColor}; border-radius:3px; padding:0 .16em; font-weight:700; ${r.blink ? `animation:pmk068RememberedBlink ${r.speedMs}ms ease-in-out infinite;` : ""} }
            @media (prefers-reduced-motion: reduce) { .pmk068-last-search,.pmk068-remembered { animation:none !important; opacity:1 !important; } }
        `;
    }

    function collectCodes() {
        const path = location.pathname || "";
        if (!path.endsWith("itemsearch.pl") && !path.endsWith("moremember.pl")) return;
        const table = document.querySelector(config.selectors.collectedTable);
        if (!table) return;
        const codes = [];
        table.querySelectorAll("a").forEach(function (a) {
            const value = String(a.textContent || "").trim();
            if ((path.endsWith("itemsearch.pl") && NUMERIC_RX.test(value)) || (path.endsWith("moremember.pl") && (NUMERIC_RX.test(value) || DR_RX.test(value)))) codes.push(value);
        });
        const now = Date.now();
        safeSet(CODES_KEY, JSON.stringify(Array.from(new Set(codes)).map(function (code) { return { code:code, at:now, source:path.endsWith("itemsearch.pl") ? "Recherche d’exemplaires" : "Dossier adhérent" }; })));
    }

    function captureSearchFromForm(event) {
        const form = event && event.target;
        if (!form || form.nodeType !== 1) return;
        const input = form.querySelector("#search-form, input[name='q'], input[type='search'], #findborrower, #findborrower_main");
        const value = input ? String(input.value || "").trim() : "";
        if (SEARCH_RX.test(value)) safeSet(SEARCH_KEY, value);
    }

    function applyHighlights() {
        unwrapGenerated();
        if (config.enabled === false) return;
        injectStyle();
        collectCodes();
        const path = location.pathname || "";
        const search = String(safeGet(SEARCH_KEY, "") || "").trim();
        if (path.endsWith("detail.pl")) {
            const table = document.querySelector(config.selectors.detailTable);
            if (!table) return;
            if (config.remembered.enabled !== false) readCodeEntries().sort(function (a,b){return b.code.length-a.code.length;}).forEach(function (entry) { highlight(table, entry.code, "pmk068-remembered", "Code-barres mémorisé localement · " + (entry.source || "source historique")); });
            if (config.lastSearch.enabled !== false && SEARCH_RX.test(search)) highlight(table, search, "pmk068-last-search", "Dernier code-barres recherché dans cet navigateur");
        } else if (path.endsWith("view_holdsqueue.pl")) {
            const table = document.querySelector(config.selectors.holdsQueueTable);
            if (table && config.lastSearch.enabled !== false && SEARCH_RX.test(search)) highlight(table, search, "pmk068-last-search", "Dernier code-barres recherché dans cet navigateur");
        }
    }

    function observe(selector) {
        const root = document.querySelector(selector);
        if (!root || observers.has(root)) return;
        let timer = null;
        const obs = new MutationObserver(function (mutations) {
            if (!mutations.some(function (m) { return m.type === "childList" && (m.addedNodes.length || m.removedNodes.length); })) return;
            clearTimeout(timer); timer = setTimeout(applyHighlights, 100);
        });
        obs.observe(root, { childList: true, subtree: true });
        observers.set(root, obs);
    }

    function validate(raw) {
        const cfg = normalize(raw);
        if (cfg.lastSearch.speedMs < 150 || cfg.remembered.speedMs < 150) return { ok:false, message:"La vitesse de clignotement doit être au moins de 150 ms." };
        return { ok:true };
    }

    function definition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr:"Repérage des codes-barres", en:"Barcode highlighting" },
            description: { fr:"Repère visuellement le dernier code-barres recherché et les codes-barres mémorisés. Le module fonctionne indépendamment du 036.", en:"Highlights the last searched barcode and remembered barcodes. This module works independently from module 036." },
            category: { fr:"Catalogue / circulation", en:"Catalog / circulation" },
            supportedPages:["catalogue.detail","catalogue.itemsearch","members.moremember","circ.holdsqueue"],
            prerequisites:[], dependencies:[], defaults:clone(DEFAULTS), normalize:normalize, validate:validate,
            schema:[
                { type:"section", id:"general", label:{fr:"Activation",en:"Activation"}, fields:[{key:"enabled",type:"boolean",label:{fr:"Activer le repérage des codes-barres",en:"Enable barcode highlighting"}}] },
                { type:"section", id:"lastSearch", label:{fr:"Dernier code-barres recherché",en:"Last searched barcode"}, description:{fr:"Repère le code-barres de la dernière recherche. Cette fonction ne dépend pas du module 036 : le 068 mémorise lui-même les recherches code-barres qu’il observe.",en:"Highlights the last barcode search. This does not depend on module 036; module 068 records barcode searches itself when observed."}, fields:[
                    {key:"lastSearch.enabled",type:"boolean",label:{fr:"Activer ce repérage",en:"Enable this highlight"}},
                    {key:"lastSearch.backgroundColor",type:"color",label:{fr:"Couleur de fond",en:"Background color"}},
                    {key:"lastSearch.textColor",type:"color",label:{fr:"Couleur du texte",en:"Text color"}},
                    {key:"lastSearch.blink",type:"boolean",label:{fr:"Faire clignoter",en:"Blink"}},
                    {key:"lastSearch.speedMs",type:"number",min:150,max:10000,label:{fr:"Vitesse du clignotement (ms)",en:"Blink speed (ms)"}}
                ]},
                { type:"section", id:"remembered", label:{fr:"Codes-barres mémorisés",en:"Remembered barcodes"}, description:{fr:"Repère les codes collectés depuis itemsearch.pl ou moremember.pl. Par défaut, ceux-ci clignotent alors que le dernier code recherché reste fixe.",en:"Highlights codes collected from itemsearch.pl or moremember.pl. By default these blink while the last searched barcode stays fixed."}, fields:[
                    {key:"remembered.enabled",type:"boolean",label:{fr:"Activer ce repérage",en:"Enable this highlight"}},
                    {key:"remembered.backgroundColor",type:"color",label:{fr:"Couleur de fond",en:"Background color"}},
                    {key:"remembered.textColor",type:"color",label:{fr:"Couleur du texte",en:"Text color"}},
                    {key:"remembered.blink",type:"boolean",label:{fr:"Faire clignoter",en:"Blink"}},
                    {key:"remembered.speedMs",type:"number",min:150,max:10000,label:{fr:"Vitesse du clignotement (ms)",en:"Blink speed (ms)"}},
                    {key:"remembered.retentionHours",type:"number",min:1,max:8760,label:{fr:"Durée de mémorisation dans ce navigateur (heures)",en:"Retention in this browser (hours)"}},
                    {type:"action",label:{fr:"Mémoire locale",en:"Local memory"},buttonLabel:{fr:"Effacer les codes mémorisés",en:"Clear remembered barcodes"},action:function(){safeSet(CODES_KEY,"[]");safeSet(SEARCH_KEY,"");applyHighlights();return {message:(document.documentElement.lang||"").toLowerCase().startsWith("en")?"Barcode memory cleared in this browser.":"Mémoire des codes-barres effacée sur ce navigateur."};}}
                ]},
                { type:"section", id:"advanced", advanced:true, label:{fr:"Sélecteurs techniques",en:"Technical selectors"}, fields:[
                    {key:"exactMatch",type:"boolean",label:{fr:"Exiger un code-barres complet",en:"Require a complete barcode"},help:{fr:"Évite de repérer un code présent seulement à l’intérieur d’un identifiant plus long.",en:"Avoids highlighting a code found only inside a longer identifier."}},
                    {key:"selectors.collectedTable",type:"text",label:{fr:"Table de collecte",en:"Collection table"}},
                    {key:"selectors.detailTable",type:"text",label:{fr:"Table exemplaires détail",en:"Detail holdings table"}},
                    {key:"selectors.holdsQueueTable",type:"text",label:{fr:"Table file de réservations",en:"Holds queue table"}}
                ]}
            ]
        };
    }

    function apply(raw) {
        config = normalize(raw);
        applyHighlights();
        observe(config.selectors.collectedTable);
        observe(config.selectors.detailTable);
        observe(config.selectors.holdsQueueTable);
    }
    function register() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) {}
        if (typeof window.PMKConfig.subscribe === "function" && !unsubscribe) {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, apply); } catch (_) {}
        }
        return true;
    }
    function load() {
        register();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(clone(DEFAULTS));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).then(normalize).catch(function(){ return clone(DEFAULTS); });
    }
    function start() {
        document.addEventListener("submit", captureSearchFromForm, true);
        if (register()) load().then(apply); else apply(DEFAULTS);
        window.addEventListener("pmk:config-ready", function(){ load().then(apply); }, { once:true });
        setTimeout(applyHighlights, 400);
        setTimeout(applyHighlights, 1400);
    }

    window.PMK068BarcodeHighlights = { moduleId:MODULE_ID, version:VERSION, refresh:function(){return load().then(apply);} };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once:true }); else start();
})(window, document);

;window.PMKNonPlugin.loaded.push("068-blinking-barcode.js");
} catch (error) { window.PMKNonPlugin.errors.push("068-blinking-barcode.js: "+error.message); console.error("[PMK] 068-blinking-barcode.js",error); };
try {
/*
 Nom du fichier : 070-address-autocomplete-memberentry.js
 Version : 3.1.2
 Date : 2026-09-19
 Auteur : équipe PimpMyKoha / consolidation PimpMyKoha

 Module PimpMyKoha : 070 — Autocomplétion des adresses

 Fonction :
   - ajoute une autocomplétion d'adresse sur members/memberentry.pl ;
   - utilise l'API d'autocomplétion de la Géoplateforme ;
   - peut favoriser les résultats proches d'une ville de référence sans exclure
     les autres résultats ;
   - l'utilisateur ne saisit jamais de coordonnées : la ville de référence est
     résolue automatiquement puis mise en cache localement ;
   - remplit l'adresse, le code postal et la ville ;
   - restaure les adresses complètes numérotées : le numéro (bis/ter compris)
     est conservé dans le champ Adresse comme dans le script historique ;
   - l'adresse principale est active par défaut ;
   - l'adresse secondaire Koha peut être activée séparément ;
   - la saisie manuelle Koha reste toujours possible ;
   - navigation clavier, annulation des requêtes obsolètes et comportement fail-safe.

 API :
   https://data.geopf.fr/geocodage/completion/
*/
(function () {
    'use strict';

    var MODULE_ID = '070';
    var PAGE_PATH = '/cgi-bin/koha/members/memberentry.pl';
    var STYLE_ID = 'pmk070-address-autocomplete-style';
    var CACHE_KEY = 'PimpMyKoha.070.referencePlace.v1';
    var API_URL = 'https://data.geopf.fr/geocodage/completion/';

    var DEFAULT_CONFIG = {
        enabled: true,
        page: {
            enabled: true,
            pageId: 'members.memberentry',
            path: PAGE_PATH
        },
        addresses: {
            primary: {
                enabled: true,
                addressSelector: '#address, input[name="address"]',
                zipcodeSelector: '#zipcode, input[name="zipcode"]',
                citySelector: '#city, input[name="city"]'
            },
            secondary: {
                enabled: false,
                addressSelector: '#B_address, input[name="B_address"]',
                zipcodeSelector: '#B_zipcode, input[name="B_zipcode"]',
                citySelector: '#B_city, input[name="B_city"]'
            }
        },
        search: {
            minChars: 3,
            debounceMs: 300,
            maxResults: 6,
            requestTimeoutMs: 6000,
            endpoint: API_URL,
            providerLabel: 'Géoplateforme'
        },
        geoBias: {
            enabled: true,
            referenceCity: 'Draguignan',
            referencePostalCode: '83300',
            cacheDays: 30
        }
    };

    var currentConfig = clone(DEFAULT_CONFIG);
    var unsubscribe = null;
    var pmkInitialized = false;
    var mounted = [];
    var referencePromise = null;
    var referencePromiseKey = '';
    var queryCache = new Map();

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return !!value && typeof value === 'object' && !Array.isArray(value);
    }

    function deepMerge(base, extra) {
        if (Array.isArray(base)) return Array.isArray(extra) ? clone(extra) : clone(base);
        if (!isObject(base)) return extra === undefined ? clone(base) : clone(extra);
        var out = clone(base);
        if (!isObject(extra)) return out;
        Object.keys(extra).forEach(function (key) {
            if (Array.isArray(extra[key])) out[key] = clone(extra[key]);
            else if (isObject(extra[key]) && isObject(out[key])) out[key] = deepMerge(out[key], extra[key]);
            else if (extra[key] !== undefined) out[key] = clone(extra[key]);
        });
        return out;
    }

    function clampInt(value, fallback, min, max) {
        var number = Number(value);
        if (!Number.isFinite(number)) number = fallback;
        number = Math.round(number);
        return Math.min(max, Math.max(min, number));
    }

    function cleanText(value) {
        return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    }

    function normalizeText(value) {
        return cleanText(value)
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .toLowerCase();
    }

    function normalizeConfig(config) {
        var cfg = deepMerge(DEFAULT_CONFIG, isObject(config) ? config : {});
        cfg.enabled = cfg.enabled !== false;
        cfg.page = deepMerge(DEFAULT_CONFIG.page, cfg.page || {});
        cfg.page.enabled = cfg.page.enabled !== false;
        cfg.page.pageId = DEFAULT_CONFIG.page.pageId;
        cfg.page.path = PAGE_PATH;

        cfg.addresses = deepMerge(DEFAULT_CONFIG.addresses, cfg.addresses || {});
        cfg.addresses.primary.enabled = cfg.addresses.primary.enabled !== false;
        cfg.addresses.secondary.enabled = cfg.addresses.secondary.enabled === true;

        cfg.search = deepMerge(DEFAULT_CONFIG.search, cfg.search || {});
        cfg.search.minChars = clampInt(cfg.search.minChars, 3, 2, 8);
        cfg.search.debounceMs = clampInt(cfg.search.debounceMs, 300, 150, 1500);
        cfg.search.maxResults = clampInt(cfg.search.maxResults, 6, 1, 15);
        cfg.search.requestTimeoutMs = clampInt(cfg.search.requestTimeoutMs, 6000, 1500, 20000);
        cfg.search.endpoint = cleanText(cfg.search.endpoint || API_URL);
        if (!/^https:\/\//i.test(cfg.search.endpoint) && !/^\//.test(cfg.search.endpoint)) cfg.search.endpoint = API_URL;
        cfg.search.providerLabel = cleanText(cfg.search.providerLabel || 'Service d’adresses');

        cfg.geoBias = deepMerge(DEFAULT_CONFIG.geoBias, cfg.geoBias || {});
        cfg.geoBias.enabled = cfg.geoBias.enabled !== false;
        cfg.geoBias.referenceCity = cleanText(cfg.geoBias.referenceCity);
        cfg.geoBias.referencePostalCode = cleanText(cfg.geoBias.referencePostalCode).replace(/[^0-9A-Za-z-]/g, '');
        cfg.geoBias.cacheDays = clampInt(cfg.geoBias.cacheDays, 30, 1, 365);
        return cfg;
    }

    function language() {
        var lang = String(document.documentElement.lang || '').toLowerCase();
        return lang.indexOf('en') === 0 ? 'en' : 'fr';
    }

    function t(fr, en) {
        return language() === 'en' ? en : fr;
    }

    function safeStorageGet(key) {
        try { return window.localStorage.getItem(key); }
        catch (_) { return null; }
    }

    function safeStorageSet(key, value) {
        try {
            window.localStorage.setItem(key, value);
            return true;
        } catch (_) {
            return false;
        }
    }

    function safeJsonParse(value, fallback) {
        try { return JSON.parse(value); }
        catch (_) { return fallback; }
    }

    function dispatchValue(input, value) {
        if (!input) return;
        input.value = value == null ? '' : String(value);
        try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
        try { input.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
    }

    function firstElement(selector) {
        if (!selector) return null;
        try { return document.querySelector(selector); }
        catch (_) { return null; }
    }

    function ensureStyle() {
        if (document.getElementById(STYLE_ID)) return;
        var style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = [
            '.pmk070-autocomplete-host{position:relative;}',
            '.pmk070-suggestions{position:absolute;z-index:1055;display:none;box-sizing:border-box;min-width:260px;max-width:min(620px,calc(100vw - 32px));max-height:280px;overflow:auto;margin-top:2px;padding:3px;background:#fff;border:1px solid #b7c2cc;border-radius:4px;box-shadow:0 4px 12px rgba(0,0,0,.14);}',
            '.pmk070-suggestions[aria-hidden="false"]{display:block;}',
            '.pmk070-option{display:block;width:100%;margin:0;padding:7px 9px;border:0;border-radius:3px;background:transparent;color:inherit;text-align:left;line-height:1.3;cursor:pointer;}',
            '.pmk070-option:hover,.pmk070-option[aria-selected="true"]{background:#eef4f7;}',
            '.pmk070-option-main{display:block;font-weight:600;}',
            '.pmk070-option-meta{display:block;margin-top:1px;color:#687078;font-size:.86em;}',
            '.pmk070-message{padding:7px 9px;color:#687078;font-size:.9em;}',
            '.pmk070-message.pmk070-error{color:#8a4b08;}',
            '@media (max-width:767px){.pmk070-suggestions{max-width:calc(100vw - 24px);}}'
        ].join('\n');
        (document.head || document.documentElement).appendChild(style);
    }

    function requestJson(url, signal, timeoutMs) {
        var timeoutController = null;
        var timeoutId = null;
        var finalSignal = signal || null;

        if (!signal && typeof AbortController !== 'undefined') {
            timeoutController = new AbortController();
            finalSignal = timeoutController.signal;
        }
        if (timeoutController) {
            timeoutId = window.setTimeout(function () {
                try { timeoutController.abort(); } catch (_) {}
            }, timeoutMs);
        }

        return fetch(url, {
            method: 'GET',
            mode: 'cors',
            credentials: 'omit',
            headers: { 'Accept': 'application/json' },
            signal: finalSignal || undefined
        }).then(function (response) {
            if (!response.ok) throw new Error('HTTP ' + response.status);
            return response.json();
        }).finally(function () {
            if (timeoutId) window.clearTimeout(timeoutId);
        });
    }

    function buildUrl(params, endpoint) {
        var search = new URLSearchParams();
        Object.keys(params || {}).forEach(function (key) {
            var value = params[key];
            if (value === undefined || value === null || value === '') return;
            search.set(key, String(value));
        });
        return (endpoint || currentConfig.search.endpoint || API_URL) + '?' + search.toString();
    }

    function numericCoordinate(value) {
        var n = Number(value);
        return Number.isFinite(n) ? n : null;
    }

    function isCommuneLike(result) {
        var kind = normalizeText(result && result.kind);
        var poiTypes = Array.isArray(result && result.poiType)
            ? result.poiType.map(normalizeText)
            : [normalizeText(result && result.poiType)];
        return kind === 'commune'
            || kind === 'municipality'
            || poiTypes.indexOf('commune') !== -1
            || poiTypes.indexOf('administratif') !== -1;
    }

    function resultPostcodes(result) {
        var out = [];
        if (result && result.zipcode) out.push(String(result.zipcode));
        if (Array.isArray(result && result.zipcodes)) {
            result.zipcodes.forEach(function (value) { out.push(String(value)); });
        }
        return Array.from(new Set(out.filter(Boolean)));
    }

    function scoreReferenceResult(result, wantedCity, wantedPostalCode) {
        if (!result) return -Infinity;
        var x = numericCoordinate(result.x);
        var y = numericCoordinate(result.y);
        if (x === null || y === null) return -Infinity;

        var wanted = normalizeText(wantedCity);
        var city = normalizeText(result.city);
        var street = normalizeText(result.street);
        var fulltext = normalizeText(result.fulltext);
        var names = Array.isArray(result.names) ? result.names.map(normalizeText) : [];
        var score = 0;

        if (wanted && city === wanted) score += 120;
        if (wanted && names.indexOf(wanted) !== -1) score += 110;
        if (wanted && street === wanted) score += 70;
        if (wanted && fulltext.indexOf(wanted) === 0) score += 45;
        if (isCommuneLike(result)) score += 55;

        if (wantedPostalCode) {
            var postcodes = resultPostcodes(result);
            if (postcodes.indexOf(String(wantedPostalCode)) !== -1) score += 150;
            else score -= 25;
        }

        var classification = Number(result.classification);
        if (Number.isFinite(classification)) score += Math.max(0, 12 - classification);
        return score;
    }

    function referenceCacheKey(cfg) {
        return normalizeText(cfg.geoBias.referenceCity) + '|' + String(cfg.geoBias.referencePostalCode || '').toLowerCase();
    }

    function readReferenceCache(cfg) {
        var raw = safeJsonParse(safeStorageGet(CACHE_KEY), null);
        if (!raw || raw.key !== referenceCacheKey(cfg)) return null;
        if (!Number.isFinite(Number(raw.x)) || !Number.isFinite(Number(raw.y))) return null;
        var maxAge = cfg.geoBias.cacheDays * 86400000;
        if (!Number.isFinite(Number(raw.savedAt)) || Date.now() - Number(raw.savedAt) > maxAge) return null;
        return {
            x: Number(raw.x),
            y: Number(raw.y),
            label: cleanText(raw.label),
            city: cleanText(raw.city),
            zipcode: cleanText(raw.zipcode)
        };
    }

    function writeReferenceCache(cfg, result) {
        if (!result) return;
        safeStorageSet(CACHE_KEY, JSON.stringify({
            key: referenceCacheKey(cfg),
            savedAt: Date.now(),
            x: result.x,
            y: result.y,
            label: result.label || '',
            city: result.city || '',
            zipcode: result.zipcode || ''
        }));
    }

    function resolveReferencePlace(cfg) {
        if (!cfg.geoBias.enabled || !cfg.geoBias.referenceCity) return Promise.resolve(null);

        var cached = readReferenceCache(cfg);
        if (cached) return Promise.resolve(cached);

        var key = referenceCacheKey(cfg);
        if (referencePromise && referencePromiseKey === key) return referencePromise;
        referencePromiseKey = key;

        var text = cfg.geoBias.referenceCity;
        if (cfg.geoBias.referencePostalCode) text += ' ' + cfg.geoBias.referencePostalCode;

        var url = buildUrl({
            text: text,
            type: 'PositionOfInterest,StreetAddress',
            poiType: 'administratif',
            maximumResponses: 15
        }, cfg.search.endpoint);

        referencePromise = requestJson(url, null, cfg.search.requestTimeoutMs)
            .then(function (data) {
                var results = Array.isArray(data && data.results) ? data.results : [];
                var best = null;
                var bestScore = -Infinity;
                results.forEach(function (result) {
                    var score = scoreReferenceResult(
                        result,
                        cfg.geoBias.referenceCity,
                        cfg.geoBias.referencePostalCode
                    );
                    if (score > bestScore) {
                        bestScore = score;
                        best = result;
                    }
                });

                if (!best) return null;
                var resolved = {
                    x: Number(best.x),
                    y: Number(best.y),
                    label: cleanText(best.fulltext || [best.city, best.zipcode].filter(Boolean).join(' ')),
                    city: cleanText(best.city || cfg.geoBias.referenceCity),
                    zipcode: cleanText(best.zipcode || cfg.geoBias.referencePostalCode)
                };
                writeReferenceCache(cfg, resolved);
                return resolved;
            })
            .catch(function () { return null; })
            .finally(function () {
                referencePromise = null;
                referencePromiseKey = '';
            });

        return referencePromise;
    }

    function extractAddressPartFromFulltext(result) {
        var full = cleanText(result && result.fulltext);
        if (!full) return '';

        var city = cleanText(result && result.city);
        var zipcode = cleanText(result && result.zipcode);
        var suffix = cleanText([zipcode, city].filter(Boolean).join(' '));

        if (suffix) {
            var escaped = suffix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            var suffixRegex = new RegExp('(?:,\\s*|\\s+)' + escaped + '$', 'i');
            var withoutSuffix = cleanText(full.replace(suffixRegex, ''));
            if (withoutSuffix && withoutSuffix !== full) return withoutSuffix;
        }

        // Fallback pour les réponses où CP/ville ne sont pas exposés dans
        // des propriétés distinctes mais restent présents à la fin de fulltext.
        var generic = full.match(/^(.*?)(?:,\s*|\s+)(?:[0-9]{5})\s+.+$/);
        if (generic && generic[1]) return cleanText(generic[1]);

        return full;
    }

    function houseNumberFromAddress(value) {
        var text = cleanText(value);
        if (!text) return '';
        var match = text.match(/^(\d{1,6}(?:\s*(?:bis|ter|quater|quinquies|[A-Za-z]))?)\b/i);
        return match ? cleanText(match[1]) : '';
    }

    function resultHouseNumber(result) {
        var direct = cleanText(result && (result.number || result.housenumber));
        if (direct) return direct;
        return houseNumberFromAddress(extractAddressPartFromFulltext(result));
    }

    function addressFromResult(result) {
        var fullAddress = extractAddressPartFromFulltext(result);
        var number = resultHouseNumber(result);
        var street = cleanText(result && result.street);

        /*
         * Restauration du comportement historique du 070 : une adresse
         * numérotée reste numérotée dans le champ Koha Adresse.
         *
         * La Géoplateforme peut fournir le numéro uniquement dans fulltext
         * alors que street ne contient que le nom de voie. On privilégie donc
         * le morceau d'adresse complet lorsque celui-ci commence par un numéro.
         */
        if (fullAddress && houseNumberFromAddress(fullAddress)) return fullAddress;

        if (street) return cleanText([number, street].filter(Boolean).join(' '));
        if (fullAddress) return fullAddress;
        return '';
    }

    function queryHouseNumber(query) {
        return houseNumberFromAddress(query);
    }

    function rankNumberedResults(results, query) {
        var wantedNumber = normalizeText(queryHouseNumber(query));
        return (results || []).map(function (result, index) {
            var resultNumber = normalizeText(resultHouseNumber(result));
            var bucket = 2;

            if (wantedNumber) {
                if (resultNumber === wantedNumber) bucket = 0;
                else if (resultNumber) bucket = 1;
                else bucket = 3;
            } else {
                // Sans numéro saisi, on conserve l'ordre de proximité du
                // service. Les adresses numérotées ne sont pas artificiellement
                // remontées devant une voie pertinente.
                bucket = 0;
            }

            return { result: result, index: index, bucket: bucket };
        }).sort(function (a, b) {
            return a.bucket - b.bucket || a.index - b.index;
        }).map(function (entry) { return entry.result; });
    }

    function displayLabel(result) {
        var full = cleanText(result && result.fulltext);
        if (full) return full;
        return cleanText([
            addressFromResult(result),
            result && result.zipcode,
            result && result.city
        ].filter(Boolean).join(' '));
    }

    function uniqueResults(results, maxResults) {
        var seen = Object.create(null);
        var out = [];
        (results || []).forEach(function (result) {
            if (!result || out.length >= maxResults) return;
            var label = displayLabel(result);
            if (!label) return;
            var key = normalizeText(label);
            if (!key || seen[key]) return;
            seen[key] = true;
            out.push(result);
        });
        return out;
    }

    function cacheQuery(key, results) {
        queryCache.set(key, results);
        while (queryCache.size > 60) {
            var firstKey = queryCache.keys().next().value;
            queryCache.delete(firstKey);
        }
    }

    function fetchAddressSuggestions(query, cfg, signal) {
        return resolveReferencePlace(cfg).then(function (reference) {
            var cacheKey = normalizeText(query) + '|' + (reference ? reference.x + ',' + reference.y : '') + '|' + cfg.search.maxResults;
            if (queryCache.has(cacheKey)) return clone(queryCache.get(cacheKey));

            var wantedNumber = queryHouseNumber(query);
            // L'API Géoplateforme accepte maximum 15 réponses.
            // Avec 6 résultats configurés, l'ancienne formule demandait 18
            // et provoquait une réponse HTTP 400 sur les recherches numérotées.
            var requestedMaximum = wantedNumber
                ? Math.min(15, Math.max(cfg.search.maxResults, cfg.search.maxResults * 3))
                : Math.min(15, cfg.search.maxResults);

            var params = {
                text: query,
                type: 'StreetAddress',
                maximumResponses: requestedMaximum
            };
            if (reference) params.lonlat = reference.x + ',' + reference.y;

            return requestJson(buildUrl(params, cfg.search.endpoint), signal, cfg.search.requestTimeoutMs)
                .then(function (data) {
                    var raw = Array.isArray(data && data.results) ? data.results : [];
                    var ranked = rankNumberedResults(raw, query);

                    /*
                     * Si l'utilisateur a commencé par un numéro, on évite qu'une
                     * simple voie sans numéro remplace sa saisie. On conserve en
                     * priorité les réponses réellement numérotées. S'il n'y en a
                     * aucune, les résultats du service restent affichés afin de
                     * ne jamais bloquer la saisie manuelle.
                     */
                    if (wantedNumber) {
                        var numbered = ranked.filter(function (result) {
                            return Boolean(resultHouseNumber(result));
                        });
                        if (numbered.length) ranked = numbered;
                    }

                    var results = uniqueResults(ranked, cfg.search.maxResults);
                    cacheQuery(cacheKey, results);
                    return clone(results);
                });
        });
    }

    function setListGeometry(instance) {
        if (!instance || !instance.input || !instance.list) return;
        var input = instance.input;
        var list = instance.list;
        var parent = input.parentElement;
        if (!parent) return;

        var parentRect = parent.getBoundingClientRect();
        var inputRect = input.getBoundingClientRect();
        list.style.left = Math.max(0, inputRect.left - parentRect.left) + 'px';
        list.style.top = (inputRect.bottom - parentRect.top + 2) + 'px';
        list.style.width = Math.max(260, inputRect.width) + 'px';
    }

    function closeList(instance) {
        if (!instance || !instance.list) return;
        // Selecting a result dispatches input/change for Koha. Cancel the
        // resulting debounce and pending request so the list stays closed.
        if (instance.timer) window.clearTimeout(instance.timer);
        instance.timer = null;
        instance.requestSerial++;
        if (instance.controller) instance.controller.abort();
        instance.controller = null;
        if (instance.requestTimeoutTimer) window.clearTimeout(instance.requestTimeoutTimer);
        instance.requestTimeoutTimer = null;
        instance.results = [];
        instance.activeIndex = -1;
        instance.list.innerHTML = '';
        instance.list.setAttribute('aria-hidden', 'true');
        instance.input.setAttribute('aria-expanded', 'false');
        instance.input.removeAttribute('aria-activedescendant');
    }

    function renderMessage(instance, message, error) {
        instance.results = [];
        instance.activeIndex = -1;
        instance.list.innerHTML = '';
        var div = document.createElement('div');
        div.className = 'pmk070-message' + (error ? ' pmk070-error' : '');
        div.textContent = message;
        instance.list.appendChild(div);
        setListGeometry(instance);
        instance.list.setAttribute('aria-hidden', 'false');
        instance.input.setAttribute('aria-expanded', 'true');
    }

    function selectResult(instance, result) {
        if (!instance || !result) return;
        var address = addressFromResult(result);
        var city = cleanText(result.city);
        var zipcode = cleanText(result.zipcode);

        if (address) dispatchValue(instance.input, address);
        if (city && instance.cityInput) dispatchValue(instance.cityInput, city);
        if (zipcode && instance.zipcodeInput) dispatchValue(instance.zipcodeInput, zipcode);
        closeList(instance);
        try { instance.input.focus({ preventScroll: true }); } catch (_) { instance.input.focus(); }
    }

    function updateActiveOption(instance, nextIndex) {
        var buttons = instance.list.querySelectorAll('.pmk070-option');
        if (!buttons.length) return;
        var count = buttons.length;
        nextIndex = ((nextIndex % count) + count) % count;
        instance.activeIndex = nextIndex;
        buttons.forEach(function (button, index) {
            var selected = index === nextIndex;
            button.setAttribute('aria-selected', selected ? 'true' : 'false');
            if (selected) {
                instance.input.setAttribute('aria-activedescendant', button.id);
                try { button.scrollIntoView({ block: 'nearest' }); } catch (_) {}
            }
        });
    }

    function renderResults(instance, results, elapsedMs, cfg) {
        instance.results = results;
        instance.activeIndex = -1;
        instance.list.innerHTML = '';

        if (!results.length) {
            renderMessage(instance, t('Aucune adresse trouvée.', 'No address found.'), false);
            return;
        }

        results.forEach(function (result, index) {
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'pmk070-option';
            button.id = instance.id + '-option-' + index;
            button.setAttribute('role', 'option');
            button.setAttribute('aria-selected', 'false');

            var main = document.createElement('span');
            main.className = 'pmk070-option-main';
            main.textContent = addressFromResult(result) || displayLabel(result);
            button.appendChild(main);

            var locality = cleanText([result.zipcode, result.city].filter(Boolean).join(' '));
            var kind = cleanText(result.kind || (Array.isArray(result.poiType) ? result.poiType.join(', ') : result.poiType));
            if (locality) {
                var meta = document.createElement('span');
                meta.className = 'pmk070-option-meta';
                meta.textContent = locality + (kind ? ' · ' + kind : '');
                button.appendChild(meta);
            }

            button.addEventListener('mousedown', function (event) {
                event.preventDefault();
            });
            button.addEventListener('click', function () {
                selectResult(instance, result);
            });
            instance.list.appendChild(button);
        });

        var localityKeys = new Set(results.map(function (result) { return normalizeText([result.zipcode, result.city].filter(Boolean).join(' ')); }).filter(Boolean));
        var footer = document.createElement('div');
        footer.className = 'pmk070-message';
        footer.textContent = (cfg.search.providerLabel || 'Service d’adresses') + ' · ' + Math.max(0, Math.round(elapsedMs || 0)) + ' ms' + (localityKeys.size > 1 ? t(' · plusieurs communes : vérifiez le code postal avant de choisir.', ' · several cities: check the postal code before choosing.') : '');
        instance.list.appendChild(footer);

        setListGeometry(instance);
        instance.list.setAttribute('aria-hidden', 'false');
        instance.input.setAttribute('aria-expanded', 'true');
    }

    function destroyInstance(instance) {
        if (!instance) return;
        if (instance.timer) window.clearTimeout(instance.timer);
        if (instance.requestTimeoutTimer) window.clearTimeout(instance.requestTimeoutTimer);
        if (instance.controller) {
            try { instance.controller.abort(); } catch (_) {}
        }
        (instance.listeners || []).forEach(function (entry) {
            try { entry.target.removeEventListener(entry.type, entry.handler, entry.options); } catch (_) {}
        });
        if (instance.list && instance.list.parentNode) instance.list.parentNode.removeChild(instance.list);
        if (instance.input) {
            instance.input.removeAttribute('aria-autocomplete');
            instance.input.removeAttribute('aria-controls');
            instance.input.removeAttribute('aria-expanded');
            instance.input.removeAttribute('aria-activedescendant');
            instance.input.removeAttribute('data-pmk070-mounted');
            if (instance.previousAutocomplete === null) instance.input.removeAttribute('autocomplete');
            else instance.input.setAttribute('autocomplete', instance.previousAutocomplete);
        }
        if (instance.host && instance.host.getAttribute('data-pmk070-host') === '1') {
            instance.host.removeAttribute('data-pmk070-host');
            instance.host.classList.remove('pmk070-autocomplete-host');
        }
    }

    function destroyAll() {
        mounted.forEach(destroyInstance);
        mounted = [];
    }

    function addListener(instance, target, type, handler, options) {
        target.addEventListener(type, handler, options);
        instance.listeners.push({ target: target, type: type, handler: handler, options: options });
    }

    function mountField(kind, fieldConfig, cfg) {
        if (!fieldConfig || fieldConfig.enabled !== true) return null;
        var input = firstElement(fieldConfig.addressSelector);
        if (!input || input.getAttribute('data-pmk070-mounted') === '1') return null;

        var zipcodeInput = firstElement(fieldConfig.zipcodeSelector);
        var cityInput = firstElement(fieldConfig.citySelector);
        var host = input.parentElement;
        if (!host) return null;

        ensureStyle();
        host.classList.add('pmk070-autocomplete-host');
        host.setAttribute('data-pmk070-host', '1');

        var id = 'pmk070-' + kind + '-' + Math.random().toString(36).slice(2, 9);
        var list = document.createElement('div');
        list.id = id + '-list';
        list.className = 'pmk070-suggestions';
        list.setAttribute('role', 'listbox');
        list.setAttribute('aria-hidden', 'true');
        host.appendChild(list);

        var previousAutocomplete = input.hasAttribute('autocomplete') ? input.getAttribute('autocomplete') : null;
        input.setAttribute('data-pmk070-mounted', '1');
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('aria-autocomplete', 'list');
        input.setAttribute('aria-controls', list.id);
        input.setAttribute('aria-expanded', 'false');

        var instance = {
            id: id,
            kind: kind,
            input: input,
            zipcodeInput: zipcodeInput,
            cityInput: cityInput,
            host: host,
            list: list,
            results: [],
            activeIndex: -1,
            timer: null,
            controller: null,
            requestTimeoutTimer: null,
            requestSerial: 0,
            previousAutocomplete: previousAutocomplete,
            listeners: []
        };

        function performSearch(query) {
            if (instance.controller) {
                try { instance.controller.abort(); } catch (_) {}
            }
            if (instance.requestTimeoutTimer) {
                window.clearTimeout(instance.requestTimeoutTimer);
                instance.requestTimeoutTimer = null;
            }
            instance.controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
            var signal = instance.controller ? instance.controller.signal : null;
            var serial = ++instance.requestSerial;
            var startedAt = performance.now();
            renderMessage(instance, t('Recherche auprès de ', 'Searching ') + cfg.search.providerLabel + '…', false);

            if (instance.controller && cfg.search.requestTimeoutMs > 0) {
                instance.requestTimeoutTimer = window.setTimeout(function () {
                    try { instance.controller.abort(); } catch (_) {}
                }, cfg.search.requestTimeoutMs);
            }

            fetchAddressSuggestions(query, cfg, signal)
                .then(function (results) {
                    if (serial !== instance.requestSerial) return;
                    renderResults(instance, results, performance.now() - startedAt, cfg);
                })
                .catch(function (error) {
                    if (serial !== instance.requestSerial) return;
                    if (error && error.name === 'AbortError') {
                        renderMessage(
                            instance,
                            t('La recherche a pris trop de temps — saisie manuelle possible.', 'The search took too long — manual entry remains available.'),
                            true
                        );
                        return;
                    }
                    renderMessage(
                        instance,
                        t('Service d’adresses indisponible — saisie manuelle possible.', 'Address service unavailable — manual entry remains available.'),
                        true
                    );
                })
                .finally(function () {
                    if (serial === instance.requestSerial && instance.requestTimeoutTimer) {
                        window.clearTimeout(instance.requestTimeoutTimer);
                        instance.requestTimeoutTimer = null;
                    }
                });
        }

        addListener(instance, input, 'input', function () {
            if (instance.timer) window.clearTimeout(instance.timer);
            var query = cleanText(input.value);
            if (query.length < cfg.search.minChars) {
                closeList(instance);
                return;
            }
            instance.timer = window.setTimeout(function () {
                performSearch(query);
            }, cfg.search.debounceMs);
        });

        addListener(instance, input, 'keydown', function (event) {
            var open = instance.list.getAttribute('aria-hidden') === 'false';
            if (!open) return;

            if (event.key === 'ArrowDown') {
                event.preventDefault();
                updateActiveOption(instance, instance.activeIndex + 1);
            } else if (event.key === 'ArrowUp') {
                event.preventDefault();
                updateActiveOption(instance, instance.activeIndex <= 0 ? instance.results.length - 1 : instance.activeIndex - 1);
            } else if (event.key === 'Enter') {
                if (instance.activeIndex >= 0 && instance.results[instance.activeIndex]) {
                    event.preventDefault();
                    selectResult(instance, instance.results[instance.activeIndex]);
                }
            } else if (event.key === 'Escape') {
                event.preventDefault();
                closeList(instance);
            } else if (event.key === 'Tab') {
                closeList(instance);
            }
        });

        addListener(instance, input, 'focus', function () {
            if (instance.results.length) {
                setListGeometry(instance);
                instance.list.setAttribute('aria-hidden', 'false');
                input.setAttribute('aria-expanded', 'true');
            }
        });

        addListener(instance, document, 'mousedown', function (event) {
            if (event.target === input || list.contains(event.target)) return;
            closeList(instance);
        }, true);

        addListener(instance, window, 'resize', function () {
            if (instance.list.getAttribute('aria-hidden') === 'false') setListGeometry(instance);
        });

        return instance;
    }

    function mountContextButton() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
        var input = firstElement(currentConfig.addresses.primary.addressSelector);
        if (!input) return;
        var anchor = input.parentElement || input;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: 'append',
                contextKey: 'member-address-autocomplete',
                context: {
                    pageId: 'members.memberentry',
                    sectionId: 'geography'
                }
            });
        } catch (_) {}
    }

    function render() {
        destroyAll();
        if (window.location.pathname !== PAGE_PATH) return;
        if (!currentConfig.enabled || !currentConfig.page.enabled) return;

        if (currentConfig.addresses.primary.enabled) {
            var primary = mountField('primary', currentConfig.addresses.primary, currentConfig);
            if (primary) mounted.push(primary);
        }
        if (currentConfig.addresses.secondary.enabled) {
            var secondary = mountField('secondary', currentConfig.addresses.secondary, currentConfig);
            if (secondary) mounted.push(secondary);
        }

        if (currentConfig.geoBias.enabled && currentConfig.geoBias.referenceCity) {
            resolveReferencePlace(currentConfig).catch(function () {});
        }

        mountContextButton();
    }

    async function initializePmk() {
        if (pmkInitialized || !window.PMKConfig) return;
        pmkInitialized = true;

        try {
            var cfg = await window.PMKConfig.getConfig(MODULE_ID);
            currentConfig = normalizeConfig(deepMerge(DEFAULT_CONFIG, cfg || {}));
        } catch (_) {
            currentConfig = normalizeConfig(DEFAULT_CONFIG);
        }

        if (typeof window.PMKConfig.subscribe === 'function') {
            try {
                unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                    currentConfig = normalizeConfig(deepMerge(DEFAULT_CONFIG, cfg || {}));
                    referencePromise = null;
                    referencePromiseKey = '';
                    queryCache.clear();
                    render();
                });
            } catch (_) {}
        }

        render();
    }

    function start() {
        currentConfig = normalizeConfig(DEFAULT_CONFIG);
        render();

        if (window.PMKConfig) initializePmk();
        else window.addEventListener('pmk:config-ready', initializePmk, { once: true });
    }

    window.PMK070 = {
        moduleId: MODULE_ID,
        version: '3.1.2',
        defaults: clone(DEFAULT_CONFIG),
        getConfig: function () { return clone(currentConfig); },
        resolveReferencePlace: function () { return resolveReferencePlace(currentConfig); },
        render: render,
        destroy: function () {
            destroyAll();
            if (typeof unsubscribe === 'function') {
                try { unsubscribe(); } catch (_) {}
                unsubscribe = null;
            }
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("070-address-autocomplete-memberentry.js");
} catch (error) { window.PMKNonPlugin.errors.push("070-address-autocomplete-memberentry.js: "+error.message); console.error("[PMK] 070-address-autocomplete-memberentry.js",error); };
try {
/*
 Nom du fichier: 070-date-utils.js
 Module PMK: Dates relatives
 ID PMK: relative-dates
 Version: 3.1.0-pmk-unified-circulation
 Date de dernière modification: 2026-09-22

 Historique / consolidation:
 - conserve l'API historique window.VC_DATE_UTILS ;
 - absorbe la fonction métier de 081-holdings-table-durations-detail.js ;
 - absorbe les améliorations utiles de 100-koha-age-insertion-split.js ;
 - fournit par défaut les trois règles historiques :
   * Date d'acquisition ;
   * Date du dernier emprunt ;
   * Vu en dernier ;
 - traite #holdings_table et #otherholdings_table ;
 - fonctionne sans jQuery ;
 - s'enregistre directement dans PMK sans modifier le socle 000 ;
 - v2.2.0 : ajoute un saut de ligne configurable avant/après/autour du résultat des règles « Élément libre ».
 - v2.3.0 : le picker sait convertir une cellule <td> sans id/classe en ciblage stable de toute sa colonne dans le tableau.
   - v2.4.0 : calcul relatif calendaire précis (années, mois puis jours restants), sans approximation 30,44/365,25.
*/

(function () {
    "use strict";

    const MODULE_ID = "relative-dates";
    const MODULE_VERSION = "3.1.0-pmk-unified-circulation";
    const SCRIPT_GUARD = "__pmk070RelativeDatesV24";
    const STYLE_ID = "pmk070-relative-dates-style";
    const GENERATED_ATTR = "data-pmk-relative-date-generated";
    const DETAIL_PATH = "/cgi-bin/koha/catalogue/detail.pl";
    const DETAIL_PAGE_ID = "catalogue.detail";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const DEFAULTS = {
        enabled: true,
        pages: {
            detail: {
                enabled: true,
                pageId: DETAIL_PAGE_ID,
                path: DETAIL_PATH
            }
        },
        display: {
            className: "vc-age",
            wrapInParentheses: false,
            pastPrefixFr: "il y a ",
            futurePrefixFr: "dans ",
            instantFr: "à l’instant",
            pastSuffixEn: " ago",
            futurePrefixEn: "in ",
            instantEn: "just now"
        },
        behavior: {
            observeDynamicChanges: true,
            observeDelayMs: 100,
            waitTimeoutMs: 5000
        },
        rules: [
            {
                id: "holdings-acquisition-date",
                enabled: true,
                targetMode: "tableColumn",
                labelFr: "Date d’acquisition",
                labelEn: "Acquisition date",
                pagePath: DETAIL_PATH,
                tableSelector: "#holdings_table, #otherholdings_table",
                columnName: "dateaccessioned",
                headerAliases: "date d'acquisition|date d’acquisition|acquisition|acquisition date",
                parserMode: "date"
            },
            {
                id: "holdings-last-checkout-date",
                enabled: true,
                targetMode: "tableColumn",
                labelFr: "Date du dernier emprunt",
                labelEn: "Last checkout date",
                pagePath: DETAIL_PATH,
                tableSelector: "#holdings_table, #otherholdings_table",
                columnName: "datelastborrowed",
                headerAliases: "date du dernier emprunt|dernier emprunt|last checkout|last borrowed",
                parserMode: "date"
            },
            {
                id: "holdings-last-seen-date",
                enabled: true,
                targetMode: "tableColumn",
                labelFr: "Vu en dernier",
                labelEn: "Last seen",
                pagePath: DETAIL_PATH,
                tableSelector: "#holdings_table, #otherholdings_table",
                columnName: "lastseen",
                headerAliases: "vu en dernier|dernière consultation|derniere consultation|last seen",
                parserMode: "datetime"
            }
        ]
    };

    const defaultPresets=window.PMKConfig?.services?.get('pmk.date-settings')?.presets?.() || [
    {
        "id": "waiting-waiting-waitingSince",
        "originModule": "waiting-holds-age",
        "enabled": true,
        "labelFr": "En attente depuis — en attente",
        "labelEn": "waitingSince — waiting",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdst",
        "columnName": "waitingSince",
        "headerAliases": "waiting since|en attente depuis|date de mise en attente|attente depuis",
        "fallbackColumn": 1,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-waiting-holdDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date de réservation — en attente",
        "labelEn": "holdDate — waiting",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdst",
        "columnName": "holdDate",
        "headerAliases": "hold date|date de réservation|date de la réservation|date hold placed|date of hold",
        "fallbackColumn": 2,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-waiting-expirationDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date d’expiration — en attente",
        "labelEn": "expirationDate — waiting",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdst",
        "columnName": "expirationDate",
        "headerAliases": "expiration|date d’expiration|expiry date",
        "fallbackColumn": 3,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days-since",
        "pastOnly": false,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-expired-waitingSince",
        "originModule": "waiting-holds-age",
        "enabled": true,
        "labelFr": "En attente depuis — expirées",
        "labelEn": "waitingSince — expired",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdso",
        "columnName": "waitingSince",
        "headerAliases": "waiting since|en attente depuis|date de mise en attente|attente depuis",
        "fallbackColumn": 1,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-expired-holdDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date de réservation — expirées",
        "labelEn": "holdDate — expired",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdso",
        "columnName": "holdDate",
        "headerAliases": "hold date|date de réservation|date de la réservation|date hold placed|date of hold",
        "fallbackColumn": 2,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-expired-expirationDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date d’expiration — expirées",
        "labelEn": "expirationDate — expired",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdso",
        "columnName": "expirationDate",
        "headerAliases": "expiration|date d’expiration|expiry date",
        "fallbackColumn": 3,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days-since",
        "pastOnly": false,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-cancelled-waitingSince",
        "originModule": "waiting-holds-age",
        "enabled": true,
        "labelFr": "En attente depuis — annulées",
        "labelEn": "waitingSince — cancelled",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdscr",
        "columnName": "waitingSince",
        "headerAliases": "waiting since|en attente depuis|date de mise en attente|attente depuis",
        "fallbackColumn": 1,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-cancelled-holdDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date de réservation — annulées",
        "labelEn": "holdDate — cancelled",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdscr",
        "columnName": "holdDate",
        "headerAliases": "hold date|date de réservation|date de la réservation|date hold placed|date of hold",
        "fallbackColumn": 2,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days",
        "pastOnly": true,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "waiting-cancelled-expirationDate",
        "originModule": "waiting-holds-age",
        "enabled": false,
        "labelFr": "Date d’expiration — annulées",
        "labelEn": "expirationDate — cancelled",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/circ/waitingreserves.pl",
        "tableSelector": "#holdscr",
        "columnName": "expirationDate",
        "headerAliases": "expiration|date d’expiration|expiry date",
        "fallbackColumn": 3,
        "sourceMode": "attribute",
        "sourceAttribute": "data-order",
        "parserMode": "date",
        "calculationMode": "duration",
        "durationFormat": "days-since",
        "pastOnly": false,
        "warningEnabled": true,
        "warningDays": 35
    },
    {
        "id": "loan-due-holdings",
        "originModule": "loan-duration-detail",
        "enabled": true,
        "labelFr": "Échéance de prêt — exemplaires",
        "labelEn": "Loan due date — holdings",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/catalogue/detail.pl",
        "tableSelector": "#holdings_table",
        "columnName": "status",
        "headerAliases": "statut|status",
        "dataPath": "checkout.due_date",
        "durationFormat": "due-date",
        "displayLanguage": "auto",
        "showFuture": true,
        "showToday": true,
        "showOverdue": true,
        "parserMode": "date"
    },
    {
        "id": "loan-due-otherholdings",
        "originModule": "loan-duration-detail",
        "enabled": true,
        "labelFr": "Échéance de prêt — autres exemplaires",
        "labelEn": "Loan due date — otherholdings",
        "targetMode": "tableColumn",
        "pagePath": "/cgi-bin/koha/catalogue/detail.pl",
        "tableSelector": "#otherholdings_table",
        "columnName": "status",
        "headerAliases": "statut|status",
        "dataPath": "checkout.due_date",
        "durationFormat": "due-date",
        "displayLanguage": "auto",
        "showFuture": true,
        "showToday": true,
        "showOverdue": true,
        "parserMode": "date"
    }
];
    DEFAULTS.rules.push(...defaultPresets);

    let currentConfig = clone(DEFAULTS);
    let pmkRegistered = false;
    let unsubscribe = null;
    let observer = null;
    let observerTimer = null;
    let started = false;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function object(value) {
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    }

    function merge(base, extra) {
        const out = clone(base);
        if (!extra || typeof extra !== "object") return out;
        Object.keys(extra).forEach(function (key) {
            const incoming = extra[key];
            if (Array.isArray(incoming)) {
                out[key] = clone(incoming);
            } else if (
                incoming && typeof incoming === "object" && !Array.isArray(incoming) &&
                out[key] && typeof out[key] === "object" && !Array.isArray(out[key])
            ) {
                out[key] = merge(out[key], incoming);
            } else if (incoming !== undefined) {
                out[key] = incoming;
            }
        });
        return out;
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function clamp(value, min, max, fallback) {
        const number = Number(value);
        if (!Number.isFinite(number)) return fallback;
        return Math.min(max, Math.max(min, Math.round(number)));
    }

    function normalizeText(value) {
        return clean(value)
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[’‘`]/g, "'")
            .replace(/\s+/g, " ");
    }

    function validLocalDate(year, month, day, hour, minute, second) {
        const y = Number(year);
        const m = Number(month);
        const d = Number(day);
        const h = Number(hour || 0);
        const min = Number(minute || 0);
        const sec = Number(second || 0);

        if (![y, m, d, h, min, sec].every(Number.isFinite)) return null;
        if (y < 1000 || m < 1 || m > 12 || d < 1 || d > 31) return null;
        if (h < 0 || h > 23 || min < 0 || min > 59 || sec < 0 || sec > 59) return null;

        const date = new Date(y, m - 1, d, h, min, sec, 0);
        if (
            date.getFullYear() !== y ||
            date.getMonth() !== m - 1 ||
            date.getDate() !== d ||
            date.getHours() !== h ||
            date.getMinutes() !== min ||
            date.getSeconds() !== sec
        ) return null;
        return date;
    }

    function parseDate(value) {
        if(window.PMKDates)return window.PMKDates.parse(value);
        const raw = clean(value);
        if (!raw) return null;

        let match = raw.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
        if (match) {
            return validLocalDate(match[1], match[2], match[3], match[4], match[5], match[6]);
        }

        match = raw.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
        if (match) {
            return validLocalDate(match[3], match[2], match[1], match[4], match[5], match[6]);
        }

        return null;
    }

    function parseDateFR(value) {
        return parseDate(value);
    }

    function parseDateTimeFR(value) {
        return parseDate(value);
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try { return api.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const htmlLang = clean(document.documentElement.getAttribute("lang")).toLowerCase();
        if (htmlLang.indexOf("en") === 0) return "en";
        const navLang = clean(navigator.language).toLowerCase();
        return navLang.indexOf("en") === 0 ? "en" : "fr";
    }

    function unitLabel(value, unit, lang) {
        const n = Math.max(0, Math.floor(Math.abs(value)));
        if (lang === "en") {
            const names = {
                year: n === 1 ? "year" : "years",
                month: n === 1 ? "month" : "months",
                day: n === 1 ? "day" : "days",
                hour: n === 1 ? "hour" : "hours",
                minute: n === 1 ? "minute" : "minutes"
            };
            return n + " " + names[unit];
        }
        const names = {
            year: n === 1 ? "an" : "ans",
            month: "mois",
            day: n === 1 ? "jour" : "jours",
            hour: n === 1 ? "heure" : "heures",
            minute: n === 1 ? "minute" : "minutes"
        };
        return n + " " + names[unit];
    }

    function daysInMonth(year, monthIndex) {
        return new Date(year, monthIndex + 1, 0).getDate();
    }

    function addCalendarYears(date, years) {
        const result = new Date(date.getTime());
        const originalDay = result.getDate();
        result.setDate(1);
        result.setFullYear(result.getFullYear() + years);
        result.setDate(Math.min(originalDay, daysInMonth(result.getFullYear(), result.getMonth())));
        return result;
    }

    function addCalendarMonths(date, months) {
        const result = new Date(date.getTime());
        const originalDay = result.getDate();
        result.setDate(1);
        result.setMonth(result.getMonth() + months);
        result.setDate(Math.min(originalDay, daysInMonth(result.getFullYear(), result.getMonth())));
        return result;
    }

    function startOfLocalDay(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
    }

    function wholeCalendarDays(from, to) {
        const a = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
        const b = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
        return Math.max(0, Math.round((b - a) / 86400000));
    }

    function calendarDifference(startDate, endDate) {
        let cursor = new Date(startDate.getTime());
        let years = 0;
        let months = 0;

        while (true) {
            const next = addCalendarYears(cursor, 1);
            if (next.getTime() > endDate.getTime()) break;
            cursor = next;
            years += 1;
        }

        while (true) {
            const next = addCalendarMonths(cursor, 1);
            if (next.getTime() > endDate.getTime()) break;
            cursor = next;
            months += 1;
        }

        const days = wholeCalendarDays(startOfLocalDay(cursor), startOfLocalDay(endDate));
        return { years: years, months: months, days: days };
    }

    function relativeParts(date, now) {
        if (!(date instanceof Date) || Number.isNaN(date.getTime())) return null;
        const reference = now instanceof Date && !Number.isNaN(now.getTime()) ? now : new Date();
        const diffMs = date.getTime() - reference.getTime();
        const future = diffMs > 0;
        const absMs = Math.abs(diffMs);

        if (absMs < 60000) return { future: future, unit: "instant", value: 0, values: [] };

        const earlier = future ? reference : date;
        const later = future ? date : reference;
        const earlierDay = startOfLocalDay(earlier);
        const laterDay = startOfLocalDay(later);
        const dayGap = wholeCalendarDays(earlierDay, laterDay);

        if (dayGap === 0) {
            const minutes = Math.floor(absMs / 60000);
            const hours = Math.floor(absMs / 3600000);
            if (hours >= 1) return { future: future, unit: "hour", value: hours, values: [{ unit: "hour", value: hours }] };
            if (minutes >= 1) return { future: future, unit: "minute", value: minutes, values: [{ unit: "minute", value: minutes }] };
            return { future: future, unit: "instant", value: 0, values: [] };
        }

        const diff = calendarDifference(earlierDay, laterDay);
        const values = [];
        if (diff.years) values.push({ unit: "year", value: diff.years });
        if (diff.months) values.push({ unit: "month", value: diff.months });
        if (diff.days) values.push({ unit: "day", value: diff.days });

        if (!values.length) values.push({ unit: "day", value: dayGap });
        return {
            future: future,
            unit: values[0].unit,
            value: values[0].value,
            values: values
        };
    }

    function joinRelativeValues(parts, lang) {
        const values = Array.isArray(parts && parts.values) && parts.values.length
            ? parts.values
            : [{ unit: parts.unit, value: parts.value }];
        const labels = values.map(function (part) {
            return unitLabel(part.value, part.unit, lang);
        });
        if (labels.length <= 1) return labels[0] || "";
        if (lang === "en") return labels.slice(0, -1).join(", ") + " and " + labels[labels.length - 1];
        return labels.slice(0, -1).join(", ") + " et " + labels[labels.length - 1];
    }

    function relativeLabel(date, lang, config) {
        const cfg = normalizeConfig(config || currentConfig);
        const selectedLang = lang === "en" ? "en" : "fr";
        const parts = relativeParts(date);
        if (!parts) return "";

        if (parts.unit === "instant") {
            return selectedLang === "en" ? cfg.display.instantEn : cfg.display.instantFr;
        }

        const value = joinRelativeValues(parts, selectedLang);
        if (selectedLang === "en") {
            return parts.future
                ? cfg.display.futurePrefixEn + value
                : value + cfg.display.pastSuffixEn;
        }
        return parts.future
            ? cfg.display.futurePrefixFr + value
            : cfg.display.pastPrefixFr + value;
    }

    function tempsEcoule(date) {
        return relativeLabel(date, language(), currentConfig);
    }

    function newRule() {
        const suffix = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
        return {
            id: "relative-date-" + suffix,
            enabled: true,
            labelFr: "Nouvelle date relative",
            labelEn: "New relative date",
            pagePath: window.location.pathname || DETAIL_PATH,
            targetMode: "element",
            selector: "",
            targetName: "",
            matchCount: null,
            tableSelector: "",
            columnName: "",
            headerAliases: "",
            parserMode: "auto",
            sourceMode: "auto",
            sourceAttribute: "datetime",
            dateRegex: "",
            placement: "append",
            lineBreak: "none",
            separator: " — "
        };
    }

    function normalizeRule(rule, index) {
        const source = object(rule);
        const explicitMode = clean(source.targetMode);
        const inferredMode = explicitMode || (clean(source.selector) ? "element" : "tableColumn");
        return {
            id: clean(source.id) || "rule-" + (index + 1),
            enabled: source.enabled !== false,
            calculationMode: source.calculationMode === "age" ? "age" : "duration",
            ageFormat: ["years", "years_months", "years_months_days"].includes(source.ageFormat) ? source.ageFormat : "years",
            durationFormat: ["largest","days","days-since","due-date"].includes(source.durationFormat) ? source.durationFormat : "full",
            originModule: clean(source.originModule),
            dataPath: clean(source.dataPath),
            fallbackColumn: Number.isInteger(source.fallbackColumn) ? source.fallbackColumn : -1,
            pastOnly: source.pastOnly === true,
            warningEnabled: source.warningEnabled === true,
            warningDays: clamp(source.warningDays,0,3650,35),
            displayLanguage: ['fr','en'].includes(source.displayLanguage) ? source.displayLanguage : 'auto',
            showFuture: source.showFuture !== false,
            showToday: source.showToday !== false,
            showOverdue: source.showOverdue !== false,

            labelFr: clean(source.labelFr) || "Date relative " + (index + 1),
            labelEn: clean(source.labelEn) || "Relative date " + (index + 1),
            pagePath: clean(source.pagePath) || DETAIL_PATH,
            targetMode: inferredMode === "element" ? "element" : "tableColumn",
            selector: clean(source.selector),
            targetName: clean(source.targetName),
            matchCount: Number.isInteger(source.matchCount) ? source.matchCount : null,
            tableSelector: clean(source.tableSelector) || (inferredMode === "tableColumn" ? "#holdings_table" : ""),
            columnName: clean(source.columnName),
            headerAliases: clean(source.headerAliases),
            parserMode: ["auto", "date", "datetime"].indexOf(clean(source.parserMode)) >= 0
                ? clean(source.parserMode)
                : "auto",
            sourceMode: ["auto", "text", "value", "attribute"].indexOf(clean(source.sourceMode)) >= 0
                ? clean(source.sourceMode)
                : "auto",
            sourceAttribute: clean(source.sourceAttribute) || "datetime",
            dateRegex: clean(source.dateRegex),
            placement: ["append", "prepend", "after", "before"].indexOf(clean(source.placement)) >= 0
                ? clean(source.placement)
                : "append",
            lineBreak: ["none", "before", "after", "both"].indexOf(clean(source.lineBreak)) >= 0
                ? clean(source.lineBreak)
                : "none",
            separator: source.separator == null ? " — " : String(source.separator)
        };
    }

    function normalizeConfig(config) {
        const cfg = merge(DEFAULTS, object(config));
        cfg.enabled = cfg.enabled !== false;
        cfg.pages = merge(DEFAULTS.pages, object(cfg.pages));
        cfg.pages.detail = merge(DEFAULTS.pages.detail, object(cfg.pages.detail));
        cfg.pages.detail.enabled = cfg.pages.detail.enabled !== false;
        cfg.pages.detail.pageId = DETAIL_PAGE_ID;
        cfg.pages.detail.path = DETAIL_PATH;
        cfg.display = merge(DEFAULTS.display, object(cfg.display));
        cfg.display.className = clean(cfg.display.className) || DEFAULTS.display.className;
        cfg.display.wrapInParentheses = cfg.display.wrapInParentheses === true;
        cfg.behavior = merge(DEFAULTS.behavior, object(cfg.behavior));
        cfg.behavior.observeDynamicChanges = cfg.behavior.observeDynamicChanges !== false;
        cfg.behavior.observeDelayMs = clamp(cfg.behavior.observeDelayMs, 25, 2000, DEFAULTS.behavior.observeDelayMs);
        cfg.behavior.waitTimeoutMs = clamp(cfg.behavior.waitTimeoutMs, 500, 20000, DEFAULTS.behavior.waitTimeoutMs);
        cfg.rules = Array.isArray(cfg.rules) ? cfg.rules.map(normalizeRule) : clone(DEFAULTS.rules);
        return cfg;
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        const ids = new Set();
        for (let i = 0; i < cfg.rules.length; i += 1) {
            const rule = cfg.rules[i];
            if (!rule.id || ids.has(rule.id)) {
                return { ok: false, message: "Chaque règle doit avoir un identifiant unique." };
            }
            ids.add(rule.id);
            if (!rule.enabled) continue;
            if (!rule.pagePath) return { ok: false, message: "Chaque règle active doit indiquer une page Koha." };
            if (rule.targetMode === "element") {
                if (!rule.selector) {
                    return { ok: false, message: "Chaque règle « Élément libre » active doit cibler un élément avec le picker." };
                }
                if (rule.sourceMode === "attribute" && !rule.sourceAttribute) {
                    return { ok: false, message: "Indiquez l’attribut qui contient la date." };
                }
                if (rule.dateRegex) {
                    try { new RegExp(rule.dateRegex); }
                    catch (_) { return { ok: false, message: "L’expression régulière d’extraction de date est invalide." }; }
                }
            } else {
                if (!rule.tableSelector) return { ok: false, message: "Chaque règle de colonne active doit indiquer un tableau cible." };
                if (!rule.columnName && !rule.headerAliases) {
                    return { ok: false, message: "Chaque règle de colonne active doit indiquer un data-colname ou un libellé d’en-tête de secours." };
                }
            }
        }
        return { ok: true };
    }

    function getRuleFromPath(rootObject, fieldPath) {
        const path = Array.isArray(fieldPath) ? fieldPath : [];
        const pos = path.indexOf("rules");
        const index = pos >= 0 ? Number(path[pos + 1]) : NaN;
        if (!Number.isInteger(index) || !rootObject || !Array.isArray(rootObject.rules)) return null;
        return rootObject.rules[index] || null;
    }

    function selectorCount(selector) {
        if (!clean(selector)) return 0;
        try { return document.querySelectorAll(selector).length; } catch (_) { return 0; }
    }

    function applyPickerResult(rootObject, fieldPath, result) {
        const rule = getRuleFromPath(rootObject, fieldPath);
        if (!rule || !result) return;
        rule.pagePath = result.pagePath || rule.pagePath || window.location.pathname;
        rule.targetMode = "element";
        rule.selector = result.selector || result.value || rule.selector || "";
        rule.targetName = result.targetName || rule.targetName || "Élément Koha";
        rule.matchCount = Number.isInteger(result.matchCount)
            ? result.matchCount
            : selectorCount(rule.selector);
    }

    function pickForRule(context) {
        const ctx = context || {};
        const rule = getRuleFromPath(ctx.rootObject, ctx.fieldPath);
        const targetUrl = rule && rule.pagePath ? rule.pagePath : window.location.pathname;
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.pickForConfig !== "function") {
            return Promise.reject(new Error("shared_picker_unavailable"));
        }
        return picker.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: targetUrl,
            fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath.slice() : [],
            rootObject: ctx.rootObject || {},
            adminContext: { sectionId: "rules", pagePath: targetUrl },
            options: {
                bannerText: language() === "en"
                    ? "Click the element containing the date — Esc cancels"
                    : "Clique sur l’élément contenant la date — Échap annule"
            }
        });
    }

    function escapeCssIdent(value) {
        const raw = String(value == null ? "" : value);
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(raw);
        return raw.replace(/[^a-zA-Z0-9_-]/g, function (ch) {
            return "\\" + ch.charCodeAt(0).toString(16) + " ";
        });
    }

    function tableSelectorForCell(cell) {
        const table = cell && cell.closest ? cell.closest("table") : null;
        if (!table) return "";

        if (table.id) return "#" + escapeCssIdent(table.id);

        const stableAttrs = ["data-table", "data-testid", "aria-label", "name"];
        for (let i = 0; i < stableAttrs.length; i += 1) {
            const attr = stableAttrs[i];
            const value = clean(table.getAttribute(attr));
            if (!value) continue;
            const selector = "table[" + attr + '=\"' + value.replace(/\\/g, "\\\\").replace(/\"/g, '\\\"') + '\"]';
            try {
                if (document.querySelectorAll(selector).length === 1) return selector;
            } catch (_) {}
        }

        const usefulClasses = Array.from(table.classList || []).filter(function (name) {
            return name && !/^(table|display|dataTable|no-footer|collapsed|responsive|dtr-inline)$/i.test(name);
        });
        for (let i = 0; i < usefulClasses.length; i += 1) {
            const selector = "table." + escapeCssIdent(usefulClasses[i]);
            try {
                if (document.querySelectorAll(selector).length === 1) return selector;
            } catch (_) {}
        }

        const tables = Array.from(document.querySelectorAll("table"));
        if (tables.length === 1 && tables[0] === table) return "table";
        return "";
    }

    function tableColumnInfoFromCell(candidate) {
        const cell = candidate && candidate.closest ? candidate.closest("td") : null;
        if (!cell || !cell.parentElement) return null;

        const rowCells = Array.from(cell.parentElement.children).filter(function (node) {
            return node && /^(TD|TH)$/.test(node.tagName || "");
        });
        const columnIndex = rowCells.indexOf(cell);
        if (columnIndex < 0) return null;

        const table = cell.closest("table");
        const tableSelector = tableSelectorForCell(cell);
        if (!table || !tableSelector) return null;

        let header = "";
        const headRows = Array.from(table.querySelectorAll("thead tr"));
        for (let i = headRows.length - 1; i >= 0 && !header; i -= 1) {
            const headers = Array.from(headRows[i].children).filter(function (node) {
                return node && /^(TH|TD)$/.test(node.tagName || "");
            });
            if (headers[columnIndex]) header = clean(headers[columnIndex].textContent);
        }

        if (!header) {
            const dataCol = clean(cell.getAttribute("data-colname"));
            if (dataCol) header = dataCol;
        }

        const selector = tableSelector + " tbody tr > td:nth-child(" + (columnIndex + 1) + ")";
        let matchCount = 0;
        try { matchCount = document.querySelectorAll(selector).length; } catch (_) {}

        return {
            selector: selector,
            matchCount: matchCount,
            columnIndex: columnIndex + 1,
            header: header,
            tableSelector: tableSelector
        };
    }

    function registerPickerAdapter() {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return false;
        try {
            picker.register(MODULE_ID, {
                buildResult: function (candidate, result) {
                    const column = tableColumnInfoFromCell(candidate);
                    if (column) {
                        result.selector = column.selector;
                        result.value = column.selector;
                        result.matchCount = column.matchCount;
                        result.targetName = column.header
                            ? "Colonne « " + column.header + " »"
                            : "Colonne " + column.columnIndex + " du tableau";
                        result.pmkRelativeDateTarget = {
                            kind: "table-column",
                            tableSelector: column.tableSelector,
                            columnIndex: column.columnIndex,
                            header: column.header
                        };
                        return result;
                    }

                    result.targetName = clean(candidate && (candidate.getAttribute("aria-label") || candidate.getAttribute("title")))
                        || clean(candidate && candidate.textContent).slice(0, 120)
                        || (candidate && candidate.tagName ? candidate.tagName.toLowerCase() : "element");
                    result.matchCount = selectorCount(result.selector);
                    return result;
                },
                applyPending: function (draft, pending, picked) {
                    applyPickerResult(draft, pending && pending.fieldPath, picked);
                    return draft;
                }
            });
            return true;
        } catch (_) {
            return false;
        }
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function registerPmkDefinition() {
        const api = pmkApi();
        if (!api || typeof api.registerModule !== "function") return false;
        if (pmkRegistered) return true;
        if (api.services && api.services.get && api.services.get("pmk.date-settings")) {
            pmkRegistered = true;
            registerPickerAdapter();
            return true;
        }

        try {
            api.registerModule({
                id: MODULE_ID,
                schemaVersion: 2,
                name: {
                    fr: "Âges et dates relatives",
                    en: "Relative dates"
                },
                description: {
                    fr: "Ajoute un calcul de date relatif (par exemple « il y a 3 mois ») à n’importe quel élément Koha choisi avec le picker, tout en conservant les trois usages historiques du 081/100 sur la table des exemplaires.",
                    en: "Adds a relative-date calculation (for example “3 months ago”) to any Koha element selected with the picker, while preserving the three historical 081/100 holdings-table uses."
                },
                category: {
                    fr: "Interface / présentation",
                    en: "Interface / presentation"
                },
                supportedPages: ["*"],
                prerequisites: [],
                dependencies: [],
                defaults: clone(DEFAULTS),
                normalize: normalizeConfig,
                validate: validateConfig,
                schema: [
                    {
                        type: "section",
                        id: "activation",
                        label: { fr: "Activation", en: "Activation" },
                        fields: [
                            { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                            { key: "pages.detail.enabled", type: "boolean", label: { fr: "Activer sur detail.pl", en: "Enable on detail.pl" } },
                            { key: "pages.detail.path", type: "readonly", advanced: true, label: { fr: "Page Koha", en: "Koha page" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "wording",
                        label: { fr: "Libellés temporels", en: "Relative-time wording" },
                        description: {
                            fr: "Les valeurs par défaut reproduisent le rendu historique « il y a X » du 081/100.",
                            en: "Defaults preserve the historical 081/100 relative-time rendering."
                        },
                        fields: [
                            { key: "display.instantFr", type: "text", label: { fr: "FR — moins d’une minute", en: "FR — less than one minute" } },
                            { key: "display.pastPrefixFr", type: "text", label: { fr: "FR — préfixe passé", en: "FR — past prefix" } },
                            { key: "display.futurePrefixFr", type: "text", label: { fr: "FR — préfixe futur", en: "FR — future prefix" } },
                            { key: "display.instantEn", type: "text", label: { fr: "EN — moins d’une minute", en: "EN — less than one minute" } },
                            { key: "display.pastSuffixEn", type: "text", label: { fr: "EN — suffixe passé", en: "EN — past suffix" } },
                            { key: "display.futurePrefixEn", type: "text", label: { fr: "EN — préfixe futur", en: "EN — future prefix" } },
                            { key: "display.wrapInParentheses", type: "boolean", label: { fr: "Afficher le libellé entre parenthèses", en: "Wrap relative label in parentheses" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "rules",
                        label: { fr: "Dates concernées", en: "Target dates" },
                        description: {
                            fr: "Les trois premières règles correspondent aux anciennes fonctions du 081/100. Elles sont actives par défaut. Les nouvelles règles peuvent cibler n’importe quel élément d’une page Koha avec le picker commun.",
                            en: "The first three rules reproduce the former 081/100 behavior and are enabled by default. New rules can target any element on a Koha page with the shared picker."
                        },
                        fields: [
                            {
                                key: "rules",
                                type: "repeater",
                                label: { fr: "Règles de dates relatives", en: "Relative-date rules" },
                                addLabel: { fr: "Ajouter une date", en: "Add a date" },
                                emptyLabel: { fr: "Aucune date configurée.", en: "No date configured." },
                                reorder: true,
                                newItem: newRule,
                                itemTitle: function (item, index, lang) {
                                    const label = lang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
                                    return label || ((lang === "en" ? "Relative date " : "Date relative ") + (index + 1));
                                },
                                fields: [
                                    { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                    { key: "calculationMode", type: "select", refreshOnChange: true, label: {fr: "Calcul", en: "Calculation"}, options: [
                                        {value: "duration", label: {fr: "Durée relative", en: "Relative duration"}},
                                        {value: "age", label: {fr: "Âge", en: "Age"}}
                                    ]},
                                    { key: "ageFormat", type: "select", label: {fr: "Format d’âge", en: "Age format"},
                                        when: function (root, path) { return root.rules[Number(path[1])].calculationMode === "age"; },
                                        options: [
                                            {value: "years", label: {fr: "Années", en: "Years"}},
                                            {value: "years_months", label: {fr: "Années et mois", en: "Years and months"}},
                                            {value: "years_months_days", label: {fr: "Années, mois et jours", en: "Years, months and days"}}
                                        ]},
                                    { key: "durationFormat", type: "select", label: {fr: "Format de durée", en: "Duration format"},
                                        when: function (root, path) { return root.rules[Number(path[1])].calculationMode !== "age"; },
                                        options: [{value: "full", label: {fr: "Durée complète", en: "Full duration"}}, {value: "largest", label: {fr: "Unité principale", en: "Largest unit"}}]},
                                    { key: "labelFr", type: "text", label: { fr: "Nom FR", en: "French name" } },
                                    { key: "labelEn", type: "text", label: { fr: "Nom EN", en: "English name" } },
                                    {
                                        key: "targetMode",
                                        type: "select",
                                        label: { fr: "Type de cible", en: "Target type" },
                                        help: {
                                            fr: "« Élément libre » permet de calculer une date n’importe où dans Koha avec le picker. « Colonne de tableau » conserve les règles historiques 081/100.",
                                            en: "“Free element” calculates a date anywhere in Koha using the picker. “Table column” preserves the historical 081/100 rules."
                                        },
                                        options: [
                                            { value: "element", label: { fr: "Élément libre (picker)", en: "Free element (picker)" } },
                                            { value: "tableColumn", label: { fr: "Colonne de tableau Koha", en: "Koha table column" } }
                                        ]
                                    },
                                    {
                                        key: "pagePath",
                                        type: "text",
                                        label: { fr: "Page Koha", en: "Koha page" },
                                        help: { fr: "Le picker renseigne automatiquement ce chemin. Si vous cliquez une cellule de tableau sans id/classe, PMK cible automatiquement toute la colonne. Utiliser * pour toutes les pages.", en: "The picker fills this path automatically. If you click a table cell without an id/class, PMK automatically targets the whole column. Use * for all pages." }
                                    },
                                    {
                                        key: "selector",
                                        type: "elementPicker",
                                        label: { fr: "Élément contenant la date", en: "Element containing the date" },
                                        pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                        emptyLabel: { fr: "Aucun élément libre choisi", en: "No free element selected" },
                                        help: { fr: "Utilisé uniquement en mode « Élément libre ». Le sélecteur peut aussi être saisi manuellement.", en: "Used only in “Free element” mode. The selector may also be entered manually." },
                                        allowManual: true,
                                        pick: pickForRule,
                                        onPick: applyPickerResult
                                    },
                                    { key: "targetName", type: "readonly", label: { fr: "Élément détecté", en: "Detected element" } },
                                    { key: "matchCount", type: "readonly", advanced: true, label: { fr: "Éléments trouvés lors du choix", en: "Elements found when selected" } },
                                    {
                                        key: "sourceMode",
                                        type: "select",
                                        label: { fr: "Où lire la date", en: "Where to read the date" },
                                        options: [
                                            { value: "auto", label: { fr: "Automatique (recommandé)", en: "Automatic (recommended)" } },
                                            { value: "text", label: { fr: "Texte de l’élément", en: "Element text" } },
                                            { value: "value", label: { fr: "Valeur du champ", en: "Field value" } },
                                            { value: "attribute", label: { fr: "Attribut HTML", en: "HTML attribute" } }
                                        ]
                                    },
                                    { key: "sourceAttribute", type: "text", advanced: true, label: { fr: "Attribut contenant la date", en: "Attribute containing the date" }, help: { fr: "Ex. datetime, data-date. Utilisé si « Attribut HTML » est choisi.", en: "E.g. datetime, data-date. Used when “HTML attribute” is selected." } },
                                    { key: "dateRegex", type: "text", advanced: true, label: { fr: "Extraction par expression régulière", en: "Regular-expression extraction" }, help: { fr: "Optionnel. Le groupe capturant 1 est utilisé s’il existe ; sinon la correspondance complète. Laisser vide dans la majorité des cas.", en: "Optional. Capture group 1 is used when present; otherwise the full match. Leave empty in most cases." } },
                                    {
                                        key: "placement",
                                        type: "select",
                                        label: { fr: "Position du calcul", en: "Calculation position" },
                                        options: [
                                            { value: "append", label: { fr: "Dans l’élément, après le contenu", en: "Inside the element, after content" } },
                                            { value: "prepend", label: { fr: "Dans l’élément, avant le contenu", en: "Inside the element, before content" } },
                                            { value: "after", label: { fr: "Après l’élément", en: "After the element" } },
                                            { value: "before", label: { fr: "Avant l’élément", en: "Before the element" } }
                                        ]
                                    },
                                    {
                                        key: "lineBreak",
                                        type: "select",
                                        label: { fr: "Saut de ligne autour du calcul", en: "Line break around calculation" },
                                        help: {
                                            fr: "Permet de placer le résultat calculé sur une ligne séparée, avant, après, ou des deux côtés.",
                                            en: "Places the calculated result on a separate line, before it, after it, or on both sides."
                                        },
                                        options: [
                                            { value: "none", label: { fr: "Aucun", en: "None" } },
                                            { value: "before", label: { fr: "Avant le calcul", en: "Before calculation" } },
                                            { value: "after", label: { fr: "Après le calcul", en: "After calculation" } },
                                            { value: "both", label: { fr: "Avant et après le calcul", en: "Before and after calculation" } }
                                        ]
                                    },
                                    { key: "separator", type: "text", label: { fr: "Séparateur", en: "Separator" }, help: { fr: "Utilisé pour l’insertion à l’intérieur de l’élément. Par défaut : « — ».", en: "Used for insertion inside the element. Default: “—”." } },
                                    { key: "tableSelector", type: "text", advanced: true, label: { fr: "Tableau cible — mode colonne", en: "Target table — column mode" } },
                                    { key: "columnName", type: "text", advanced: true, label: { fr: "data-colname — mode colonne", en: "data-colname — column mode" } },
                                    {
                                        key: "headerAliases",
                                        type: "text",
                                        advanced: true,
                                        label: { fr: "Libellés d’en-tête de secours — mode colonne", en: "Fallback header labels — column mode" },
                                        help: { fr: "Séparer les variantes par |.", en: "Separate alternatives with |." }
                                    },
                                    {
                                        key: "parserMode",
                                        type: "select",
                                        advanced: true,
                                        label: { fr: "Type de date", en: "Date type" },
                                        options: [
                                            { value: "auto", label: { fr: "Automatique", en: "Automatic" } },
                                            { value: "date", label: { fr: "Date", en: "Date" } },
                                            { value: "datetime", label: { fr: "Date et heure", en: "Date and time" } }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "behavior",
                        label: { fr: "Chargements dynamiques", en: "Dynamic loading" },
                        fields: [
                            { key: "behavior.observeDynamicChanges", type: "boolean", label: { fr: "Retraiter après reconstruction des tableaux", en: "Reprocess after table rebuilds" } },
                            { key: "behavior.observeDelayMs", type: "number", advanced: true, min: 25, max: 2000, label: { fr: "Délai de retraitement (ms)", en: "Reprocessing delay (ms)" } },
                            { key: "behavior.waitTimeoutMs", type: "number", advanced: true, min: 500, max: 20000, label: { fr: "Attente maximale du tableau (ms)", en: "Maximum table wait (ms)" } }
                        ]
                    }
                ],
                focusContext: function (main, context) {
                    if (!main) return;
                    const wanted = context && context.sectionId ? context.sectionId : "rules";
                    const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                    if (!section) return;
                    window.setTimeout(function () {
                        try { section.scrollIntoView({ block: "start", behavior: "smooth" }); } catch (_) {}
                    }, 60);
                }
            });
            pmkRegistered = true;
            registerPickerAdapter();
            return true;
        } catch (_) {
            return false;
        }
    }

    if (!registerPmkDefinition()) {
        window.addEventListener("pmk:config-ready", function () {
            registerPickerAdapter();
            registerPmkDefinition();
        }, { once: true });
    } else {
        registerPickerAdapter();
    }

    function ensureStyle() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = [
            ".pmk-relative-date-age, .vc-age{color:#555;font-size:.85em;margin-top:4px;line-height:1.25;}",
            ".pmk-relative-date-age{white-space:normal;}",
            ".pmk-relative-date-inline{display:inline;margin-left:.35em;margin-right:.35em;white-space:normal;}"
        ].join("\n");
        document.head.appendChild(style);
    }

    function removeGenerated(root) {
        const scope = root || document;
        scope.querySelectorAll("[" + GENERATED_ATTR + "]").forEach(function (node) {
            try { node.remove(); } catch (_) {
                if (node.parentNode) node.parentNode.removeChild(node);
            }
        });
    }

    function aliases(rule) {
        return clean(rule.headerAliases)
            .split("|")
            .map(normalizeText)
            .filter(Boolean);
    }

    function findColumnIndex(table, rule) {
        const headers = Array.from(table.querySelectorAll("thead th"));
        const wantedCol = normalizeText(rule.columnName);
        const fallbackAliases = aliases(rule);
        let aliasMatch = -1;

        for (let i = 0; i < headers.length; i += 1) {
            const th = headers[i];
            const colname = normalizeText(th.getAttribute("data-colname") || "");
            if (wantedCol && colname === wantedCol) return i;

            if (aliasMatch < 0 && fallbackAliases.length) {
                const text = normalizeText(th.textContent || "");
                if (fallbackAliases.some(function (alias) { return text.indexOf(alias) >= 0; })) {
                    aliasMatch = i;
                }
            }
        }
        return aliasMatch >= 0 ? aliasMatch : (rule.fallbackColumn >= 0 && rule.fallbackColumn < headers.length ? rule.fallbackColumn : -1);
    }

    function rawCellText(cell) {
        if (!cell) return "";
        const copy = cell.cloneNode(true);
        copy.querySelectorAll("[" + GENERATED_ATTR + "]").forEach(function (node) { node.remove(); });
        return clean(copy.textContent);
    }

    function extractDateSource(value, rule) {
        let raw = clean(value);
        if (!raw) return "";
        if (rule && rule.dateRegex) {
            try {
                const match = raw.match(new RegExp(rule.dateRegex));
                if (!match) return "";
                raw = clean(match[1] != null ? match[1] : match[0]);
            } catch (_) {
                return "";
            }
        }
        return raw;
    }

    function parseByMode(value, mode, rule) {
        const raw = extractDateSource(value, rule || {});
        if (!raw) return null;
        if (mode === "date") return parseDate(raw);
        if (mode === "datetime") return parseDate(raw);
        return parseDate(raw);
    }

    function calendarDaysFromToday(date) {
        const now=new Date();
        return Math.round((Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())-Date.UTC(now.getFullYear(),now.getMonth(),now.getDate()))/86400000);
    }
    function calculationLabel(date, rule, config) {
        if(rule?.pastOnly && calendarDaysFromToday(date)>0)return "";
        if (rule && ['days','days-since','due-date'].includes(rule.durationFormat)) {
            const delta=calendarDaysFromToday(date), count=Math.abs(delta);
            const en=rule.displayLanguage==='en' || (rule.displayLanguage!=='fr' && language()==='en');
            const days=count+' '+(en ? (count===1?'day':'days') : (count===1?'jour':'jours'));
            if (rule.pastOnly && delta>0) return '';
            if (rule.durationFormat==='due-date') {
                if ((delta>0 && !rule.showFuture)||(delta===0 && !rule.showToday)||(delta<0 && !rule.showOverdue)) return '';
                return delta===0 ? (en?'Due today':'Retour aujourd’hui') : days+(en ? (delta>0?' remaining':' overdue') : (delta>0?' restants':' de retard'));
            }
            if (rule.durationFormat==='days') return days;
            return delta>0 ? (en?'in ':'dans ')+days : (en?days+' ago':'depuis '+days);
        }
        if (!rule || rule.calculationMode !== "age") {
            if (!rule || rule.durationFormat !== "largest") return relativeLabel(date, language(), config);
            const parts = relativeParts(date);
            if (!parts || parts.unit === "instant") return relativeLabel(date, language(), config);
            const label = unitLabel(parts.value, parts.unit, language());
            if (language() === "en") return parts.future ? config.display.futurePrefixEn + label : label + config.display.pastSuffixEn;
            return (parts.future ? config.display.futurePrefixFr : config.display.pastPrefixFr) + label;
        }
        const today = startOfLocalDay(new Date());
        const birth = startOfLocalDay(date);
        if (birth > today) return "";
        const parts = calendarDifference(birth, today);
        if (parts.years > 130) return "";
        const en = language() === "en";
        function unit(value, singular, plural) { return value + " " + (value === 1 ? singular : plural); }
        const labels = [unit(parts.years, en ? "year" : "an", en ? "years" : "ans")];
        if (rule.ageFormat !== "years") labels.push(unit(parts.months, en ? "month" : "mois", en ? "months" : "mois"));
        if (rule.ageFormat === "years_months_days") labels.push(unit(parts.days, en ? "day" : "jour", en ? "days" : "jours"));
        return labels.join(" ");
    }

    function styleDateLabel(node,date,rule) {
        if(rule.warningEnabled && -calendarDaysFromToday(date)>rule.warningDays)node.style.color='#b91c1c';
        if(rule.durationFormat==='due-date') {
            node.classList.add('pmk-loan-duration-indicator','d-block','small');
            node.classList.add(calendarDaysFromToday(date)<0?'text-danger':calendarDaysFromToday(date)===0?'text-warning':'text-success');
            if(calendarDaysFromToday(date)<=0)node.classList.add('fw-semibold');
            node.style.marginTop='.15rem';
            const delta=calendarDaysFromToday(date);
            node.style.color=delta<0?'#b91c1c':delta===0?'#856404':'#237a39';
        }
    }

    function renderLabel(cell, date, config, rule, raw) {
        if (!cell || !date) return;
        const label = calculationLabel(date, rule, config);
        if (!label) return;

        const div = document.createElement("div");
        div.className = "pmk-relative-date-age " + (clean(config.display.className) || "vc-age");
        div.setAttribute(GENERATED_ATTR, rule.id);
        styleDateLabel(div,date,rule);
        if(window.PMKDates?.inspect(raw).ambiguous)div.title="Date interprétée jour/mois/année : format Koha non disponible.";
        div.textContent = config.display.wrapInParentheses ? "(" + label + ")" : label;
        cell.appendChild(div);
    }

    function processTableRule(table, rule, config) {
        const columnIndex = findColumnIndex(table, rule);
        if (columnIndex < 0) return;

        Array.from(table.querySelectorAll("tbody tr")).forEach(function (row) {
            const cells = row.querySelectorAll("td");
            const cell = cells[columnIndex];
            if (!cell) return;

            cell.querySelectorAll('['+GENERATED_ATTR+']').forEach(node=>{if(node.getAttribute(GENERATED_ATTR)===rule.id)node.remove()});
            let raw='';
            if (rule.dataPath) {
                try {
                    const jq=window.jQuery;
                    if(jq?.fn?.dataTable?.isDataTable(table)) {
                        let data=jq(table).DataTable().row(row).data();
                        if(rule.originModule==='loan-duration-detail' && Array.isArray(data?._status) && !data._status.some(status=>['checked_out','local_use'].includes(status)))return;
                        for(const key of rule.dataPath.split('.')) data=data?.[key];
                        raw=data == null ? '' : String(data);
                    }
                } catch (_) {}
            } else {
                raw=rule.sourceMode==='attribute' ? (cell.getAttribute(rule.sourceAttribute) || cell.querySelector('['+rule.sourceAttribute+']')?.getAttribute(rule.sourceAttribute) || rawCellText(cell)) : rawCellText(cell);
            }
            if (!raw) return;
            const date = parseByMode(raw, rule.parserMode, rule);
            if (!date || Number.isNaN(date.getTime())) return;
            renderLabel(cell, date, config, rule, raw);
            // Compatibilité 081/100 : leur ancien garde-fou détecte ce marqueur.
            cell.dataset.vcAgeProcessed = "pmk070";
        });
    }

    function elementTextWithoutGenerated(element) {
        if (!element) return "";
        const copy = element.cloneNode(true);
        if (copy.querySelectorAll) {
            copy.querySelectorAll("[" + GENERATED_ATTR + "]").forEach(function (node) { node.remove(); });
        }
        return clean(copy.textContent);
    }

    function elementDateSource(element, rule) {
        if (!element) return "";
        const mode = rule.sourceMode || "auto";
        if (mode === "attribute") return clean(element.getAttribute(rule.sourceAttribute || "datetime"));
        if (mode === "value") return clean(element.value);
        if (mode === "text") return elementTextWithoutGenerated(element);

        const tag = clean(element.tagName).toLowerCase();
        if ((tag === "input" || tag === "textarea" || tag === "select") && element.value != null) {
            const value = clean(element.value);
            if (value) return value;
        }
        const datetime = clean(element.getAttribute && element.getAttribute("datetime"));
        if (datetime) return datetime;
        return elementTextWithoutGenerated(element);
    }

    function genericRenderedText(date, config, rule) {
        const label = calculationLabel(date, rule, config);
        if (!label) return "";
        return config.display.wrapInParentheses ? "(" + label + ")" : label;
    }

    function renderElementLabel(element, date, rule, config, raw) {
        if (!element || !date) return;
        const text = genericRenderedText(date, config, rule);
        if (!text) return;

        const node = document.createElement("span");
        node.className = "pmk-relative-date-age pmk-relative-date-inline " + (clean(config.display.className) || "vc-age");
        node.setAttribute(GENERATED_ATTR, rule.id || "1");
        styleDateLabel(node,date,rule);
        if(window.PMKDates?.inspect(raw).ambiguous)node.title="Date interprétée jour/mois/année : format Koha non disponible.";
        node.setAttribute("data-pmk-relative-date-rule", rule.id || "");

        const separator = rule.separator == null ? " — " : String(rule.separator);
        const outside = function (where) {
            node.textContent = text;
            try {
                element.insertAdjacentElement(where === "before" ? "beforebegin" : "afterend", node);
                return true;
            } catch (_) {
                if (!element.parentNode) return false;
                if (where === "before") element.parentNode.insertBefore(node, element);
                else element.parentNode.insertBefore(node, element.nextSibling);
                return true;
            }
        };

        function addBreak(where) {
            const br = document.createElement("br");
            br.setAttribute(GENERATED_ATTR, rule.id || "1");
            br.setAttribute("data-pmk-relative-date-rule", rule.id || "");
            try {
                node.insertAdjacentElement(where === "before" ? "beforebegin" : "afterend", br);
            } catch (_) {
                if (!node.parentNode) return;
                if (where === "before") node.parentNode.insertBefore(br, node);
                else node.parentNode.insertBefore(br, node.nextSibling);
            }
        }

        try {
            if (rule.placement === "prepend") {
                node.textContent = text + separator;
                element.insertBefore(node, element.firstChild);
            } else if (rule.placement === "after") {
                outside("after");
            } else if (rule.placement === "before") {
                outside("before");
            } else {
                node.textContent = separator + text;
                element.appendChild(node);
            }

            if (node.isConnected) {
                if (rule.lineBreak === "before" || rule.lineBreak === "both") addBreak("before");
                if (rule.lineBreak === "after" || rule.lineBreak === "both") addBreak("after");
            }
        } catch (_) {
            if (!node.isConnected) outside("after");
            if (node.isConnected) {
                if (rule.lineBreak === "before" || rule.lineBreak === "both") addBreak("before");
                if (rule.lineBreak === "after" || rule.lineBreak === "both") addBreak("after");
            }
        }
    }

    function processElementRule(rule, config) {
        let targets = [];
        try { targets = Array.from(document.querySelectorAll(rule.selector)); } catch (_) { targets = []; }
        targets.forEach(function (element) {
            const raw = elementDateSource(element, rule);
            if (!raw) return;
            const date = parseByMode(raw, rule.parserMode, rule);
            if (!date || Number.isNaN(date.getTime())) return;
            renderElementLabel(element, date, rule, config, raw);
        });
    }

    function ruleAppliesToCurrentPage(rule) {
        const wanted = clean(rule.pagePath);
        const current = window.location.pathname || "";
        if (!wanted || wanted === "*") return true;
        return wanted === current || current.indexOf(wanted) >= 0;
    }

    function processConfiguredRules(config) {
        const cfg = normalizeConfig(config || currentConfig);
        if (!cfg.enabled) {
            removeGenerated(document);
            return;
        }

        removeGenerated(document);
        ensureStyle();
        const tableRulePairs = [];

        cfg.rules.forEach(function (rule) {
            if (!rule.enabled || !ruleAppliesToCurrentPage(rule)) return;
            if (!rule.originModule && (cfg.relativeDatesEnabled===false || (window.location.pathname===DETAIL_PATH && cfg.pages.detail.enabled===false))) return;
            if (rule.targetMode === "element") {
                processElementRule(rule, cfg);
                return;
            }
            let tables = [];
            try { tables = Array.from(document.querySelectorAll(rule.tableSelector)); } catch (_) { tables = []; }
            tables.forEach(function (table) {
                tableRulePairs.push([table, rule]);
            });
        });

        tableRulePairs.forEach(function (pair) {
            processTableRule(pair[0], pair[1], cfg);
        });
    }

    function waitForAnyRelevantTable(config) {
        const cfg = normalizeConfig(config || currentConfig);
        const selectors = cfg.rules
            .filter(function (rule) { return rule.enabled && ruleAppliesToCurrentPage(rule); })
            .map(function (rule) { return rule.targetMode === "element" ? rule.selector : rule.tableSelector; })
            .filter(Boolean);

        if (!selectors.length) return Promise.resolve(null);
        const selector = selectors.join(", ");

        if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === "function") {
            return window.KOHA_UTILS.waitFor(selector, cfg.behavior.waitTimeoutMs);
        }

        return new Promise(function (resolve, reject) {
            let first = null;
            try { first = document.querySelector(selector); } catch (_) {}
            if (first) return resolve(first);

            const observerLocal = new MutationObserver(function () {
                let found = null;
                try { found = document.querySelector(selector); } catch (_) {}
                if (!found) return;
                observerLocal.disconnect();
                resolve(found);
            });
            observerLocal.observe(document.documentElement, { childList: true, subtree: true });
            window.setTimeout(function () {
                observerLocal.disconnect();
                reject(new Error("timeout"));
            }, cfg.behavior.waitTimeoutMs);
        });
    }

    function stopObserver() {
        if (observer) {
            try { observer.disconnect(); } catch (_) {}
            observer = null;
        }
        if (observerTimer) {
            window.clearTimeout(observerTimer);
            observerTimer = null;
        }
    }

    function startObserver(config) {
        stopObserver();
        const cfg = normalizeConfig(config || currentConfig);
        if (!cfg.enabled || !cfg.behavior.observeDynamicChanges) return;

        observer = new MutationObserver(function (mutations) {
            const onlyOurNodes = mutations.length > 0 && mutations.every(function (mutation) {
                return Array.from(mutation.addedNodes || []).every(function (node) {
                    return node.nodeType !== 1 ||
                        node.hasAttribute && node.hasAttribute(GENERATED_ATTR) ||
                        node.closest && node.closest("[" + GENERATED_ATTR + "]");
                });
            });
            if (onlyOurNodes) return;

            if (observerTimer) window.clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                observerTimer = null;
                processConfiguredRules(currentConfig);
            }, cfg.behavior.observeDelayMs);
        });

        observer.observe(document.body || document.documentElement, {
            childList: true,
            subtree: true
        });
    }

    function mountContextAccess() {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;
        if (window.location.pathname !== DETAIL_PATH) return;
        const anchor = document.querySelector("#holdings_table_wrapper, #holdings_table");
        if (!anchor) return;
        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "before",
                contextKey: DETAIL_PAGE_ID,
                context: { sectionId: "rules", pageId: DETAIL_PAGE_ID }
            });
        } catch (_) {}
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULTS);
        removeGenerated(document);
        processConfiguredRules(currentConfig);
        startObserver(currentConfig);
        mountContextAccess();
    }

    function connectPmkConfig() {
        registerPmkDefinition();
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            applyConfig(DEFAULTS);
            return false;
        }

        api.getConfig(MODULE_ID)
            .then(function (config) { applyConfig(config || DEFAULTS); })
            .catch(function () { applyConfig(DEFAULTS); });

        if (!unsubscribe && typeof api.subscribe === "function") {
            try {
                unsubscribe = api.subscribe(MODULE_ID, function (config) {
                    applyConfig(config || DEFAULTS);
                });
            } catch (_) {}
        }
        return true;
    }

    /*
     * API historique + API consolidée.
     * Les anciens scripts qui consomment VC_DATE_UTILS continuent de fonctionner.
     */
    const publicApi = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        parseDate: parseDate,
        parseDateFR: parseDateFR,
        parseDateTimeFR: parseDateTimeFR,
        relativeLabel: function (date, lang) { return relativeLabel(date, lang || language(), currentConfig); },
        tempsEcoule: tempsEcoule,
        applyConfiguredRules: function () { processConfiguredRules(currentConfig); },
        processTableRule: function (table, rule) { processTableRule(table, normalizeRule(rule || {}, 0), currentConfig); },
        processElementRule: function (rule) { processElementRule(normalizeRule(rule || {}, 0), currentConfig); },
        defaults: clone(DEFAULTS),
        normalizeConfig: normalizeConfig,
        validateConfig: validateConfig,
        skipKohaAgeInsertion: true,
        ownsHoldingsRelativeDates: true
    };

    window.VC_DATE_UTILS = publicApi;
    window.PMK070RelativeDates = publicApi;

    function start() {
        if (started) return;
        started = true;

        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }

        waitForAnyRelevantTable(currentConfig)
            .then(function () { processConfiguredRules(currentConfig); mountContextAccess(); })
            .catch(function () {});
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("070-date-utils.js");
} catch (error) { window.PMKNonPlugin.errors.push("070-date-utils.js: "+error.message); console.error("[PMK] 070-date-utils.js",error); };
try {
/*
 Nom du fichier : 071-history-system-pmk-loader.js
 Version : 1.1.0-consolidated
 Date : 2026-09-20

 Rôle :
 - ne modifie pas 071-history-system.js ;
 - enregistre « Historique récent » dans PMK ;
 - charge le runtime historique seulement si le module est actif ;
 - expose window.PMKHistory071 pour IntranetNav 134.
*/
(function (window, document) {
    "use strict";
    if (window.__PMK071_HISTORY_LOADER__) return;
    window.__PMK071_HISTORY_LOADER__ = true;

    const MODULE_ID = "recent-history";
    const SCRIPT_URL = (window.PMKPlugin?.assetUrl ? window.PMKPlugin.assetUrl("071-history-system.js") : "/public/koha-scripts/071-history-system.js");
    const SCRIPT_ID = "pmk-071-history-runtime";
    const DISABLED_CLASS = "pmk-071-disabled";
    const STYLE_ID = "pmk-071-disabled-style";
    let config = { enabled: true };
    let loading = null;
    let unsubscribe = null;

    function runtimeReady() {
        return !!(window.KOHA_HISTORY && typeof window.KOHA_HISTORY.open === "function") || typeof window.openNav === "function";
    }
    function installMask() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `html.${DISABLED_CLASS} #customSidebar, html.${DISABLED_CLASS} #bottomActionBar #historique { display:none !important; }`;
        document.head.appendChild(style);
    }
    function closePanel() {
        try {
            if (window.KOHA_HISTORY && typeof window.KOHA_HISTORY.close === "function") window.KOHA_HISTORY.close();
            else if (typeof window.closeNav === "function") window.closeNav();
        } catch (_) {}
        const panel = document.getElementById("customSidebar");
        if (panel) {
            panel.classList.remove("is-open");
            panel.setAttribute("aria-hidden", "true");
            panel.style.width = "0px";
        }
    }
    function setDisabled(disabled) {
        installMask();
        document.documentElement.classList.toggle(DISABLED_CLASS, !!disabled);
        if (disabled) closePanel();
    }
    function dispatch(reason) {
        try {
            window.dispatchEvent(new CustomEvent("pmk:history-state", { detail:{ moduleId:MODULE_ID, enabled:config.enabled !== false, loaded:runtimeReady(), reason:reason || "state" } }));
        } catch (_) {}
    }
    function existingScript() {
        return document.getElementById(SCRIPT_ID) || Array.from(document.scripts || []).find(function (s) { return /(?:^|\/)071-history-system\.js(?:\?|$)/.test(String(s.src || "")); }) || null;
    }
    function waitRuntime(timeout) {
        return new Promise(function (resolve) {
            if (runtimeReady()) return resolve(true);
            const start = Date.now();
            const timer = setInterval(function () {
                if (runtimeReady()) { clearInterval(timer); resolve(true); }
                else if (Date.now() - start > timeout) { clearInterval(timer); resolve(false); }
            }, 50);
        });
    }
    function loadRuntime() {
        if (config.enabled === false) { setDisabled(true); dispatch("disabled"); return Promise.resolve(false); }
        setDisabled(false);
        if (runtimeReady()) return Promise.resolve(true);
        if (loading) return loading;
        const existing = existingScript();
        if (existing && existing.id !== SCRIPT_ID) {
            loading = waitRuntime(5000).then(function (ok) { loading = null; dispatch(ok ? "legacy-loaded" : "legacy-timeout"); return ok; });
            return loading;
        }
        loading = new Promise(function (resolve) {
            const script = existing || document.createElement("script");
            script.id = SCRIPT_ID;
            script.src = SCRIPT_URL;
            script.async = true;
            script.dataset.pmkControlled = "1";
            script.addEventListener("load", function () {
                waitRuntime(3000).then(function (ok) { loading = null; setDisabled(config.enabled === false); dispatch(ok ? "loaded" : "runtime-not-ready"); resolve(ok); });
            }, { once:true });
            script.addEventListener("error", function () { loading = null; dispatch("load-error"); resolve(false); }, { once:true });
            if (!script.isConnected) document.head.appendChild(script);
        });
        return loading;
    }
    async function open() {
        if (config.enabled === false) return false;
        if (!(await loadRuntime())) return false;
        try {
            if (window.KOHA_HISTORY && typeof window.KOHA_HISTORY.open === "function") { window.KOHA_HISTORY.open(); return true; }
            if (typeof window.openNav === "function") { window.openNav(); return true; }
        } catch (_) {}
        return false;
    }
    async function toggle() {
        if (config.enabled === false) return false;
        if (!(await loadRuntime())) return false;
        try {
            if (window.KOHA_HISTORY && typeof window.KOHA_HISTORY.toggle === "function") { window.KOHA_HISTORY.toggle(); return true; }
            return open();
        } catch (_) { return false; }
    }
    function definition() {
        return {
            id:MODULE_ID, schemaVersion:1,
            name:{fr:"Historique récent",en:"Recent history"},
            description:{fr:"Retrouvez les derniers adhérents, notices et recherches consultés dans ce navigateur, avec recherche et suppression des entrées. Chaque liste conserve jusqu’à 50 visites dans le stockage local de ce navigateur, partagé entre ses onglets. Aucun historique n’est transmis à PMK côté serveur. L’accès peut être ajouté au menu de navigation.",en:"Return to recently viewed patrons, records and searches in this browser. Search or remove entries; each list stores up to 50 visits. An entry can be added to the navigation menu."},
            category:{fr:"Interface & outils",en:"Interface & tools"}, supportedPages:["*"], prerequisites:[], dependencies:[], defaults:{enabled:true,excludedPaths:""},
            schema:[{type:"section",id:"recording",label:{fr:"Pages à ignorer",en:"Excluded pages"},fields:[{key:"excludedPaths",type:"textarea",label:{fr:"Ne pas enregistrer ces pages (un chemin par ligne)",en:"Do not record these pages (one path per line)"},help:{fr:"Exemple : /cgi-bin/koha/members/moremember.pl. Les entrées déjà conservées restent disponibles et peuvent être effacées individuellement.",en:"Example: /cgi-bin/koha/members/moremember.pl. Existing entries remain available and can be deleted individually."}}]}]
        };
    }
    function apply(raw) {
        config = Object.assign({ enabled:true,excludedPaths:"" }, raw || {});
        window.PMKHistory071.config = config;
        setDisabled(config.enabled === false);
        if (config.enabled !== false) loadRuntime();
        dispatch("config");
        window.PMKHistory071.enabled = config.enabled !== false;
    }
    function register() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) {}
        if (typeof window.PMKConfig.subscribe === "function" && !unsubscribe) {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, apply); } catch (_) {}
        }
        return true;
    }
    function loadConfig() {
        register();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve({enabled:true});
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).catch(function(){return {enabled:true};});
    }

    window.PMKHistory071 = { moduleId:MODULE_ID, enabled:true, open:open, toggle:toggle, close:closePanel, load:loadRuntime };
    function start() {
        if (register()) loadConfig().then(apply); else apply({enabled:true});
        window.addEventListener("pmk:config-ready", function(){ loadConfig().then(apply); }, { once:true });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once:true }); else start();
})(window, document);

;window.PMKNonPlugin.loaded.push("071-history-system-pmk-loader.js");
} catch (error) { window.PMKNonPlugin.errors.push("071-history-system-pmk-loader.js: "+error.message); console.error("[PMK] 071-history-system-pmk-loader.js",error); };
try {
/*
 Nom du fichier: 074-claims-filtering.js
 Version: 2.0.0
 Date de consolidation: 2026-09-19
 Auteur: équipe PimpMyKoha / consolidation PimpMyKoha

 Description:
   Conserve la fonction historique du 074 sur serials/claims.pl :
   - afficher uniquement les fascicules en retard ;
   - afficher uniquement les fascicules déjà réclamés ;
   - revenir au tableau complet en recliquant sur le filtre actif.

 Consolidation :
   - activation/désactivation depuis PMK Config ;
   - libellés FR/EN ;
   - alias de colonne et de statuts configurables pour les autres installations ;
   - sélecteurs Koha configurables en mode avancé ;
   - filtrage via DataTables lorsque disponible, repli DOM sinon ;
   - boutons compacts intégrés visuellement à Koha ;
   - un seul filtre actif à la fois ;
   - nettoyage complet si le module est désactivé à chaud ;
   - idempotence : aucun doublon de boutons ou de filtre DataTables.
*/
(function () {
  'use strict';

  var MODULE_ID = 'serials-claims-filtering';
  var PAGE_PATH = '/cgi-bin/koha/serials/claims.pl';
  var TOOLBAR_ID = 'pmk074-claims-filters';
  var STYLE_ID = 'pmk074-claims-filters-style';
  var CONFIG_HOST_ID = 'pmk074-config-host';

  var DEFAULT_CONFIG = {
    enabled: true,
    page: {
      enabled: true,
      path: PAGE_PATH
    },
    filters: {
      lateEnabled: true,
      claimedEnabled: true,
      statusHeaderAliases: 'Statut, Status',
      lateTerms: 'Retard, En retard, Late',
      claimedTerms: 'Réclamé, Reclamé, Claimed',
      fallbackStatusColumn: 6
    },
    labels: {
      lateFr: 'Afficher uniquement les retards',
      lateEn: 'Show late issues only',
      claimedFr: 'Afficher uniquement les réclamés',
      claimedEn: 'Show claimed issues only',
      resetFr: 'Afficher le tableau complet',
      resetEn: 'Show full table'
    },
    selectors: {
      form: '#claims_form',
      table: '#claimst'
    }
  };

  var currentConfig = clone(DEFAULT_CONFIG);
  var activeFilter = '';
  var dataTableFilter = null;
  var statusColumnIndex = -1;
  var currentTable = null;
  var subscribed = false;
  var configReadyBound = false;
  var tableObserver = null;
  var refreshTimer = null;
  var headerSignature = '';
  var currentForm = null;

  function clone(value) {
    try { return JSON.parse(JSON.stringify(value)); }
    catch (_) { return value; }
  }

  function isObject(value) {
    return value && typeof value === 'object' && !Array.isArray(value);
  }

  function merge(base, override) {
    if (Array.isArray(base)) return Array.isArray(override) ? clone(override) : clone(base);
    if (!isObject(base)) return override === undefined ? clone(base) : clone(override);
    var out = clone(base) || {};
    if (!isObject(override)) return out;
    Object.keys(override).forEach(function (key) {
      if (isObject(base[key]) && isObject(override[key])) out[key] = merge(base[key], override[key]);
      else out[key] = clone(override[key]);
    });
    return out;
  }

  function text(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function normalized(value) {
    var out = text(value).toLocaleLowerCase();
    try {
      out = out.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    } catch (_) {}
    return out;
  }

  function splitTerms(value) {
    return String(value == null ? '' : value)
      .split(/[\n,;|]+/)
      .map(function (entry) { return normalized(entry); })
      .filter(Boolean);
  }

  function language() {
    try {
      if (window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function') {
        return window.PMKConfig.getLanguage() === 'en' ? 'en' : 'fr';
      }
      var htmlLang = String(document.documentElement.lang || '').toLowerCase();
      return htmlLang.indexOf('en') === 0 ? 'en' : 'fr';
    } catch (_) {
      return 'fr';
    }
  }

  function label(frKey, enKey) {
    return language() === 'en'
      ? text(currentConfig.labels && currentConfig.labels[enKey])
      : text(currentConfig.labels && currentConfig.labels[frKey]);
  }

  function waitFor(selector, timeout) {
    var sel = text(selector);
    if (!sel) return Promise.reject(new Error('empty selector'));

    if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === 'function') {
      try { return window.KOHA_UTILS.waitFor(sel, timeout || 5000); }
      catch (_) {}
    }

    return new Promise(function (resolve, reject) {
      var existing = null;
      try { existing = document.querySelector(sel); } catch (_) {}
      if (existing) return resolve(existing);

      var done = false;
      var observer = new MutationObserver(function () {
        var found = null;
        try { found = document.querySelector(sel); } catch (_) {}
        if (!found || done) return;
        done = true;
        observer.disconnect();
        resolve(found);
      });

      observer.observe(document.documentElement, { childList: true, subtree: true });
      window.setTimeout(function () {
        if (done) return;
        done = true;
        observer.disconnect();
        reject(new Error('timeout'));
      }, timeout || 5000);
    });
  }

  function pageIsActive() {
    return Boolean(
      currentConfig &&
      currentConfig.enabled !== false &&
      currentConfig.page &&
      currentConfig.page.enabled !== false &&
      window.location.pathname === text(currentConfig.page.path || PAGE_PATH)
    );
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;

    var style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = [
      '#' + TOOLBAR_ID + '{',
      ' display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;',
      ' margin:.55rem 0 .75rem 0;',
      '}',
      '#' + TOOLBAR_ID + ' .pmk074-btn{',
      ' display:inline-flex;align-items:center;justify-content:center;gap:.35rem;',
      ' min-height:2rem;padding:.3rem .65rem;',
      ' border:1px solid #adb5bd;border-radius:.25rem;',
      ' background:#fff;color:#212529;',
      ' font:inherit;font-size:.9rem;line-height:1.25;',
      ' cursor:pointer;box-shadow:none;',
      '}',
      '#' + TOOLBAR_ID + ' .pmk074-btn:hover,',
      '#' + TOOLBAR_ID + ' .pmk074-btn:focus{',
      ' background:#f1f3f5;border-color:#868e96;color:#212529;text-decoration:none;',
      '}',
      '#' + TOOLBAR_ID + ' .pmk074-btn[aria-pressed="true"]{',
      ' background:#e9ecef;border-color:#6c757d;font-weight:600;',
      '}',
      '#' + TOOLBAR_ID + ' .pmk074-dot{',
      ' width:.55rem;height:.55rem;border-radius:50%;display:inline-block;',
      ' background:currentColor;opacity:.7;flex:0 0 auto;',
      '}',
      '#' + TOOLBAR_ID + ' .pmk074-late{color:#9a6700;}',
      '#' + TOOLBAR_ID + ' .pmk074-claimed{color:#9b2c2c;}',
      '#' + CONFIG_HOST_ID + '{display:inline-flex;align-items:center;margin-left:.15rem;}',
      '@media(max-width:575.98px){',
      ' #' + TOOLBAR_ID + '{align-items:stretch;}',
      ' #' + TOOLBAR_ID + ' .pmk074-btn{flex:1 1 100%;justify-content:flex-start;}',
      '}'
    ].join('\n');
    document.head.appendChild(style);
  }

  function removeStyles() {
    var style = document.getElementById(STYLE_ID);
    if (style) style.remove();
  }

  function findStatusColumn(table) {
    if (!table) return -1;
    var aliases = splitTerms(currentConfig.filters && currentConfig.filters.statusHeaderAliases);
    var headers = table.querySelectorAll('thead th');

    for (var i = 0; i < headers.length; i += 1) {
      var value = normalized(headers[i].textContent);
      if (!value) continue;
      for (var a = 0; a < aliases.length; a += 1) {
        if (value === aliases[a] || value.indexOf(aliases[a]) !== -1) return i;
      }
    }

    var fallback = Number(currentConfig.filters && currentConfig.filters.fallbackStatusColumn);
    if (Number.isInteger(fallback) && fallback >= 0 && fallback < headers.length) return fallback;
    return -1;
  }

  function filterTerms(kind) {
    if (kind === 'late') return splitTerms(currentConfig.filters && currentConfig.filters.lateTerms);
    if (kind === 'claimed') return splitTerms(currentConfig.filters && currentConfig.filters.claimedTerms);
    return [];
  }

  function statusMatches(value, kind) {
    if (!kind) return true;
    var haystack = normalized(value);
    if (!haystack) return false;
    var terms = filterTerms(kind);
    for (var i = 0; i < terms.length; i += 1) {
      if (terms[i] && haystack.indexOf(terms[i]) !== -1) return true;
    }
    return false;
  }

  function dataTablesAvailable() {
    return Boolean(
      window.jQuery &&
      window.jQuery.fn &&
      window.jQuery.fn.dataTable &&
      window.jQuery.fn.dataTable.ext &&
      Array.isArray(window.jQuery.fn.dataTable.ext.search)
    );
  }

  function tableHasDataTable(table) {
    if (!table || !window.jQuery || !window.jQuery.fn) return false;
    try {
      if (window.jQuery.fn.DataTable && typeof window.jQuery.fn.DataTable.isDataTable === 'function') {
        return window.jQuery.fn.DataTable.isDataTable(table);
      }
      return Boolean(window.jQuery(table).hasClass('dataTable'));
    } catch (_) {
      return false;
    }
  }

  function removeDataTableFilter() {
    if (!dataTableFilter || !dataTablesAvailable()) {
      dataTableFilter = null;
      return;
    }
    var list = window.jQuery.fn.dataTable.ext.search;
    for (var i = list.length - 1; i >= 0; i -= 1) {
      if (list[i] === dataTableFilter) list.splice(i, 1);
    }
    dataTableFilter = null;
  }

  function installDataTableFilter(table) {
    removeDataTableFilter();
    if (!table || !dataTablesAvailable()) return false;

    dataTableFilter = function (settings, data, dataIndex, rowData, counter) {
      if (!settings || settings.nTable !== table) return true;
      if (!activeFilter || statusColumnIndex < 0) return true;

      var value = '';
      if (Array.isArray(data) && statusColumnIndex >= 0) value = data[statusColumnIndex] || '';

      if (!text(value) && settings.aoData && settings.aoData[dataIndex] && settings.aoData[dataIndex].nTr) {
        var row = settings.aoData[dataIndex].nTr;
        var cell = row && row.cells ? row.cells[statusColumnIndex] : null;
        value = cell ? cell.textContent : '';
      }
      return statusMatches(value, activeFilter);
    };

    window.jQuery.fn.dataTable.ext.search.push(dataTableFilter);
    return true;
  }

  function restoreDomRows(table) {
    if (!table) return;
    Array.prototype.forEach.call(table.querySelectorAll('tbody tr'), function (row) {
      if (row.hasAttribute('data-pmk074-display')) {
        row.style.display = row.getAttribute('data-pmk074-display') || '';
        row.removeAttribute('data-pmk074-display');
      }
    });
  }

  function applyDomFilter(table) {
    if (!table || statusColumnIndex < 0) return;
    var rows = table.querySelectorAll('tbody tr');
    Array.prototype.forEach.call(rows, function (row) {
      if (!row.hasAttribute('data-pmk074-display')) {
        row.setAttribute('data-pmk074-display', row.style.display || '');
      }
      if (!activeFilter) {
        row.style.display = row.getAttribute('data-pmk074-display') || '';
        return;
      }
      var cell = row.cells ? row.cells[statusColumnIndex] : null;
      row.style.display = cell && statusMatches(cell.textContent, activeFilter) ? (row.getAttribute('data-pmk074-display') || '') : 'none';
    });
  }

  function redrawTable() {
    if (!currentTable) return;

    if (tableHasDataTable(currentTable)) {
      restoreDomRows(currentTable);
      try {
        var api = window.jQuery(currentTable).DataTable();
        api.draw(false);
        return;
      } catch (_) {}
    }

    applyDomFilter(currentTable);
  }

  function updateButtons() {
    var late = document.querySelector('#' + TOOLBAR_ID + ' [data-pmk074-filter="late"]');
    var claimed = document.querySelector('#' + TOOLBAR_ID + ' [data-pmk074-filter="claimed"]');
    var resetLabel = label('resetFr', 'resetEn') || (language() === 'en' ? 'Show full table' : 'Afficher le tableau complet');

    if (late) {
      var lateActive = activeFilter === 'late';
      late.setAttribute('aria-pressed', lateActive ? 'true' : 'false');
      var lateText = lateActive ? resetLabel : (label('lateFr', 'lateEn') || (language() === 'en' ? 'Show late issues only' : 'Afficher uniquement les retards'));
      var lateLabel = late.querySelector('.pmk074-label');
      if (lateLabel) lateLabel.textContent = lateText;
    }

    if (claimed) {
      var claimedActive = activeFilter === 'claimed';
      claimed.setAttribute('aria-pressed', claimedActive ? 'true' : 'false');
      var claimedText = claimedActive ? resetLabel : (label('claimedFr', 'claimedEn') || (language() === 'en' ? 'Show claimed issues only' : 'Afficher uniquement les réclamés'));
      var claimedLabel = claimed.querySelector('.pmk074-label');
      if (claimedLabel) claimedLabel.textContent = claimedText;
    }
  }

  function setFilter(kind) {
    if (statusColumnIndex < 0) return;
    activeFilter = activeFilter === kind ? '' : kind;
    updateButtons();
    redrawTable();
  }

  function makeButton(kind, className, labelText) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn btn-default btn-sm pmk074-btn ' + className;
    button.setAttribute('data-pmk074-filter', kind);
    button.setAttribute('aria-pressed', 'false');

    var dot = document.createElement('span');
    dot.className = 'pmk074-dot';
    dot.setAttribute('aria-hidden', 'true');

    var span = document.createElement('span');
    span.className = 'pmk074-label';
    span.textContent = labelText;

    button.appendChild(dot);
    button.appendChild(span);
    button.addEventListener('click', function () { setFilter(kind); });
    return button;
  }

  function mountConfigButton(toolbar) {
    if (!toolbar || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
    if (!window.PMKConfig.canOpenAdmin || !window.PMKConfig.canOpenAdmin()) return;

    var existing = document.getElementById(CONFIG_HOST_ID);
    if (existing) existing.remove();

    var host = document.createElement('span');
    host.id = CONFIG_HOST_ID;
    toolbar.appendChild(host);

    try {
      window.PMKConfig.mountContextButton({
        moduleId: MODULE_ID,
        anchor: host,
        contextKey: 'claims-filters',
        context: { sectionId: 'filters', pagePath: PAGE_PATH }
      });
    } catch (_) {}
  }

  function removeToolbar() {
    var toolbar = document.getElementById(TOOLBAR_ID);
    if (toolbar) toolbar.remove();
  }

  function cleanup() {
    if (tableObserver) tableObserver.disconnect();
    tableObserver = null;
    clearTimeout(refreshTimer);
    refreshTimer = null;
    headerSignature = '';
    currentForm = null;
    activeFilter = '';
    removeDataTableFilter();
    if (currentTable) {
      restoreDomRows(currentTable);
      if (tableHasDataTable(currentTable)) {
        try { window.jQuery(currentTable).DataTable().draw(false); } catch (_) {}
      }
    }
    currentTable = null;
    statusColumnIndex = -1;
    removeToolbar();
    removeStyles();
  }

  function render(form, table) {
    if (!form || !table || !form.parentNode) return;

    removeToolbar();
    injectStyles();
    currentTable = table;
    statusColumnIndex = findStatusColumn(table);
    installDataTableFilter(table);

    var toolbar = document.createElement('div');
    toolbar.id = TOOLBAR_ID;
    toolbar.className = 'pmk074-toolbar';
    toolbar.setAttribute('role', 'group');
    toolbar.setAttribute('aria-label', language() === 'en' ? 'Claims filters' : 'Filtres des réclamations');

    if (!currentConfig.filters || currentConfig.filters.lateEnabled !== false) {
      toolbar.appendChild(makeButton(
        'late',
        'pmk074-late',
        label('lateFr', 'lateEn') || (language() === 'en' ? 'Show late issues only' : 'Afficher uniquement les retards')
      ));
    }

    if (!currentConfig.filters || currentConfig.filters.claimedEnabled !== false) {
      toolbar.appendChild(makeButton(
        'claimed',
        'pmk074-claimed',
        label('claimedFr', 'claimedEn') || (language() === 'en' ? 'Show claimed issues only' : 'Afficher uniquement les réclamés')
      ));
    }

    var note = document.createElement('span');
    note.className = 'pmk074-diagnostic';
    note.setAttribute('role', 'status');
    if (statusColumnIndex < 0) {
      note.textContent = language() === 'en'
        ? 'Status column not found. No rows are filtered. Check the column names or position in the settings.'
        : 'Colonne de statut introuvable. Aucune ligne n’est filtrée. Vérifiez son intitulé ou sa position dans les réglages.';
      toolbar.querySelectorAll('button').forEach(function (button) { button.disabled = true; });
    } else {
      var aliases = splitTerms(currentConfig.filters && currentConfig.filters.statusHeaderAliases);
      var heading = table.querySelectorAll('thead th')[statusColumnIndex];
      var value = normalized(heading && heading.textContent);
      var byName = aliases.some(function (alias) { return value === alias || value.indexOf(alias) !== -1; });
      if (!byName) note.textContent = language() === 'en'
        ? 'Status uses configured column position ' + (statusColumnIndex + 1) + '. Check this position if the table changes.'
        : 'Le statut utilise la position configurée : colonne ' + (statusColumnIndex + 1) + '. Vérifiez-la si le tableau change.';
    }
    if (note.textContent) toolbar.appendChild(note);
    if (!toolbar.querySelector('.pmk074-btn') && !note.textContent) return;

    form.parentNode.insertBefore(toolbar, form);
    mountConfigButton(toolbar);
    updateButtons();
  }

  function applyConfig() {
    cleanup();
    if (!pageIsActive()) return;
    var formSelector = text(currentConfig.selectors && currentConfig.selectors.form) || '#claims_form';
    var tableSelector = text(currentConfig.selectors && currentConfig.selectors.table) || '#claimst';
    // Validate selectors once; an invalid custom target must never hide native rows.
    try { document.querySelector(formSelector); document.querySelector(tableSelector); }
    catch (_) { return; }

    function refresh(rowsChanged) {
      if (!pageIsActive()) return;
      tableObserver.disconnect();
      try {
        var form = document.querySelector(formSelector);
        var table = document.querySelector(tableSelector);
        var signature = table ? Array.from(table.querySelectorAll('thead th')).map(function (th) { return th.textContent; }).join('\u0000') : '';
        var changed = table !== currentTable || form !== currentForm || signature !== headerSignature;
        if (changed) {
          removeDataTableFilter();
          if (currentTable) {
            restoreDomRows(currentTable);
            if (currentTable !== table && tableHasDataTable(currentTable)) {
              try { window.jQuery(currentTable).DataTable().draw(false); } catch (_) {}
            }
          }
          removeToolbar();
          currentTable = table;
          currentForm = form;
          headerSignature = signature;
          statusColumnIndex = -1;
          if (form && table) render(form, table);
        }
        if (currentTable && currentForm && (changed || rowsChanged)) redrawTable();
      } finally {
        if (tableObserver) tableObserver.observe(document.body || document.documentElement, {childList:true, subtree:true, characterData:true});
      }
    }
    var rowsDirty = false;
    tableObserver = new MutationObserver(function (mutations) {
      rowsDirty = rowsDirty || mutations.some(function (mutation) { return currentTable && currentTable.contains(mutation.target); });
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(function () { var dirty = rowsDirty; rowsDirty = false; refresh(dirty); }, 40);
    });
    refresh(true);
  }

  function loadWithPMK() {
    if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') return false;

    window.PMKConfig.getConfig(MODULE_ID).then(function (config) {
      currentConfig = merge(DEFAULT_CONFIG, config || {});
      applyConfig();
    }).catch(function () {
      currentConfig = clone(DEFAULT_CONFIG);
      applyConfig();
    });

    if (!subscribed && typeof window.PMKConfig.subscribe === 'function') {
      subscribed = true;
      window.PMKConfig.subscribe(MODULE_ID, function (config) {
        currentConfig = merge(DEFAULT_CONFIG, config || {});
        applyConfig();
      });
    }
    return true;
  }

  function boot() {
    if (window.location.pathname !== PAGE_PATH) return;

    if (loadWithPMK()) return;

    // Mode autonome / dégradé : comportement historique actif avec
    // valeurs par défaut, puis reprise de la configuration dès que PMK
    // devient disponible.
    currentConfig = clone(DEFAULT_CONFIG);
    applyConfig();

    if (!configReadyBound) {
      configReadyBound = true;
      window.addEventListener('pmk:config-ready', function () {
        loadWithPMK();
      }, { once: true });
    }
  }

  boot();
})();

;window.PMKNonPlugin.loaded.push("074-claims-filtering.js");
} catch (error) { window.PMKNonPlugin.errors.push("074-claims-filtering.js: "+error.message); console.error("[PMK] 074-claims-filtering.js",error); };
try {
/*
 Nom du fichier : 075-advanced-search-pmk-loader.js
 Version : 1.0.0
 Date : 2026-09-19

 Rôle :
 - NE MODIFIE PAS le module autonome 075-advanced-search-sidebar.js ;
 - enregistre dans PimpMyKoha un interrupteur Activer / Désactiver ;
 - charge le script 075 uniquement lorsque le module PMK est actif ;
 - masque/ferme immédiatement son interface lorsque le module est désactivé ;
 - bloque ALT+clic et l'événement koha:toggleAdvancedSearch quand le module est désactivé ;
 - expose une passerelle stable pour 134-intranetnav-menu.js.

 Important :
 - ce loader remplace le chargement direct de 075-advanced-search-sidebar.js
   dans IntranetUserJS ;
 - 075-advanced-search-sidebar.js reste inchangé.
*/
(function () {
    'use strict';

    if (window.__PMK_ADVANCED_SEARCH_LOADER__) return;
    window.__PMK_ADVANCED_SEARCH_LOADER__ = true;

    const MODULE_ID = 'advanced-search-sidebar';
    const RUNTIME_SCRIPT_ID = 'pmk-advanced-search-runtime-script';
    const DISABLED_STYLE_ID = 'pmk-advanced-search-disabled-style';
    const DISABLED_CLASS = 'pmk-advanced-search-disabled';
    const SCRIPT_URL = (window.PMKPlugin?.assetUrl ? window.PMKPlugin.assetUrl('075-advanced-search-sidebar.js') : '/public/koha-scripts/075-advanced-search-sidebar.js');

    let currentConfig = { enabled: true, indexes:{"seriesEnabled": true, "seriesIndex": "index-title-serie", "treeEnabled": true, "domainIndex": "f099a", "subdomainIndex": "f099b", "themeIndex": "f099e", "subjectIndex": "f099f", "additionalIndexes":[]} };
    let configRegistered = false;
    let loadingPromise = null;
    let unsubscribe = null;

    function isLoaded() {
        return !!window.__kohaAdvancedSearchSidebarV2 ||
            typeof window.openAdvancedSearchSidebar === 'function' ||
            typeof window.toggleAdvancedSearchSidebar === 'function';
    }

    function isAvailable() {
        return currentConfig.enabled !== false;
    }

    function dispatchState(extra) {
        try {
            window.dispatchEvent(new CustomEvent('pmk:advanced-search-state', {
                detail: Object.assign({
                    moduleId: MODULE_ID,
                    enabled: isAvailable(),
                    loaded: isLoaded(),
                    available: isAvailable()
                }, extra || {})
            }));
        } catch (_) {}
    }

    function installDisabledMask() {
        if (document.getElementById(DISABLED_STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = DISABLED_STYLE_ID;
        style.textContent = `
            html.${DISABLED_CLASS} #kohaAdvancedSearchSidebar,
            html.${DISABLED_CLASS} #kohaAdvancedSearchToast,
            html.${DISABLED_CLASS} #bottomActionBar #advancedSearch {
                display: none !important;
            }
        `;
        document.head.appendChild(style);
    }

    function closeRuntimePanel() {
        try {
            if (typeof window.closeAdvancedSearchSidebar === 'function') {
                window.closeAdvancedSearchSidebar();
                return;
            }
            const panel = document.getElementById('kohaAdvancedSearchSidebar');
            if (panel) panel.classList.remove('open');
        } catch (_) {}
    }

    function setDisabledMask(disabled) {
        installDisabledMask();
        document.documentElement.classList.toggle(DISABLED_CLASS, !!disabled);
        if (disabled) closeRuntimePanel();
    }

    /*
     * Le 075 historique installe un ALT+clic global et écoute
     * koha:toggleAdvancedSearch. Comme on ne touche pas à son code, le loader
     * neutralise uniquement ces deux points d'entrée lorsque PMK le désactive.
     */
    document.addEventListener('click', function (event) {
        if (currentConfig.enabled !== false || !event.altKey) return;
        event.preventDefault();
        event.stopImmediatePropagation();
    }, true);

    document.addEventListener('koha:toggleAdvancedSearch', function (event) {
        if (currentConfig.enabled !== false) return;
        if (event && typeof event.preventDefault === 'function') event.preventDefault();
        if (event && typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
    }, true);

    function existingRuntimeScript() {
        return document.getElementById(RUNTIME_SCRIPT_ID) ||
            Array.from(document.scripts || []).find(function (script) {
                return /(?:^|\/)075-advanced-search-sidebar\.js(?:\?|$)/.test(String(script.src || ''));
            }) || null;
    }

    function waitForRuntime(timeout) {
        const limit = Number(timeout) > 0 ? Number(timeout) : 5000;
        return new Promise(function (resolve) {
            if (isLoaded()) return resolve(true);
            const started = Date.now();
            const timer = window.setInterval(function () {
                if (isLoaded()) {
                    window.clearInterval(timer);
                    resolve(true);
                    return;
                }
                if (Date.now() - started >= limit) {
                    window.clearInterval(timer);
                    resolve(false);
                }
            }, 50);
        });
    }

    function loadHistoricalModule() {
        if (currentConfig.enabled === false) {
            setDisabledMask(true);
            dispatchState({ reason: 'disabled' });
            return Promise.resolve(false);
        }

        setDisabledMask(false);

        if (isLoaded()) {
            dispatchState({ reason: 'already-loaded' });
            return Promise.resolve(true);
        }

        if (loadingPromise) return loadingPromise;

        const existing = existingRuntimeScript();
        if (existing && existing.id !== RUNTIME_SCRIPT_ID) {
            loadingPromise = waitForRuntime(5000).then(function (loaded) {
                loadingPromise = null;
                dispatchState({ reason: loaded ? 'legacy-direct-load' : 'legacy-load-timeout' });
                return loaded;
            });
            return loadingPromise;
        }

        loadingPromise = new Promise(function (resolve) {
            const script = existing || document.createElement('script');
            script.id = RUNTIME_SCRIPT_ID;
            script.src = SCRIPT_URL;
            script.async = true;
            script.dataset.pmkControlled = '1';

            script.addEventListener('load', function () {
                waitForRuntime(3000).then(function (loaded) {
                    loadingPromise = null;
                    setDisabledMask(currentConfig.enabled === false);
                    dispatchState({ reason: loaded ? 'loaded' : 'runtime-not-ready' });
                    resolve(loaded);
                });
            }, { once: true });

            script.addEventListener('error', function () {
                loadingPromise = null;
                dispatchState({ reason: 'load-error' });
                resolve(false);
            }, { once: true });

            if (!script.isConnected) document.head.appendChild(script);
        });

        return loadingPromise;
    }

    async function openAdvancedSearch() {
        if (currentConfig.enabled === false) return false;
        const loaded = await loadHistoricalModule();
        if (!loaded) return false;

        if (typeof window.openAdvancedSearchSidebar === 'function') {
            window.openAdvancedSearchSidebar();
            return true;
        }
        if (typeof window.toggleAdvancedSearchSidebar === 'function') {
            window.toggleAdvancedSearchSidebar();
            return true;
        }
        try {
            document.dispatchEvent(new CustomEvent('koha:toggleAdvancedSearch'));
            return true;
        } catch (_) {
            return false;
        }
    }

    async function toggleAdvancedSearch() {
        if (currentConfig.enabled === false) return false;
        const loaded = await loadHistoricalModule();
        if (!loaded) return false;

        if (typeof window.toggleAdvancedSearchSidebar === 'function') {
            window.toggleAdvancedSearchSidebar();
            return true;
        }
        return openAdvancedSearch();
    }

    function applyConfig(config) {
        currentConfig = Object.assign({ enabled: true }, config || {});
        window.PMKAdvancedSearchOptions=currentConfig.indexes;
        const disabled = currentConfig.enabled === false;
        setDisabledMask(disabled);

        if (!disabled) loadHistoricalModule();
        dispatchState({ reason: 'config' });
    }

    function registerWithPMK() {
        if (!window.PMKConfig || configRegistered) return false;
        configRegistered = true;

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 1,
            name: {
                fr: 'Recherche avancée',
                en: 'Advanced search'
            },
            description: {
                fr: 'Active ou désactive le module autonome de recherche avancée sans modifier son fonctionnement interne. L’accès peut être placé dans le Menu IntranetNav.',
                en: 'Enables or disables the standalone advanced-search module without changing its internal behavior. Its entry point can be placed in the IntranetNav menu.'
            },
            category: {
                fr: 'Catalogue / recherche',
                en: 'Catalogue / search'
            },
            defaults: {
                enabled: true, indexes:{"seriesEnabled": true, "seriesIndex": "index-title-serie", "treeEnabled": true, "domainIndex": "f099a", "subdomainIndex": "f099b", "themeIndex": "f099e", "subjectIndex": "f099f", "additionalIndexes":[]}
            },
            schema: [{"type": "section", "id": "indexes", "label": {"fr": "Index propres à votre Koha — recharger après modification", "en": "Indexes from your Koha — reload after changes"}, "description":{"fr":"Les index par défaut conservent la configuration d’origine. Ajoutez ici les index exposés par une autre installation Koha.","en":"Default indexes preserve the original configuration. Add indexes exposed by another Koha installation here."}, "fields": [{"key": "indexes.seriesEnabled", "type": "boolean", "label": {"fr": "Proposer le titre de série", "en": "Offer series title"}}, {"key": "indexes.seriesIndex", "type": "text", "label": {"fr": "Index du titre de série", "en": "Series title index"}}, {"key": "indexes.treeEnabled", "type": "boolean", "label": {"fr": "Proposer les critères de l’arborescence", "en": "Offer tree criteria"}}, {"key": "indexes.domainIndex", "type": "text", "label": {"fr": "Index Domaine", "en": "Domain index"}}, {"key": "indexes.subdomainIndex", "type": "text", "label": {"fr": "Index Sous-domaine", "en": "Subdomain index"}}, {"key": "indexes.themeIndex", "type": "text", "label": {"fr": "Index Thème", "en": "Theme index"}}, {"key": "indexes.subjectIndex", "type": "text", "label": {"fr": "Index Sujet", "en": "Subject index"}}, {"key":"indexes.additionalIndexes","type":"repeater","label":{"fr":"Autres index de recherche","en":"Other search indexes"},"addLabel":{"fr":"Ajouter un index","en":"Add an index"},"newItem":{"enabled":true,"label":"","group":"Index personnalisés","index":"","exactIndex":""},"itemTitle":function(item,index){return item&&item.label?item.label:"Index "+(index+1);},"fields":[{"key":"enabled","type":"boolean","label":{"fr":"Actif","en":"Enabled"}},{"key":"label","type":"text","label":{"fr":"Libellé visible","en":"Visible label"}},{"key":"group","type":"text","label":{"fr":"Groupe","en":"Group"}},{"key":"index","type":"text","label":{"fr":"Index Koha","en":"Koha index"},"help":{"fr":"Exemple : publdate, Host-item ou un index Zebra/Elasticsearch propre à votre installation.","en":"Example: publdate, Host-item or a Zebra/Elasticsearch index from your installation."}},{"key":"exactIndex","type":"text","label":{"fr":"Index exact (facultatif)","en":"Exact index (optional)"}}]}]}]
        });

        window.PMKConfig.getConfig(MODULE_ID)
            .then(applyConfig)
            .catch(function () {
                applyConfig({ enabled: true });
            });

        if (typeof window.PMKConfig.subscribe === 'function') {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
        }

        return true;
    }

    window.PMKAdvancedSearch = {
        moduleId: MODULE_ID,
        scriptUrl: SCRIPT_URL,
        get enabled() {
            return currentConfig.enabled !== false;
        },
        get loaded() {
            return isLoaded();
        },
        ensureLoaded: loadHistoricalModule,
        open: openAdvancedSearch,
        toggle: toggleAdvancedSearch,
        close: closeRuntimePanel,
        refreshState: function () {
            dispatchState({ reason: 'manual-refresh' });
        }
    };

    function bootstrap() {
        installDisabledMask();

        if (registerWithPMK()) return;

        window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });

        let tries = 0;
        const timer = window.setInterval(function () {
            tries += 1;
            if (registerWithPMK() || tries >= 100) {
                window.clearInterval(timer);
                if (!configRegistered) {
                    /* PMK absent : comportement historique conservé par défaut. */
                    currentConfig = { enabled: true };
                    setDisabledMask(false);
                    loadHistoricalModule();
                }
            }
        }, 50);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    } else {
        bootstrap();
    }

    window.addEventListener('beforeunload', function () {
        if (typeof unsubscribe === 'function') {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("075-advanced-search-pmk-loader.js");
} catch (error) { window.PMKNonPlugin.errors.push("075-advanced-search-pmk-loader.js: "+error.message); console.error("[PMK] 075-advanced-search-pmk-loader.js",error); };
try {
/* ============================================================
   077-save-guarantor-tp4.js
   Module PMK : Impression des résultats de rapports
   Version    : 2.0.0
   Date       : 2026-09-19

   IMPORTANT
   ----------
   Le nom historique du fichier est conservé uniquement pour ne pas
   casser l'IntranetUserJS existant. Ce script ne traite plus et ne
   sauvegarde aucune information de garant.

   Fonction :
   - ajoute une action "Imprimer le tableau" sur les résultats d'un
     rapport Koha (guided_reports.pl) ;
   - s'appuie sur #report_results et non sur le bouton graphique Koha ;
   - respecte par défaut les lignes et colonnes actuellement visibles,
     y compris après filtrage/masquage par un autre module tel que 062 ;
   - ajoute le titre du rapport et son identifiant selon configuration ;
   - choisit automatiquement portrait/paysage ou respecte le choix PMK ;
   - s'intègre dans #toolbar lorsque Koha le fournit et crée sinon une
     petite barre d'actions compatible Koha juste au-dessus du tableau ;
   - garde anti-double chargement ;
   - configuration FR/EN via PMKConfig avec valeurs par défaut locales.

   Compatibilité visée : Koha 24.11 / 25.11 / 26.05.
   ============================================================ */
(function () {
    "use strict";

    if (window.__PMK_077_GUIDED_REPORT_PRINT__) return;
    window.__PMK_077_GUIDED_REPORT_PRINT__ = true;

    var MODULE_ID = "guided-report-print";
    var PAGE_PATH = "/cgi-bin/koha/reports/guided_reports.pl";
    var BUTTON_ID = "pmk077-print-report";
    var GROUP_ID = "pmk077-print-group";
    var OWN_TOOLBAR_ID = "pmk077-toolbar";
    var CONFIG_HOST_ID = "pmk077-config-host";

    var DEFAULT_CONFIG = {
        enabled: true,
        page: {
            enabled: true,
            path: PAGE_PATH
        },
        print: {
            showTitle: true,
            showReportId: true,
            visibleRowsOnly: true,
            visibleColumnsOnly: true,
            orientation: "auto",
            autoLandscapeColumns: 7
        },
        labels: {
            buttonFr: "Imprimer le tableau",
            buttonEn: "Print table",
            documentFr: "Résultats du rapport",
            documentEn: "Report results",
            reportIdFr: "Rapport n°",
            reportIdEn: "Report ID",
            popupBlockedFr: "La fenêtre d'impression a été bloquée par le navigateur.",
            popupBlockedEn: "The print window was blocked by the browser."
        },
        selectors: {
            table: "#report_results",
            toolbar: "#toolbar",
            paginationTop: "#pagination_top",
            heading: "main h1",
            reportNumber: ".report_heading_id .report_number"
        }
    };

    var currentConfig = clone(DEFAULT_CONFIG);
    var subscribed = false;

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function merge(base, patch) {
        var out = clone(base);
        if (!patch || typeof patch !== "object") return out;
        Object.keys(patch).forEach(function (key) {
            var value = patch[key];
            if (
                value &&
                typeof value === "object" &&
                !Array.isArray(value) &&
                out[key] &&
                typeof out[key] === "object" &&
                !Array.isArray(out[key])
            ) {
                out[key] = merge(out[key], value);
            } else {
                out[key] = clone(value);
            }
        });
        return out;
    }

    function text(value) {
        return String(value == null ? "" : value).trim();
    }

    function pageIsActive() {
        if (window.location.pathname !== PAGE_PATH) return false;
        if (!currentConfig.enabled) return false;
        return !currentConfig.page || currentConfig.page.enabled !== false;
    }

    function language() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            }
            var htmlLang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
            return htmlLang.indexOf("en") === 0 ? "en" : "fr";
        } catch (_) {
            return "fr";
        }
    }

    function label(frKey, enKey) {
        var labels = currentConfig.labels || {};
        return language() === "en" ? text(labels[enKey]) : text(labels[frKey]);
    }

    function waitFor(selector, timeout) {
        var sel = text(selector);
        if (!sel) return Promise.reject(new Error("empty selector"));

        if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === "function") {
            try {
                return window.KOHA_UTILS.waitFor(sel, timeout || 5000);
            } catch (_) {}
        }

        return new Promise(function (resolve, reject) {
            var first;
            try { first = document.querySelector(sel); } catch (err) { reject(err); return; }
            if (first) { resolve(first); return; }

            var root = document.documentElement || document.body;
            if (!root) { reject(new Error("document root unavailable")); return; }

            var done = false;
            var observer = new MutationObserver(function () {
                if (done) return;
                var found = null;
                try { found = document.querySelector(sel); } catch (_) {}
                if (found) {
                    done = true;
                    observer.disconnect();
                    resolve(found);
                }
            });
            observer.observe(root, { childList: true, subtree: true });

            window.setTimeout(function () {
                if (done) return;
                done = true;
                observer.disconnect();
                reject(new Error("timeout"));
            }, timeout || 5000);
        });
    }

    function isActuallyVisible(node) {
        if (!node || node.nodeType !== 1) return false;
        if (node.hidden || node.getAttribute("aria-hidden") === "true") return false;
        if (node.classList.contains("d-none") || node.classList.contains("hidden")) return false;
        try {
            var style = window.getComputedStyle(node);
            if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
        } catch (_) {}
        return true;
    }

    function visibleColumnIndexes(table) {
        if (!table) return [];
        var row = table.querySelector("thead tr");
        if (!row) return [];
        return Array.prototype.map.call(row.children, function (cell, index) {
            return isActuallyVisible(cell) ? index : -1;
        }).filter(function (index) { return index >= 0; });
    }

    function removeHiddenRows(sourceTable, clonedTable) {
        if (!currentConfig.print || currentConfig.print.visibleRowsOnly === false) return;
        var sourceRows = sourceTable.querySelectorAll("tbody tr");
        var clonedRows = clonedTable.querySelectorAll("tbody tr");
        for (var i = clonedRows.length - 1; i >= 0; i -= 1) {
            var source = sourceRows[i];
            if (!source || !isActuallyVisible(source)) clonedRows[i].remove();
        }
    }

    function removeHiddenColumns(sourceTable, clonedTable) {
        if (!currentConfig.print || currentConfig.print.visibleColumnsOnly === false) return;
        var header = sourceTable.querySelector("thead tr");
        if (!header) return;

        var hidden = [];
        Array.prototype.forEach.call(header.children, function (cell, index) {
            if (!isActuallyVisible(cell)) hidden.push(index);
        });
        if (!hidden.length) return;

        var rows = clonedTable.querySelectorAll("tr");
        Array.prototype.forEach.call(rows, function (row) {
            for (var i = hidden.length - 1; i >= 0; i -= 1) {
                var index = hidden[i];
                if (row.children[index]) row.children[index].remove();
            }
        });
    }

    function cleanClone(clonedTable) {
        if (!clonedTable) return;
        clonedTable.removeAttribute("id");
        clonedTable.removeAttribute("style");
        clonedTable.className = "pmk077-print-table";

        clonedTable.querySelectorAll("script, style, iframe, object, embed, base, link, meta, .dropdown-menu, .tooltip, .popover, .data-plain, [aria-hidden='true']").forEach(function (node) {
            node.remove();
        });

        [clonedTable,...clonedTable.querySelectorAll('*')].forEach(node=>{for(const attr of Array.from(node.attributes)){if(/^on/i.test(attr.name)||attr.name==='srcdoc')node.removeAttribute(attr.name);}});

        clonedTable.querySelectorAll("button, input, select, textarea").forEach(function (node) {
            var replacement = document.createTextNode(text(node.textContent || node.value || ""));
            if (node.parentNode) node.parentNode.replaceChild(replacement, node);
        });

        clonedTable.querySelectorAll("a").forEach(function (link) {
            link.removeAttribute("href");
            link.removeAttribute("target");
            link.removeAttribute("role");
            link.removeAttribute("data-bs-toggle");
            link.removeAttribute("data-toggle");
        });

        // Les styles d’écran ne doivent pas polluer l’impression.
        // Si l’utilisateur a désactivé "visibleColumnsOnly", retirer un
        // display:none permet au contraire de réimprimer la colonne masquée.
        clonedTable.querySelectorAll("[style]").forEach(function (node) {
            node.removeAttribute("style");
        });
    }

    function getReportId() {
        var selector = text(currentConfig.selectors && currentConfig.selectors.reportNumber);
        if (selector) {
            try {
                var node = document.querySelector(selector);
                if (node && text(node.textContent)) return text(node.textContent);
            } catch (_) {}
        }
        try {
            return text(new URL(window.location.href).searchParams.get("id"));
        } catch (_) {
            return "";
        }
    }

    function getReportTitle() {
        var selector = text(currentConfig.selectors && currentConfig.selectors.heading);
        if (!selector) return "";
        var heading = null;
        try { heading = document.querySelector(selector); } catch (_) {}
        if (!heading) return "";

        var copy = heading.cloneNode(true);
        copy.querySelectorAll(".report_heading_id").forEach(function (node) { node.remove(); });
        return text(copy.textContent);
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function resolveOrientation(table) {
        var configured = text(currentConfig.print && currentConfig.print.orientation).toLowerCase();
        if (configured === "portrait" || configured === "landscape") return configured;

        var threshold = Number(currentConfig.print && currentConfig.print.autoLandscapeColumns);
        if (!Number.isFinite(threshold) || threshold < 2) threshold = 7;
        var columns;
        if (currentConfig.print && currentConfig.print.visibleColumnsOnly === false) {
            var header = table.querySelector("thead tr");
            columns = header ? header.children.length : 0;
        } else {
            columns = visibleColumnIndexes(table).length;
        }
        return columns >= threshold ? "landscape" : "portrait";
    }

    function printTable() {
        var tableSelector = text(currentConfig.selectors && currentConfig.selectors.table) || "#report_results";
        var table = null;
        try { table = document.querySelector(tableSelector); } catch (_) {}
        if (!table) return;

        var printWindow = window.open("", "pmk077-report-print", "height=900,width=1100");
        if (!printWindow) {
            window.alert(label("popupBlockedFr", "popupBlockedEn") || "Print window blocked.");
            return;
        }

        var cloneTable = table.cloneNode(true);
        removeHiddenRows(table, cloneTable);
        removeHiddenColumns(table, cloneTable);
        cleanClone(cloneTable);

        var orientation = resolveOrientation(table);
        var reportTitle = getReportTitle();
        var reportId = getReportId();
        var showTitle = !currentConfig.print || currentConfig.print.showTitle !== false;
        var showReportId = !currentConfig.print || currentConfig.print.showReportId !== false;
        var fallbackTitle = label("documentFr", "documentEn") || "Report results";

        var titleHtml = "";
        if (showTitle) {
            titleHtml += '<h1>' + escapeHtml(reportTitle || fallbackTitle) + "</h1>";
        }
        if (showReportId && reportId) {
            titleHtml += '<div class="pmk077-report-id">' + escapeHtml(label("reportIdFr", "reportIdEn") || "Report ID") + " " + escapeHtml(reportId) + "</div>";
        }

        const printedRows=cloneTable.querySelectorAll('tbody tr').length;
        titleHtml+='<p class="pmk077-print-scope">'+escapeHtml(printedRows+' '+(document.documentElement.lang.startsWith('en')?'row(s) loaded in this browser; unloaded result pages are not included.':'ligne(s) chargée(s) dans ce navigateur ; les pages de résultats non chargées ne sont pas incluses.'))+'</p>';

        var columnCount = visibleColumnIndexes(table).length || (cloneTable.querySelector("thead tr") ? cloneTable.querySelector("thead tr").children.length : 1);
        var fontSize = columnCount >= 12 ? "7.5pt" : columnCount >= 9 ? "8.5pt" : "9.5pt";

        var html = "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<title>" + escapeHtml(reportTitle || fallbackTitle) + "</title>" +
            "<style>" +
            "@page{size:A4 " + orientation + ";margin:10mm;}" +
            "html,body{margin:0;padding:0;color:#111;background:#fff;font-family:Arial,Helvetica,sans-serif;}" +
            "body{font-size:" + fontSize + ";}" +
            "h1{font-size:15pt;line-height:1.2;margin:0 0 3mm 0;font-weight:600;}" +
            ".pmk077-report-id{font-size:9pt;color:#555;margin:0 0 5mm 0;}" +
            ".pmk077-print-table{width:100%;border-collapse:collapse;table-layout:auto;}" +
            ".pmk077-print-table thead{display:table-header-group;}" +
            ".pmk077-print-table tr{break-inside:avoid;page-break-inside:avoid;}" +
            ".pmk077-print-table th,.pmk077-print-table td{border:1px solid #bbb;padding:3px 5px;vertical-align:top;text-align:left;overflow-wrap:anywhere;word-break:normal;}" +
            ".pmk077-print-table th{background:#f1f1f1;font-weight:700;}" +
            ".pmk077-print-table a{color:#111;text-decoration:none;}" +
            "</style></head><body>" + titleHtml + cloneTable.outerHTML + "</body></html>";

        try {
            printWindow.document.open();
            printWindow.document.write(html);
            printWindow.document.close();
            printWindow.focus();
            window.setTimeout(function () {
                try { printWindow.print(); } catch (_) {}
            }, 150);
        } catch (_) {
            try { printWindow.close(); } catch (__) {}
        }
    }

    function removeUi() {
        var group = document.getElementById(GROUP_ID);
        if (group) group.remove();
        var ownToolbar = document.getElementById(OWN_TOOLBAR_ID);
        if (ownToolbar) ownToolbar.remove();
    }

    function ensureToolbar(table) {
        var toolbarSelector = text(currentConfig.selectors && currentConfig.selectors.toolbar) || "#toolbar";
        var toolbar = null;
        try { toolbar = document.querySelector(toolbarSelector); } catch (_) {}
        if (toolbar) return toolbar;

        var own = document.getElementById(OWN_TOOLBAR_ID);
        if (own) return own;

        own = document.createElement("div");
        own.id = OWN_TOOLBAR_ID;
        own.className = "btn-toolbar mb-2";
        own.setAttribute("role", "toolbar");
        own.setAttribute("aria-label", label("documentFr", "documentEn") || "Report actions");

        var paginationSelector = text(currentConfig.selectors && currentConfig.selectors.paginationTop) || "#pagination_top";
        var pagination = null;
        try { pagination = document.querySelector(paginationSelector); } catch (_) {}

        if (pagination && pagination.parentNode) pagination.parentNode.insertBefore(own, pagination);
        else if (table && table.parentNode) table.parentNode.insertBefore(own, table);
        return own;
    }

    function mountConfigButton(group) {
        if (!group || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (!window.PMKConfig.canOpenAdmin || !window.PMKConfig.canOpenAdmin()) return;

        var previous = document.getElementById(CONFIG_HOST_ID);
        if (previous) previous.remove();

        var host = document.createElement("span");
        host.id = CONFIG_HOST_ID;
        host.className = "pmk077-config-host";
        group.appendChild(host);

        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: host,
                contextKey: "guided-report-print",
                context: { sectionId: "print", pagePath: PAGE_PATH }
            });
        } catch (_) {}
    }

    function render(table) {
        if (!pageIsActive() || !table) {
            removeUi();
            return;
        }

        var old = document.getElementById(GROUP_ID);
        if (old) old.remove();

        var toolbar = ensureToolbar(table);
        if (!toolbar) return;

        var group = document.createElement("div");
        group.id = GROUP_ID;
        group.className = "btn-group pmk077-print-group";
        group.setAttribute("role", "group");

        var button = document.createElement("button");
        button.type = "button";
        button.id = BUTTON_ID;
        button.className = "btn btn-default btn-sm";
        button.innerHTML = '<i class="fa fa-print" aria-hidden="true"></i> <span></span>';
        button.querySelector("span").textContent = label("buttonFr", "buttonEn") || "Imprimer le tableau";
        button.addEventListener("click", printTable);

        group.appendChild(button);
        toolbar.appendChild(group);
        mountConfigButton(group);
    }

    function applyConfig() {
        removeUi();
        if (!pageIsActive()) return;

        var selector = text(currentConfig.selectors && currentConfig.selectors.table) || "#report_results";
        waitFor(selector, 5000).then(function (table) {
            if (!pageIsActive()) return;
            render(table);
        }).catch(function () {
            removeUi();
        });
    }

    function loadWithPMK() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return false;

        window.PMKConfig.getConfig(MODULE_ID).then(function (config) {
            currentConfig = merge(DEFAULT_CONFIG, config || {});
            applyConfig();
        }).catch(function () {
            currentConfig = clone(DEFAULT_CONFIG);
            applyConfig();
        });

        if (!subscribed && typeof window.PMKConfig.subscribe === "function") {
            subscribed = true;
            window.PMKConfig.subscribe(MODULE_ID, function (config) {
                currentConfig = merge(DEFAULT_CONFIG, config || {});
                applyConfig();
            });
        }
        return true;
    }

    function boot() {
        if (window.location.pathname !== PAGE_PATH) return;
        if (loadWithPMK()) return;

        currentConfig = clone(DEFAULT_CONFIG);
        applyConfig();

        window.addEventListener("pmk:config-ready", function () {
            loadWithPMK();
        }, { once: true });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
        boot();
    }
})();

;window.PMKNonPlugin.loaded.push("077-save-guarantor-tp4.js");
} catch (error) { window.PMKNonPlugin.errors.push("077-save-guarantor-tp4.js: "+error.message); console.error("[PMK] 077-save-guarantor-tp4.js",error); };
try {
/*
 Nom du fichier: 078-hide-print-overdues.js
 Version: 3.2.0-universal
 Date de dernière modification: 2026-09-22
 Auteur: équipe PimpMyKoha / refonte PimpMyKoha
 Module PMK: patron-overdues-print

 Fonction historique conservée :
 - mémorise le lecteur et son/ses garant(s) avant impression ;
 - sur print_overdues.pl, remplace le destinataire par le/les garant(s) ;
 - conserve STRICTEMENT le rendu historique :
     GARANT(S)
     adresse...
     Enfant : NOM ENFANT
   avec exactement le même assemblage par <br> que le script historique ;
 - intègre "Imprimer les retards" dans le menu déroulant Koha "Imprimer" ;
 - réutilise l'action native si elle existe, sinon recrée l'action Koha équivalente.

 Version 3 — constructeur de modèle PMK :
 - le rendu historique reste le mode par défaut et reste strictement identique ;
 - un mode personnalisé permet de composer le destinataire imprimé sans code ;
 - blocs réordonnables : garants, adresse, enfant, texte libre, espace, séparateur ;
 - texte libre avec variables {GARANTS}, {GARANTS_LIGNES}, {ADRESSE}, {ENFANT},
   {ENFANT_LIBELLE} et {BORROWERNUMBER} ;
 - préfixes/suffixes FR/EN, casse, alignement, graisse, italique, souligné,
   taille, couleur et marges par bloc ;
 - réglages globaux de police, taille, couleur, alignement et interligne ;
 - le module s'auto-enregistre dans PMK avec PMKConfig.registerModule().
*/

(function () {
  'use strict';

  if (window.__PMK078_OVERDUES_PRINT_V3__) return;
  window.__PMK078_OVERDUES_PRINT_V3__ = true;

  var MODULE_ID = 'patron-overdues-print';
  var PAGE_PATHS = {
    circulation: '/cgi-bin/koha/circ/circulation.pl',
    moremember: '/cgi-bin/koha/members/moremember.pl',
    printOverdues: '/cgi-bin/koha/members/print_overdues.pl'
  };

  function defaultBlockStyle() {
    return {
      fontSizePx: 0,
      bold: false,
      italic: false,
      underline: false,
      useColor: false,
      color: '#212529',
      textAlign: 'inherit',
      marginTopPx: 0,
      marginBottomPx: 0
    };
  }

  function printBlock(id, type, label, extra) {
    return Object.assign({
      id: id,
      enabled: true,
      label: label,
      type: type,
      prefixFr: '',
      prefixEn: '',
      suffixFr: '',
      suffixEn: '',
      transform: 'none',
      joinMode: 'comma',
      textFr: '',
      textEn: '',
      spacerHeightPx: 8,
      separatorWidthPx: 1,
      separatorStyle: 'solid',
      separatorColor: '#ced4da',
      style: defaultBlockStyle()
    }, extra || {});
  }

  function defaultPrintBlocks() {
    return [
      printBlock('guarantors', 'guarantors', 'Garant(s)', {
        marginBottomPx: 0
      }),
      printBlock('address', 'address', 'Adresse'),
      printBlock('child', 'child', 'Enfant', {
        prefixFr: 'Enfant : ',
        prefixEn: 'Child: '
      })
    ];
  }

  var DEFAULT_CONFIG = {
    enabled: true,
    behavior: {
      integratePrintOverduesInPrintMenu: true,
      storageTtlSeconds: 300
    },
    privacy: {
      recipientPolicy: 'Le courrier est destiné au(x) garant(s) détecté(s) sur la fiche du lecteur.',
      dataPolicy: 'Le rendu peut imprimer les noms des garants, l’adresse postale, le nom de l’enfant et, seulement si le modèle le demande, le numéro interne du lecteur.'
    },
    rendering: {
      mode: 'historical',
      skipEmptyBlocks: true,
      global: {
        fontFamily: 'inherit',
        fontSizePx: 0,
        lineHeight: '',
        useColor: false,
        color: '#212529',
        textAlign: 'inherit'
      },
      blocks: defaultPrintBlocks()
    },
    selectors: {
      patronInformation: '#patron-information',
      childNameLegacy: '.patroninfo h5, #patron-information h5, .patron_title h3, .patron-title h3',
      morememberHeading: 'main h1, #main h1, h1',
      guarantorLabel: 'span.label',
      printAction: '#print_overdues',
      printCapture: '#print_overdues, [data-pmk078-overdues-menu="1"], a.printslip',
      addressBlock: '#addressBlock, .address p, .patronaddress p, .address, .patronaddress'
    }
  };

  var STORAGE_PREFIX = 'pmk078:patron:';
  var STORAGE_LATEST = 'pmk078:latest';
  var STORAGE_CAPTURED_AT = 'pmk078:lastCapturedAt';
  var LEGACY_CHILD = 'k078_child_name';
  var LEGACY_GUARANTOR = 'k078_guarantor';
  var LEGACY_INLINE_GUARANTOR = 'guarantor';

  var currentConfig = clone(DEFAULT_CONFIG);
  var subscribed = false;
  var configurationVersion = 0;
  var moduleRegistered = false;
  var printObserver = null;
  var activePrintRecord = null;
  var activePrintData = null;
  var clickCaptureAttached = false;
  var printMenuObserver = null;
  var printActionPlacement = null;

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function object(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  }

  function merge(base, patch) {
    var out = clone(base);
    var src = object(patch);
    Object.keys(src).forEach(function (key) {
      if (out[key] && typeof out[key] === 'object' && !Array.isArray(out[key]) && src[key] && typeof src[key] === 'object' && !Array.isArray(src[key])) {
        out[key] = merge(out[key], src[key]);
      } else {
        out[key] = src[key];
      }
    });
    return out;
  }

  function clampInt(value, min, max, fallback) {
    var n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(min, Math.min(max, Math.round(n)));
  }

  function cleanText(value) {
    return String(value == null ? '' : value).trim();
  }

  function detectLanguage() {
    try {
      if (window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function') {
        return window.PMKConfig.getLanguage() === 'en' ? 'en' : 'fr';
      }
    } catch (_) {}
    var lang = String(document.documentElement.lang || navigator.language || '').toLowerCase();
    return lang.indexOf('en') === 0 ? 'en' : 'fr';
  }

  function localized(fr, en) {
    return detectLanguage() === 'en' ? (en || fr || '') : (fr || en || '');
  }

  function uniqueBlockId(value, used, index) {
    var base = String(value || ('block-' + (index + 1)))
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-|-$/g, '') || ('block-' + (index + 1));
    var id = base;
    var n = 2;
    while (used[id]) {
      id = base + '-' + n;
      n += 1;
    }
    used[id] = true;
    return id;
  }

  function normalizeBlock(raw, index, used) {
    var block = merge(printBlock('', 'text', 'Bloc ' + (index + 1)), object(raw));
    block.id = uniqueBlockId(block.id, used, index);
    block.enabled = block.enabled !== false;
    block.type = ['guarantors', 'address', 'child', 'text', 'spacer', 'separator'].indexOf(block.type) >= 0 ? block.type : 'text';
    block.transform = ['none', 'upper', 'lower'].indexOf(block.transform) >= 0 ? block.transform : 'none';
    block.joinMode = ['comma', 'line', 'and', 'semicolon'].indexOf(block.joinMode) >= 0 ? block.joinMode : 'comma';
    block.spacerHeightPx = clampInt(block.spacerHeightPx, 0, 200, 8);
    block.separatorWidthPx = clampInt(block.separatorWidthPx, 1, 12, 1);
    block.separatorStyle = ['solid', 'dashed', 'dotted', 'double'].indexOf(block.separatorStyle) >= 0 ? block.separatorStyle : 'solid';
    block.style = merge(defaultBlockStyle(), object(block.style));
    block.style.fontSizePx = clampInt(block.style.fontSizePx, 0, 96, 0);
    block.style.marginTopPx = clampInt(block.style.marginTopPx, 0, 200, 0);
    block.style.marginBottomPx = clampInt(block.style.marginBottomPx, 0, 200, 0);
    block.style.textAlign = ['inherit', 'left', 'center', 'right', 'justify'].indexOf(block.style.textAlign) >= 0 ? block.style.textAlign : 'inherit';
    block.style.bold = block.style.bold === true;
    block.style.italic = block.style.italic === true;
    block.style.underline = block.style.underline === true;
    block.style.useColor = block.style.useColor === true;
    return block;
  }

  function normalizeConfig(config) {
    var cfg = merge(DEFAULT_CONFIG, config || {});
    cfg.enabled = cfg.enabled !== false;
    cfg.behavior = merge(DEFAULT_CONFIG.behavior, object(cfg.behavior));
    cfg.selectors = merge(DEFAULT_CONFIG.selectors, object(cfg.selectors));
    cfg.rendering = merge(DEFAULT_CONFIG.rendering, object(cfg.rendering));
    cfg.rendering.global = merge(DEFAULT_CONFIG.rendering.global, object(cfg.rendering.global));
    cfg.rendering.mode = cfg.rendering.mode === 'custom' ? 'custom' : 'historical';
    cfg.rendering.skipEmptyBlocks = cfg.rendering.skipEmptyBlocks !== false;
    cfg.rendering.global.fontFamily = ['inherit', 'Arial, sans-serif', 'Georgia, serif', 'Times New Roman, serif', 'Verdana, sans-serif', 'monospace'].indexOf(cfg.rendering.global.fontFamily) >= 0
      ? cfg.rendering.global.fontFamily : 'inherit';
    cfg.rendering.global.fontSizePx = clampInt(cfg.rendering.global.fontSizePx, 0, 96, 0);
    cfg.rendering.global.textAlign = ['inherit', 'left', 'center', 'right', 'justify'].indexOf(cfg.rendering.global.textAlign) >= 0
      ? cfg.rendering.global.textAlign : 'inherit';
    cfg.rendering.global.useColor = cfg.rendering.global.useColor === true;
    var used = Object.create(null);
    cfg.rendering.blocks = Array.isArray(cfg.rendering.blocks) && cfg.rendering.blocks.length
      ? cfg.rendering.blocks.map(function (block, index) { return normalizeBlock(block, index, used); })
      : defaultPrintBlocks().map(function (block, index) { return normalizeBlock(block, index, used); });
    cfg.behavior.integratePrintOverduesInPrintMenu = cfg.behavior.integratePrintOverduesInPrintMenu !== false;
    cfg.behavior.storageTtlSeconds = clampInt(cfg.behavior.storageTtlSeconds, 30, 3600, DEFAULT_CONFIG.behavior.storageTtlSeconds);
    return cfg;
  }

  function pathIs(expected) {
    var path = window.location.pathname || '';
    return path === expected || path.endsWith(expected.split('/').pop());
  }

  function isSupportedPage() {
    return pathIs(PAGE_PATHS.circulation) || pathIs(PAGE_PATHS.moremember) || pathIs(PAGE_PATHS.printOverdues);
  }

  function safeQuery(selector, root) {
    try {
      return (root || document).querySelector(selector);
    } catch (_) {
      return null;
    }
  }

  function safeQueryAll(selector, root) {
    try {
      return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    } catch (_) {
      return [];
    }
  }

  function waitFor(selector, timeout) {
    if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === 'function') {
      try { return window.KOHA_UTILS.waitFor(selector, timeout); } catch (_) {}
    }
    return new Promise(function (resolve, reject) {
      var el = safeQuery(selector);
      if (el) return resolve(el);
      var finished = false;
      var obs = new MutationObserver(function () {
        var found = safeQuery(selector);
        if (!found) return;
        finished = true;
        try { obs.disconnect(); } catch (_) {}
        resolve(found);
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      window.setTimeout(function () {
        if (finished) return;
        try { obs.disconnect(); } catch (_) {}
        reject(new Error('timeout'));
      }, timeout || 3000);
    });
  }

  /* IMPORTANT : fonction historique conservée telle quelle sur le principe.
     Elle conditionne le texte exact envoyé vers l'impression. */
  function normalizePersonName(value) {
    return String(value || '')
      .replace(/\([^)]*\)/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function uniqueNames(values) {
    var out = [];
    values.forEach(function (value) {
      var name = normalizePersonName(value);
      if (name && out.indexOf(name) === -1) out.push(name);
    });
    return out;
  }

  function getBorrowerNumber() {
    try {
      var params = new URLSearchParams(window.location.search || '');
      var direct = params.get('borrowernumber');
      if (direct && /^\d+$/.test(direct)) return direct;
    } catch (_) {}

    var input = safeQuery('input[name="borrowernumber"], input#borrowernumber');
    if (input && /^\d+$/.test(String(input.value || '').trim())) return String(input.value).trim();

    var links = safeQueryAll('a[href*="borrowernumber="]');
    for (var i = 0; i < links.length; i += 1) {
      try {
        var url = new URL(links[i].href, window.location.href);
        var value = url.searchParams.get('borrowernumber');
        if (value && /^\d+$/.test(value)) return value;
      } catch (_) {}
    }
    return '';
  }

  function getChildName() {
    var legacy = safeQuery(currentConfig.selectors.childNameLegacy);
    if (legacy) {
      var oldText = normalizePersonName(legacy.textContent || '');
      if (oldText) return oldText;
    }

    /* Sur moremember.pl actuel, le h1 est directement patron-title.inc.
       Ce fallback n'est volontairement PAS utilisé sur circulation.pl afin
       d'éviter de capturer le h1 générique "Check out". */
    if (pathIs(PAGE_PATHS.moremember)) {
      var heading = safeQuery(currentConfig.selectors.morememberHeading);
      if (heading) {
        var headingText = normalizePersonName(heading.textContent || '');
        if (headingText) return headingText;
      }
    }
    return '';
  }

  function labelIsGuarantor(text) {
    var value = String(text || '').replace(/\s+/g, ' ').trim().replace(/:$/, '').toLowerCase();
    return value.indexOf('garant') === 0 || value.indexOf('guarantor') === 0;
  }

  function namesFromGuarantorListItem(li) {
    if (!li) return [];

    /* PARITÉ HISTORIQUE IMPORTANTE : l'ancien 078 prenait le premier <a>
       trouvé dans le <li> du libellé Garant. S'il y en avait un, il ne
       parcourait pas ensuite la liste imbriquée. On conserve volontairement
       cette règle pour ne jamais modifier le destinataire imprimé. */
    var firstLink = safeQuery('a', li);
    if (firstLink) {
      var firstName = normalizePersonName(firstLink.textContent || '');
      return firstName ? [firstName] : [];
    }

    var names = [];
    var ul = safeQuery('ul', li);
    if (ul) {
      safeQueryAll('li', ul).forEach(function (item) {
        var value = normalizePersonName(item.textContent || '');
        if (value) names.push(value);
      });
    }
    return uniqueNames(names);
  }

  function getGuarantorNames() {
    var patronInfo = safeQuery(currentConfig.selectors.patronInformation);
    var roots = [];
    if (patronInfo) roots.push(patronInfo);

    /* Fallback historique : nécessaire pour anciennes versions / installations
       dont le bloc n'a pas #patron-information. */
    var historicalContainer = safeQuery('.col-sm-6');
    if (historicalContainer && roots.indexOf(historicalContainer) === -1) roots.push(historicalContainer);

    for (var r = 0; r < roots.length; r += 1) {
      var labels = safeQueryAll(currentConfig.selectors.guarantorLabel, roots[r]);
      for (var i = 0; i < labels.length; i += 1) {
        if (!labelIsGuarantor(labels[i].textContent || '')) continue;
        var li = labels[i].closest ? labels[i].closest('li') : null;
        var names = namesFromGuarantorListItem(li);
        if (names.length) return names;
      }
    }
    return [];
  }

  function recordKey(borrowerNumber) {
    return STORAGE_PREFIX + String(borrowerNumber || 'unknown');
  }

  function storageSet(key, value) {
    try { localStorage.setItem(key, value); } catch (_) {}
  }

  function storageGet(key) {
    try { return localStorage.getItem(key); } catch (_) { return null; }
  }

  function storageRemove(key) {
    try { localStorage.removeItem(key); } catch (_) {}
  }

  function purgeExpiredStoredData() {
    try {
      var ttlMs = currentConfig.behavior.storageTtlSeconds * 1000;
      var now = Date.now();
      var keys = [];
      for (var i = 0; i < localStorage.length; i += 1) {
        var key = localStorage.key(i);
        if (key && key.indexOf(STORAGE_PREFIX) === 0) keys.push(key);
      }
      keys.forEach(function (key) {
        var record = parseRecord(storageGet(key));
        if (!record) storageRemove(key);
      });

      var latest = parseRecord(storageGet(STORAGE_LATEST));
      if (!latest) {
        storageRemove(STORAGE_LATEST);
        var capturedAt = Number(storageGet(STORAGE_CAPTURED_AT) || 0);
        if (!capturedAt || now - capturedAt > ttlMs) {
          storageRemove(STORAGE_CAPTURED_AT);
          storageRemove(LEGACY_CHILD);
          storageRemove(LEGACY_GUARANTOR);
          storageRemove(LEGACY_INLINE_GUARANTOR);
        }
      }
    } catch (_) {}
  }

  function capturePrintContext() {
    try {
      var borrowerNumber = getBorrowerNumber();
      var childName = getChildName();
      var guarantors = getGuarantorNames();
      var joined = guarantors.join(', '); /* EXACTEMENT le séparateur historique. */
      var now = Date.now();

      var record = {
        version: 2,
        borrowerNumber: borrowerNumber,
        childName: childName,
        guarantors: guarantors,
        guarantorJoined: joined,
        capturedAt: now
      };

      storageSet(recordKey(borrowerNumber), JSON.stringify(record));
      storageSet(STORAGE_LATEST, JSON.stringify(record));
      storageSet(STORAGE_CAPTURED_AT, String(now));

      /* Compatibilité avec le script historique et avec un éventuel JS contenu
         dans la notice OVERDUES_SLIP. Les valeurs sont désormais nettoyées
         rapidement et ne servent plus de source principale à la v2. */
      if (childName) storageSet(LEGACY_CHILD, childName);
      else storageRemove(LEGACY_CHILD);

      if (joined) {
        storageSet(LEGACY_GUARANTOR, joined);
        storageSet(LEGACY_INLINE_GUARANTOR, joined);
      } else {
        storageRemove(LEGACY_GUARANTOR);
        storageRemove(LEGACY_INLINE_GUARANTOR);
      }

      return record;
    } catch (_) {
      return null;
    }
  }

  function parseRecord(raw) {
    if (!raw) return null;
    try {
      var record = JSON.parse(raw);
      if (!record || typeof record !== 'object') return null;
      var capturedAt = Number(record.capturedAt || 0);
      if (!capturedAt) return null;
      var ttlMs = currentConfig.behavior.storageTtlSeconds * 1000;
      if (Date.now() - capturedAt > ttlMs) return null;
      record.childName = normalizePersonName(record.childName || '');
      record.guarantors = Array.isArray(record.guarantors) ? uniqueNames(record.guarantors) : [];
      record.guarantorJoined = normalizePersonName(record.guarantorJoined || record.guarantors.join(', '));
      return record;
    } catch (_) {
      return null;
    }
  }

  function loadPrintRecord() {
    var borrowerNumber = getBorrowerNumber();
    var record = parseRecord(storageGet(recordKey(borrowerNumber)));
    if (record) return record;

    record = parseRecord(storageGet(STORAGE_LATEST));
    if (record && (!borrowerNumber || !record.borrowerNumber || String(record.borrowerNumber) === String(borrowerNumber))) return record;

    /* Compatibilité de transition : les anciennes clés ne sont acceptées que
       si elles ont été écrites récemment par cette v2 (timestamp séparé). */
    var capturedAt = Number(storageGet(STORAGE_CAPTURED_AT) || 0);
    if (capturedAt && Date.now() - capturedAt <= currentConfig.behavior.storageTtlSeconds * 1000) {
      var child = normalizePersonName(storageGet(LEGACY_CHILD) || '');
      var guarantor = normalizePersonName(storageGet(LEGACY_GUARANTOR) || storageGet(LEGACY_INLINE_GUARANTOR) || '');
      if (guarantor) {
        return {
          version: 1,
          borrowerNumber: borrowerNumber,
          childName: child,
          guarantors: guarantor ? [guarantor] : [],
          guarantorJoined: guarantor,
          capturedAt: capturedAt
        };
      }
    }
    return null;
  }

  function clearStoredRecord(record) {
    if (record && record.borrowerNumber) storageRemove(recordKey(record.borrowerNumber));
    storageRemove(STORAGE_LATEST);
    storageRemove(STORAGE_CAPTURED_AT);
    storageRemove(LEGACY_CHILD);
    storageRemove(LEGACY_GUARANTOR);
    storageRemove(LEGACY_INLINE_GUARANTOR);
  }

  function getAddressBlock() {
    /* Priorité historique stricte à #addressBlock, même si un autre sélecteur
       de repli apparaît plus tôt dans le DOM. */
    var historical = document.getElementById('addressBlock');
    if (historical) return historical;
    return safeQuery(currentConfig.selectors.addressBlock);
  }

  /* =====================================================================
     RENDU HISTORIQUE — NE PAS MODIFIER SANS RECETTE VISUELLE EXPLICITE.
     Les trois fonctions ci-dessous reproduisent volontairement le 078
     historique afin que le document imprimé reste strictement identique.
     ===================================================================== */

  function removeGarantLines(scope) {
    try {
      var root = scope || document;
      var addressBlock = (root.querySelector && root.querySelector('#addressBlock')) || getAddressBlock();
      if (addressBlock) {
        var cleaned = addressBlock.innerHTML
          .replace(/<br\s*\/?\s*>\s*(?:<strong>\s*)?Garant\s*:\s*[^<]*/gi, '')
          .replace(/<br\s*\/?\s*>\s*(?:<strong>\s*)?Garants\s*:\s*[^<]*/gi, '')
          .replace(/<br\s*\/?\s*>\s*(?:<strong>\s*)?Ou\s*:\s*[^<]*/gi, '');
        if (cleaned !== addressBlock.innerHTML) addressBlock.innerHTML = cleaned;

        addressBlock.querySelectorAll('p, li, div, span, strong').forEach(function (node) {
          var txt = (node.textContent || '').replace(/\s+/g, ' ').trim();
          if (/^Garant\s*:/i.test(txt) || /^Garants\s*:/i.test(txt) || /^Ou\s*:/i.test(txt)) {
            var wrapper = node.closest('.js-guarantor-line, p, li, div, span') || node;
            if (wrapper && wrapper.parentNode) wrapper.remove();
          }
        });
      }
    } catch (_) {}
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function extractPrintData(record, addressBlock) {
    if (activePrintData) return activePrintData;
    if (!record || !addressBlock) return null;

    var guarantor = normalizePersonName(record.guarantorJoined || '');
    var raw = (addressBlock.innerText || addressBlock.textContent || '').replace(/\u00a0/g, ' ');
    var lines = raw
      .split(/\r?\n/)
      .map(function (line) { return line.replace(/\s+/g, ' ').trim(); })
      .filter(Boolean)
      .filter(function (line) {
        return !/^Garant\s*:/i.test(line)
          && !/^Garants\s*:/i.test(line)
          && !/^Guarantor(?:s)?\s*:/i.test(line)
          && !/^Ou\s*:/i.test(line)
          && !/^Enfant\s*:/i.test(line)
          && !/^Child\s*:/i.test(line);
      });

    var storedChild = normalizePersonName(record.childName || '');
    var normalizedLines = lines.map(normalizePersonName);
    var childName = storedChild;
    var addressLines = lines.slice();

    if (normalizedLines.length > 0 && guarantor && normalizedLines[0] === guarantor) {
      addressLines = lines.slice(1);
    } else if (normalizedLines.length > 0 && (!guarantor || normalizedLines[0] !== guarantor)) {
      addressLines = lines.slice(1);
      if (!childName) childName = normalizedLines[0];
    }

    addressLines = addressLines.filter(function (line) {
      var normalized = normalizePersonName(line);
      return !!normalized && normalized !== guarantor && normalized !== childName;
    });

    activePrintData = {
      borrowerNumber: String(record.borrowerNumber || ''),
      guarantors: Array.isArray(record.guarantors) && record.guarantors.length
        ? uniqueNames(record.guarantors)
        : (guarantor ? [guarantor] : []),
      guarantorJoined: guarantor,
      childName: childName,
      addressLines: addressLines
    };
    return activePrintData;
  }

  function applyHistoricalLayout(record, addressBlock) {
    var data = extractPrintData(record, addressBlock);
    if (!data || !data.guarantorJoined) return false;

    /* STRICTEMENT IDENTIQUE AU 078 HISTORIQUE. */
    var formatted = [data.guarantorJoined]
      .concat(data.addressLines)
      .concat(data.childName ? ['Enfant : ' + data.childName] : []);

    if (!formatted.length) return false;
    var nextHtml = formatted.map(escapeHtml).join('<br>');
    if (addressBlock.dataset.k078AddressHtml === nextHtml && addressBlock.dataset.k078RenderMode === 'historical') return true;

    addressBlock.innerHTML = nextHtml;
    addressBlock.dataset.k078AddressHtml = nextHtml;
    addressBlock.dataset.k078RenderMode = 'historical';
    return true;
  }

  function transformValue(value, mode) {
    var text = String(value == null ? '' : value);
    if (mode === 'upper') return text.toLocaleUpperCase();
    if (mode === 'lower') return text.toLocaleLowerCase();
    return text;
  }

  function joinGuarantors(names, mode) {
    var list = Array.isArray(names) ? names.filter(Boolean) : [];
    if (mode === 'line') return list.join('\n');
    if (mode === 'and') {
      if (list.length <= 1) return list.join('');
      return list.slice(0, -1).join(', ') + localized(' et ', ' and ') + list[list.length - 1];
    }
    if (mode === 'semicolon') return list.join('; ');
    return list.join(', ');
  }

  function templateVariables(data) {
    return {
      GARANTS: joinGuarantors(data.guarantors, 'comma'),
      GARANTS_LIGNES: joinGuarantors(data.guarantors, 'line'),
      GUARANTORS: joinGuarantors(data.guarantors, 'comma'),
      GUARANTORS_LINES: joinGuarantors(data.guarantors, 'line'),
      ADRESSE: data.addressLines.join('\n'),
      ADDRESS: data.addressLines.join('\n'),
      ENFANT: data.childName || '',
      CHILD: data.childName || '',
      ENFANT_LIBELLE: data.childName ? ('Enfant : ' + data.childName) : '',
      CHILD_LABEL: data.childName ? ('Child: ' + data.childName) : '',
      BORROWERNUMBER: data.borrowerNumber || ''
    };
  }

  function expandTemplate(value, data) {
    var vars = templateVariables(data);
    return String(value == null ? '' : value).replace(/\{([A-Z_]+)\}/g, function (_all, key) {
      return Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : _all;
    });
  }

  function blockText(block, data) {
    if (block.type === 'guarantors') return joinGuarantors(data.guarantors, block.joinMode);
    if (block.type === 'address') return data.addressLines.join('\n');
    if (block.type === 'child') return data.childName || '';
    if (block.type === 'text') return expandTemplate(localized(block.textFr, block.textEn), data);
    return '';
  }

  function styleText(block) {
    var style = block.style || {};
    var css = [];
    if (style.fontSizePx > 0) css.push('font-size:' + style.fontSizePx + 'px');
    if (style.bold) css.push('font-weight:700');
    if (style.italic) css.push('font-style:italic');
    if (style.underline) css.push('text-decoration:underline');
    if (style.useColor && cleanText(style.color)) css.push('color:' + cleanText(style.color));
    if (style.textAlign && style.textAlign !== 'inherit') css.push('text-align:' + style.textAlign);
    if (style.marginTopPx > 0) css.push('margin-top:' + style.marginTopPx + 'px');
    if (style.marginBottomPx > 0) css.push('margin-bottom:' + style.marginBottomPx + 'px');
    return css.join(';');
  }

  function htmlWithBreaks(value) {
    return escapeHtml(value).replace(/\r?\n/g, '<br>');
  }

  function privacyDisclosure(config) {
    var cfg = config || currentConfig;
    var fields = [];
    var blocks = cfg.rendering.mode === 'custom' ? (cfg.rendering.blocks || []).filter(function (block) { return block && block.enabled !== false; }) : defaultPrintBlocks();
    var serialized = JSON.stringify(blocks);
    if (blocks.some(function (block) { return block.type === 'guarantors'; }) || /GARANTS|GUARANTORS/.test(serialized)) fields.push(localized('noms des garants', 'guarantor names'));
    if (blocks.some(function (block) { return block.type === 'address'; }) || /ADRESSE|ADDRESS/.test(serialized)) fields.push(localized('adresse postale', 'postal address'));
    if (blocks.some(function (block) { return block.type === 'child'; }) || /ENFANT|CHILD/.test(serialized)) fields.push(localized('nom de l’enfant', 'child name'));
    if (/BORROWERNUMBER/.test(serialized)) fields.push(localized('numéro interne du lecteur', 'internal patron number'));
    return {
      recipient: blocks.some(function (block) { return block.type === 'guarantors' && block.enabled !== false; }) ? localized('garant(s) détecté(s)', 'detected guarantor(s)') : localized('destinataire défini par le modèle', 'recipient defined by the model'),
      fields: fields
    };
  }

  function renderCustomBlock(block, data) {
    if (!block || block.enabled === false) return '';

    if (block.type === 'spacer') {
      return '<div class="pmk078-model-spacer" aria-hidden="true" style="height:' + clampInt(block.spacerHeightPx, 0, 200, 8) + 'px"></div>';
    }

    if (block.type === 'separator') {
      return '<div class="pmk078-model-separator" aria-hidden="true" style="border-top:'
        + clampInt(block.separatorWidthPx, 1, 12, 1) + 'px '
        + escapeHtml(block.separatorStyle || 'solid') + ' '
        + escapeHtml(block.separatorColor || '#ced4da')
        + ';margin:6px 0"></div>';
    }

    var value = blockText(block, data);
    var prefix = expandTemplate(localized(block.prefixFr, block.prefixEn), data);
    var suffix = expandTemplate(localized(block.suffixFr, block.suffixEn), data);
    value = transformValue(value, block.transform);

    if (currentConfig.rendering.skipEmptyBlocks !== false && !cleanText(value)) return '';

    var combined = prefix + value + suffix;
    var css = styleText(block);
    return '<div class="pmk078-model-block pmk078-model-' + escapeHtml(block.type) + '"'
      + (css ? ' style="' + escapeHtml(css) + '"' : '')
      + '>' + htmlWithBreaks(combined) + '</div>';
  }

  function applyCustomRootStyle(addressBlock) {
    var style = currentConfig.rendering.global || {};
    if (style.fontFamily && style.fontFamily !== 'inherit') addressBlock.style.fontFamily = style.fontFamily;
    if (style.fontSizePx > 0) addressBlock.style.fontSize = style.fontSizePx + 'px';
    if (cleanText(style.lineHeight)) addressBlock.style.lineHeight = cleanText(style.lineHeight);
    if (style.useColor && cleanText(style.color)) addressBlock.style.color = cleanText(style.color);
    if (style.textAlign && style.textAlign !== 'inherit') addressBlock.style.textAlign = style.textAlign;
  }

  function applyCustomLayout(record, addressBlock) {
    var data = extractPrintData(record, addressBlock);
    if (!data) return false;

    var blocks = currentConfig.rendering.blocks || [];
    var html = blocks.map(function (block) {
      return renderCustomBlock(block, data);
    }).filter(Boolean).join('');

    if (!html) return false;
    applyCustomRootStyle(addressBlock);

    if (addressBlock.dataset.k078AddressHtml === html && addressBlock.dataset.k078RenderMode === 'custom') return true;
    addressBlock.innerHTML = html;
    addressBlock.dataset.k078AddressHtml = html;
    addressBlock.dataset.k078RenderMode = 'custom';
    return true;
  }

  function applyGuarantorAddressLayout() {
    try {
      if (!pathIs(PAGE_PATHS.printOverdues)) return false;

      var record = activePrintRecord || loadPrintRecord();
      if (!record) return false;
      activePrintRecord = record;

      var guarantor = normalizePersonName(record.guarantorJoined || '');
      if (!guarantor && currentConfig.rendering.mode === 'historical') return false;

      /* Empêcher le JS de la notice de réinjecter "Garant : ...". */
      storageRemove(LEGACY_INLINE_GUARANTOR);

      var addressBlock = getAddressBlock();
      if (!addressBlock) return false;

      if (currentConfig.rendering.mode === 'custom') {
        return applyCustomLayout(record, addressBlock);
      }
      return applyHistoricalLayout(record, addressBlock);
    } catch (_) {
      return false;
    }
  }

  function stopPrintObserver() {
    if (printObserver) {
      try { printObserver.disconnect(); } catch (_) {}
      printObserver = null;
    }
  }

  function startPrintObserver(addressBlock) {
    stopPrintObserver();
    if (!addressBlock) return;

    var scheduled = false;
    printObserver = new MutationObserver(function () {
      if (scheduled) return;
      scheduled = true;
      window.setTimeout(function () {
        scheduled = false;
        removeGarantLines(document);
        applyGuarantorAddressLayout();
      }, 30);
    });

    var container = addressBlock.parentElement || addressBlock;
    printObserver.observe(container, { childList: true, subtree: true, characterData: true });
  }

  function runPrintPage() {
    if (!pathIs(PAGE_PATHS.printOverdues) || !currentConfig.enabled) return;

    activePrintRecord = activePrintRecord || loadPrintRecord();
    removeGarantLines(document);

    var addressBlock = getAddressBlock();
    if (addressBlock) {
      var applied = applyGuarantorAddressLayout();
      startPrintObserver(addressBlock);
      if (applied) {
        /* Le rendu est désormais mémorisé en mémoire dans activePrintRecord ;
           on peut supprimer les données nominatives persistantes. */
        clearStoredRecord(activePrintRecord);
      }
      return;
    }

    waitFor(currentConfig.selectors.addressBlock, 3500).then(function (el) {
      if (!currentConfig.enabled) return;
      removeGarantLines(document);
      var applied = applyGuarantorAddressLayout();
      startPrintObserver(el);
      if (applied) clearStoredRecord(activePrintRecord);
    }).catch(function () {});
  }

  function attachPrintCapture() {
    if (clickCaptureAttached) return;
    clickCaptureAttached = true;

    document.addEventListener('click', function (event) {
      if (!currentConfig.enabled) return;
      var target = event.target && event.target.closest ? event.target.closest(currentConfig.selectors.printCapture) : null;
      if (!target) return;
      capturePrintContext();
    }, true);
  }

  function findKohaPrintMenu() {
    var groups = safeQueryAll('.btn-group');
    for (var i = 0; i < groups.length; i += 1) {
      var group = groups[i];
      var toggle = safeQuery(':scope > button.dropdown-toggle, :scope > a.dropdown-toggle', group);
      var menu = safeQuery(':scope > ul.dropdown-menu, :scope > .dropdown-menu', group);
      if (!toggle || !menu) continue;

      var hasPrintIcon = Boolean(safeQuery('.fa-print, .fa-solid.fa-print, [class*="fa-print"]', toggle));
      var label = String(toggle.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      var looksLikePrint = hasPrintIcon || label.indexOf('imprimer') >= 0 || label.indexOf('print') >= 0;
      if (!looksLikePrint) continue;

      return { group: group, toggle: toggle, menu: menu };
    }
    return null;
  }

  function restorePrintActionPlacement() {
    if (printMenuObserver) {
      try { printMenuObserver.disconnect(); } catch (_) {}
      printMenuObserver = null;
    }

    var placement = printActionPlacement;
    if (!placement || !placement.action) return;

    var action = placement.action;
    try {
      if (placement.originalClassName !== null) action.className = placement.originalClassName;
      else action.removeAttribute('class');
      if (placement.originalStyle !== null) action.setAttribute('style', placement.originalStyle);
      else action.removeAttribute('style');
      delete action.dataset.pmk078OverduesMenu;

      if (placement.originalParent && placement.originalParent.isConnected) {
        if (placement.originalNextSibling && placement.originalNextSibling.parentNode === placement.originalParent) {
          placement.originalParent.insertBefore(action, placement.originalNextSibling);
        } else {
          placement.originalParent.appendChild(action);
        }
      }

      if (placement.createdLi && placement.createdLi.parentNode) placement.createdLi.remove();
      if (placement.originalContainer && placement.originalContainerDisplay !== null) {
        placement.originalContainer.style.display = placement.originalContainerDisplay;
      }
    } catch (_) {}

    printActionPlacement = null;
  }

  function buildFallbackPrintOverduesAction() {
    var borrowerNumber = getBorrowerNumber();
    if (!borrowerNumber) return null;

    var action = document.createElement('a');
    action.id = 'print_overdues';
    action.className = 'dropdown-item';
    action.href = PAGE_PATHS.printOverdues + '?borrowernumber=' + encodeURIComponent(borrowerNumber);
    action.target = 'printwindow';
    action.dataset.pmk078Generated = '1';
    action.dataset.pmk078OverduesMenu = '1';
    action.textContent = localized('Imprimer les retards', 'Print overdues');
    return action;
  }

  function insertPrintActionInKohaMenu(action) {
    if (!action) return false;
    var isGeneratedAction = action.dataset && action.dataset.pmk078Generated === '1';
    if (!action.isConnected && !isGeneratedAction) return false;
    var printMenu = findKohaPrintMenu();
    if (!printMenu || !printMenu.menu) return false;

    if (action.closest && action.closest('.dropdown-menu') === printMenu.menu) {
      action.classList.remove('btn', 'btn-default', 'btn-primary', 'btn-secondary');
      action.classList.add('dropdown-item');
      action.style.removeProperty('display');
      return true;
    }

    if (printActionPlacement && printActionPlacement.action === action && printActionPlacement.createdLi && printActionPlacement.createdLi.isConnected) {
      return true;
    }

    restorePrintActionPlacement();

    var originalParent = action.parentNode;
    var originalNextSibling = action.nextSibling;
    var originalClassName = action.getAttribute('class');
    var originalStyle = action.getAttribute('style');
    var originalContainer = action.closest ? action.closest('.btn-group') : null;
    var originalContainerDisplay = originalContainer ? originalContainer.style.display : null;

    var li = document.createElement('li');
    li.dataset.pmk078PrintOverduesItem = '1';

    var checkin = safeQuery('a.printslip[data-code="checkinslip"], a[data-code="checkinslip"]', printMenu.menu);
    var checkinLi = checkin && checkin.closest ? checkin.closest('li') : null;
    if (checkinLi && checkinLi.parentNode === printMenu.menu) printMenu.menu.insertBefore(li, checkinLi);
    else printMenu.menu.appendChild(li);

    li.appendChild(action);
    action.classList.remove('btn', 'btn-default', 'btn-primary', 'btn-secondary', 'dropdown-toggle');
    action.classList.add('dropdown-item');
    action.style.removeProperty('display');
    action.dataset.pmk078OverduesMenu = '1';

    if (originalContainer && originalContainer !== printMenu.group && originalContainer.children.length === 0) {
      originalContainer.style.display = 'none';
    }

    printActionPlacement = {
      action: action,
      originalParent: originalParent,
      originalNextSibling: originalNextSibling,
      originalClassName: originalClassName,
      originalStyle: originalStyle,
      originalContainer: originalContainer,
      originalContainerDisplay: originalContainerDisplay,
      createdLi: li
    };

    return true;
  }

  function ensurePrintActionInKohaMenu() {
    if (pathIs(PAGE_PATHS.printOverdues)) return;

    if (!currentConfig.enabled || !currentConfig.behavior.integratePrintOverduesInPrintMenu) {
      restorePrintActionPlacement();
      return;
    }

    var place = function () {
      var action = safeQuery(currentConfig.selectors.printAction);

      /* Koha n'affiche pas systématiquement #print_overdues dans la barre
         d'outils (notamment selon version / contexte). Dans ce cas, on recrée
         strictement l'action Koha : même endpoint print_overdues.pl et même
         borrowernumber, puis on l'insère dans le menu Imprimer. */
      if (!action) action = buildFallbackPrintOverduesAction();
      if (!action) return false;

      return insertPrintActionInKohaMenu(action);
    };

    if (place()) return;

    Promise.all([
      waitFor(currentConfig.selectors.printAction, 3500).catch(function () { return null; }),
      waitFor('.btn-group .dropdown-menu', 3500).catch(function () { return null; })
    ]).then(function () {
      if (!currentConfig.enabled || !currentConfig.behavior.integratePrintOverduesInPrintMenu) return;
      place();
    });

    if (!printMenuObserver && document.body && typeof MutationObserver === 'function') {
      printMenuObserver = new MutationObserver(function () {
        if (printActionPlacement && printActionPlacement.createdLi && printActionPlacement.createdLi.isConnected) return;
        if (place()) {
          try { printMenuObserver.disconnect(); } catch (_) {}
          printMenuObserver = null;
        }
      });
      printMenuObserver.observe(document.body, { childList: true, subtree: true });
      window.setTimeout(function () {
        if (printMenuObserver) {
          try { printMenuObserver.disconnect(); } catch (_) {}
          printMenuObserver = null;
        }
      }, 5000);
    }
  }

  function mountContextButton() {
    if (pathIs(PAGE_PATHS.printOverdues)) return;
    if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
    if (!window.PMKConfig.canOpenAdmin || !window.PMKConfig.canOpenAdmin()) return;
    if (document.getElementById('pmk078-config-host')) return;

    var toolbar = document.getElementById('toolbar') || safeQuery('.btn-toolbar');
    if (!toolbar) return;

    var host = document.createElement('span');
    host.id = 'pmk078-config-host';
    host.style.display = 'inline-flex';
    host.style.alignItems = 'center';
    host.style.marginLeft = '.25rem';
    toolbar.appendChild(host);

    try {
      window.PMKConfig.mountContextButton({
        moduleId: MODULE_ID,
        anchor: host,
        contextKey: 'overdues-print',
        context: { sectionId: 'activation', pagePath: window.location.pathname }
      });
    } catch (_) {}
  }

  function applyConfig() {
    if (!isSupportedPage()) return;

    attachPrintCapture();

    if (pathIs(PAGE_PATHS.printOverdues)) {
      if (currentConfig.enabled) runPrintPage();
      else stopPrintObserver();
      return;
    }

    ensurePrintActionInKohaMenu();
    mountContextButton();
  }

  function blockFromPath(rootObject, fieldPath) {
    if (!rootObject || !Array.isArray(rootObject.rendering && rootObject.rendering.blocks) || !Array.isArray(fieldPath)) return null;
    var index = fieldPath.indexOf('blocks');
    if (index < 0 || !Number.isInteger(Number(fieldPath[index + 1]))) return null;
    return rootObject.rendering.blocks[Number(fieldPath[index + 1])] || null;
  }

  function newPrintBlock() {
    return printBlock('block-' + Date.now().toString(36), 'text', localized('Nouveau bloc', 'New block'), {
      textFr: 'Nouveau texte',
      textEn: 'New text',
      style: defaultBlockStyle()
    });
  }


  function moduleDefinition() {
    function blockWhen(type) {
      return function (rootObject, fieldPath) {
        var block = blockFromPath(rootObject, fieldPath);
        return Boolean(block && block.type === type);
      };
    }

    function dataBlockWhen(rootObject, fieldPath) {
      var block = blockFromPath(rootObject, fieldPath);
      return Boolean(block && ['guarantors', 'address', 'child', 'text'].indexOf(block.type) >= 0);
    }

    function customMode(rootObject) {
      return rootObject && rootObject.rendering && rootObject.rendering.mode === 'custom';
    }

    var commonBlockFields = [
      { key: 'enabled', type: 'boolean', label: { fr: 'Bloc actif', en: 'Block enabled' } },
      { key: 'label', type: 'text', label: { fr: 'Nom du bloc dans PMK', en: 'Block name in PMK' } },
      {
        key: 'type',
        type: 'select',
        refreshOnChange: true,
        label: { fr: 'Contenu du bloc', en: 'Block content' },
        options: [
          { value: 'guarantors', label: { fr: 'Garant(s)', en: 'Guarantor(s)' } },
          { value: 'address', label: { fr: 'Adresse', en: 'Address' } },
          { value: 'child', label: { fr: 'Nom de l’enfant', en: 'Child name' } },
          { value: 'text', label: { fr: 'Texte libre / modèle avec variables', en: 'Free text / variable template' } },
          { value: 'spacer', label: { fr: 'Espace vertical', en: 'Vertical spacer' } },
          { value: 'separator', label: { fr: 'Ligne de séparation', en: 'Separator line' } }
        ]
      },
      {
        key: 'joinMode',
        type: 'select',
        when: blockWhen('guarantors'),
        label: { fr: 'Séparation entre plusieurs garants', en: 'Separator between multiple guarantors' },
        options: [
          { value: 'comma', label: { fr: 'Virgule', en: 'Comma' } },
          { value: 'line', label: { fr: 'Un garant par ligne', en: 'One guarantor per line' } },
          { value: 'and', label: { fr: '« et » / « and »', en: '“and”' } },
          { value: 'semicolon', label: { fr: 'Point-virgule', en: 'Semicolon' } }
        ]
      },
      {
        key: 'textFr',
        type: 'textarea',
        when: blockWhen('text'),
        label: { fr: 'Texte / modèle — français', en: 'Text / template — French' },
        help: {
          fr: 'Variables disponibles : {GARANTS}, {GARANTS_LIGNES}, {ADRESSE}, {ENFANT}, {ENFANT_LIBELLE}, {BORROWERNUMBER}. Les retours à la ligne sont conservés.',
          en: 'Available variables: {GUARANTORS}, {GUARANTORS_LINES}, {ADDRESS}, {CHILD}, {CHILD_LABEL}, {BORROWERNUMBER}. Line breaks are preserved.'
        }
      },
      {
        key: 'textEn',
        type: 'textarea',
        when: blockWhen('text'),
        label: { fr: 'Texte / modèle — anglais', en: 'Text / template — English' }
      },
      { key: 'prefixFr', type: 'text', when: dataBlockWhen, label: { fr: 'Préfixe — français', en: 'Prefix — French' } },
      { key: 'prefixEn', type: 'text', when: dataBlockWhen, label: { fr: 'Préfixe — anglais', en: 'Prefix — English' } },
      { key: 'suffixFr', type: 'text', when: dataBlockWhen, label: { fr: 'Suffixe — français', en: 'Suffix — French' } },
      { key: 'suffixEn', type: 'text', when: dataBlockWhen, label: { fr: 'Suffixe — anglais', en: 'Suffix — English' } },
      {
        key: 'transform',
        type: 'select',
        when: dataBlockWhen,
        label: { fr: 'Casse du texte', en: 'Text case' },
        options: [
          { value: 'none', label: { fr: 'Conserver', en: 'Keep as is' } },
          { value: 'upper', label: { fr: 'MAJUSCULES', en: 'UPPERCASE' } },
          { value: 'lower', label: { fr: 'minuscules', en: 'lowercase' } }
        ]
      },
      { key: 'spacerHeightPx', type: 'number', min: 0, max: 200, when: blockWhen('spacer'), label: { fr: 'Hauteur de l’espace (px)', en: 'Spacer height (px)' } },
      { key: 'separatorWidthPx', type: 'number', min: 1, max: 12, when: blockWhen('separator'), label: { fr: 'Épaisseur de la ligne (px)', en: 'Line width (px)' } },
      {
        key: 'separatorStyle',
        type: 'select',
        when: blockWhen('separator'),
        label: { fr: 'Style de ligne', en: 'Line style' },
        options: [
          { value: 'solid', label: { fr: 'Continue', en: 'Solid' } },
          { value: 'dashed', label: { fr: 'Tirets', en: 'Dashed' } },
          { value: 'dotted', label: { fr: 'Pointillés', en: 'Dotted' } },
          { value: 'double', label: { fr: 'Double', en: 'Double' } }
        ]
      },
      { key: 'separatorColor', type: 'color', when: blockWhen('separator'), label: { fr: 'Couleur de la ligne', en: 'Line color' } },
      { key: 'style.fontSizePx', type: 'number', min: 0, max: 96, when: dataBlockWhen, label: { fr: 'Taille du texte (px, 0 = héritée)', en: 'Text size (px, 0 = inherited)' } },
      { key: 'style.bold', type: 'boolean', when: dataBlockWhen, label: { fr: 'Gras', en: 'Bold' } },
      { key: 'style.italic', type: 'boolean', when: dataBlockWhen, label: { fr: 'Italique', en: 'Italic' } },
      { key: 'style.underline', type: 'boolean', when: dataBlockWhen, label: { fr: 'Souligné', en: 'Underline' } },
      { key: 'style.useColor', type: 'boolean', refreshOnChange: true, when: dataBlockWhen, label: { fr: 'Personnaliser la couleur', en: 'Customize color' } },
      {
        key: 'style.color',
        type: 'color',
        when: function (rootObject, fieldPath) {
          var block = blockFromPath(rootObject, fieldPath);
          return Boolean(block && ['guarantors', 'address', 'child', 'text'].indexOf(block.type) >= 0 && block.style && block.style.useColor === true);
        },
        label: { fr: 'Couleur du texte', en: 'Text color' }
      },
      {
        key: 'style.textAlign',
        type: 'select',
        when: dataBlockWhen,
        label: { fr: 'Alignement', en: 'Alignment' },
        options: [
          { value: 'inherit', label: { fr: 'Hérité', en: 'Inherited' } },
          { value: 'left', label: { fr: 'Gauche', en: 'Left' } },
          { value: 'center', label: { fr: 'Centré', en: 'Centered' } },
          { value: 'right', label: { fr: 'Droite', en: 'Right' } },
          { value: 'justify', label: { fr: 'Justifié', en: 'Justified' } }
        ]
      },
      { key: 'style.marginTopPx', type: 'number', min: 0, max: 200, when: dataBlockWhen, label: { fr: 'Marge avant (px)', en: 'Top margin (px)' } },
      { key: 'style.marginBottomPx', type: 'number', min: 0, max: 200, when: dataBlockWhen, label: { fr: 'Marge après (px)', en: 'Bottom margin (px)' } }
    ];

    return {
      id: MODULE_ID,
      schemaVersion: 3,
      name: {
        fr: 'Impression des retards / garant',
        en: 'Overdues printing / guarantor'
      },
      description: {
        fr: 'Prépare l’impression des retards pour les lecteurs avec garant. Le modèle historique reste disponible, et un constructeur complet permet de composer un modèle personnalisé sans code.',
        en: 'Prepares overdue printing for patrons with a guarantor. The historical model remains available, while a full builder can create a custom model without code.'
      },
      category: {
        fr: 'Adhérents / impression',
        en: 'Patrons / printing'
      },
      supportedPages: ['circ.circulation', 'members.moremember', 'members.print_overdues'],
      prerequisites: [],
      dependencies: [],
      defaults: DEFAULT_CONFIG,
      normalize: normalizeConfig,
      validate: function (config) {
        var cfg = normalizeConfig(config);
        if (cfg.rendering.mode === 'custom') {
          var enabled = (cfg.rendering.blocks || []).filter(function (block) { return block && block.enabled !== false; });
          if (!enabled.length) {
            return { ok: false, message: localized('Le modèle personnalisé doit contenir au moins un bloc actif.', 'The custom model must contain at least one enabled block.') };
          }
        }
        var selectorKeys = ['patronInformation', 'childNameLegacy', 'morememberHeading', 'guarantorLabel', 'printAction', 'printCapture', 'addressBlock'];
        for (var i = 0; i < selectorKeys.length; i += 1) {
          var selector = cleanText(cfg.selectors[selectorKeys[i]]);
          if (!selector) return { ok: false, message: localized('Un sélecteur technique du module 078 est vide.', 'A technical selector in module 078 is empty.') };
          try { document.querySelector(selector); } catch (_) {
            return { ok: false, message: localized('Un sélecteur technique du module 078 est invalide.', 'A technical selector in module 078 is invalid.') };
          }
        }
        return { ok: true };
      },
      schema: [
        {
          type: 'section',
          id: 'activation',
          label: { fr: 'Activation', en: 'Activation' },
          fields: [
            { key: 'enabled', type: 'boolean', label: { fr: 'Activer l’impression des retards / garant', en: 'Enable overdues / guarantor printing' } },
            {
              key: 'behavior.integratePrintOverduesInPrintMenu',
              type: 'boolean',
              label: { fr: 'Intégrer « Imprimer les retards » dans le menu Imprimer de Koha', en: 'Integrate “Print overdues” into Koha’s Print menu' },
              help: {
                fr: 'Activé par défaut : si Koha fournit #print_overdues, l’action est déplacée dans le menu Imprimer. Si elle est absente, PMK recrée l’action Koha équivalente vers print_overdues.pl pour le lecteur courant. Elle est placée juste avant le ticket de retour.',
                en: 'Enabled by default: when Koha provides #print_overdues, the action is moved into the Print menu. If it is absent, PMK recreates the equivalent Koha action to print_overdues.pl for the current patron. It is placed just before the check-in slip.'
              }
            }
          ]
        },
        {
          type: 'section',
          id: 'privacy',
          label: { fr: 'Destinataire et données imprimées', en: 'Recipient and printed data' },
          description: { fr: 'Ces informations permettent de vérifier le contenu personnel avant impression. Elles ne modifient pas le modèle historique.', en: 'Use this information to review personal content before printing. It does not change the historical model.' },
          fields: [
            { key: 'privacy.recipientPolicy', type: 'textarea', readOnly: true, label: { fr: 'Destinataire par défaut', en: 'Default recipient' } },
            { key: 'privacy.dataPolicy', type: 'textarea', readOnly: true, label: { fr: 'Données personnelles susceptibles d’être imprimées', en: 'Personal data that may be printed' } }
          ]
        },
        {
          type: 'section',
          id: 'model',
          label: { fr: 'Modèle d’impression', en: 'Print model' },
          description: {
            fr: 'Le mode Historique garantit le rendu actuel. Le mode Personnalisé active le constructeur ci-dessous.',
            en: 'Historical mode guarantees the current output. Custom mode enables the builder below.'
          },
          fields: [
            {
              key: 'rendering.mode',
              type: 'select',
              refreshOnChange: true,
              label: { fr: 'Mode d’impression', en: 'Print mode' },
              options: [
                { value: 'historical', label: { fr: 'Historique — rendu 078 strict', en: 'Historical — strict 078 output' } },
                { value: 'custom', label: { fr: 'Personnalisé — constructeur de modèle', en: 'Custom — model builder' } }
              ]
            },
            {
              key: 'rendering.skipEmptyBlocks',
              type: 'boolean',
              when: customMode,
              label: { fr: 'Ignorer automatiquement les blocs sans valeur', en: 'Automatically skip blocks with no value' }
            },
            {
              type: 'visualPreview',
              when: customMode,
              label: { fr: 'Aperçu du courrier', en: 'Letter preview' },
              help: {
                fr: 'Aperçu WYSIWYG mis à jour depuis le brouillon avec des données fictives. Il permet de régler l’ordre, les textes, marges, couleurs et alignements sans imprimer.',
                en: 'WYSIWYG preview updated from the draft with sample data. Use it to adjust order, text, margins, colors and alignment without printing.'
              }
            },
            {
              key: 'rendering.blocks',
              type: 'repeater',
              when: customMode,
              label: { fr: 'Blocs du modèle', en: 'Model blocks' },
              addLabel: { fr: 'Ajouter un bloc', en: 'Add block' },
              emptyLabel: { fr: 'Aucun bloc : ajoutez au moins un élément au modèle.', en: 'No blocks: add at least one element to the model.' },
              reorder: true,
              newItem: newPrintBlock,
              liveTitleKey: 'label',
              itemTitle: function (item, index) {
                return cleanText(item && item.label) || localized('Bloc ', 'Block ') + (index + 1);
              },
              fields: commonBlockFields
            }
          ]
        },
        {
          type: 'section',
          id: 'global-style',
          label: { fr: 'Style global du modèle personnalisé', en: 'Custom model global style' },
          when: customMode,
          fields: [
            {
              key: 'rendering.global.fontFamily',
              type: 'select',
              when: customMode,
              label: { fr: 'Police', en: 'Font' },
              options: [
                { value: 'inherit', label: { fr: 'Police Koha / notice', en: 'Koha / notice font' } },
                { value: 'Arial, sans-serif', label: { fr: 'Arial', en: 'Arial' } },
                { value: 'Verdana, sans-serif', label: { fr: 'Verdana', en: 'Verdana' } },
                { value: 'Georgia, serif', label: { fr: 'Georgia', en: 'Georgia' } },
                { value: 'Times New Roman, serif', label: { fr: 'Times New Roman', en: 'Times New Roman' } },
                { value: 'monospace', label: { fr: 'Monospace', en: 'Monospace' } }
              ]
            },
            { key: 'rendering.global.fontSizePx', type: 'number', min: 0, max: 96, when: customMode, label: { fr: 'Taille générale (px, 0 = héritée)', en: 'Global size (px, 0 = inherited)' } },
            { key: 'rendering.global.lineHeight', type: 'text', when: customMode, label: { fr: 'Interligne (ex. 1.3 ou 18px)', en: 'Line height (e.g. 1.3 or 18px)' } },
            {
              key: 'rendering.global.textAlign',
              type: 'select',
              when: customMode,
              label: { fr: 'Alignement général', en: 'Global alignment' },
              options: [
                { value: 'inherit', label: { fr: 'Hérité', en: 'Inherited' } },
                { value: 'left', label: { fr: 'Gauche', en: 'Left' } },
                { value: 'center', label: { fr: 'Centré', en: 'Centered' } },
                { value: 'right', label: { fr: 'Droite', en: 'Right' } },
                { value: 'justify', label: { fr: 'Justifié', en: 'Justified' } }
              ]
            },
            { key: 'rendering.global.useColor', type: 'boolean', refreshOnChange: true, when: customMode, label: { fr: 'Personnaliser la couleur générale', en: 'Customize global color' } },
            {
              key: 'rendering.global.color',
              type: 'color',
              when: function (rootObject) { return Boolean(customMode(rootObject) && rootObject.rendering.global.useColor === true); },
              label: { fr: 'Couleur générale', en: 'Global color' }
            }
          ]
        }
      ],
      focusContext: function (main, context) {
        if (!main) return;
        var wanted = context && context.sectionId ? context.sectionId : 'activation';
        var section = main.querySelector('[data-pmk-section-id="' + wanted + '"]')
          || main.querySelector('[data-pmk-section-id="activation"]');
        if (!section) return;
        window.setTimeout(function () {
          section.scrollIntoView({ block: 'start', behavior: 'smooth' });
        }, 0);
      }
    };
  }

  function registerVisualEditor() {
    if (!window.PMKConfig || !window.PMKConfig.visualEditor || typeof window.PMKConfig.visualEditor.register !== 'function') return false;
    try {
      window.PMKConfig.visualEditor.register(MODULE_ID, {
        capabilities: { inlinePreview: true },
        renderPreview: function (context) {
          var cfg = normalizeConfig(context && context.rootObject ? context.rootObject : DEFAULT_CONFIG);
          var paper = document.createElement('div');
          paper.className = 'pmk078-wysiwyg-preview';
          paper.style.background = '#fff';
          paper.style.color = '#212529';
          paper.style.border = '1px solid #cfd6dd';
          paper.style.borderRadius = '4px';
          paper.style.boxShadow = '0 2px 8px rgba(0,0,0,.08)';
          paper.style.padding = '22px 26px';
          paper.style.minHeight = '180px';
          paper.style.maxWidth = '680px';
          paper.style.margin = '0 auto';
          paper.style.boxSizing = 'border-box';
          var disclosure = privacyDisclosure(cfg);
          var notice = document.createElement('div');
          notice.className = 'pmk078-preview-disclosure';
          notice.style.cssText = 'margin:-10px -12px 16px;padding:9px 12px;background:#f3f6f9;border:1px solid #d7dfe7;border-radius:4px;font-size:12px;line-height:1.4';
          notice.textContent = localized('Destinataire : ', 'Recipient: ') + disclosure.recipient + ' · ' + localized('Données imprimées : ', 'Printed data: ') + (disclosure.fields.join(', ') || localized('aucune donnée personnelle dans les blocs actifs', 'no personal data in enabled blocks'));
          var letter = document.createElement('div');
          letter.className = 'pmk078-preview-letter';
          paper.appendChild(notice);
          paper.appendChild(letter);

          var sample = {
            guarantors: ['Jean DUPONT', 'Marie DUPONT'],
            guarantorJoined: 'Jean DUPONT, Marie DUPONT',
            addressLines: ['12 rue des Médiathèques', '83300 Draguignan'],
            childName: 'Paul DUPONT',
            borrowerNumber: '12345'
          };

          if (cfg.rendering.mode !== 'custom') {
            letter.innerHTML = '<div style="font-weight:700;margin-bottom:8px">Jean DUPONT, Marie DUPONT</div>' +
              '<div>12 rue des Médiathèques</div><div>83300 Draguignan</div><div style="margin-top:8px">Enfant : Paul DUPONT</div>';
            return paper;
          }

          var previous = currentConfig;
          try {
            currentConfig = cfg;
            var globalStyle = cfg.rendering.global || {};
            if (globalStyle.fontFamily && globalStyle.fontFamily !== 'inherit') paper.style.fontFamily = globalStyle.fontFamily;
            if (globalStyle.fontSizePx > 0) paper.style.fontSize = globalStyle.fontSizePx + 'px';
            if (cleanText(globalStyle.lineHeight)) paper.style.lineHeight = cleanText(globalStyle.lineHeight);
            if (globalStyle.useColor && cleanText(globalStyle.color)) paper.style.color = cleanText(globalStyle.color);
            if (globalStyle.textAlign && globalStyle.textAlign !== 'inherit') paper.style.textAlign = globalStyle.textAlign;
            var html = (cfg.rendering.blocks || []).map(function (block) { return renderCustomBlock(block, sample); }).filter(Boolean).join('');
            letter.innerHTML = html || '<div style="color:#6c757d;text-align:center">Aucun bloc actif à afficher.</div>';
          } finally {
            currentConfig = previous;
          }
          return paper;
        }
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  function registerModuleDefinition() {
    if (moduleRegistered) return true;
    if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function') return false;
    try {
      window.PMKConfig.registerModule(moduleDefinition());
      registerVisualEditor();
      moduleRegistered = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  function loadPMKConfig() {
    if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== 'function') return false;

    // Les événements de configuration reçus pendant la lecture initiale sont prioritaires.
    var loadVersion = configurationVersion;
    if (!subscribed && typeof window.PMKConfig.subscribe === 'function') {
      subscribed = true;
      window.PMKConfig.subscribe(MODULE_ID, function (config) {
        configurationVersion += 1;
        currentConfig = normalizeConfig(config || {});
        applyConfig();
      });
    }

    Promise.resolve().then(function () { return window.PMKConfig.getConfig(MODULE_ID); })
      .then(function (config) {
        if (configurationVersion !== loadVersion) return;
        currentConfig = normalizeConfig(config || {});
        applyConfig();
      }).catch(function () {
        // Ne jamais écraser une configuration plus récente par défaut.
        if (configurationVersion !== loadVersion) return;
        currentConfig = clone(DEFAULT_CONFIG);
        applyConfig();
      });
    return true;
  }

  function boot() {
    registerModuleDefinition();

    if (!isSupportedPage()) return;

    /* Démarrage immédiat avec le mode historique : indispensable sur
       print_overdues.pl, qui peut déclencher l'impression très rapidement. */
    currentConfig = clone(DEFAULT_CONFIG);
    purgeExpiredStoredData();
    applyConfig();
    loadPMKConfig();
  }

  /* Auto-enregistrement PMK même si le socle est chargé après le module. */
  if (!registerModuleDefinition()) {
    window.addEventListener('pmk:config-ready', function () {
      registerModuleDefinition();
      registerVisualEditor();
      if (isSupportedPage()) loadPMKConfig();
    }, { once: true });
  }

  /* Exécution immédiate comme le script historique. Sur une page encore en
     construction, waitFor() prend le relais pour les éléments tardifs. */
  boot();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      registerModuleDefinition();
      mountContextButton();
      ensurePrintActionInKohaMenu();
    }, { once: true });
  }
})();

;window.PMKNonPlugin.loaded.push("078-hide-print-overdues.js");
} catch (error) { window.PMKNonPlugin.errors.push("078-hide-print-overdues.js: "+error.message); console.error("[PMK] 078-hide-print-overdues.js",error); };
try {
/*
 Nom du fichier: 079-new-release-logos.js
 Module PMK: Indicateurs de nouveauté
 Version: 3.0.0-pmk-isolated
 Date de dernière modification: 2026-09-20
 Auteur: équipe PimpMyKoha / refactorisation PimpMyKoha

 Fonction:
 - affiche un seul badge de nouveauté par notice ;
 - le badge est calculé à partir de la date d'acquisition de l'exemplaire le plus récent ;
 - fonctionne sur catalogue/search.pl et catalogue/detail.pl ;
 - conserve les seuils historiques 3 mois / 6 mois / 1 an par défaut ;
 - conserve .date_achat comme source initiale sur search.pl ;
 - utilise dateaccessioned / acquisition_date sur detail.pl ;
 - s'intègre directement à PMK sans modification du socle 000 ;
 - FR/EN, responsive, idempotent, sans dépendance jQuery.
*/

(function () {
    "use strict";

    const MODULE_ID = "new-release-indicators";
    const MODULE_VERSION = "3.0.0-pmk-isolated";
    const SCRIPT_GUARD = "__pmk079NewReleaseIndicatorsV3";
    const STYLE_ID = "pmk079-new-release-style";
    const GENERATED_ATTR = "data-pmk079-generated";

    const SEARCH_PATH = "/cgi-bin/koha/catalogue/search.pl";
    const DETAIL_PATH = "/cgi-bin/koha/catalogue/detail.pl";
    const SEARCH_PAGE_ID = "catalogue.search.results";
    const DETAIL_PAGE_ID = "catalogue.detail";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    const DEFAULTS = {
        enabled: true,
        pages: {
            search: {
                enabled: true,
                pageId: SEARCH_PAGE_ID,
                path: SEARCH_PATH,
                rowSelector: 'tr[id^="row"]',
                dateSelector: ".date_achat",
                preferredTargetSelector: ".bookcoverimg"
            },
            detail: {
                enabled: true,
                pageId: DETAIL_PAGE_ID,
                path: DETAIL_PATH,
                rowSelector: "#holdings_table tbody tr",
                dateSelector: 'td.dateaccessioned, td[data-colname="acquisition_date"]',
                preferredTargetSelector: "#catalogue_detail_biblio p.first"
            }
        },
        thresholds: {
            recent: {
                days: 90,
                labelFr: "3m",
                labelEn: "3m",
                color: "#008000",
                tooltipFr: "Nouveauté de moins de 3 mois",
                tooltipEn: "New acquisition less than 3 months old"
            },
            medium: {
                days: 180,
                labelFr: "6m",
                labelEn: "6m",
                color: "#ffa500",
                tooltipFr: "Nouveauté de moins de 6 mois",
                tooltipEn: "New acquisition less than 6 months old"
            },
            year: {
                days: 365,
                labelFr: "1a",
                labelEn: "1y",
                color: "#ff0000",
                tooltipFr: "Nouveauté de moins de 1 an",
                tooltipEn: "New acquisition less than 1 year old"
            }
        },
        appearance: {
            showIcon: true,
            icon: "★",
            fontSizePx: 14,
            compact: true
        },
        behavior: {
            observeDynamicChanges: true,
            observeDelayMs: 120
        }
    };

    let currentConfig = clone(DEFAULTS);
    let unsubscribe = null;
    let observer = null;
    let observerTimer = null;
    let pmkRegistered = false;
    let started = false;

    function clone(value) {
        try {
            if (typeof structuredClone === "function") return structuredClone(value);
        } catch (_) {}
        return JSON.parse(JSON.stringify(value));
    }

    function object(value) {
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    }

    function merge(base, extra) {
        const out = clone(base);
        const src = object(extra);
        Object.keys(src).forEach(function (key) {
            const incoming = src[key];
            if (
                incoming && typeof incoming === "object" && !Array.isArray(incoming) &&
                out[key] && typeof out[key] === "object" && !Array.isArray(out[key])
            ) {
                out[key] = merge(out[key], incoming);
            } else {
                out[key] = clone(incoming);
            }
        });
        return out;
    }

    function integer(value, fallback, min, max) {
        let n = Number(value);
        if (!Number.isFinite(n)) n = fallback;
        n = Math.round(n);
        if (Number.isFinite(min)) n = Math.max(min, n);
        if (Number.isFinite(max)) n = Math.min(max, n);
        return n;
    }

    function cleanText(value, fallback) {
        const text = String(value == null ? "" : value).trim();
        return text || String(fallback == null ? "" : fallback);
    }

    function normalizeColor(value, fallback) {
        const candidate = String(value || "").trim();
        return /^#[0-9a-f]{6}$/i.test(candidate) ? candidate.toLowerCase() : fallback;
    }

    function normalizeConfig(config) {
        const value = merge(DEFAULTS, object(config));

        value.enabled = value.enabled !== false;
        value.pages = merge(DEFAULTS.pages, object(value.pages));
        value.pages.search = merge(DEFAULTS.pages.search, object(value.pages.search));
        value.pages.detail = merge(DEFAULTS.pages.detail, object(value.pages.detail));
        value.pages.search.enabled = value.pages.search.enabled !== false;
        value.pages.detail.enabled = value.pages.detail.enabled !== false;
        value.pages.search.pageId = SEARCH_PAGE_ID;
        value.pages.detail.pageId = DETAIL_PAGE_ID;
        value.pages.search.path = SEARCH_PATH;
        value.pages.detail.path = DETAIL_PATH;

        value.thresholds = merge(DEFAULTS.thresholds, object(value.thresholds));
        ["recent", "medium", "year"].forEach(function (key) {
            value.thresholds[key] = merge(DEFAULTS.thresholds[key], object(value.thresholds[key]));
        });

        value.thresholds.recent.days = integer(value.thresholds.recent.days, 90, 1, 3650);
        value.thresholds.medium.days = integer(value.thresholds.medium.days, 180, 1, 3650);
        value.thresholds.year.days = integer(value.thresholds.year.days, 365, 1, 3650);

        ["recent", "medium", "year"].forEach(function (key) {
            const base = DEFAULTS.thresholds[key];
            const tier = value.thresholds[key];
            tier.labelFr = cleanText(tier.labelFr, base.labelFr);
            tier.labelEn = cleanText(tier.labelEn, base.labelEn);
            tier.tooltipFr = cleanText(tier.tooltipFr, base.tooltipFr);
            tier.tooltipEn = cleanText(tier.tooltipEn, base.tooltipEn);
            tier.color = normalizeColor(tier.color, base.color);
        });

        value.appearance = merge(DEFAULTS.appearance, object(value.appearance));
        value.appearance.showIcon = value.appearance.showIcon !== false;
        value.appearance.icon = cleanText(value.appearance.icon, DEFAULTS.appearance.icon);
        value.appearance.fontSizePx = integer(value.appearance.fontSizePx, 14, 9, 28);
        value.appearance.compact = value.appearance.compact !== false;

        value.behavior = merge(DEFAULTS.behavior, object(value.behavior));
        value.behavior.observeDynamicChanges = value.behavior.observeDynamicChanges !== false;
        value.behavior.observeDelayMs = integer(value.behavior.observeDelayMs, 120, 50, 2000);

        value.pages.search.rowSelector = cleanText(
            value.pages.search.rowSelector,
            DEFAULTS.pages.search.rowSelector
        );
        value.pages.search.dateSelector = cleanText(
            value.pages.search.dateSelector,
            DEFAULTS.pages.search.dateSelector
        );
        value.pages.search.preferredTargetSelector = cleanText(
            value.pages.search.preferredTargetSelector,
            DEFAULTS.pages.search.preferredTargetSelector
        );
        value.pages.detail.rowSelector = cleanText(
            value.pages.detail.rowSelector,
            DEFAULTS.pages.detail.rowSelector
        );
        value.pages.detail.dateSelector = cleanText(
            value.pages.detail.dateSelector,
            DEFAULTS.pages.detail.dateSelector
        );
        value.pages.detail.preferredTargetSelector = cleanText(
            value.pages.detail.preferredTargetSelector,
            DEFAULTS.pages.detail.preferredTargetSelector
        );

        return value;
    }

    function validateConfig(config) {
        const value = normalizeConfig(config);
        const lang = language();
        const fail = function (fr, en) {
            return { ok: false, message: lang === "en" ? en : fr };
        };

        if (!(value.thresholds.recent.days < value.thresholds.medium.days)) {
            return fail(
                "Le premier seuil doit être inférieur au deuxième.",
                "The first threshold must be lower than the second."
            );
        }
        if (!(value.thresholds.medium.days < value.thresholds.year.days)) {
            return fail(
                "Le deuxième seuil doit être inférieur au troisième.",
                "The second threshold must be lower than the third."
            );
        }
        return { ok: true };
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object"
            ? window.PMKConfig
            : null;
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try { return api.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const htmlLang = (document.documentElement.getAttribute("lang") || "").toLowerCase();
        if (htmlLang.startsWith("en")) return "en";
        const navLang = (navigator.language || "").toLowerCase();
        return navLang.startsWith("en") ? "en" : "fr";
    }

    function registerPmkDefinition() {
        const api = pmkApi();
        if (!api || typeof api.registerModule !== "function") return false;
        if (pmkRegistered) return true;

        try {
            api.registerModule({
                id: MODULE_ID,
                schemaVersion: 1,
                name: {
                    fr: "Indicateurs de nouveauté",
                    en: "New acquisition indicators"
                },
                description: {
                    fr: "Affiche un badge de nouveauté calculé à partir de la date d’acquisition de l’exemplaire le plus récent, sur les résultats de recherche et la notice détaillée.",
                    en: "Displays a new-acquisition badge calculated from the most recent item acquisition date on search results and record detail pages."
                },
                category: {
                    fr: "Catalogue / affichage",
                    en: "Catalog / display"
                },
                supportedPages: [SEARCH_PAGE_ID, DETAIL_PAGE_ID],
                prerequisites: [
                    {
                        fr: "Sur search.pl, la configuration d’origine utilise la classe .date_achat produite par le rendu/XSLT local. Sur une autre installation, renseigner le sélecteur qui contient les dates d’acquisition.",
                        en: "On search.pl, the Original installation defaults use the .date_achat class produced by the local XSLT/output. On another installation, set the selector containing acquisition dates."
                    }
                ],
                dependencies: [],
                defaults: clone(DEFAULTS),
                normalize: normalizeConfig,
                validate: validateConfig,
                schema: [
                    {
                        type: "section",
                        id: "general",
                        label: { fr: "Fonctionnement", en: "Behavior" },
                        description: {
                            fr: "Une notice reçoit au maximum un badge. Le calcul retient uniquement l’exemplaire dont la date d’acquisition est la plus récente. Les dates futures et invalides sont ignorées.",
                            en: "A record receives at most one badge. The calculation only uses the item with the most recent acquisition date. Future and invalid dates are ignored."
                        },
                        fields: [
                            {
                                key: "enabled",
                                type: "boolean",
                                label: { fr: "Activer le module", en: "Enable module" }
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "pages",
                        label: { fr: "Pages actives", en: "Enabled pages" },
                        description: {
                            fr: "Les deux pages historiques sont actives par défaut et peuvent être désactivées indépendamment.",
                            en: "Both historical pages are enabled by default and can be disabled independently."
                        },
                        fields: [
                            {
                                key: "pages.search.enabled",
                                type: "boolean",
                                label: { fr: "Résultats de recherche — search.pl", en: "Search results — search.pl" }
                            },
                            {
                                key: "pages.detail.enabled",
                                type: "boolean",
                                label: { fr: "Détail de notice — detail.pl", en: "Record detail — detail.pl" }
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "thresholds",
                        label: { fr: "Seuils de nouveauté", en: "New acquisition thresholds" },
                        description: {
                            fr: "Valeurs historiques : 90 jours = 3m, 180 jours = 6m, 365 jours = 1a. Les seuils doivent rester croissants.",
                            en: "Historical defaults: 90 days = 3m, 180 days = 6m, 365 days = 1y. Thresholds must remain increasing."
                        },
                        fields: [
                            { key: "thresholds.recent.days", type: "number", min: 1, max: 3650, label: { fr: "Premier seuil — jours", en: "First threshold — days" } },
                            { key: "thresholds.recent.labelFr", type: "text", label: { fr: "Premier badge — libellé FR", en: "First badge — French label" } },
                            { key: "thresholds.recent.labelEn", type: "text", label: { fr: "Premier badge — libellé EN", en: "First badge — English label" } },
                            { key: "thresholds.recent.color", type: "color", label: { fr: "Premier badge — couleur", en: "First badge — color" } },
                            { key: "thresholds.recent.tooltipFr", type: "text", label: { fr: "Premier badge — infobulle FR", en: "First badge — French tooltip" } },
                            { key: "thresholds.recent.tooltipEn", type: "text", label: { fr: "Premier badge — infobulle EN", en: "First badge — English tooltip" } },

                            { key: "thresholds.medium.days", type: "number", min: 1, max: 3650, label: { fr: "Deuxième seuil — jours", en: "Second threshold — days" } },
                            { key: "thresholds.medium.labelFr", type: "text", label: { fr: "Deuxième badge — libellé FR", en: "Second badge — French label" } },
                            { key: "thresholds.medium.labelEn", type: "text", label: { fr: "Deuxième badge — libellé EN", en: "Second badge — English label" } },
                            { key: "thresholds.medium.color", type: "color", label: { fr: "Deuxième badge — couleur", en: "Second badge — color" } },
                            { key: "thresholds.medium.tooltipFr", type: "text", label: { fr: "Deuxième badge — infobulle FR", en: "Second badge — French tooltip" } },
                            { key: "thresholds.medium.tooltipEn", type: "text", label: { fr: "Deuxième badge — infobulle EN", en: "Second badge — English tooltip" } },

                            { key: "thresholds.year.days", type: "number", min: 1, max: 3650, label: { fr: "Troisième seuil — jours", en: "Third threshold — days" } },
                            { key: "thresholds.year.labelFr", type: "text", label: { fr: "Troisième badge — libellé FR", en: "Third badge — French label" } },
                            { key: "thresholds.year.labelEn", type: "text", label: { fr: "Troisième badge — libellé EN", en: "Third badge — English label" } },
                            { key: "thresholds.year.color", type: "color", label: { fr: "Troisième badge — couleur", en: "Third badge — color" } },
                            { key: "thresholds.year.tooltipFr", type: "text", label: { fr: "Troisième badge — infobulle FR", en: "Third badge — French tooltip" } },
                            { key: "thresholds.year.tooltipEn", type: "text", label: { fr: "Troisième badge — infobulle EN", en: "Third badge — English tooltip" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "appearance",
                        label: { fr: "Apparence", en: "Appearance" },
                        description: {
                            fr: "Le rendu reste volontairement compact et proche de Koha. Les couleurs historiques restent les valeurs par défaut.",
                            en: "The display remains intentionally compact and close to Koha. Historical colors remain the defaults."
                        },
                        fields: [
                            { key: "appearance.showIcon", type: "boolean", label: { fr: "Afficher l’icône", en: "Show icon" } },
                            {
                                key: "appearance.icon",
                                type: "text",
                                label: { fr: "Icône / caractère", en: "Icon / character" },
                                when: function (root) { return root.appearance && root.appearance.showIcon !== false; }
                            },
                            { key: "appearance.fontSizePx", type: "number", min: 9, max: 28, label: { fr: "Taille du texte (px)", en: "Text size (px)" } },
                            { key: "appearance.compact", type: "boolean", label: { fr: "Rendu compact", en: "Compact display" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "advanced",
                        label: { fr: "Compatibilité / réglages avancés", en: "Compatibility / advanced settings" },
                        description: {
                            fr: "Ces sélecteurs permettent d’adapter le module à une autre installation sans modifier le code. Les valeurs initiales sont préchargées.",
                            en: "These selectors let the module adapt to another installation without code changes. Original values are preloaded."
                        },
                        fields: [
                            { key: "pages.search.rowSelector", type: "text", advanced: true, label: { fr: "Search — sélecteur d’une ligne de résultat", en: "Search — result row selector" } },
                            { key: "pages.search.dateSelector", type: "text", advanced: true, label: { fr: "Search — sélecteur des dates d’acquisition", en: "Search — acquisition date selector" }, help: { fr: "Valeur initiale : .date_achat", en: "Original value: .date_achat" } },
                            { key: "pages.search.preferredTargetSelector", type: "text", advanced: true, label: { fr: "Search — cible d’affichage préférée", en: "Search — preferred display target" } },
                            { key: "pages.detail.rowSelector", type: "text", advanced: true, label: { fr: "Detail — sélecteur des lignes d’exemplaires", en: "Detail — item row selector" } },
                            { key: "pages.detail.dateSelector", type: "text", advanced: true, label: { fr: "Detail — sélecteur de la date d’acquisition", en: "Detail — acquisition date selector" } },
                            { key: "pages.detail.preferredTargetSelector", type: "text", advanced: true, label: { fr: "Detail — cible d’affichage préférée", en: "Detail — preferred display target" } },
                            { key: "behavior.observeDynamicChanges", type: "boolean", advanced: true, label: { fr: "Retraiter les contenus ajoutés dynamiquement", en: "Reprocess dynamically added content" } },
                            { key: "behavior.observeDelayMs", type: "number", min: 50, max: 2000, advanced: true, label: { fr: "Délai de retraitement (ms)", en: "Reprocessing delay (ms)" } }
                        ]
                    }
                ],
                focusContext: function (main, context) {
                    if (!main) return;
                    const wanted = context && context.sectionId ? context.sectionId : "general";
                    const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                    if (!section) return;
                    window.setTimeout(function () {
                        try { section.scrollIntoView({ block: "start", behavior: "smooth" }); } catch (_) {}
                    }, 60);
                }
            });
            pmkRegistered = true;
            return true;
        } catch (_) {
            return false;
        }
    }

    if (!registerPmkDefinition()) {
        window.addEventListener("pmk:config-ready", function () {
            registerPmkDefinition();
        }, { once: true });
    }

    function parseDate(value) {
        if(window.PMKDates){const date=window.PMKDates.parse(value);return date?validLocalDate(date.getFullYear(),date.getMonth()+1,date.getDate()):null;}
        const raw = String(value == null ? "" : value).trim();
        if (!raw) return null;

        let match = raw.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})(?:\D.*)?$/);
        if (match) {
            return validLocalDate(Number(match[1]), Number(match[2]), Number(match[3]));
        }

        match = raw.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})(?:\D.*)?$/);
        if (match) {
            return validLocalDate(Number(match[3]), Number(match[2]), Number(match[1]));
        }

        const native = new Date(raw);
        if (Number.isNaN(native.getTime())) return null;
        return new Date(native.getFullYear(), native.getMonth(), native.getDate(), 12, 0, 0, 0);
    }

    function validLocalDate(year, month, day) {
        if (year < 1000 || month < 1 || month > 12 || day < 1 || day > 31) return null;
        const date = new Date(year, month - 1, day, 12, 0, 0, 0);
        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) return null;
        return date;
    }

    function todayNoon() {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0, 0);
    }

    function newestValidDate(elements) {
        const today = todayNoon();
        let newest = null;

        Array.from(elements || []).forEach(function (node) {
            const date = parseDate(node && (node.getAttribute("data-order") || node.getAttribute("datetime") || node.textContent));
            if (!date) return;
            if (date.getTime() > today.getTime()) return;
            if (!newest || date.getTime() > newest.getTime()) newest = date;
        });

        return newest;
    }

    function ageInDays(date) {
        if (!(date instanceof Date) || Number.isNaN(date.getTime())) return null;
        const today=todayNoon();
        const diff = Date.UTC(today.getFullYear(),today.getMonth(),today.getDate()) - Date.UTC(date.getFullYear(),date.getMonth(),date.getDate());
        if (diff < 0) return null;
        return Math.floor(diff / 86400000);
    }

    function indicatorFor(date) {
        const days = ageInDays(date);
        if (days === null) return null;

        const thresholds = currentConfig.thresholds;
        if (days <= thresholds.recent.days) return thresholds.recent;
        if (days <= thresholds.medium.days) return thresholds.medium;
        if (days <= thresholds.year.days) return thresholds.year;
        return null;
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk079-wrapper {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: .3rem;
                margin: .35rem 0;
                max-width: 100%;
            }
            .pmk079-wrapper.pmk079-search {
                justify-content: flex-start;
            }
            .pmk079-badge {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: .28rem;
                color: #fff;
                font-weight: 600;
                line-height: 1.25;
                white-space: nowrap;
                border-radius: 999px;
                padding: .23rem .52rem;
                box-shadow: 0 1px 3px rgba(0,0,0,.18);
                vertical-align: middle;
                cursor: default;
                transition: opacity .15s ease, filter .15s ease;
            }
            .pmk079-wrapper:not(.pmk079-compact) .pmk079-badge {
                padding: .32rem .68rem;
            }
            .pmk079-badge:hover,
            .pmk079-badge:focus-visible {
                opacity: .88;
                filter: saturate(.94);
            }
            .pmk079-icon {
                line-height: 1;
                flex: 0 0 auto;
            }
            @media (max-width: 576px) {
                .pmk079-wrapper { margin: .28rem 0; }
                .pmk079-badge { max-width: 100%; }
            }
        `;
        document.head.appendChild(style);
    }

    function clearGenerated() {
        document.querySelectorAll("[" + GENERATED_ATTR + '="1"]').forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });
    }

    function makeBadge(indicator, pageKind, acquisitionDate) {
        const lang = language();
        const badge = document.createElement("span");
        badge.className = "pmk079-badge";
        badge.style.backgroundColor = indicator.color;
        badge.style.fontSize = currentConfig.appearance.fontSizePx + "px";
        badge.setAttribute("role", "img");

        const tooltip = lang === "en" ? indicator.tooltipEn : indicator.tooltipFr;
        const suffix = pageKind === "detail"
            ? (lang === "en"
                ? " — most recent item acquisition date"
                : " — date d’acquisition de l’exemplaire le plus récent")
            : "";
        const sourceDate=acquisitionDate.toLocaleDateString(lang==='en'?'en-GB':'fr-FR');
        badge.title = tooltip + suffix + (lang==='en'?' — Acquisition: ':' — Acquisition : ') + sourceDate;
        badge.dataset.acquisitionDate=[acquisitionDate.getFullYear(),String(acquisitionDate.getMonth()+1).padStart(2,'0'),String(acquisitionDate.getDate()).padStart(2,'0')].join('-');
        badge.setAttribute("aria-label", badge.title);

        if (currentConfig.appearance.showIcon) {
            const icon = document.createElement("span");
            icon.className = "pmk079-icon";
            icon.setAttribute("aria-hidden", "true");
            icon.textContent = currentConfig.appearance.icon;
            badge.appendChild(icon);
        }

        const label = document.createElement("span");
        label.textContent = lang === "en" ? indicator.labelEn : indicator.labelFr;
        badge.appendChild(label);
        return badge;
    }

    function makeWrapper(indicator, pageKind, acquisitionDate) {
        const wrapper = document.createElement("div");
        wrapper.className = "pmk079-wrapper pmk079-" + pageKind;
        if (currentConfig.appearance.compact) wrapper.classList.add("pmk079-compact");
        wrapper.setAttribute(GENERATED_ATTR, "1");
        wrapper.appendChild(makeBadge(indicator, pageKind, acquisitionDate));
        return wrapper;
    }

    function safeQuery(root, selector) {
        if (!root || !selector) return null;
        try { return root.querySelector(selector); } catch (_) { return null; }
    }

    function safeQueryAll(root, selector) {
        if (!root || !selector) return [];
        try { return root.querySelectorAll(selector); } catch (_) { return []; }
    }

    function searchTarget(row) {
        const preferred = safeQuery(row, currentConfig.pages.search.preferredTargetSelector);
        if (preferred) return preferred;

        const title = safeQuery(row, ".bibliotitle, a.title, .title");
        if (title && title.closest("td")) return title.closest("td");

        const cells = safeQueryAll(row, "td");
        if (cells.length > 1) return cells[1];
        if (cells.length === 1) return cells[0];
        return null;
    }

    function processSearch() {
        if (!currentConfig.pages.search.enabled) return;

        const rows = safeQueryAll(document, currentConfig.pages.search.rowSelector);
        Array.from(rows).forEach(function (row) {
            const dates = safeQueryAll(row, currentConfig.pages.search.dateSelector);
            const newest = newestValidDate(dates);
            if (!newest) return;

            const indicator = indicatorFor(newest);
            if (!indicator) return;

            const target = searchTarget(row);
            if (!target) return;

            const wrapper = makeWrapper(indicator, "search", newest);
            target.appendChild(wrapper);
        });
    }

    function detailTarget() {
        const preferred = safeQuery(document, currentConfig.pages.detail.preferredTargetSelector);
        if (preferred && preferred.parentNode) {
            return { node: preferred, mode: "before" };
        }

        const heading = safeQuery(document, "#catalogue_detail_biblio h1, #catalogue_detail_biblio h2");
        if (heading && heading.parentNode) return { node: heading, mode: "after" };

        const section = safeQuery(document, "#catalogue_detail_biblio .page-section, #catalogue_detail_biblio");
        if (section) return { node: section, mode: "prepend" };

        return null;
    }

    function processDetail() {
        if (!currentConfig.pages.detail.enabled) return;

        const rows = safeQueryAll(document, currentConfig.pages.detail.rowSelector);
        const dates = [];
        Array.from(rows).forEach(function (row) {
            Array.from(safeQueryAll(row, currentConfig.pages.detail.dateSelector)).forEach(function (cell) {
                dates.push(cell);
            });
        });

        const newest = newestValidDate(dates);
        if (!newest) return;

        const indicator = indicatorFor(newest);
        if (!indicator) return;

        const target = detailTarget();
        if (!target) return;

        const wrapper = makeWrapper(indicator, "detail", newest);
        if (target.mode === "before") {
            target.node.parentNode.insertBefore(wrapper, target.node);
        } else if (target.mode === "after") {
            target.node.parentNode.insertBefore(wrapper, target.node.nextSibling);
        } else {
            target.node.insertBefore(wrapper, target.node.firstChild);
        }
    }

    function currentPageKind() {
        const path = window.location.pathname || "";
        if (path === SEARCH_PATH) return "search";
        if (path === DETAIL_PATH) return "detail";
        return "";
    }

    function mountContextAccess(pageKind) {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;

        let anchor = null;
        let pageId = "";
        if (pageKind === "search") {
            anchor = safeQuery(document, "#searchresults h1, #searchresults h2, #searchresults h3, h1, h2");
            pageId = SEARCH_PAGE_ID;
        } else if (pageKind === "detail") {
            anchor = safeQuery(document, "#catalogue_detail_biblio h1, #catalogue_detail_biblio h2, #catalogue_detail_biblio p.first");
            pageId = DETAIL_PAGE_ID;
        }
        if (!anchor) return;

        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: pageId,
                context: {
                    sectionId: "general",
                    pageId: pageId
                }
            });
        } catch (_) {}
    }

    function stopObserver() {
        if (observer) {
            try { observer.disconnect(); } catch (_) {}
            observer = null;
        }
        if (observerTimer) {
            window.clearTimeout(observerTimer);
            observerTimer = null;
        }
    }

    function startObserver() {
        stopObserver();
        if (!currentConfig.behavior.observeDynamicChanges) return;
        if (!document.body || typeof MutationObserver !== "function") return;

        observer = new MutationObserver(function (mutations) {
            const relevant = Array.from(mutations || []).some(function (mutation) {
                if (!mutation) return false;
                const target = mutation.target && mutation.target.nodeType === 1
                    ? mutation.target
                    : mutation.target && mutation.target.parentElement;
                if (target && target.closest && target.closest("[" + GENERATED_ATTR + '=\"1\"]')) return false;
                return mutation.addedNodes && mutation.addedNodes.length > 0;
            });
            if (!relevant) return;

            if (observerTimer) window.clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                observerTimer = null;
                applyConfig(currentConfig, true);
            }, currentConfig.behavior.observeDelayMs);
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    function applyConfig(config, fromObserver) {
        currentConfig = normalizeConfig(config || DEFAULTS);
        const pageKind = currentPageKind();

        if (observer && !fromObserver) stopObserver();
        if (observer && fromObserver) {
            try { observer.disconnect(); } catch (_) {}
        }

        clearGenerated();

        if (currentConfig.enabled && pageKind) {
            injectStyles();
            if (pageKind === "search" && currentConfig.pages.search.enabled) processSearch();
            if (pageKind === "detail" && currentConfig.pages.detail.enabled) processDetail();
            mountContextAccess(pageKind);
        }

        if (pageKind) startObserver();
    }

    function connectPmkConfig() {
        registerPmkDefinition();
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            applyConfig(DEFAULTS);
            return false;
        }

        api.getConfig(MODULE_ID)
            .then(function (config) {
                applyConfig(config || DEFAULTS);
            })
            .catch(function () {
                applyConfig(DEFAULTS);
            });

        if (!unsubscribe && typeof api.subscribe === "function") {
            try {
                unsubscribe = api.subscribe(MODULE_ID, function (config) {
                    applyConfig(config || DEFAULTS);
                });
            } catch (_) {}
        }

        return true;
    }

    function start() {
        if (started) return;
        started = true;

        if (!currentPageKind()) return;

        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }

        window.setTimeout(function () { applyConfig(currentConfig); }, 250);
        window.setTimeout(function () { applyConfig(currentConfig); }, 900);
    }

    window.PMK079NewReleaseIndicators = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULTS),
        normalizeConfig: normalizeConfig,
        validateConfig: validateConfig,
        parseDate: parseDate,
        newestValidDate: newestValidDate,
        indicatorFor: indicatorFor,
        applyConfig: applyConfig,
        clearGenerated: clearGenerated
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("079-new-release-logos.js");
} catch (error) { window.PMKNonPlugin.errors.push("079-new-release-logos.js: "+error.message); console.error("[PMK] 079-new-release-logos.js",error); };
try {
/*
 Nom du fichier : 081-084-6xx-suggestions.js
 Module PMK      : Aide à l’indexation 6XX
 ID PMK          : cataloging-6xx-suggestions
 Version         : 2.3.3-preplugin
 Date            : 2026-10-01
 Auteur          : équipe PimpMyKoha / consolidation PimpMyKoha

 Fusion :
 - 081-6xx-genre-select2.js
 - 082-6xx-indexation-select2.js
 - 083-6xx-element-entry-suggestions.js
 - 084-6xx-subject-category-suggestions.js

 Principes :
 - un seul moteur, autant de règles 6XX que nécessaire ;
 - les quatre listes initiales sont conservées comme presets ;
 - le vrai champ Koha n'est jamais remplacé ni désactivé ;
 - ciblage prioritaire par zone + sous-zone MARC, libellé seulement en secours ;
 - source des suggestions : manuel / valeurs autorisées Koha / mixte ;
 - plusieurs catégories de valeurs autorisées peuvent alimenter une même règle ;
 - déduplication des valeurs ;
 - Select2 si disponible, chargement optionnel si absent, repli natif sinon ;
 - prise en charge des champs / zones répétés ajoutés dynamiquement par Koha ;
 - les contrôles d’aide PMK ne portent jamais de name : seul le vrai champ Koha est soumis ;
 - présentation initiale restaurée par défaut : champ de gauche + liste Select2 de droite en 50/50, écart 10 px, sans compteur ajouté.

 Correctifs 2.3.1 :
 - suppression du doublon visuel Select2 / select natif ;
 - masquage temporaire du Select2 Koha natif en mode historique, sans le détruire ;
 - sécurisation des répétitions/suppressions de zones et sous-zones Koha ;
 - conservation de toutes les sous-zones MARC lors de l’enregistrement ;
 - ciblage de secours par libellé plus strict ;
 - options de tri/déduplication appliquées également aux presets historiques.
 - correction de la synchronisation Select2 -> vrai champ MARC Koha ;
 - synchronisation de sécurité juste avant document.f.submit().
*/

(function () {
    "use strict";

    if (window.__PMK6XXConfigBootstrapLoaded) return;
    window.__PMK6XXConfigBootstrapLoaded = true;

    const MODULE_ID = "cataloging-6xx-suggestions";
    const MODULE_VERSION = "2.3.3-preplugin";
    const PAGE_PATH_SUFFIX = "/addbiblio.pl";
    const PAGE_ID = "cataloguing.addbiblio";

    const HISTORICAL = {
        genre: "Abécédaires\nAction & Aventure\nAlbums pour les plus grands\nApprentissage\nAventure\nBandes originales de films\nBiographies romancées\nBlack Music\nClassiques\nComics\nComptine, chanson\nDark romance\nDocu-fictions, biographies, histoires vécues\nDystopie\nElectro\nÉrotique\nEspionnage\nFantastique/Fantasy\nFeel good\nFilm Famille\nFilm d'animation\nFilm-Vintage\nFilms - Grands classiques\nFilms-Aventure\nFilms-Action\nFilms-Courts métrages\nFilms-Drames\nFilms-Japanimation\nFilms-Regards de femmes\nFilms-Science-fiction\nFilms-Se détendre\nFilms-Western\nFilms d'horreur\nFilms historiques\nFilms muets\nFilms musicaux\nFilms noirs\nFrissons\nHistorique\nHorreur\nHumour\nImagiers\nInitiatique\nJazz\nLégendes, mythes, fables\nLivre à toucher\nLivre sonore\nLivre animé\nLivres à compter\nLivre-jeu\nMondes Imaginaires\nMystères et enquêtes\nMusique Classique\nMusique Francophone\nMusique actuelle\nMusique du monde\nNature\nNovélisation de films/séries\nNovélisation de jeux vidéo\nNouvelles\nPolicier\nPsychologique\nRéaliste\nRécits de vie\nRimes\nRomance\nScience-fiction\nSentimental\nSerie|serie\nSéries courtes\nTerroir\nThriller",
        indexation: "Adaptation litteraire|Adaptation littéraire\nAlbum sans texte\nAntivol\nBandes originales\nBD Documentaire\nBD One Shot\nBD petit format|BD Petit format\nBD sans texte\nBiographie\nBlack Music\nComics\nCorner nature\nDVD Musicaux\nDVD Théâtre\nDyslexique\nElectro\nFilm d'animation\nFilm Famille\nFilm-Drame\nFilm-Vintage\nFilms - Grands classiques\nFilms-Aventure\nFilms-Action\nFilms-Courts métrages\nFilms-Grands classiques\nFilms-Japanimation\nFilms-Regards de femmes\nFilms-Science-fiction\nFilms-Se détendre\nFilms-Western\nFilms d'horreur\nFilms historiques\nFilms muets\nFilms musicaux\nFilms noirs\nFacile a lire\nHumour\nImages de dragons\nInstruments de musique\nJazz\nJeu illustrateur\nJeux de société\nLangues etrangeres|Langues étrangères\nlitteratures|Littératures\nMangas\nMusique à Lire\nMusique actuelle\nMusique Classique\nMusique du monde\nMusique Francophone\nParents et compagnie\nPoesie et theatre|Poésie et théâtre\nPremière lecture\nPremieres cases|Premières cases\nRomans Ados\nScène locale\nserie|Série\nSéries courtes\nTextes illustrés\nvintage|Film - Vintage",
        element: "Sorcières\nLe loup\nMonstres\nSirènes\nPrinces, chevaliers et princesses\nPirates\nIndiens, Cow-boys\nSuperhéros\nMulticulturalisme et diversité",
        subject: "Acquisition de la Propreté\nAffirmation de soi et opposition\nAngoisse de séparation\nAlimentation\nAmitié\nAnimaux\nAnimaux familiers\nAnimaux sauvages\nArts et spectacles\nBain, hygiène\nBobos\nBonnes Manières\nCampagne, vie rurale, ferme\nCaractères (courageux, curiosité, rêveur, leader...)\nChâteaux forts\nCivilisations (Maya, Viking, esquimau...)\nColère\nComportements sociaux (antisémitisme, différence, entraide, relation fille-garçons..)\nConditions de vie (pauvreté, précarité, immigration et réfugiés..)\nCorps humain (cinq sens, image du corps..)\nCrèche\nDéménagement\nDinosaures\nDoudou / Tétine\nÉcologie, environnement\nÉmotions et Sentiments\nEngins et moyens de Transport\nFêtes (Noël, Pâques...)\nHistoire (grandes époques, guerres et conflits, personnages célèbres)\nIntimidation / Harcèlement\nLangage, jeux de langage, jeux de mots, contraire\nLe corps et ses différences (handicaps, neurodiversité, lunettes..)\nLe rituel du coucher\nLes conflits\nLivre et bibliothèque\nMaison, habitation, jardin et jardinage\nMaternité, naissance\nMers, marins\nMétéorologie et saisons\nMort, deuil\nNature\nNouveau bébé\nOrphelins et foyers d'accueil\nPays et continents\nPeur du noir\nPolitesse, bienséance\nPremiers apprentissages (couleurs, formes, etc)\nPréhistoire\nQuestions de genres\nRelation aux autres\nRelations dans la famille (Fratrie, Parents, Grands-parents, Familles atypiques..)\nReligions, croyances\nRentrée scolaire\nSanté et maladies\nScolarité\nSciences et techniques (espace, inventions...)\nSéparation Divorce\nSons, bruits et cris\nSport\nTerritoires (Amazonie, jungle, montagne, désert, banquise, île, forêt...)\nTransgression des interdits : inceste, maltraitance, violence, violence sexuelle, vol..\n Intimidation / Harcèlement\nTravail et métiers\nVacances\nVille (bâtiment et construction, zoo, jardin public, marché, musée..etc)\nVie quotidienne familiale (bêtises, respect des règles, éducation, fugue..)"
    };

    function clone(value) {
        if (value === undefined) return undefined;
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function boundedNumber(value, min, max, fallback) {
        if (value === null || value === undefined || value === "") return fallback;
        const number = Number(value);
        if (!Number.isFinite(number)) return fallback;
        return Math.max(min, Math.min(max, number));
    }

    function deepMerge(target, source) {
        if (!source || typeof source !== "object") return target;
        Object.keys(source).forEach(function (key) {
            const value = source[key];
            if (Array.isArray(value)) target[key] = clone(value);
            else if (value && typeof value === "object") {
                if (!target[key] || typeof target[key] !== "object" || Array.isArray(target[key])) target[key] = {};
                deepMerge(target[key], value);
            } else if (value !== undefined) {
                target[key] = value;
            }
        });
        return target;
    }

    function uid(prefix) {
        return (prefix || "rule") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
    }

    function newCategory() {
        return {
            enabled: true,
            name: "",
            manualName: ""
        };
    }

    function newRule() {
        return {
            id: uid("6xx"),
            enabled: true,
            nameFr: "Nouvelle aide 6XX",
            nameEn: "New 6XX helper",
            marcTag: "610",
            subfield: "a",
            fallbackLabel: "",
            placeholderFr: "Sélectionner une valeur",
            placeholderEn: "Select a value",
            select2PlaceholderFr: "",
            sourceMode: "manual",
            categories: [],
            manualValues: "",
            displayMode: "description",
            sortMode: "source",
            deduplicateCaseInsensitive: false
        };
    }

    const DEFAULTS = {
        enabled: true,
        pages: [
            {
                id: PAGE_ID,
                pathSuffix: PAGE_PATH_SUFFIX,
                enabled: true
            }
        ],
        api: {
            perPage: 500,
            maxPages: 20
        },
        select2: {
            enabled: true,
            loadIfMissing: true,
            cssUrl: "https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css",
            jsUrl: "https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"
        },
        appearance: {
            mode: "legacy-split",
            gapPx: 10,
            leftWidthPercent: 50,
            rightWidthPercent: 50,
            showStatus: false,
            stackOnSmallScreens: false,
            stackBreakpoint: 900,
            dropdownMaxHeight: 520
        },
        rules: [
            {
                id: "legacy-081-genre",
                enabled: true,
                nameFr: "Genre littéraire — historique 081",
                nameEn: "Literary genre — legacy 081",
                marcTag: "608",
                subfield: "a",
                fallbackLabel: "Genre littéraire",
                placeholderFr: "Sélectionner un genre",
                placeholderEn: "Select a genre",
                select2PlaceholderFr: "Sélectionner un genre",
                sourceMode: "manual",
                categories: [],
                manualValues: HISTORICAL.genre,
                displayMode: "description",
                sortMode: "source",
                deduplicateCaseInsensitive: false
            },
            {
                id: "legacy-082-indexation",
                enabled: true,
                nameFr: "Indexation — historique 082",
                nameEn: "Indexing — legacy 082",
                marcTag: "610",
                subfield: "a",
                fallbackLabel: "Indexation",
                placeholderFr: "Sélectionner une indexation",
                placeholderEn: "Select an indexing value",
                select2PlaceholderFr: "Selectionnez une indexation",
                sourceMode: "manual",
                categories: [],
                manualValues: HISTORICAL.indexation,
                displayMode: "description",
                sortMode: "source",
                deduplicateCaseInsensitive: false
            },
            {
                id: "legacy-083-element",
                enabled: true,
                nameFr: "Élément d'entrée — historique 083",
                nameEn: "Entry element — legacy 083",
                marcTag: "623",
                subfield: "a",
                fallbackLabel: "Elément d'entrée",
                placeholderFr: "Sélectionner un personnage",
                placeholderEn: "Select a character",
                select2PlaceholderFr: "Sélectionner un personnage",
                sourceMode: "manual",
                categories: [],
                manualValues: HISTORICAL.element,
                displayMode: "description",
                sortMode: "source",
                deduplicateCaseInsensitive: false
            },
            {
                id: "legacy-084-categorie",
                enabled: true,
                nameFr: "Catégorie de sujet — historique 084",
                nameEn: "Subject category — legacy 084",
                marcTag: "615",
                subfield: "a",
                fallbackLabel: "catégorie sujet",
                placeholderFr: "Sélectionner une indexation matière",
                placeholderEn: "Select a subject category",
                select2PlaceholderFr: "Sélectionner une indexation matière",
                sourceMode: "manual",
                categories: [],
                manualValues: HISTORICAL.subject,
                displayMode: "description",
                sortMode: "source",
                deduplicateCaseInsensitive: true
            }
        ]
    };

    function normalizeCategory(category) {
        const src = category && typeof category === "object" ? category : {};
        return {
            enabled: src.enabled !== false,
            name: clean(src.name),
            manualName: clean(src.manualName)
        };
    }

    function normalizeRule(rule, index) {
        const src = rule && typeof rule === "object" ? rule : {};
        const sourceMode = ["manual", "authorised", "mixed"].includes(src.sourceMode) ? src.sourceMode : "manual";
        const displayMode = ["description", "opac-description", "value", "value-description"].includes(src.displayMode)
            ? src.displayMode : "description";
        const sortMode = ["source", "label", "value"].includes(src.sortMode) ? src.sortMode : "source";
        return {
            id: clean(src.id) || ("6xx-rule-" + (index + 1)),
            enabled: src.enabled !== false,
            nameFr: clean(src.nameFr) || ("Règle 6XX " + (index + 1)),
            nameEn: clean(src.nameEn) || clean(src.nameFr) || ("6XX rule " + (index + 1)),
            marcTag: clean(src.marcTag).replace(/\D/g, "").slice(0, 3),
            subfield: clean(src.subfield).slice(0, 1),
            fallbackLabel: clean(src.fallbackLabel),
            placeholderFr: clean(src.placeholderFr) || "Sélectionner une valeur",
            placeholderEn: clean(src.placeholderEn) || clean(src.placeholderFr) || "Select a value",
            select2PlaceholderFr: clean(src.select2PlaceholderFr) || clean(src.placeholderFr) || "Sélectionner une valeur",
            sourceMode: sourceMode,
            categories: Array.isArray(src.categories) ? src.categories.map(normalizeCategory) : [],
            manualValues: typeof src.manualValues === "string" ? src.manualValues : valuesToText(src.manualValues),
            displayMode: displayMode,
            sortMode: sortMode,
            deduplicateCaseInsensitive: src.deduplicateCaseInsensitive === true
        };
    }

    function valuesToText(value) {
        if (typeof value === "string") return value;
        if (!Array.isArray(value)) return "";
        return value.map(function (entry) {
            if (typeof entry === "string") return entry;
            if (!entry || typeof entry !== "object") return "";
            const v = clean(entry.value);
            const label = clean(entry.text || entry.label || entry.description);
            if (!v) return "";
            return label && label !== v ? (v + "|" + label) : v;
        }).filter(Boolean).join("\n");
    }

    function migrateLegacyConfig(input, output) {
        if (!input || typeof input !== "object") return output;
        const byId = new Map(output.rules.map(function (rule) { return [rule.id, rule]; }));
        const legacyMap = [
            {
                id: "legacy-081-genre",
                enabledKeys: ["enableGenre", "genreEnabled", "enabledGenre"],
                valuesKeys: ["genreOptions", "genreValues", "optionsGenre"],
                labelKeys: ["genreLabel", "labelGenre"],
                placeholderKeys: ["genrePlaceholder", "placeholderGenre"]
            },
            {
                id: "legacy-082-indexation",
                enabledKeys: ["enableIndexation", "indexationEnabled", "enabledIndexation"],
                valuesKeys: ["indexationOptions", "indexationValues", "optionsIndexation"],
                labelKeys: ["indexationLabel", "labelIndexation"],
                placeholderKeys: ["indexationPlaceholder", "placeholderIndexation"]
            },
            {
                id: "legacy-083-element",
                enabledKeys: ["enableElement", "elementEnabled", "enabledElement", "enableEntryElement"],
                valuesKeys: ["elementOptions", "elementEntryOptions", "entryOptions"],
                labelKeys: ["elementLabel", "elementEntryLabel", "entryLabel"],
                placeholderKeys: ["elementPlaceholder", "entryPlaceholder"]
            },
            {
                id: "legacy-084-categorie",
                enabledKeys: ["enableCategory", "categoryEnabled", "subjectCategoryEnabled", "enableSubjectCategory"],
                valuesKeys: ["categoryOptions", "subjectCategoryOptions", "subjectOptions"],
                labelKeys: ["categoryLabel", "subjectCategoryLabel"],
                placeholderKeys: ["categoryPlaceholder", "subjectCategoryPlaceholder"]
            }
        ];

        function firstDefined(keys) {
            for (let i = 0; i < keys.length; i += 1) {
                if (Object.prototype.hasOwnProperty.call(input, keys[i])) return input[keys[i]];
            }
            return undefined;
        }

        legacyMap.forEach(function (map) {
            const rule = byId.get(map.id);
            if (!rule) return;
            const enabled = firstDefined(map.enabledKeys);
            const values = firstDefined(map.valuesKeys);
            const label = firstDefined(map.labelKeys);
            const placeholder = firstDefined(map.placeholderKeys);
            if (enabled !== undefined) rule.enabled = enabled !== false;
            if (values !== undefined) rule.manualValues = valuesToText(values) || rule.manualValues;
            if (label !== undefined && clean(label)) rule.fallbackLabel = clean(label);
            if (placeholder !== undefined && clean(placeholder)) rule.placeholderFr = clean(placeholder);
        });

        return output;
    }

    function normalizeConfig(config) {
        const result = deepMerge(clone(DEFAULTS), config && typeof config === "object" ? config : {});
        result.enabled = result.enabled !== false;
        result.pages = Array.isArray(result.pages) && result.pages.length ? result.pages : clone(DEFAULTS.pages);
        result.pages = result.pages.map(function (page) {
            return {
                id: clean(page && page.id) || PAGE_ID,
                pathSuffix: clean(page && page.pathSuffix) || PAGE_PATH_SUFFIX,
                enabled: !page || page.enabled !== false
            };
        });
        result.api = deepMerge(clone(DEFAULTS.api), result.api || {});
        result.api.perPage = boundedNumber(result.api.perPage, 20, 1000, DEFAULTS.api.perPage);
        result.api.maxPages = boundedNumber(result.api.maxPages, 1, 100, DEFAULTS.api.maxPages);
        result.select2 = deepMerge(clone(DEFAULTS.select2), result.select2 || {});
        result.select2.enabled = result.select2.enabled !== false;
        result.select2.loadIfMissing = result.select2.loadIfMissing !== false;
        result.appearance = deepMerge(clone(DEFAULTS.appearance), result.appearance || {});
        result.appearance.mode = ["legacy-split", "inline-assistant"].includes(result.appearance.mode)
            ? result.appearance.mode : DEFAULTS.appearance.mode;
        result.appearance.gapPx = boundedNumber(result.appearance.gapPx, 0, 40, DEFAULTS.appearance.gapPx);
        result.appearance.leftWidthPercent = boundedNumber(result.appearance.leftWidthPercent, 20, 80, DEFAULTS.appearance.leftWidthPercent);
        result.appearance.rightWidthPercent = boundedNumber(result.appearance.rightWidthPercent, 20, 80, DEFAULTS.appearance.rightWidthPercent);
        result.appearance.showStatus = result.appearance.showStatus === true;
        result.appearance.stackOnSmallScreens = result.appearance.stackOnSmallScreens === true;
        result.appearance.stackBreakpoint = boundedNumber(result.appearance.stackBreakpoint, 320, 1600, DEFAULTS.appearance.stackBreakpoint);
        result.appearance.dropdownMaxHeight = boundedNumber(result.appearance.dropdownMaxHeight, 160, 900, DEFAULTS.appearance.dropdownMaxHeight);
        result.rules = Array.isArray(result.rules) ? result.rules.map(normalizeRule) : clone(DEFAULTS.rules);
        migrateLegacyConfig(config, result);
        return result;
    }

    function validate(config) {
        const c = normalizeConfig(config);
        const seen = new Set();
        for (let i = 0; i < c.rules.length; i += 1) {
            const rule = c.rules[i];
            if (!rule.enabled) continue;
            if (!/^\d{3}$/.test(rule.marcTag)) {
                return { ok: false, message: "La règle « " + rule.nameFr + " » doit contenir une zone MARC sur 3 chiffres." };
            }
            if (!rule.subfield && !rule.fallbackLabel) {
                return { ok: false, message: "La règle « " + rule.nameFr + " » doit contenir une sous-zone ou un libellé de secours." };
            }
            const key = rule.marcTag + "$" + (rule.subfield || "*");
            if (seen.has(key)) {
                return { ok: false, message: "Deux règles actives ciblent " + key + ". Fusionnez leurs sources dans une seule règle." };
            }
            seen.add(key);
            if (rule.sourceMode === "authorised" || rule.sourceMode === "mixed") {
                const activeCategories = rule.categories.filter(function (category) {
                    return category.enabled !== false && clean(category.manualName || category.name);
                });
                if (!activeCategories.length && rule.sourceMode === "authorised") {
                    return { ok: false, message: "La règle « " + rule.nameFr + " » utilise les valeurs autorisées mais aucune catégorie Koha n'est sélectionnée." };
                }
            }
        }
        return { ok: true };
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        return (document.documentElement.lang || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function ensureAuthorisedValuesService() {
        if (window.PMKAuthorisedValuesService) return window.PMKAuthorisedValuesService;

        const categoryCache = { value: null, promise: null };
        const valueCache = new Map();

        async function fetchPaged(baseUrl, orderBy, perPage, maxPages) {
            const rows = [];
            for (let page = 1; page <= maxPages; page += 1) {
                const url = new URL(baseUrl, window.location.origin);
                url.searchParams.set("_page", String(page));
                url.searchParams.set("_per_page", String(perPage));
                if (orderBy) url.searchParams.set("_order_by", orderBy);

                const response = await fetch(url.toString(), {
                    credentials: "same-origin",
                    headers: { "Accept": "application/json" }
                });
                if (!response.ok) {
                    const error = new Error("Koha API " + response.status + " — " + url.pathname);
                    error.status = response.status;
                    throw error;
                }
                const batch = await response.json();
                if (!Array.isArray(batch)) return rows;
                rows.push.apply(rows, batch);
                if (batch.length < perPage) break;
            }
            return rows;
        }

        async function listCategories(options) {
            const opts = options || {};
            if (!opts.force && Array.isArray(categoryCache.value)) return clone(categoryCache.value);
            if (!opts.force && categoryCache.promise) return categoryCache.promise.then(clone);

            const perPage = Math.max(20, Math.min(1000, Number(opts.perPage) || 500));
            const maxPages = Math.max(1, Math.min(100, Number(opts.maxPages) || 20));
            categoryCache.promise = fetchPaged(
                "/api/v1/authorised_value_categories",
                "category_name",
                perPage,
                maxPages
            ).then(function (rows) {
                const result = rows
                    .map(function (row) { return clean(row && row.category_name); })
                    .filter(Boolean)
                    .filter(function (value, index, arr) { return arr.indexOf(value) === index; })
                    .sort(function (a, b) { return a.localeCompare(b, language() === "en" ? "en" : "fr"); });
                categoryCache.value = result;
                categoryCache.promise = null;
                return clone(result);
            }).catch(function (error) {
                categoryCache.promise = null;
                throw error;
            });
            return categoryCache.promise.then(clone);
        }

        async function listValues(categoryName, options) {
            const category = clean(categoryName);
            if (!category) return [];
            const opts = options || {};
            if (!opts.force && valueCache.has(category)) {
                const cached = valueCache.get(category);
                if (Array.isArray(cached)) return clone(cached);
                return cached.then(clone);
            }

            const perPage = Math.max(20, Math.min(1000, Number(opts.perPage) || 500));
            const maxPages = Math.max(1, Math.min(100, Number(opts.maxPages) || 20));
            const promise = fetchPaged(
                "/api/v1/authorised_value_categories/" + encodeURIComponent(category) + "/authorised_values",
                "description",
                perPage,
                maxPages
            ).then(function (rows) {
                valueCache.set(category, rows);
                return clone(rows);
            }).catch(function (error) {
                valueCache.delete(category);
                throw error;
            });
            valueCache.set(category, promise);
            return promise.then(clone);
        }

        window.PMKAuthorisedValuesService = {
            listCategories: listCategories,
            listValues: listValues,
            clear: function () {
                categoryCache.value = null;
                categoryCache.promise = null;
                valueCache.clear();
            }
        };

        return window.PMKAuthorisedValuesService;
    }

    function categoryOptionsLoader() {
        const service = ensureAuthorisedValuesService();
        const cfg = currentConfig || DEFAULTS;
        return service.listCategories(cfg.api).then(function (names) {
            return [
                { value: "", label: { fr: "— Choisir une catégorie Koha —", en: "— Choose a Koha category —" } }
            ].concat(names.map(function (name) {
                return { value: name, label: { fr: name, en: name } };
            }));
        });
    }

    function ruleFromPath(root, path) {
        if (!root || !Array.isArray(root.rules) || !Array.isArray(path)) return null;
        const pos = path.indexOf("rules");
        if (pos === -1 || path.length <= pos + 1) return null;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? root.rules[index] : null;
    }

    function showCategories(root, path) {
        const rule = ruleFromPath(root, path);
        return !!rule && (rule.sourceMode === "authorised" || rule.sourceMode === "mixed");
    }

    function showManual(root, path) {
        const rule = ruleFromPath(root, path);
        return !!rule && (rule.sourceMode === "manual" || rule.sourceMode === "mixed");
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 3,
            name: {
                fr: "Aide à l’indexation 6XX",
                en: "6XX indexing helpers"
            },
            description: {
                fr: "Guide la saisie des valeurs de notices et d’autorités sans empêcher la création, afin de limiter les erreurs de frappe et d’harmoniser l’indexation.",
                en: "Guides entry of bibliographic and authority values without preventing creation, reducing typos and improving indexing consistency."
            },
            category: {
                fr: "Catalogage / indexation",
                en: "Cataloguing / indexing"
            },
            supportedPages: [PAGE_ID],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULTS),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "general",
                    label: { fr: "Fonctionnement", en: "Behavior" },
                    description: {
                        fr: "Le champ Koha reste toujours le vrai champ enregistré. La liste PMK est seulement une aide de saisie : choisir une suggestion écrit dans le champ Koha sans le remplacer ni le désactiver.",
                        en: "The Koha field always remains the real submitted field. The PMK list is only an input helper: choosing a suggestion writes into the Koha field without replacing or disabling it."
                    },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer l’aide à l’indexation 6XX", en: "Enable 6XX indexing helpers" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Règles et listes de suggestions", en: "Rules and suggestion lists" },
                    description: {
                        fr: "Les quatre règles historiques sont fournies par défaut. Vous pouvez les modifier ou ajouter d’autres zones 6XX. Pour chaque règle : liste manuelle, valeurs autorisées Koha, ou mode mixte.",
                        en: "The four historical rules are supplied by default. You can edit them or add other 6XX tags. Each rule can use a manual list, Koha authorised values, or mixed mode."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Aides à la saisie", en: "Input helpers" },
                            addLabel: { fr: "Ajouter une règle 6XX", en: "Add a 6XX rule" },
                            reorder: true,
                            newItem: newRule,
                            itemTitle: function (item, index, lang) {
                                const title = lang === "en" ? clean(item && item.nameEn) : clean(item && item.nameFr);
                                const marc = clean(item && item.marcTag) + (clean(item && item.subfield) ? ("$" + clean(item.subfield)) : "");
                                return (title || ("Règle " + (index + 1))) + (marc ? (" — " + marc) : "");
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "nameFr", type: "text", label: { fr: "Nom — français", en: "Name — French" } },
                                { key: "nameEn", type: "text", label: { fr: "Nom — anglais", en: "Name — English" } },
                                {
                                    key: "marcTag",
                                    type: "text",
                                    label: { fr: "Zone MARC", en: "MARC tag" },
                                    help: { fr: "Exemple : 608, 610, 615, 623.", en: "Example: 608, 610, 615, 623." }
                                },
                                {
                                    key: "subfield",
                                    type: "text",
                                    label: { fr: "Sous-zone", en: "Subfield" },
                                    help: { fr: "Exemple : a. Le ciblage MARC est prioritaire sur le libellé.", en: "Example: a. MARC targeting takes priority over the label." }
                                },
                                {
                                    key: "fallbackLabel",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Libellé de secours", en: "Fallback label" },
                                    help: {
                                        fr: "Utilisé seulement si le champ n’est pas retrouvé par zone/sous-zone. Utile pour reprendre exactement une grille historique.",
                                        en: "Used only when the field cannot be found by tag/subfield. Useful for exact legacy-framework compatibility."
                                    }
                                },
                                { key: "placeholderFr", type: "text", label: { fr: "Texte d’aide — français", en: "Placeholder — French" } },
                                { key: "placeholderEn", type: "text", label: { fr: "Texte d’aide — anglais", en: "Placeholder — English" } },
                                { key: "select2PlaceholderFr", type: "text", advanced: true, label: { fr: "Placeholder Select2 historique", en: "Legacy Select2 placeholder" }, help: { fr: "Permet de conserver exactement le texte affiché par les anciens scripts.", en: "Keeps the exact text shown by legacy scripts." } },
                                {
                                    key: "sourceMode",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Source des suggestions", en: "Suggestion source" },
                                    options: [
                                        { value: "manual", label: { fr: "Liste manuelle", en: "Manual list" } },
                                        { value: "authorised", label: { fr: "Valeurs autorisées Koha", en: "Koha authorised values" } },
                                        { value: "mixed", label: { fr: "Valeurs autorisées Koha + compléments manuels", en: "Koha authorised values + manual additions" } }
                                    ]
                                },
                                {
                                    key: "categories",
                                    type: "repeater",
                                    when: showCategories,
                                    label: { fr: "Catégories de valeurs autorisées", en: "Authorised-value categories" },
                                    addLabel: { fr: "Ajouter une catégorie Koha", en: "Add a Koha category" },
                                    reorder: true,
                                    newItem: newCategory,
                                    itemTitle: function (item, index) {
                                        return clean(item && (item.manualName || item.name)) || ("Catégorie " + (index + 1));
                                    },
                                    fields: [
                                        { key: "enabled", type: "boolean", label: { fr: "Catégorie active", en: "Category enabled" } },
                                        {
                                            key: "name",
                                            type: "select",
                                            label: { fr: "Catégorie Koha détectée", en: "Detected Koha category" },
                                            options: [
                                                { value: "", label: { fr: "Chargement des catégories…", en: "Loading categories…" } }
                                            ],
                                            loadOptions: categoryOptionsLoader,
                                            help: {
                                                fr: "La liste est chargée depuis l’API REST Koha avec la session courante. Il faut le droit catalogue. Si la catégorie n’apparaît pas, utilisez le code manuel ci-dessous.",
                                                en: "The list is loaded from the Koha REST API using the current session. Catalogue permission is required. If the category does not appear, use the manual code below."
                                            }
                                        },
                                        {
                                            key: "manualName",
                                            type: "text",
                                            advanced: true,
                                            label: { fr: "Code de catégorie manuel — optionnel", en: "Manual category code — optional" },
                                            help: {
                                                fr: "Prioritaire sur la sélection ci-dessus. Utile si la liste des catégories ne se charge pas ou pour saisir directement un code connu. Le chargement des valeurs nécessite toujours l’API Koha.",
                                                en: "Takes priority over the selection above. Useful if the category list cannot be loaded or to enter a known code directly. Loading the values still requires the Koha API."
                                            }
                                        }
                                    ]
                                },
                                {
                                    key: "manualValues",
                                    type: "textarea",
                                    rows: 10,
                                    when: showManual,
                                    label: { fr: "Valeurs manuelles", en: "Manual values" },
                                    help: {
                                        fr: "Une valeur par ligne. Format : valeur|libellé. Si le libellé est omis, la valeur sert aussi de libellé. En mode mixte, une valeur manuelle identique remplace le libellé provenant de Koha.",
                                        en: "One value per line. Format: value|label. If the label is omitted, the value is also used as label. In mixed mode, an identical manual value overrides the label coming from Koha."
                                    }
                                },
                                {
                                    key: "displayMode",
                                    type: "select",
                                    when: showCategories,
                                    label: { fr: "Libellé des valeurs Koha", en: "Koha value labels" },
                                    options: [
                                        { value: "description", label: { fr: "Description professionnelle", en: "Staff description" } },
                                        { value: "opac-description", label: { fr: "Description OPAC", en: "OPAC description" } },
                                        { value: "value", label: { fr: "Code uniquement", en: "Value only" } },
                                        { value: "value-description", label: { fr: "Code — description", en: "Value — description" } }
                                    ]
                                },
                                {
                                    key: "sortMode",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Tri de la liste", en: "List sorting" },
                                    options: [
                                        { value: "source", label: { fr: "Conserver l’ordre des sources", en: "Keep source order" } },
                                        { value: "label", label: { fr: "Trier par libellé", en: "Sort by label" } },
                                        { value: "value", label: { fr: "Trier par valeur", en: "Sort by value" } }
                                    ]
                                },
                                {
                                    key: "deduplicateCaseInsensitive",
                                    type: "boolean",
                                    advanced: true,
                                    label: { fr: "Dédupliquer sans tenir compte des majuscules/minuscules", en: "Deduplicate ignoring letter case" }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "select2",
                    label: { fr: "Affichage des listes", en: "List display" },
                    fields: [
                        { key: "select2.enabled", type: "boolean", label: { fr: "Utiliser Select2 lorsqu’il est disponible", en: "Use Select2 when available" } },
                        { key: "select2.loadIfMissing", type: "boolean", label: { fr: "Charger Select2 s’il manque", en: "Load Select2 if missing" } },
                        { key: "select2.cssUrl", type: "text", advanced: true, label: { fr: "URL CSS Select2", en: "Select2 CSS URL" } },
                        { key: "select2.jsUrl", type: "text", advanced: true, label: { fr: "URL JavaScript Select2", en: "Select2 JavaScript URL" } },
                        {
                            key: "appearance.mode",
                            type: "select",
                            label: { fr: "Présentation des champs", en: "Field presentation" },
                            options: [
                                { value: "legacy-split", label: { fr: "Présentation initiale — 50/50", en: "Original layout — 50/50" } },
                                { value: "inline-assistant", label: { fr: "Assistant à droite du champ natif", en: "Assistant next to native field" } }
                            ],
                            help: {
                                fr: "Le mode historique reproduit la présentation des anciens 081/082/083/084 : valeur courante à gauche et Select2 à droite.",
                                en: "Legacy mode reproduces the former 081/082/083/084 layout: current value on the left and Select2 on the right."
                            }
                        },
                        { key: "appearance.gapPx", type: "number", min: 0, max: 40, step: 1, label: { fr: "Écart entre les deux champs (px)", en: "Gap between fields (px)" } },
                        { key: "appearance.leftWidthPercent", type: "number", min: 20, max: 80, step: 1, label: { fr: "Largeur champ gauche (%)", en: "Left field width (%)" } },
                        { key: "appearance.rightWidthPercent", type: "number", min: 20, max: 80, step: 1, label: { fr: "Largeur liste droite (%)", en: "Right list width (%)" } },
                        { key: "appearance.showStatus", type: "boolean", advanced: true, label: { fr: "Afficher le compteur de suggestions", en: "Show suggestion count" } },
                        { key: "appearance.stackOnSmallScreens", type: "boolean", advanced: true, label: { fr: "Empiler les champs sur petit écran", en: "Stack fields on small screens" } },
                        { key: "appearance.stackBreakpoint", type: "number", min: 320, max: 1600, step: 10, advanced: true, label: { fr: "Seuil d’empilement (px)", en: "Stacking breakpoint (px)" } },
                        { key: "appearance.dropdownMaxHeight", type: "number", min: 160, max: 900, step: 10, advanced: true, label: { fr: "Hauteur maximale du menu Select2 (px)", en: "Select2 dropdown maximum height (px)" } }
                    ]
                },
                {
                    type: "section",
                    id: "api",
                    label: { fr: "API Koha", en: "Koha API" },
                    description: {
                        fr: "Les catégories et leurs valeurs sont lues à la demande depuis Koha. Aucune copie des valeurs autorisées n’est enregistrée dans PMK.",
                        en: "Categories and their values are read on demand from Koha. PMK does not store a duplicate copy of authorised values."
                    },
                    fields: [
                        { key: "api.perPage", type: "number", min: 20, max: 1000, step: 10, advanced: true, label: { fr: "Valeurs par page API", en: "API values per page" } },
                        { key: "api.maxPages", type: "number", min: 1, max: 100, step: 1, advanced: true, label: { fr: "Nombre maximal de pages API", en: "Maximum API pages" } }
                    ]
                },
                {
                    type: "section",
                    id: "pages",
                    label: { fr: "Page active", en: "Active page" },
                    fields: [
                        {
                            key: "pages",
                            type: "repeater",
                            canAdd: function () { return false; },
                            removable: false,
                            reorder: false,
                            label: { fr: "Pages", en: "Pages" },
                            itemTitle: function () { return "cataloguing/addbiblio.pl"; },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Activer sur addbiblio.pl", en: "Enable on addbiblio.pl" } },
                                { key: "id", type: "readonly", advanced: true, label: { fr: "Identifiant fonctionnel", en: "Functional identifier" } },
                                { key: "pathSuffix", type: "readonly", label: { fr: "Chemin Koha", en: "Koha path" } }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && (context.sectionId || context.section) ? (context.sectionId || context.section) : "rules";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]')
                    || main.querySelector('[data-pmk-section-id="rules"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        });

        return true;
    }

    let currentConfig = normalizeConfig(DEFAULTS);
    let readyResolve;
    let readyResolved = false;
    const ready = new Promise(function (resolve) { readyResolve = resolve; });

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULTS);
        try {
            window.dispatchEvent(new CustomEvent("pmk6xx:config-changed", { detail: clone(currentConfig) }));
        } catch (_) {}
        return currentConfig;
    }

    function resolveReady(config) {
        if (readyResolved) return;
        readyResolved = true;
        readyResolve(config);
    }

    function mountContextButton() {
        if (!window.location.pathname.endsWith(PAGE_PATH_SUFFIX)) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = document.querySelector("#tab6XX-tab") || document.querySelector("h1");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: "cataloging-6xx",
                context: { page: PAGE_ID, section: "rules", sectionId: "rules" }
            });
        } catch (_) {}
    }

    function loadFromCore() {
        ensureAuthorisedValuesService();
        if (!registerModule()) {
            const applied = applyConfig(DEFAULTS);
            resolveReady(applied);
            return Promise.resolve(applied);
        }

        const getPromise = typeof window.PMKConfig.getConfig === "function"
            ? Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).catch(function () { return DEFAULTS; })
            : Promise.resolve(DEFAULTS);

        return getPromise.then(function (config) {
            const applied = applyConfig(config || DEFAULTS);
            resolveReady(applied);

            if (typeof window.PMKConfig.subscribe === "function") {
                try {
                    window.PMKConfig.subscribe(MODULE_ID, function (next) {
                        applyConfig(next || DEFAULTS);
                    });
                } catch (_) {}
            }

            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", mountContextButton, { once: true });
            } else {
                mountContextButton();
            }

            return applied;
        });
    }

    function bootstrapConfig() {
        if (window.PMKConfig) {
            loadFromCore();
            return;
        }
        let attempts = 0;
        const timer = window.setInterval(function () {
            attempts += 1;
            if (window.PMKConfig) {
                window.clearInterval(timer);
                loadFromCore();
                return;
            }
            if (attempts >= 10) {
                window.clearInterval(timer);
                const applied = applyConfig(DEFAULTS);
                resolveReady(applied);
                window.setTimeout(function retry() {
                    if (window.PMKConfig) loadFromCore();
                    else window.setTimeout(retry, 1000);
                }, 1000);
            }
        }, 100);
    }

    window.PMK6XXConfig = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULTS),
        ready: ready,
        get: function () { return currentConfig; },
        normalize: normalizeConfig,
        apply: applyConfig,
        authorisedValues: ensureAuthorisedValuesService()
    };

    bootstrapConfig();
})();

(function () {
    "use strict";

    if (window.__PMK6XXRuntimeLoaded) return;
    window.__PMK6XXRuntimeLoaded = true;

    const PAGE_PATH_SUFFIX = "/addbiblio.pl";
    const RUNTIME_APPEARANCE_DEFAULTS = Object.freeze({
        gapPx: 10,
        leftWidthPercent: 50,
        rightWidthPercent: 50,
        showStatus: false,
        stackOnSmallScreens: false,
        stackBreakpoint: 900,
        dropdownMaxHeight: 520
    });
    const KOHA_MUTATOR_NAMES = ["CloneField", "CloneSubfield", "UnCloneField"];
    let runtimeStarted = false;
    let mutationObserver = null;
    let scanScheduled = false;
    let select2Promise = null;
    const optionsCache = new Map();

    function cfg() {
        return window.PMK6XXConfig && typeof window.PMK6XXConfig.get === "function"
            ? window.PMK6XXConfig.get()
            : null;
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        return (document.documentElement.lang || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function t(fr, en) {
        return language() === "en" ? en : fr;
    }

    function normalizeText(value) {
        return clean(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .replace(/\s+/g, " ");
    }

    function pageEnabled(config) {
        if (!config || config.enabled === false) return false;
        if (!window.location.pathname.endsWith(PAGE_PATH_SUFFIX)) return false;
        const pages = Array.isArray(config.pages) ? config.pages : [];
        const page = pages.find(function (entry) {
            return entry && clean(entry.pathSuffix || PAGE_PATH_SUFFIX) === PAGE_PATH_SUFFIX;
        });
        return !page || page.enabled !== false;
    }

    function injectStyles(config) {
        let style = document.getElementById("pmk6xx-styles");
        if (!style) {
            style = document.createElement("style");
            style.id = "pmk6xx-styles";
            document.head.appendChild(style);
        }

        const appearance = (config && config.appearance) || RUNTIME_APPEARANCE_DEFAULTS;
        const gapNumber = Number(appearance.gapPx);
        const leftNumber = Number(appearance.leftWidthPercent);
        const rightNumber = Number(appearance.rightWidthPercent);
        const breakpointNumber = Number(appearance.stackBreakpoint);
        const maxHeightNumber = Number(appearance.dropdownMaxHeight);
        const gap = Math.max(0, Math.min(40, Number.isFinite(gapNumber) ? gapNumber : 10));
        const left = Math.max(20, Math.min(80, Number.isFinite(leftNumber) ? leftNumber : 50));
        const right = Math.max(20, Math.min(80, Number.isFinite(rightNumber) ? rightNumber : 50));
        const breakpoint = Math.max(320, Math.min(1600, Number.isFinite(breakpointNumber) ? breakpointNumber : 900));
        const maxHeight = Math.max(160, Math.min(900, Number.isFinite(maxHeightNumber) ? maxHeightNumber : 520));
        const showStatus = appearance.showStatus === true;
        const stack = appearance.stackOnSmallScreens === true;

        style.textContent = `
.pmk6xx-assistant {
    box-sizing: border-box;
}
.pmk6xx-legacy-row {
    display: flex;
    gap: ${gap}px;
    align-items: center;
    width: 100%;
}
.pmk6xx-legacy-row > .pmk6xx-legacy-display {
    box-sizing: border-box;
    width: ${left}%;
    flex: 0 1 ${left}%;
    min-width: 0;
}
.pmk6xx-legacy-row > .pmk6xx-select:not(.select2-hidden-accessible) {
    box-sizing: border-box;
    width: ${right}%;
    flex: 0 1 ${right}%;
    min-width: 0;
}
/* Sécurise Select2 même si Koha fournit le JS sans sa règle CSS de masquage. */
.pmk6xx-assistant .pmk6xx-select.select2-hidden-accessible {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    white-space: nowrap !important;
    border: 0 !important;
}
/* Le Select2 déjà créé par Koha pour le vrai champ est conservé, mais masqué
   tant que le mode historique PMK affiche sa propre représentation. */
.pmk6xx-native-select2-hidden {
    display: none !important;
}
.pmk6xx-legacy-row > .select2-container {
    box-sizing: border-box;
    width: ${right}% !important;
    flex: 0 1 ${right}%;
    min-width: 0;
}
.pmk6xx-inline-assistant {
    display: inline-flex;
    align-items: center;
    gap: .35rem;
    width: min(360px, 46%);
    min-width: 220px;
    margin-left: .45rem;
    vertical-align: top;
}
.pmk6xx-inline-assistant select {
    width: 100%;
    max-width: 100%;
}
.pmk6xx-inline-assistant .select2-container {
    width: 100% !important;
    min-width: 0;
}
.pmk6xx-native-source {
    display: none !important;
}
.pmk6xx-assistant.pmk6xx-loading {
    opacity: .75;
}
.pmk6xx-assistant.pmk6xx-error select {
    border-color: #b94a48;
}
.pmk6xx-assistant .pmk6xx-status {
    ${showStatus ? "" : "display: none !important;"}
    flex: 0 0 auto;
    font-size: .78rem;
    color: #6c757d;
}
.select2-container--open {
    z-index: 99999;
}
.select2-container--open .select2-dropdown {
    z-index: 99999;
}
.select2-results__options {
    max-height: min(70vh, ${maxHeight}px) !important;
    overflow-y: auto !important;
}
${stack ? `
@media (max-width: ${breakpoint}px) {
    .pmk6xx-legacy-row {
        display: flex;
        flex-direction: column;
        align-items: stretch;
    }
    .pmk6xx-legacy-row > .pmk6xx-legacy-display,
    .pmk6xx-legacy-row > .pmk6xx-select,
    .pmk6xx-legacy-row > .select2-container {
        width: 100% !important;
        flex-basis: auto;
    }
}` : ""}
`;
    }

    function parseManualValues(text) {
        return String(text || "")
            .split(/\r?\n/)
            .map(function (line) { return line.trim(); })
            .filter(function (line) { return line && !line.startsWith("#"); })
            .map(function (line) {
                const pos = line.indexOf("|");
                const value = clean(pos === -1 ? line : line.slice(0, pos));
                const label = clean(pos === -1 ? line : line.slice(pos + 1)) || value;
                return value ? { value: value, label: label, source: "manual" } : null;
            })
            .filter(Boolean);
    }

    function legacySelect2Placeholder(rule) {
        return clean(rule && rule.select2PlaceholderFr)
            || clean(rule && rule.placeholderFr)
            || "Sélectionner une valeur";
    }

    function labelForKohaValue(row, mode) {
        const value = clean(row && row.value);
        const description = clean(row && row.description);
        const opac = clean(row && row.opac_description);
        if (mode === "value") return value;
        if (mode === "opac-description") return opac || description || value;
        if (mode === "value-description") {
            const label = description || opac || value;
            return label && label !== value ? (value + " — " + label) : value;
        }
        return description || opac || value;
    }

    function categoryName(entry) {
        return clean(entry && (entry.manualName || entry.name));
    }

    function optionKey(value, caseInsensitive) {
        const cleaned = clean(value);
        return caseInsensitive ? normalizeText(cleaned) : cleaned;
    }

    function mergeOptions(apiOptions, manualOptions, rule) {
        const map = new Map();
        const order = [];
        function add(option, override) {
            if (!option || !clean(option.value)) return;
            const key = optionKey(option.value, rule.deduplicateCaseInsensitive === true);
            if (!key) return;
            const variant = { value: clean(option.value), label: clean(option.label) || clean(option.value), source: option.source || "unknown", category: option.category || "" };
            if (!map.has(key)) {
                order.push(key);
                map.set(key, Object.assign({}, option, { variants: [variant], sources: [variant.source + (variant.category ? ":" + variant.category : "")] }));
                return;
            }
            const current = map.get(key);
            if (!current.variants.some(item => item.value === variant.value && item.label === variant.label && item.source === variant.source && item.category === variant.category)) current.variants.push(variant);
            const source = variant.source + (variant.category ? ":" + variant.category : "");
            if (!current.sources.includes(source)) current.sources.push(source);
            if (override) Object.assign(current, option, { variants: current.variants, sources: current.sources });
        }
        (apiOptions || []).forEach(function (option) { add(option, false); });
        (manualOptions || []).forEach(function (option) { add(option, true); });

        let result = order.map(function (key) { return map.get(key); }).filter(Boolean);
        if (rule.sortMode === "label") {
            result = result.slice().sort(function (a, b) {
                return clean(a.label).localeCompare(clean(b.label), document.documentElement.lang || "fr", { sensitivity: "base" });
            });
        } else if (rule.sortMode === "value") {
            result = result.slice().sort(function (a, b) {
                return clean(a.value).localeCompare(clean(b.value), document.documentElement.lang || "fr", { sensitivity: "base" });
            });
        }
        return result;
    }

    function decorateSuggestionOption(option, entry) {
        const sources = Array.isArray(entry.sources) ? entry.sources : [entry.source || "unknown"];
        const variants = Array.isArray(entry.variants) ? entry.variants : [];
        option.dataset.pmk6xxSources = sources.join(",");
        option.dataset.pmk6xxVariantCount = String(variants.length || 1);
        const sourceText = sources.map(source => source === "manual" ? t("liste manuelle", "manual list") : source.replace(/^koha:/, t("Koha : ", "Koha: "))).join(" + ");
        const variantText = variants.length > 1 ? t(" · Variantes conservées : ", " · Preserved variants: ") + variants.map(item => `« ${item.value}${item.label !== item.value ? " — " + item.label : ""} »`).join(", ") : "";
        option.title = t("Origine : ", "Source: ") + sourceText + variantText;
    }

    function suggestionSummary(options) {
        const duplicates = (options || []).filter(entry => (entry.variants || []).length > 1).length;
        return (options || []).length + t(" suggestion(s)", " suggestion(s)") + (duplicates ? t(` · ${duplicates} doublon(s) avec variantes conservées`, ` · ${duplicates} duplicate(s) with preserved variants`) : "");
    }

    async function optionsForRule(rule, config) {
        const fingerprint = JSON.stringify({
            id: rule.id,
            sourceMode: rule.sourceMode,
            categories: (rule.categories || []).map(function (entry) { return [entry.enabled !== false, categoryName(entry)]; }),
            manualValues: rule.manualValues,
            displayMode: rule.displayMode,
            sortMode: rule.sortMode,
            deduplicateCaseInsensitive: rule.deduplicateCaseInsensitive
        });
        if (optionsCache.has(fingerprint)) return optionsCache.get(fingerprint);

        const promise = (async function () {
            const manual = rule.sourceMode === "authorised"
                ? []
                : parseManualValues(rule.manualValues);
            let apiOptions = [];

            if (rule.sourceMode === "authorised" || rule.sourceMode === "mixed") {
                const service = window.PMK6XXConfig && window.PMK6XXConfig.authorisedValues;
                if (!service || typeof service.listValues !== "function") {
                    if (rule.sourceMode === "authorised") throw new Error("Service des valeurs autorisées indisponible.");
                } else {
                    const categories = (rule.categories || [])
                        .filter(function (entry) { return entry && entry.enabled !== false && categoryName(entry); })
                        .map(categoryName);

                    for (let i = 0; i < categories.length; i += 1) {
                        try {
                            const rows = await service.listValues(categories[i], config.api || {});
                            rows.forEach(function (row) {
                                const value = clean(row && row.value);
                                if (!value) return;
                                apiOptions.push({
                                    value: value,
                                    label: labelForKohaValue(row, rule.displayMode),
                                    source: "koha",
                                    category: categories[i]
                                });
                            });
                        } catch (error) {
                            if (rule.sourceMode === "authorised") throw error;
                            console.warn("[PMK 6XX] Catégorie Koha indisponible en mode mixte :", categories[i], error);
                        }
                    }
                }
            }

            return mergeOptions(apiOptions, manual, rule);
        })();

        optionsCache.set(fingerprint, promise);
        try {
            const result = await promise;
            optionsCache.set(fingerprint, Promise.resolve(result));
            return result;
        } catch (error) {
            optionsCache.delete(fingerprint);
            throw error;
        }
    }

    function isUsableMarcControl(node) {
        if (!(node instanceof HTMLElement)) return false;
        if (node.closest(".pmk6xx-assistant")) return false;
        if (node.getAttribute("data-pmk6xx-display-only") === "1") return false;
        if (node.tagName === "INPUT" && String(node.type || "").toLowerCase() === "hidden") return false;
        return true;
    }

    function findFieldsByMarc(rule) {
        const tag = clean(rule.marcTag);
        const subfield = clean(rule.subfield);
        // Sans sous-zone précise, on laisse volontairement le libellé de secours
        // cibler le bon contrôle au lieu d'appliquer la règle à toutes les sous-zones.
        if (!/^\d{3}$/.test(tag) || !subfield) return [];
        const prefix = 'tag_' + tag + '_subfield_' + subfield + '_';
        const nodes = Array.from(document.querySelectorAll('input[name^="' + prefix + '"], textarea[name^="' + prefix + '"], select[name^="' + prefix + '"]'));
        return nodes.filter(isUsableMarcControl);
    }

    function findFieldsByLabel(rule) {
        const wanted = normalizeText(rule.fallbackLabel);
        if (!wanted) return [];
        const tag = clean(rule.marcTag);
        const result = [];
        document.querySelectorAll("label.labelsubfield").forEach(function (label) {
            if (normalizeText(label.textContent || "") !== wanted) return;

            // Si le conteneur de zone est identifiable, on reste dans la zone MARC demandée.
            if (/^\d{3}$/.test(tag)) {
                const tagContainer = label.closest('.tag[id^="tag_' + tag + '_"]');
                if (!tagContainer) return;
            }

            const id = clean(label.getAttribute("for"));
            const field = id ? document.getElementById(id) : null;
            if (field && isUsableMarcControl(field) && !result.includes(field)) result.push(field);
        });
        return result;
    }

    function findFields(rule) {
        const byMarc = findFieldsByMarc(rule);
        return byMarc.length ? byMarc : findFieldsByLabel(rule);
    }

    function dispatchNative(field) {
        // Les événements natifs bullent jusqu'aux gestionnaires jQuery de Koha ;
        // inutile de les déclencher une seconde fois via jQuery.
        try { field.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
        try { field.dispatchEvent(new Event("change", { bubbles: true })); } catch (_) {}
    }

    function destroySelect2(select) {
        if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.select2) return;
        try {
            if (window.jQuery(select).hasClass("select2-hidden-accessible")) window.jQuery(select).select2("destroy");
        } catch (_) {}
    }

    function select2ContainerFor(field) {
        if (!field || field.tagName !== "SELECT") return null;
        if (window.jQuery) {
            try {
                const instance = window.jQuery(field).data("select2");
                if (instance && instance.$container && instance.$container[0]) return instance.$container[0];
            } catch (_) {}
        }
        const next = field.nextElementSibling;
        return next && next.classList && next.classList.contains("select2-container") ? next : null;
    }

    function hideNativeSelect2(field) {
        const container = select2ContainerFor(field);
        if (!container) return null;
        container.classList.add("pmk6xx-native-select2-hidden");
        try { field.__pmk6xxNativeSelect2Container = container; } catch (_) {}
        return container;
    }

    function stripSelect2Artifacts(field) {
        if (!field) return;
        field.classList.remove("select2-hidden-accessible");
        field.removeAttribute("data-select2-id");
        field.removeAttribute("aria-hidden");
        if (field.getAttribute("tabindex") === "-1") field.removeAttribute("tabindex");
    }

    /*
     * En mode historique PMK, le vrai contrôle Koha est uniquement une source
     * de données/soumission. Il ne doit plus avoir sa propre représentation
     * Select2 visible. On suspend donc explicitement son Select2 au lieu de
     * simplement tenter de masquer son conteneur.
     */
    function suspendNativeSelect2(field) {
        if (!field || field.tagName !== "SELECT") return;

        if (!field.hasAttribute("data-pmk6xx-had-select2-class")) {
            field.setAttribute(
                "data-pmk6xx-had-select2-class",
                field.classList.contains("select2") ? "1" : "0"
            );
        }

        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
            try {
                const jq = window.jQuery(field);
                if (jq.data("select2") || jq.hasClass("select2-hidden-accessible")) {
                    jq.select2("destroy");
                }
            } catch (_) {}
        }

        // Retire aussi un éventuel conteneur Select2 devenu orphelin.
        let next = field.nextElementSibling;
        while (next && next.classList && next.classList.contains("select2-container")) {
            const following = next.nextElementSibling;
            next.remove();
            next = following;
        }

        // Empêche l'initialisation automatique tardive de Koha sur ce select.
        field.classList.remove("select2");
        stripSelect2Artifacts(field);
        field.setAttribute("data-pmk6xx-native-select2-suspended", "1");
    }

    function restoreNativeSelect2(field) {
        if (!field) return null;

        let container = field.__pmk6xxNativeSelect2Container || null;
        if (!container || !container.isConnected) container = select2ContainerFor(field);
        if (container && container.classList) {
            container.classList.remove("pmk6xx-native-select2-hidden");
        }

        if (field.getAttribute("data-pmk6xx-had-select2-class") === "1") {
            field.classList.add("select2");
        }
        field.removeAttribute("data-pmk6xx-had-select2-class");
        field.removeAttribute("data-pmk6xx-native-select2-suspended");

        try { delete field.__pmk6xxNativeSelect2Container; } catch (_) {
            field.__pmk6xxNativeSelect2Container = null;
        }
        return container || null;
    }

    function reinitNativeSelect2(field) {
        if (!field || field.tagName !== "SELECT") return;
        if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.select2) return;

        try {
            if (window.Select2Utils && typeof window.Select2Utils.initSelect2 === "function") {
                window.Select2Utils.initSelect2(window.jQuery(field));
            } else if (field.classList.contains("select2")) {
                window.jQuery(field).select2();
            }
        } catch (_) {}
    }

    /*
     * Garde-fou contre une initialisation Select2 tardive de Koha après le
     * montage PMK. Dans une ligne historique, seuls le champ source caché,
     * l'input de présentation, la liste PMK et SON conteneur Select2 sont admis.
     */
    function pruneLegacyHost(host) {
        if (!host || !host.isConnected) return;

        const source = host.__pmk6xxSource || host.querySelector(".pmk6xx-native-source");
        const helper = host.querySelector('select[data-pmk6xx-helper="1"]');

        if (source && source.tagName === "SELECT") {
            suspendNativeSelect2(source);
        }

        let ownedContainer = null;
        if (helper) {
            ownedContainer = select2ContainerFor(helper);
            if (ownedContainer) {
                ownedContainer.setAttribute("data-pmk6xx-owned-select2", "1");
            }
        }

        host.querySelectorAll(".select2-container").forEach(function (container) {
            if (container !== ownedContainer) container.remove();
        });

        Array.from(host.children || []).forEach(function (child) {
            if (
                child.tagName === "SELECT" &&
                child !== source &&
                child !== helper
            ) {
                child.remove();
            }
        });
    }

    function scheduleLegacyHostPrune(host) {
        if (!host) return;
        [0, 50, 250, 1000, 2500].forEach(function (delay) {
            window.setTimeout(function () {
                try { pruneLegacyHost(host); } catch (_) {}
            }, delay);
        });
    }

    function ensureSelect2(config) {
        if (!config.select2 || config.select2.enabled === false) return Promise.resolve(false);
        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) return Promise.resolve(true);
        if (config.select2.loadIfMissing === false) return Promise.resolve(false);
        if (select2Promise) return select2Promise;

        select2Promise = new Promise(function (resolve) {
            const cssUrl = clean(config.select2.cssUrl);
            const jsUrl = clean(config.select2.jsUrl);

            if (cssUrl && !document.querySelector('link[data-pmk6xx-select2-css="1"]')) {
                const link = document.createElement("link");
                link.rel = "stylesheet";
                link.href = cssUrl;
                link.dataset.pmk6xxSelect2Css = "1";
                document.head.appendChild(link);
            }

            if (!jsUrl) {
                resolve(false);
                return;
            }

            let script = document.querySelector('script[data-pmk6xx-select2-js="1"]');
            if (!script) {
                script = document.createElement("script");
                script.src = jsUrl;
                script.async = true;
                script.dataset.pmk6xxSelect2Js = "1";
                document.head.appendChild(script);
            }

            const done = function () {
                resolve(!!(window.jQuery && window.jQuery.fn && window.jQuery.fn.select2));
            };
            if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
                done();
                return;
            }
            script.addEventListener("load", done, { once: true });
            script.addEventListener("error", function () { resolve(false); }, { once: true });
            window.setTimeout(done, 5000);
        });

        return select2Promise;
    }

    function syncAssistantFromField(field, select) {
        const value = clean(field.value);
        const exists = Array.from(select.options).some(function (option) { return option.value === value; });
        select.value = exists ? value : "";
        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
            try { window.jQuery(select).val(select.value).trigger("change.select2"); } catch (_) {}
        }
    }

    function rememberOriginalStyle(field) {
        if (field.hasAttribute("data-pmk6xx-original-style")) return;
        const value = field.getAttribute("style");
        field.setAttribute("data-pmk6xx-original-style", value === null ? "__PMK_NONE__" : value);
    }

    function restoreOriginalStyle(field) {
        const value = field.getAttribute("data-pmk6xx-original-style");
        if (value === null) return;
        if (value === "__PMK_NONE__") field.removeAttribute("style");
        else field.setAttribute("style", value);
        field.removeAttribute("data-pmk6xx-original-style");
    }

    function removeRuleSyncHandler(field, ruleId) {
        if (!field || !field.__pmk6xxSyncHandlers) return;
        const handler = field.__pmk6xxSyncHandlers[ruleId];
        if (typeof handler === "function") {
            field.removeEventListener("input", handler);
            field.removeEventListener("change", handler);
        }
        try { delete field.__pmk6xxSyncHandlers[ruleId]; } catch (_) { field.__pmk6xxSyncHandlers[ruleId] = null; }
    }

    function removeHelperCommitHandler(select) {
        if (!select) return;
        const handler = select.__pmk6xxCommitHandler;
        if (typeof handler === "function") {
            try { select.removeEventListener("change", handler); } catch (_) {}
            if (window.jQuery) {
                try { window.jQuery(select).off(".pmk6xxCommit", handler); } catch (_) {}
            }
        }
        try { delete select.__pmk6xxCommitHandler; } catch (_) { select.__pmk6xxCommitHandler = null; }
        try { delete select.__pmk6xxCommitLock; } catch (_) { select.__pmk6xxCommitLock = false; }
    }

    function bindHelperCommitHandler(select, callback) {
        if (!select || typeof callback !== "function") return;
        removeHelperCommitHandler(select);

        const handler = function () {
            // Select2 émet des événements jQuery ; le <select> natif peut aussi
            // émettre un vrai change. On écoute les deux sans exécuter deux fois
            // la même sélection dans la même pile d'événements.
            if (select.__pmk6xxCommitLock) return;
            select.__pmk6xxCommitLock = true;
            select.__pmk6xxDirty = true;
            try {
                callback();
            } finally {
                Promise.resolve().then(function () {
                    select.__pmk6xxCommitLock = false;
                });
            }
        };

        select.__pmk6xxCommitCallback = callback;
        select.__pmk6xxCommitHandler = handler;
        select.addEventListener("change", handler);

        if (window.jQuery) {
            try {
                window.jQuery(select)
                    .off(".pmk6xxCommit")
                    .on("change.pmk6xxCommit select2:select.pmk6xxCommit select2:clear.pmk6xxCommit", handler);
            } catch (_) {}
        }
    }

    function commitAssistantToSource(host) {
        if (!host) return;
        const source = host.__pmk6xxSource || host.querySelector(".pmk6xx-native-source");
        const select = host.querySelector(".pmk6xx-select");
        const rule = host.__pmk6xxRule || null;
        if (!source || !select) return;
        // Ne jamais recopier une liste restée vide simplement parce que la valeur
        // MARC courante n'existe pas dans les suggestions. Seules les listes
        // réellement manipulées par l'utilisateur sont resynchronisées au submit.
        if (select.__pmk6xxDirty !== true) return;

        const value = String(select.value == null ? "" : select.value);
        if (!value && preserveValueOnClear(rule)) return;
        const selected = select.options && select.selectedIndex >= 0 ? select.options[select.selectedIndex] : null;
        const label = selected ? selected.textContent : value;

        setFieldValue(source, value, label || value);
        dispatchNative(source);
    }

    function syncAllAssistantsToSources() {
        document.querySelectorAll(".pmk6xx-assistant").forEach(function (host) {
            try { commitAssistantToSource(host); } catch (error) {
                console.warn("[PMK 6XX] Synchronisation avant enregistrement impossible :", error);
            }
        });
    }

    function installFormSubmitGuard() {
        const form = document.getElementById("f") || document.forms.f;
        if (!form || form.__pmk6xxSubmitGuard) return;
        if (typeof form.submit !== "function") return;

        const originalSubmit = form.submit.bind(form);
        form.__pmk6xxNativeSubmit = originalSubmit;
        form.submit = function () {
            // Koha appelle document.f.submit() dans Check(), ce qui contourne
            // l'événement submit. La synchronisation doit donc se faire ici.
            syncAllAssistantsToSources();
            return originalSubmit();
        };
        form.__pmk6xxSubmitGuard = true;
    }

    function setFieldValue(field, value, label) {
        if (field.tagName === "SELECT") {
            const exists = Array.from(field.options || []).some(function (option) {
                return option.value === value;
            });
            if (value && !exists) {
                const option = document.createElement("option");
                option.value = value;
                option.textContent = label || value;
                option.setAttribute("data-pmk6xx-injected", "1");
                field.appendChild(option);
            }
        }
        field.value = value;
    }

    function setLegacyDisplayValue(displayField, value, label) {
        if (!displayField) return;
        if (displayField.tagName === "SELECT") {
            const exists = Array.from(displayField.options || []).some(function (option) {
                return option.value === value;
            });
            if (value && !exists) {
                const option = document.createElement("option");
                option.value = value;
                option.textContent = label || value;
                option.setAttribute("data-pmk6xx-display-only", "1");
                displayField.appendChild(option);
            }
        }
        displayField.value = value;
    }

    function syncLegacyFromField(field, displayField, select) {
        const value = String(field.value == null ? "" : field.value);
        setLegacyDisplayValue(displayField, value, value);
        const exists = Array.from(select.options || []).some(function (option) {
            return option.value === value;
        });
        select.value = exists ? value : "";
        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
            try { window.jQuery(select).val(select.value).trigger("change.select2"); } catch (_) {}
        }
    }

    function createHistoricalSelect(field, rule) {
        const select = document.createElement("select");
        select.className = "koha-6xx-suggestions-select pmk6xx-select";
        // IMPORTANT : aucun name. Koha reconstruit le MARC en se basant sur l'ordre
        // des paramètres tag_* ; un contrôle PMK nommé pourrait interrompre la lecture
        // des sous-zones suivantes (notamment le $9 d'autorité).
        select.removeAttribute("name");
        select.setAttribute("data-koha-custom", "1");
        select.setAttribute("data-pmk6xx-helper", "1");
        select.setAttribute("placeholder", rule.placeholderFr || "");
        select.style.width = "50%";
        return select;
    }

    function preserveValueOnClear(rule) {
        return !!rule && [
            "legacy-082-indexation",
            "legacy-083-element",
            "legacy-084-categorie"
        ].includes(String(rule.id || ""));
    }

    async function bindFieldLegacy(field, rule, config) {
        const parent = field.parentNode;
        if (!parent) return;

        rememberOriginalStyle(field);
        // Le vrai contrôle Koha reste la source soumise au formulaire, mais sa
        // représentation Select2 native est suspendue pendant l'affichage PMK.
        suspendNativeSelect2(field);

        const host = document.createElement("div");
        host.className = "pmk6xx-assistant pmk6xx-legacy-row pmk6xx-loading";
        host.dataset.ruleId = rule.id;
        host.__pmk6xxLive = true;
        host.__pmk6xxSource = field;
        host.__pmk6xxRule = rule;

        // Toujours un INPUT texte de présentation à gauche.
        // Ne jamais cloner le contrôle Koha ici : si le vrai champ est un <select>,
        // le clone conserve ses classes Select2 et Koha peut l'initialiser à son tour,
        // ce qui crée une deuxième liste déroulante visible.
        const displayField = document.createElement("input");
        displayField.type = "text";
        displayField.disabled = true;
        displayField.value = String(field.value == null ? "" : field.value);
        displayField.className = "input_marceditor pmk6xx-legacy-display";
        displayField.style.width = (config.appearance.leftWidthPercent || 50) + "%";
        if (field.id) displayField.id = field.id + "_clone";
        displayField.setAttribute("data-pmk6xx-display-only", "1");
        displayField.setAttribute("aria-hidden", "true");
        displayField.tabIndex = -1;

        const select = createHistoricalSelect(field, rule);
        select.style.width = (config.appearance.rightWidthPercent || 50) + "%";
        select.setAttribute("aria-label", language() === "en" ? rule.nameEn : rule.nameFr);

        const status = document.createElement("span");
        status.className = "pmk6xx-status";
        status.setAttribute("aria-hidden", "true");
        status.textContent = "…";

        parent.insertBefore(host, field);
        host.appendChild(field);
        host.appendChild(displayField);
        host.appendChild(select);
        host.appendChild(status);

        field.classList.add("pmk6xx-native-source");
        pruneLegacyHost(host);
        scheduleLegacyHostPrune(host);

        bindHelperCommitHandler(select, function () {
            const value = select.value;
            const selected = select.options[select.selectedIndex];
            const label = selected ? selected.textContent : value;

            // Les historiques 082/083/084 conservaient la valeur sur un clear ;
            // les nouvelles règles (et 081) peuvent réellement vider le champ Koha.
            if (!value && preserveValueOnClear(rule)) {
                syncLegacyFromField(field, displayField, select);
                return;
            }

            setFieldValue(field, value || "", label || value || "");
            setLegacyDisplayValue(displayField, value || "", label || value || "");
            dispatchNative(field);
        });

        const syncHandler = function () {
            syncLegacyFromField(field, displayField, select);
        };
        field.addEventListener("input", syncHandler);
        field.addEventListener("change", syncHandler);
        if (!field.__pmk6xxSyncHandlers) field.__pmk6xxSyncHandlers = {};
        field.__pmk6xxSyncHandlers[rule.id] = syncHandler;

        try {
            const options = await optionsForRule(rule, config);
            if (!host.isConnected) return;

            const current = String(field.value == null ? "" : field.value);
            select.innerHTML = "";

            const placeholder = document.createElement("option");
            placeholder.value = "";
            placeholder.textContent = language() === "en" ? rule.placeholderEn : rule.placeholderFr;
            select.appendChild(placeholder);

            options.forEach(function (entry) {
                const option = document.createElement("option");
                option.value = entry.value;
                option.textContent = entry.label || entry.value;
                decorateSuggestionOption(option, entry);
                if (entry.value === current) option.selected = true;
                select.appendChild(option);
            });

            // Comme dans les scripts historiques : une valeur libre reste visible
            // à gauche mais n'est pas ajoutée artificiellement dans la liste.
            syncLegacyFromField(field, displayField, select);
            select.__pmk6xxDirty = false;

            host.classList.remove("pmk6xx-loading");
            status.textContent = options.length ? String(options.length) : "0";
            status.title = suggestionSummary(options);

            const hasSelect2 = await ensureSelect2(config);
            if (hasSelect2 && host.isConnected) {
                try {
                    destroySelect2(select);
                    const select2Options = {
                        width: "100%",
                        placeholder: language() === "en" ? rule.placeholderEn : legacySelect2Placeholder(rule),
                        allowClear: true
                    };
                    if (rule.id === "legacy-081-genre") {
                        select2Options.dropdownParent = window.jQuery(document.body);
                    }
                    window.jQuery(select).select2(select2Options);
                    pruneLegacyHost(host);
                    scheduleLegacyHostPrune(host);
                    if (typeof select.__pmk6xxCommitCallback === "function") {
                        bindHelperCommitHandler(select, select.__pmk6xxCommitCallback);
                    }
                } catch (error) {
                    destroySelect2(select);
                    stripSelect2Artifacts(select);
                    console.warn("[PMK 6XX] Select2 indisponible, repli sur la liste native :", error);
                }
            }
        } catch (error) {
            if (!host.isConnected) return;

            // En mode historique le vrai champ est masqué. En cas d'échec de la
            // source de suggestions, on revient donc immédiatement au contrôle Koha
            // natif au lieu de laisser un assistant vide bloquer la saisie.
            removeRuleSyncHandler(field, rule.id);
            const nativeContainer = restoreNativeSelect2(field);
            field.classList.remove("pmk6xx-native-source");
            restoreOriginalStyle(field);
            if (host.parentNode) {
                host.parentNode.insertBefore(field, host);
                if (nativeContainer && host.contains(nativeContainer)) {
                    host.parentNode.insertBefore(nativeContainer, host);
                }
            }
            destroySelect2(select);
            host.remove();

            // data-pmk6xx-rules est volontairement conservé jusqu'au prochain
            // refresh de configuration afin d'éviter une boucle de tentatives API.
            console.warn("[PMK 6XX] Impossible de charger les suggestions pour", rule.id, error);
        }
    }

    async function bindFieldInline(field, rule, config) {
        const host = document.createElement("span");
        host.className = "pmk6xx-assistant pmk6xx-inline-assistant pmk6xx-loading";
        host.dataset.ruleId = rule.id;
        host.__pmk6xxLive = true;
        host.__pmk6xxSource = field;
        host.__pmk6xxRule = rule;

        const select = document.createElement("select");
        select.className = "pmk6xx-select";
        select.setAttribute("data-pmk6xx-helper", "1");
        select.removeAttribute("name");
        select.setAttribute("aria-label", language() === "en" ? rule.nameEn : rule.nameFr);
        select.innerHTML = '<option value="">' + (language() === "en" ? rule.placeholderEn : rule.placeholderFr) + "</option>";
        host.appendChild(select);

        const status = document.createElement("span");
        status.className = "pmk6xx-status";
        status.setAttribute("aria-hidden", "true");
        status.textContent = "…";
        host.appendChild(status);

        // Avec un champ Koha déjà en Select2, le conteneur visible est le vrai
        // point d'ancrage : l'assistant reste bien placé à sa droite.
        const nativeVisible = select2ContainerFor(field);
        const anchor = nativeVisible && nativeVisible.isConnected ? nativeVisible : field;
        anchor.insertAdjacentElement("afterend", host);

        bindHelperCommitHandler(select, function () {
            if (!select.value && preserveValueOnClear(rule)) {
                syncAssistantFromField(field, select);
                return;
            }
            const selected = select.options[select.selectedIndex];
            setFieldValue(field, select.value || "", selected ? selected.textContent : (select.value || ""));
            dispatchNative(field);
        });

        const syncHandler = function () { syncAssistantFromField(field, select); };
        field.addEventListener("input", syncHandler);
        field.addEventListener("change", syncHandler);
        if (!field.__pmk6xxSyncHandlers) field.__pmk6xxSyncHandlers = {};
        field.__pmk6xxSyncHandlers[rule.id] = syncHandler;

        try {
            const options = await optionsForRule(rule, config);
            if (!host.isConnected) return;

            const current = clean(field.value);
            select.innerHTML = "";
            const placeholder = document.createElement("option");
            placeholder.value = "";
            placeholder.textContent = language() === "en" ? rule.placeholderEn : rule.placeholderFr;
            select.appendChild(placeholder);

            options.forEach(function (entry) {
                const option = document.createElement("option");
                option.value = entry.value;
                option.textContent = entry.label || entry.value;
                decorateSuggestionOption(option, entry);
                select.appendChild(option);
            });

            if (current && !options.some(function (entry) { return entry.value === current; })) {
                const option = document.createElement("option");
                option.value = current;
                option.textContent = t("Valeur actuelle — ", "Current value — ") + current;
                select.appendChild(option);
            }

            syncAssistantFromField(field, select);
            select.__pmk6xxDirty = false;
            host.classList.remove("pmk6xx-loading");
            status.textContent = options.length ? String(options.length) : "0";
            status.title = suggestionSummary(options);

            const hasSelect2 = await ensureSelect2(config);
            if (hasSelect2 && host.isConnected) {
                try {
                    destroySelect2(select);
                    window.jQuery(select).select2({
                        width: "100%",
                        placeholder: language() === "en" ? rule.placeholderEn : rule.placeholderFr,
                        allowClear: true,
                        dropdownParent: window.jQuery(document.body)
                    });
                    if (typeof select.__pmk6xxCommitCallback === "function") {
                        bindHelperCommitHandler(select, select.__pmk6xxCommitCallback);
                    }
                } catch (error) {
                    destroySelect2(select);
                    stripSelect2Artifacts(select);
                    console.warn("[PMK 6XX] Select2 indisponible, repli sur la liste native :", error);
                }
            }
        } catch (error) {
            if (!host.isConnected) return;
            host.classList.remove("pmk6xx-loading");
            host.classList.add("pmk6xx-error");
            status.textContent = "!";
            status.title = t(
                "Valeurs Koha indisponibles : le champ natif reste utilisable.",
                "Koha values unavailable: the native field remains usable."
            );
            console.warn("[PMK 6XX] Impossible de charger les suggestions pour", rule.id, error);
        }
    }

    async function bindField(field, rule, config) {
        const boundRules = clean(field.getAttribute("data-pmk6xx-rules"))
            .split(",")
            .map(function (value) { return value.trim(); })
            .filter(Boolean);
        if (boundRules.includes(rule.id)) return;
        if (boundRules.length) {
            console.warn("[PMK 6XX] Contrôle déjà géré par une autre règle, seconde règle ignorée :", rule.id, field);
            return;
        }
        boundRules.push(rule.id);
        field.setAttribute("data-pmk6xx-rules", boundRules.join(","));

        if (config.appearance && config.appearance.mode === "legacy-split") {
            return bindFieldLegacy(field, rule, config);
        }
        return bindFieldInline(field, rule, config);
    }

    function kohaMutationTouchesManaged6xx(index) {
        if (!index) return false;
        const target = document.getElementById(String(index));
        if (!target) return false;

        if (
            target.matches &&
            target.matches(".pmk6xx-assistant, .pmk6xx-native-source")
        ) {
            return true;
        }

        if (
            target.querySelector &&
            target.querySelector(".pmk6xx-assistant, .pmk6xx-native-source")
        ) {
            return true;
        }

        return !!(
            target.closest &&
            target.closest(".pmk6xx-assistant")
        );
    }

    function installKohaMutationGuards() {
        KOHA_MUTATOR_NAMES.forEach(function (name) {
            const current = window[name];
            if (typeof current !== "function" || current.__pmk6xxGuard === true) return;

            const original = current;
            const guarded = function () {
                const activeConfig = cfg();
                if (!pageEnabled(activeConfig)) return original.apply(this, arguments);

                /*
                 * Très important : un clic sur la croix rouge d'une autre zone
                 * ne doit pas démonter les assistants 6XX. On n'intervient que
                 * si CloneField / CloneSubfield / UnCloneField touche réellement
                 * un nœud contenant un assistant PMK.
                 */
                const touchesManaged6xx = kohaMutationTouchesManaged6xx(arguments[0]);
                if (!touchesManaged6xx) {
                    return original.apply(this, arguments);
                }

                // Pour un 6XX réellement géré, on démonte avant le clone afin que
                // Koha ne copie jamais les contrôles PMK sans leurs listeners.
                clearAssistants();
                try {
                    return original.apply(this, arguments);
                } finally {
                    window.setTimeout(scheduleScan, 0);
                    window.setTimeout(scheduleScan, 80);
                }
            };
            guarded.__pmk6xxGuard = true;
            guarded.__pmk6xxOriginal = original;
            window[name] = guarded;
        });
    }

    function clearAssistants() {
        document.querySelectorAll(".pmk6xx-assistant").forEach(function (host) {
            const select = host.querySelector(".pmk6xx-select");
            if (select) {
                removeHelperCommitHandler(select);
                try { delete select.__pmk6xxCommitCallback; } catch (_) { select.__pmk6xxCommitCallback = null; }
                destroySelect2(select);
            }

            const source = host.querySelector(".pmk6xx-native-source");
            if (source && host.parentNode) {
                const nativeContainer = restoreNativeSelect2(source);
                source.classList.remove("pmk6xx-native-source");
                restoreOriginalStyle(source);
                host.parentNode.insertBefore(source, host);
                // Si Koha a recréé Select2 après le montage PMK, son conteneur peut
                // se trouver dans le host : on le replace à côté de son vrai select.
                if (nativeContainer && host.contains(nativeContainer)) {
                    host.parentNode.insertBefore(nativeContainer, host);
                }
                reinitNativeSelect2(source);
            }

            host.remove();
        });

        document.querySelectorAll("[data-pmk6xx-rules]").forEach(function (node) {
            restoreNativeSelect2(node);
            const handlers = node.__pmk6xxSyncHandlers || {};
            Object.keys(handlers).forEach(function (ruleId) {
                const handler = handlers[ruleId];
                if (typeof handler !== "function") return;
                node.removeEventListener("input", handler);
                node.removeEventListener("change", handler);
            });
            try { delete node.__pmk6xxSyncHandlers; } catch (_) { node.__pmk6xxSyncHandlers = null; }
            node.removeAttribute("data-pmk6xx-rules");
        });

        // Filet de sécurité si un conteneur Select2 natif a été remplacé entre-temps.
        document.querySelectorAll(".pmk6xx-native-select2-hidden").forEach(function (container) {
            container.classList.remove("pmk6xx-native-select2-hidden");
        });
    }

    function scan() {
        scanScheduled = false;
        const config = cfg();
        if (!pageEnabled(config)) return;
        installKohaMutationGuards();
        installFormSubmitGuard();
        injectStyles(config);

        // Neutralise toute réinitialisation Select2 tardive du vrai champ Koha
        // et supprime les éventuels contrôles parasites apparus dans la ligne PMK.
        document.querySelectorAll(".pmk6xx-legacy-row").forEach(function (host) {
            pruneLegacyHost(host);
        });
        document.querySelectorAll(".pmk6xx-native-source").forEach(function (field) {
            suspendNativeSelect2(field);
        });

        const rules = Array.isArray(config.rules) ? config.rules.filter(function (rule) { return rule && rule.enabled !== false; }) : [];
        rules.forEach(function (rule) {
            findFields(rule).forEach(function (field) {
                bindField(field, rule, config);
            });
        });
    }

    function scheduleScan() {
        if (scanScheduled) return;
        scanScheduled = true;
        window.requestAnimationFrame(scan);
    }

    function start(config) {
        if (runtimeStarted || !pageEnabled(config)) return;
        runtimeStarted = true;
        installKohaMutationGuards();
        installFormSubmitGuard();
        injectStyles(config);
        scan();

        mutationObserver = new MutationObserver(scheduleScan);
        mutationObserver.observe(document.documentElement, { childList: true, subtree: true });

        window.setTimeout(scan, 400);
        window.setTimeout(scan, 1200);
        window.setTimeout(scan, 2500);
    }

    function refresh(config) {
        optionsCache.clear();
        select2Promise = null;
        try {
            const service = window.PMK6XXConfig && window.PMK6XXConfig.authorisedValues;
            if (service && typeof service.clear === "function") service.clear();
        } catch (_) {}
        if (!pageEnabled(config)) {
            if (mutationObserver) {
                mutationObserver.disconnect();
                mutationObserver = null;
            }
            clearAssistants();
            runtimeStarted = false;
            return;
        }
        clearAssistants();
        runtimeStarted = false;
        start(config);
    }

    const api = window.PMK6XXConfig;
    if (api && api.ready && typeof api.ready.then === "function") {
        api.ready.then(start).catch(function () { start(api.get ? api.get() : null); });
    } else {
        (function (callback) {
        if (document.readyState !== 'loading') callback.call(document);
        else document.addEventListener('DOMContentLoaded', callback, { once: true });
    })(function () { start(cfg()); });
    }

    window.PMK6XXSuggestions = {
        version: "2.3.1-preplugin",
        syncAll: syncAllAssistantsToSources,
        analyzeRule: async function (ruleId) {
            const config = cfg();
            const rule = (config.rules || []).find(function (item) { return item.id === ruleId; });
            if (!rule) return null;
            const options = await optionsForRule(rule, config);
            return { ruleId: rule.id, options: JSON.parse(JSON.stringify(options)), summary: suggestionSummary(options) };
        },
        inspect: function () {
            return Array.from(document.querySelectorAll(".pmk6xx-assistant")).map(function (host) {
                const source = host.__pmk6xxSource || host.querySelector(".pmk6xx-native-source");
                const select = host.querySelector(".pmk6xx-select");
                return {
                    ruleId: host.dataset.ruleId || "",
                    sourceName: source ? source.name : "",
                    sourceValue: source ? source.value : "",
                    helperValue: select ? select.value : "",
                    dirty: select ? select.__pmk6xxDirty === true : false,
                    sourceDisabled: source ? !!source.disabled : null
                };
            });
        }
    };

    window.addEventListener("pmk6xx:config-changed", function (event) {
        const config = event && event.detail ? event.detail : cfg();
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", function () { refresh(config); }, { once: true });
        } else {
            refresh(config);
        }
    });
})();

;window.PMKNonPlugin.loaded.push("081-084-6xx-suggestions.js");
} catch (error) { window.PMKNonPlugin.errors.push("081-084-6xx-suggestions.js: "+error.message); console.error("[PMK] 081-084-6xx-suggestions.js",error); };
try {
/* ============================================================
   088-musicbrainz-coverart.js
   PimpMyKoha — Jaquettes musicales MusicBrainz / Cover Art Archive
   Version : 3.0.8-preplugin
   Date : 2026-09-21

   Réécriture complète :
   - MusicBrainz uniquement pour retrouver un MBID ;
   - Cover Art Archive pour l'image ;
   - file globale <= 1 requête MusicBrainz / seconde ;
   - cache local positif/négatif ;
   - détail et résultats search.pl activés par défaut ;
   - limitation du nombre de résultats et file MusicBrainz conservées ;
   - aucun appel si une vraie couverture est déjà présente ;
   - auto-enregistrement PMK;
   - compatibilité DOM d’origine/Koha : .bookcoverimg + .imgcouv;
   - une image masquée par un autre module ne compte plus comme couverture affichée;
   - extraction EAN depuis .tech-ean / zone 073 et titre depuis .titlebib;
   - search.pl d’origine : .titlebibresult, .ean-result, .bookcoverimg / .cover-slides;
   - création d’une cible de jaquette lorsque Koha affiche « Pas d’image disponible ».
   - v3.0.3 : démarrage fiabilisé si PMKConfig arrive après le module ;
   - relecture de la configuration PMK avant exécution ;
   - relance automatique du traitement lorsqu’une configuration change.
   - v3.0.4 : états explicites sur search.pl (waiting/loading/loaded/not-found/error) ;
   - observation continue des résultats reconstruits dynamiquement ;
   - observer IntersectionObserver persistant et rescans anti-doublon ;
   - API de diagnostic searchStatus()/rerunSearch().
   - v3.0.5 : search.pl activé par défaut dans la configuration du module.
   - v3.0.6 : migration unique des anciennes configs Firestore où searchEnabled=false ;
   - la migration active search.pl une fois, persiste ce choix, puis respecte
     les modifications manuelles ultérieures.
   - v3.0.7 : correction du blocage Firefox sur search.pl : une image lazy
     en display:none pouvait ne jamais émettre load ; préchargement hors DOM ;
   - cible search visible pour le moteur de chargement mais cachée par visibility ;
   - traitement direct des premiers résultats (plus de dépendance à IntersectionObserver) ;
   - verrou runtime versionné afin qu’une ancienne copie du 088 ne bloque pas
     l’exécution de cette version plus récente.

   Remarque : dans un script exécuté directement dans le navigateur, le
   User-Agent HTTP est celui du navigateur et n'est pas un en-tête fiable à
   personnaliser. Pour une diffusion commerciale / multi-clients, le mode
   recommandé est à terme un proxy côté plugin Koha avec User-Agent PMK.
   ============================================================ */
(function (window, document) {
    "use strict";

    if (!window || !document) return;

    const MODULE_ID = "musicbrainz-coverart";
    const MODULE_VERSION = "3.0.8-preplugin";
    const RUNTIME_KEY = "__PMK088MusicBrainzCoverArt_v307";

    // Verrou propre à cette version : une ancienne v3.0.x déjà chargée ne doit
    // plus empêcher la version courante de prendre la main.
    if (window[RUNTIME_KEY]) return;
    window[RUNTIME_KEY] = true;
    window.__PMK088MusicBrainzCoverArt = true;
    const CACHE_PREFIX = "pmk088:mb:";

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        detailEnabled: true,
        searchEnabled: true,
        onlyWhenMissing: true,
        searchMaxResults: 6,
        musicBrainzGapMs: 1100,
        positiveCacheDays: 30,
        negativeCacheHours: 24,
        useBarcodeFirst: true
    });

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let bootPromise = null;
    let domReady = document.readyState !== "loading";
    let searchIntersectionObserver = null;
    let searchMutationObserver = null;
    let searchScanTimer = null;

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function clean(value) { return String(value == null ? "" : value).replace(/\s+/g, " ").trim(); }
    function normalizeConfig(raw) {
        const s = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: s.enabled !== false,
            detailEnabled: s.detailEnabled !== false,
            searchEnabled: s.searchEnabled !== false,
            onlyWhenMissing: s.onlyWhenMissing !== false,
            searchMaxResults: Math.max(1, Math.min(30, Number(s.searchMaxResults) || 6)),
            musicBrainzGapMs: Math.max(1000, Math.min(10000, Number(s.musicBrainzGapMs) || 1100)),
            positiveCacheDays: Math.max(1, Math.min(365, Number(s.positiveCacheDays) || 30)),
            negativeCacheHours: Math.max(1, Math.min(168, Number(s.negativeCacheHours) || 24)),
            useBarcodeFirst: s.useBarcodeFirst !== false,
            searchDefaultMigrationV1: s.searchDefaultMigrationV1 === true
        };
    }

    function ensureQueue() {
        if (window.PMKMusicBrainzQueue) return window.PMKMusicBrainzQueue;
        let tail = Promise.resolve();
        let lastStart = 0;
        window.PMKMusicBrainzQueue = {
            run: function (task, gapMs) {
                const job = tail.catch(function () {}).then(async function () {
                    const gap = Math.max(1000, Number(gapMs) || 1100);
                    const wait = Math.max(0, gap - (Date.now() - lastStart));
                    if (wait) await new Promise(function (resolve) { window.setTimeout(resolve, wait); });
                    lastStart = Date.now();
                    return task();
                });
                tail = job.catch(function () {});
                return job;
            }
        };
        return window.PMKMusicBrainzQueue;
    }

    function cacheKey(query) {
        let hash = 2166136261;
        const text = String(query || "");
        for (let i = 0; i < text.length; i += 1) {
            hash ^= text.charCodeAt(i);
            hash = Math.imul(hash, 16777619);
        }
        return CACHE_PREFIX + (hash >>> 0).toString(36);
    }

    function readCache(query) {
        try {
            const raw = localStorage.getItem(cacheKey(query));
            if (!raw) return null;
            const data = JSON.parse(raw);
            if (!data || !data.expiresAt || Date.now() > Number(data.expiresAt)) {
                localStorage.removeItem(cacheKey(query));
                return null;
            }
            return data.value === undefined ? null : data.value;
        } catch (_) { return null; }
    }

    function writeCache(query, value) {
        try {
            const ttl = value
                ? currentConfig.positiveCacheDays * 86400000
                : currentConfig.negativeCacheHours * 3600000;
            localStorage.setItem(cacheKey(query), JSON.stringify({ expiresAt: Date.now() + ttl, value: value }));
        } catch (_) {}
    }
    function rejectionKey(query) { return cacheKey(query).replace(CACHE_PREFIX, "pmk088:reject:"); }
    function isRejected(query) { try { return localStorage.getItem(rejectionKey(query)) === "1"; } catch (_) { return false; } }
    function rejectQuery(query) { try { localStorage.setItem(rejectionKey(query), "1"); } catch (_) {} }
    function clearLookupMemory(query, includeRejection) { try { localStorage.removeItem(cacheKey(query)); if (includeRejection) localStorage.removeItem(rejectionKey(query)); } catch (_) {} }

    function escapeQuery(value) {
        return clean(value).replace(/["\\]/g, " ");
    }

    function makeQuery(meta) {
        if (currentConfig.useBarcodeFirst && meta.barcode && /^\d{8,14}$/.test(meta.barcode)) {
            return "barcode:" + meta.barcode;
        }
        const parts = [];
        if (meta.title) parts.push('release:"' + escapeQuery(meta.title) + '"');
        if (meta.author) parts.push('artist:"' + escapeQuery(meta.author) + '"');
        return parts.join(" AND ");
    }

    async function musicBrainzLookup(meta) {
        const query = makeQuery(meta);
        if (!query) return null;
        if (isRejected(query)) return { rejected:true, query:query };
        const cached = readCache(query);
        if (cached !== null) return cached ? Object.assign({query:query,matchedBy:query.startsWith("barcode:")?"EAN/UPC":"titre et artiste",cached:true},cached) : null;

        const queue = ensureQueue();
        const result = await queue.run(async function () {
            const url = new URL("https://musicbrainz.org/ws/2/release/", window.location.href);
            url.searchParams.set("query", query);
            url.searchParams.set("fmt", "json");
            url.searchParams.set("limit", "5");
            const response = await fetch(url.toString(), {
                method: "GET",
                mode: "cors",
                credentials: "omit",
                headers: { "Accept": "application/json" }
            });
            if (!response.ok) throw new Error("MusicBrainz " + response.status);
            const payload = await response.json();
            const releases = Array.isArray(payload && payload.releases) ? payload.releases : [];
            if (!releases.length) return null;
            const best = releases.slice().sort(function (a, b) { return Number(b.score || 0) - Number(a.score || 0); })[0];
            if (!best || !best.id) return null;
            return {
                releaseId: best.id,
                releaseGroupId: best["release-group"] && best["release-group"].id ? best["release-group"].id : "",
                score: Number(best.score || 0),
                query: query,
                matchedBy: query.startsWith("barcode:") ? "EAN/UPC" : "titre et artiste",
                cached: false
            };
        }, currentConfig.musicBrainzGapMs);

        writeCache(query, result || "");
        return result;
    }

    function coverUrls(match) {
        const urls = [];
        if (match && match.releaseId) urls.push("https://coverartarchive.org/release/" + encodeURIComponent(match.releaseId) + "/front-250");
        if (match && match.releaseGroupId) urls.push("https://coverartarchive.org/release-group/" + encodeURIComponent(match.releaseGroupId) + "/front-250");
        return urls;
    }

    function isPlaceholderImage(img) {
        if (!img) return true;
        const src = clean(img.getAttribute && img.getAttribute("src"));
        if (!src) return true;
        return /no[-_ ]?image|no[-_ ]?cover|default[-_ ]?cover|placeholder|spacer|blank/i.test(src);
    }

    function isActuallyVisible(element) {
        if (!element || !element.isConnected) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(element) : null;
        if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) return false;
        return element.getClientRects ? element.getClientRects().length > 0 : true;
    }

    function targetHasCover(target) {
        if (!target) return false;
        if (target.tagName === "IMG") return isActuallyVisible(target) && !isPlaceholderImage(target);
        const style = window.getComputedStyle ? window.getComputedStyle(target) : null;
        const bg = clean((style && style.backgroundImage) || target.style.backgroundImage);
        return isActuallyVisible(target) && bg && bg !== "none" && !/no[-_ ]?image|placeholder/i.test(bg);
    }

    function detailCoverHost() {
        return document.querySelector(".bookcoverimg, #bookcoverimg, .cover-slider, #catalogue_detail_biblio") || null;
    }

    function visibleDetailCoverExists() {
        const host = detailCoverHost();
        if (!host) return false;
        return Array.from(host.querySelectorAll("img")).some(function (img) {
            if (img.classList && img.classList.contains("pmk088-cover")) return targetHasCover(img);
            return targetHasCover(img);
        });
    }

    function applyImage(target, urls) {
        return new Promise(function (resolve) {
            if (!target || !urls.length) {
                resolve(false);
                return;
            }

            const candidates = urls.slice();
            let index = 0;

            function finishWithUrl(url) {
                if (target.tagName === "IMG") {
                    target.loading = "eager";
                    target.src = url;
                    target.style.display = "block";
                    target.style.visibility = "visible";
                    target.style.opacity = "1";
                    target.dataset.pmk088Loaded = "1";
                } else {
                    target.style.backgroundImage = 'url("' + url.replace(/"/g, "%22") + '")';
                    target.style.backgroundSize = "cover";
                    target.style.backgroundPosition = "center";
                }

                const host = target.closest && target.closest(".bookcoverimg, .cover-slides, #bookcoverimg");
                if (host) {
                    host.querySelectorAll(".no-image").forEach(function (node) {
                        node.style.display = "none";
                    });
                }
                resolve(true);
            }

            function fail() {
                if (target.tagName === "IMG") {
                    delete target.dataset.pmk088Loaded;
                    if (target.classList.contains("pmk088-cover")) {
                        target.style.visibility = "hidden";
                        target.style.display = "none";
                        target.removeAttribute("src");
                    }
                }
                resolve(false);
            }

            function probeNext() {
                if (index >= candidates.length) {
                    fail();
                    return;
                }

                const url = candidates[index++];
                const probe = new Image();
                probe.loading = "eager";
                probe.decoding = "async";

                probe.onload = function () {
                    if ((probe.naturalWidth || 0) < 2 || (probe.naturalHeight || 0) < 2) {
                        probeNext();
                        return;
                    }
                    finishWithUrl(url);
                };
                probe.onerror = probeNext;
                probe.src = url;
            }

            probeNext();
        });
    }

    function numericProductCode(text) {
        const matches = String(text || "").match(/\b\d{8,14}\b/g) || [];
        return matches.length ? matches[0] : "";
    }

    function detailMeta() {
        const root = document.querySelector("#catalogue_detail_biblio, .biblio_data, #catalogue_detail, main") || document;
        const titleEl = root.querySelector(".titlebib a, strong.titlebib a, h1, h2.title, .title");
        const authorEl = root.querySelector('[title*="Zone : 700"] a, [title*="Zone : 701"] a, .author a, a[href*="q=au:"], a[href*="idx=au"], .author');
        const identifierNodes = document.querySelectorAll('.tech-ean, .detail_isbn, .isbn, .ean, [title*="Zone : 073"], [data-label*="ISBN" i], [data-label*="EAN" i]');
        let barcode = "";
        identifierNodes.forEach(function (node) { if (!barcode) barcode = numericProductCode(node.textContent); });
        return {
            title: clean(titleEl && titleEl.textContent).replace(/^Détails pour\s*/i, ""),
            author: clean(authorEl && authorEl.textContent).replace(/\s*\([^)]*\)\s*-?\s*$/, ""),
            barcode: barcode
        };
    }

    function detailTarget() {
        return document.querySelector(
            ".bookcoverimg img.pmk088-cover, " +
            ".bookcoverimg img.imgcouv:not([style*=\"display: none\"]), " +
            ".bookcoverimg img[data-pmk025-cover-controlled]:not([style*=\"display: none\"]), " +
            ".bookcoverimg img:not(.pmk086-trigger img), " +
            "#bookcoverimg img, #bookcoverimg, " +
            "#catalogue_detail_biblio img.cover-image, .bookcover img, .cover-image img"
        );
    }

    function ensureDetailTarget() {
        const existing = detailTarget();
        if (existing && existing.tagName === "IMG" && isActuallyVisible(existing)) return existing;

        const host = detailCoverHost();
        if (!host) return existing || null;

        let image = host.querySelector("img.pmk088-cover");
        if (!image) {
            image = document.createElement("img");
            image.className = "imgcouv pmk088-cover";
            image.alt = "Jaquette musicale";
            image.loading = "lazy";
            image.style.cssText = "float:none;margin-right:0;margin-bottom:8px;max-width:140px;height:auto;display:block;";
            const anchor = host.querySelector(".technique, .koha-technique-moved");
            if (anchor) host.insertBefore(image, anchor);
            else host.prepend(image);
        }
        return image;
    }

    async function enhanceDetail() {
        if (!currentConfig.detailEnabled || window.location.pathname !== "/cgi-bin/koha/catalogue/detail.pl") return;
        if (currentConfig.onlyWhenMissing && visibleDetailCoverExists()) return;

        const meta = detailMeta();
        if (!meta.title && !meta.barcode) return;

        try {
            const match = await musicBrainzLookup(meta);
            if (!match || match.rejected) return;
            const target = ensureDetailTarget();
            if (target) {
                const loaded=await applyImage(target, coverUrls(match));
                if(loaded)target.title="Cover Art Archive — correspondance "+match.matchedBy+" — score "+match.score+" — release "+match.releaseId;
            }
        } catch (error) {
            console.info("[PMK088] MusicBrainz indisponible sur detail.pl", error);
        }
    }

    function searchRows() {
        const rows = Array.from(document.querySelectorAll(".result, tr[id^='row']"));
        return rows.slice(0, currentConfig.searchMaxResults);
    }

    function metaFromRow(row) {
        const titleEl = row.querySelector(
            ".titlebibresult a, .titlebibresult, .titlemikaresult a, " +
            ".firstresult strong a, .title a, a.title, h3 a, h2 a"
        );
        const authorEl = row.querySelector(
            ".kx-notice-meta-author[title*='700'] a, li[title*='Zone : 700'] a, " +
            "[title*='Zone : 700'] a, .author a, .author"
        );
        let barcode = "";
        row.querySelectorAll(
            ".ean-result, .isbn-result, .ean, .isbn, .tech-ean, " +
            "[data-label*='ISBN' i], [data-label*='EAN' i], .bookcoverimg[data-isbn]"
        ).forEach(function (node) {
            if (barcode) return;
            barcode = numericProductCode(
                node.textContent || (node.dataset && node.dataset.isbn) || node.getAttribute("data-isbn") || ""
            );
        });
        return {
            title: clean(titleEl && titleEl.textContent),
            author: clean(authorEl && authorEl.textContent).replace(/\s*\([^)]*\)\s*-?\s*$/, ""),
            barcode: barcode
        };
    }

    function searchCoverHost(row) {
        return row && row.querySelector("td.bookcoverimg, .bookcoverimg, .cover-slides, .thumbimg, .cover-image");
    }

    function visibleSearchCoverExists(row) {
        const host = searchCoverHost(row);
        if (!host) return false;
        return Array.from(host.querySelectorAll("img")).some(function (img) {
            return targetHasCover(img);
        });
    }

    function ensureSearchTarget(row) {
        const host = searchCoverHost(row);
        if (!host) return null;

        const existingPmk = host.querySelector("img.pmk088-cover");
        if (existingPmk) return existingPmk;

        const visible = Array.from(host.querySelectorAll("img")).find(function (img) { return targetHasCover(img); });
        if (visible) return visible;

        const image = document.createElement("img");
        image.className = "pmk088-cover pmk088-cover-search";
        image.alt = "Jaquette musicale";
        image.loading = "eager";
        image.style.cssText = "display:block;visibility:hidden;max-width:120px;height:auto;margin:0 auto;";

        const slides = row.querySelector(".cover-slides") || host;
        slides.appendChild(image);
        return image;
    }

    function setRowStatus(row, status, detail) {
        if (!row) return;
        row.dataset.pmk088Status = status;
        row.dataset.pmk088Version = MODULE_VERSION;
        if (detail) row.dataset.pmk088StatusDetail = String(detail).slice(0, 180);
        else delete row.dataset.pmk088StatusDetail;
    }

    function renderRowFeedback(row, status, detail, meta, match, target) {
        let box=row.querySelector('.pmk088-feedback');
        if(!box){box=document.createElement('div');box.className='pmk088-feedback';box.style.cssText='font-size:11px;margin-top:4px;overflow-wrap:anywhere';(searchCoverHost(row)||row).appendChild(box);}
        box.replaceChildren();
        const text=document.createElement('span');text.textContent=detail;box.appendChild(text);
        if(status==='loaded'&&match){
            const reject=document.createElement('button');reject.type='button';reject.className='btn btn-link btn-xs';reject.textContent='Écarter cette correspondance';
            reject.addEventListener('click',function(){rejectQuery(match.query||makeQuery(meta));if(target){target.removeAttribute('src');target.style.display='none';}setRowStatus(row,'rejected','Correspondance écartée sur ce navigateur');renderRowFeedback(row,'rejected','Correspondance écartée sur ce navigateur',meta,null,target);});box.append(' ',reject);
        } else if(status==='error'||status==='not-found') {
            const retry=document.createElement('button');retry.type='button';retry.className='btn btn-link btn-xs';retry.textContent='Réessayer';
            retry.addEventListener('click',function(){clearLookupMemory(makeQuery(meta),false);enhanceRow(row,true);});box.append(' ',retry);
        }
    }

    function rowIsEligibleForSearch(row) {
        return !!(row && row.matches && row.matches(".result, tr[id^='row']"));
    }

    async function enhanceRow(row, force) {
        if (!row || !rowIsEligibleForSearch(row)) return;

        const status = row.dataset.pmk088Status || "";
        if (!force && ["loading", "loaded", "not-found", "existing"].includes(status) &&
            row.dataset.pmk088Version === MODULE_VERSION) {
            return;
        }

        row.dataset.pmk088Done = "1";
        setRowStatus(row, "loading");

        if (currentConfig.onlyWhenMissing && visibleSearchCoverExists(row)) {
            setRowStatus(row, "existing", "Une couverture visible existe déjà");
            return;
        }

        const meta = metaFromRow(row);
        if (!meta.title && !meta.barcode) {
            setRowStatus(row, "not-found", "Métadonnées insuffisantes");
            return;
        }

        const target = ensureSearchTarget(row);
        if (!target) {
            setRowStatus(row, "error", "Emplacement de jaquette introuvable");
            return;
        }

        try {
            const match = await musicBrainzLookup(meta);
            if(match&&match.rejected){setRowStatus(row,"rejected","Correspondance écartée sur ce navigateur");renderRowFeedback(row,"rejected","Correspondance écartée sur ce navigateur",meta,null,target);return;}
            if (!match) {
                const detail=meta.barcode ? "Aucun résultat MusicBrainz pour " + meta.barcode : "Aucun résultat MusicBrainz";setRowStatus(row, "not-found",detail);renderRowFeedback(row,"not-found",detail,meta,null,target);
                return;
            }

            const loaded = await applyImage(target, coverUrls(match));
            if (loaded) {
                const detail="Cover Art Archive — correspondance "+match.matchedBy+" — score "+match.score+" — release "+match.releaseId+(match.cached?" — cache local":"");
                setRowStatus(row, "loaded",detail);renderRowFeedback(row,"loaded",detail,meta,match,target);
            } else {
                const detail="Release "+match.releaseId+" trouvée, mais aucune image exploitable";setRowStatus(row, "not-found",detail);renderRowFeedback(row,"not-found",detail,meta,match,target);
            }
        } catch (error) {
            const detail=error && error.message ? error.message : String(error || "Erreur inconnue");setRowStatus(row, "error",detail);renderRowFeedback(row,"error",detail,meta,null,target);
            console.info("[PMK088] MusicBrainz indisponible sur search.pl", error);
        }
    }

    function scanSearchRows(force) {
        if (!currentConfig.searchEnabled || window.location.pathname !== "/cgi-bin/koha/catalogue/search.pl") return [];

        const rows = searchRows();

        rows.forEach(function (row) {
            const status = row.dataset.pmk088Status || "";
            const sameVersion = row.dataset.pmk088Version === MODULE_VERSION;

            if (force || !sameVersion || !status || status === "waiting" || status === "error") {
                setRowStatus(row, "waiting");
                // Le nombre de lignes est déjà borné par searchMaxResults et les
                // requêtes MusicBrainz restent sérialisées par la file globale.
                enhanceRow(row, !!force);
            }
        });

        return rows;
    }

    function scheduleSearchScan(force) {
        if (searchScanTimer) window.clearTimeout(searchScanTimer);
        searchScanTimer = window.setTimeout(function () {
            searchScanTimer = null;
            scanSearchRows(!!force);
        }, 80);
    }

    function ensureSearchMutationObserver() {
        if (searchMutationObserver || window.location.pathname !== "/cgi-bin/koha/catalogue/search.pl") return;

        const root =
            document.querySelector("#searchresults, #catalogue-results, table tbody, main") ||
            document.body;

        searchMutationObserver = new MutationObserver(function (mutations) {
            let relevant = false;
            for (const mutation of mutations) {
                if (mutation.type !== "childList" || !mutation.addedNodes.length) continue;
                for (const node of mutation.addedNodes) {
                    if (!(node instanceof Element)) continue;
                    if (
                        rowIsEligibleForSearch(node) ||
                        node.querySelector(".result, tr[id^='row'], td.bookcoverimg, .cover-slides")
                    ) {
                        relevant = true;
                        break;
                    }
                }
                if (relevant) break;
            }
            if (relevant) scheduleSearchScan(false);
        });

        searchMutationObserver.observe(root, { childList: true, subtree: true });
    }

    function enhanceSearch(force) {
        if (!currentConfig.searchEnabled || window.location.pathname !== "/cgi-bin/koha/catalogue/search.pl") return;
        ensureSearchMutationObserver();
        scanSearchRows(!!force);
    }

    function searchStatusSummary() {
        const rows = Array.from(document.querySelectorAll(".result, tr[id^='row']"));
        const counts = {};
        const details = rows.map(function (row) {
            const status = row.dataset.pmk088Status || "unseen";
            counts[status] = (counts[status] || 0) + 1;
            return {
                id: row.id || "",
                status: status,
                detail: row.dataset.pmk088StatusDetail || "",
                version: row.dataset.pmk088Version || ""
            };
        });

        return {
            page: window.location.pathname,
            enabled: !!currentConfig.enabled,
            searchEnabled: !!currentConfig.searchEnabled,
            maxResults: currentConfig.searchMaxResults,
            totalRows: rows.length,
            counts: counts,
            rows: details.slice(0, currentConfig.searchMaxResults)
        };
    }

    function definition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr: "Jaquettes musicales — MusicBrainz", en: "Music cover art — MusicBrainz" },
            description: {
                fr: "Recherche un MBID via MusicBrainz puis utilise Cover Art Archive comme source de jaquette. Le module respecte une file à une requête MusicBrainz par seconde et utilise un cache local.",
                en: "Finds an MBID through MusicBrainz then uses Cover Art Archive for cover images. The module enforces a one-request-per-second MusicBrainz queue and uses a local cache."
            },
            category: { fr: "Catalogue / couvertures", en: "Catalogue / covers" },
            supportedPages: ["catalogue.detail", "catalogue.search"],
            prerequisites: [
                { fr: "Accès HTTPS aux domaines musicbrainz.org et coverartarchive.org", en: "HTTPS access to musicbrainz.org and coverartarchive.org" }
            ],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            schema: [
                {
                    type: "section",
                    id: "settings",
                    label: { fr: "Réglages", en: "Settings" },
                    description: {
                        fr: "MusicBrainz indique que son Web Service est gratuit pour un usage non commercial. La recherche sur search.pl est activée par défaut, avec une limite de résultats et une file d’attente respectant environ 1 requête/s par IP.",
                        en: "MusicBrainz states that its web service is free for non-commercial use. Search-page enrichment is enabled by default with a result limit and a queue respecting roughly one request per second per IP."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        { key: "detailEnabled", type: "boolean", label: { fr: "Chercher une jaquette sur detail.pl", en: "Look up covers on detail.pl" } },
                        { key: "searchEnabled", type: "boolean", label: { fr: "Chercher des jaquettes sur search.pl", en: "Look up covers on search.pl" } },
                        { key: "onlyWhenMissing", type: "boolean", label: { fr: "Ne compléter que si aucune vraie couverture n’est déjà affichée", en: "Only fill when no real cover is already displayed" } },
                        { key: "searchMaxResults", type: "number", label: { fr: "Nombre maximal de résultats interrogés par page", en: "Maximum search results queried per page" } },
                        { key: "useBarcodeFirst", type: "boolean", label: { fr: "Privilégier EAN/UPC lorsqu’il est détecté", en: "Prefer detected EAN/UPC" } },
                        { key: "musicBrainzGapMs", type: "number", advanced: true, label: { fr: "Intervalle minimal MusicBrainz (ms)", en: "Minimum MusicBrainz interval (ms)" } },
                        { key: "positiveCacheDays", type: "number", advanced: true, label: { fr: "Cache des correspondances réussies (jours)", en: "Successful match cache (days)" } },
                        { key: "negativeCacheHours", type: "number", advanced: true, label: { fr: "Cache des absences de résultat (heures)", en: "No-result cache (hours)" } }
                    ]
                }
            ]
        };
    }

    function runCurrentPage() {
        if (!domReady || !currentConfig.enabled) return;
        if (window.location.pathname === "/cgi-bin/koha/catalogue/detail.pl") {
            enhanceDetail();
        } else if (window.location.pathname === "/cgi-bin/koha/catalogue/search.pl") {
            enhanceSearch(false);
        }
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) { return false; }

        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            try {
                unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                    currentConfig = normalizeConfig(cfg);
                    runCurrentPage();
                });
            } catch (_) {}
        }
        return true;
    }

    async function boot() {
        if (!domReady) return false;
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return false;

        if (bootPromise) return bootPromise;

        bootPromise = (async function () {
            registerModule();
            try {
                const loadedConfig = await window.PMKConfig.getConfig(MODULE_ID);
                currentConfig = normalizeConfig(loadedConfig);
            } catch (_) {
                currentConfig = normalizeConfig(currentConfig);
            }
            runCurrentPage();
            return true;
        })();

        try {
            return await bootPromise;
        } finally {
            bootPromise = null;
        }
    }

    function onDomReady() {
        domReady = true;
        boot();
    }

    function onConfigReady() {
        boot();
    }

    window.PMK088MusicBrainzCoverArt = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        status: function () {
            return {
                version: MODULE_VERSION,
                page: window.location.pathname,
                pmkReady: !!(window.PMKConfig && typeof window.PMKConfig.getConfig === "function"),
                runtimeKey: RUNTIME_KEY,
                config: clone(currentConfig)
            };
        },
        rerun: function () { return boot(); },
        rerunSearch: function () {
            if (window.location.pathname !== "/cgi-bin/koha/catalogue/search.pl") return false;
            enhanceSearch(true);
            return true;
        },
        searchStatus: function () {
            return searchStatusSummary();
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", onDomReady, { once: true });
    } else {
        domReady = true;
        boot();
    }

    window.addEventListener("pmk:config-ready", onConfigReady);

    // Filet de sécurité : certaines installations PMK ne diffusent pas
    // l'événement ou peuvent le diffuser avant ce fichier.
    if (!window.PMKConfig) {
        let retries = 0;
        const timer = window.setInterval(function () {
            retries += 1;
            if (window.PMKConfig) {
                window.clearInterval(timer);
                boot();
            } else if (retries >= 40) {
                window.clearInterval(timer);
            }
        }, 250);
    }
})(window, document);

;window.PMKNonPlugin.loaded.push("088-musicbrainz-coverart.js");
} catch (error) { window.PMKNonPlugin.errors.push("088-musicbrainz-coverart.js: "+error.message); console.error("[PMK] 088-musicbrainz-coverart.js",error); };
try {
/* Ancien relais de page personnalisée archivé dans dev/legacy-archive.
   Les confirmations et annulations sont assurées par les commandes natives Koha. */

;window.PMKNonPlugin.loaded.push("091-popup-annulation-transfert.js");
} catch (error) { window.PMKNonPlugin.errors.push("091-popup-annulation-transfert.js: "+error.message); console.error("[PMK] 091-popup-annulation-transfert.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.transferInfo;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 092-popup-info-site-transfert.js
 Dépendances: KOHA_UTILS.waitFor (fallback included), jQuery optional
 Date de dernière modification: 2026-02-21
 Auteur: équipe PimpMyKoha
 Description: Affiche une pop-up d'information pour les sites de transfert.
*/

(function(){
  'use strict';
  try{
    (function(){})('092-popup-info-site-transfert: loaded');
    if (!window.location.pathname || window.location.pathname!==options.path) return;

    const waitFor = (selector, timeout) => {
      if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === 'function') return window.KOHA_UTILS.waitFor(selector, timeout);
      return new Promise((resolve, reject) => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        const obs = new MutationObserver(() => { const found = document.querySelector(selector); if (found) { obs.disconnect(); resolve(found); } });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        setTimeout(() => { obs.disconnect(); reject(new Error('timeout')); }, timeout || 3000);
      });
    };

    waitFor(options.target, 3000).then(() => {
      try{
        document.querySelectorAll(options.target).forEach(el => {
          el.addEventListener('click', function(e){
            e.preventDefault(); const info = this.dataset.info || this.title || this.textContent; const modal = document.querySelector(options.modal); if (modal){ modal.querySelector('.modal-body').textContent = info; try{ if (window.jQuery) window.jQuery(modal).modal('show'); }catch(e){ (function(){})('092: show modal failed', e); } } else { alert(info); }
          });
        });
      }catch(e){ (function(){})('092: init failed', e); }
    }).catch(()=>{});

  }catch(e){ (function(){})('092-popup-info-site-transfert: failed', e); }
})();

})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("092-popup-info-site-transfert.js");
} catch (error) { window.PMKNonPlugin.errors.push("092-popup-info-site-transfert.js: "+error.message); console.error("[PMK] 092-popup-info-site-transfert.js",error); };
try {
/* Ancien relais de page personnalisée archivé dans dev/legacy-archive.
   Les confirmations et annulations sont assurées par les commandes natives Koha. */

;window.PMKNonPlugin.loaded.push("093-cancel-hold-and-transfer.js");
} catch (error) { window.PMKNonPlugin.errors.push("093-cancel-hold-and-transfer.js: "+error.message); console.error("[PMK] 093-cancel-hold-and-transfer.js",error); };
