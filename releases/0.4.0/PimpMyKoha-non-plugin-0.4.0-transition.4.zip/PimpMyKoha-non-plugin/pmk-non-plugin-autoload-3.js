/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
/* ============================================================
   000-pmk-cover-resolver.js
   PimpMyKoha — moteur transverse de résolution des couvertures
   Version : 1.0.1
   Date : 2026-10-01

   Objectif :
   - moteur commun pour 066-067 (listes personnelles) et 142 (bibliographies) ;
   - sources uniquement issues de Koha / de ce que Koha rend déjà disponible ;
   - DOM courant, HTML detail.pl, Electre via endpoint Koha, source existante, MARC 856 ;
   - aucun appel direct codé vers Google Books / Open Library / Amazon ;
   - cache par biblionumber / ISBN ;
   - file globale limitée à 4 résolutions simultanées ;
   - chargement différé possible à l'approche du viewport ;
   - fallback automatique si une image échoue ou est vide/minuscule.
   ============================================================ */
(function (window, document) {
    'use strict';

    if (!window || !document) return;
    if (window.PMKCoverResolver && window.PMKCoverResolver.version) return;

    const VERSION = '1.0.1';
    const MAX_CONCURRENCY = 4;
    const MIN_VALID_IMAGE_SIZE = 20;

    const resolutionCache = new Map();
    const detailHtmlCache = new Map();
    const marcCache = new Map();

    let activeJobs = 0;
    const pendingJobs = [];

    async function fetchKoha(url,options) {
        const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
        try {const response=await fetch(url,{...options,signal:controller.signal});
            // A missing optional cover service may return a large HTML error page.
            // Keep its status without downloading a diagnostic page as image data.
            if(!response.ok){try{await response.body?.cancel();}catch(_){}return {ok:false,status:response.status,text:async()=>''};}
            const text=await response.text();return {ok:response.ok,status:response.status,text:async()=>text};}
        finally {clearTimeout(timer);}
    }

    function clean(value) {
        return String(value == null ? '' : value)
            .replace(/\u00a0/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function absoluteUrl(value) {
        const url = clean(value);
        if (!url) return '';
        try {
            return new URL(url, window.location.origin).href;
        } catch (_) {
            return url;
        }
    }

    function uniqueCoverCandidates(values) {
        const out = [];
        const seen = new Set();

        (values || []).flat(Infinity).forEach(value => {
            const url = absoluteUrl(value);
            if (!url) return;

            const lowered = url.toLowerCase();
            if (
                lowered.includes('/img/spinner') ||
                lowered.includes('favicon') ||
                lowered.includes('blank.gif') ||
                lowered.includes('transparent') ||
                lowered === 'about:blank'
            ) return;

            if (seen.has(url)) return;
            seen.add(url);
            out.push(url);
        });

        return out;
    }

    function normalizeIsbn(value) {
        const source = Array.isArray(value) ? value[0] : value;
        const first = clean(source).split(/[\s,;]+/)[0] || '';
        return first.replace(/[^0-9Xx]/g, '').toUpperCase();
    }

    function isbnValues(value) {
        const source = Array.isArray(value) ? value : [value];
        const out = [];

        source.forEach(entry => {
            String(entry || '')
                .split(/[\s,;|]+/)
                .map(part => normalizeIsbn(part))
                .filter(Boolean)
                .forEach(isbn => {
                    if (!out.includes(isbn)) out.push(isbn);
                });
        });

        return out;
    }

    function isbn13to10(value) {
        const isbn = normalizeIsbn(value);
        if (/^\d{9}[\dX]$/.test(isbn)) return isbn;
        if (!/^978\d{10}$/.test(isbn)) return '';

        const core = isbn.slice(3, 12);
        let sum = 0;
        for (let i = 0; i < 9; i += 1) sum += (10 - i) * Number(core[i]);
        const check = (11 - (sum % 11)) % 11;
        return core + (check === 10 ? 'X' : String(check));
    }

    function marcValue(marc, tag, code) {
        return marc?.[String(tag)]?.[String(code)] ?? '';
    }

    function firstMarcValue(marc, candidates) {
        for (const [tag, code] of candidates || []) {
            const value = marcValue(marc, tag, code);
            if (Array.isArray(value)) {
                const first = value.find(Boolean);
                if (first) return clean(first);
            } else if (clean(value)) {
                return clean(value);
            }
        }
        return '';
    }

    function electreIsbn10Candidates(input, marc) {
        const values = [
            ...isbnValues(input?.isbn),
            ...isbnValues(marcValue(marc || {}, '010', 'a'))
        ];
        const out = [];
        values.forEach(value => {
            const isbn10 = isbn13to10(value);
            if (isbn10 && !out.includes(isbn10)) out.push(isbn10);
        });
        return out;
    }

    function runQueued(task) {
        return new Promise((resolve, reject) => {
            pendingJobs.push({ task, resolve, reject });
            drainQueue();
        });
    }

    function drainQueue() {
        while (activeJobs < MAX_CONCURRENCY && pendingJobs.length) {
            const job = pendingJobs.shift();
            activeJobs += 1;
            Promise.resolve()
                .then(job.task)
                .then(job.resolve, job.reject)
                .finally(() => {
                    activeJobs -= 1;
                    drainQueue();
                });
        }
    }

    async function fetchDetailHtml(biblionumber) {
        const id = clean(biblionumber);
        if (!id) return '';
        if (detailHtmlCache.has(id)) return await detailHtmlCache.get(id);

        const promise = (async () => {
            const response = await fetchKoha(
                '/cgi-bin/koha/catalogue/detail.pl?biblionumber=' + encodeURIComponent(id),
                {
                    credentials: 'same-origin',
                    headers: { Accept: 'text/html,application/xhtml+xml' }
                }
            );
            if (!response.ok) throw new Error('HTTP ' + response.status + ' — fiche notice ' + id);
            return await response.text();
        })();

        detailHtmlCache.set(id, promise);
        try {
            return await promise;
        } catch (error) {
            detailHtmlCache.delete(id);
            throw error;
        }
    }

    function imgCandidateUrls(img) {
        if (!img) return [];
        const urls = [
            img.getAttribute('src'),
            img.getAttribute('data-src'),
            img.getAttribute('data-original'),
            img.getAttribute('data-lazy-src')
        ];
        const srcset = clean(img.getAttribute('srcset'));
        if (srcset) {
            srcset.split(',').forEach(part => {
                const url = clean(part.trim().split(/\s+/)[0]);
                if (url) urls.push(url);
            });
        }
        return uniqueCoverCandidates(urls);
    }

    function extractKohaCoverCandidatesFromHtml(htmlText) {
        if (!htmlText) return [];
        const doc = new DOMParser().parseFromString(htmlText, 'text/html');
        const urls = [];

        [
            '#biblio-cover-slider .cover-image img',
            '.bookcoverimg .cover-image img',
            '#biblio-cover-slider img',
            '.bookcoverimg img',
            '#custom-img',
            '.imgcouv',
            '.imgcouvlist',
            '.thumbimg'
        ].forEach(selector => {
            doc.querySelectorAll(selector).forEach(img => {
                urls.push(...imgCandidateUrls(img));
                const link = img.closest('a[href]')?.getAttribute('href');
                if (link && /\/catalogue\/image\.pl\?/i.test(link)) urls.push(link);
            });
        });

        return uniqueCoverCandidates(urls);
    }

    function currentBiblionumber() {
        try {
            return clean(new URL(window.location.href).searchParams.get('biblionumber'));
        } catch (_) {
            return '';
        }
    }

    function extractLiveKohaCoverCandidates(biblionumber) {
        const bibId = clean(biblionumber);
        if (!bibId || currentBiblionumber() !== bibId) return [];

        const urls = [];
        document.querySelectorAll(
            '#biblio-cover-slider img, .bookcoverimg img, .imgcouv, .imgcouvlist, .thumbimg'
        ).forEach(img => urls.push(...imgCandidateUrls(img)));
        return uniqueCoverCandidates(urls);
    }

    function addMarcValue(target, tag, code, value) {
        const cleanValue = clean(value);
        if (!cleanValue) return;
        if (!target[tag]) target[tag] = {};
        const previous = target[tag][code];
        if (previous == null || previous === '') target[tag][code] = cleanValue;
        else if (Array.isArray(previous)) {
            if (!previous.includes(cleanValue)) previous.push(cleanValue);
        } else if (previous !== cleanValue) {
            target[tag][code] = [previous, cleanValue];
        }
    }

    function parseMarcXml(xmlText) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(xmlText, 'application/xml');
        if (doc.querySelector('parsererror')) throw new Error('MARCXML illisible.');

        const marc = {};
        Array.from(doc.getElementsByTagNameNS('*', 'datafield')).forEach(field => {
            const tag = clean(field.getAttribute('tag'));
            if (!tag) return;
            Array.from(field.getElementsByTagNameNS('*', 'subfield')).forEach(subfield => {
                const code = clean(subfield.getAttribute('code'));
                if (!code) return;
                addMarcValue(marc, tag, code, subfield.textContent);
            });
        });
        return marc;
    }

    async function fetchMarcXml(url) {
        const response = await fetchKoha(url, {
            credentials: 'same-origin',
            headers: { Accept: 'application/marcxml+xml' }
        });
        if (!response.ok) throw new Error('HTTP ' + response.status + ' — ' + url);
        const xml = await response.text();
        if (!xml || !/<(?:\w+:)?record\b/i.test(xml)) throw new Error('Réponse MARCXML invalide — ' + url);
        return xml;
    }

    async function fetchMarcForBiblio(biblionumber) {
        const id = clean(biblionumber);
        if (!id) return {};
        if (marcCache.has(id)) return await marcCache.get(id);

        const promise = (async () => {
            const encoded = encodeURIComponent(id);
            const urls = [
                '/api/v1/biblios/' + encoded,
                '/api/v1/public/biblios/' + encoded
            ];
            for (const url of urls) {
                try {
                    return parseMarcXml(await fetchMarcXml(url));
                } catch (_) {}
            }
            return {};
        })();

        marcCache.set(id, promise);
        try {
            return await promise;
        } catch (error) {
            marcCache.delete(id);
            return {};
        }
    }

    function marc856CoverCandidates(marc) {
        const raw = marcValue(marc || {}, '856', 'u');
        const values = Array.isArray(raw) ? raw : [raw];
        return uniqueCoverCandidates(
            values
                .map(value => clean(value))
                .filter(value => /^https?:\/\//i.test(value) || value.startsWith('/'))
        );
    }

    async function fetchElectreCoverViaKoha(input, marc) {
        const candidates = electreIsbn10Candidates(input, marc);
        if (!candidates.length) return '';

        for (const isbn10 of candidates) {
            const url = '/api/v1/contrib/electre/image'
                + '?isbn10=' + encodeURIComponent(isbn10)
                + '&side=staff'
                + '&result_page=true';
            try {
                const response = await fetchKoha(url, {
                    credentials: 'same-origin',
                    headers: { Accept: 'text/plain, application/json;q=0.9, */*;q=0.8' }
                });
                if (!response.ok) continue;
                let value = clean(await response.text());
                value = value.replace(/^"(.*)"$/s, '$1').trim();
                if (value && value !== 'null' && value !== 'undefined') return absoluteUrl(value);
            } catch (_) {}
        }
        return '';
    }

    function sourceCandidates(input) {
        return uniqueCoverCandidates([
            input?.cover,
            input?.imgSrc,
            ...(Array.isArray(input?.coverCandidates) ? input.coverCandidates : [])
        ]);
    }

    function resolutionKey(input, marc) {
        const bibId = clean(input?.biblionumber);
        if (bibId) return 'bib:' + bibId;
        const isbn = normalizeIsbn(input?.isbn || firstMarcValue(marc || {}, [['010', 'a']]));
        return isbn ? 'isbn:' + isbn : '';
    }

    async function resolveCandidates(input = {}, options = {}) {
        const suppliedMarc = options.marc || input.marc || null;
        const initialKey = resolutionKey(input, suppliedMarc || {});
        if (initialKey && resolutionCache.has(initialKey)) return await resolutionCache.get(initialKey);

        const promise = runQueued(async () => {
            const bibId = clean(input?.biblionumber);
            const source = sourceCandidates(input);
            const live = extractLiveKohaCoverCandidates(bibId);

            let detail = [];
            let marc = suppliedMarc || {};

            const tasks = [];
            if (bibId) {
                tasks.push(
                    fetchDetailHtml(bibId)
                        .then(extractKohaCoverCandidatesFromHtml)
                        .catch(() => [])
                );
                if (!suppliedMarc) tasks.push(fetchMarcForBiblio(bibId));
            }

            if (tasks.length) {
                const results = await Promise.all(tasks);
                detail = results[0] || [];
                if (!suppliedMarc && results.length > 1) marc = results[1] || {};
            }

            const electre = await fetchElectreCoverViaKoha(input, marc);
            const from856 = marc856CoverCandidates(marc);

            return uniqueCoverCandidates([
                live,
                detail,
                electre,
                source,
                from856
            ]);
        });

        const cacheKey = initialKey || resolutionKey(input, suppliedMarc || {});
        if (cacheKey) resolutionCache.set(cacheKey, promise);

        try {
            return await promise;
        } catch (error) {
            if (cacheKey) resolutionCache.delete(cacheKey);
            return sourceCandidates(input);
        }
    }

    function waitUntilNearViewport(element, rootMargin = '300px') {
        if (!element || !('IntersectionObserver' in window)) return Promise.resolve();
        return new Promise(resolve => {
            const observer = new IntersectionObserver(entries => {
                if (entries.some(entry => entry.isIntersecting)) {
                    observer.disconnect();
                    resolve();
                }
            }, { root: null, rootMargin });
            observer.observe(element);
        });
    }

    function bindImage(img, input = {}, options = {}) {
        if (!img) return Promise.resolve([]);
        if (img.dataset.pmkCoverResolverBound === '1') return Promise.resolve([]);
        img.dataset.pmkCoverResolverBound = '1';

        const removeOnExhausted = options.removeOnExhausted !== false;
        const deferUntilVisible = options.deferUntilVisible === true;
        const resolveOnErrorOnly = options.resolveOnErrorOnly === true;
        const initial = sourceCandidates(input);

        let candidates = initial.slice();
        let index = -1;
        let fullResolved = false;
        let resolving = null;
        let finished = false;

        img.loading = img.loading || 'lazy';
        img.decoding = 'async';
        img.style.visibility = 'hidden';

        function exhaust() {
            if (finished) return;
            finished = true;
            img.style.visibility = '';
            if (removeOnExhausted) img.remove();
            else img.style.display = 'none';
        }

        async function ensureFullCandidates() {
            if (fullResolved) return candidates;
            if (resolving) return await resolving;
            resolving = (async () => {
                if (deferUntilVisible) await waitUntilNearViewport(img, options.rootMargin || '300px');
                const resolved = await resolveCandidates(input, options);
                candidates = uniqueCoverCandidates([candidates, resolved]);
                fullResolved = true;
                return candidates;
            })();
            try {
                return await resolving;
            } finally {
                resolving = null;
            }
        }

        async function nextCandidate(forceResolve = false) {
            if (finished) return;
            index += 1;

            if (index >= candidates.length && (!fullResolved || forceResolve)) {
                await ensureFullCandidates();
            }

            if (index >= candidates.length) {
                exhaust();
                return;
            }

            img.style.visibility = 'hidden';
            img.src = candidates[index];
        }

        img.addEventListener('error', () => {
            void nextCandidate(true);
        });

        img.addEventListener('load', () => {
            if (finished) return;
            if (
                img.naturalWidth > 0 &&
                img.naturalHeight > 0 &&
                (img.naturalWidth < MIN_VALID_IMAGE_SIZE || img.naturalHeight < MIN_VALID_IMAGE_SIZE)
            ) {
                void nextCandidate(true);
                return;
            }
            img.style.visibility = 'visible';
        });

        if (initial.length) {
            index = 0;
            img.src = initial[0];
            if (!resolveOnErrorOnly) void ensureFullCandidates();
        } else {
            index = -1;
            void nextCandidate(true);
        }

        return Promise.resolve(candidates);
    }

    function clearCache() {
        resolutionCache.clear();
        detailHtmlCache.clear();
        marcCache.clear();
    }

    window.PMKCoverResolver = Object.freeze({
        version: VERSION,
        maxConcurrency: MAX_CONCURRENCY,
        resolveCandidates,
        bindImage,
        uniqueCandidates: uniqueCoverCandidates,
        fetchMarcForBiblio,
        clearCache,
        stats() {
            return {
                resolutionCache: resolutionCache.size,
                detailHtmlCache: detailHtmlCache.size,
                marcCache: marcCache.size,
                activeJobs,
                pendingJobs: pendingJobs.length
            };
        }
    });

    try {
        window.dispatchEvent(new CustomEvent('pmk:cover-resolver-ready', {
            detail: { version: VERSION }
        }));
    } catch (_) {}
})(window, document);

;window.PMKNonPlugin.loaded.push("000-pmk-cover-resolver.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-cover-resolver.js: "+error.message); console.error("[PMK] 000-pmk-cover-resolver.js",error); };
try {
/* Dates communes Koha : dates impossibles refusées, ordre local explicite,
   fuseau respecté lorsqu’il est fourni. Le défaut historique reste jour/mois. */
(function(){
 'use strict';
 if(window.PMKDates)return;
 function order(options={}){
  const values=[options.order,window.dateformat,window.DateFormat,window.kohaDateFormat,document.documentElement.dataset.dateformat,document.body?.dataset.dateformat];
  for(const value of values){const text=String(value||'').toLowerCase();if(['us','mdy','mm/dd/yyyy'].includes(text))return {value:'mdy',source:'koha'};if(['metric','dmy','dd/mm/yyyy','dd.mm.yyyy'].includes(text))return {value:'dmy',source:'koha'};}
  return {value:'dmy',source:'historical-default'};
 }
 function inspect(value,options={}){
  if(value instanceof Date)return Number.isNaN(value.getTime())?{status:'invalid',date:null}:{status:'ok',date:new Date(value),source:'date',ambiguous:false};
  const raw=String(value??'').replace(/\u00a0/g,' ').trim();if(!raw)return {status:'empty',date:null};
  // Extract one complete date from a Koha label; refuse multiple dates or partial identifiers.
  const pattern=/(?<![\d\p{L}])(?:\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4})(?:[T ]+\d{1,2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?(?:\s*(?:Z|[+-]\d{2}:?\d{2}|AM|PM))?)?(?![\d\p{L}])/giu;
  const matches=[...raw.matchAll(pattern)];if(matches.length!==1)return {status:matches.length?'ambiguous':'invalid',date:null};
  const text=matches[0][0];if(options.exact&&text!==raw)return {status:'invalid',date:null};
  const remainder=raw.slice(matches[0].index+text.length);
  if(/^(?:[:.]\d|\s*[+-]\d|\s+\d+:)/.test(remainder))return {status:'invalid',date:null};
  const m=text.match(/^(\d+)[-/.](\d+)[-/.](\d+)(?:[T ]+(\d+):(\d+)(?::(\d+)(?:\.(\d+))?)?\s*(Z|[+-]\d{2}:?\d{2}|AM|PM)?)?$/i);if(!m)return {status:'invalid',date:null};
  let year,month,day,source='iso',dateOrder='ymd',ambiguous=false;const a=Number(m[1]),b=Number(m[2]),c=Number(m[3]);
  if(m[1].length===4){year=a;month=b;day=c;}else{year=c;const chosen=order(options);source=chosen.source;dateOrder=a>12?'dmy':b>12?'mdy':chosen.value;ambiguous=a<=12&&b<=12&&a!==b&&chosen.source==='historical-default';month=dateOrder==='mdy'?a:b;day=dateOrder==='mdy'?b:a;}
  let hour=Number(m[4]||0),minute=Number(m[5]||0),second=Number(m[6]||0),ms=Number((m[7]||'').padEnd(3,'0').slice(0,3)),zone=(m[8]||'').toUpperCase();
  if(zone==='AM'||zone==='PM'){if(hour<1||hour>12)return {status:'invalid',date:null};hour=hour%12+(zone==='PM'?12:0);zone='';}
  if(year<1000||year>9999||month<1||month>12||day<1||day>31||hour>23||minute>59||second>59)return {status:'invalid',date:null};
  const validation=new Date(Date.UTC(year,month-1,day,hour,minute,second,ms));if(validation.getUTCMonth()!==month-1||validation.getUTCDate()!==day)return {status:'invalid',date:null};
  let date;
  if(zone){let offset=0;if(zone!=='Z'){const z=zone.match(/^([+-])(\d{2}):?(\d{2})$/);if(!z||Number(z[2])>14||Number(z[3])>59||(Number(z[2])===14&&Number(z[3])!==0))return {status:'invalid',date:null};offset=(Number(z[2])*60+Number(z[3]))*(z[1]==='-'?-1:1);}date=new Date(validation.getTime()-offset*60000);}
  else{date=new Date(year,month-1,day,hour,minute,second,ms);if(date.getHours()!==hour||date.getMinutes()!==minute)return {status:'invalid',date:null};}
  return {status:ambiguous?'assumed':'ok',date,source,ambiguous,order:dateOrder};
 }
 const api={version:'1.0.0',inspect,parse:(value,options)=>inspect(value,options).date,order};window.PMKDates=api;window.PMKConfig?.services.register('dates',api);
})();

;window.PMKNonPlugin.loaded.push("000-pmk-dates.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-dates.js: "+error.message); console.error("[PMK] 000-pmk-dates.js",error); };
try {
/* PMK — validation commune des fichiers, URL et fragments HTML importés. */
(function(window){
'use strict';
if(window.PMKImportCommon)return;
const DEFAULT_MAX_BYTES=25*1024*1024;
function plainObject(value){return !!value&&typeof value==='object'&&!Array.isArray(value);}
function safeName(file){return String(file?.name||'fichier').replace(/[\u0000-\u001f\u007f]/g,'').slice(0,180);}
async function textFile(file,options={}){
  if(!file||typeof file.arrayBuffer!=='function')throw new Error('Fichier absent ou illisible.');
  const maxBytes=Math.max(1,Number(options.maxBytes)||DEFAULT_MAX_BYTES);
  if(Number(file.size)>maxBytes)throw new Error(`${safeName(file)} dépasse la taille autorisée (${Math.ceil(maxBytes/1048576)} Mo).`);
  const buffer=await file.arrayBuffer();
  if(buffer.byteLength>maxBytes)throw new Error('Le fichier dépasse la taille autorisée.');
  const bytes=new Uint8Array(buffer);if(bytes.some((value,index)=>value===0&&index<8192))throw new Error('Le fichier semble binaire et ne peut pas être importé comme texte.');
  let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch(_){throw new Error('Le fichier n’est pas un texte UTF-8 valide.');}
  text=text.replace(/^\uFEFF/,'');if(!text.trim())throw new Error('Le fichier est vide.');return text;
}
function inspect(value,limits={}){
  const maxDepth=Math.max(1,Number(limits.maxDepth)||80),maxNodes=Math.max(1,Number(limits.maxNodes)||250000);let nodes=0;
  function visit(current,depth){if(++nodes>maxNodes)throw new Error('Le fichier contient trop d’éléments.');if(depth>maxDepth)throw new Error('Le fichier est imbriqué trop profondément.');if(!current||typeof current!=='object')return;for(const key of Object.keys(current)){if(['__proto__','prototype','constructor'].includes(key))throw new Error(`Propriété interdite dans le fichier : ${key}.`);visit(current[key],depth+1);}}
  visit(value,0);return value;
}
function jsonText(text,options={}){
  let value;try{value=JSON.parse(String(text));}catch(error){throw new Error(`JSON malformé : ${error.message}.`);}
  if(options.object!==false&&!plainObject(value))throw new Error('Le fichier JSON doit contenir un objet à sa racine.');
  return inspect(value,options);
}
async function jsonFile(file,options={}){return jsonText(await textFile(file,options),options);}
function sameOriginURL(value,options={}){
  let url;try{url=new URL(String(value||''),window.location.origin);}catch(_){throw new Error('Adresse URL malformée.');}
  if(!/^https?:$/.test(url.protocol)||url.origin!==window.location.origin)throw new Error('L’adresse doit appartenir à cette installation Koha.');
  const paths=options.paths||[];if(paths.length&&!paths.includes(url.pathname))throw new Error('Chemin Koha inattendu : '+url.pathname+'.');return url;
}
function htmlText(text,options={}){
  text=String(text||'');if(text.length>(Number(options.maxChars)||5_000_000))throw new Error('Le document HTML dépasse la taille autorisée.');if(!text.trim()||text.includes('\u0000'))throw new Error('Document HTML vide ou binaire.');
  const doc=new DOMParser().parseFromString(text,'text/html');if(!doc?.documentElement||!doc.body)throw new Error('Document HTML malformé.');
  if(options.allowActive!==true){const active=doc.querySelector('script,iframe,object,embed,base,meta[http-equiv]');const handler=Array.from(doc.querySelectorAll('*')).some(node=>Array.from(node.attributes||[]).some(attribute=>/^on/i.test(attribute.name)||/^(?:href|src|action|formaction)$/i.test(attribute.name)&&/^\s*javascript:/i.test(attribute.value)));if(active||handler)throw new Error('Le document HTML contient du contenu actif interdit.');}
  if(options.rejectLogin&&doc.querySelector('#loginform,input[name="password"],input[name="koha_login_context"]'))throw new Error('Le document importé est une page de connexion Koha.');return doc;
}
window.PMKImportCommon=Object.freeze({version:'1.0.0',textFile,jsonText,jsonFile,sameOriginURL,htmlText});
})(window);

;window.PMKNonPlugin.loaded.push("000-pmk-import-common.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-import-common.js: "+error.message); console.error("[PMK] 000-pmk-import-common.js",error); };
try {
/* PimpMyKoha — moteur commun des plannings et estimations de navette. */
(function(window){
  'use strict';
  if(window.PMKPlanningCommon)return;

  const text=value=>String(value??'').trim();
  const clone=value=>JSON.parse(JSON.stringify(value));
  const isoDate=date=>{
    const year=date.getFullYear(),month=String(date.getMonth()+1).padStart(2,'0'),day=String(date.getDate()).padStart(2,'0');
    return `${year}-${month}-${day}`;
  };
  const parseDate=value=>{
    if(!/^\d{4}-\d{2}-\d{2}$/.test(text(value)))return null;
    const date=new Date(`${value}T00:00:00`);
    return Number.isNaN(date.getTime())?null:date;
  };
  const minutes=value=>{
    const match=/^(\d{1,2}):(\d{2})$/.exec(text(value));
    if(!match)return null;
    const result=Number(match[1])*60+Number(match[2]);
    return result>=0&&result<1440?result:null;
  };
  const key=value=>text(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();

  function normalizeStop(stop){
    const name=text(stop?.name);if(!name)return null;
    return {name,location:text(stop?.location),time:text(stop?.time)};
  }
  function normalizeSlot(slot,index){
    if(!slot||typeof slot!=='object')return null;
    const stops=(Array.isArray(slot.stops)?slot.stops:[]).map(normalizeStop).filter(Boolean);if(!stops.length)return null;
    const kind=slot.kind==='weekly'?'weekly':'date';
    const result={id:text(slot.id)||`slot-${index+1}`,kind,period:text(slot.period),start:text(slot.start),end:text(slot.end),stops};
    if(kind==='weekly')Object.assign(result,{weekday:Math.min(6,Math.max(0,Number(slot.weekday)||0)),dateFrom:text(slot.dateFrom),dateTo:text(slot.dateTo)});
    else result.date=text(slot.date);
    return result;
  }
  function normalizeService(service,index){
    const name=text(service?.name)||`Service ${index+1}`;
    return {
      ...clone(service&&typeof service==='object'?service:{}),
      id:text(service?.id)||`service-${index+1}`,name,title:text(service?.title)||name,
      active:service?.active!==false,order:Number.isFinite(Number(service?.order))?Number(service.order):(index+1)*10,
      maxUpcoming:Math.min(50,Math.max(1,Number(service?.maxUpcoming)||5)),
      slots:(Array.isArray(service?.slots)?service.slots:[]).map(normalizeSlot).filter(Boolean),
      exceptions:(Array.isArray(service?.exceptions)?service.exceptions:[]).map((exception,i)=>({id:text(exception?.id)||`exception-${i+1}`,date:text(exception?.date),period:text(exception?.period),cancelled:exception?.cancelled!==false})).filter(exception=>parseDate(exception.date))
    };
  }
  function normalizeConfig(raw){
    const input=raw&&typeof raw==='object'?raw:{};
    return {schemaVersion:Number(input.schemaVersion)||1,source:text(input.source)||'koha',services:(Array.isArray(input.services)?input.services:[]).map(normalizeService)};
  }
  function cancelled(service,date,period){return service.exceptions.some(exception=>exception.cancelled&&exception.date===date&&(!exception.period||exception.period===period));}
  function collectOccurrences(service,options={}){
    service=normalizeService(service,0);const now=options.now instanceof Date?new Date(options.now):new Date(),today=new Date(now);today.setHours(0,0,0,0);
    const horizonDays=Math.min(730,Math.max(1,Number(options.horizonDays)||180)),limit=Math.min(200,Math.max(1,Number(options.limit)||service.maxUpcoming||5)),result=[];
    for(const slot of service.slots){
      if(slot.kind==='date'){
        const date=parseDate(slot.date);if(date&&date>=today&&!cancelled(service,slot.date,slot.period))result.push({...clone(slot),iso:slot.date,dateObj:date});
        continue;
      }
      for(let offset=0;offset<=horizonDays;offset++){
        const date=new Date(today);date.setDate(date.getDate()+offset);const iso=isoDate(date);
        if(date.getDay()!==slot.weekday||(slot.dateFrom&&iso<slot.dateFrom)||(slot.dateTo&&iso>slot.dateTo)||cancelled(service,iso,slot.period))continue;
        result.push({...clone(slot),iso,dateObj:date});
      }
    }
    result.sort((a,b)=>a.dateObj-b.dateObj||(minutes(a.start)??9999)-(minutes(b.start)??9999));
    return result.slice(0,limit);
  }
  function aliasNames(value,aliases){
    const values=[text(value)],mapping=aliases&&typeof aliases==='object'?aliases:{};
    const direct=mapping[value]??mapping[text(value).toUpperCase()]??mapping[text(value).toLowerCase()];
    (Array.isArray(direct)?direct:[direct]).filter(Boolean).forEach(item=>values.push(text(item)));
    return new Set(values.map(key).filter(Boolean));
  }
  function stopIndex(stops,names){return stops.findIndex(stop=>names.has(key(stop.name))||names.has(key(stop.location)));}
  function occurrenceDate(occurrence,stop){
    const result=new Date(occurrence.dateObj),value=minutes(stop?.time)||minutes(occurrence.start);
    if(value!=null)result.setHours(Math.floor(value/60),value%60,0,0);else result.setHours(0,0,0,0);
    return result;
  }
  function estimate(config,query={}){
    const normalized=normalizeConfig(config),now=query.at instanceof Date?query.at:new Date(query.at||Date.now()),fromNames=aliasNames(query.from,query.aliases),toNames=aliasNames(query.to,query.aliases),matches=[];
    for(const service of normalized.services.filter(service=>service.active&&(!query.serviceId||service.id===query.serviceId))){
      for(const occurrence of collectOccurrences(service,{now,horizonDays:query.horizonDays||180,limit:200})){
        const fromIndex=stopIndex(occurrence.stops,fromNames),toIndex=stopIndex(occurrence.stops,toNames);
        if(fromIndex<0||toIndex<0||fromIndex>=toIndex)continue;
        const estimatedAt=occurrenceDate(occurrence,occurrence.stops[toIndex]);if(estimatedAt<now)continue;
        matches.push({kind:'estimate',serviceId:service.id,serviceTitle:service.title,occurrenceId:occurrence.id,date:occurrence.iso,period:occurrence.period,fromStop:occurrence.stops[fromIndex],toStop:occurrence.stops[toIndex],estimatedAt:estimatedAt.toISOString()});
      }
    }
    matches.sort((a,b)=>Date.parse(a.estimatedAt)-Date.parse(b.estimatedAt));
    return matches[0]||null;
  }
  async function read(){
    const registered=window.PMKHomeWidgets?.storage?.get('planning-services/config');
    if(registered?.read){const snapshot=await registered.read();return normalizeConfig(snapshot?.data?snapshot.data():snapshot);}
    const api=window.PMKNativeData;if(!api)throw new Error('Stockage natif Koha indisponible.');
    const snapshot=await api.getDoc(api.doc(api.createDatabase('planning'),'planning','config'));
    return normalizeConfig(snapshot?.exists?.()?snapshot.data():{});
  }

  window.PMKPlanningCommon=Object.freeze({normalizeConfig,collectOccurrences,estimate,read,key});
})(window);

;window.PMKNonPlugin.loaded.push("000-pmk-planning-common.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-planning-common.js: "+error.message); console.error("[PMK] 000-pmk-planning-common.js",error); };
try {
window.PMKInstallationSQL={async copy(file){
 const url=window.PMKPlugin?.assetUrl?PMKPlugin.assetUrl('sql/'+file):'/public/koha-scripts/sql/'+file;
 const response=await fetch(url,{credentials:'same-origin'});if(!response.ok)throw new Error('SQL indisponible : '+response.status);
 const sql=await response.text();if(!/^\s*(?:--|SELECT|WITH)/i.test(sql))throw new Error('Fichier SQL invalide');
 PMKConfig.services.get('sql-reports').registerDefinition({id:file.toLowerCase(),sql,purpose:file,parameters:[...sql.matchAll(/<<([^>]+)>>/g)].map(x=>x[1]),columns:[]},{replace:true});
 await navigator.clipboard.writeText(sql);return {changed:false,message:'SQL copié. Créez un rapport privé Koha, puis renseignez son identifiant dans PMK.'};
}};
(function(){
 const defaults={enabled:true,allReportId:5246,duplicatesReportId:5245,orphansReportId:5260,personTypes:'NP\nPERS\nSAUT\nFAM'};
 const REPORTS=[['allReportId','Référentiel complet','Authorities-referentiel.sql'],['duplicatesReportId','Doublons','Authorities-doublons.sql'],['orphansReportId','Orphelins','Authorities-orphelins.sql']];
 function diagnose(config=defaults){
  const ids=new Map(),reports=REPORTS.map(([key,label,file])=>{const id=Number(config?.[key]),valid=Number.isSafeInteger(id)&&id>0;if(valid){if(!ids.has(id))ids.set(id,[]);ids.get(id).push(key);}return {key,label,file,id:valid?id:0,valid,state:valid?'à vérifier dans ce Koha':'identifiant manquant'};});
  for(const report of reports)if(report.valid&&ids.get(report.id).length>1)report.state='identifiant partagé avec un autre rapport';
  const raw=String(config?.personTypes||'').split(/[\n,;]+/).map(value=>value.trim()).filter(Boolean),seen=new Set(),duplicates=[],invalid=[];
  for(const value of raw){const normalized=value.toUpperCase();if(seen.has(normalized))duplicates.push(value);else seen.add(normalized);if(!/^[A-Za-z0-9_-]{1,20}$/.test(value))invalid.push(value);}
  return {reports,personTypes:[...seen],duplicatePersonTypes:[...new Set(duplicates)],invalidPersonTypes:[...new Set(invalid)],valid:reports.every(report=>report.valid&&report.state==='à vérifier dans ce Koha')&&seen.size>0&&!duplicates.length&&!invalid.length};
 }
 async function checkInstallation(config=defaults){
  const local=diagnose(config);if(!window.PMKWorkbench?.checkReports)return {...local,checked:false,error:'Le diagnostic commun des rapports n’est pas chargé.'};
  const reportConfig={};for(const report of local.reports)reportConfig[report.key]={reportId:report.id};
  const remote=await PMKWorkbench.checkReports(reportConfig),byId=new Map((remote.rows||[]).map(row=>[Number(row.id),row]));
  return {...local,checked:true,reports:local.reports.map(report=>({...report,remote:byId.get(report.id)||null}))};
 }
 function renderDiagnostic(ctx){
  const box=document.createElement('div'),result=diagnose(ctx.rootObject||defaults),title=document.createElement('strong');title.textContent='Diagnostic de cette installation';box.append(title);
  const list=document.createElement('ul');for(const report of result.reports){const li=document.createElement('li');li.textContent=report.label+' — rapport '+(report.id||'non configuré')+' : '+report.state;list.append(li);}box.append(list);
  const types=document.createElement('p');types.textContent='Types de personnes : '+(result.personTypes.join(', ')||'aucun')+(result.duplicatePersonTypes.length?' · doublons : '+result.duplicatePersonTypes.join(', '):'')+(result.invalidPersonTypes.length?' · codes invalides : '+result.invalidPersonTypes.join(', '):'');box.append(types);
  const note=document.createElement('p');note.textContent='Le contrôle à distance lit uniquement le nom et les paramètres des rapports. Il n’exécute pas leur SQL et ne modifie aucune autorité.';box.append(note);
  const button=document.createElement('button');button.type='button';button.className='btn btn-default btn-sm';button.textContent='Vérifier les rapports dans ce Koha';const status=document.createElement('div');status.setAttribute('role','status');status.style.marginTop='6px';
  button.onclick=async()=>{button.disabled=true;status.textContent='Vérification…';try{const checked=await checkInstallation(ctx.rootObject||defaults);status.textContent=checked.checked?checked.reports.map(report=>report.label+' : '+(report.remote?.state==='ok'?'disponible':report.remote?.state==='missing'?'introuvable':report.remote?.state||report.state)).join(' · '):checked.error;}catch(error){status.textContent='Vérification impossible : '+error.message;}finally{button.disabled=false;}};
  box.append(button,status);return box;
 }
 const definition={configurationOnly:true,id:'authority-installation-options',schemaVersion:1,name:{fr:'Autorités — paramètres de l’installation',en:'Authorities — installation settings'},description:{fr:'Périmètre v1 : UNIMARC/A. Configurez les trois rapports propres à ce Koha et les codes de types de personnes. Cette fiche contrôle uniquement l’installation ; le moteur métier de la page Autorités reste inchangé.',en:'v1: UNIMARC/A. Configure this Koha installation reports and person authority types.'},category:{fr:'Pages et outils internes',en:'Internal pages'},defaults,
  validate:config=>{const result=diagnose(config);return result.valid?{ok:true}:{ok:false,message:'Corrigez les identifiants de rapports et les codes de types signalés dans le diagnostic.'};},
  schema:[{type:'section',id:'reports',label:{fr:'Rapports et types d’autorités',en:'Reports and authority types'},description:{fr:'Les identifiants sont propres à chaque installation. Copiez les modèles SQL, créez les rapports dans Koha, puis indiquez ici leurs numéros.',en:'Report IDs belong to each installation.'},fields:[
   {key:'allReportId',type:'number',label:{fr:'Rapport Référentiel complet',en:'Full authority report'}},{key:'duplicatesReportId',type:'number',label:{fr:'Rapport Doublons',en:'Duplicate authority report'}},{key:'orphansReportId',type:'number',label:{fr:'Rapport Orphelins',en:'Orphan authority report'}},{key:'personTypes',type:'textarea',label:{fr:'Codes des types de personnes, un par ligne',en:'Person authority type codes, one per line'},help:{fr:'Codes auth_tag_to_report réellement utilisés dans cette installation, par exemple NP, PERS, SAUT ou FAM.',en:'Actual auth_tag_to_report codes used in this installation.'}},{type:'custom',render:renderDiagnostic}
  ]}]
 };
 definition.schema[0].fields.push(...REPORTS.map(([,label,file])=>({type:'action',label:{fr:file,en:file},buttonLabel:{fr:'Copier le SQL',en:'Copy SQL'},help:{fr:'Modèle pour le rapport '+label+'.',en:'SQL template.'},action:()=>PMKInstallationSQL.copy(file)})));
 window.PMKAuthorityInstallation=Object.freeze({diagnose,checkInstallation,defaults});
 PMKConfig.registerModule(definition);
})();

;window.PMKNonPlugin.loaded.push("000-pmk-settings-authorities.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-settings-authorities.js: "+error.message); console.error("[PMK] 000-pmk-settings-authorities.js",error); };
try {
/* Réglages des améliorations historiques, appliqués avant leur démarrage. */
(function(){'use strict';
 const id='legacy-interface-options';
 const defaults={"enabled": true, "print": {"enabled": true, "target": "#printpatron, #printpatron_dropdown, .btn-group:has(.printslip) > button.dropdown-toggle", "birthLabel": "Date de naissance", "genderLabel": "Genre"}, "shuttle": {"enabled": true, "schedule": "", "excludedWeeks": "52", "morningCutoff": 12, "afternoonCutoff": 18}, "awards": {"enabled": true, "values": "", "index": "nt"}, "concern": {"enabled": true, "source": "#newconcern", "after": "#placehold", "label": "Signaler un problème dans cette notice"}, "transferInfo": {"enabled": true, "path": "/cgi-bin/koha/circ/transfer.pl", "target": ".site-info", "modal": "#siteInfoModal"}, "titles": {"enabled": true, "suffix": "Catalogue"}, "tree": {"enabled": true, "pageId": "114", "target": "#arborescence"}, "holdsMessage": {"enabled": false, "text": "Les rapports sont innaccessibles pour le moment. La liste des réservations n'est donc pas présentées comme vous en avez l'habitude. un ticket est en cours."}, "scanner": {"enabled": true, "extraSelector":"", "targets": "search-form\nsearchmember\nret_barcode\nfindborrower\nbarcode"}, "hideSuggestion": {"enabled": true}};
 const DEFAULT_SHUTTLE={"Mardi":{"Matin":["DRAGUIGNAN","FIGANIERES","BARGEMON","CALLAS","LA MOTTE","DRAGUIGNAN"],"Après-midi":["DRAGUIGNAN","LE MUY","VIDAUBAN","LORGUES","SALERNES","FLAYOSC","DRAGUIGNAN"]},"Mercredi":{"Matin":["DRAGUIGNAN","AMPUS","MONTFERRAT","COMPS-SUR-ARTUBY","CLAVIERS","DRAGUIGNAN"]},"Vendredi":{"Matin":["DRAGUIGNAN","LE MUY","VIDAUBAN","LORGUES","SALERNES","FLAYOSC","DRAGUIGNAN"],"Après-midi":["DRAGUIGNAN","FIGANIERES","BARGEMON","CALLAS","LA MOTTE","DRAGUIGNAN"]}};
 function scheduleRows(value){
  let schedule=value;
  if(typeof schedule==='string'){if(!schedule.trim())schedule=DEFAULT_SHUTTLE;else try{schedule=JSON.parse(schedule);}catch{return {valid:false,error:'Le JSON des tournées est invalide.',entries:[]};}}
  if(!schedule||typeof schedule!=='object'||Array.isArray(schedule))return {valid:false,error:'Les tournées doivent être un objet organisé par jour et période.',entries:[]};
  const entries=[];
  for(const [day,periods] of Object.entries(schedule)){
   if(!periods||typeof periods!=='object'||Array.isArray(periods))return {valid:false,error:'Le jour « '+day+' » doit contenir des périodes.',entries:[]};
   for(const [period,sites] of Object.entries(periods)){
    if(!Array.isArray(sites)||!sites.length||sites.some(site=>!String(site||'').trim()))return {valid:false,error:'La tournée « '+day+' — '+period+' » doit contenir au moins un site.',entries:[]};
    entries.push({day,period,sites:sites.map(site=>String(site).trim()),source:typeof value==='string'&&value.trim()?'personnalisée':'d’origine par défaut'});
   }
  }
  return entries.length?{valid:true,error:'',entries}:{valid:false,error:'Aucune tournée n’est configurée.',entries:[]};
 }
 function selectorState(selector,root=document){
  if(!String(selector||'').trim())return {selector:'',valid:true,count:0,status:'non configuré'};
  try{const count=root.querySelectorAll(String(selector)).length;return {selector:String(selector),valid:true,count,status:count?'trouvé':'absent sur cette page'};}
  catch{return {selector:String(selector),valid:false,count:0,status:'sélecteur invalide'};}
 }
 function targetDiagnostics(config=defaults,root=document){
  const list=[['Impression',config.print?.target],['Signaler un problème',config.concern?.source],['Placement du signalement',config.concern?.after],['Informations de site',config.transferInfo?.target],['Fenêtre du site',config.transferInfo?.modal],['Arborescence',config.tree?.target],['Champ caméra supplémentaire',config.scanner?.extraSelector]];
  for(const target of String(config.scanner?.targets||'').split(/\n/).map(v=>v.trim()).filter(Boolean))list.push(['Caméra — '+target,'#'+CSS.escape(target)+',[name="'+CSS.escape(target)+'"]']);
  return list.map(([label,selector])=>({label,...selectorState(selector,root)}));
 }
 function cameraCapabilities(nav=navigator){
  return {secure:window.isSecureContext===true,mediaDevices:!!nav.mediaDevices,permissionRequest:typeof nav.mediaDevices?.getUserMedia==='function',touch:Number(nav.maxTouchPoints||0)>0,userAgent:String(nav.userAgent||'')};
 }
 function makeSchedulePreview(ctx){
  const box=document.createElement('div'),result=scheduleRows(ctx.rootObject?.shuttle?.schedule??'');box.className='alert '+(result.valid?'alert-info':'alert-danger');
  const title=document.createElement('strong');title.textContent=result.valid?'Aperçu des tournées':'Configuration invalide';box.append(title);
  if(!result.valid){const p=document.createElement('p');p.textContent=result.error;box.append(p);return box;}
  const table=document.createElement('table');table.className='table table-condensed';const head=document.createElement('tr');for(const label of ['Jour','Période','Parcours','Origine']){const th=document.createElement('th');th.textContent=label;head.append(th);}table.append(head);
  for(const row of result.entries){const tr=document.createElement('tr');for(const value of [row.day,row.period,row.sites.join(' → '),row.source]){const td=document.createElement('td');td.textContent=value;tr.append(td);}table.append(tr);}box.append(table);return box;
 }
 function makeTargetPreview(ctx){
  const box=document.createElement('div'),title=document.createElement('strong');title.textContent='Cibles sur la page actuellement ouverte';box.append(title);
  const list=document.createElement('ul');for(const item of targetDiagnostics(ctx.rootObject||defaults)){const li=document.createElement('li');li.textContent=item.label+' : '+item.status+(item.count?' ('+item.count+')':'');li.dataset.status=item.status;list.append(li);}box.append(list);
  const cap=cameraCapabilities(),p=document.createElement('p');p.textContent='Caméra : '+(cap.secure&&cap.permissionRequest?'API disponible ; l’autorisation sera demandée au premier scan.':'HTTPS ou API caméra indisponible dans ce navigateur.')+(cap.touch?' Appareil tactile détecté.':' Aucun écran tactile détecté.');box.append(p);return box;
 }
 const scannerField={key:'scanner.extraSelector',type:'elementPicker',label:{fr:'Choisir un champ supplémentaire sur la page',en:'Pick an additional field'},allowManual:true,manualAlways:true,pick:ctx=>PMKConfig.elementPicker.pickForConfig({moduleId:id,targetUrl:location.pathname,rootObject:ctx.rootObject,fieldPath:ctx.fieldPath,persistAfterPick:false,options:{rootSelector:'body'}})};
 const moduleDefinition={id,schemaVersion:1,name:{fr:'Interface — améliorations historiques',en:'Interface — historic enhancements'},description:{fr:'Commandes, navette, recherches et caméra des anciens scripts. Les changements prennent effet au prochain chargement. Les anciennes commandes 091 et 093 sont archivées : Koha conserve ses propres confirmations et droits.',en:'Historic interface settings; reload after changes. Native Koha transfer and hold confirmations remain authoritative.'},category:{fr:'Interface',en:'Interface'},defaults,schema:[{"type": "section", "id": "print", "label": {"fr": "Impression des informations adhérent", "en": "Impression des informations adhérent"}, "fields": [{"key": "print.enabled", "type": "boolean", "label": {"fr": "Ajouter l’action d’impression", "en": "Ajouter l’action d’impression"}}, {"key": "print.target", "type": "text", "label": {"fr": "Bouton du menu Imprimer", "en": "Bouton du menu Imprimer"}}, {"key": "print.birthLabel", "type": "text", "label": {"fr": "Libellé de la date de naissance", "en": "Libellé de la date de naissance"}}, {"key": "print.genderLabel", "type": "text", "label": {"fr": "Libellé du genre", "en": "Libellé du genre"}}]}, {"type": "section", "id": "shuttle", "label": {"fr": "Estimation du passage de la navette", "en": "Estimation du passage de la navette"}, "fields": [{"key": "shuttle.enabled", "type": "boolean", "label": {"fr": "Afficher la prochaine navette", "en": "Afficher la prochaine navette"}}, {"key": "shuttle.schedule", "type": "textarea", "label": {"fr": "Tournées par jour et période (JSON ; vide = tournées d’origine)", "en": "Tournées par jour et période (JSON ; vide = tournées d’origine)"}}, {"key": "shuttle.excludedWeeks", "type": "text", "label": {"fr": "Semaines ISO sans tournée, séparées par des virgules", "en": "Semaines ISO sans tournée, séparées par des virgules"}}, {"key": "shuttle.morningCutoff", "type": "number", "label": {"fr": "Heure limite du matin", "en": "Heure limite du matin"}, "min": 0, "max": 23}, {"key": "shuttle.afternoonCutoff", "type": "number", "label": {"fr": "Heure limite de l’après-midi", "en": "Heure limite de l’après-midi"}, "min": 0, "max": 23}]}, {"type": "section", "id": "awards", "label": {"fr": "Recherches par prix littéraires", "en": "Recherches par prix littéraires"}, "fields": [{"key": "awards.enabled", "type": "boolean", "label": {"fr": "Afficher les prix littéraires", "en": "Afficher les prix littéraires"}}, {"key": "awards.values", "type": "textarea", "label": {"fr": "Un prix par ligne ; vide = liste d’origine", "en": "Un prix par ligne ; vide = liste d’origine"}}, {"key": "awards.index", "type": "text", "label": {"fr": "Index de recherche Koha", "en": "Index de recherche Koha"}}]}, {"type": "section", "id": "concern", "label": {"fr": "Commande native Signaler un problème", "en": "Commande native Signaler un problème"}, "fields": [{"key": "concern.enabled", "type": "boolean", "label": {"fr": "Déplacer la commande", "en": "Déplacer la commande"}}, {"key": "concern.source", "type": "text", "label": {"fr": "Commande native à déplacer", "en": "Commande native à déplacer"}}, {"key": "concern.after", "type": "text", "label": {"fr": "Placer après cet élément", "en": "Placer après cet élément"}}, {"key": "concern.label", "type": "text", "label": {"fr": "Intitulé", "en": "Intitulé"}}]}, {"type": "section", "id": "transferInfo", "label": {"fr": "Information de site — ancienne page personnalisée", "en": "Information de site — ancienne page personnalisée"}, "fields": [{"key": "transferInfo.enabled", "type": "boolean", "label": {"fr": "Activer sur la page personnalisée", "en": "Activer sur la page personnalisée"}}, {"key": "transferInfo.path", "type": "text", "label": {"fr": "Chemin de la page", "en": "Chemin de la page"}}, {"key": "transferInfo.target", "type": "text", "label": {"fr": "Éléments contenant data-info", "en": "Éléments contenant data-info"}}, {"key": "transferInfo.modal", "type": "text", "label": {"fr": "Fenêtre native facultative", "en": "Fenêtre native facultative"}}]}, {"type": "section", "id": "titles", "label": {"fr": "Titres des onglets", "en": "Titres des onglets"}, "fields": [{"key": "titles.enabled", "type": "boolean", "label": {"fr": "Enrichir le titre des onglets", "en": "Enrichir le titre des onglets"}}, {"key": "titles.suffix", "type": "text", "label": {"fr": "Suffixe", "en": "Suffixe"}}]}, {"type": "section", "id": "tree", "label": {"fr": "Ancienne page d’arborescence", "en": "Ancienne page d’arborescence"}, "fields": [{"key": "tree.enabled", "type": "boolean", "label": {"fr": "Présenter l’arborescence repliable", "en": "Présenter l’arborescence repliable"}}, {"key": "tree.pageId", "type": "text", "label": {"fr": "Identifiant de la page Koha", "en": "Identifiant de la page Koha"}}, {"key": "tree.target", "type": "text", "label": {"fr": "Conteneur de l’arborescence", "en": "Conteneur de l’arborescence"}}]}, {"type": "section", "id": "holdsMessage", "label": {"fr": "Message exceptionnel des réservations", "en": "Message exceptionnel des réservations"}, "fields": [{"key": "holdsMessage.enabled", "type": "boolean", "label": {"fr": "Afficher ce message exceptionnel", "en": "Afficher ce message exceptionnel"}}, {"key": "holdsMessage.text", "type": "textarea", "label": {"fr": "Message", "en": "Message"}}]}, {"type": "section", "id": "scanner", "label": {"fr": "Lecture de codes-barres par caméra", "en": "Lecture de codes-barres par caméra"}, "fields": [{"key": "scanner.enabled", "type": "boolean", "label": {"fr": "Proposer la caméra sur mobile", "en": "Proposer la caméra sur mobile"}}, {"key": "scanner.targets", "type": "textarea", "label": {"fr": "Identifiants des champs, un par ligne", "en": "Identifiants des champs, un par ligne"}, "help": {"fr": "HTTPS et autorisation caméra nécessaires. Le code est saisi sans validation automatique.", "en": "HTTPS and camera permission required. No automatic submission."}}]}, {"type": "section", "id": "suggestion", "label": {"fr": "Suggestions", "en": "Suggestions"}, "fields": [{"key": "hideSuggestion.enabled", "type": "boolean", "label": {"fr": "Masquer le bouton Nouvelle suggestion", "en": "Masquer le bouton Nouvelle suggestion"}}]}]};
 const pickerKeys=new Set(['print.target','concern.source','concern.after','transferInfo.target','transferInfo.modal','tree.target']);
 for(const section of moduleDefinition.schema)for(const field of section.fields||[])if(pickerKeys.has(field.key)){field.type='elementPicker';field.allowManual=true;field.manualAlways=true;field.pick=ctx=>PMKConfig.elementPicker.pickForConfig({moduleId:id,targetUrl:location.pathname,rootObject:ctx.rootObject,fieldPath:ctx.fieldPath,persistAfterPick:false,options:{rootSelector:'body'}});}
 moduleDefinition.schema.find(section=>section.id==='shuttle').fields.push({type:'custom',render:makeSchedulePreview});
 moduleDefinition.schema.find(section=>section.id==='scanner').fields.push(scannerField,{type:'custom',render:makeTargetPreview});
 moduleDefinition.validate=config=>{const schedule=scheduleRows(config?.shuttle?.schedule??'');if(!schedule.valid)return {ok:false,message:schedule.error};for(const item of targetDiagnostics(config,document))if(!item.valid)return {ok:false,message:'Cible invalide pour « '+item.label+' » : '+item.selector};return {ok:true};};
 PMKConfig.registerModule(moduleDefinition);
 window.PMKLegacyOptions={ready:PMKConfig.getConfig(id),defaults,diagnostics:Object.freeze({scheduleRows,targetDiagnostics,cameraCapabilities})};
})();

;window.PMKNonPlugin.loaded.push("000-pmk-settings-legacy.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-settings-legacy.js: "+error.message); console.error("[PMK] 000-pmk-settings-legacy.js",error); };
try {
/* Outils de contrôle communs : lecture seule jusqu’à une action explicite.
   Les confirmations, le ciblage et les requêtes restent ceux du socle PMK. */
(function () {
  'use strict';
  if (window.PMKWorkbench) return;
  const forbidden = new Set(['__proto__', 'prototype', 'constructor']);
  const sensitive = /password|secret|token|api.?key|credential/i;
  const undo = new Map();
  const openPanels = new Set();
  const clone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (object(value)) return Object.fromEntries(Object.keys(value).filter(k=>!forbidden.has(k)).sort().map(k=>[k,canonical(value[k])]));
    return value;
  }
  const equal = (a,b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
  function differences(before, after, path=[], out=[]) {
    if (equal(before,after)) return out;
    if (object(before) && object(after) && path.length<20) {
      for (const key of new Set([...Object.keys(before),...Object.keys(after)])) {
        if (!forbidden.has(key)) differences(before[key],after[key],[...path,key],out);
      }
    } else out.push({path, before:clone(before), after:clone(after), resettable:before!==undefined && !Array.isArray(before) && !Array.isArray(after) && !object(before) && !object(after)});
    return out;
  }
  function display(value,path=[]) {
    if (path.some(key=>sensitive.test(key))) return 'Valeur confidentielle masquée';
    if (value===undefined) return 'Non défini';
    const raw=typeof value==='string'?value:JSON.stringify(value);
    return raw.length>600?raw.slice(0,600)+'…':raw;
  }
  function safeUrl(value, options={}) {
    const url=new URL(String(value),location.href);
    if(!(options.protocols||['http:','https:']).includes(url.protocol)||url.username||url.password)throw new Error('Adresse non autorisée');
    if(options.sameOrigin && url.origin!==location.origin)throw new Error('Adresse extérieure à ce Koha');
    if(options.hosts && !options.hosts.includes(url.hostname))throw new Error('Fournisseur non autorisé');
    return url;
  }
  function urlSummary(value) {
    const url=safeUrl(value), parameters=[];
    for(const [key,value]of [...url.searchParams]){parameters.push({name:key,value:sensitive.test(key)?'Masqué':value});if(sensitive.test(key))url.searchParams.set(key,'MASQUE');}
    return {href:url.href,origin:url.origin,external:url.origin!==location.origin,parameters};
  }
  function renderTemplate(template, context, options={}) {
    let invalid=false;
    const rendered=String(template||'').trim().replace(/\{([a-z0-9_]+)\}/gi,(_,token)=>{
      const key=options.uppercase?token.toUpperCase():token;
      const raw=options.rawTokens?.includes(key)||key.endsWith('_RAW');
      const name=key.endsWith('_RAW')?key.slice(0,-4):key;
      if(!Object.prototype.hasOwnProperty.call(context,name)){invalid=true;return '';}
      const value=String(context[name]??'');
      if(!value&&(options.required||[]).includes(name))invalid=true;
      return raw||options.encode===false?value:encodeURIComponent(value);
    });
    if(invalid||!rendered||/\{[a-z0-9_]+\}/i.test(rendered))return null;
    try {const url=safeUrl(rendered,{protocols:options.protocols});return options.absolute?url.href:rendered;}catch(_){return null;}
  }
  const linkDescriptions=new WeakMap();
  function restoreLinkDescription(anchor){const original=linkDescriptions.get(anchor);if(!original)return;for(const [name,value]of Object.entries(original)){if(value===null)anchor.removeAttribute(name);else anchor.setAttribute(name,value);}linkDescriptions.delete(anchor);delete anchor.dataset.pmkLinkTitle;}
  function describeLink(anchor) {
    if(!anchor?.getAttribute('href'))return;
    try {
      const url=safeUrl(anchor.href,{protocols:['http:','https:','mailto:','tel:','ftp:']}),en=window.PMKConfig?.getLanguage?.()==='en';
      const info=['http:','https:'].includes(url.protocol)?urlSummary(url.href):{href:url.href,parameters:[]};
      const label=(en?'Destination: ':'Destination : ')+info.href+(info.parameters.length?'\n'+(en?'Parameters sent: ':'Paramètres transmis : ')+info.parameters.map(p=>p.name+' = '+p.value).join(' ; '):'');
      if(!linkDescriptions.has(anchor))linkDescriptions.set(anchor,{title:anchor.getAttribute('title'),'aria-description':anchor.getAttribute('aria-description')});
      if(!anchor.dataset.pmkLinkTitle)anchor.dataset.pmkLinkTitle=anchor.title||' ';
      anchor.title=[anchor.dataset.pmkLinkTitle.trim(),label].filter(Boolean).join('\n');
      anchor.setAttribute('aria-description',label);
      return info;
    }catch(_){return null;}
  }
  // Shared text ownership: explicit user labels override module presentation defaults.
  const labelLayers = new Map();
  function labelNode(element) {
    if(element?.nodeType===Node.TEXT_NODE)return element;
    if(!element?.querySelector)return null;
    const title=element.querySelector('.dt-column-title, .label');
    if(title)return labelNode(title);
    const own=[...element.childNodes].find(node=>node.nodeType===Node.TEXT_NODE && node.data.trim());
    if(own)return own;
    const simple=[...element.children].find(child=>!child.matches('button,input,select,textarea,i,img,svg,.fa,[data-pmk-ui-injected]') && !child.children.length && child.textContent.trim());
    return simple ? labelNode(simple) : null;
  }
  function renderLabel(node,state) {
    if(node.data!==state.last)state.base=node.data;
    const winner=[...state.layers.values()].sort((a,b)=>b.priority-a.priority || a.owner.localeCompare(b.owner))[0];
    const value=winner?winner.value:state.base;
    if(node.data!==value)node.data=value;
    state.last=value;
    if(!winner)labelLayers.delete(node);
  }
  const labels={
    claim(element,value,options) {
      const node=labelNode(element);if(!node)return null;
      let state=labelLayers.get(node);
      if(!state){state={base:node.data,last:node.data,layers:new Map()};labelLayers.set(node,state);}
      const layer={owner:options.owner,title:options.title||options.owner,priority:Number(options.priority)||0,value:String(value)};
      state.layers.set(layer.owner,layer);renderLabel(node,state);
      return ()=>{if(state.layers.get(layer.owner)!==layer)return;state.layers.delete(layer.owner);renderLabel(node,state);};
    },
    conflicts(root=document) {
      return [...labelLayers].filter(([node,state])=>root.contains(node) && state.layers.size>1 && new Set([...state.layers.values()].map(layer=>layer.value)).size>1).map(([node,state])=>{
        const layers=[...state.layers.values()].sort((a,b)=>b.priority-a.priority || a.owner.localeCompare(b.owner));
        return {value:node.data,winner:layers[0].title,owners:layers.map(layer=>layer.title)};
      });
    }
  };
  function contrast(foreground,background) {
    const rgb=value=>{const match=String(value||'').match(/^#([a-f0-9]{3}|[a-f0-9]{6})$/i);if(!match)return null;const h=match[1].length===3?[...match[1]].map(c=>c+c).join(''):match[1];return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4));};
    const a=rgb(foreground),b=rgb(background);if(!a||!b)return null;
    const luminance=c=>c[0]*.2126+c[1]*.7152+c[2]*.0722,x=luminance(a),y=luminance(b);
    return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);
  }
  function pageMatches(value) {
    if(!value||value==='*')return true;
    try {const expected=new URL(value,location.origin);return expected.pathname===location.pathname && [...expected.searchParams].every(([k,v])=>new URL(location.href).searchParams.get(k)===v);}catch(_){return false;}
  }
  function diagnose(config, root=document) {
    const rows=[], targets=new Map(),matchedNodes=new WeakMap(); let visited=0;
    function visit(value,path=[],scope=true,active=true) {
      if(++visited>12000||path.length>18)return;
      if(Array.isArray(value)){value.forEach((row,i)=>visit(row,[...path,String(i)],scope,active));return;}
      if(!object(value))return;
      const localScope=scope && (value.allPages===true || pageMatches(value.pageUrl || value.pagePath || (typeof value.path==='string'&&value.path.startsWith('/cgi-bin/')?value.path:null)));
      const localActive=active && value.enabled!==false;
      const ratio=contrast(value.textColor||value.color||value.linkColor,value.backgroundColor||value.textBackgroundColor||value.background||value.linkBackground);
      if(localScope&&localActive&&ratio!==null&&ratio<4.5)rows.push({path,kind:'contrast',state:'review',message:'Contraste texte/fond : '+ratio.toFixed(2)+' ; vérifier la lisibilité (4,5 conseillé pour du texte courant).'});
      for(const [key,entry]of Object.entries(value)) {
        if(forbidden.has(key)||sensitive.test(key))continue;
        const here=[...path,key];
        if(typeof entry==='string'&&entry.trim()&&(/selector/i.test(key)||(/^(target|anchor|root|source|after|before)$/i.test(key)&&(/[#.\[ >:+~,*]/.test(entry)||/^(body|main|table|form|h[1-6])$/.test(entry))))&&!/^https?:|^\/|^\d+$/.test(entry)&&!/[{}]/.test(entry)) {
          try {
            if(!localScope||!localActive){rows.push({path:here,kind:'target',state:'untested',message:localActive?'À vérifier sur la page concernée':'Règle désactivée'});continue;}
            const nodes=root.querySelectorAll(entry),count=nodes.length;
            const overlaps=new Set();for(const node of [...nodes].slice(0,200)){const prior=matchedNodes.get(node);if(prior&&prior.selector!==entry)overlaps.add(prior.path.join(' / '));else matchedNodes.set(node,{selector:entry,path:here});}
            if(overlaps.size)rows.push({path:here,kind:'overlap',state:'review',message:'Éléments également ciblés par '+[...overlaps].join(', ')+'. Vérifier les effets et la priorité des règles.'});
            rows.push({path:here,kind:'target',state:count?'ok':'missing',message:count+' élément(s) trouvé(s) sur cette page',selector:entry});
            const prior=targets.get(entry);if(prior)rows.push({path:here,kind:'overlap',state:'review',message:'Cible également utilisée par '+prior.join(' / ')+'. Vérifier l’ordre et les effets.'});else targets.set(entry,here);
          }catch(_){rows.push({path:here,kind:'target',state:'invalid',message:'Sélecteur invalide'});}
        } else if(typeof entry==='string'&&entry.trim()&&/url|href|endpoint/i.test(key)&&!/[{}]/.test(entry)) {
          try {const info=urlSummary(entry);rows.push({path:here,kind:'url',state:info.external?'external':'ok',message:info.external?'Destination externe : '+info.origin:'Destination de ce Koha',url:info.href,parameters:info.parameters});}
          catch(_){rows.push({path:here,kind:'url',state:'invalid',message:'Adresse invalide ou protocole non autorisé'});}
        } else if(/report.*id|^REPORT_/i.test(key)&&(typeof entry==='number'||/^\d+$/.test(String(entry)))) {
          rows.push({path:here,kind:'report',state:Number(entry)>0?'untested':'missing',reportId:Number(entry),message:Number(entry)>0?'Rapport '+entry+' : disponibilité à vérifier':'Rapport non configuré'});
        }
        if(entry && typeof entry==='object')visit(entry,here,localScope,localActive);
      }
    }
    visit(config);
    labels.conflicts(root).forEach(conflict=>rows.push({path:[],kind:'overlap',state:'review',message:'Libellé partagé « '+conflict.value+' » : priorité à '+conflict.winner+'. Autres réglages : '+conflict.owners.slice(1).join(', ')+'.'}));
    return {at:new Date().toISOString(),page:location.pathname+location.search,rows,limited:visited>12000};
  }
  async function checkReports(config,options={}) {
    const ids=[...new Set(diagnose(config).rows.filter(row=>row.kind==='report'&&row.reportId>0).map(row=>row.reportId))];
    const rows=[];
    for(const id of ids.slice(0,50)){
      if(options.signal?.aborted)break;
      try{
        const response=await fetch('/api/v1/contrib/pmk/reports/'+id+'/diagnostic',{credentials:'same-origin',headers:{Accept:'application/json'},signal:options.signal?AbortSignal.any([options.signal,AbortSignal.timeout(8000)]):AbortSignal.timeout(8000)});
        const data=response.ok?await response.json():null;
        rows.push({id,state:response.ok?'ok':response.status===404?'missing':response.status===403?'forbidden':'unavailable',name:data?.name||'',parameters:data?.parameters||[],executed:false});
      }catch(error){if(options.signal?.aborted)break;rows.push({id,state:'unavailable',executed:false});}
    }
    return {rows,limited:ids.length>50};
  }
  function node(tag,text,className) {const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el;}
  function button(text,action) {const el=node('button',text,'btn btn-default btn-sm');el.type='button';el.addEventListener('click',action);return el;}
  async function confirm(options={}) {
    const changes=(options.changes||[]).map(row=>row.label+' : '+display(row.before)+' → '+display(row.after)).join('\n');
    return window.PMKConfig.confirmAction({title:options.title,message:[options.summary,changes].filter(Boolean).join('\n\n'),confirmLabel:options.confirmLabel||'Confirmer',danger:options.danger!==false});
  }
  async function batch(entries, action, options={}) {
    const result={rows:[],completed:0,failed:0,cancelled:false};
    const previous=new Map((options.previous?.rows||[]).map(row=>[row.key,row]));
    const keys=entries.map((entry,i)=>String(options.key?options.key(entry):i));
    if(new Set(keys).size!==keys.length)throw new Error('Chaque ligne du traitement doit avoir un identifiant unique.');
    for(let i=0;i<entries.length;i++) {
      if(options.signal?.aborted){result.cancelled=true;break;}
      const entry=entries[i],key=keys[i],old=previous.get(key);
      if(options.failedOnly&&old?.ok){result.rows.push(old);result.completed++;continue;}
      let row;
      try {row={key,ok:true,value:await action(entry,i)};result.completed++;}
      catch(error){row={key,ok:false,error:String(error.message||error)};result.failed++;}
      result.rows.push(row);options.onProgress?.({...result,rows:result.rows.slice(),total:entries.length});
    }
    return result;
  }
  function mountConfigPanel(ctx) {
    const panel=node('details',undefined,'pmk-workbench-panel');
    panel.appendChild(node('summary','Vérifier mes réglages et leurs cibles'));
    const content=node('div');panel.appendChild(content);
    const labelMap=new Map();
    function labels(fields,prefix=[]){for(const field of fields||[]){const here=field.key?[...prefix,...field.key.split('.')]:prefix;if(field.label&&field.key)labelMap.set(here.join('.'),typeof field.label==='string'?field.label:(field.label.fr||field.label.en));if(field.fields)labels(field.fields,here);}}
    labels(ctx.definition.schema);
    const label=path=>labelMap.get(path.join('.'))||path.join(' / ');
    const status=node('p');status.setAttribute('role','status');
    function render() {
      content.replaceChildren();
      const custom=differences(ctx.definition.defaults||{},ctx.draft),changed=differences(ctx.saved||{},ctx.draft);
      content.appendChild(node('p',custom.length+' personnalisation(s) ; '+changed.length+' changement(s) non enregistré(s). Les vérifications ne modifient aucune donnée.'));
      let page=0;
      const table=node('table',undefined,'table table-striped table-sm');const thead=node('thead'),head=node('tr');['Réglage','Valeur par défaut','Votre valeur','Action'].forEach(t=>{const th=node('th',t);th.scope='col';head.appendChild(th);});thead.appendChild(head);table.appendChild(thead);const body=node('tbody');table.appendChild(body);
      function more(){custom.slice(page,page+30).forEach(row=>{const tr=node('tr');tr.append(node('td',label(row.path)),node('td',display(row.before,row.path)),node('td',display(row.after,row.path)));const cell=node('td');if(row.resettable&&!row.path.some(k=>sensitive.test(k)))cell.appendChild(button('Reprendre cette valeur',async()=>{
        if(!await confirm({title:'Reprendre une valeur par défaut',changes:[{label:label(row.path),before:row.after,after:row.before}],summary:'Seul ce réglage sera modifié dans le brouillon. Enregistrez ensuite pour appliquer.'}))return;
        let target=ctx.draft;for(const key of row.path.slice(0,-1)){if(forbidden.has(key)||!object(target[key]))return;target=target[key];}
        const key=row.path.at(-1);if(!key||forbidden.has(key))return;
        undo.set(ctx.moduleId,{path:row.path,before:clone(target[key]),after:clone(row.before)});target[key]=clone(row.before);ctx.changed();render();
      }));else cell.textContent='À modifier dans les options ci-dessous';tr.appendChild(cell);body.appendChild(tr);});page+=30;moreButton.hidden=page>=custom.length;}
      const moreButton=button('Afficher les suivantes',more);more();content.append(table,moreButton);
      const record=undo.get(ctx.moduleId);
      if(record)content.appendChild(button('Annuler la dernière remise à défaut',()=>{let target=ctx.draft;for(const key of record.path.slice(0,-1))target=target?.[key];const key=record.path.at(-1);if(!target||!equal(target[key],record.after)){status.textContent='Ce réglage a été modifié depuis. Annulation automatique refusée.';return;}target[key]=clone(record.before);undo.delete(ctx.moduleId);ctx.changed();render();}));
      const output=node('div');content.appendChild(button('Contrôler les cibles sur cette page',()=>{output.replaceChildren();const result=diagnose(ctx.draft);output.appendChild(node('p','Vérifié le '+new Date(result.at).toLocaleString()+' sur '+result.page+'. Une cible absente peut dépendre du contenu affiché.'));for(const row of result.rows){const line=node('p',label(row.path)+' — '+row.message);if(row.url){const code=node('code',row.url);line.append(' ',code);}output.appendChild(line);}if(!result.rows.length)output.appendChild(node('p','Aucune cible ou adresse contrôlable automatiquement pour ces réglages.'));}));content.append(output,status);
      if(window.PMKPlugin)content.appendChild(button('Vérifier les rapports configurés',async event=>{
        const trigger=event.currentTarget;trigger.disabled=true;status.textContent='Vérification des rapports…';
        try{const result=await checkReports(ctx.draft);output.replaceChildren();for(const row of result.rows){const descriptions={ok:'disponible : '+row.name,missing:'introuvable',forbidden:'accès refusé',unavailable:'vérification indisponible'};output.appendChild(node('p','Rapport '+row.id+' — '+descriptions[row.state]+(row.parameters.length?' · Paramètres : '+row.parameters.join(', '):'')));}status.textContent=(result.rows.length?'Métadonnées vérifiées. Aucun rapport exécuté ; les colonnes et le contenu restent à vérifier avec les données de ce Koha.':'Aucun rapport configuré à vérifier.')+(result.limited?' Contrôle limité aux 50 premiers rapports.':'');}catch(_){status.textContent='Vérification indisponible. Aucun réglage modifié.';}finally{trigger.disabled=false;}
      }));
    }
    panel.open=openPanels.has(ctx.moduleId);if(panel.open)render();
    panel.addEventListener('toggle',()=>{if(!panel.isConnected)return;if(panel.open){openPanels.add(ctx.moduleId);render();}else openPanels.delete(ctx.moduleId);});
    return panel;
  }
  const api={version:'1.0.0',differences,diagnose,checkReports,safeUrl,urlSummary,renderTemplate,describeLink,restoreLinkDescription,contrast,labels,confirm,batch,mountConfigPanel,display,equal};
  window.PMKWorkbench=api;
  window.PMKConfig?.services.register('workbench',api);
})();

;window.PMKNonPlugin.loaded.push("000-pmk-workbench.js");
} catch (error) { window.PMKNonPlugin.errors.push("000-pmk-workbench.js: "+error.message); console.error("[PMK] 000-pmk-workbench.js",error); };
try {
/* ============================================================
   PimpMyKoha - Pré-plugin
   Fichier : 001-modification-entete-issuehistory.js
   Version : 3.6.0-isolated

   Module PMK : table-labels
   Nom UI     : Libellés et éléments d'interface

   Évolution :
   - conserve le même MODULE_ID que l'ancien module "Libellés des tableaux" ;
   - migre automatiquement l'ancienne structure pages > tables > columns ;
   - utilise UNE SEULE liste de règles pour les tableaux et les autres éléments ;
   - permet de cibler n'importe quel élément Koha avec le picker commun PMK ;
   - permet de modifier texte, icône/image, apparence, lien ou visibilité ;
   - intègre les comportements historiques des scripts 040, 020 et 045 ;
   - absorbe les actions de visibilité du 020 (normal / masquer / afficher / désactiver) ;
   - délègue aperçu, pipette et prévisualisation live au moteur visuel commun du 000 ;
   - conserve le traitement robuste des colonnes de issuehistory.pl ;
   - aucune dépendance directe à Firestore dans la logique métier ;
   - aucun moteur de picker local : le picker commun de 000 est utilisé.
   - ajoute une gestion superlibrarian des éléments masqués : masqué, filigrane ou affichage forcé ;
   - ajoute un mode global de prévisualisation en filigrane pour les superlibrarians.
   - ajoute, pour chaque règle, une option « Appliquer sur toutes les pages » sans perdre la page de référence.
   ============================================================ */

(function () {
    "use strict";

    if (window.__PMK_001_UI_LABELS__) return;
    window.__PMK_001_UI_LABELS__ = true;

    const MODULE_ID = "table-labels";
    const SCHEMA_VERSION = 5;
    const ISSUEHISTORY_PATH = "/cgi-bin/koha/catalogue/issuehistory.pl";
    const ISSUEHISTORY_TABLE = "#table_issues";
    const MAINPAGE_PATH = "/cgi-bin/koha/mainpage.pl";
    const HOLDSQUEUE_PATH = "/cgi-bin/koha/circ/view_holdsqueue.pl";
    const REQUEST_PATH = "/cgi-bin/koha/reserve/request.pl";

    const KNOWN_ORDER_WITH_PATRON = [
        "patron",
        "barcode",
        "checked_out_from",
        "checked_out_by",
        "renewed",
        "checkout_on",
        "due_date",
        "checkin_on"
    ];

    const KNOWN_ORDER_WITHOUT_PATRON = [
        "barcode",
        "checked_out_from",
        "checked_out_by",
        "renewed",
        "checkout_on",
        "due_date",
        "checkin_on"
    ];

    const TRACKED_ELEMENTS = new Set();
    const ORIGINAL_STATE = new WeakMap();

    let currentConfig = null;
    let bootedWithCore = false;
    let runtimeStarted = false;
    let domObserver = null;
    let reapplyTimer = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function cleanText(value) {
        return String(value == null ? "" : value).trim();
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const lang = (document.documentElement.getAttribute("lang") || navigator.language || "").toLowerCase();
        return lang.startsWith("fr") ? "fr" : "en";
    }

    function i18n(fr, en) {
        return detectLanguage() === "fr" ? fr : en;
    }

    function makeId(prefix) {
        const p = cleanText(prefix) || "ui";
        if (window.crypto && typeof window.crypto.randomUUID === "function") {
            return p + "-" + window.crypto.randomUUID();
        }
        return p + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
    }

    function uniqueId(base, used) {
        let id = cleanText(base) || makeId("ui");
        if (!used.has(id)) {
            used.add(id);
            return id;
        }
        let n = 2;
        while (used.has(id + "-" + n)) n += 1;
        id = id + "-" + n;
        used.add(id);
        return id;
    }

    function issuehistorySelector(columnId) {
        return ISSUEHISTORY_TABLE + ' thead tr:first-child th[data-pmk-colname="' + columnId + '"]';
    }

    const RULE_TEMPLATE = {
        id: "",
        enabled: true,
        label: "",
        allPages: false,
        pagePath: "",
        selector: "",
        targetName: "",
        matchCount: null,

        changeText: false,
        textFr: "",
        textEn: "",
        customizeTextStyle: false,
        textSizePx: 14,
        textColor: "#212529",
        textHoverColor: "#000000",
        textBold: false,
        textItalic: false,
        textUnderline: false,
        textBackgroundColor: "",
        textBorderRadiusPx: 0,

        changeIcon: false,
        iconType: "fa",
        iconClass: "fa fa-fw fa-book",
        imageUrl: "",
        iconPosition: "before",
        iconSizePx: 16,
        iconColor: "#495057",
        iconHoverColor: "#212529",

        changeLink: false,
        href: "",
        openInNewTab: false,

        visibilityAction: "unchanged",
        visibilityScope: "self",
        superlibrarianHiddenMode: "inherit",
        hidden: false
    };

    const DEFAULT_CONFIG = {
        enabled: true,
        observeDom: true,
        observeDelay: 120,
        superlibrarianPreviewHidden: false,
        migrations: {
            /*
             * false dans les valeurs brutes : normalizeConfig() passe ce marqueur
             * à true dès que les deux presets historiques du 040 ont été contrôlés.
             * Une suppression volontaire ultérieure reste donc respectée.
             */
            script040Imported: false,
            script020Imported: false,
            script045Imported: false
        },
        rules: [
            {
                id: "issuehistory-due-date",
                enabled: true,
                label: "Historique notice — Retour prévu",
                pagePath: ISSUEHISTORY_PATH,
                selector: issuehistorySelector("due_date"),
                targetName: "Colonne due_date",
                matchCount: 1,
                changeText: true,
                textFr: "Retour prévu",
                textEn: "Expected return"
            },
            {
                id: "issuehistory-checkin-on",
                enabled: true,
                label: "Historique notice — Retour effectif",
                pagePath: ISSUEHISTORY_PATH,
                selector: issuehistorySelector("checkin_on"),
                targetName: "Colonne checkin_on",
                matchCount: 1,
                changeText: true,
                textFr: "Retour effectif",
                textEn: "Actual return"
            },
            {
                id: "mainpage-item-lists",
                enabled: true,
                label: "Accueil — Listes d'exemplaires",
                pagePath: MAINPAGE_PATH,
                selector: "a.icon_course_reserves",
                targetName: "Raccourci Réserves de cours",
                matchCount: 1,
                changeText: true,
                textFr: "Listes d'exemplaires",
                textEn: "Item lists",
                changeIcon: true,
                iconType: "fa",
                iconClass: "fa fa-fw fa-book",
                iconPosition: "before",
                iconSizePx: 16
            },
            {
                id: "mainpage-biblio-lists",
                enabled: true,
                label: "Accueil — Listes de notices",
                pagePath: MAINPAGE_PATH,
                selector: "a.icon_general.icon_lists",
                targetName: "Raccourci Listes",
                matchCount: 1,
                changeText: true,
                textFr: "Listes de notices",
                textEn: "Record lists",
                changeIcon: true,
                iconType: "fa",
                iconClass: "fa fa-fw fa-book",
                iconPosition: "before",
                iconSizePx: 16
            },
            {
                id: "legacy-020-hide-pendingreserves-on-holdsqueue",
                enabled: true,
                label: "File des réservations — Masquer « Réservations à traiter »",
                pagePath: HOLDSQUEUE_PATH,
                selector: '.circ-nav-menu a[href="/cgi-bin/koha/circ/pendingreserves.pl"]',
                targetName: "Réservations à traiter",
                matchCount: 1,
                visibilityAction: "hide",
                visibilityScope: "closest-li"
            },
            {
                id: "legacy-045-hide-holds-to-place-count",
                enabled: true,
                label: "Réservation — Masquer le nombre de réservations à placer",
                pagePath: REQUEST_PATH,
                selector: "#holds_to_place_count",
                targetName: "Nombre de réservations à placer",
                matchCount: 1,
                visibilityAction: "hide",
                visibilityScope: "closest-li"
            }
        ].map(function (rule) {
            return Object.assign({}, RULE_TEMPLATE, rule);
        })
    };

    function mergeRule(rule, index) {
        const merged = Object.assign({}, RULE_TEMPLATE, rule || {});
        merged.id = cleanText(merged.id) || makeId("ui-rule");
        merged.label = cleanText(merged.label) || (i18n("Personnalisation ", "Customization ") + ((index || 0) + 1));

        /*
         * allPages est indépendant de pagePath : la page de référence reste mémorisée
         * pour le picker et redevient immédiatement la restriction si l'option est décochée.
         * Compatibilité : une ancienne règle enregistrée avec pagePath="*" devient globale.
         */
        const hadExplicitAllPages = rule && Object.prototype.hasOwnProperty.call(rule, "allPages");
        const rawPagePath = cleanText(rule && rule.pagePath);
        merged.allPages = hadExplicitAllPages ? rule.allPages === true : rawPagePath === "*";
        merged.pagePath = rawPagePath && rawPagePath !== "*" ? rawPagePath : window.location.pathname;

        merged.selector = cleanText(merged.selector);
        merged.targetName = cleanText(merged.targetName);
        merged.textFr = String(merged.textFr == null ? "" : merged.textFr);
        merged.textEn = String(merged.textEn == null ? "" : merged.textEn);
        merged.iconClass = cleanText(merged.iconClass) || "fa fa-fw fa-book";
        merged.imageUrl = cleanText(merged.imageUrl);
        merged.href = String(merged.href == null ? "" : merged.href).trim();
        merged.iconPosition = merged.iconPosition === "after" ? "after" : "before";
        merged.iconType = ["fa", "image", "none"].includes(merged.iconType) ? merged.iconType : "fa";
        merged.textSizePx = Math.max(8, Math.min(72, Number(merged.textSizePx) || 14));
        merged.textBorderRadiusPx = Math.max(0, Math.min(48, Number(merged.textBorderRadiusPx) || 0));
        merged.iconSizePx = Math.max(8, Math.min(96, Number(merged.iconSizePx) || 16));

        const explicitVisibility = rule && Object.prototype.hasOwnProperty.call(rule, "visibilityAction")
            ? String(rule.visibilityAction || "")
            : "";
        merged.visibilityAction = ["unchanged", "hide", "show", "disable"].includes(explicitVisibility)
            ? explicitVisibility
            : (rule && rule.hidden === true ? "hide" : "unchanged");
        merged.visibilityScope = ["self", "closest-li", "closest-tr"].includes(String(merged.visibilityScope || ""))
            ? String(merged.visibilityScope)
            : "self";
        merged.superlibrarianHiddenMode = ["inherit", "hidden", "watermark", "visible"].includes(String(merged.superlibrarianHiddenMode || ""))
            ? String(merged.superlibrarianHiddenMode)
            : "inherit";
        merged.hidden = merged.visibilityAction === "hide";
        return merged;
    }

    function migrateLegacyPages(config) {
        if (!config || !Array.isArray(config.pages) || !config.pages.length) return null;

        const rules = [];
        const used = new Set();

        config.pages.forEach(function (page) {
            if (!page || !Array.isArray(page.tables)) return;
            page.tables.forEach(function (table) {
                if (!table || !Array.isArray(table.columns)) return;
                table.columns.forEach(function (column) {
                    if (!column || !column.id) return;
                    let selector = "";
                    if (cleanText(page.path) === ISSUEHISTORY_PATH && cleanText(table.selector) === ISSUEHISTORY_TABLE) {
                        selector = issuehistorySelector(column.id);
                    } else if (cleanText(table.selector)) {
                        selector = cleanText(table.selector) + ' [data-colname="' + String(column.id).replace(/"/g, '\\"') + '"]';
                    }

                    const baseId = cleanText(page.id) + "-" + cleanText(table.id) + "-" + cleanText(column.id);
                    rules.push(mergeRule({
                        id: uniqueId(baseId, used),
                        enabled: page.enabled !== false && table.enabled !== false && column.enabled !== false,
                        label: cleanText(page.labelFr) + " — " + cleanText(column.labelFr || column.id),
                        pagePath: cleanText(page.path) || ISSUEHISTORY_PATH,
                        selector: selector,
                        targetName: "Colonne " + column.id,
                        changeText: true,
                        textFr: column.labelFr || "",
                        textEn: column.labelEn || column.labelFr || ""
                    }, rules.length));
                });
            });
        });

        return rules;
    }

    function hasEquivalentRule(rules, candidate) {
        const list = Array.isArray(rules) ? rules : [];
        const candidateId = cleanText(candidate && candidate.id);
        const candidatePage = cleanText(candidate && candidate.pagePath);
        const candidateSelector = cleanText(candidate && candidate.selector);
        return list.some(function (rule) {
            if (!rule) return false;
            if (candidateId && cleanText(rule.id) === candidateId) return true;
            return Boolean(
                candidatePage && candidateSelector &&
                cleanText(rule.pagePath) === candidatePage &&
                cleanText(rule.selector) === candidateSelector
            );
        });
    }

    function rulesMatchDefaults(rules) {
        if (!Array.isArray(rules) || rules.length !== DEFAULT_CONFIG.rules.length) return false;
        try {
            return JSON.stringify(rules) === JSON.stringify(DEFAULT_CONFIG.rules);
        } catch (_) {
            return false;
        }
    }

    function normalizeConfig(config) {
        const source = config && typeof config === "object" ? config : {};
        const legacyRules = migrateLegacyPages(source);
        const suppliedRules = Array.isArray(source.rules) ? source.rules : null;

        let baseRules;
        /*
         * PMK fusionne les defaults AVANT normalize(). Sur un ancien document
         * pages > tables > columns, source.rules peut donc être la liste des
         * quatre defaults injectée par le merge. Dans ce cas on migre bien les
         * anciennes colonnes au lieu de les écraser par ces defaults.
         */
        if (legacyRules && (!suppliedRules || rulesMatchDefaults(suppliedRules))) {
            baseRules = legacyRules;
        } else if (suppliedRules) {
            baseRules = suppliedRules;
        } else {
            baseRules = clone(DEFAULT_CONFIG.rules);
        }

        const used = new Set();
        const rules = [];
        baseRules.forEach(function (rule, index) {
            const merged = mergeRule(rule, index);
            merged.id = uniqueId(merged.id, used);
            rules.push(merged);
        });

        const migrations = source.migrations && typeof source.migrations === "object"
            ? Object.assign({}, source.migrations)
            : {};

        /*
         * Migrations ciblées des anciens petits scripts désormais absorbés.
         * Chaque famille possède son propre marqueur afin qu'une suppression
         * volontaire d'une règle reste ensuite respectée.
         */
        if (migrations.script040Imported !== true) {
            DEFAULT_CONFIG.rules.filter(function (preset) {
                return preset.id === "mainpage-item-lists" || preset.id === "mainpage-biblio-lists";
            }).forEach(function (preset) {
                if (hasEquivalentRule(rules, preset)) return;
                const cloned = mergeRule(clone(preset), rules.length);
                cloned.id = uniqueId(cloned.id, used);
                rules.push(cloned);
            });
            migrations.script040Imported = true;
        }

        if (migrations.script020Imported !== true) {
            DEFAULT_CONFIG.rules.filter(function (preset) {
                return preset.id === "legacy-020-hide-pendingreserves-on-holdsqueue";
            }).forEach(function (preset) {
                if (hasEquivalentRule(rules, preset)) return;
                const cloned = mergeRule(clone(preset), rules.length);
                cloned.id = uniqueId(cloned.id, used);
                rules.push(cloned);
            });
            migrations.script020Imported = true;
        }

        if (migrations.script045Imported !== true) {
            DEFAULT_CONFIG.rules.filter(function (preset) {
                return preset.id === "legacy-045-hide-holds-to-place-count";
            }).forEach(function (preset) {
                if (hasEquivalentRule(rules, preset)) return;
                const cloned = mergeRule(clone(preset), rules.length);
                cloned.id = uniqueId(cloned.id, used);
                rules.push(cloned);
            });
            migrations.script045Imported = true;
        }

        return {
            enabled: source.enabled !== false,
            observeDom: source.observeDom !== false,
            observeDelay: Math.max(25, Math.min(2000, Number(source.observeDelay) || DEFAULT_CONFIG.observeDelay)),
            superlibrarianPreviewHidden: source.superlibrarianPreviewHidden === true,
            migrations: migrations,
            rules: rules
        };
    }

    function pageMatches(rule) {
        if (rule && rule.allPages === true) return true;
        const path = cleanText(rule && rule.pagePath);
        if (!path || path === "*") return true;
        return window.location.pathname === path;
    }

    function safeQueryAll(selector) {
        const s = cleanText(selector);
        if (!s) return [];
        try {
            return Array.from(document.querySelectorAll(s));
        } catch (_err) {
            return [];
        }
    }

    function selectorCount(selector) {
        return safeQueryAll(selector).length;
    }

    function mapIssuehistoryHeaders() {
        if (window.location.pathname !== ISSUEHISTORY_PATH) return;
        const table = document.querySelector(ISSUEHISTORY_TABLE);
        if (!table) return;
        const headers = Array.from(table.querySelectorAll("thead tr:first-child th"));
        if (!headers.length) return;

        headers.forEach(function (th) {
            const colname = th.getAttribute("data-colname");
            if (colname) th.setAttribute("data-pmk-colname", colname);
        });

        let order = null;
        if (headers.length === KNOWN_ORDER_WITH_PATRON.length) order = KNOWN_ORDER_WITH_PATRON;
        else if (headers.length === KNOWN_ORDER_WITHOUT_PATRON.length) order = KNOWN_ORDER_WITHOUT_PATRON;
        if (!order) return;

        headers.forEach(function (th, index) {
            if (!th.getAttribute("data-pmk-colname") && order[index]) {
                th.setAttribute("data-pmk-colname", order[index]);
            }
        });
    }

    function rememberState(element) {
        if (ORIGINAL_STATE.has(element)) return ORIGINAL_STATE.get(element);
        const state = {
            display: element.style.display,
            hidden: element.hidden,
            ariaHidden: element.getAttribute("aria-hidden"),
            ariaDisabled: element.getAttribute("aria-disabled"),
            tabindex: element.getAttribute("tabindex"),
            disabled: ("disabled" in element) ? Boolean(element.disabled) : null,
            opacity: element.style.opacity,
            cursor: element.style.cursor,
            pointerEvents: element.style.pointerEvents,
            color: element.style.color,
            fontSize: element.style.fontSize,
            fontWeight: element.style.fontWeight,
            fontStyle: element.style.fontStyle,
            textDecoration: element.style.textDecoration,
            backgroundColor: element.style.backgroundColor,
            borderRadius: element.style.borderRadius,
            hrefHad: element.hasAttribute("href"),
            href: element.getAttribute("href"),
            targetHad: element.hasAttribute("target"),
            target: element.getAttribute("target"),
            relHad: element.hasAttribute("rel"),
            rel: element.getAttribute("rel"),
            classes: [],
            textChanges: [],
            sharedTextReleases: [],
            hiddenIcons: [],
            injected: []
        };
        ORIGINAL_STATE.set(element, state);
        TRACKED_ELEMENTS.add(element);
        return state;
    }

    function rememberClass(element, className, state) {
        if (!className || element.classList.contains(className)) return;
        element.classList.add(className);
        state.classes.push(className);
    }

    function restoreAll() {
        TRACKED_ELEMENTS.forEach(function (element) {
            const state = ORIGINAL_STATE.get(element);
            if (!state) return;

            state.injected.forEach(function (node) {
                if (node && node.parentNode) node.parentNode.removeChild(node);
            });

            state.hiddenIcons.forEach(function (entry) {
                if (entry && entry.node && entry.node.style) entry.node.style.display = entry.display;
            });

            state.sharedTextReleases.slice().reverse().forEach(release => release());

            state.textChanges.slice().reverse().forEach(function (entry) {
                if (!entry || !entry.node) return;
                if (entry.kind === "textNode" && entry.node.nodeType === Node.TEXT_NODE) {
                    entry.node.data = entry.value;
                } else if (entry.kind === "element" && entry.node.nodeType === Node.ELEMENT_NODE) {
                    entry.node.textContent = entry.value;
                }
            });

            state.classes.forEach(function (className) {
                if (element.classList) element.classList.remove(className);
            });

            element.style.display = state.display;
            element.hidden = Boolean(state.hidden);
            if (state.ariaHidden === null) element.removeAttribute("aria-hidden");
            else element.setAttribute("aria-hidden", state.ariaHidden);
            if (state.ariaDisabled === null) element.removeAttribute("aria-disabled");
            else element.setAttribute("aria-disabled", state.ariaDisabled);
            if (state.tabindex === null) element.removeAttribute("tabindex");
            else element.setAttribute("tabindex", state.tabindex);
            if (state.disabled !== null && "disabled" in element) element.disabled = state.disabled;
            element.style.opacity = state.opacity;
            element.style.cursor = state.cursor;
            element.style.pointerEvents = state.pointerEvents;
            element.style.color = state.color;
            element.style.fontSize = state.fontSize;
            element.style.fontWeight = state.fontWeight;
            element.style.fontStyle = state.fontStyle;
            element.style.textDecoration = state.textDecoration;
            element.style.backgroundColor = state.backgroundColor;
            element.style.borderRadius = state.borderRadius;

            if (state.hrefHad) element.setAttribute("href", state.href == null ? "" : state.href);
            else element.removeAttribute("href");

            if (state.targetHad) element.setAttribute("target", state.target == null ? "" : state.target);
            else element.removeAttribute("target");

            if (state.relHad) element.setAttribute("rel", state.rel == null ? "" : state.rel);
            else element.removeAttribute("rel");

            ORIGINAL_STATE.delete(element);
        });
        TRACKED_ELEMENTS.clear();
    }

    function textForRule(rule) {
        const lang = detectLanguage();
        if (lang === "fr") return String(rule.textFr || rule.textEn || "");
        return String(rule.textEn || rule.textFr || "");
    }

    function findSafeTextTarget(element) {
        const dtTitle = element.querySelector && element.querySelector(":scope > .dt-column-header .dt-column-title, :scope > .dt-column-title, .dt-column-title");
        if (dtTitle) return { kind: "element", node: dtTitle };

        const textNode = Array.from(element.childNodes || []).find(function (node) {
            return node.nodeType === Node.TEXT_NODE && cleanText(node.data);
        });
        if (textNode) return { kind: "textNode", node: textNode };

        const children = Array.from(element.children || []);
        const simple = children.find(function (child) {
            if (child.matches("i, img, svg, .fa, [data-pmk-ui-injected]")) return false;
            return child.children.length === 0 && cleanText(child.textContent);
        });
        if (simple) return { kind: "element", node: simple };

        return null;
    }

    function applyText(element, rule, state) {
        if (!rule.changeText) return;
        const value = textForRule(rule);
        const target = findSafeTextTarget(element);
        if (!target) return;

        const common = window.PMKWorkbench?.labels;
        if (common) {
            const original = target.kind === "textNode" ? target.node.data : "";
            const formatted = (original.match(/^\s*/) || [""])[0] + value + (original.match(/\s*$/) || [""])[0];
            const release = common.claim(target.node, formatted, {owner:MODULE_ID,priority:100,title:"Libellés et éléments d’interface"});
            if (release) { state.sharedTextReleases.push(release); return; }
        }

        if (target.kind === "textNode") {
            const original = target.node.data;
            state.textChanges.push({ kind: "textNode", node: target.node, value: original });
            const leading = (original.match(/^\s*/) || [""])[0];
            const trailing = (original.match(/\s*$/) || [""])[0];
            target.node.data = leading + value + trailing;
        } else {
            state.textChanges.push({ kind: "element", node: target.node, value: target.node.textContent });
            target.node.textContent = value;
        }
    }

    function existingVisuals(element) {
        return Array.from(element.children || []).filter(function (child) {
            return child.matches("i, img, svg, .fa, [class*='fa-']") && !child.hasAttribute("data-pmk-ui-injected");
        });
    }

    function normalizeFaClass(value) {
        const raw = cleanText(value) || "fa fa-fw fa-book";
        const classes = raw.split(/\s+/).filter(Boolean);
        const hasFamily = classes.some(function (name) {
            return ["fa", "fas", "far", "fal", "fad", "fab", "fa-solid", "fa-regular", "fa-brands"].includes(name);
        });
        if (!hasFamily) classes.unshift("fa");
        if (!classes.includes("fa-fw")) classes.splice(1, 0, "fa-fw");
        return classes.join(" ");
    }

    function applyIcon(element, rule, state, className) {
        if (!rule.changeIcon) return;

        existingVisuals(element).forEach(function (visual) {
            state.hiddenIcons.push({ node: visual, display: visual.style.display });
            visual.style.display = "none";
        });

        if (rule.iconType === "none") return;

        let visual;
        if (rule.iconType === "image") {
            visual = document.createElement("img");
            visual.src = rule.imageUrl;
            visual.alt = "";
            visual.setAttribute("aria-hidden", "true");
            visual.style.width = rule.iconSizePx + "px";
            visual.style.height = rule.iconSizePx + "px";
            visual.style.objectFit = "contain";
        } else {
            visual = document.createElement("i");
            visual.className = normalizeFaClass(rule.iconClass);
            visual.setAttribute("aria-hidden", "true");
            visual.style.fontSize = rule.iconSizePx + "px";
            visual.style.color = rule.iconColor || "";
        }

        visual.setAttribute("data-pmk-ui-injected", "1");
        visual.setAttribute("data-pmk-ui-icon-rule", className);
        visual.style.display = "inline-block";
        visual.style.verticalAlign = "middle";
        visual.style.transition = "color .15s ease, transform .15s ease, opacity .15s ease";

        if (rule.iconPosition === "after") {
            visual.style.marginLeft = ".35em";
            element.appendChild(visual);
        } else {
            visual.style.marginRight = ".35em";
            element.insertBefore(visual, element.firstChild);
        }
        state.injected.push(visual);
    }

    function cssSafeId(value) {
        return cleanText(value).replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "") || "rule";
    }

    function buildDynamicStyles(config) {
        const id = "pmk-table-labels-dynamic-style";
        let style = document.getElementById(id);
        if (!style) {
            style = document.createElement("style");
            style.id = id;
            document.head.appendChild(style);
        }

        const css = [
            ".pmk-hidden-superlibrarian-preview{outline:2px dashed rgba(108,117,125,.75)!important;outline-offset:2px!important;filter:grayscale(.2);}",
            ".pmk-hidden-superlibrarian-preview *{pointer-events:none!important;}"
        ];
        (config.rules || []).forEach(function (rule) {
            if (!rule || rule.enabled === false || !pageMatches(rule)) return;
            const className = "pmk-ui-rule-" + cssSafeId(rule.id);
            if (rule.customizeTextStyle && rule.textHoverColor) {
                css.push("." + className + ":hover{color:" + rule.textHoverColor + "!important;}");
            }
            if (rule.changeIcon && rule.iconType === "fa" && rule.iconHoverColor) {
                css.push("." + className + ":hover [data-pmk-ui-icon-rule=\"" + className + "\"]{color:" + rule.iconHoverColor + "!important;transform:scale(1.08);}");
            }
            if (rule.changeIcon && rule.iconType === "image") {
                css.push("." + className + ":hover [data-pmk-ui-icon-rule=\"" + className + "\"]{transform:scale(1.08);opacity:.88;}");
            }
        });
        style.textContent = css.join("\n");
    }

    function isSuperlibrarian() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === "function") {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }

        const user = document.querySelector(
            ".loggedinusername[data-is-superlibrarian], " +
            ".loggedinusername.is_superlibrarian, " +
            "#logged-in-info-full .loggedinusername[data-loggedinusername]"
        );
        if (!user) return false;
        if (user.classList.contains("is_superlibrarian")) return true;

        const raw = cleanText(
            user.getAttribute("data-is-superlibrarian") ||
            (user.dataset && user.dataset.isSuperlibrarian) ||
            ""
        );
        return /^(1|true|yes|superlibrarian|is_superlibrarian)$/i.test(raw);
    }

    function effectiveSuperlibrarianHiddenMode(rule) {
        if (!isSuperlibrarian()) return "hidden";

        const configured = String(rule && rule.superlibrarianHiddenMode || "inherit");
        if (configured === "hidden" || configured === "watermark" || configured === "visible") {
            return configured;
        }
        return currentConfig && currentConfig.superlibrarianPreviewHidden === true
            ? "watermark"
            : "hidden";
    }

    function resolveVisibilityTarget(element, rule) {
        if (!element) return null;
        const scope = String(rule && rule.visibilityScope || "self");
        if (scope === "closest-li" && element.closest) return element.closest("li") || element;
        if (scope === "closest-tr" && element.closest) return element.closest("tr") || element;
        return element;
    }

    function applyVisibility(element, rule) {
        const action = String(rule && rule.visibilityAction || (rule && rule.hidden ? "hide" : "unchanged"));
        if (action === "unchanged") return { hidden: false, target: element };
        const target = resolveVisibilityTarget(element, rule) || element;
        const state = rememberState(target);

        if (action === "hide") {
            const adminMode = effectiveSuperlibrarianHiddenMode(rule);

            if (adminMode === "visible") {
                target.hidden = false;
                target.removeAttribute("aria-hidden");
                target.style.removeProperty("display");
                return { hidden: false, target: target };
            }

            if (adminMode === "watermark") {
                target.hidden = false;
                target.removeAttribute("aria-hidden");
                target.style.removeProperty("display");
                rememberClass(target, "pmk-hidden-superlibrarian-preview", state);
                target.style.opacity = "0.32";
                target.style.pointerEvents = "none";
                return { hidden: false, target: target };
            }

            target.style.setProperty("display", "none", "important");
            target.hidden = true;
            target.setAttribute("aria-hidden", "true");
            return { hidden: true, target: target };
        }

        if (action === "show") {
            target.hidden = false;
            target.removeAttribute("aria-hidden");
            target.style.removeProperty("display");
            return { hidden: false, target: target };
        }

        if (action === "disable") {
            target.setAttribute("aria-disabled", "true");
            target.setAttribute("tabindex", "-1");
            if ("disabled" in target) target.disabled = true;
            target.style.opacity = "0.55";
            target.style.cursor = "not-allowed";
            if (!("disabled" in target)) target.style.pointerEvents = "none";
        }
        return { hidden: false, target: target };
    }

    function applyRuleToElement(element, rule) {
        const visibility = applyVisibility(element, rule);
        if (visibility.hidden) return;

        const state = rememberState(element);
        const className = "pmk-ui-rule-" + cssSafeId(rule.id);
        rememberClass(element, className, state);

        if (rule.customizeTextStyle) {
            element.style.fontSize = rule.textSizePx + "px";
            element.style.color = rule.textColor || "";
            element.style.fontWeight = rule.textBold ? "700" : "";
            element.style.fontStyle = rule.textItalic ? "italic" : "";
            element.style.textDecoration = rule.textUnderline ? "underline" : "";
            element.style.backgroundColor = rule.textBackgroundColor || "";
            element.style.borderRadius = rule.textBorderRadiusPx ? (rule.textBorderRadiusPx + "px") : "";
        }

        applyText(element, rule, state);
        applyIcon(element, rule, state, className);

        if (rule.changeLink && element.matches("a, area")) {
            element.setAttribute("href", rule.href || "#");
            if (rule.openInNewTab) {
                element.setAttribute("target", "_blank");
                element.setAttribute("rel", "noopener noreferrer");
            } else {
                element.removeAttribute("target");
                if (!state.relHad) element.removeAttribute("rel");
            }
        }
    }

    function disconnectObserver() {
        if (domObserver) domObserver.disconnect();
    }

    function connectObserver() {
        if (!currentConfig || currentConfig.enabled === false || currentConfig.observeDom === false) return;
        if (!document.body) return;
        if (!domObserver) {
            domObserver = new MutationObserver(function () {
                scheduleApply();
            });
        }
        domObserver.observe(document.body, { childList: true, subtree: true });
    }

    function applyConfig(config) {
        disconnectObserver();
        restoreAll();

        const normalized = normalizeConfig(config);
        currentConfig = normalized;
        mapIssuehistoryHeaders();
        buildDynamicStyles(normalized);

        if (normalized.enabled !== false) {
            normalized.rules.forEach(function (rule) {
                if (!rule || rule.enabled === false || !pageMatches(rule) || !rule.selector) return;
                safeQueryAll(rule.selector).forEach(function (element) {
                    applyRuleToElement(element, rule);
                });
            });
        }

        connectObserver();
    }

    function scheduleApply() {
        if (reapplyTimer) window.clearTimeout(reapplyTimer);
        reapplyTimer = window.setTimeout(function () {
            reapplyTimer = null;
            if (currentConfig) applyConfig(currentConfig);
        }, currentConfig && currentConfig.observeDelay ? currentConfig.observeDelay : 120);
    }

    function attachDataTablesHook() {
        if (!window.jQuery || !window.jQuery.fn) return;
        const events = [
            "init.dt.pmkTableLabels001",
            "draw.dt.pmkTableLabels001",
            "column-visibility.dt.pmkTableLabels001"
        ].join(" ");
        window.jQuery(document)
            .off(events)
            .on(events, "table", function () {
                scheduleApply();
            });
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const relevant = currentConfig && currentConfig.rules && currentConfig.rules.some(function (rule) {
            return rule && rule.enabled !== false && pageMatches(rule);
        });
        if (!relevant) return;

        const anchor = document.querySelector("h1") || document.querySelector("h2") || document.querySelector("main") || document.body;
        if (!anchor) return;

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: anchor,
            position: "append",
            contextKey: "page-" + window.location.pathname,
            context: { pagePath: window.location.pathname }
        });
    }

    function getRuleIndex(fieldPath) {
        if (!Array.isArray(fieldPath)) return null;
        const pos = fieldPath.indexOf("rules");
        if (pos < 0 || pos + 1 >= fieldPath.length) return null;
        const index = Number(fieldPath[pos + 1]);
        return Number.isInteger(index) ? index : null;
    }

    function getRuleFromPath(rootObject, fieldPath) {
        const index = getRuleIndex(fieldPath);
        if (index === null || !rootObject || !Array.isArray(rootObject.rules)) return null;
        return rootObject.rules[index] || null;
    }

    function cssColorToHex(value) {
        const raw = cleanText(value).toLowerCase();
        if (!raw || raw === "transparent") return "";
        if (/^#[0-9a-f]{6}$/i.test(raw)) return raw;
        if (/^#[0-9a-f]{3}$/i.test(raw)) {
            return "#" + raw.slice(1).split("").map(function (c) { return c + c; }).join("");
        }
        const nums = raw.match(/[\d.]+/g);
        if (!nums || nums.length < 3) return "";
        if (nums.length >= 4 && Number(nums[3]) === 0) return "";
        const toHex = function (n) {
            return Math.max(0, Math.min(255, Math.round(Number(n) || 0))).toString(16).padStart(2, "0");
        };
        return "#" + toHex(nums[0]) + toHex(nums[1]) + toHex(nums[2]);
    }

    function applyStyleSample(rule, sample) {
        if (!rule || !sample) return false;
        rule.customizeTextStyle = true;
        const size = parseFloat(sample.fontSize);
        if (Number.isFinite(size)) rule.textSizePx = Math.max(8, Math.min(72, Math.round(size)));
        const textColor = cssColorToHex(sample.color);
        if (textColor) rule.textColor = textColor;
        const bg = cssColorToHex(sample.backgroundColor);
        rule.textBackgroundColor = bg || "";
        const weight = parseInt(sample.fontWeight, 10);
        rule.textBold = Number.isFinite(weight) ? weight >= 600 : /bold/i.test(String(sample.fontWeight || ""));
        rule.textItalic = /italic|oblique/i.test(String(sample.fontStyle || ""));
        rule.textUnderline = /underline/i.test(String(sample.textDecorationLine || sample.textDecoration || ""));
        const radius = parseFloat(sample.borderRadius);
        if (Number.isFinite(radius)) rule.textBorderRadiusPx = Math.max(0, Math.min(48, Math.round(radius)));
        return true;
    }

    function visualPreviewModel(context) {
        const ctx = context || {};
        const rule = getRuleFromPath(ctx.rootObject, ctx.fieldPath) || RULE_TEMPLATE;
        const style = {};
        if (rule.customizeTextStyle) {
            style.fontSize = (Number(rule.textSizePx) || 14) + "px";
            style.color = rule.textColor || "#212529";
            style.fontWeight = rule.textBold ? "700" : "400";
            style.fontStyle = rule.textItalic ? "italic" : "normal";
            style.textDecorationLine = rule.textUnderline ? "underline" : "none";
            style.backgroundColor = rule.textBackgroundColor || "transparent";
            style.borderRadius = (Number(rule.textBorderRadiusPx) || 0) + "px";
        }

        let icon = null;
        if (rule.changeIcon && rule.iconType !== "none") {
            icon = {
                type: rule.iconType,
                className: rule.iconType === "fa" ? normalizeFaClass(rule.iconClass) : "",
                url: rule.iconType === "image" ? rule.imageUrl : "",
                size: Number(rule.iconSizePx) || 16,
                color: rule.iconColor || "",
                position: rule.iconPosition || "before"
            };
        }

        return {
            text: textForRule(rule) || rule.targetName || rule.label || i18n("Élément", "Element"),
            style: style,
            icon: icon,
            hidden: rule.visibilityAction === "hide",
            disabled: rule.visibilityAction === "disable",
            title: rule.visibilityAction === "hide"
                ? i18n("Cet élément sera masqué", "This element will be hidden")
                : ""
        };
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: true,
                livePreview: true
            },
            previewModel: visualPreviewModel,
            styleTargetUrl: function (context) {
                const rule = getRuleFromPath(context && context.rootObject, context && context.fieldPath);
                const path = cleanText(rule && rule.pagePath);
                return path && path !== "*" ? path : window.location.pathname;
            },
            applyStyleSample: function (context) {
                const rule = getRuleFromPath(context && context.rootObject, context && context.fieldPath);
                if (rule) applyStyleSample(rule, context && context.sample);
                return { rootObject: context && context.rootObject };
            },
            previewDraft: function (draft) {
                const before = clone(currentConfig || DEFAULT_CONFIG);
                applyConfig(draft);
                return function () {
                    applyConfig(before);
                };
            }
        });
        return true;
    }

    function applyPickerResult(rootObject, fieldPath, result) {
        const rule = getRuleFromPath(rootObject, fieldPath);
        if (!rule || !result) return;
        /* Le picker met à jour la page de référence sans modifier la portée globale de la règle. */
        rule.pagePath = result.pagePath || rule.pagePath || window.location.pathname;
        rule.targetName = result.targetName || rule.targetName || i18n("Élément Koha", "Koha element");
        rule.matchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(result.selector || rule.selector);
    }

    function pickForRule(context) {
        const ctx = context || {};
        const rule = getRuleFromPath(ctx.rootObject, ctx.fieldPath);
        const configuredPath = cleanText(rule && rule.pagePath);
        const targetUrl = configuredPath && configuredPath !== "*" ? configuredPath : window.location.pathname;
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.pickForConfig !== "function") {
            return Promise.reject(new Error("shared_picker_unavailable"));
        }
        return picker.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: targetUrl,
            fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath.slice() : [],
            rootObject: ctx.rootObject || {},
            adminContext: { sectionId: "rules", pagePath: targetUrl },
            options: {
                bannerText: i18n(
                    "Clique sur l’élément à personnaliser — Échap annule",
                    "Click the element to customize — Esc cancels"
                )
            }
        });
    }

    function registerPickerAdapter() {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return;
        picker.register(MODULE_ID, {
            buildResult: function (candidate, result) {
                result.targetName = cleanText(candidate.getAttribute("aria-label")) || cleanText(candidate.getAttribute("title")) || cleanText(candidate.textContent).slice(0, 100) || candidate.tagName.toLowerCase();
                result.matchCount = selectorCount(result.selector);
                return result;
            },
            applyPending: function (draft, pending, picked) {
                const rule = getRuleFromPath(draft, pending && pending.fieldPath);
                if (!rule || !picked) return draft;
                /* Conserve allPages tel quel : le pick ne change que la page de référence. */
                rule.pagePath = picked.pagePath || rule.pagePath || window.location.pathname;
                rule.targetName = picked.targetName || rule.targetName || i18n("Élément Koha", "Koha element");
                rule.matchCount = Number.isInteger(picked.matchCount) ? picked.matchCount : null;
                return draft;
            }
        });
    }

    function newRule() {
        return mergeRule({
            id: makeId("ui-rule"),
            enabled: true,
            label: i18n("Nouvelle personnalisation", "New customization"),
            allPages: false,
            pagePath: window.location.pathname,
            selector: "",
            targetName: ""
        }, 0);
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        if (!Array.isArray(cfg.rules)) {
            return { ok: false, message: i18n("La liste des règles est invalide.", "The rule list is invalid.") };
        }

        const ids = new Set();
        for (const rule of cfg.rules) {
            if (!rule.id || ids.has(rule.id)) {
                return { ok: false, message: i18n("Chaque règle doit avoir un identifiant unique.", "Each rule must have a unique identifier.") };
            }
            ids.add(rule.id);

            /* Une règle inactive peut rester incomplète pendant sa préparation. */
            if (rule.enabled === false) continue;

            /*
             * Une personnalisation sans cible est un brouillon valide :
             * elle est sauvegardée mais ignorée à l’exécution jusqu’au pick.
             */
            if (!cleanText(rule.selector)) continue;

            if (rule.allPages !== true && !cleanText(rule.pagePath)) {
                return { ok: false, message: i18n("Chaque règle limitée à une page doit indiquer une page Koha.", "Each rule limited to one page must specify a Koha page.") };
            }
            try {
                document.createDocumentFragment().querySelector(rule.selector);
            } catch (_) {
                return { ok: false, message: i18n("Un sélecteur CSS configuré n’est pas valide : ", "A configured CSS selector is invalid: ") + rule.selector };
            }
            if (rule.changeText && !cleanText(rule.textFr) && !cleanText(rule.textEn)) {
                return { ok: false, message: i18n("Une règle qui modifie le texte doit contenir au moins un libellé.", "A text-changing rule must contain at least one label.") };
            }
            if (rule.changeIcon && rule.iconType === "fa" && !cleanText(rule.iconClass)) {
                return { ok: false, message: i18n("Indique une classe Font Awesome.", "Provide a Font Awesome class.") };
            }
            if (rule.changeIcon && rule.iconType === "image" && !cleanText(rule.imageUrl)) {
                return { ok: false, message: i18n("Indique l’URL de l’image.", "Provide the image URL.") };
            }
            if (rule.changeLink && !cleanText(rule.href)) {
                return { ok: false, message: i18n("Indique l’adresse du lien.", "Provide the link URL.") };
            }
        }
        return { ok: true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: SCHEMA_VERSION,
            name: {
                fr: "Libellés et éléments d’interface",
                en: "Labels and interface elements"
            },
            description: {
                fr: "Personnalise dans une liste unique les libellés de tableaux et n’importe quel autre élément Koha : texte, icône, apparence, lien ou visibilité.",
                en: "Customizes table labels and any other Koha interface element in one rule list: text, icon, appearance, link or visibility."
            },
            category: { fr: "Interface / présentation", en: "Interface / presentation" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validateConfig,
            schema: [
                {
                    key: "enabled",
                    type: "boolean",
                    label: { fr: "Module actif", en: "Module enabled" },
                    help: {
                        fr: "Désactiver le module restaure les éléments modifiés sans désactiver les autres modules PMK.",
                        en: "Disabling this module restores modified elements without disabling other PMK modules."
                    }
                },
                {
                    key: "superlibrarianPreviewHidden",
                    type: "boolean",
                    label: {
                        fr: "Superlibrarian — afficher les éléments masqués en filigrane",
                        en: "Superlibrarian — show hidden elements as a watermark"
                    },
                    help: {
                        fr: "Mode de prévisualisation global. Il ne change rien pour les autres agents. Une règle peut surcharger ce comportement.",
                        en: "Global preview mode. It does not change anything for other staff. Individual rules can override it."
                    }
                },
                {
                    key: "observeDom",
                    type: "boolean",
                    advanced: true,
                    label: { fr: "Retraiter les éléments ajoutés dynamiquement", en: "Process dynamically added elements" }
                },
                {
                    key: "observeDelay",
                    type: "number",
                    advanced: true,
                    min: 25,
                    max: 2000,
                    label: { fr: "Délai de retraitement (ms)", en: "Reprocessing delay (ms)" }
                },
                {
                    key: "rules",
                    type: "repeater",
                    label: { fr: "Personnalisations", en: "Customizations" },
                    addLabel: { fr: "Ajouter une personnalisation", en: "Add customization" },
                    emptyLabel: { fr: "Aucune personnalisation configurée.", en: "No customization configured." },
                    reorder: true,
                    newItem: newRule,
                    liveTitleKey: "label",
                    itemTitle: function (item, index) {
                        return cleanText(item && item.label) || (i18n("Personnalisation ", "Customization ") + (index + 1));
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                        { key: "label", type: "text", label: { fr: "Nom de la règle", en: "Rule name" } },
                        {
                            key: "allPages",
                            type: "boolean",
                            label: { fr: "Appliquer sur toutes les pages", en: "Apply on all pages" },
                            refreshOnChange: true,
                            help: {
                                fr: "Si cette option est activée, la règle est recherchée et appliquée sur toutes les pages Koha où le sélecteur existe. La page choisie reste mémorisée comme page de référence et sera réutilisée si vous désactivez cette option.",
                                en: "When enabled, the rule is searched for and applied on every Koha page where the selector exists. The selected page remains stored as the reference page and is reused if you disable this option."
                            }
                        },
                        {
                            key: "pagePath",
                            type: "text",
                            label: { fr: "Page Koha", en: "Koha page" },
                            help: {
                                fr: "Renseignée automatiquement par le picker. Cette page reste mémorisée même si la règle est appliquée sur toutes les pages. Exemple : /cgi-bin/koha/mainpage.pl",
                                en: "Filled automatically by the picker. This page remains stored even when the rule is applied on all pages. Example: /cgi-bin/koha/mainpage.pl"
                            },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.allPages !== true);
                            }
                        },
                        {
                            key: "selector",
                            type: "elementPicker",
                            label: { fr: "Élément à personnaliser", en: "Element to customize" },
                            pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                            emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                            help: {
                                fr: "Une règle sans élément peut être enregistrée : elle reste simplement sans effet jusqu’à la sélection d’une cible.",
                                en: "A rule without an element can be saved: it simply remains inactive in practice until a target is selected."
                            },
                            allowManual: true,
                            pick: pickForRule,
                            onPick: applyPickerResult,
                        },
                        { key: "targetName", type: "readonly", label: { fr: "Élément détecté", en: "Detected element" } },
                        { key: "matchCount", type: "readonly", advanced: true, label: { fr: "Éléments trouvés lors du choix", en: "Elements found when selected" } },

                        {
                            type: "visualPreview",
                            label: { fr: "Aperçu", en: "Preview" }
                        },
                        {
                            type: "styleEyedropper",
                            label: { fr: "Pipette de style", en: "Style eyedropper" },
                            buttonLabel: { fr: "Copier le style d’un élément…", en: "Copy style from an element…" },
                            iconClass: "fa fa-eyedropper",
                            sectionId: "rules",
                            help: {
                                fr: "Utilise le moteur visuel commun PMK. Seules les propriétés sûres et pertinentes pour ce module sont reprises.",
                                en: "Uses the shared PMK visual engine. Only safe properties relevant to this module are copied."
                            }
                        },
                        {
                            key: "changeText",
                            type: "boolean",
                            label: { fr: "Modifier le texte / libellé", en: "Change text / label" },
                            refreshOnChange: true
                        },
                        {
                            key: "textFr",
                            type: "text",
                            label: { fr: "Nouveau texte — français", en: "New text — French" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeText);
                            }
                        },
                        {
                            key: "textEn",
                            type: "text",
                            label: { fr: "Nouveau texte — anglais", en: "New text — English" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeText);
                            }
                        },
                        {
                            key: "customizeTextStyle",
                            type: "boolean",
                            label: { fr: "Personnaliser l’apparence du texte", en: "Customize text appearance" },
                            refreshOnChange: true
                        },
                        {
                            key: "textSizePx",
                            type: "number",
                            label: { fr: "Taille du texte (px)", en: "Text size (px)" },
                            min: 8,
                            max: 72,
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textColor",
                            type: "color",
                            label: { fr: "Couleur du texte", en: "Text color" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textHoverColor",
                            type: "color",
                            label: { fr: "Couleur du texte au survol", en: "Text hover color" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },

                        {
                            key: "textBold",
                            type: "boolean",
                            label: { fr: "Gras", en: "Bold" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textItalic",
                            type: "boolean",
                            label: { fr: "Italique", en: "Italic" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textUnderline",
                            type: "boolean",
                            label: { fr: "Souligné", en: "Underline" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textBackgroundColor",
                            type: "color",
                            allowEmpty: true,
                            label: { fr: "Couleur de fond", en: "Background color" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },
                        {
                            key: "textBorderRadiusPx",
                            type: "number",
                            min: 0,
                            max: 48,
                            label: { fr: "Arrondi du fond (px)", en: "Background radius (px)" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.customizeTextStyle);
                            }
                        },

                        {
                            key: "changeIcon",
                            type: "boolean",
                            label: { fr: "Modifier / ajouter l’icône", en: "Change / add icon" },
                            refreshOnChange: true
                        },
                        {
                            key: "iconType",
                            type: "select",
                            label: { fr: "Type d’icône", en: "Icon type" },
                            options: [
                                { value: "fa", label: { fr: "Font Awesome", en: "Font Awesome" } },
                                { value: "image", label: { fr: "Image", en: "Image" } },
                                { value: "none", label: { fr: "Aucune icône", en: "No icon" } }
                            ],
                            refreshOnChange: true,
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon);
                            }
                        },
                        {
                            key: "iconClass",
                            type: "text",
                            label: { fr: "Classe Font Awesome", en: "Font Awesome class" },
                            help: { fr: "Exemple : fa fa-fw fa-book", en: "Example: fa fa-fw fa-book" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType === "fa");
                            }
                        },
                        {
                            key: "imageUrl",
                            type: "imageUrl",
                            label: { fr: "URL de l’image", en: "Image URL" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType === "image");
                            }
                        },
                        {
                            key: "iconPosition",
                            type: "select",
                            label: { fr: "Position de l’icône", en: "Icon position" },
                            options: [
                                { value: "before", label: { fr: "Avant le texte", en: "Before text" } },
                                { value: "after", label: { fr: "Après le texte", en: "After text" } }
                            ],
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType !== "none");
                            }
                        },
                        {
                            key: "iconSizePx",
                            type: "number",
                            min: 8,
                            max: 96,
                            label: { fr: "Taille de l’icône / image (px)", en: "Icon / image size (px)" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType !== "none");
                            }
                        },
                        {
                            key: "iconColor",
                            type: "color",
                            label: { fr: "Couleur Font Awesome", en: "Font Awesome color" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType === "fa");
                            }
                        },
                        {
                            key: "iconHoverColor",
                            type: "color",
                            label: { fr: "Couleur Font Awesome au survol", en: "Font Awesome hover color" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeIcon && rule.iconType === "fa");
                            }
                        },

                        {
                            key: "changeLink",
                            type: "boolean",
                            label: { fr: "Modifier l’adresse du lien", en: "Change link address" },
                            refreshOnChange: true
                        },
                        {
                            key: "href",
                            type: "text",
                            label: { fr: "Nouvelle adresse", en: "New address" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeLink);
                            }
                        },
                        {
                            key: "openInNewTab",
                            type: "boolean",
                            label: { fr: "Ouvrir dans un nouvel onglet", en: "Open in a new tab" },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.changeLink);
                            }
                        },
                        {
                            key: "visibilityAction",
                            type: "select",
                            label: { fr: "Visibilité / disponibilité", en: "Visibility / availability" },
                            options: [
                                { value: "unchanged", label: { fr: "Ne pas modifier", en: "Do not change" } },
                                { value: "hide", label: { fr: "Masquer", en: "Hide" } },
                                { value: "show", label: { fr: "Forcer l’affichage", en: "Force visible" } },
                                { value: "disable", label: { fr: "Désactiver sans masquer", en: "Disable without hiding" } }
                            ],
                            refreshOnChange: true,
                            help: {
                                fr: "Reprend les possibilités utiles de l’ancien module Affichage conditionnel.",
                                en: "Includes the useful capabilities of the former Conditional visibility module."
                            }
                        },
                        {
                            key: "visibilityScope",
                            type: "select",
                            advanced: true,
                            label: { fr: "Portée de l’action de visibilité", en: "Visibility action scope" },
                            options: [
                                { value: "self", label: { fr: "Élément sélectionné", en: "Selected element" } },
                                { value: "closest-li", label: { fr: "Ligne / entrée <li> parente", en: "Parent <li> row / entry" } },
                                { value: "closest-tr", label: { fr: "Ligne de tableau <tr> parente", en: "Parent table row <tr>" } }
                            ],
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.visibilityAction && rule.visibilityAction !== "unchanged");
                            }
                        },
                        {
                            key: "superlibrarianHiddenMode",
                            type: "select",
                            label: {
                                fr: "Affichage pour les superlibrarians",
                                en: "Display for superlibrarians"
                            },
                            options: [
                                { value: "inherit", label: { fr: "Utiliser le réglage global", en: "Use global setting" } },
                                { value: "hidden", label: { fr: "Masqué également", en: "Hidden as well" } },
                                { value: "watermark", label: { fr: "Visible en filigrane", en: "Visible as a watermark" } },
                                { value: "visible", label: { fr: "Forcer l’affichage normal", en: "Force normal display" } }
                            ],
                            help: {
                                fr: "Ne s’applique qu’aux règles dont l’action est « Masquer ». Le mode filigrane neutralise les clics sur l’élément.",
                                en: "Only applies to rules whose action is Hide. Watermark mode disables interaction with the element."
                            },
                            when: function (root, path) {
                                const rule = getRuleFromPath(root, path);
                                return Boolean(rule && rule.visibilityAction === "hide");
                            }
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main || !context || !context.pagePath) return;
                const repeater = main.querySelector(".pmk-repeater");
                if (repeater) {
                    window.setTimeout(function () {
                        repeater.scrollIntoView({ block: "start", behavior: "smooth" });
                    }, 0);
                }
            }
        };
    }

    async function startRuntimeWithCore() {
        if (!window.PMKConfig || bootedWithCore) return;
        bootedWithCore = true;

        registerPickerAdapter();
        registerVisualEditorAdapter();
        window.PMKConfig.registerModule(moduleDefinition());

        currentConfig = normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID));
        applyConfig(currentConfig);
        attachDataTablesHook();
        mountContextAccess();

        window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
            currentConfig = normalizeConfig(newConfig);
            applyConfig(currentConfig);
            mountContextAccess();
        });
    }

    function startRuntimeWithoutCore() {
        if (runtimeStarted) return;
        runtimeStarted = true;
        currentConfig = clone(DEFAULT_CONFIG);
        applyConfig(currentConfig);
        attachDataTablesHook();
    }

    function onDomReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else {
            callback();
        }
    }

    onDomReady(function () {
        if (window.PMKConfig) {
            startRuntimeWithCore();
        } else {
            startRuntimeWithoutCore();
            window.addEventListener("pmk:config-ready", function () {
                startRuntimeWithCore();
            }, { once: true });
        }
    });
})();

;window.PMKNonPlugin.loaded.push("001-modification-entete-issuehistory.js");
} catch (error) { window.PMKNonPlugin.errors.push("001-modification-entete-issuehistory.js: "+error.message); console.error("[PMK] 001-modification-entete-issuehistory.js",error); };
try {
/* ============================================================
   PimpMyKoha - Pré-plugin
   Fichier : 002-verification-coordonnees.js
   Version : 2.1.0-isolated

   Module fonctionnel : Vérification avant renouvellement lecteur

   Fonction :
   - détecte structurellement un lecteur expiré / bientôt expiré ;
   - affiche une checklist configurable des informations à vérifier ;
   - bloque les actions natives Koha de renouvellement d'adhésion tant
     que toutes les vérifications actives ne sont pas confirmées ;
   - couvre les liens d'alerte ET la commande native de la barre d'outils ;
   - FR/EN, responsive, idempotent, fail-safe ;
   - configuration partagée via 000-pmk-config-firestore.js ;
   - aucune dépendance directe à Firebase dans la logique métier.
   ============================================================ */

(function () {
    "use strict";

    if (window.__PMK_002_PATRON_RENEWAL_VERIFICATION__) return;
    window.__PMK_002_PATRON_RENEWAL_VERIFICATION__ = true;

    const MODULE_ID = "patron-renewal-verification";
    const UI_ID = "pmk-patron-renewal-verification";
    const STYLE_ID = "pmk-patron-renewal-verification-style";

    const PAGES = [
        {
            id: "members.moremember",
            path: "/cgi-bin/koha/members/moremember.pl",
            labelFr: "Fiche lecteur",
            labelEn: "Patron details"
        },
        {
            id: "circ.circulation",
            path: "/cgi-bin/koha/circ/circulation.pl",
            labelFr: "Circulation",
            labelEn: "Circulation"
        }
    ];

    // Native Koha information presets; each can be retargeted or supplemented with custom fields.
    const CHECK_OPTIONS = [
        { value: "address", label: { fr: "Adresse complète", en: "Full address" } },
        { value: "phone", label: { fr: "Téléphone de contact", en: "Contact phone" } },
        { value: "email", label: { fr: "E-mail de contact", en: "Contact email" } },
        { value: "dateofbirth", label: { fr: "Date de naissance", en: "Date of birth" } }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        expired: true,
        expiringSoon: true,
        targets: {expired:'li.expired',expiringSoon:'li.warndeparture',patronRoot:'',renewAction:'',destination:''},
        introFr: "Vérifiez les informations du lecteur avant de renouveler son adhésion :",
        introEn: "Verify the patron information before renewing the membership:",
        missingFr: "Non renseigné",
        missingEn: "Not provided",
        pages: PAGES.map(function (page) {
            return {
                id: page.id,
                path: page.path,
                enabled: true,
                labelFr: page.labelFr,
                labelEn: page.labelEn
            };
        }),
        checks: [
            {
                id: "address",
                enabled: true,
                severity: "blocking",
                labelFr: "Adresse",
                labelEn: "Address"
            },
            {
                id: "phone",
                enabled: true,
                severity: "blocking",
                labelFr: "Téléphone",
                labelEn: "Phone"
            },
            {
                id: "email",
                enabled: true,
                severity: "blocking",
                labelFr: "E-mail",
                labelEn: "Email"
            }
        ]
    };

    let currentConfig = null;
    let coreRegistered = false;
    let fallbackStarted = false;
    let runtimeLocked = false;
    let guardInstalled = false;
    let currentWarning = null;
    let currentPageId = null;
    let currentLinks = [];
    const originalLinkAttributes=new WeakMap();

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function normalizeConfig(config) {
        const value = Object.assign(clone(DEFAULT_CONFIG), config || {});
        value.targets = Object.assign({}, DEFAULT_CONFIG.targets, config && config.targets || {});
        value.pages = Array.isArray(config && config.pages) ? config.pages.map(function (page) { return Object.assign({}, page); }) : clone(DEFAULT_CONFIG.pages);
        value.checks = Array.isArray(config && config.checks) ? config.checks.map(function (check) {
            const row = Object.assign({}, check);
            row.severity = ["information", "warning", "blocking"].includes(row.severity) ? row.severity : "blocking";
            return row;
        }) : clone(DEFAULT_CONFIG.checks);
        return value;
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const lang = (document.documentElement.getAttribute("lang") || navigator.language || "").toLowerCase();
        return lang.startsWith("fr") ? "fr" : "en";
    }

    function localText(fr, en) {
        return detectLanguage() === "fr" ? fr : en;
    }

    function getCurrentPageDefinition() {
        const path = window.location.pathname;
        return (currentConfig.pages || PAGES).find(function (page) {
            return page.path === path;
        }) || null;
    }

    function getPageConfig(config, pageId) {
        if (!config || !Array.isArray(config.pages)) return null;
        return config.pages.find(function (page) {
            return page && page.id === pageId;
        }) || null;
    }

    function safeQuery(selector, root) {
        try { return selector ? (root || document).querySelector(selector) : null; } catch (_) { return null; }
    }
    function targetSelector(key, fallback) { return (currentConfig.targets || {})[key] || fallback || ''; }
    function pickRenewalTarget(context) {
        const page = context.rootObject.pages.find(p => p.enabled !== false && p.path === location.pathname)
            || context.rootObject.pages.find(p => p.enabled !== false);
        return window.PMKConfig.elementPicker.pickForConfig({moduleId:MODULE_ID,rootObject:context.rootObject,
            fieldPath:context.fieldPath,targetUrl:page ? page.path : location.pathname,persistAfterPick:false});
    }

    function isSupportedRenewLink(link) {
        if (!link) return false;
        const selector = targetSelector('renewAction');
        if (selector) { try { return link.matches(selector) && link.matches('a,button,input[type="submit"],input[type="button"]'); } catch (_) { return false; } }
        if (link.tagName !== "A" || !link.href) return false;
        try {
            const url = new URL(link.href, window.location.origin);
            return url.origin === window.location.origin &&
                url.pathname === "/cgi-bin/koha/members/setstatus.pl" &&
                url.searchParams.get("reregistration") === "y";
        } catch (_) {
            return false;
        }
    }

    function findRenewLinks() {
        return Array.from(document.querySelectorAll('a[href],button,input[type="submit"],input[type="button"]'))
            .filter(isSupportedRenewLink);
    }

    function findPatronWarning(selector) {
        /*
         * Koha n'utilise pas le même conteneur selon la page :
         * - moremember.pl peut exposer #patron_messages ;
         * - circulation.pl rend patron_messages.inc dans un .circmessage
         *   dont l'id peut être absent ou vide selon le template/version.
         *
         * On cible donc l'élément métier (li.expired / li.warndeparture)
         * à l'intérieur des zones de messages Koha, sans dépendre d'un id.
         */
        const scopedSelectors = [
            "#patron_messages " + selector,
            "#circmessages " + selector,
            ".circmessage.warning " + selector,
            ".circmessage.attention " + selector,
            ".circmessage " + selector
        ];

        for (const scopedSelector of scopedSelectors) {
            const found = safeQuery(scopedSelector);
            if (found) return found;
        }

        /*
         * Dernier repli borné : patron_messages.inc produit directement
         * ces classes sur des <li>. Cela couvre une personnalisation de
         * conteneur sans élargir la détection à du texte traduit.
         */
        return safeQuery(selector);
    }

    function detectWarningState() {
        const expired = findPatronWarning(targetSelector('expired', 'li.expired'));
        if (expired) {
            return {
                type: "expired",
                element: expired,
                messages: expired.closest(".circmessage, #patron_messages") || expired.parentElement
            };
        }

        const expiring = findPatronWarning(targetSelector('expiringSoon', 'li.warndeparture'));
        if (expiring) {
            return {
                type: "expiringSoon",
                element: expiring,
                messages: expiring.closest(".circmessage, #patron_messages") || expiring.parentElement
            };
        }

        return null;
    }

    function warningEnabled(config, warning) {
        if (!config || !warning) return false;
        if (warning.type === "expired") return config.expired !== false;
        if (warning.type === "expiringSoon") return config.expiringSoon !== false;
        return false;
    }

    function getPatronInfoRoot() {
        /*
         * circ-menu.inc expose normalement .patroninfo sur les pages lecteur
         * et circulation. On prévoit plusieurs replis structurels pour rester
         * compatible avec les variantes de gabarit et personnalisations Koha.
         */
        if (targetSelector('patronRoot')) return safeQuery(targetSelector('patronRoot'));
        const patronInfo = document.querySelector(".patroninfo");
        if (patronInfo) return patronInfo;

        const briefInfo = document.querySelector(".patronbriefinfo");
        if (briefInfo) {
            return briefInfo.closest(".patroninfo") || briefInfo;
        }

        const patronInformation = document.getElementById("patron-information");
        if (patronInformation) return patronInformation;

        return null;
    }

    function cleanText(value) {
        return String(value || "").replace(/\s+/g, " ").trim();
    }

    function textOf(element) {
        return element ? cleanText(element.textContent) : "";
    }

    function firstText(root, selectors) {
        if (!root) return "";
        for (const selector of selectors) {
            const el = root.querySelector(selector);
            const value = textOf(el);
            if (value) return value;
        }
        return "";
    }

    function uniqueNonEmpty(values) {
        const seen = new Set();
        const result = [];
        values.forEach(function (value) {
            const cleaned = cleanText(value);
            if (!cleaned || seen.has(cleaned)) return;
            seen.add(cleaned);
            result.push(cleaned);
        });
        return result;
    }

    function resolveAddress(root) {
        if (!root) return "";

        const parts = [
            firstText(root, [".patronaddress1"]),
            firstText(root, [".patronaddress2"]),
            firstText(root, [".patronaddress3"]),
            firstText(root, [".patroncity"])
        ];

        const found = uniqueNonEmpty(parts);
        if (found.length) return found.join(", ");

        /* Repli borné pour les variantes de display-address-style.inc. */
        const addressBlock = root.querySelector(".address") || root.querySelector("ul.patronbriefinfo");
        if (!addressBlock) return "";

        const addressLines = Array.from(addressBlock.querySelectorAll(
            ".patronaddress1, .patronaddress2, .patronaddress3, .patroncity"
        )).map(textOf);

        return uniqueNonEmpty(addressLines).join(", ");
    }

    function resolvePhone(root) {
        return firstText(root, [
            ".patronphone a[href^='tel:']",
            ".patronphone",
            "a[href^='tel:']"
        ]);
    }

    function resolveEmail(root) {
        return firstText(root, [
            "li.email a[href^='mailto:']",
            ".email a[href^='mailto:']",
            "a[href^='mailto:']"
        ]);
    }

    function resolveDateOfBirth(root) {
        if (!root) return "";
        const item = root.querySelector(".patrondateofbirth");
        if (!item) return "";

        const copy = item.cloneNode(true);
        const firstDirectSpan = Array.from(copy.children).find(function (child) {
            return child.tagName === "SPAN";
        });
        if (firstDirectSpan) firstDirectSpan.remove();
        return textOf(copy);
    }

    const FIELD_RESOLVERS = {
        address: resolveAddress,
        phone: resolvePhone,
        email: resolveEmail,
        dateofbirth: resolveDateOfBirth
    };

    function getConfiguredValue(check, root, config) {
        if (!check) return '';
        const element = check.selector ? safeQuery(check.selector) : null;
        const value = check.selector ? cleanText(element && ('value' in element ? element.value : element.textContent))
            : FIELD_RESOLVERS[check.id] ? FIELD_RESOLVERS[check.id](root) : '';
        if (value) return value;
        return detectLanguage() === "fr"
            ? (config.missingFr || "Non renseigné")
            : (config.missingEn || "Not provided");
    }

    function labelForCheck(check) {
        if (!check) return "";
        if (detectLanguage() === "fr") return check.labelFr || check.labelEn || check.id || "";
        return check.labelEn || check.labelFr || check.id || "";
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #${UI_ID} {
                margin-top: .65rem;
                padding: .65rem .75rem;
                border: 1px solid #d7dce1;
                border-left: 3px solid #e0a800;
                border-radius: .25rem;
                background: var(--bs-body-bg, #fff);
                color: var(--bs-body-color, #212529);
                max-width: 100%;
            }
            #${UI_ID} .pmk-renewal-heading {
                display: flex;
                align-items: center;
                gap: .35rem;
                margin-bottom: .5rem;
                min-width: 0;
            }
            #${UI_ID} .pmk-renewal-title {
                font-weight: 600;
                flex: 1 1 auto;
                min-width: 0;
                overflow-wrap: anywhere;
            }
            #${UI_ID} .pmk-renewal-checks {
                display: grid;
                gap: .35rem;
            }
            #${UI_ID} .pmk-renewal-check {
                display: grid;
                grid-template-columns: auto minmax(0, 1fr);
                gap: .45rem;
                align-items: start;
                margin: 0;
                cursor: pointer;
                padding: .2rem .1rem;
                max-width: 100%;
            }
            #${UI_ID} .pmk-renewal-check input {
                margin-top: .2rem;
                width: 1rem;
                height: 1rem;
                flex: 0 0 auto;
            }
            #${UI_ID} .pmk-renewal-value {
                overflow-wrap: anywhere;
                word-break: break-word;
            }
            #${UI_ID} .pmk-renewal-status {
                margin-top: .5rem;
                font-size: .9em;
                color: #6c757d;
            }
            #${UI_ID} .pmk-renewal-level { display:inline-block;margin-right:.35rem;padding:.05rem .35rem;border-radius:999px;font-size:.78em;font-weight:700; }
            #${UI_ID} [data-severity="blocking"] .pmk-renewal-level { background:#f8d7da;color:#842029; }
            #${UI_ID} [data-severity="warning"] .pmk-renewal-level { background:#fff3cd;color:#664d03; }
            #${UI_ID} [data-severity="information"] .pmk-renewal-level { background:#cff4fc;color:#055160; }
            #${UI_ID}.pmk-complete {
                border-left-color: #198754;
            }
            .pmk-patron-renew-link-locked {
                opacity: .55 !important;
                cursor: not-allowed !important;
            }
            @media (max-width: 576px) {
                #${UI_ID} {
                    padding: .55rem;
                }
                #${UI_ID} .pmk-renewal-check {
                    gap: .5rem;
                    padding: .3rem 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function setLinkLocked(link, locked) {
        if (!link || (locked && !isSupportedRenewLink(link))) return;
        if (!locked && !originalLinkAttributes.has(link) && !link.hasAttribute("data-pmk-renew-original-tabindex")) return;

        if (locked) {
            if (!originalLinkAttributes.has(link)) originalLinkAttributes.set(link,{aria:link.getAttribute('aria-disabled'),tab:link.getAttribute('tabindex')});
            if (!link.hasAttribute("data-pmk-renew-original-tabindex")) {
                const original = link.getAttribute("tabindex");
                link.setAttribute("data-pmk-renew-original-tabindex", original === null ? "__none__" : original);
            }
            link.classList.add("pmk-patron-renew-link-locked");
            link.setAttribute("aria-disabled", "true");
            link.setAttribute("tabindex", "-1");
        } else {
            link.classList.remove("pmk-patron-renew-link-locked");
            link.removeAttribute("aria-disabled");

            const original = link.getAttribute("data-pmk-renew-original-tabindex");
            if (original === "__none__") link.removeAttribute("tabindex");
            else if (original !== null) link.setAttribute("tabindex", original);
            link.removeAttribute("data-pmk-renew-original-tabindex");
            const saved=originalLinkAttributes.get(link);
            if(saved){for(const [attr,value] of [['aria-disabled',saved.aria],['tabindex',saved.tab]]){if(value===null)link.removeAttribute(attr);else link.setAttribute(attr,value);}originalLinkAttributes.delete(link);}
        }
    }

    function syncRenewLinks() {
        const discovered = findRenewLinks();
        currentLinks = discovered;
        discovered.forEach(function (link) {
            setLinkLocked(link, runtimeLocked);
        });
    }

    function focusFirstUnchecked() {
        const first = document.querySelector("#" + UI_ID + " .pmk-renewal-check input:not(:checked)");
        if (first) {
            first.focus({ preventScroll: true });
            first.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    }

    function installActionGuard() {
        if (guardInstalled) return;
        guardInstalled = true;

        const guard = function (event) {
            if (!runtimeLocked) return;
            const target = event.type === 'submit' ? (event.submitter || Array.from(event.target.elements || []).find(isSupportedRenewLink))
                : event.target && event.target.closest ? event.target.closest('a,button,input') : null;
            if (!target || !isSupportedRenewLink(target)) return;

            event.preventDefault();
            event.stopPropagation();
            if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
            syncRenewLinks();
            focusFirstUnchecked();
        };

        document.addEventListener("click", guard, true);
        document.addEventListener("auxclick", guard, true);
        document.addEventListener("submit", guard, true);
    }

    function setLockedState(locked) {
        runtimeLocked = Boolean(locked);
        syncRenewLinks();

        const container = document.getElementById(UI_ID);
        if (!container) return;

        container.classList.toggle("pmk-complete", !runtimeLocked);
        const status = container.querySelector(".pmk-renewal-status");
        if (status) {
            status.textContent = runtimeLocked
                ? localText(
                    "Le renouvellement sera disponible après validation de toutes les informations.",
                    "Renewal will be available after all information has been confirmed."
                )
                : localText(
                    "Vérification terminée : le renouvellement Koha est disponible.",
                    "Verification complete: Koha renewal is available."
                );
        }
    }

    function removeRuntimeUi() {
        const container = document.getElementById(UI_ID);
        if (container) container.remove();
        runtimeLocked = false;
        currentWarning = null;
        currentLinks.forEach(function (link) { setLinkLocked(link, false); });
        findRenewLinks().forEach(function (link) { setLinkLocked(link, false); });
        currentLinks = [];
    }

    function mountContextAccess(heading) {
        if (!heading || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: heading,
            position: "append",
            contextKey: currentPageId || "renewal",
            context: {
                pageId: currentPageId,
                sectionId: "pages"
            }
        });
    }

    function buildUi(config, warning, patronRoot, checks) {
        injectStyles();

        const container = document.createElement("div");
        container.id = UI_ID;
        container.setAttribute("role", "region");
        container.setAttribute(
            "aria-label",
            localText("Vérification avant renouvellement", "Verification before renewal")
        );

        const heading = document.createElement("div");
        heading.className = "pmk-renewal-heading";

        const title = document.createElement("div");
        title.className = "pmk-renewal-title";
        title.textContent = detectLanguage() === "fr"
            ? (config.introFr || DEFAULT_CONFIG.introFr)
            : (config.introEn || DEFAULT_CONFIG.introEn);
        heading.appendChild(title);
        container.appendChild(heading);

        const list = document.createElement("div");
        list.className = "pmk-renewal-checks";

        checks.forEach(function (check, index) {
            const label = document.createElement("label");
            label.className = "pmk-renewal-check";
            label.dataset.severity = check.severity || "blocking";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "pmk-renewal-checkbox";
            checkbox.id = "pmk-renewal-check-" + index + "-" + check.id;
            checkbox.setAttribute("data-pmk-check-id", check.id);
            checkbox.setAttribute("data-severity", check.severity || "blocking");
            if (check.severity === "information") { checkbox.checked = true; checkbox.disabled = true; }

            const value = document.createElement("span");
            value.className = "pmk-renewal-value";

            const strong = document.createElement("strong");
            const level = document.createElement("span");
            level.className = "pmk-renewal-level";
            level.textContent = check.severity === "information" ? localText("Information", "Information") : check.severity === "warning" ? localText("Avertissement", "Warning") : localText("Bloquant", "Blocking");
            value.appendChild(level);
            strong.textContent = labelForCheck(check) + " : ";
            value.appendChild(strong);
            value.appendChild(document.createTextNode(getConfiguredValue(check, patronRoot, config)));

            label.appendChild(checkbox);
            label.appendChild(value);
            list.appendChild(label);
        });

        container.appendChild(list);

        const status = document.createElement("div");
        status.className = "pmk-renewal-status";
        status.setAttribute("aria-live", "polite");
        container.appendChild(status);

        const update = function () {
            const boxes = Array.from(container.querySelectorAll(".pmk-renewal-checkbox"));
            const blocking = boxes.filter(function (box) { return box.dataset.severity === "blocking"; });
            const warnings = boxes.filter(function (box) { return box.dataset.severity === "warning" && !box.checked; });
            const remaining = blocking.filter(function (box) { return !box.checked; });
            setLockedState(remaining.length > 0);
            const status = container.querySelector(".pmk-renewal-status");
            if (status) status.textContent += " " + localText("Synthèse : ", "Summary: ") + remaining.length + localText(" contrôle(s) bloquant(s), ", " blocking check(s), ") + warnings.length + localText(" avertissement(s) non confirmé(s).", " unconfirmed warning(s).");
        };

        list.addEventListener("change", function (event) {
            if (event.target && event.target.classList.contains("pmk-renewal-checkbox")) update();
        });

        const destination = targetSelector('destination') ? safeQuery(targetSelector('destination')) : warning.element;
        if (!destination) return;
        destination.appendChild(container);
        mountContextAccess(heading);
        update();
    }

    function applyConfig(config) {
        removeRuntimeUi();
        currentConfig = normalizeConfig(config || DEFAULT_CONFIG);
        config = currentConfig;

        const pageDef = getCurrentPageDefinition();
        if (!pageDef || !config || config.enabled === false) return;

        currentPageId = pageDef.id;
        const pageConfig = getPageConfig(config, pageDef.id);
        if (!pageConfig || pageConfig.enabled === false || pageConfig.path !== pageDef.path) return;

        const warning = detectWarningState();
        if (!warning || !warningEnabled(config, warning)) return;

        const renewLinks = findRenewLinks();
        if (!renewLinks.length) return;

        const patronRoot = getPatronInfoRoot();
        if (!patronRoot) return;

        const checks = Array.isArray(config.checks)
            ? config.checks.filter(function (check) {
                return check && check.enabled !== false && (FIELD_RESOLVERS[check.id] || check.selector);
            })
            : [];
        if (!checks.length) return;

        currentWarning = warning;
        currentLinks = renewLinks;
        installActionGuard();
        buildUi(config, warning, patronRoot, checks);
    }

    function waitForRequiredStructure(timeoutMs) {
        return new Promise(function (resolve) {
            const inspect = function () {
                const warning = detectWarningState();
                const patron = getPatronInfoRoot();
                return warning && patron ? { warning: warning, patron: patron } : null;
            };

            const existing = inspect();
            if (existing) {
                resolve(existing);
                return;
            }

            const root = document.body || document.documentElement;
            if (!root) {
                resolve(null);
                return;
            }

            let finished = false;
            const observer = new MutationObserver(function () {
                const found = inspect();
                if (!found || finished) return;
                finished = true;
                observer.disconnect();
                resolve(found);
            });

            observer.observe(root, { childList: true, subtree: true });
            window.setTimeout(function () {
                if (finished) return;
                finished = true;
                observer.disconnect();
                resolve(inspect());
            }, timeoutMs || 3000);
        });
    }

    function validateConfig(config) {
        if (!config || !Array.isArray(config.pages) || !Array.isArray(config.checks)) {
            return { ok: false, message: "Configuration incomplète." };
        }

        if (config.enabled !== false && config.expired === false && config.expiringSoon === false) {
            return { ok: false, message: "Active au moins un état : adhésion expirée ou expiration prochaine." };
        }

        const selectors = Object.values(config.targets || {}).concat(config.checks.map(c => c && c.selector));
        for (const selector of selectors.filter(Boolean)) { try { document.createDocumentFragment().querySelector(selector); } catch (_) { return {ok:false,message:'Sélecteur invalide : '+selector}; } }

        const pageIds = new Set();
        for (const page of config.pages) {
            if (!page || !page.id || !/^\/cgi-bin\/koha\/[^?#]+$/.test(page.path || "")) {
                return { ok: false, message: "Une page configurée n'est pas reconnue par le module." };
            }
            if (pageIds.has(page.id)) {
                return { ok: false, message: "Une même page ne peut être configurée qu'une seule fois." };
            }
            pageIds.add(page.id);


        }

        const knownChecks = new Set(CHECK_OPTIONS.map(function (option) { return option.value; }));
        const checkIds = new Set();
        let activeCount = 0;

        for (const check of config.checks) {
            if (!check || !check.id || (!knownChecks.has(check.id) && !check.selector)) {
                return { ok: false, message: "Une information à vérifier n'est pas reconnue par le module." };
            }
            if (checkIds.has(check.id)) {
                return { ok: false, message: "Une information ne peut apparaître qu'une seule fois dans la checklist." };
            }
            checkIds.add(check.id);

            if (check.enabled !== false) {
                activeCount += 1;
                if (!String(check.labelFr || check.labelEn || "").trim()) {
                    return { ok: false, message: "Chaque vérification active doit avoir un libellé." };
                }
            }
        }

        if (config.enabled !== false && activeCount === 0) {
            return { ok: false, message: "Le module actif doit contenir au moins une information à vérifier." };
        }

        return { ok: true };
    }

    function nextUnusedPage(rootObject) {
        const used = new Set((rootObject.pages || []).map(function (page) { return page && page.id; }));
        return PAGES.find(function (page) { return !used.has(page.id); }) || PAGES[0];
    }

    function nextUnusedCheck(rootObject) {
        const used = new Set((rootObject.checks || []).map(function (check) { return check && check.id; }));
        return CHECK_OPTIONS.find(function (option) { return !used.has(option.value); }) || CHECK_OPTIONS[0];
    }

    function moduleDefinition() {
        return {id:MODULE_ID,schemaVersion:2,compactActivation:true,hidePageCount:true,
            name:{fr:'Vérification avant renouvellement lecteur',en:'Patron renewal verification'},
            description:{fr:'Avant de renouveler une adhésion expirée ou proche de son échéance, demande à l’agent de confirmer les coordonnées du lecteur. Choisissez les informations à vérifier ; les actions natives de Koha restent utilisées.',en:'Before renewing an expired or expiring membership, ask staff to confirm the patron information. Select the checks; renewal still uses native Koha actions.'},
            category:{fr:'Adhérents',en:'Patrons'},supportedPages:['*'],defaults:clone(DEFAULT_CONFIG),normalize:normalizeConfig,validate:validateConfig,
            schema:[
                {
                    type: "section",
                    id: "general",
                    label: { fr: "Paramètres généraux", en: "General settings" },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Module actif", en: "Module enabled" }
                        },
                        {
                            key: "expired",
                            type: "boolean",
                            label: { fr: "Contrôler les adhésions expirées", en: "Check expired memberships" }
                        },
                        {
                            key: "expiringSoon",
                            type: "boolean",
                            label: { fr: "Contrôler les adhésions arrivant à expiration", en: "Check memberships expiring soon" }
                        },
                        {
                            key: "introFr",
                            type: "text",
                            label: { fr: "Texte introductif — français", en: "Introductory text — French" }
                        },
                        {
                            key: "introEn",
                            type: "text",
                            label: { fr: "Texte introductif — anglais", en: "Introductory text — English" }
                        },
                        {
                            key: "missingFr",
                            type: "text",
                            label: { fr: "Valeur absente — français", en: "Missing value — French" }
                        },
                        {
                            key: "missingEn",
                            type: "text",
                            label: { fr: "Valeur absente — anglais", en: "Missing value — English" }
                        }
                    ]
                },

                {type:'section',id:'pages',label:{fr:'Pages concernées',en:'Target pages'},fields:[
                    {key:'pages',type:'repeater',addLabel:{fr:'Ajouter une page',en:'Add page'},reorder:true,
                        newItem:()=>({id:'page-'+Date.now().toString(36),enabled:true,path:location.pathname,labelFr:'Page Koha',labelEn:'Koha page'}),
                        itemTitle:p=>p.labelFr || p.path,
                        fields:[{key:'enabled',type:'boolean',label:{fr:'Page active',en:'Enabled page'}},
                            {key:'path',type:'text',label:{fr:'Chemin de la page Koha',en:'Koha page path'}},
                            {key:'labelFr',type:'text',label:{fr:'Nom français',en:'French name'}},{key:'labelEn',type:'text',label:{fr:'Nom anglais',en:'English name'}}]}
                ]},
                {type:'section',id:'checks',label:{fr:'Informations à vérifier',en:'Information to verify'},
                    description:{fr:'Toutes les informations actives doivent être confirmées. Pour une information ajoutée, choisissez sa valeur sur la fiche lecteur. Les champs préconfigurés utilisent la lecture native de Koha tant qu’aucune cible n’est choisie.',en:'All active checks must be confirmed. For extra information, pick its value on the patron page. Built-in checks use native Koha fields unless a target is chosen.'},fields:[
                    {key:'checks',type:'repeater',reorder:true,addLabel:{fr:'Ajouter une information',en:'Add information'},
                        newItem:root=>{const used=new Set(root.checks.map(c=>c.id));const option=CHECK_OPTIONS.find(c=>!used.has(c.value));return option ? {id:option.value,enabled:true,severity:'blocking',labelFr:option.label.fr,labelEn:option.label.en} : {id:'custom-'+Date.now().toString(36),enabled:true,severity:'blocking',labelFr:'Information à vérifier',labelEn:'Information to verify',selector:''};},
                        itemTitle:(c,i,lang)=>c[lang==='en'?'labelEn':'labelFr'] || c.id,
                        fields:[{key:'enabled',type:'boolean',label:{fr:'Vérification active',en:'Enabled check'}},
                            {key:'severity',type:'select',label:{fr:'Effet sur le renouvellement',en:'Renewal effect'},options:[{value:'information',label:{fr:'Information — lecture seule',en:'Information — read only'}},{value:'warning',label:{fr:'Avertissement — confirmation conseillée',en:'Warning — confirmation recommended'}},{value:'blocking',label:{fr:'Blocage — confirmation obligatoire',en:'Blocking — confirmation required'}}]},
                            {key:'labelFr',type:'text',label:{fr:'Libellé français',en:'French label'}},{key:'labelEn',type:'text',label:{fr:'Libellé anglais',en:'English label'}},
                            {key:'selector',type:'elementPicker',allowManual:true,manualAlways:true,label:{fr:'Valeur à lire sur la fiche',en:'Value to read on the page'},pick:pickRenewalTarget},
                            {key:'id',type:'readonly',advanced:true,label:{fr:'Identifiant conservé',en:'Preserved identifier'}}]}
                ]},
                {type:'section',id:'targets',label:{fr:'Adapter les éléments Koha',en:'Adapt Koha elements'},
                    description:{fr:'En cas de gabarit personnalisé, sélectionnez les avertissements, la zone d’informations et l’action de renouvellement. Une cible vide conserve la détection native. Choisissez une page concernée dans la liste avant de lancer le sélecteur.',en:'For custom templates, pick warnings, patron information and the renewal action. Empty targets keep native detection.'},
                    fields:[['expired','Avertissement d’adhésion expirée'],['expiringSoon','Avertissement d’expiration prochaine'],['patronRoot','Bloc des informations lecteur'],['renewAction','Action native de renouvellement'],['destination','Bloc où afficher les vérifications']].map(([key,label])=>({key:'targets.'+key,type:'elementPicker',allowManual:true,manualAlways:true,label,pick:pickRenewalTarget}))}
            ]};
    }

    async function startWithCore() {
        if (!window.PMKConfig) return;

        if (!coreRegistered) {
            window.PMKConfig.registerModule(moduleDefinition());
            coreRegistered = true;
        }

        currentConfig = normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID));
        const pageDef = getCurrentPageDefinition();
        if (pageDef && currentConfig.enabled !== false) await waitForRequiredStructure(4000);
        applyConfig(currentConfig);

        window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
            currentConfig = normalizeConfig(newConfig);
            applyConfig(currentConfig);
        });
    }

    async function startWithoutCore() {
        if (fallbackStarted) return;
        fallbackStarted = true;

        const pageDef = getCurrentPageDefinition();
        if (!pageDef) return;

        const structure = await waitForRequiredStructure(4000);
        if (!structure) return;

        currentConfig = clone(DEFAULT_CONFIG);
        applyConfig(currentConfig);
    }

    function onDomReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else {
            callback();
        }
    }

    onDomReady(function () {
        if (window.PMKConfig) {
            startWithCore();
        } else {
            startWithoutCore();
            window.addEventListener("pmk:config-ready", function () {
                startWithCore();
            }, { once: true });
        }
    });
})();

;window.PMKNonPlugin.loaded.push("002-verification-coordonnees.js");
} catch (error) { window.PMKNonPlugin.errors.push("002-verification-coordonnees.js: "+error.message); console.error("[PMK] 002-verification-coordonnees.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.print;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 003-ajout-bouton-imprimer-info.js
 Dépendances: aucune
 Date de dernière modification: 2026-06-19
 Auteur: équipe PimpMyKoha
 Description: Ajoute une option permettant d'imprimer les informations d'un adhérent directement dans le menu déroulant "Imprimer" de la fiche membre via délégation d'événement au clic.
*/

(function(){
    (function (callback) {
        if (document.readyState !== 'loading') callback.call(document);
        else document.addEventListener('DOMContentLoaded', callback, { once: true });
    })(function(){

        if (window.location.pathname.includes("moremember.pl") || window.location.pathname.includes("circulation.pl")) {

            // Attendre proprement la présence de la zone patroninfo plutôt que d'utiliser setTimeout
            function waitForSelector(selector, options) {
                options = options || {};
                const timeout = options.timeout;
                const signal = options.signal;
                return new Promise((resolve, reject) => {
                    const el = document.querySelector(selector);
                    if (el) return resolve(el);
                    const obs = new MutationObserver(() => {
                        const found = document.querySelector(selector);
                        if (found) { obs.disconnect(); cleanup(); resolve(found); }
                    });
                    obs.observe(document.documentElement, { childList: true, subtree: true });

                    let timeoutId;
                    const cleanup = () => {
                        if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
                        if (signal && typeof signal.removeEventListener === 'function') signal.removeEventListener('abort', onAbort);
                    };

                    const onAbort = () => { obs.disconnect(); cleanup(); reject(new DOMException('Aborted','AbortError')); };

                    if (timeout) {
                        timeoutId = setTimeout(() => { obs.disconnect(); cleanup(); reject(new Error('timeout')); }, timeout);
                    }

                    if (signal) {
                        if (signal.aborted) return onAbort();
                        signal.addEventListener('abort', onAbort);
                    }
                });
            }

            // Attente de la présence de la fiche de l'adhérent pour extraire les données
            waitForSelector('.patroninfo h5').then(() => {

                // ---- Extraction des données (Variables globales à la fermeture) ----
                let name = 'Non disponible';
                let cardNumbers = '';
                const nameElement = document.querySelector('.patroninfo h5');

                if (nameElement) {
                    const fullText = nameElement.textContent.trim();
                    const numbersMatch = fullText.match(/\(([^)]+)\)/);
                    if (numbersMatch && numbersMatch[1]) { cardNumbers = numbersMatch[1]; }
                    name = fullText.replace(/\(.*?\)/g, '').trim();
                }

                const phoneElement = document.querySelector('li a[href^="tel:"]');
                const phone = phoneElement ? phoneElement.textContent.trim() : 'Non disponible';

                const emailElement = document.querySelector('li.email a[href^="mailto:"]');
                const email = emailElement ? emailElement.textContent.trim() : 'Non disponible';

                const birthdateElement = Array.from(document.querySelectorAll('li')).find(el => el.querySelector('span.label') && el.querySelector('span.label').textContent.includes(options.birthLabel));
                const birthdate = birthdateElement ? birthdateElement.textContent.replace(options.birthLabel, '').replace(/^\s*:\s*/, '').trim() : 'Non disponible';

                const genderElement = Array.from(document.querySelectorAll('li')).find(el => el.querySelector('span.label') && el.querySelector('span.label').textContent.includes(options.genderLabel));
                const gender = genderElement ? genderElement.textContent.replace(options.genderLabel, '').replace(/^\s*:\s*/, '').trim() : 'Non disponible';

                const guarantorsList = Array.from(document.querySelectorAll('#patron-information li ul li')).map(el => el.textContent.trim()).filter(Boolean);

                const suspensionMessages = [];
                document.querySelectorAll('#patron_messages .blocker').forEach(msg => { suspensionMessages.push(msg.innerText.trim()); });

                const messageElements = [];
                document.querySelectorAll('#patron_messages li').forEach(item => {
                    const title = item.querySelector('span.circ-hlt') ? item.querySelector('span.circ-hlt').innerText.trim() : '';
                    const details = item.childNodes[2] ? item.childNodes[2].textContent.trim() : '';
                    messageElements.push(`${title} ${details}`);
                });

                // ---- Logique d'injection dynamique au clic ----
                // On écoute TOUS les clics sur la page. Si on clique sur le bouton "Imprimer" (ou un de ses enfants)
                document.addEventListener('click', function(event) {
                    const printButton = event.target.closest(options.target);

                    // Si on a cliqué sur le bouton "Imprimer"
                    if (printButton) {
                        // On cherche le menu dropdown associé à ce bouton spécifique
                        const printMenu = printButton.closest('.btn-group').querySelector('ul.dropdown-menu');

                        if (printMenu && !document.getElementById('infoButton')) {
                            const listItem = document.createElement('li');
                            const button = document.createElement('a');

                            button.id = 'infoButton';
                            button.className = 'dropdown-item';
                            button.href = '#';
                            button.setAttribute('role', 'button');
                            button.setAttribute('aria-label', 'Imprimer les informations de l\'adhérent');
                            button.textContent = 'Imprimer les informations';

                            // Action d'impression
                            button.addEventListener('click', function (e) {
                                e.preventDefault();
                                e.stopPropagation(); // Évite de fermer le menu trop abruptement avant action

                                const printWindow = window.open('', '', 'height=800,width=600');
                                if (!printWindow) return;

                                printWindow.document.open();
                                printWindow.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Impression des informations</title></head><body></body></html>');

                                const doc = printWindow.document;
                                const ps = doc.createElement('style');
                                ps.textContent = 'body{font-family:Arial,Helvetica,sans-serif;padding:16px;color:#111} h1{font-size:1.2em;margin-bottom:8px} p{margin:6px 0}';
                                doc.head.appendChild(ps);

                                const container = doc.createElement('div');
                                const h1 = doc.createElement('h1'); h1.textContent = name || 'Non disponible'; container.appendChild(h1);

                                const addRow = (label, value) => { const p = doc.createElement('p'); const strong = doc.createElement('strong'); strong.textContent = label + ': '; p.appendChild(strong); p.appendChild(doc.createTextNode(value || 'Non disponible')); container.appendChild(p); };

                                addRow('Numéros de carte', cardNumbers);
                                addRow('Téléphone', phone);
                                addRow('Email', email);
                                addRow('Date de naissance', birthdate);
                                addRow('Genre', gender);
                                addRow('Garants', guarantorsList.length ? guarantorsList.join(', ') : 'Non disponible');

                                if (suspensionMessages.length) {
                                    const p = doc.createElement('p'); const strong = doc.createElement('strong'); strong.textContent = 'Messages de suspension:'; p.appendChild(strong); suspensionMessages.forEach(m => { const div = doc.createElement('div'); div.textContent = m; p.appendChild(div); }); container.appendChild(p);
                                }
                                if (messageElements.length) {
                                    const p = doc.createElement('p'); const strong = doc.createElement('strong'); strong.textContent = 'Messages:'; p.appendChild(strong); messageElements.forEach(m => { const div = doc.createElement('div'); div.textContent = m; p.appendChild(div); }); container.appendChild(p);
                                }

                                doc.body.appendChild(container);
                                doc.body.offsetHeight;
                                doc.close();

                                printWindow.focus();
                                printWindow.print();
                            });

                            listItem.appendChild(button);
                            printMenu.appendChild(listItem);
                        }
                    }
                });

            }).catch(() => {});
        }
    });
})();
})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("003-ajout-bouton-imprimer-info.js");
} catch (error) { window.PMKNonPlugin.errors.push("003-ajout-bouton-imprimer-info.js: "+error.message); console.error("[PMK] 003-ajout-bouton-imprimer-info.js",error); };
try {
/* Compatibility entry point. Settings and rendering are unified in relative-dates.
 * Existing Firestore documents are read and preserved by 000; no document is deleted. */
(function () {
    'use strict';
    if (window.VC_DATE_UTILS || document.querySelector('script[data-pmk-date-runtime]')) return;
    const current=document.currentScript;
    if (!current || !current.src) return;
    const script=document.createElement('script');
    script.dataset.pmkDateRuntime='1';
    script.src=new URL('070-date-utils.js',current.src).href;
    document.head.appendChild(script);
})();

;window.PMKNonPlugin.loaded.push("004-calcul-duree-pret-detail.js");
} catch (error) { window.PMKNonPlugin.errors.push("004-calcul-duree-pret-detail.js: "+error.message); console.error("[PMK] 004-calcul-duree-pret-detail.js",error); };
try {
/*
 * Nom du fichier : 005-style-holdings-table.js
 * Module cible    : Tables responsives
 * Phase           : script isolé préparatoire à PimpMyKoha
 * Version         : 2.1.1
 * Date            : 2026-09-16
 *
 * Fonction :
 * - rend les tableaux d'exemplaires de catalogue/detail.pl lisibles sur petit écran ;
 * - associe chaque cellule à son en-tête sans dépendre d'indices de colonnes codés en dur ;
 * - respecte les colonnes masquées par Koha / DataTables ;
 * - supporte holdings_table et otherholdings_table ;
 * - réagit aux redraws DataTables et aux mutations utiles du tableau ;
 * - ignore les aides de tri DataTables ("Activate to sort") comme libellés ;
 * - ne modifie les cellules que sous le breakpoint mobile et restaure ensuite
 *   exactement les libellés/attributs/classes présents avant son activation ;
 * - reste idempotent si le script est chargé plusieurs fois ;
 * - n'utilise ni Firebase, ni Firestore, ni stockage local.
 *
 * La configuration est volontairement séparée du moteur afin de pouvoir être
 * remplacée plus tard par la couche de stockage PimpMyKoha / BDD Koha.
 */
(function () {
    'use strict';

    const GLOBAL_GUARD = '__PMK_005_RESPONSIVE_TABLES__';
    const MODULE_ID = 'responsive-tables';
    const MODULE_VERSION = '2.1.1';
    const STYLE_ID = 'pmk-005-responsive-tables-style';
    const TABLE_CLASS = 'pmk-responsive-table';
    const READY_ATTR = 'data-pmk-responsive-ready';
    const LABEL_ATTR = 'data-pmk-responsive-label';
    const KEY_ATTR = 'data-pmk-responsive-column';
    const PRIORITY_ATTR = 'data-pmk-responsive-priority';
    const HIDDEN_CLASS = 'pmk-responsive-column-hidden';
    const UNLABELLED_CLASS = 'pmk-responsive-unlabelled';
    const MOBILE_BREAKPOINT = 768;

    if (window[GLOBAL_GUARD]) {
        return;
    }

    window[GLOBAL_GUARD] = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        initialized: false,
        tables: new Map(),
        lateObserver: null,
        lateTimer: null,
        currentConfig: null,
        viewportQuery: null,
        viewportBound: false
    };

    /*
     * État initial des cellules avant toute intervention du 005.
     * WeakMap évite toute fuite mémoire si DataTables remplace les lignes.
     */
    const ORIGINAL_CELL_STATE = new WeakMap();

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        detailEnabled: true,
        holdingsEnabled: true,
        holdingsMode: 'stack',
        otherholdingsEnabled: true,
        otherholdingsMode: 'stack',
        primaryColumns: 'itemcallnumber,barcode,homebranch,holdingbranch,status',
        actionColumns: 'actions,action,edit,modify'
    });

    const DETAIL_PATH = '/cgi-bin/koha/catalogue/detail.pl';

    function isPlainObject(value) {
        return Object.prototype.toString.call(value) === '[object Object]';
    }

    function clone(value) {
        if (Array.isArray(value)) {
            return value.map(clone);
        }
        if (isPlainObject(value)) {
            const result = {};
            Object.keys(value).forEach(function (key) {
                result[key] = clone(value[key]);
            });
            return result;
        }
        return value;
    }

    function normalizeUserConfig(rawConfig) {
        const source = isPlainObject(rawConfig) ? rawConfig : {};
        const result = clone(DEFAULT_CONFIG);

        if (typeof source.enabled === 'boolean') result.enabled = source.enabled;
        if (typeof source.detailEnabled === 'boolean') result.detailEnabled = source.detailEnabled;
        if (typeof source.holdingsEnabled === 'boolean') result.holdingsEnabled = source.holdingsEnabled;
        if (source.holdingsMode === 'scroll' || source.holdingsMode === 'stack') {
            result.holdingsMode = source.holdingsMode;
        }
        if (typeof source.otherholdingsEnabled === 'boolean') result.otherholdingsEnabled = source.otherholdingsEnabled;
        if (source.otherholdingsMode === 'scroll' || source.otherholdingsMode === 'stack') {
            result.otherholdingsMode = source.otherholdingsMode;
        }
        result.primaryColumns = typeof source.primaryColumns === 'string' ? source.primaryColumns : DEFAULT_CONFIG.primaryColumns;
        result.actionColumns = typeof source.actionColumns === 'string' ? source.actionColumns : DEFAULT_CONFIG.actionColumns;

        /*
         * Compatibilité avec la configuration 2.0.0 qui utilisait pages[].
         * Cela permet de reprendre sans casse un éventuel objet injecté avant
         * le passage au registre PMK central.
         */
        if (Array.isArray(source.pages)) {
            const page = source.pages.find(function (candidate) {
                return candidate && candidate.id === 'catalogue.detail';
            });
            if (page) {
                result.detailEnabled = page.enabled !== false;
                const tables = Array.isArray(page.tables) ? page.tables : [];
                const holdings = tables.find(function (table) {
                    return table && table.id === 'holdings_table';
                });
                const other = tables.find(function (table) {
                    return table && table.id === 'otherholdings_table';
                });
                if (holdings) {
                    result.holdingsEnabled = holdings.enabled !== false;
                    result.holdingsMode = holdings.mode === 'scroll' ? 'scroll' : 'stack';
                }
                if (other) {
                    result.otherholdingsEnabled = other.enabled !== false;
                    result.otherholdingsMode = other.mode === 'scroll' ? 'scroll' : 'stack';
                }
            }
        }

        return result;
    }

    function buildPageConfig(config) {
        if (!config || config.enabled === false || config.detailEnabled === false) {
            return null;
        }

        return {
            id: 'catalogue.detail',
            enabled: true,
            paths: [DETAIL_PATH],
            tables: [
                {
                    id: 'holdings_table',
                    enabled: config.holdingsEnabled !== false,
                    mode: config.holdingsMode === 'scroll' ? 'scroll' : 'stack',
                    primaryColumns: config.primaryColumns,
                    actionColumns: config.actionColumns
                },
                {
                    id: 'otherholdings_table',
                    enabled: config.otherholdingsEnabled !== false,
                    mode: config.otherholdingsMode === 'scroll' ? 'scroll' : 'stack',
                    primaryColumns: config.primaryColumns,
                    actionColumns: config.actionColumns
                }
            ]
        };
    }

    function isTargetPage() {
        return normalizePath(window.location.pathname || '') === DETAIL_PATH;
    }

    function normalizePath(path) {
        if (typeof path !== 'string') {
            return '';
        }
        return path.replace(/\/+$/, '') || '/';
    }

    function normalizeText(value) {
        return String(value || '')
            .replace(/\u00a0/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function normalizeKey(value) {
        return normalizeText(value)
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }

    function safeCssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === 'function') {
            return window.CSS.escape(value);
        }
        return String(value || '').replace(/([ #;?%&,.+*~\\':"!^$[\]()=>|/@])/g, '\\$1');
    }

    function isElementHidden(element) {
        if (!element || element.nodeType !== 1) {
            return false;
        }

        if (element.hidden || element.getAttribute('aria-hidden') === 'true') {
            return true;
        }

        if (
            element.classList.contains('d-none') ||
            element.classList.contains('hidden') ||
            element.classList.contains('dt-hidden') ||
            element.classList.contains('dtr-hidden')
        ) {
            return true;
        }

        const inlineDisplay = element.style ? element.style.display : '';
        if (inlineDisplay === 'none') {
            return true;
        }

        try {
            return window.getComputedStyle(element).display === 'none';
        } catch (error) {
            return false;
        }
    }

    function stripSortingHelp(value) {
        let text = normalizeText(value);

        /*
         * Ces textes sont des aides DataTables au tri, pas des libellés métier.
         * Ils ne doivent jamais apparaître devant chaque cellule mobile.
         */
        const patterns = [
            /\bactivate to sort(?: ascending| descending)?\b/gi,
            /\bactivate to sort\b/gi,
            /\bactiver pour trier(?: par ordre croissant| par ordre décroissant)?\b/gi,
            /\bactiver pour trier\b/gi,
            /\bsort ascending\b/gi,
            /\bsort descending\b/gi,
            /\btrier par ordre croissant\b/gi,
            /\btrier par ordre décroissant\b/gi
        ];

        patterns.forEach(function (pattern) {
            text = text.replace(pattern, ' ');
        });

        return normalizeText(text);
    }

    function getHeaderLabel(header) {
        if (!header) {
            return '';
        }

        /*
         * data-pmk-label est une surcharge volontaire. En revanche aria-label
         * et title appartiennent souvent à DataTables ("Activate to sort") :
         * on ne les utilise jamais comme nom de colonne.
         */
        const explicitLabel = stripSortingHelp(
            header.getAttribute('data-pmk-label') || ''
        );

        if (explicitLabel) {
            return explicitLabel;
        }

        const cloneNode = header.cloneNode(true);
        cloneNode.querySelectorAll(
            [
                '.DataTables_sort_icon',
                '.dt-column-order',
                '.sorting_1',
                '.visually-hidden',
                '.sr-only',
                '[data-dt-order]',
                'script',
                'style'
            ].join(', ')
        ).forEach(function (node) {
            node.remove();
        });

        return stripSortingHelp(cloneNode.textContent || header.textContent || '');
    }

    function getHeaderTechnicalKey(header, index, tableId) {
        if (!header) {
            return tableId + '-column-' + index;
        }

        const candidates = [
            header.getAttribute('data-colname'),
            header.getAttribute('data-column'),
            header.getAttribute('data-name'),
            header.id
        ];

        for (let i = 0; i < candidates.length; i += 1) {
            const key = normalizeKey(candidates[i]);
            if (key) {
                return key;
            }
        }

        return tableId + '-column-' + index;
    }

    function buildHeaderModel(table) {
        const headerRow = table.querySelector('thead tr:last-child');
        if (!headerRow) {
            return null;
        }

        const headers = Array.from(headerRow.cells || []);
        if (!headers.length) {
            return null;
        }

        const model = [];
        const byId = new Map();
        const byKey = new Map();
        let logicalIndex = 0;

        headers.forEach(function (header) {
            const colspan = Math.max(1, Number(header.getAttribute('colspan') || 1));
            const label = getHeaderLabel(header);
            const key = getHeaderTechnicalKey(header, logicalIndex, table.id || 'table');
            const descriptor = {
                element: header,
                id: normalizeText(header.id),
                key: key,
                label: label,
                hidden: isElementHidden(header),
                startIndex: logicalIndex,
                colspan: colspan
            };

            if (descriptor.id) {
                byId.set(descriptor.id, descriptor);
            }
            if (descriptor.key) {
                byKey.set(descriptor.key, descriptor);
            }

            for (let offset = 0; offset < colspan; offset += 1) {
                model[logicalIndex + offset] = descriptor;
            }

            logicalIndex += colspan;
        });

        return {
            list: model,
            byId: byId,
            byKey: byKey,
            logicalLength: logicalIndex
        };
    }

    function getCellTechnicalCandidates(cell) {
        const values = [
            cell.getAttribute('data-colname'),
            cell.getAttribute('data-column'),
            cell.getAttribute('data-name'),
            cell.id
        ];

        Array.from(cell.classList || []).forEach(function (className) {
            values.push(className);
        });

        return values
            .map(normalizeKey)
            .filter(Boolean);
    }

    function descriptorFromHeadersAttribute(cell, headerModel) {
        const headersAttr = normalizeText(cell.getAttribute('headers'));
        if (!headersAttr) {
            return null;
        }

        const ids = headersAttr.split(/\s+/).filter(Boolean);
        for (let i = 0; i < ids.length; i += 1) {
            if (headerModel.byId.has(ids[i])) {
                return headerModel.byId.get(ids[i]);
            }
        }

        return null;
    }

    function descriptorFromTechnicalIdentity(cell, headerModel) {
        const candidates = getCellTechnicalCandidates(cell);
        if (!candidates.length) {
            return null;
        }

        const descriptors = Array.from(new Set(headerModel.list.filter(Boolean)));

        for (let i = 0; i < candidates.length; i += 1) {
            const candidate = candidates[i];

            if (headerModel.byKey.has(candidate)) {
                return headerModel.byKey.get(candidate);
            }

            for (let j = 0; j < descriptors.length; j += 1) {
                const descriptor = descriptors[j];
                if (!descriptor || !descriptor.key) {
                    continue;
                }

                if (
                    descriptor.key === candidate ||
                    descriptor.key.endsWith('-' + candidate) ||
                    candidate.endsWith('-' + descriptor.key)
                ) {
                    return descriptor;
                }
            }
        }

        return null;
    }

    function descriptorFromPosition(cell, row, headerModel) {
        if (!cell || !row || !headerModel) {
            return null;
        }

        const colspan = Math.max(1, Number(cell.getAttribute('colspan') || 1));
        if (colspan > 1) {
            return null;
        }

        let logicalIndex = 0;
        const cells = Array.from(row.cells || []);

        for (let i = 0; i < cells.length; i += 1) {
            const current = cells[i];
            const currentColspan = Math.max(1, Number(current.getAttribute('colspan') || 1));

            if (current === cell) {
                return headerModel.list[logicalIndex] || null;
            }

            logicalIndex += currentColspan;
        }

        return null;
    }

    function resolveCellDescriptor(cell, row, headerModel) {
        return (
            descriptorFromHeadersAttribute(cell, headerModel) ||
            descriptorFromTechnicalIdentity(cell, headerModel) ||
            descriptorFromPosition(cell, row, headerModel) ||
            null
        );
    }

    function snapshotCellState(cell) {
        if (!cell || ORIGINAL_CELL_STATE.has(cell)) {
            return;
        }

        ORIGINAL_CELL_STATE.set(cell, {
            hadLabel: cell.hasAttribute(LABEL_ATTR),
            label: cell.getAttribute(LABEL_ATTR),
            hadKey: cell.hasAttribute(KEY_ATTR),
            key: cell.getAttribute(KEY_ATTR),
            hadPriority: cell.hasAttribute(PRIORITY_ATTR),
            priority: cell.getAttribute(PRIORITY_ATTR),
            hadHiddenClass: cell.classList.contains(HIDDEN_CLASS),
            hadUnlabelledClass: cell.classList.contains(UNLABELLED_CLASS)
        });
    }

    function clearManagedCellState(cell) {
        if (!cell) return;
        cell.removeAttribute(LABEL_ATTR);
        cell.removeAttribute(KEY_ATTR);
        cell.removeAttribute(PRIORITY_ATTR);
        cell.classList.remove(HIDDEN_CLASS, UNLABELLED_CLASS);
    }

    function restoreCellState(cell) {
        if (!cell) return;

        const original = ORIGINAL_CELL_STATE.get(cell);
        clearManagedCellState(cell);

        if (!original) return;

        if (original.hadLabel) {
            cell.setAttribute(LABEL_ATTR, original.label === null ? '' : original.label);
        }
        if (original.hadKey) {
            cell.setAttribute(KEY_ATTR, original.key === null ? '' : original.key);
        }
        if (original.hadPriority) cell.setAttribute(PRIORITY_ATTR, original.priority === null ? '' : original.priority);
        if (original.hadHiddenClass) {
            cell.classList.add(HIDDEN_CLASS);
        }
        if (original.hadUnlabelledClass) {
            cell.classList.add(UNLABELLED_CLASS);
        }

        ORIGINAL_CELL_STATE.delete(cell);
    }

    function applyRowLabels(row, headerModel, tableConfig) {
        if (!row || row.nodeType !== 1 || !headerModel) {
            return false;
        }

        const cells = Array.from(row.cells || []).filter(function (cell) {
            return cell.tagName === 'TD';
        });

        if (!cells.length) {
            return false;
        }

        const rowLogicalLength = cells.reduce(function (total, cell) {
            return total + Math.max(1, Number(cell.getAttribute('colspan') || 1));
        }, 0);

        /*
         * Une ligne DataTables de type "aucun résultat" peut légitimement être
         * composée d'une seule cellule avec colspan. On la conserve, sans tenter
         * de lui inventer un libellé. Toute autre divergence de structure entraîne
         * un abandon de la ligne plutôt qu'un décalage de colonnes.
         */
        if (rowLogicalLength !== headerModel.logicalLength) {
            cells.forEach(function (cell) {
                snapshotCellState(cell);
                clearManagedCellState(cell);
                cell.classList.add(UNLABELLED_CLASS);
            });

            if (cells.length === 1 && rowLogicalLength >= headerModel.logicalLength) {
                return true;
            }

            return false;
        }

        let resolvedCount = 0;

        cells.forEach(function (cell) {
            snapshotCellState(cell);
            clearManagedCellState(cell);

            const descriptor = resolveCellDescriptor(cell, row, headerModel);
            const hidden = isElementHidden(cell) || (descriptor && descriptor.hidden);

            if (hidden) {
                cell.classList.add(HIDDEN_CLASS);
            }

            if (!descriptor) {
                cell.classList.add(UNLABELLED_CLASS);
                return;
            }

            resolvedCount += 1;
            cell.setAttribute(KEY_ATTR, descriptor.key || '');
            const primary = String(tableConfig && tableConfig.primaryColumns || '').split(/[\s,;]+/).map(normalizeKey).filter(Boolean);
            const actions = String(tableConfig && tableConfig.actionColumns || '').split(/[\s,;]+/).map(normalizeKey).filter(Boolean);
            if (primary.some(function (key) { return descriptor.key === key || descriptor.key.endsWith('-' + key); })) cell.setAttribute(PRIORITY_ATTR, 'primary');
            if (actions.some(function (key) { return descriptor.key === key || descriptor.key.endsWith('-' + key); })) cell.setAttribute(PRIORITY_ATTR, 'actions');

            if (descriptor.label) {
                cell.setAttribute(LABEL_ATTR, descriptor.label);
            } else {
                cell.classList.add(UNLABELLED_CLASS);
            }
        });

        /*
         * Fail-safe : si moins de la moitié des cellules sont identifiées,
         * la ligne est considérée trop ambiguë pour la présentation empilée.
         */
        const minimumResolved = Math.max(1, Math.ceil(cells.length / 2));
        return resolvedCount >= minimumResolved;
    }

    function restoreTable(table) {
        if (!table) {
            return;
        }

        table.classList.remove(TABLE_CLASS, 'pmk-responsive-mode-stack', 'pmk-responsive-mode-scroll');
        table.removeAttribute(READY_ATTR);

        table.querySelectorAll('tbody td').forEach(function (cell) {
            restoreCellState(cell);
        });
    }

    function applyTable(table, tableConfig) {
        if (!table || !tableConfig || tableConfig.enabled === false) {
            return false;
        }

        const headerModel = buildHeaderModel(table);
        if (!headerModel || !headerModel.logicalLength) {
            restoreTable(table);
            return false;
        }

        const rows = Array.from(table.querySelectorAll('tbody tr'));
        if (!rows.length) {
            table.classList.add(TABLE_CLASS);
            table.classList.toggle('pmk-responsive-mode-stack', tableConfig.mode !== 'scroll');
            table.classList.toggle('pmk-responsive-mode-scroll', tableConfig.mode === 'scroll');
            table.setAttribute(READY_ATTR, '1');
            return true;
        }

        let safeRows = 0;
        rows.forEach(function (row) {
            if (applyRowLabels(row, headerModel, tableConfig)) {
                safeRows += 1;
            }
        });

        /*
         * Fail-safe au niveau du tableau : si aucune ligne réelle n'a pu être
         * associée de façon suffisamment fiable, on n'active pas le rendu mobile.
         */
        if (safeRows === 0) {
            restoreTable(table);
            return false;
        }

        table.classList.add(TABLE_CLASS);
        table.classList.toggle('pmk-responsive-mode-stack', tableConfig.mode !== 'scroll');
        table.classList.toggle('pmk-responsive-mode-scroll', tableConfig.mode === 'scroll');
        table.setAttribute(READY_ATTR, '1');
        return true;
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) {
            return;
        }

        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.setAttribute('data-pmk-module', MODULE_ID);
        style.textContent = `
/* PimpMyKoha 005 - Tables responsives */
.${TABLE_CLASS} {
    width: 100%;
}

.${TABLE_CLASS}.pmk-responsive-mode-scroll {
    min-width: max-content;
}

@media screen and (max-width: ${MOBILE_BREAKPOINT}px) {
    .${TABLE_CLASS}.pmk-responsive-mode-scroll {
        display: table;
        width: max-content;
        min-width: 100%;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack {
        display: block !important;
        width: 100% !important;
        border-collapse: separate;
        border-spacing: 0;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > thead {
        display: table-header-group !important;
        position: absolute !important;
        width: 1px !important;
        height: 1px !important;
        padding: 0 !important;
        margin: -1px !important;
        overflow: hidden !important;
        clip: rect(0, 0, 0, 0) !important;
        clip-path: inset(50%) !important;
        white-space: nowrap !important;
        border: 0 !important;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody {
        display: block !important;
        width: 100% !important;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr {
        display: flex !important;
        flex-direction: column;
        width: 100% !important;
        margin: 0 0 0.75rem 0;
        border: 1px solid var(--bs-border-color, #dee2e6);
        border-radius: 0.375rem;
        background: var(--bs-body-bg, #fff);
        overflow: hidden;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td[${PRIORITY_ATTR}="primary"] { order: -2; }
    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td[${PRIORITY_ATTR}="actions"] {
        order: 2;
        position: sticky;
        bottom: 0;
        z-index: 1;
        background: var(--bs-body-bg, #fff);
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td {
        box-sizing: border-box;
        width: 100% !important;
        min-width: 0;
        padding: 0.5rem 0.625rem !important;
        border: 0;
        border-bottom: 1px solid var(--bs-border-color, #dee2e6);
        vertical-align: top;
        text-align: left;
        overflow-wrap: anywhere;
        word-break: normal;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td:not(.${UNLABELLED_CLASS}):not(.${HIDDEN_CLASS}) {
        display: grid !important;
        grid-template-columns: minmax(7.5rem, 36%) minmax(0, 1fr);
        gap: 0.5rem 0.75rem;
        align-items: start;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td:not(.${UNLABELLED_CLASS}):not(.${HIDDEN_CLASS})::before {
        content: attr(${LABEL_ATTR}) !important;
        font-weight: 600;
        line-height: 1.35;
        text-align: left;
        color: inherit;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td.${UNLABELLED_CLASS}:not(.${HIDDEN_CLASS}) {
        display: block !important;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td.${UNLABELLED_CLASS}:not(.${HIDDEN_CLASS})::before {
        content: none !important;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td.${HIDDEN_CLASS} {
        display: none !important;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td:last-child {
        border-bottom: 0;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td .btn-group,
    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td .btn-toolbar {
        max-width: 100%;
        flex-wrap: wrap;
        gap: 0.25rem;
    }

    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td img,
    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td svg {
        max-width: 100%;
        height: auto;
    }
}

@media screen and (max-width: 480px) {
    .${TABLE_CLASS}.pmk-responsive-mode-stack > tbody > tr > td:not(.${UNLABELLED_CLASS}):not(.${HIDDEN_CLASS}) {
        grid-template-columns: 1fr !important;
        gap: 0.2rem;
    }
}
`;
        document.head.appendChild(style);
    }

    function scheduleRefresh(state, delay) {
        if (!state || !state.table || !state.config) {
            return;
        }

        if (state.refreshTimer) {
            window.clearTimeout(state.refreshTimer);
        }

        state.refreshTimer = window.setTimeout(function () {
            state.refreshTimer = null;

            const guard = window[GLOBAL_GUARD];
            const query = guard && guard.viewportQuery;
            if (query && !query.matches) {
                restoreTable(state.table);
                return;
            }

            applyTable(state.table, state.config);
        }, typeof delay === 'number' ? delay : 60);
    }

    function bindJQueryDataTablesEvents(state) {
        if (!window.jQuery || !state || !state.table || state.jqueryBound) {
            return;
        }

        const $table = window.jQuery(state.table);
        const namespace = '.pmk005ResponsiveTables';

        $table.off(namespace);
        $table.on(
            'draw.dt' + namespace +
            ' column-visibility.dt' + namespace +
            ' responsive-resize.dt' + namespace,
            function () {
                scheduleRefresh(state, 30);
            }
        );

        state.jqueryBound = true;
    }

    function bindTableObserver(state) {
        if (!state || !state.table || state.observer) {
            return;
        }

        state.observer = new MutationObserver(function (mutations) {
            let shouldRefresh = false;

            for (let i = 0; i < mutations.length; i += 1) {
                const mutation = mutations[i];

                if (mutation.type === 'characterData') {
                    const parent = mutation.target && mutation.target.parentElement;
                    if (parent && parent.closest('thead')) {
                        shouldRefresh = true;
                        break;
                    }
                }

                if (mutation.type === 'childList') {
                    const target = mutation.target && mutation.target.nodeType === 1
                        ? mutation.target
                        : mutation.target && mutation.target.parentElement;

                    if (!target) {
                        continue;
                    }

                    if (
                        target.closest('thead') ||
                        target.closest('tbody') ||
                        Array.from(mutation.addedNodes || []).some(function (node) {
                            return node.nodeType === 1 && (
                                node.matches('thead, tbody, tr') ||
                                node.querySelector('thead, tbody, tr')
                            );
                        })
                    ) {
                        shouldRefresh = true;
                        break;
                    }
                }
            }

            if (shouldRefresh) {
                scheduleRefresh(state, 80);
            }
        });

        state.observer.observe(state.table, {
            childList: true,
            subtree: true,
            characterData: true
        });
    }

    function createTableState(table, tableConfig) {
        const guard = window[GLOBAL_GUARD];
        const existing = guard.tables.get(table.id);

        if (existing && existing.table === table) {
            existing.config = tableConfig;
            return existing;
        }

        if (existing) {
            if (existing.observer) {
                existing.observer.disconnect();
            }
            if (existing.refreshTimer) {
                window.clearTimeout(existing.refreshTimer);
            }
        }

        const state = {
            table: table,
            config: tableConfig,
            observer: null,
            refreshTimer: null,
            jqueryBound: false
        };

        guard.tables.set(table.id, state);
        return state;
    }

    function enhanceTable(tableConfig) {
        if (!tableConfig || tableConfig.enabled === false || !tableConfig.id) {
            return;
        }

        const id = String(tableConfig.id).trim();
        if (!/^[A-Za-z][A-Za-z0-9_:\-.]*$/.test(id)) {
            return;
        }

        const table = document.getElementById(id);
        if (!table || table.tagName !== 'TABLE') {
            return;
        }

        const state = createTableState(table, tableConfig);
        applyTable(table, tableConfig);
        bindJQueryDataTablesEvents(state);
        bindTableObserver(state);
    }

    function enhanceConfiguredTables(pageConfig) {
        if (!pageConfig || !Array.isArray(pageConfig.tables)) {
            return;
        }

        pageConfig.tables.forEach(enhanceTable);
    }

    function stopLateTableObserver() {
        const guard = window[GLOBAL_GUARD];
        if (!guard) return;
        if (guard.lateObserver) {
            guard.lateObserver.disconnect();
            guard.lateObserver = null;
        }
        if (guard.lateTimer) {
            window.clearTimeout(guard.lateTimer);
            guard.lateTimer = null;
        }
    }

    function observeLateTables(pageConfig) {
        stopLateTableObserver();

        if (!pageConfig || !Array.isArray(pageConfig.tables)) {
            return;
        }

        const expectedIds = pageConfig.tables
            .filter(function (tableConfig) {
                return tableConfig && tableConfig.enabled !== false && tableConfig.id;
            })
            .map(function (tableConfig) {
                return String(tableConfig.id).trim();
            });

        if (!expectedIds.length) {
            return;
        }

        const allAlreadyPresent = expectedIds.every(function (id) {
            return Boolean(document.getElementById(id));
        });

        if (allAlreadyPresent) {
            return;
        }

        const guard = window[GLOBAL_GUARD];
        const observer = new MutationObserver(function () {
            let foundNew = false;

            pageConfig.tables.forEach(function (tableConfig) {
                if (!tableConfig || tableConfig.enabled === false || !tableConfig.id) {
                    return;
                }

                const id = String(tableConfig.id).trim();
                if (
                    document.getElementById(id) &&
                    !guard.tables.has(id)
                ) {
                    enhanceTable(tableConfig);
                    foundNew = true;
                }
            });

            const allFound = expectedIds.every(function (id) {
                return Boolean(document.getElementById(id));
            });

            if (allFound) {
                stopLateTableObserver();
            } else if (foundNew) {
                enhanceConfiguredTables(pageConfig);
            }
        });

        guard.lateObserver = observer;
        observer.observe(document.body || document.documentElement, {
            childList: true,
            subtree: true
        });

        guard.lateTimer = window.setTimeout(function () {
            stopLateTableObserver();
        }, 10000);
    }

    function clearManagedTables() {
        const guard = window[GLOBAL_GUARD];
        if (!guard) return;

        stopLateTableObserver();

        guard.tables.forEach(function (state) {
            if (!state) return;
            if (state.observer) state.observer.disconnect();
            if (state.refreshTimer) window.clearTimeout(state.refreshTimer);
            if (state.jqueryBound && window.jQuery && state.table) {
                window.jQuery(state.table).off('.pmk005ResponsiveTables');
            }
            if (state.table) restoreTable(state.table);
        });
        guard.tables.clear();

        ['holdings_table', 'otherholdings_table'].forEach(function (id) {
            const table = document.getElementById(id);
            if (table) restoreTable(table);
        });
    }

    function isMobileViewport() {
        const guard = window[GLOBAL_GUARD];
        if (!guard) return window.innerWidth <= MOBILE_BREAKPOINT;

        if (!guard.viewportQuery && typeof window.matchMedia === 'function') {
            guard.viewportQuery = window.matchMedia(
                '(max-width: ' + MOBILE_BREAKPOINT + 'px)'
            );
        }

        return guard.viewportQuery
            ? guard.viewportQuery.matches
            : window.innerWidth <= MOBILE_BREAKPOINT;
    }

    function bindViewportWatcher() {
        const guard = window[GLOBAL_GUARD];
        if (!guard || guard.viewportBound || typeof window.matchMedia !== 'function') {
            return;
        }

        guard.viewportQuery = guard.viewportQuery || window.matchMedia(
            '(max-width: ' + MOBILE_BREAKPOINT + 'px)'
        );

        const handler = function () {
            applyRuntimeConfig(guard.currentConfig || DEFAULT_CONFIG);
        };

        if (typeof guard.viewportQuery.addEventListener === 'function') {
            guard.viewportQuery.addEventListener('change', handler);
        } else if (typeof guard.viewportQuery.addListener === 'function') {
            guard.viewportQuery.addListener(handler);
        }

        guard.viewportBound = true;
    }

    function applyRuntimeConfig(rawConfig) {
        const config = normalizeUserConfig(rawConfig);
        const guard = window[GLOBAL_GUARD];

        if (guard) {
            guard.currentConfig = clone(config);
        }

        bindViewportWatcher();
        clearManagedTables();

        /*
         * Le 005 ne modifie le DOM que lorsque son affichage mobile est
         * réellement actif. Sur écran large, Koha et les autres modules
         * retrouvent exactement leurs libellés/attributs d'origine.
         */
        if (
            !isTargetPage() ||
            config.enabled === false ||
            config.detailEnabled === false ||
            !isMobileViewport()
        ) {
            if (guard) guard.initialized = true;
            return;
        }

        const pageConfig = buildPageConfig(config);
        if (!pageConfig) {
            if (guard) guard.initialized = true;
            return;
        }

        injectStyles();
        enhanceConfiguredTables(pageConfig);
        observeLateTables(pageConfig);

        if (guard) guard.initialized = true;
    }

    function validateConfig(config) {
        const normalized = normalizeUserConfig(config);
        const validModes = ['stack', 'scroll'];
        if (!validModes.includes(normalized.holdingsMode) || !validModes.includes(normalized.otherholdingsMode)) {
            return {
                ok: false,
                message: (document.documentElement.lang || '').toLowerCase().startsWith('fr')
                    ? "Le mode d'affichage mobile sélectionné n'est pas valide."
                    : "The selected mobile display mode is invalid."
            };
        }
        return { ok: true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: {
                fr: "Tableaux d’exemplaires sur mobile",
                en: "Item tables on mobile"
            },
            description: {
                fr: "Rend les tableaux d’exemplaires plus lisibles sur les petits écrans, sans modifier les données Koha.",
                en: "Makes item tables easier to read on small screens without changing Koha data."
            },
            category: {
                fr: "Interface / responsive",
                en: "Interface / responsive"
            },
            supportedPages: ["catalogue.detail"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "page",
                    label: {
                        fr: "Page concernée",
                        en: "Where it applies"
                    },
                    description: {
                        fr: "Ce module agit uniquement sur la fiche détaillée d’une notice.",
                        en: "This module only applies to the record detail page."
                    },
                    fields: [
                        {
                            key: "detailEnabled",
                            type: "boolean",
                            label: {
                                fr: "Activer sur la fiche notice",
                                en: "Enable on record details"
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "tables",
                    label: {
                        fr: "Affichage des tableaux",
                        en: "Table display"
                    },
                    description: {
                        fr: "Choisis simplement le comportement de chaque tableau sur petit écran.",
                        en: "Choose how each item table should behave on small screens."
                    },
                    fields: [
                        {
                            key: "holdingsEnabled",
                            type: "boolean",
                            label: {
                                fr: "Adapter le tableau Exemplaires",
                                en: "Adapt the Holdings table"
                            }
                        },
                        {
                            key: "holdingsMode",
                            type: "select",
                            label: {
                                fr: "Affichage mobile — Exemplaires",
                                en: "Mobile display — Holdings"
                            },
                            when: function (rootObject) {
                                return rootObject.holdingsEnabled !== false;
                            },
                            options: [
                                {
                                    value: "stack",
                                    label: {
                                        fr: "Fiches empilées — recommandé",
                                        en: "Stacked cards — recommended"
                                    }
                                },
                                {
                                    value: "scroll",
                                    label: {
                                        fr: "Tableau avec défilement horizontal",
                                        en: "Horizontally scrollable table"
                                    }
                                }
                            ]
                        },
                        {
                            key: "otherholdingsEnabled",
                            type: "boolean",
                            label: {
                                fr: "Adapter le tableau Autres exemplaires",
                                en: "Adapt the Other holdings table"
                            }
                        },
                        {
                            key: "otherholdingsMode",
                            type: "select",
                            label: {
                                fr: "Affichage mobile — Autres exemplaires",
                                en: "Mobile display — Other holdings"
                            },
                            when: function (rootObject) {
                                return rootObject.otherholdingsEnabled !== false;
                            },
                            options: [
                                {
                                    value: "stack",
                                    label: {
                                        fr: "Fiches empilées — recommandé",
                                        en: "Stacked cards — recommended"
                                    }
                                },
                                {
                                    value: "scroll",
                                    label: {
                                        fr: "Tableau avec défilement horizontal",
                                        en: "Horizontally scrollable table"
                                    }
                                }
                            ]
                        },
                        {
                            key: "primaryColumns",
                            type: "text",
                            label: { fr: "Colonnes à afficher en premier", en: "Columns shown first" },
                            help: { fr: "Identifiants techniques séparés par des virgules. Les valeurs par défaut reconnaissent cote, code-barres, bibliothèques et statut.", en: "Comma-separated technical identifiers. Defaults recognise call number, barcode, libraries and status." }
                        },
                        {
                            key: "actionColumns",
                            type: "text",
                            label: { fr: "Colonnes d’actions à garder accessibles", en: "Action columns kept accessible" },
                            help: { fr: "Ces colonnes restent à la fin de chaque fiche et visibles lors du défilement vertical.", en: "These columns stay at the end of each card and visible while scrolling vertically." }
                        }
                    ]
                }
            ]
        };
    }

    let coreRegistered = false;
    let runtimeStarted = false;
    let unsubscribeConfig = null;

    async function startWithCore() {
        if (!window.PMKConfig) return;

        if (!coreRegistered) {
            window.PMKConfig.registerModule(moduleDefinition());
            coreRegistered = true;
        }

        if (!isTargetPage() || runtimeStarted) return;
        runtimeStarted = true;

        let config = clone(DEFAULT_CONFIG);
        try {
            config = await window.PMKConfig.getConfig(MODULE_ID);
        } catch (_) {
            config = clone(DEFAULT_CONFIG);
        }

        applyRuntimeConfig(config);

        if (typeof window.PMKConfig.subscribe === 'function' && !unsubscribeConfig) {
            unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
                applyRuntimeConfig(newConfig);
            });
        }
    }

    function startWithoutCore() {
        if (!isTargetPage() || runtimeStarted) return;
        runtimeStarted = true;
        applyRuntimeConfig(window.PMK_RESPONSIVE_TABLES_CONFIG || DEFAULT_CONFIG);
    }

    function onDomReady(callback) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', callback, { once: true });
        } else {
            callback();
        }
    }

    onDomReady(function () {
        if (window.PMKConfig) {
            startWithCore();
        } else {
            startWithoutCore();
            window.addEventListener('pmk:config-ready', function () {
                startWithCore();
            }, { once: true });
        }
    });
}());

;window.PMKNonPlugin.loaded.push("005-style-holdings-table.js");
} catch (error) { window.PMKNonPlugin.errors.push("005-style-holdings-table.js: "+error.message); console.error("[PMK] 005-style-holdings-table.js",error); };
try {
/* ============================================================
   006-copy-patron-identifiers.js
   Module PMK : Actions de copie
   Version    : 4.2.0-preplugin
   Date       : 2026-09-20

   Fonction :
   - ajoute des actions de copie sur n'importe quelle page Koha ;
   - l'élément source est choisi avec le picker commun PMK ;
   - copie le texte, la valeur d'un champ ou un attribut HTML ;
   - copie la valeur complète, un préfixe ou un suffixe ;
   - action placée avant ou après l'élément (ou à l'intérieur) ;
   - rendu discret : icône/image sans apparence de bouton ;
   - couleur Font Awesome normale et au survol configurables ;
   - taille de l’action/icône configurable ;
   - taille et couleur du texte configurables, y compris au survol ;
   - icône facultative : Font Awesome, image ou aucune ;
   - texte facultatif et personnalisable FR/EN ;
   - compatible avec les anciens réglages 006 pages/actions ;
   - absorbe le script historique 056 (copie ISBN / EAN / titre sur search.pl et detail.pl) ;
   - absorbe le script historique 115 (copie groupée en tableaux : CB / biblionumbers) ;
   - propose un mode individuel et un mode groupé/tableau dans un seul moteur ;
   - peut utiliser un élément visuel déjà présent comme déclencheur sans ajouter un second bouton ;
   - aucun accès direct à Firebase : PMKConfig porte la configuration.
   ============================================================ */
(function () {
    "use strict";

    if (window.__PMK_006_COPY_ACTIONS__) return;
    window.__PMK_006_COPY_ACTIONS__ = true;

    const MODULE_ID = "copy-actions";
    const MODULE_VERSION = "4.2.0-preplugin";
    const BUILTIN_RULE_VERSION = 3;
    const STYLE_ID = "pmk-006-copy-actions-style";
    const CLUSTER_CLASS = "pmk-copy-actions";
    const BUTTON_CLASS = "pmk-copy-action";
    const FEEDBACK_CLASS = "pmk-copy-feedback";
    const TABLE_BUTTON_CLASS = "pmk-copy-table-action";

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function cleanText(value) {
        return String(value == null ? "" : value)
            .replace(/\u00a0/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function normalizePath(value) {
        const raw = String(value || "").trim();
        if (!raw) return "/";
        try {
            if (/^https?:\/\//i.test(raw)) {
                const url = new URL(raw);
                return url.pathname || "/";
            }
        } catch (_) {}
        return (raw.split("?")[0] || "/").replace(/\/+$/, "") || "/";
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const lang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function i18n(fr, en) {
        return detectLanguage() === "en" ? en : fr;
    }

    function makeId() {
        return "copy-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    }

    const CIRC_CARD_SELECTOR = [
        "label.circ_barcode .cardnumber",
        'h4 a[href*="/cgi-bin/koha/members/moremember.pl?borrowernumber="] .cardnumber',
        ".patroninfo h5 .cardnumber"
    ].join(", ");

    const BASE_DEFAULT_RULES = [
        {
            id: "legacy-moremember-username-full",
            enabled: true,
            label: "Identifiant lecteur — complet",
            pagePath: "/cgi-bin/koha/members/moremember.pl",
            selector: "#patron-username",
            targetName: "Identifiant utilisateur",
            matchMode: "first",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".label, .pmk-context-config, .pmk-copy-actions",
            trim: true,
            extractRegex: "",
            regexFlags: "",
            regexGroup: 0,
            transform: "full",
            length: 4,
            placement: "inside-end",
            visualType: "fa",
            iconClass: "fa fa-copy",
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier l'identifiant",
            titleEn: "Copy username"
        },
        {
            id: "legacy-moremember-card-full",
            enabled: true,
            label: "Numéro de carte — complet",
            pagePath: "/cgi-bin/koha/members/moremember.pl",
            selector: "#patron-cardnumber",
            targetName: "Numéro de carte",
            matchMode: "first",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".label, .pmk-context-config, .pmk-copy-actions",
            trim: true,
            extractRegex: "",
            regexFlags: "",
            regexGroup: 0,
            transform: "full",
            length: 4,
            placement: "inside-end",
            visualType: "fa",
            iconClass: "fa fa-copy",
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier le numéro de carte",
            titleEn: "Copy card number"
        },
        {
            id: "legacy-moremember-card-suffix4",
            enabled: true,
            label: "Numéro de carte — 4 derniers caractères",
            pagePath: "/cgi-bin/koha/members/moremember.pl",
            selector: "#patron-cardnumber",
            targetName: "Numéro de carte",
            matchMode: "first",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".label, .pmk-context-config, .pmk-copy-actions",
            trim: true,
            extractRegex: "",
            regexFlags: "",
            regexGroup: 0,
            transform: "suffix",
            length: 4,
            placement: "inside-end",
            visualType: "fa",
            iconClass: "fa fa-copy",
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier les 4 derniers caractères",
            titleEn: "Copy last 4 characters"
        },
        {
            id: "legacy-circulation-card-full",
            enabled: true,
            label: "Numéro de carte au prêt — complet",
            pagePath: "/cgi-bin/koha/circ/circulation.pl",
            selector: CIRC_CARD_SELECTOR,
            targetName: "Numéro de carte",
            matchMode: "first",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".pmk-context-config, .pmk-copy-actions",
            trim: true,
            extractRegex: "^\\(?([^()]*)\\)?$",
            regexFlags: "",
            regexGroup: 1,
            transform: "full",
            length: 4,
            placement: "after",
            visualType: "fa",
            iconClass: "fa fa-copy",
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier le numéro de carte",
            titleEn: "Copy card number"
        },
        {
            id: "legacy-circulation-card-suffix4",
            enabled: true,
            label: "Numéro de carte au prêt — 4 derniers caractères",
            pagePath: "/cgi-bin/koha/circ/circulation.pl",
            selector: CIRC_CARD_SELECTOR,
            targetName: "Numéro de carte",
            matchMode: "first",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".pmk-context-config, .pmk-copy-actions",
            trim: true,
            extractRegex: "^\\(?([^()]*)\\)?$",
            regexFlags: "",
            regexGroup: 1,
            transform: "suffix",
            length: 4,
            placement: "after",
            visualType: "fa",
            iconClass: "fa fa-copy",
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier les 4 derniers caractères",
            titleEn: "Copy last 4 characters"
        }
    ];

    /*
     * Règles historiques du 056 intégrées directement au moteur commun.
     *
     * Le 056 ne créait pas ces pictogrammes : ils sont fournis par les mises en
     * page catalogue d’origine. Le moteur "Actions de copie" se branche
     * donc sur ces déclencheurs existants, sans produire un second bouton.
     */
    const LEGACY_056_RULES = [
        {
            id: "legacy-056-search-isbn",
            enabled: true,
            label: "Résultats catalogue — copier ISBN",
            pagePath: "/cgi-bin/koha/catalogue/search.pl",
            actionMode: "existing-trigger",
            selector: ".isbn-result",
            targetName: "ISBN",
            triggerSelector: "span.copy-isbn-result",
            triggerName: "Action Copier ISBN",
            matchMode: "all",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier ISBN",
            titleEn: "Copy ISBN"
        },
        {
            id: "legacy-056-search-ean",
            enabled: true,
            label: "Résultats catalogue — copier EAN",
            pagePath: "/cgi-bin/koha/catalogue/search.pl",
            actionMode: "existing-trigger",
            selector: ".ean-result",
            targetName: "EAN",
            triggerSelector: "span.copy-ean-result",
            triggerName: "Action Copier EAN",
            matchMode: "all",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier EAN",
            titleEn: "Copy EAN"
        },
        {
            id: "legacy-056-search-title",
            enabled: true,
            label: "Résultats catalogue — copier le titre",
            pagePath: "/cgi-bin/koha/catalogue/search.pl",
            actionMode: "existing-trigger",
            selector: ".firstresult .titlebibresult",
            targetName: "Titre",
            triggerSelector: "img.copy-title-result",
            triggerName: "Action Copier le titre",
            matchMode: "all",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier le titre",
            titleEn: "Copy title"
        },
        {
            id: "legacy-056-detail-isbn",
            enabled: true,
            label: "Notice détaillée — copier ISBN",
            pagePath: "/cgi-bin/koha/catalogue/detail.pl",
            actionMode: "existing-trigger",
            selector: ".tech-isbn",
            targetName: "ISBN",
            triggerSelector: ".copy-isbn",
            triggerName: "Action Copier ISBN",
            matchMode: "first",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier ISBN",
            titleEn: "Copy ISBN"
        },
        {
            id: "legacy-056-detail-ean",
            enabled: true,
            label: "Notice détaillée — copier EAN",
            pagePath: "/cgi-bin/koha/catalogue/detail.pl",
            actionMode: "existing-trigger",
            selector: ".tech-ean",
            targetName: "EAN",
            triggerSelector: ".copy-ean",
            triggerName: "Action Copier EAN",
            matchMode: "first",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier EAN",
            titleEn: "Copy EAN"
        },
        {
            id: "legacy-056-detail-title",
            enabled: true,
            label: "Notice détaillée — copier le titre",
            pagePath: "/cgi-bin/koha/catalogue/detail.pl",
            actionMode: "existing-trigger",
            selector: ".titlemika",
            targetName: "Titre",
            triggerSelector: ".copy-title",
            triggerName: "Action Copier le titre",
            matchMode: "first",
            valueSource: "text",
            trim: true,
            transform: "full",
            titleFr: "Copier le titre",
            titleEn: "Copy title"
        }
    ];


    /*
     * Règles historiques du 115 intégrées au moteur commun.
     *
     * Le comportement visible historique est conservé :
     * - bouton dans la barre DataTables ;
     * - copie des valeurs actuellement affichées ;
     * - déduplication ;
     * - une valeur par ligne dans le presse-papiers.
     *
     * Les sélecteurs par libellé restent uniquement des fallbacks FR/EN :
     * une classe/structure stable est utilisée en priorité lorsqu'elle existe.
     */
    const LEGACY_115_TABLE_RULES = [
        {
            id: "legacy-115-returns-barcodes",
            legacyButtonId: "btn-copy-all-barcodes",
            enabled: true,
            label: "Retours — copier les codes-barres",
            pagePath: "/cgi-bin/koha/circ/returns.pl",
            tableSelector: "#checkedintable",
            tableName: "Table des retours",
            sourceMode: "column",
            columnHeaderSelector: "thead th.ci-barcode",
            columnHeaderLabels: "Code à barres;Code barre;Code-barres;Barcode",
            sourceSelector: "",
            valueSource: "text",
            attributeName: "",
            urlParam: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les codes-barres",
            buttonTextEn: "Copy barcodes",
            titleFr: "Copier tous les codes-barres affichés",
            titleEn: "Copy all displayed barcodes",
            feedbackSuccessTextFr: "{count} code(s) à barres copié(s) !",
            feedbackSuccessTextEn: "{count} barcode(s) copied!",
            feedbackEmptyTextFr: "Aucun code-barres trouvé",
            feedbackEmptyTextEn: "No barcode found"
        },
        {
            id: "legacy-115-moremember-barcodes",
            legacyButtonId: "btn-copy-all-barcodes",
            enabled: true,
            label: "Fiche lecteur — copier les codes-barres des prêts",
            pagePath: "/cgi-bin/koha/members/moremember.pl",
            tableSelector: "#issues-table",
            tableName: "Prêts du lecteur",
            sourceMode: "selector",
            sourceSelector: '#issues-table tbody a[href*="/cgi-bin/koha/catalogue/moredetail.pl?biblionumber="]',
            sourceName: "Code-barres du prêt",
            valueSource: "text",
            attributeName: "",
            urlParam: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les codes-barres",
            buttonTextEn: "Copy barcodes",
            titleFr: "Copier tous les codes-barres affichés",
            titleEn: "Copy all displayed barcodes",
            feedbackSuccessTextFr: "{count} code(s) à barres copié(s) !",
            feedbackSuccessTextEn: "{count} barcode(s) copied!",
            feedbackEmptyTextFr: "Aucun code-barres trouvé",
            feedbackEmptyTextEn: "No barcode found"
        },
        {
            id: "legacy-115-circulation-barcodes",
            legacyButtonId: "btn-copy-all-barcodes",
            enabled: true,
            label: "Prêt — copier les codes-barres des prêts",
            pagePath: "/cgi-bin/koha/circ/circulation.pl",
            tableSelector: "#issues-table",
            tableName: "Prêts du lecteur",
            sourceMode: "selector",
            sourceSelector: '#issues-table tbody a[href*="/cgi-bin/koha/catalogue/moredetail.pl?biblionumber="]',
            sourceName: "Code-barres du prêt",
            valueSource: "text",
            attributeName: "",
            urlParam: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les codes-barres",
            buttonTextEn: "Copy barcodes",
            titleFr: "Copier tous les codes-barres affichés",
            titleEn: "Copy all displayed barcodes",
            feedbackSuccessTextFr: "{count} code(s) à barres copié(s) !",
            feedbackSuccessTextEn: "{count} barcode(s) copied!",
            feedbackEmptyTextFr: "Aucun code-barres trouvé",
            feedbackEmptyTextEn: "No barcode found"
        },
        {
            id: "legacy-115-batchmod-barcodes",
            legacyButtonId: "btn-copy-all-barcodes",
            enabled: true,
            label: "Modification par lot — copier les codes-barres",
            pagePath: "/cgi-bin/koha/tools/batchMod.pl",
            tableSelector: "#itemst",
            tableName: "Exemplaires de la modification par lot",
            sourceMode: "column",
            columnHeaderSelector: "",
            columnHeaderLabels: "Code barre;Code à barres;Code-barres;Barcode",
            sourceSelector: "",
            valueSource: "text",
            attributeName: "",
            urlParam: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les codes-barres",
            buttonTextEn: "Copy barcodes",
            titleFr: "Copier tous les codes-barres affichés",
            titleEn: "Copy all displayed barcodes",
            feedbackSuccessTextFr: "{count} code(s) à barres copié(s) !",
            feedbackSuccessTextEn: "{count} barcode(s) copied!",
            feedbackEmptyTextFr: "Aucun code-barres trouvé",
            feedbackEmptyTextEn: "No barcode found"
        },
        {
            id: "legacy-115-itemsearch-biblionumbers",
            legacyButtonId: "btn-copy-all-barcodes",
            enabled: true,
            label: "Recherche exemplaires — copier les biblionumbers",
            pagePath: "/cgi-bin/koha/catalogue/itemsearch.pl",
            tableSelector: "#item_search",
            tableName: "Résultats de recherche exemplaires",
            sourceMode: "selector",
            sourceSelector: '#item_search tbody a[href*="biblionumber="]',
            sourceName: "Lien vers la notice",
            valueSource: "attribute",
            attributeName: "href",
            urlParam: "biblionumber",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les biblionumbers",
            buttonTextEn: "Copy biblionumbers",
            titleFr: "Copier tous les biblionumbers affichés",
            titleEn: "Copy all displayed biblionumbers",
            feedbackSuccessTextFr: "{count} biblionumber(s) copié(s) !",
            feedbackSuccessTextEn: "{count} biblionumber(s) copied!",
            feedbackEmptyTextFr: "Aucun biblionumber trouvé",
            feedbackEmptyTextEn: "No biblionumber found"
        },
        {
            id: "legacy-115-itemsearch-barcodes",
            legacyButtonId: "btn-copy-itemsearch-barcodes",
            enabled: true,
            label: "Recherche exemplaires — copier les codes-barres",
            pagePath: "/cgi-bin/koha/catalogue/itemsearch.pl",
            tableSelector: "#item_search",
            tableName: "Résultats de recherche exemplaires",
            sourceMode: "column",
            columnHeaderSelector: "",
            columnHeaderLabels: "Code à barres;Code barre;Code-barres;Barcode",
            sourceSelector: "",
            valueSource: "text",
            attributeName: "",
            urlParam: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonContainerSelector: "",
            buttonPosition: "append",
            iconClass: "fa fa-lg fa-copy",
            buttonTextFr: "Copier les codes-barres",
            buttonTextEn: "Copy barcodes",
            titleFr: "Copier tous les codes-barres affichés",
            titleEn: "Copy all displayed barcodes",
            feedbackSuccessTextFr: "{count} code(s) à barres copié(s) !",
            feedbackSuccessTextEn: "{count} barcode(s) copied!",
            feedbackEmptyTextFr: "Aucun code-barres trouvé",
            feedbackEmptyTextEn: "No barcode found"
        }
    ];

    /*
     * Règle historique du 133 absorbée dans le moteur commun :
     * copie individuelle du code-barres dans le tableau des exemplaires de detail.pl.
     */
    const LEGACY_133_RULES = [
        {
            id: "legacy-133-detail-item-barcode",
            enabled: true,
            label: "Détail notice — copier le code-barres exemplaire",
            pagePath: "/cgi-bin/koha/catalogue/detail.pl",
            actionMode: "generated",
            selector: '#holdings_table td[data-label="barcode"] a',
            targetName: "Code-barres exemplaire",
            matchMode: "all",
            valueSource: "text",
            attributeName: "",
            excludeSelector: ".pmk-copy-actions",
            trim: true,
            extractRegex: "",
            regexFlags: "",
            regexGroup: 0,
            transform: "full",
            length: 4,
            placement: "after",
            visualType: "fa",
            iconClass: "fa-regular fa-copy",
            iconColor: "#6c757d",
            iconHoverColor: "#408540",
            actionSizePx: 14,
            imageUrl: "",
            showText: false,
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier le code-barres",
            titleEn: "Copy barcode",
            feedbackEnabled: true,
            feedbackSuccessTextFr: "✓ Copié",
            feedbackSuccessTextEn: "✓ Copied",
            feedbackSuccessColor: "#408540"
        }
    ];

    const DEFAULT_RULES = BASE_DEFAULT_RULES.concat(LEGACY_056_RULES, LEGACY_133_RULES);

    const DEFAULT_CONFIG = {
        enabled: true,
        observeDom: true,
        observeDelay: 120,
        builtInRuleVersion: 0,
        rules: clone(DEFAULT_RULES),
        tableRules: clone(LEGACY_115_TABLE_RULES)
    };

    const RULE_BASE = {
        id: "",
        enabled: true,
        label: "",
        pagePath: "",
        actionMode: "generated",
        selector: "",
        targetName: "",
        triggerSelector: "",
        triggerName: "",
        triggerMatchCount: null,
        matchMode: "all",
        valueSource: "text",
        attributeName: "",
        excludeSelector: "",
        trim: true,
        extractRegex: "",
        regexFlags: "",
        regexGroup: 0,
        transform: "full",
        length: 4,
        placement: "after",
        visualType: "fa",
        iconClass: "fa fa-copy",
        iconColor: "#6c757d",
        iconHoverColor: "#212529",
        actionSizePx: 16,
        imageUrl: "",
        showText: false,
        textSizePx: 13,
        textColor: "#495057",
        textHoverColor: "#212529",
        buttonTextFr: "Copier",
        buttonTextEn: "Copy",
        titleFr: "Copier",
        titleEn: "Copy",
        exampleValue: "",
        matchCount: null,

        // Feedback visuel générique — repris du rendu historique du 107.
        // Disponible pour toutes les actions actuelles et futures.
        feedbackEnabled: true,
        feedbackPlacement: "auto",
        feedbackDurationMs: 1700,
        feedbackSuccessTextFr: "✓ Copié",
        feedbackSuccessTextEn: "✓ Copied",
        feedbackErrorTextFr: "Échec de copie",
        feedbackErrorTextEn: "Copy failed",
        feedbackSuccessColor: "#2e7d32",
        feedbackErrorColor: "#dc3545",
        feedbackFontSize: "0.75em",
        feedbackFontWeight: "600",
        feedbackMargin: "0 0 0 5px",
        feedbackFade: true
    };

    const TABLE_RULE_BASE = {
        id: "",
        enabled: true,
        label: "",
        pagePath: "",
        tableSelector: "",
        tableName: "",
        tableMatchCount: null,
        sourceMode: "column",
        sourceSelector: "",
        sourceName: "",
        sourceMatchCount: null,
        columnHeaderSelector: "",
        columnHeaderLabels: "",
        columnIndexHint: null,
        valueSource: "text",
        attributeName: "",
        urlParam: "",
        excludeSelector: "",
        trim: true,
        extractRegex: "",
        regexFlags: "",
        regexGroup: 0,
        transform: "full",
        length: 4,
        scope: "visible",
        selectedRowSelector: "tr.selected",
        selectionCheckboxSelector: 'input[type="checkbox"]:checked',
        deduplicate: true,
        separator: "newline",
        customSeparator: "",
        resultOrder: "display",
        buttonStyle: "datatable",
        legacyButtonId: "",
        buttonExtraClass: "",
        buttonContainerSelector: "",
        buttonContainerName: "",
        buttonPosition: "append",
        iconClass: "fa fa-lg fa-copy",
        iconColor: "",
        showText: true,
        textColor: "",
        fontSizePx: 13,
        buttonTextFr: "Copier",
        buttonTextEn: "Copy",
        titleFr: "Copier les valeurs affichées",
        titleEn: "Copy displayed values",
        feedbackEnabled: true,
        feedbackDurationMs: 2000,
        feedbackSuccessTextFr: "{count} valeur(s) copiée(s) !",
        feedbackSuccessTextEn: "{count} value(s) copied!",
        feedbackEmptyTextFr: "Aucune valeur trouvée",
        feedbackEmptyTextEn: "No value found",
        feedbackErrorTextFr: "Erreur lors de la copie",
        feedbackErrorTextEn: "Copy failed",
        exampleValue: ""
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let observers = [];
    let observerTimer = 0;
    let registered = false;
    let existingBindings = [];
    let tableLifecycleBindings = [];

    /*
     * Compatibilité avec les règles créées avant le picker commun 1.1 :
     * lorsqu'un agent avait cliqué sur le code-barres d'un exemplaire dans
     * detail.pl, l'ancien picker mémorisait l'URL exacte avec biblionumber et
     * itemnumber. La règle ne fonctionnait donc plus sur la notice suivante.
     *
     * Cette migration reste volontairement ciblée sur ce cas connu afin de ne
     * pas modifier des sélecteurs avancés saisis intentionnellement ailleurs.
     */
    function migrateLegacyDetailBarcodeSelector(selector, pagePath) {
        const raw = String(selector || "").trim();
        if (!raw || normalizePath(pagePath) !== "/cgi-bin/koha/catalogue/detail.pl") return raw;
        const decoded = raw.replace(/&amp;/g, "&");
        const match = decoded.match(/^a\[href=(['"])(\/cgi-bin\/koha\/catalogue\/moredetail\.pl\?[^'"]*itemnumber=[^'"]*)\1\]$/i);
        if (!match) return raw;
        return '#holdings_table tbody a[href*="/cgi-bin/koha/catalogue/moredetail.pl"][href*="itemnumber="]';
    }

    function mergeRule(raw, index) {
        const rule = Object.assign({}, RULE_BASE, raw || {});
        rule.id = String(rule.id || ("copy-rule-" + (index + 1)));
        rule.pagePath = String(rule.pagePath || window.location.pathname || "/");
        rule.actionMode = rule.actionMode === "existing-trigger" ? "existing-trigger" : "generated";
        rule.selector = migrateLegacyDetailBarcodeSelector(String(rule.selector || ""), rule.pagePath);
        rule.triggerSelector = String(rule.triggerSelector || "");
        rule.matchMode = ["all", "first"].includes(rule.matchMode) ? rule.matchMode : "all";
        rule.valueSource = ["text", "value", "attribute"].includes(rule.valueSource) ? rule.valueSource : "text";
        rule.transform = ["full", "prefix", "suffix"].includes(rule.transform) ? rule.transform : "full";
        rule.placement = ["before", "after", "inside-start", "inside-end"].includes(rule.placement) ? rule.placement : "after";
        rule.visualType = ["none", "fa", "image"].includes(rule.visualType) ? rule.visualType : "fa";
        rule.actionSizePx = Math.max(8, Math.min(64, Number(rule.actionSizePx) || 16));
        rule.textSizePx = Math.max(8, Math.min(40, Number(rule.textSizePx) || 13));
        rule.length = Math.max(1, Math.min(500, Number(rule.length) || 4));
        rule.regexGroup = Math.max(0, Number(rule.regexGroup) || 0);
        rule.feedbackPlacement = ["auto", "after-trigger", "parent-end", "floating"].includes(rule.feedbackPlacement)
            ? rule.feedbackPlacement : "auto";
        rule.feedbackDurationMs = Math.max(300, Math.min(10000, Number(rule.feedbackDurationMs) || 1700));
        rule.feedbackFontSize = cleanText(rule.feedbackFontSize) || "0.75em";
        rule.feedbackFontWeight = cleanText(rule.feedbackFontWeight) || "600";
        rule.feedbackMargin = cleanText(rule.feedbackMargin) || "0 0 0 5px";
        rule.feedbackFade = rule.feedbackFade !== false;
        return rule;
    }

    function mergeTableRule(raw, index) {
        const rule = Object.assign({}, TABLE_RULE_BASE, raw || {});
        rule.id = String(rule.id || ("copy-table-rule-" + (index + 1)));
        rule.pagePath = String(rule.pagePath || window.location.pathname || "/");
        rule.tableSelector = String(rule.tableSelector || "");
        rule.legacyButtonId = String(rule.legacyButtonId || "");
        rule.sourceMode = ["column", "selector"].includes(rule.sourceMode) ? rule.sourceMode : "column";
        rule.sourceSelector = String(rule.sourceSelector || "");
        rule.columnHeaderSelector = String(rule.columnHeaderSelector || "");
        rule.columnHeaderLabels = String(rule.columnHeaderLabels || "");
        rule.valueSource = ["text", "value", "attribute"].includes(rule.valueSource) ? rule.valueSource : "text";
        rule.scope = ["visible", "filtered", "selected", "loaded"].includes(rule.scope) ? rule.scope : "visible";
        rule.separator = ["newline", "comma", "semicolon", "tab", "space", "custom"].includes(rule.separator) ? rule.separator : "newline";
        rule.resultOrder = ["display", "alpha-asc", "alpha-desc", "numeric-asc", "numeric-desc"].includes(rule.resultOrder)
            ? rule.resultOrder : "display";
        rule.buttonStyle = ["datatable", "koha"].includes(rule.buttonStyle) ? rule.buttonStyle : "datatable";
        rule.buttonPosition = rule.buttonPosition === "prepend" ? "prepend" : "append";
        rule.fontSizePx = Math.max(8, Math.min(40, Number(rule.fontSizePx) || 13));
        rule.transform = ["full", "prefix", "suffix"].includes(rule.transform) ? rule.transform : "full";
        rule.length = Math.max(1, Math.min(500, Number(rule.length) || 4));
        rule.regexGroup = Math.max(0, Number(rule.regexGroup) || 0);
        rule.feedbackDurationMs = Math.max(300, Math.min(10000, Number(rule.feedbackDurationMs) || 2000));
        rule.deduplicate = rule.deduplicate !== false;
        if (rule.columnIndexHint !== null && rule.columnIndexHint !== undefined && rule.columnIndexHint !== "") {
            const parsed = Number(rule.columnIndexHint);
            rule.columnIndexHint = Number.isInteger(parsed) && parsed >= 0 ? parsed : null;
        } else {
            rule.columnIndexHint = null;
        }
        return rule;
    }

    function ensureUniqueTableRuleIds(rules) {
        const used = new Set();
        return (Array.isArray(rules) ? rules : []).map(function (rawRule, index) {
            const rule = mergeTableRule(rawRule, index);
            let candidate = cleanText(rule.id);
            if (!candidate || used.has(candidate)) {
                const base = candidate || "copy-table-rule";
                do {
                    candidate = base + "-" + makeId().replace(/^copy-/, "");
                } while (used.has(candidate));
                rule.id = candidate;
            }
            used.add(rule.id);
            return rule;
        });
    }

    function legacySelector(pageId, source) {
        if (pageId === "members.moremember" && source === "username") {
            return { selector: "#patron-username", targetName: "Identifiant utilisateur", excludeSelector: ".label, .pmk-context-config, .pmk-copy-actions", regex: "", group: 0 };
        }
        if (pageId === "members.moremember" && source === "cardnumber") {
            return { selector: "#patron-cardnumber", targetName: "Numéro de carte", excludeSelector: ".label, .pmk-context-config, .pmk-copy-actions", regex: "", group: 0 };
        }
        if (pageId === "circ.circulation" && source === "cardnumber") {
            return { selector: CIRC_CARD_SELECTOR, targetName: "Numéro de carte", excludeSelector: ".pmk-context-config, .pmk-copy-actions", regex: "^\\(?([^()]*)\\)?$", group: 1 };
        }
        return null;
    }

    function migrateLegacyPages(raw) {
        const rules = [];
        (raw.pages || []).forEach(function (page) {
            if (!page || page.enabled === false) return;
            (page.actions || []).forEach(function (action, actionIndex) {
                if (!action) return;
                const legacy = legacySelector(page.id, action.source);
                if (!legacy) return;
                rules.push(mergeRule({
                    id: String(action.id || (page.id + "-" + actionIndex)),
                    enabled: action.enabled !== false,
                    label: String(action.labelFr || action.labelEn || legacy.targetName),
                    pagePath: page.path || (page.id === "circ.circulation" ? "/cgi-bin/koha/circ/circulation.pl" : "/cgi-bin/koha/members/moremember.pl"),
                    selector: legacy.selector,
                    targetName: legacy.targetName,
                    matchMode: "first",
                    valueSource: "text",
                    excludeSelector: legacy.excludeSelector,
                    extractRegex: legacy.regex,
                    regexGroup: legacy.group,
                    transform: action.transform || "full",
                    length: action.length || 4,
                    placement: "after",
                    visualType: "fa",
                    iconClass: "fa fa-copy",
                    showText: false,
                    titleFr: String(action.labelFr || ""),
                    titleEn: String(action.labelEn || "")
                }, rules.length));
            });
        });
        return rules;
    }

    function ensureUniqueRuleIds(rules) {
        const used = new Set();
        return (Array.isArray(rules) ? rules : []).map(function (rawRule, index) {
            const rule = mergeRule(rawRule, index);
            let candidate = cleanText(rule.id);
            if (!candidate || used.has(candidate)) {
                const base = candidate || "copy-rule";
                do {
                    candidate = base + "-" + makeId().replace(/^copy-/, "");
                } while (used.has(candidate));
                rule.id = candidate;
            }
            used.add(rule.id);
            return rule;
        });
    }

    function normalizeConfig(raw) {
        const source = raw && typeof raw === "object" ? raw : {};
        let rules;
        const suppliedRules = Array.isArray(source.rules) ? source.rules : null;
        const defaultRulesInjected = suppliedRules && JSON.stringify(suppliedRules) === JSON.stringify(DEFAULT_RULES);
        if (Array.isArray(source.pages) && (!suppliedRules || defaultRulesInjected)) rules = migrateLegacyPages(source);
        else if (suppliedRules) rules = suppliedRules.map(mergeRule);
        else rules = clone(DEFAULT_RULES).map(mergeRule);

        let tableRules = Array.isArray(source.tableRules)
            ? source.tableRules.map(mergeTableRule)
            : [];

        /*
         * Migration des règles intégrées :
         * v1 = reprise du 056 (ISBN / EAN / titre) ;
         * v2 = reprise du 115 (copies groupées dans les tableaux) ;
         * v3 = reprise du 133 (copie du code-barres exemplaire sur detail.pl).
         *
         * Chaque palier ne s'exécute qu'une fois. Ainsi, une règle historique
         * supprimée volontairement après sa migration ne réapparaît pas lors
         * d'une version ultérieure.
         */
        const sourceBuiltInVersion = Math.max(0, Number(source.builtInRuleVersion) || 0);

        if (sourceBuiltInVersion < 1) {
            const existingIds = new Set(rules.map(function (rule) { return cleanText(rule && rule.id); }));
            LEGACY_056_RULES.forEach(function (rule) {
                if (!existingIds.has(rule.id)) {
                    rules.push(mergeRule(clone(rule), rules.length));
                    existingIds.add(rule.id);
                }
            });
        }

        if (sourceBuiltInVersion < 2) {
            const existingTableIds = new Set(tableRules.map(function (rule) { return cleanText(rule && rule.id); }));
            LEGACY_115_TABLE_RULES.forEach(function (rule) {
                if (!existingTableIds.has(rule.id)) {
                    tableRules.push(mergeTableRule(clone(rule), tableRules.length));
                    existingTableIds.add(rule.id);
                }
            });
        }

        if (sourceBuiltInVersion < 3) {
            const existingIds = new Set(rules.map(function (rule) { return cleanText(rule && rule.id); }));
            LEGACY_133_RULES.forEach(function (rule) {
                if (!existingIds.has(rule.id)) {
                    rules.push(mergeRule(clone(rule), rules.length));
                    existingIds.add(rule.id);
                }
            });
        }

        rules = ensureUniqueRuleIds(rules);
        tableRules = ensureUniqueTableRuleIds(tableRules);

        return {
            enabled: source.enabled !== false,
            observeDom: source.observeDom !== false,
            observeDelay: Math.max(25, Math.min(2000, Number(source.observeDelay) || 120)),
            builtInRuleVersion: BUILTIN_RULE_VERSION,
            rules: rules,
            tableRules: tableRules
        };
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .${CLUSTER_CLASS}{display:inline-flex;align-items:center;gap:.18rem;vertical-align:middle;margin:0 .16rem;white-space:nowrap}
            .${BUTTON_CLASS}{appearance:none!important;-webkit-appearance:none!important;display:inline-flex!important;align-items:center;justify-content:center;gap:.22rem;margin:0!important;padding:.05rem .10rem!important;min-width:var(--pmk-copy-action-size,16px);min-height:var(--pmk-copy-action-size,16px);border:0!important;background:transparent!important;box-shadow:none!important;text-decoration:none!important;color:var(--pmk-copy-icon-color,currentColor)!important;opacity:.72;line-height:1;cursor:pointer;vertical-align:middle}
            .${BUTTON_CLASS}:hover{background:transparent!important;box-shadow:none!important;color:var(--pmk-copy-icon-hover-color,var(--pmk-copy-icon-color,currentColor))!important;opacity:1}
            .${BUTTON_CLASS}:focus{background:transparent!important;box-shadow:none!important}
            .${BUTTON_CLASS}:focus-visible{outline:2px solid currentColor;outline-offset:2px;border-radius:.16rem;opacity:1}
            .${BUTTON_CLASS} i{display:inline-block;font-size:var(--pmk-copy-action-size,16px);transition:transform .14s ease,color .14s ease,opacity .14s ease}
            .${BUTTON_CLASS} img{display:block;width:var(--pmk-copy-action-size,16px);height:var(--pmk-copy-action-size,16px);max-width:none;max-height:none;object-fit:contain;transition:transform .14s ease,opacity .14s ease}
            .${BUTTON_CLASS}:hover i,.${BUTTON_CLASS}:hover img{transform:scale(1.12)}
            .${BUTTON_CLASS}:hover img{opacity:.88}
            .${BUTTON_CLASS} .pmk-copy-button-text{font-size:var(--pmk-copy-text-size,13px);font-weight:500;line-height:1.1;color:var(--pmk-copy-text-color,currentColor);transition:color .14s ease}
            .${BUTTON_CLASS}:hover .pmk-copy-button-text{color:var(--pmk-copy-text-hover-color,var(--pmk-copy-text-color,currentColor))}
            .${FEEDBACK_CLASS}{display:inline-block;font-size:.78em;font-weight:600;line-height:1.2;white-space:nowrap}
            .${FEEDBACK_CLASS}.is-ok{color:var(--bs-success,#198754)}
            .${FEEDBACK_CLASS}.is-error{color:var(--bs-danger,#dc3545)}
            .${FEEDBACK_CLASS}.is-standalone{position:fixed;top:1rem;right:1rem;z-index:1095;padding:.38rem .58rem;border:1px solid currentColor;border-radius:.38rem;background:var(--bs-body-bg,#fff);box-shadow:0 2px 9px rgba(0,0,0,.14)}
            .${TABLE_BUTTON_CLASS}{display:inline-flex!important;align-items:center!important;gap:.3rem!important}
            .${TABLE_BUTTON_CLASS} i{pointer-events:none}
            .pmk-copy-table-fallback-toolbar{display:flex;flex-wrap:wrap;gap:.35rem;margin:.35rem 0 .55rem}
            .pmk-copy-table-fallback-toolbar .${TABLE_BUTTON_CLASS}{margin:0}
            @keyframes pmkCopyFadeOut{0%{opacity:1}70%{opacity:1}100%{opacity:0}}
        `;
        document.head.appendChild(style);
    }

    function safeQueryAll(selector) {
        if (!selector) return [];
        try { return Array.from(document.querySelectorAll(selector)); } catch (_) { return []; }
    }

    function extractValue(raw, rule) {
        let value = raw == null ? "" : String(raw);
        if (rule.trim !== false) value = value.trim();
        const pattern = String(rule.extractRegex || "").trim();
        if (pattern) {
            try {
                const flags = String(rule.regexFlags || "").replace(/[^dgimsuvy]/g, "");
                const match = value.match(new RegExp(pattern, flags));
                if (!match) return "";
                value = match[Math.max(0, Number(rule.regexGroup) || 0)] == null ? "" : String(match[Math.max(0, Number(rule.regexGroup) || 0)]);
            } catch (_) { return ""; }
        }
        return rule.trim !== false ? value.trim() : value;
    }

    function elementRawValue(element, rule) {
        if (!element) return "";
        if (rule.valueSource === "attribute") {
            const name = String(rule.attributeName || "").trim();
            return name ? element.getAttribute(name) : "";
        }
        if (rule.valueSource === "value") return element.value == null ? "" : element.value;
        const cloneNode = element.cloneNode(true);
        cloneNode.querySelectorAll("." + CLUSTER_CLASS + ", .pmk-context-config").forEach(function (node) { node.remove(); });
        const extra = String(rule.excludeSelector || "").trim();
        if (extra) {
            try { cloneNode.querySelectorAll(extra).forEach(function (node) { node.remove(); }); } catch (_) {}
        }
        return cloneNode.textContent || "";
    }

    function readValue(element, rule) {
        return extractValue(elementRawValue(element, rule), rule);
    }

    function transformValue(value, rule) {
        const text = cleanText(value);
        if (!text) return "";
        const length = Math.max(1, Number(rule.length) || 4);
        if (rule.transform === "prefix") return text.slice(0, length);
        if (rule.transform === "suffix") return text.slice(-length);
        return text;
    }

    function accessibleLabel(rule) {
        const configured = detectLanguage() === "en" ? rule.titleEn : rule.titleFr;
        if (cleanText(configured)) return cleanText(configured).replace(/\{n\}/g, String(rule.length || 4));
        if (rule.transform === "prefix") return i18n("Copier les {n} premiers caractères", "Copy first {n} characters").replace("{n}", String(rule.length || 4));
        if (rule.transform === "suffix") return i18n("Copier les {n} derniers caractères", "Copy last {n} characters").replace("{n}", String(rule.length || 4));
        return i18n("Copier", "Copy");
    }

    function visibleText(rule) {
        const value = detectLanguage() === "en" ? rule.buttonTextEn : rule.buttonTextFr;
        return cleanText(value) || i18n("Copier", "Copy");
    }

    async function copyToClipboard(text) {
        const previousFocus = document.activeElement;
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (_) {}
        let ta = null;
        try {
            ta = document.createElement("textarea");
            ta.value = text;
            ta.setAttribute("readonly", "readonly");
            ta.style.position = "fixed";
            ta.style.left = "-9999px";
            document.body.appendChild(ta);
            ta.select();
            return Boolean(document.execCommand("copy"));
        } catch (_) {
            return false;
        } finally {
            if (ta) ta.remove();
            if (previousFocus && previousFocus.isConnected && document.activeElement === document.body) {
                try { previousFocus.focus({ preventScroll: true }); } catch (_) {}
            }
        }
    }

    function feedbackText(rule, ok) {
        const lang = detectLanguage();
        if (ok) {
            return cleanText(lang === "en" ? rule.feedbackSuccessTextEn : rule.feedbackSuccessTextFr) ||
                (lang === "en" ? "✓ Copied" : "✓ Copié");
        }
        return cleanText(lang === "en" ? rule.feedbackErrorTextEn : rule.feedbackErrorTextFr) ||
            (lang === "en" ? "Copy failed" : "Échec de copie");
    }

    function copyToast(message, ok, rule, value) {
        if (!rule || rule.feedbackEnabled === false) return;
        document.querySelectorAll('.' + FEEDBACK_CLASS).forEach(node => node.remove());
        const toast = document.createElement('div');
        toast.className = FEEDBACK_CLASS + ' pmk-copy-toast ' + (ok ? 'is-ok' : 'is-error');
        toast.setAttribute('role', ok ? 'status' : 'alert');
        toast.setAttribute('aria-live', ok ? 'polite' : 'assertive');
        Object.assign(toast.style, {position:'fixed', top:'auto', bottom:'1rem', right:'1rem', left:'auto',
            zIndex:'11000', padding:'.85rem 1rem', margin:'0', borderRadius:'.5rem', boxShadow:'0 4px 18px #0003',
            background:'var(--bs-body-bg, #fff)', border:'1px solid currentColor', width:'max-content',
            maxWidth:'min(32rem, calc(100vw - 2rem))', fontSize:cleanText(rule.feedbackFontSize) || '0.95rem',
            color:cleanText(ok ? rule.feedbackSuccessColor : rule.feedbackErrorColor) || (ok ? '#2e7d32' : '#dc3545')});
        const title = document.createElement('strong');
        title.textContent = message;
        title.style.fontWeight=cleanText(rule.feedbackFontWeight) || '600';
        toast.appendChild(title);
        if (ok && value !== undefined && value !== '') {
            const detail = document.createElement('div');
            detail.textContent = String(value);
            Object.assign(detail.style, {whiteSpace:'pre-wrap', overflowWrap:'anywhere', maxHeight:'12rem', overflow:'auto', marginTop:'.3rem', color:'var(--bs-body-color, #222)'});
            toast.appendChild(detail);
        }
        document.body.appendChild(toast);
        window.setTimeout(() => toast.remove(), Math.max(300, Math.min(15000, Number(rule.feedbackDurationMs) || 2500)));
    }

    function showFeedback(anchor, ok, rule, value) {
        copyToast(feedbackText(rule, ok), ok, rule, value);
    }

    function appendVisual(button, rule) {
        if (rule.visualType === "image" && cleanText(rule.imageUrl)) {
            const img = document.createElement("img");
            img.src = String(rule.imageUrl).trim();
            img.alt = "";
            img.setAttribute("aria-hidden", "true");
            button.appendChild(img);
        } else if (rule.visualType === "fa" && cleanText(rule.iconClass)) {
            const icon = document.createElement("i");
            icon.className = cleanText(rule.iconClass);
            icon.setAttribute("aria-hidden", "true");
            button.appendChild(icon);
        }
        if (rule.showText === true) {
            const textNode = document.createElement("span");
            textNode.className = "pmk-copy-button-text";
            textNode.textContent = visibleText(rule);
            button.appendChild(textNode);
        }
    }

    function makeButton(element, rule) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = BUTTON_CLASS;
        button.title = accessibleLabel(rule);
        button.style.setProperty("--pmk-copy-icon-color", cleanText(rule.iconColor) || "#6c757d");
        button.style.setProperty("--pmk-copy-icon-hover-color", cleanText(rule.iconHoverColor) || cleanText(rule.iconColor) || "#212529");
        button.style.setProperty("--pmk-copy-action-size", String(rule.actionSizePx || 16) + "px");
        button.style.setProperty("--pmk-copy-text-size", String(rule.textSizePx || 13) + "px");
        button.style.setProperty("--pmk-copy-text-color", cleanText(rule.textColor) || "#495057");
        button.style.setProperty("--pmk-copy-text-hover-color", cleanText(rule.textHoverColor) || cleanText(rule.textColor) || "#212529");
        button.setAttribute("aria-label", accessibleLabel(rule));
        appendVisual(button, rule);
        if (!button.childNodes.length) button.textContent = "⧉";
        button.addEventListener("click", async function (event) {
            event.preventDefault();
            event.stopPropagation();
            const value = transformValue(readValue(element, rule), rule);
            if (!value) { showFeedback(button, false, rule); return; }
            showFeedback(button, await copyToClipboard(value), rule, value);
        });
        return button;
    }

    function rememberAttribute(element, name) {
        return {
            present: Boolean(element && element.hasAttribute && element.hasAttribute(name)),
            value: element && element.getAttribute ? element.getAttribute(name) : null
        };
    }

    function restoreAttribute(element, name, snapshot) {
        if (!element || !snapshot) return;
        if (snapshot.present) element.setAttribute(name, snapshot.value == null ? "" : snapshot.value);
        else element.removeAttribute(name);
    }

    function clearExistingBindings() {
        existingBindings.forEach(function (binding) {
            const trigger = binding && binding.trigger;
            if (!trigger) return;
            try { trigger.removeEventListener("click", binding.clickHandler); } catch (_) {}
            try { trigger.removeEventListener("keydown", binding.keyHandler); } catch (_) {}
            try { trigger.style.cursor = binding.cursor || ""; } catch (_) {}
            restoreAttribute(trigger, "role", binding.role);
            restoreAttribute(trigger, "tabindex", binding.tabindex);
            restoreAttribute(trigger, "aria-label", binding.ariaLabel);
            restoreAttribute(trigger, "title", binding.title);
            try { trigger.removeAttribute("data-pmk-copy-existing-trigger"); } catch (_) {}
        });
        existingBindings = [];
    }

    function clearTableLifecycleBindings() {
        tableLifecycleBindings.forEach(function (binding) {
            if (!binding) return;
            if (binding.observer) {
                try { binding.observer.disconnect(); } catch (_) {}
            }
            if (binding.$table && binding.eventNamespace) {
                try { binding.$table.off(binding.eventNamespace); } catch (_) {}
            }
        });
        tableLifecycleBindings = [];
    }

    function clearInjected() {
        clearExistingBindings();
        clearTableLifecycleBindings();
        document.querySelectorAll("." + CLUSTER_CLASS + '[data-pmk-copy-module="' + MODULE_ID + '"]').forEach(function (node) { node.remove(); });
        document.querySelectorAll("." + TABLE_BUTTON_CLASS + '[data-pmk-copy-module="' + MODULE_ID + '"]').forEach(function (node) { node.remove(); });
        document.querySelectorAll("." + FEEDBACK_CLASS + ".is-standalone").forEach(function (node) { node.remove(); });
    }

    function ruleApplies(rule) {
        return rule && rule.enabled !== false && normalizePath(rule.pagePath) === normalizePath(window.location.pathname);
    }

    function tableRuleApplies(rule) {
        return rule && rule.enabled !== false && normalizePath(rule.pagePath) === normalizePath(window.location.pathname);
    }

    function safeQueryWithin(root, selector) {
        if (!root || !selector || !root.querySelectorAll) return [];
        try { return Array.from(root.querySelectorAll(selector)); } catch (_) { return []; }
    }

    function resolveSourceForTrigger(trigger, rule, allSources, index) {
        if (!trigger || !rule) return null;
        if (allSources.length === 1) return allSources[0];

        /*
         * Le 056 historique liait souvent une icône à une valeur voisine.
         * On préfère une recherche locale dans la notice / ligne / carte avant
         * de retomber sur l'index global. Cela corrige notamment l'EAN des
         * résultats où .ean-result n'est plus le nextElementSibling du bouton.
         */
        const localScopes = [".firstresult", "li", "tr", ".result-item", ".kx-notice-card", ".page-section"];
        for (const scopeSelector of localScopes) {
            const scope = trigger.closest && trigger.closest(scopeSelector);
            if (!scope) continue;
            const localSources = safeQueryWithin(scope, rule.selector);
            if (localSources.length === 1) return localSources[0];
        }
        return allSources[index] || null;
    }

    function bindExistingTriggerRule(rule) {
        let triggers = safeQueryAll(rule.triggerSelector);
        /*
         * Si une même classe est posée sur un conteneur et son image enfant
         * (cas rencontré dans des personnalisations historiques), on ne garde
         * que le déclencheur extérieur afin d'éviter une double copie au clic.
         */
        triggers = triggers.filter(function (candidate) {
            return !triggers.some(function (other) {
                return other !== candidate && other.contains && other.contains(candidate);
            });
        });
        const sources = safeQueryAll(rule.selector);
        if (rule.matchMode === "first") triggers = triggers.slice(0, 1);
        if (!triggers.length || !sources.length) return;

        triggers.forEach(function (trigger, index) {
            if (!trigger || trigger.closest("#pmk-config-overlay")) return;
            const source = resolveSourceForTrigger(trigger, rule, sources, index);
            if (!source) return;

            const original = {
                trigger: trigger,
                cursor: trigger.style.cursor || "",
                role: rememberAttribute(trigger, "role"),
                tabindex: rememberAttribute(trigger, "tabindex"),
                ariaLabel: rememberAttribute(trigger, "aria-label"),
                title: rememberAttribute(trigger, "title")
            };

            const execute = async function (event) {
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                const value = transformValue(readValue(source, rule), rule);
                if (!value) {
                    showFeedback(trigger, false, rule);
                    return;
                }
                showFeedback(trigger, await copyToClipboard(value), rule, value);
            };

            const clickHandler = function (event) { execute(event); };
            const keyHandler = function (event) {
                if (event.key !== "Enter" && event.key !== " ") return;
                execute(event);
            };

            trigger.addEventListener("click", clickHandler);
            trigger.addEventListener("keydown", keyHandler);
            trigger.style.cursor = "pointer";
            trigger.setAttribute("data-pmk-copy-existing-trigger", rule.id);
            if (!trigger.matches("button,a[href],input,select,textarea,[role='button']")) {
                trigger.setAttribute("role", "button");
            }
            if (!trigger.hasAttribute("tabindex") && !trigger.matches("button,a[href],input,select,textarea")) {
                trigger.setAttribute("tabindex", "0");
            }
            if (!trigger.hasAttribute("aria-label")) trigger.setAttribute("aria-label", accessibleLabel(rule));
            if (!trigger.hasAttribute("title")) trigger.setAttribute("title", accessibleLabel(rule));

            existingBindings.push(Object.assign(original, {
                clickHandler: clickHandler,
                keyHandler: keyHandler
            }));
        });
    }


    function normalizeHeaderLabel(value) {
        return cleanText(value)
            .toLocaleLowerCase("fr")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-z0-9]+/g, " ")
            .trim();
    }

    function splitConfiguredValues(value) {
        return String(value || "")
            .split(/[;\n|]+/)
            .map(function (part) { return cleanText(part); })
            .filter(Boolean);
    }

    function getDataTableApi(table) {
        const jq = window.jQuery;
        if (!table || !jq || !jq.fn || !jq.fn.dataTable) return null;
        try {
            if (typeof jq.fn.dataTable.isDataTable === "function" && !jq.fn.dataTable.isDataTable(table)) return null;
            return jq(table).DataTable();
        } catch (_) {
            return null;
        }
    }

    function apiNodes(apiRows) {
        if (!apiRows || typeof apiRows.nodes !== "function") return [];
        try {
            const nodes = apiRows.nodes();
            if (nodes && typeof nodes.toArray === "function") return nodes.toArray();
            return Array.from(nodes || []);
        } catch (_) {
            return [];
        }
    }

    function rowIsSelected(row, rule) {
        if (!row) return false;
        const rowSelector = cleanText(rule.selectedRowSelector);
        if (rowSelector) {
            try {
                if (row.matches(rowSelector) || row.querySelector(rowSelector)) return true;
            } catch (_) {}
        }
        const checkboxSelector = cleanText(rule.selectionCheckboxSelector);
        if (checkboxSelector) {
            try {
                if (row.querySelector(checkboxSelector)) return true;
            } catch (_) {}
        }
        return false;
    }

    function tableRowsForRule(table, rule) {
        const api = getDataTableApi(table);
        if (api) {
            try {
                if (rule.scope === "visible") {
                    const rows = apiNodes(api.rows({ page: "current", search: "applied", order: "applied" }));
                    if (rows.length) return rows;
                }
                if (rule.scope === "filtered") {
                    const rows = apiNodes(api.rows({ search: "applied", order: "applied" }));
                    if (rows.length) return rows;
                }
                if (rule.scope === "loaded") {
                    const rows = apiNodes(api.rows({ order: "applied" }));
                    if (rows.length) return rows;
                }
                if (rule.scope === "selected") {
                    const jq = window.jQuery;
                    if (jq && jq.fn && jq.fn.dataTable && jq.fn.dataTable.select) {
                        const selected = apiNodes(api.rows({ selected: true, search: "applied", order: "applied" }));
                        if (selected.length) return selected;
                    }
                    const filtered = apiNodes(api.rows({ search: "applied", order: "applied" }));
                    return filtered.filter(function (row) { return rowIsSelected(row, rule); });
                }
            } catch (_) {}
        }

        const rows = Array.from(table.querySelectorAll("tbody tr"))
            .filter(function (row) { return !row.querySelector("td.dataTables_empty"); });

        if (rule.scope === "selected") return rows.filter(function (row) { return rowIsSelected(row, rule); });
        if (rule.scope === "visible" || rule.scope === "filtered") {
            return rows.filter(function (row) {
                try {
                    const style = window.getComputedStyle(row);
                    return style.display !== "none" && style.visibility !== "hidden";
                } catch (_) {
                    return true;
                }
            });
        }
        return rows;
    }

    function columnIndexForRule(table, rule) {
        if (!table) return -1;

        const selector = cleanText(rule.columnHeaderSelector);
        if (selector) {
            try {
                const header = table.querySelector(selector);
                if (header && header.parentElement) {
                    const siblings = Array.from(header.parentElement.children).filter(function (node) {
                        return node.tagName === "TH" || node.tagName === "TD";
                    });
                    const index = siblings.indexOf(header);
                    if (index >= 0) return index;
                }
            } catch (_) {}
        }

        const wanted = splitConfiguredValues(rule.columnHeaderLabels).map(normalizeHeaderLabel);
        if (wanted.length) {
            const headers = Array.from(table.querySelectorAll("thead tr:last-child th, thead tr:last-child td"));
            for (let index = 0; index < headers.length; index += 1) {
                const label = normalizeHeaderLabel(headers[index].textContent || "");
                if (wanted.some(function (candidate) {
                    return label === candidate || label.includes(candidate) || candidate.includes(label);
                })) {
                    return index;
                }
            }
        }

        return Number.isInteger(rule.columnIndexHint) ? rule.columnIndexHint : -1;
    }

    function rawTableElementValue(element, rule) {
        if (!element) return "";
        let raw;
        if (rule.valueSource === "attribute") {
            const attribute = cleanText(rule.attributeName) || "href";
            raw = element.getAttribute(attribute) || "";
        } else if (rule.valueSource === "value") {
            raw = element.value == null ? "" : element.value;
        } else {
            const cloneNode = element.cloneNode(true);
            const extra = cleanText(rule.excludeSelector);
            if (extra) {
                try { cloneNode.querySelectorAll(extra).forEach(function (node) { node.remove(); }); } catch (_) {}
            }
            raw = cloneNode.textContent || "";
        }

        if (cleanText(rule.urlParam)) {
            try {
                const parsed = new URL(String(raw || ""), window.location.origin);
                raw = parsed.searchParams.get(cleanText(rule.urlParam)) || "";
            } catch (_) {
                const match = String(raw || "").match(new RegExp("[?&]" + cleanText(rule.urlParam).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^&#]+)"));
                raw = match ? decodeURIComponent(match[1]) : "";
            }
        }

        return transformValue(extractValue(raw, rule), rule);
    }

    function selectorNodesForRow(table, row, selector) {
        if (!selector || !table || !row) return [];
        let local = [];
        try { local = Array.from(row.querySelectorAll(selector)); } catch (_) {}
        if (local.length) return local;
        return safeQueryAll(selector).filter(function (node) {
            return table.contains(node) && node.closest && node.closest("tr") === row;
        });
    }

    function tableValuesForRule(table, rule) {
        const rows = tableRowsForRule(table, rule);
        const values = [];

        if (rule.sourceMode === "column") {
            const columnIndex = columnIndexForRule(table, rule);
            if (columnIndex < 0) return [];
            rows.forEach(function (row) {
                const cells = Array.from(row.children).filter(function (node) {
                    return node.tagName === "TD" || node.tagName === "TH";
                });
                const cell = cells[columnIndex];
                if (!cell || cell.classList.contains("dataTables_empty")) return;
                let sources = [cell];
                if (cleanText(rule.sourceSelector)) {
                    const nested = selectorNodesForRow(table, row, rule.sourceSelector).filter(function (node) {
                        return cell.contains(node);
                    });
                    if (nested.length) sources = nested;
                }
                sources.forEach(function (source) {
                    const value = rawTableElementValue(source, rule);
                    if (value) values.push(value);
                });
            });
        } else {
            rows.forEach(function (row) {
                selectorNodesForRow(table, row, rule.sourceSelector).forEach(function (source) {
                    const value = rawTableElementValue(source, rule);
                    if (value) values.push(value);
                });
            });
        }

        let output = values.filter(function (value) { return cleanText(value) !== ""; });
        if (rule.deduplicate !== false) output = Array.from(new Set(output));

        if (rule.resultOrder === "alpha-asc") output.sort(function (a, b) { return String(a).localeCompare(String(b), detectLanguage(), { numeric: true }); });
        else if (rule.resultOrder === "alpha-desc") output.sort(function (a, b) { return String(b).localeCompare(String(a), detectLanguage(), { numeric: true }); });
        else if (rule.resultOrder === "numeric-asc") output.sort(function (a, b) { return Number(a) - Number(b); });
        else if (rule.resultOrder === "numeric-desc") output.sort(function (a, b) { return Number(b) - Number(a); });

        return output;
    }

    function tableSeparator(rule) {
        if (rule.separator === "comma") return ",";
        if (rule.separator === "semicolon") return ";";
        if (rule.separator === "tab") return "\t";
        if (rule.separator === "space") return " ";
        if (rule.separator === "custom") return String(rule.customSeparator == null ? "" : rule.customSeparator);
        return "\n";
    }

    function tableButtonText(rule) {
        const value = detectLanguage() === "en" ? rule.buttonTextEn : rule.buttonTextFr;
        return cleanText(value) || i18n("Copier", "Copy");
    }

    function tableTitle(rule) {
        const value = detectLanguage() === "en" ? rule.titleEn : rule.titleFr;
        return cleanText(value) || i18n("Copier les valeurs affichées", "Copy displayed values");
    }

    function tableFeedbackMessage(rule, status, count) {
        const lang = detectLanguage();
        let value = "";
        if (status === "success") value = lang === "en" ? rule.feedbackSuccessTextEn : rule.feedbackSuccessTextFr;
        else if (status === "empty") value = lang === "en" ? rule.feedbackEmptyTextEn : rule.feedbackEmptyTextFr;
        else value = lang === "en" ? rule.feedbackErrorTextEn : rule.feedbackErrorTextFr;

        if (!cleanText(value)) {
            if (status === "success") value = lang === "en" ? "{count} value(s) copied!" : "{count} valeur(s) copiée(s) !";
            else if (status === "empty") value = lang === "en" ? "No value found" : "Aucune valeur trouvée";
            else value = lang === "en" ? "Copy failed" : "Erreur lors de la copie";
        }
        return String(value).replace(/\{count\}/g, String(count || 0));
    }

    function showTableFeedback(anchor, status, rule, count, value) {
        copyToast(tableFeedbackMessage(rule, status, count), status === 'success', rule, value);
    }

    function tableButtonContainer(table, rule) {
        const configured = cleanText(rule.buttonContainerSelector);
        if (configured) {
            try {
                const found = document.querySelector(configured);
                if (found) return found;
            } catch (_) {}
        }

        let wrapper = null;
        if (table.id) wrapper = document.getElementById(table.id + "_wrapper");
        if (!wrapper && table.closest) wrapper = table.closest(".dataTables_wrapper");
        if (wrapper) {
            const toolbar = wrapper.querySelector(".dt-buttons");
            if (toolbar) return toolbar;
        }

        let fallback = table.previousElementSibling;
        if (!fallback || !fallback.classList || !fallback.classList.contains("pmk-copy-table-fallback-toolbar")) {
            fallback = document.createElement("div");
            fallback.className = "pmk-copy-table-fallback-toolbar";
            table.insertAdjacentElement("beforebegin", fallback);
        }
        return fallback;
    }

    function tableButtonSelector(rule) {
        return "." + TABLE_BUTTON_CLASS + '[data-pmk-copy-table-rule="' +
            String(rule.id || "").replace(/"/g, '\\"') + '"]';
    }

    function makeTableButton(table, rule) {
        const button = document.createElement("button");
        button.type = "button";
        if (cleanText(rule.legacyButtonId)) button.id = cleanText(rule.legacyButtonId);
        button.className = (rule.buttonStyle === "koha" ? "btn btn-default btn-sm " : "dt-button copyConditions_controls ") +
            TABLE_BUTTON_CLASS + (cleanText(rule.buttonExtraClass) ? " " + cleanText(rule.buttonExtraClass) : "");
        button.dataset.pmkCopyModule = MODULE_ID;
        button.dataset.pmkCopyTableRule = rule.id;
        button.title = tableTitle(rule);
        button.setAttribute("aria-label", tableTitle(rule));
        if (cleanText(rule.textColor)) button.style.color = cleanText(rule.textColor);
        button.style.fontSize = String(rule.fontSizePx || 13) + "px";

        const iconClass = cleanText(rule.iconClass);
        if (iconClass) {
            const icon = document.createElement("i");
            icon.className = iconClass;
            icon.setAttribute("aria-hidden", "true");
            if (cleanText(rule.iconColor)) icon.style.color = cleanText(rule.iconColor);
            button.appendChild(icon);
        }
        if (rule.showText !== false) {
            const text = document.createElement("span");
            text.className = "dt-button-text";
            text.textContent = tableButtonText(rule);
            button.appendChild(text);
        }

        button.addEventListener("click", async function (event) {
            event.preventDefault();
            event.stopPropagation();
            const values = tableValuesForRule(table, rule);
            if (!values.length) {
                showTableFeedback(button, "empty", rule, 0);
                return;
            }
            const ok = await copyToClipboard(values.join(tableSeparator(rule)));
            showTableFeedback(button, ok ? "success" : "error", rule, values.length, values.join(tableSeparator(rule)));
        });
        return button;
    }

    function ensureTableButton(rule, table) {
        if (!table || !table.isConnected) return;
        const container = tableButtonContainer(table, rule);
        if (!container) return;

        const selector = tableButtonSelector(rule);
        let button = document.querySelector(selector);

        if (!button && cleanText(rule.legacyButtonId)) {
            const legacy = document.getElementById(cleanText(rule.legacyButtonId));
            if (legacy && !legacy.classList.contains(TABLE_BUTTON_CLASS)) {
                /*
                 * Compatibilité de bascule : si le 115 s'est exécuté avant le 006,
                 * on remplace son bouton par un clone PMK afin de retirer ses
                 * handlers historiques sans conserver deux actions concurrentes.
                 */
                try { legacy.remove(); } catch (_) {}
            }
        }

        if (!button) button = makeTableButton(table, rule);
        if (button.parentElement !== container) {
            if (rule.buttonPosition === "prepend") container.insertBefore(button, container.firstChild);
            else container.appendChild(button);
        } else if (rule.buttonPosition === "prepend" && container.firstChild !== button) {
            container.insertBefore(button, container.firstChild);
        }
    }

    function bindTableLifecycle(rule, table) {
        if (!table) return;
        const binding = { observer: null, $table: null, eventNamespace: "" };

        const jq = window.jQuery;
        if (jq && jq.fn && jq.fn.dataTable) {
            try {
                const namespace = ".pmkCopyActions" + String(rule.id || "").replace(/[^A-Za-z0-9]/g, "");
                const $table = jq(table);
                const events = "draw.dt" + namespace + " column-visibility.dt" + namespace + " responsive-resize.dt" + namespace;
                $table.on(events, function () {
                    window.setTimeout(function () { ensureTableButton(rule, table); }, 0);
                });
                binding.$table = $table;
                binding.eventNamespace = namespace;
            } catch (_) {}
        }

        const root = (table.closest && table.closest(".dataTables_wrapper")) || table.parentElement;
        if (root && typeof MutationObserver === "function") {
            const localObserver = new MutationObserver(function (mutations) {
                const relevant = mutations.some(function (mutation) {
                    return Array.from(mutation.addedNodes || []).some(function (node) {
                        return node && node.nodeType === 1 &&
                            !(node.matches && node.matches("." + TABLE_BUTTON_CLASS + ", ." + FEEDBACK_CLASS));
                    });
                });
                if (relevant) window.setTimeout(function () { ensureTableButton(rule, table); }, 0);
            });
            localObserver.observe(root, { childList: true, subtree: true });
            binding.observer = localObserver;
        }

        tableLifecycleBindings.push(binding);
    }

    function renderTableRule(rule) {
        let table = null;
        try { table = document.querySelector(rule.tableSelector); } catch (_) {}
        if (!table) {
            const root = document.querySelector("#main, main, #content, .main");
            if (root && typeof MutationObserver === "function") {
                const discovery = new MutationObserver(function () {
                    let found = null;
                    try { found = document.querySelector(rule.tableSelector); } catch (_) {}
                    if (!found) return;
                    discovery.disconnect();
                    ensureTableButton(rule, found);
                    bindTableLifecycle(rule, found);
                });
                discovery.observe(root, { childList: true, subtree: true });
                tableLifecycleBindings.push({ observer: discovery, $table: null, eventNamespace: "" });
            }
            return;
        }

        ensureTableButton(rule, table);
        bindTableLifecycle(rule, table);
    }

    function renderRule(rule) {
        if (rule.actionMode === "existing-trigger") {
            bindExistingTriggerRule(rule);
            return;
        }

        let elements = safeQueryAll(rule.selector);
        if (rule.matchMode === "first") elements = elements.slice(0, 1);
        elements.forEach(function (element, index) {
            if (!element || element.closest("#pmk-config-overlay")) return;
            const cluster = document.createElement("span");
            cluster.className = CLUSTER_CLASS;
            cluster.dataset.pmkCopyModule = MODULE_ID;
            cluster.dataset.pmkCopyRule = rule.id;
            cluster.dataset.pmkCopyIndex = String(index);
            cluster.appendChild(makeButton(element, rule));
            if (rule.placement === "before") element.insertAdjacentElement("beforebegin", cluster);
            else if (rule.placement === "inside-start") element.insertBefore(cluster, element.firstChild);
            else if (rule.placement === "inside-end") element.appendChild(cluster);
            else element.insertAdjacentElement("afterend", cluster);
        });
    }

    function applyAll(config) {
        clearInjected();
        currentConfig = normalizeConfig(config);
        if (currentConfig.enabled === false) return;
        injectStyles();
        currentConfig.rules.filter(ruleApplies).forEach(renderRule);
        currentConfig.tableRules.filter(tableRuleApplies).forEach(renderTableRule);
    }

    function stopObserver() {
        observers.forEach(function (activeObserver) {
            try { activeObserver.disconnect(); } catch (_) {}
        });
        observers = [];
        if (observerTimer) window.clearTimeout(observerTimer);
        observerTimer = 0;
    }

    function observerRootForRule(rule) {
        const selector = rule && rule.actionMode === "existing-trigger" && rule.triggerSelector
            ? rule.triggerSelector
            : (rule && rule.selector);
        const first = selector ? safeQueryAll(selector)[0] : null;
        if (first && first.closest) {
            return first.closest("table, .page-section, main, #main, #content") ||
                document.querySelector("#main, main, #content");
        }
        return document.querySelector("#main, main, #content");
    }

    function startObserver(config) {
        stopObserver();
        if (!config || config.enabled === false || config.observeDom === false || typeof MutationObserver !== "function") return;

        /*
         * Contrairement au legacy 115, aucun observer global sur document.body.
         * Chaque règle individuelle observe uniquement un conteneur Koha local.
         * Les règles de tableau possèdent leur propre cycle DataTables/local.
         */
        const roots = new Set();
        (config.rules || []).filter(ruleApplies).forEach(function (rule) {
            const root = observerRootForRule(rule);
            if (root) roots.add(root);
        });

        roots.forEach(function (root) {
            const localObserver = new MutationObserver(function (mutations) {
                const relevant = mutations.some(function (mutation) {
                    return Array.from(mutation.addedNodes || []).some(function (node) {
                        if (!node || node.nodeType !== 1) return false;
                        if (node.matches && node.matches("." + CLUSTER_CLASS + ", ." + TABLE_BUTTON_CLASS + ", ." + FEEDBACK_CLASS)) return false;
                        if (node.closest && node.closest("." + CLUSTER_CLASS)) return false;
                        return true;
                    });
                });
                if (!relevant) return;
                window.clearTimeout(observerTimer);
                observerTimer = window.setTimeout(function () {
                    applyAll(currentConfig);
                    startObserver(currentConfig);
                }, currentConfig.observeDelay || 120);
            });
            localObserver.observe(root, { childList: true, subtree: true });
            observers.push(localObserver);
        });
    }

    function selectorCount(selector) {
        return safeQueryAll(selector).length;
    }

    function elementExample(element) {
        if (!element) return "";
        if ((element.tagName === "INPUT" || element.tagName === "TEXTAREA" || element.tagName === "SELECT") && element.value != null) {
            return String(element.value).trim().slice(0, 160);
        }
        return cleanText(element.textContent).slice(0, 160);
    }

    function fallbackPicker() {
        return new Promise(function (resolve, reject) {
            let hovered = null;
            const style = document.createElement("style");
            style.textContent = ".pmk006-pick{outline:3px solid #408540!important;outline-offset:2px!important;cursor:crosshair!important}";
            document.head.appendChild(style);
            function stableSelector(el) {
                if (el.id) return "#" + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id.replace(/([^a-zA-Z0-9_-])/g, "\\$1"));
                const parts = [];
                let node = el;
                while (node && node !== document.body && parts.length < 5) {
                    let part = node.tagName.toLowerCase();
                    const classes = Array.from(node.classList || []).filter(function (c) { return !/^pmk/.test(c); });
                    if (classes.length) part += "." + classes[0];
                    else if (node.parentElement) {
                        const peers = Array.from(node.parentElement.children).filter(function (x) { return x.tagName === node.tagName; });
                        if (peers.length > 1) part += ":nth-of-type(" + (peers.indexOf(node) + 1) + ")";
                    }
                    parts.unshift(part);
                    node = node.parentElement;
                }
                return parts.join(" > ");
            }
            function cleanup() {
                if (hovered) hovered.classList.remove("pmk006-pick");
                document.removeEventListener("mouseover", over, true);
                document.removeEventListener("mouseout", out, true);
                document.removeEventListener("click", click, true);
                document.removeEventListener("keydown", key, true);
                style.remove();
            }
            function over(e) { if (hovered) hovered.classList.remove("pmk006-pick"); hovered = e.target; if (hovered && hovered.classList) hovered.classList.add("pmk006-pick"); }
            function out(e) { if (e.target && e.target.classList) e.target.classList.remove("pmk006-pick"); }
            function click(e) {
                e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
                const selector = stableSelector(e.target);
                const result = { value: selector, selector: selector, targetName: elementExample(e.target) || e.target.tagName.toLowerCase(), exampleValue: elementExample(e.target), matchCount: selectorCount(selector), pagePath: window.location.pathname };
                cleanup(); resolve(result);
            }
            function key(e) { if (e.key !== "Escape") return; e.preventDefault(); cleanup(); reject(new Error("picker_cancelled")); }
            document.addEventListener("mouseover", over, true);
            document.addEventListener("mouseout", out, true);
            document.addEventListener("click", click, true);
            document.addEventListener("keydown", key, true);
        });
    }

    function getTableRuleIndex(fieldPath) {
        const index = Array.isArray(fieldPath) && fieldPath[0] === "tableRules" ? Number(fieldPath[1]) : NaN;
        return Number.isInteger(index) ? index : null;
    }

    function stableSelectorForElement(element) {
        if (!element || element.nodeType !== 1) return "";
        if (element.id) {
            const escaped = window.CSS && CSS.escape
                ? CSS.escape(element.id)
                : element.id.replace(/([^a-zA-Z0-9_-])/g, "\\$1");
            return "#" + escaped;
        }

        const tag = element.tagName.toLowerCase();
        const classes = Array.from(element.classList || []).filter(function (name) {
            return name && !/^pmk/.test(name) && !/^sorting/.test(name) && !/^dt-/.test(name);
        });
        for (const className of classes) {
            const escapedClass = window.CSS && CSS.escape
                ? CSS.escape(className)
                : className.replace(/([^a-zA-Z0-9_-])/g, "\\$1");
            const candidate = tag + "." + escapedClass;
            try {
                if (document.querySelectorAll(candidate).length === 1) return candidate;
            } catch (_) {}
        }

        if (element.parentElement) {
            const peers = Array.from(element.parentElement.children).filter(function (node) {
                return node.tagName === element.tagName;
            });
            const parentSelector = stableSelectorForElement(element.parentElement);
            if (parentSelector) {
                return parentSelector + " > " + tag +
                    (peers.length > 1 ? ":nth-of-type(" + (peers.indexOf(element) + 1) + ")" : "");
            }
        }
        return tag;
    }

    function pickedTableMetadata(candidate, result) {
        if (!candidate || !candidate.closest) return result;
        const table = candidate.closest("table");
        if (!table) return result;

        result.tableSelector = table.id
            ? "#" + (window.CSS && CSS.escape ? CSS.escape(table.id) : table.id.replace(/([^a-zA-Z0-9_-])/g, "\\$1"))
            : (candidate === table ? result.selector : "");
        result.tableName = cleanText(table.getAttribute("aria-label") || table.getAttribute("summary") || table.id || "Tableau Koha");

        const row = candidate.closest("tr");
        if (row) {
            let relative = "";
            const tag = candidate.tagName ? candidate.tagName.toLowerCase() : "";
            const stableClass = Array.from(candidate.classList || []).find(function (name) {
                return name && !/^pmk/.test(name) && !/^sorting/.test(name) && !/^dt-/.test(name);
            });
            if (stableClass && tag) {
                relative = tag + "." + stableClass;
            } else if (tag === "a") {
                const href = candidate.getAttribute("href") || "";
                const paramMatch = href.match(/[?&]([A-Za-z0-9_]+)=/);
                if (paramMatch) relative = 'a[href*="' + paramMatch[1] + '="]';
                else relative = "a[href]";
            } else if (tag) {
                relative = tag;
            }
            result.rowRelativeSelector = relative;
        }

        const cell = candidate.closest("td,th");
        if (cell && cell.parentElement) {
            const cells = Array.from(cell.parentElement.children).filter(function (node) {
                return node.tagName === "TD" || node.tagName === "TH";
            });
            const index = cells.indexOf(cell);
            if (index >= 0) {
                result.columnIndexHint = index;
                const headers = Array.from(table.querySelectorAll("thead tr:last-child th, thead tr:last-child td"));
                if (headers[index]) {
                    result.columnHeaderText = cleanText(headers[index].textContent || "");
                    if (headers[index].id) result.columnHeaderSelector = "#" + headers[index].id;
                    else {
                        const stableClass = Array.from(headers[index].classList || []).find(function (name) {
                            return name && !/^sorting/.test(name) && !/^dt-/.test(name);
                        });
                        if (stableClass) result.columnHeaderSelector = "thead th." + stableClass;
                    }
                }
            }
        }
        return result;
    }

    function applyTablePickerResult(rootObject, fieldPath, result) {
        const index = getTableRuleIndex(fieldPath);
        if (index === null || !rootObject || !Array.isArray(rootObject.tableRules) || !rootObject.tableRules[index] || !result) return;
        const rule = rootObject.tableRules[index];
        const fieldName = pickerFieldName(fieldPath);
        rule.pagePath = result.pagePath || rule.pagePath || window.location.pathname;

        if (fieldName === "tableSelector") {
            rule.tableSelector = result.tableSelector || result.selector || rule.tableSelector;
            rule.tableName = result.tableName || result.targetName || rule.tableName || "Tableau Koha";
            rule.tableMatchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(rule.tableSelector);
            return;
        }

        if (fieldName === "buttonContainerSelector") {
            rule.buttonContainerName = result.targetName || rule.buttonContainerName || "Conteneur du bouton";
            return;
        }

        rule.sourceName = result.targetName || rule.sourceName || "Valeur du tableau";
        rule.exampleValue = result.exampleValue || rule.exampleValue || "";
        if (rule.sourceMode === "selector" && cleanText(result.rowRelativeSelector)) {
            rule.sourceSelector = result.rowRelativeSelector;
        }
        rule.sourceMatchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(result.selector || rule.sourceSelector);
        if (result.tableSelector) {
            rule.tableSelector = result.tableSelector;
            rule.tableName = result.tableName || rule.tableName;
        }
        if (Number.isInteger(result.columnIndexHint)) rule.columnIndexHint = result.columnIndexHint;
        if (result.columnHeaderSelector) rule.columnHeaderSelector = result.columnHeaderSelector;
        if (result.columnHeaderText && !cleanText(rule.columnHeaderLabels)) rule.columnHeaderLabels = result.columnHeaderText;
    }

    function pickForTableRule(context) {
        const ctx = context || {};
        const index = getTableRuleIndex(ctx.fieldPath);
        const rule = index !== null && ctx.rootObject && Array.isArray(ctx.rootObject.tableRules)
            ? ctx.rootObject.tableRules[index]
            : null;
        const targetUrl = rule && rule.pagePath ? rule.pagePath : window.location.pathname;
        const fieldName = pickerFieldName(ctx.fieldPath);
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (picker && typeof picker.pickForConfig === "function") {
            let banner = i18n("Clique sur une valeur du tableau — Échap annule", "Click a table value — Esc cancels");
            if (fieldName === "tableSelector") banner = i18n("Clique dans le tableau à utiliser — Échap annule", "Click inside the table to use — Esc cancels");
            if (fieldName === "buttonContainerSelector") banner = i18n("Clique sur le conteneur où placer l’action — Échap annule", "Click the container where the action should be placed — Esc cancels");
            return picker.pickForConfig({
                moduleId: MODULE_ID,
                targetUrl: targetUrl,
                fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath.slice() : [],
                rootObject: ctx.rootObject || {},
                adminContext: { sectionId: "tableRules", pagePath: targetUrl },
                options: { bannerText: banner }
            });
        }
        return fallbackPicker();
    }

    function getRuleIndex(fieldPath) {
        const index = Array.isArray(fieldPath) && fieldPath[0] === "rules" ? Number(fieldPath[1]) : NaN;
        return Number.isInteger(index) ? index : null;
    }

    function pickerFieldName(fieldPath) {
        if (!Array.isArray(fieldPath) || !fieldPath.length) return "";
        return String(fieldPath[fieldPath.length - 1] || "");
    }

    function applyPickerResult(rootObject, fieldPath, result) {
        const index = getRuleIndex(fieldPath);
        if (index === null || !rootObject || !Array.isArray(rootObject.rules) || !rootObject.rules[index] || !result) return;
        const rule = rootObject.rules[index];
        const fieldName = pickerFieldName(fieldPath);
        rule.pagePath = result.pagePath || rule.pagePath || window.location.pathname;

        if (fieldName === "triggerSelector") {
            rule.triggerName = result.targetName || rule.triggerName || "Déclencheur de copie";
            rule.triggerMatchCount = Number.isInteger(result.matchCount)
                ? result.matchCount
                : selectorCount(result.selector || rule.triggerSelector);
            return;
        }

        rule.targetName = result.targetName || rule.targetName || "Élément Koha";
        rule.exampleValue = result.exampleValue || rule.exampleValue || "";
        rule.matchCount = Number.isInteger(result.matchCount) ? result.matchCount : selectorCount(result.selector || rule.selector);
    }

    function pickForRule(context) {
        const ctx = context || {};
        const index = getRuleIndex(ctx.fieldPath);
        const rule = index !== null && ctx.rootObject && Array.isArray(ctx.rootObject.rules) ? ctx.rootObject.rules[index] : null;
        const targetUrl = rule && rule.pagePath ? rule.pagePath : window.location.pathname;
        const fieldName = pickerFieldName(ctx.fieldPath);
        const isTriggerPick = fieldName === "triggerSelector";
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (picker && typeof picker.pickForConfig === "function") {
            return picker.pickForConfig({
                moduleId: MODULE_ID,
                targetUrl: targetUrl,
                fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath.slice() : [],
                rootObject: ctx.rootObject || {},
                adminContext: { sectionId: "rules", pagePath: targetUrl },
                options: {
                    bannerText: isTriggerPick
                        ? i18n("Clique sur l’élément qui déclenchera la copie — Échap annule", "Click the element that will trigger copying — Esc cancels")
                        : i18n("Clique sur l’élément dont la valeur doit être copiée — Échap annule", "Click the element whose value must be copied — Esc cancels")
                }
            });
        }
        return fallbackPicker();
    }

    function registerPickerAdapter() {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return;
        picker.register(MODULE_ID, {
            buildResult: function (candidate, result) {
                result.exampleValue = elementExample(candidate);
                result.matchCount = selectorCount(result.selector);
                return pickedTableMetadata(candidate, result);
            },
            applyPending: function (draft, pending, picked) {
                const fieldPath = pending && pending.fieldPath;
                if (!picked || !draft) return draft;

                const tableIndex = getTableRuleIndex(fieldPath);
                if (tableIndex !== null && Array.isArray(draft.tableRules) && draft.tableRules[tableIndex]) {
                    applyTablePickerResult(draft, fieldPath, picked);
                    return draft;
                }

                const index = getRuleIndex(fieldPath);
                if (index === null || !Array.isArray(draft.rules) || !draft.rules[index]) return draft;
                const rule = draft.rules[index];
                const fieldName = pickerFieldName(fieldPath);
                rule.pagePath = picked.pagePath || rule.pagePath || window.location.pathname;

                if (fieldName === "triggerSelector") {
                    rule.triggerName = picked.targetName || rule.triggerName || "Déclencheur de copie";
                    rule.triggerMatchCount = Number.isInteger(picked.matchCount) ? picked.matchCount : null;
                    return draft;
                }

                rule.targetName = picked.targetName || rule.targetName || "Élément Koha";
                rule.exampleValue = picked.exampleValue || rule.exampleValue || "";
                rule.matchCount = Number.isInteger(picked.matchCount) ? picked.matchCount : null;
                return draft;
            }
        });
    }

    function newRule() {
        return mergeRule({
            id: makeId(),
            label: i18n("Nouvelle action de copie", "New copy action"),
            pagePath: window.location.pathname,
            actionMode: "generated",
            selector: "",
            targetName: "",
            triggerSelector: "",
            triggerName: "",
            iconColor: "#6c757d",
            iconHoverColor: "#212529",
            actionSizePx: 16,
            showText: false,
            textSizePx: 13,
            textColor: "#495057",
            textHoverColor: "#212529",
            titleFr: "Copier",
            titleEn: "Copy"
        }, 0);
    }

    function newTableRule() {
        return mergeTableRule({
            id: makeId().replace(/^copy-/, "copy-table-"),
            label: i18n("Nouvelle copie groupée", "New grouped copy action"),
            pagePath: window.location.pathname,
            tableSelector: "",
            tableName: "",
            sourceMode: "column",
            sourceSelector: "",
            sourceName: "",
            columnHeaderSelector: "",
            columnHeaderLabels: "",
            scope: "visible",
            deduplicate: true,
            separator: "newline",
            resultOrder: "display",
            buttonStyle: "datatable",
            buttonTextFr: "Copier",
            buttonTextEn: "Copy",
            titleFr: "Copier les valeurs affichées",
            titleEn: "Copy displayed values"
        }, 0);
    }

    function validate(config) {
        const cfg = normalizeConfig(config);
        const ids = new Set();
        for (const rule of cfg.rules) {
            if (!rule.id || ids.has(rule.id)) return { ok: false, message: i18n("Chaque action doit avoir un identifiant unique.", "Each action must have a unique identifier.") };
            ids.add(rule.id);
            if (!String(rule.pagePath || "").trim()) return { ok: false, message: i18n("Chaque action doit indiquer une page Koha.", "Each action must specify a Koha page.") };
            if (!String(rule.selector || "").trim()) return { ok: false, message: i18n("Chaque action doit cibler l’élément dont la valeur sera copiée.", "Each action must target the element whose value will be copied.") };
            if (rule.actionMode === "existing-trigger" && !String(rule.triggerSelector || "").trim()) {
                return { ok: false, message: i18n("Cette action doit indiquer l’élément existant qui déclenchera la copie.", "This action must specify the existing element that will trigger copying.") };
            }
            if (rule.valueSource === "attribute" && !String(rule.attributeName || "").trim()) return { ok: false, message: i18n("Le nom de l’attribut à copier est vide.", "The attribute name to copy is empty.") };
            if (rule.transform !== "full" && (!Number.isFinite(Number(rule.length)) || Number(rule.length) < 1)) return { ok: false, message: i18n("Le nombre de caractères doit être supérieur à zéro.", "The character count must be greater than zero.") };
            if (rule.actionMode === "generated" && rule.visualType === "fa" && !cleanText(rule.iconClass)) return { ok: false, message: i18n("Indique une classe Font Awesome ou choisis « aucune icône ».", "Provide a Font Awesome class or choose no icon.") };
            if (rule.actionMode === "generated" && rule.visualType === "image" && !cleanText(rule.imageUrl)) return { ok: false, message: i18n("Indique l’URL de l’image de l’action.", "Provide the action image URL.") };
        }

        for (const rule of cfg.tableRules) {
            if (!rule.id || ids.has(rule.id)) return { ok: false, message: i18n("Chaque action doit avoir un identifiant unique.", "Each action must have a unique identifier.") };
            ids.add(rule.id);
            if (!cleanText(rule.pagePath)) return { ok: false, message: i18n("Chaque copie groupée doit indiquer une page Koha.", "Each grouped copy action must specify a Koha page.") };
            if (!cleanText(rule.tableSelector)) return { ok: false, message: i18n("Chaque copie groupée doit cibler un tableau.", "Each grouped copy action must target a table.") };
            if (rule.sourceMode === "selector" && !cleanText(rule.sourceSelector)) {
                return { ok: false, message: i18n("La copie groupée par sélecteur doit indiquer l’élément à extraire.", "Grouped selector copy must specify the element to extract.") };
            }
            if (rule.sourceMode === "column" && !cleanText(rule.columnHeaderSelector) && !cleanText(rule.columnHeaderLabels) && !Number.isInteger(rule.columnIndexHint)) {
                return { ok: false, message: i18n("La copie groupée par colonne doit identifier la colonne (sélecteur, libellé ou index).", "Grouped column copy must identify the column (selector, label or index).") };
            }
            if (rule.valueSource === "attribute" && !cleanText(rule.attributeName)) {
                return { ok: false, message: i18n("Le nom de l’attribut à copier est vide.", "The attribute name to copy is empty.") };
            }
            if (rule.separator === "custom" && rule.customSeparator === undefined) {
                return { ok: false, message: i18n("Le séparateur personnalisé est invalide.", "The custom separator is invalid.") };
            }
        }
        return { ok: true };
    }

    function ruleFromVisualPath(rootObject, fieldPath) {
        const index = getRuleIndex(fieldPath || []);
        return rootObject && Array.isArray(rootObject.rules) && index !== null
            ? rootObject.rules[index]
            : null;
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: true,
                livePreview: true
            },
            previewModel: function (context) {
                const rule = ruleFromVisualPath(context && context.rootObject, context && context.fieldPath) || RULE_BASE;
                return {
                    text: rule.showText === true
                        ? visibleText(rule)
                        : i18n("Action de copie", "Copy action"),
                    style: {
                        fontSize: (Number(rule.textSizePx) || 13) + "px",
                        color: cleanText(rule.textColor) || "#495057"
                    },
                    icon: rule.visualType === "none" ? null : {
                        type: rule.visualType,
                        className: rule.visualType === "fa" ? rule.iconClass : "",
                        url: rule.visualType === "image" ? rule.imageUrl : "",
                        size: Number(rule.actionSizePx) || 16,
                        color: cleanText(rule.iconColor) || "#6c757d",
                        position: "before"
                    },
                    title: accessibleLabel(rule)
                };
            },
            styleTargetUrl: function (context) {
                const rule = ruleFromVisualPath(context && context.rootObject, context && context.fieldPath);
                return rule && rule.pagePath ? rule.pagePath : window.location.pathname;
            },
            applyStyleSample: function (context) {
                const rule = ruleFromVisualPath(context && context.rootObject, context && context.fieldPath);
                const sample = context && context.sample;
                if (!rule || !sample) return { rootObject: context && context.rootObject };
                const visual = window.PMKConfig && window.PMKConfig.visualEditor;
                const size = visual && typeof visual.pxNumber === "function"
                    ? visual.pxNumber(sample.fontSize, null)
                    : parseFloat(sample.fontSize);
                const color = visual && typeof visual.colorToHex === "function"
                    ? visual.colorToHex(sample.color)
                    : "";
                if (Number.isFinite(size)) {
                    rule.actionSizePx = Math.max(8, Math.min(64, Math.round(size)));
                    rule.textSizePx = Math.max(8, Math.min(40, Math.round(size)));
                }
                if (color) {
                    rule.iconColor = color;
                    rule.textColor = color;
                }
                return { rootObject: context && context.rootObject };
            },
            previewDraft: function (draft) {
                const before = clone(currentConfig || DEFAULT_CONFIG);
                applyAll(draft);
                return function () {
                    applyAll(before);
                };
            }
        });
        return true;
    }

    function moduleDefinition() {
        const valueSourceOptions = [
            { value: "text", label: { fr: "Texte affiché dans l’élément", en: "Displayed element text" } },
            { value: "value", label: { fr: "Valeur d’un champ de formulaire", en: "Form field value" } },
            { value: "attribute", label: { fr: "Attribut HTML", en: "HTML attribute" } }
        ];
        return {
            id: MODULE_ID,
            schemaVersion: 6,
            name: { fr: "Actions de copie", en: "Copy actions" },
            description: {
                fr: "Centralise les copies individuelles et groupées dans Koha. Les usages historiques du 056 (ISBN, EAN, titre), du 115 (copies groupées en tableaux) et du 133 (copie du code-barres exemplaire sur detail.pl) sont intégrés ici.",
                en: "Centralizes individual and grouped copying in Koha. Historical 056 behavior (ISBN, EAN, title), 115 table behavior and 133 item-barcode copying on detail.pl are integrated here."
            },
            category: { fr: "Interface / outils", en: "Interface / tools" },
            supportedPages: ["*"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Actions de copie", en: "Copy actions" },
                    description: {
                        fr: "Ajoute autant d’actions que nécessaire. Une action peut créer un nouveau contrôle ou réutiliser un pictogramme/lien déjà présent. La source et le déclencheur sont choisis avec le picker commun PMK.",
                        en: "Add as many actions as needed. An action can create a new control or reuse an existing icon/link. Source and trigger are selected with the shared PMK picker."
                    },
                    fields: [
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Actions configurées", en: "Configured actions" },
                            addLabel: { fr: "Ajouter une action de copie", en: "Add a copy action" },
                            reorder: true,
                            newItem: newRule,
                            liveTitleKey: "label",
                            itemTitle: function (item, index) { return cleanText(item && item.label) || (i18n("Action ", "Action ") + (index + 1)); },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Action active", en: "Action enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de l’action", en: "Action name" } },
                                {
                                    key: "actionMode",
                                    type: "select",
                                    label: { fr: "Déclenchement de la copie", en: "Copy trigger" },
                                    options: [
                                        { value: "generated", label: { fr: "Ajouter une action de copie", en: "Add a copy action" } },
                                        { value: "existing-trigger", label: { fr: "Utiliser un élément déjà présent", en: "Use an existing element" } }
                                    ],
                                    refreshOnChange: true
                                },
                                {
                                    key: "pagePath",
                                    type: "text",
                                    label: { fr: "Page Koha", en: "Koha page" },
                                    help: { fr: "Ex. /cgi-bin/koha/catalogue/detail.pl. Si cette page n’est pas ouverte, le picker commun peut y naviguer avant la sélection.", en: "E.g. /cgi-bin/koha/catalogue/detail.pl. If that page is not open, the shared picker can navigate there before selection." }
                                },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Élément dont la valeur sera copiée", en: "Element whose value will be copied" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                                    allowManual: true,
                                    pick: pickForRule,
                                    onPick: applyPickerResult
                                },
                                { key: "targetName", type: "readonly", label: { fr: "Élément source détecté", en: "Detected source element" } },
                                {
                                    key: "triggerSelector",
                                    type: "elementPicker",
                                    label: { fr: "Élément existant qui déclenche la copie", en: "Existing element that triggers copying" },
                                    pickLabel: { fr: "Choisir le déclencheur sur la page", en: "Choose trigger on page" },
                                    emptyLabel: { fr: "Aucun déclencheur choisi", en: "No trigger selected" },
                                    allowManual: true,
                                    pick: pickForRule,
                                    onPick: applyPickerResult,
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "existing-trigger"); }
                                },
                                {
                                    key: "triggerName",
                                    type: "readonly",
                                    label: { fr: "Déclencheur détecté", en: "Detected trigger" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "existing-trigger"); }
                                },
                                {
                                    type: "visualPreview",
                                    label: { fr: "Aperçu de l’action", en: "Action preview" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); }
                                },
                                {
                                    type: "styleEyedropper",
                                    label: { fr: "Pipette de style", en: "Style eyedropper" },
                                    buttonLabel: { fr: "Reprendre la taille et la couleur d’un élément…", en: "Reuse an element’s size and color…" },
                                    iconClass: "fa fa-eyedropper",
                                    sectionId: "rules",
                                    help: {
                                        fr: "La pipette adapte uniquement la taille et les couleurs de l’action de copie ; elle ne copie ni position ni comportement.",
                                        en: "The eyedropper only adapts the copy action size and colors; it never copies positioning or behavior."
                                    },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); }
                                },
                                {
                                    key: "valueSource",
                                    type: "select",
                                    label: { fr: "Valeur à copier", en: "Value to copy" },
                                    options: valueSourceOptions,
                                    refreshOnChange: true
                                },
                                {
                                    key: "attributeName",
                                    type: "text",
                                    label: { fr: "Nom de l’attribut HTML", en: "HTML attribute name" },
                                    placeholder: { fr: "ex. data-id, href, title", en: "e.g. data-id, href, title" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].valueSource === "attribute"); }
                                },
                                {
                                    key: "transform",
                                    type: "select",
                                    label: { fr: "Partie à copier", en: "Part to copy" },
                                    options: [
                                        { value: "full", label: { fr: "Valeur complète", en: "Full value" } },
                                        { value: "prefix", label: { fr: "Premiers caractères", en: "First characters" } },
                                        { value: "suffix", label: { fr: "Derniers caractères", en: "Last characters" } }
                                    ],
                                    refreshOnChange: true
                                },
                                {
                                    key: "length",
                                    type: "number",
                                    min: 1,
                                    max: 500,
                                    label: { fr: "Nombre de caractères", en: "Number of characters" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].transform !== "full"); }
                                },
                                {
                                    key: "placement",
                                    type: "select",
                                    label: { fr: "Position de l’icône / action", en: "Icon / action position" },
                                    options: [
                                        { value: "before", label: { fr: "Avant l’élément", en: "Before the element" } },
                                        { value: "after", label: { fr: "Après l’élément", en: "After the element" } },
                                        { value: "inside-start", label: { fr: "Au début de l’élément", en: "At the start of the element" } },
                                        { value: "inside-end", label: { fr: "À la fin de l’élément", en: "At the end of the element" } }
                                    ],
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); }
                                },
                                {
                                    key: "visualType",
                                    type: "select",
                                    label: { fr: "Visuel de l’action", en: "Action visual" },
                                    options: [
                                        { value: "fa", label: { fr: "Icône Font Awesome", en: "Font Awesome icon" } },
                                        { value: "image", label: { fr: "Image", en: "Image" } },
                                        { value: "none", label: { fr: "Aucun logo", en: "No logo" } }
                                    ],
                                    refreshOnChange: true,
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); }
                                },
                                {
                                    key: "iconClass",
                                    type: "text",
                                    label: { fr: "Classe Font Awesome", en: "Font Awesome class" },
                                    placeholder: { fr: "fa fa-copy", en: "fa fa-copy" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].visualType === "fa"); }
                                },
                                {
                                    key: "iconColor",
                                    type: "color",
                                    label: { fr: "Couleur de l’icône Font Awesome", en: "Font Awesome icon color" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].visualType === "fa"); }
                                },
                                {
                                    key: "iconHoverColor",
                                    type: "color",
                                    label: { fr: "Couleur de l’icône au survol", en: "Icon hover color" },
                                    help: { fr: "Le survol reste volontairement discret : changement de couleur et léger agrandissement, sans fond de bouton.", en: "Hover stays intentionally discreet: color change and slight enlargement, with no button background." },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].visualType === "fa"); }
                                },
                                {
                                    key: "actionSizePx",
                                    type: "number",
                                    label: { fr: "Taille de l’action / icône (px)", en: "Action / icon size (px)" },
                                    help: { fr: "Règle la taille de l’icône Font Awesome ou de l’image. Zone conseillée : 12 à 24 px pour rester discrète.", en: "Controls the Font Awesome icon or image size. Recommended range: 12 to 24 px for a discreet action." },
                                    min: 8,
                                    max: 64,
                                    step: 1,
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); }
                                },
                                {
                                    key: "imageUrl",
                                    type: "imageUrl",
                                    label: { fr: "Image de l’action", en: "Action image" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].visualType === "image"); }
                                },
                                { key: "showText", type: "boolean", label: { fr: "Afficher un texte à côté de l’icône", en: "Show text next to the icon" }, refreshOnChange: true, when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated"); } },
                                {
                                    key: "textSizePx",
                                    type: "number",
                                    label: { fr: "Taille du texte (px)", en: "Text size (px)" },
                                    min: 8,
                                    max: 40,
                                    step: 1,
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].showText === true); }
                                },
                                {
                                    key: "textColor",
                                    type: "color",
                                    label: { fr: "Couleur du texte", en: "Text color" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].showText === true); }
                                },
                                {
                                    key: "textHoverColor",
                                    type: "color",
                                    label: { fr: "Couleur du texte au survol", en: "Text hover color" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].showText === true); }
                                },
                                {
                                    key: "buttonTextFr",
                                    type: "text",
                                    label: { fr: "Texte de l’action — français", en: "Action text — French" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].showText === true); }
                                },
                                {
                                    key: "buttonTextEn",
                                    type: "text",
                                    label: { fr: "Texte de l’action — anglais", en: "Action text — English" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "generated" && root.rules[i].showText === true); }
                                },
                                { key: "titleFr", type: "text", label: { fr: "Infobulle / libellé accessible — français", en: "Tooltip / accessible label — French" } },
                                { key: "titleEn", type: "text", label: { fr: "Infobulle / libellé accessible — anglais", en: "Tooltip / accessible label — English" } },
                                {
                                    key: "feedbackEnabled",
                                    type: "boolean",
                                    refreshOnChange: true,
                                    label: { fr: "Afficher un retour visuel après copie", en: "Show visual feedback after copy" },
                                    help: { fr: "Disponible pour toutes les actions, y compris les déclencheurs déjà présents dans Koha.", en: "Available for every action, including triggers already present in Koha." }
                                },
                                {
                                    key: "feedbackPlacement",
                                    type: "select",
                                    label: { fr: "Position du retour visuel", en: "Feedback position" },
                                    options: [
                                        { value: "auto", label: { fr: "Automatique — proche de l’action", en: "Automatic — near the action" } },
                                        { value: "after-trigger", label: { fr: "Juste après l’action", en: "Immediately after action" } },
                                        { value: "parent-end", label: { fr: "À la fin du conteneur de l’action", en: "At the end of the action container" } },
                                        { value: "floating", label: { fr: "Message flottant", en: "Floating message" } }
                                    ],
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackDurationMs",
                                    type: "number",
                                    min: 300,
                                    max: 10000,
                                    step: 100,
                                    label: { fr: "Durée du message (ms)", en: "Message duration (ms)" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackSuccessTextFr",
                                    type: "text",
                                    label: { fr: "Texte succès — français", en: "Success text — French" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackSuccessTextEn",
                                    type: "text",
                                    label: { fr: "Texte succès — anglais", en: "Success text — English" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackErrorTextFr",
                                    type: "text",
                                    label: { fr: "Texte erreur — français", en: "Error text — French" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackErrorTextEn",
                                    type: "text",
                                    label: { fr: "Texte erreur — anglais", en: "Error text — English" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackSuccessColor",
                                    type: "color",
                                    label: { fr: "Couleur du succès", en: "Success color" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackErrorColor",
                                    type: "color",
                                    label: { fr: "Couleur de l’erreur", en: "Error color" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackFontSize",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Taille du texte du retour", en: "Feedback text size" },
                                    help: { fr: "Valeur CSS, par exemple 0.75em ou 12px.", en: "CSS value, for example 0.75em or 12px." },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackFontWeight",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Graisse du texte du retour", en: "Feedback font weight" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackMargin",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Marges du retour visuel", en: "Feedback margin" },
                                    help: { fr: "Valeur CSS. Le défaut 0 0 0 5px reprend le 107.", en: "CSS value. Default 0 0 0 5px matches 107." },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                {
                                    key: "feedbackFade",
                                    type: "boolean",
                                    label: { fr: "Faire disparaître progressivement le message", en: "Fade the message out" },
                                    when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].feedbackEnabled !== false); }
                                },
                                { key: "matchMode", type: "select", advanced: true, label: { fr: "Si plusieurs éléments correspondent", en: "If several elements match" }, options: [ { value: "all", label: { fr: "Ajouter une action à chacun", en: "Add an action to each" } }, { value: "first", label: { fr: "Seulement au premier", en: "First one only" } } ] },
                                { key: "excludeSelector", type: "text", advanced: true, label: { fr: "Sous-éléments à exclure du texte copié", en: "Child elements excluded from copied text" } },
                                { key: "trim", type: "boolean", advanced: true, label: { fr: "Supprimer les espaces début/fin", en: "Trim leading/trailing spaces" } },
                                { key: "extractRegex", type: "text", advanced: true, label: { fr: "Extraire avec une RegExp", en: "Extract with RegExp" } },
                                { key: "regexFlags", type: "text", advanced: true, label: { fr: "Options RegExp", en: "RegExp flags" } },
                                { key: "regexGroup", type: "number", advanced: true, label: { fr: "Groupe RegExp utilisé", en: "RegExp group" } },
                                { key: "exampleValue", type: "readonly", advanced: true, label: { fr: "Exemple détecté lors du pick", en: "Example detected when picked" } },
                                { key: "matchCount", type: "readonly", advanced: true, label: { fr: "Sources trouvées lors du pick", en: "Sources found when picked" } },
                                { key: "triggerMatchCount", type: "readonly", advanced: true, label: { fr: "Déclencheurs trouvés lors du pick", en: "Triggers found when picked" }, when: function (root, path) { const i = getRuleIndex(path); return Boolean(i !== null && root.rules[i] && root.rules[i].actionMode === "existing-trigger"); } },
                                { key: "id", type: "readonly", advanced: true, label: { fr: "Identifiant technique", en: "Technical identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "tableRules",
                    label: { fr: "Copies groupées / tableaux", en: "Grouped / table copies" },
                    description: {
                        fr: "Copie en une action plusieurs valeurs d’un tableau Koha. Les six règles historiques du 115 sont fournies par défaut. Utilise le picker pour choisir le tableau et une valeur représentative.",
                        en: "Copies several values from a Koha table in one action. The six historical 115 rules are provided by default. Use the picker to choose the table and a representative value."
                    },
                    fields: [
                        {
                            key: "tableRules",
                            type: "repeater",
                            label: { fr: "Actions groupées configurées", en: "Configured grouped actions" },
                            addLabel: { fr: "Ajouter une copie groupée", en: "Add grouped copy action" },
                            reorder: true,
                            newItem: newTableRule,
                            liveTitleKey: "label",
                            itemTitle: function (item, index) { return cleanText(item && item.label) || (i18n("Copie groupée ", "Grouped copy ") + (index + 1)); },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Action active", en: "Action enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom de l’action", en: "Action name" } },
                                {
                                    key: "pagePath",
                                    type: "text",
                                    label: { fr: "Page Koha", en: "Koha page" },
                                    help: { fr: "Ex. /cgi-bin/koha/circ/returns.pl", en: "E.g. /cgi-bin/koha/circ/returns.pl" }
                                },
                                {
                                    key: "tableSelector",
                                    type: "elementPicker",
                                    label: { fr: "Tableau à exploiter", en: "Table to use" },
                                    pickLabel: { fr: "Choisir le tableau sur la page", en: "Choose table on page" },
                                    emptyLabel: { fr: "Aucun tableau choisi", en: "No table selected" },
                                    allowManual: true,
                                    pick: pickForTableRule,
                                    onPick: applyTablePickerResult
                                },
                                { key: "tableName", type: "readonly", label: { fr: "Tableau détecté", en: "Detected table" } },
                                {
                                    key: "sourceMode",
                                    type: "select",
                                    label: { fr: "Mode d’extraction", en: "Extraction mode" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "column", label: { fr: "Une colonne du tableau", en: "A table column" } },
                                        { value: "selector", label: { fr: "Éléments ciblés dans chaque ligne", en: "Targeted elements in each row" } }
                                    ]
                                },
                                {
                                    key: "sourceSelector",
                                    type: "elementPicker",
                                    label: { fr: "Valeur représentative", en: "Representative value" },
                                    pickLabel: { fr: "Choisir une valeur dans le tableau", en: "Choose a value in the table" },
                                    emptyLabel: { fr: "Aucune valeur choisie", en: "No value selected" },
                                    allowManual: true,
                                    pick: pickForTableRule,
                                    onPick: applyTablePickerResult,
                                    help: {
                                        fr: "En mode colonne, le picker mémorise surtout la colonne. En mode sélecteur, ce sélecteur est utilisé pour retrouver les valeurs dans chaque ligne.",
                                        en: "In column mode, the picker mainly records the column. In selector mode, this selector is used to find values in each row."
                                    }
                                },
                                { key: "sourceName", type: "readonly", label: { fr: "Valeur détectée", en: "Detected value" } },
                                {
                                    key: "columnHeaderLabels",
                                    type: "text",
                                    label: { fr: "Libellés possibles de la colonne", en: "Possible column labels" },
                                    help: { fr: "Séparer les variantes FR/EN par ;. Utilisé seulement en fallback.", en: "Separate FR/EN variants with ;. Used only as a fallback." },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].sourceMode === "column"); }
                                },
                                {
                                    key: "columnHeaderSelector",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Sélecteur stable de l’en-tête", en: "Stable header selector" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].sourceMode === "column"); }
                                },
                                {
                                    key: "columnIndexHint",
                                    type: "readonly",
                                    advanced: true,
                                    label: { fr: "Index de colonne détecté", en: "Detected column index" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].sourceMode === "column"); }
                                },
                                {
                                    key: "valueSource",
                                    type: "select",
                                    label: { fr: "Valeur à lire", en: "Value to read" },
                                    refreshOnChange: true,
                                    options: valueSourceOptions
                                },
                                {
                                    key: "attributeName",
                                    type: "text",
                                    label: { fr: "Attribut HTML à lire", en: "HTML attribute to read" },
                                    placeholder: { fr: "ex. href, data-id", en: "e.g. href, data-id" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].valueSource === "attribute"); }
                                },
                                {
                                    key: "urlParam",
                                    type: "text",
                                    label: { fr: "Extraire un paramètre de l’URL", en: "Extract URL parameter" },
                                    placeholder: { fr: "ex. biblionumber", en: "e.g. biblionumber" },
                                    advanced: true,
                                    help: { fr: "Laisser vide pour copier l’attribut entier.", en: "Leave empty to copy the whole attribute." }
                                },
                                {
                                    key: "scope",
                                    type: "select",
                                    label: { fr: "Lignes à copier", en: "Rows to copy" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "visible", label: { fr: "Page actuellement visible — historique 115", en: "Currently visible page — historical 115" } },
                                        { value: "filtered", label: { fr: "Toutes les lignes correspondant au filtre", en: "All rows matching the filter" } },
                                        { value: "selected", label: { fr: "Lignes sélectionnées uniquement", en: "Selected rows only" } },
                                        { value: "loaded", label: { fr: "Toutes les lignes chargées", en: "All loaded rows" } }
                                    ]
                                },
                                {
                                    key: "selectedRowSelector",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Sélecteur d’une ligne sélectionnée", en: "Selected row selector" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].scope === "selected"); }
                                },
                                {
                                    key: "selectionCheckboxSelector",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Case cochée indiquant la sélection", en: "Checked box indicating selection" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].scope === "selected"); }
                                },
                                { key: "deduplicate", type: "boolean", label: { fr: "Supprimer les doublons", en: "Remove duplicates" } },
                                {
                                    key: "resultOrder",
                                    type: "select",
                                    label: { fr: "Ordre des valeurs copiées", en: "Copied value order" },
                                    options: [
                                        { value: "display", label: { fr: "Ordre du tableau", en: "Table order" } },
                                        { value: "alpha-asc", label: { fr: "Alphabétique croissant", en: "Alphabetical ascending" } },
                                        { value: "alpha-desc", label: { fr: "Alphabétique décroissant", en: "Alphabetical descending" } },
                                        { value: "numeric-asc", label: { fr: "Numérique croissant", en: "Numeric ascending" } },
                                        { value: "numeric-desc", label: { fr: "Numérique décroissant", en: "Numeric descending" } }
                                    ]
                                },
                                {
                                    key: "separator",
                                    type: "select",
                                    label: { fr: "Séparateur", en: "Separator" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "newline", label: { fr: "Une valeur par ligne — historique 115", en: "One value per line — historical 115" } },
                                        { value: "comma", label: { fr: "Virgule", en: "Comma" } },
                                        { value: "semicolon", label: { fr: "Point-virgule", en: "Semicolon" } },
                                        { value: "tab", label: { fr: "Tabulation", en: "Tab" } },
                                        { value: "space", label: { fr: "Espace", en: "Space" } },
                                        { value: "custom", label: { fr: "Personnalisé", en: "Custom" } }
                                    ]
                                },
                                {
                                    key: "customSeparator",
                                    type: "text",
                                    label: { fr: "Séparateur personnalisé", en: "Custom separator" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].separator === "custom"); }
                                },
                                {
                                    key: "transform",
                                    type: "select",
                                    label: { fr: "Partie de chaque valeur à copier", en: "Part of each value to copy" },
                                    refreshOnChange: true,
                                    options: [
                                        { value: "full", label: { fr: "Valeur complète", en: "Full value" } },
                                        { value: "prefix", label: { fr: "Premiers caractères", en: "First characters" } },
                                        { value: "suffix", label: { fr: "Derniers caractères", en: "Last characters" } }
                                    ]
                                },
                                {
                                    key: "length",
                                    type: "number",
                                    min: 1,
                                    max: 500,
                                    label: { fr: "Nombre de caractères", en: "Number of characters" },
                                    when: function (root, path) { const i = getTableRuleIndex(path); return Boolean(i !== null && root.tableRules[i] && root.tableRules[i].transform !== "full"); }
                                },
                                {
                                    key: "buttonStyle",
                                    type: "select",
                                    label: { fr: "Style du bouton", en: "Button style" },
                                    options: [
                                        { value: "datatable", label: { fr: "Bouton DataTables / Koha — historique", en: "DataTables / Koha button — historical" } },
                                        { value: "koha", label: { fr: "Bouton Koha classique", en: "Classic Koha button" } }
                                    ]
                                },
                                { key: "iconClass", type: "text", label: { fr: "Icône Font Awesome", en: "Font Awesome icon" } },
                                { key: "iconColor", type: "color", label: { fr: "Couleur de l’icône", en: "Icon color" } },
                                { key: "showText", type: "boolean", label: { fr: "Afficher le texte du bouton", en: "Show button text" } },
                                { key: "buttonTextFr", type: "text", label: { fr: "Texte du bouton — français", en: "Button text — French" } },
                                { key: "buttonTextEn", type: "text", label: { fr: "Texte du bouton — anglais", en: "Button text — English" } },
                                { key: "textColor", type: "color", label: { fr: "Couleur du texte", en: "Text color" } },
                                { key: "fontSizePx", type: "number", min: 8, max: 40, label: { fr: "Taille du texte (px)", en: "Text size (px)" } },
                                { key: "titleFr", type: "text", label: { fr: "Infobulle — français", en: "Tooltip — French" } },
                                { key: "titleEn", type: "text", label: { fr: "Infobulle — anglais", en: "Tooltip — English" } },
                                {
                                    key: "buttonContainerSelector",
                                    type: "elementPicker",
                                    advanced: true,
                                    label: { fr: "Conteneur du bouton (optionnel)", en: "Button container (optional)" },
                                    pickLabel: { fr: "Choisir un emplacement", en: "Choose a location" },
                                    emptyLabel: { fr: "Automatique : barre DataTables", en: "Automatic: DataTables toolbar" },
                                    allowManual: true,
                                    pick: pickForTableRule,
                                    onPick: applyTablePickerResult
                                },
                                {
                                    key: "buttonPosition",
                                    type: "select",
                                    advanced: true,
                                    label: { fr: "Position dans le conteneur", en: "Position in container" },
                                    options: [
                                        { value: "append", label: { fr: "À la fin", en: "At the end" } },
                                        { value: "prepend", label: { fr: "Au début", en: "At the beginning" } }
                                    ]
                                },
                                { key: "buttonExtraClass", type: "text", advanced: true, label: { fr: "Classes CSS supplémentaires", en: "Additional CSS classes" } },
                                { key: "feedbackEnabled", type: "boolean", label: { fr: "Afficher un retour après la copie", en: "Show feedback after copy" } },
                                { key: "feedbackSuccessTextFr", type: "text", label: { fr: "Message succès — français", en: "Success message — French" } },
                                { key: "feedbackSuccessTextEn", type: "text", label: { fr: "Message succès — anglais", en: "Success message — English" } },
                                { key: "feedbackEmptyTextFr", type: "text", label: { fr: "Message si aucune valeur — français", en: "Empty message — French" } },
                                { key: "feedbackEmptyTextEn", type: "text", label: { fr: "Message si aucune valeur — anglais", en: "Empty message — English" } },
                                { key: "feedbackErrorTextFr", type: "text", label: { fr: "Message erreur — français", en: "Error message — French" } },
                                { key: "feedbackErrorTextEn", type: "text", label: { fr: "Message erreur — anglais", en: "Error message — English" } },
                                { key: "feedbackDurationMs", type: "number", min: 300, max: 10000, step: 100, label: { fr: "Durée du message (ms)", en: "Message duration (ms)" } },
                                { key: "excludeSelector", type: "text", advanced: true, label: { fr: "Sous-éléments à exclure", en: "Child elements to exclude" } },
                                { key: "trim", type: "boolean", advanced: true, label: { fr: "Supprimer les espaces début/fin", en: "Trim leading/trailing spaces" } },
                                { key: "extractRegex", type: "text", advanced: true, label: { fr: "Extraire avec une RegExp", en: "Extract with RegExp" } },
                                { key: "regexFlags", type: "text", advanced: true, label: { fr: "Options RegExp", en: "RegExp flags" } },
                                { key: "regexGroup", type: "number", advanced: true, label: { fr: "Groupe RegExp utilisé", en: "RegExp group" } },
                                { key: "tableMatchCount", type: "readonly", advanced: true, label: { fr: "Tableaux trouvés lors du pick", en: "Tables found when picked" } },
                                { key: "sourceMatchCount", type: "readonly", advanced: true, label: { fr: "Valeurs trouvées lors du pick", en: "Values found when picked" } },
                                { key: "exampleValue", type: "readonly", advanced: true, label: { fr: "Exemple détecté", en: "Detected example" } },
                                { key: "id", type: "readonly", advanced: true, label: { fr: "Identifiant technique", en: "Technical identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "advanced",
                    label: { fr: "Chargement dynamique", en: "Dynamic loading" },
                    fields: [
                        { key: "observeDom", type: "boolean", advanced: true, label: { fr: "Retraiter les éléments ajoutés après chargement", en: "Process elements added after page load" } },
                        { key: "observeDelay", type: "number", advanced: true, label: { fr: "Délai de retraitement (ms)", en: "Reprocessing delay (ms)" } }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId === "tableRules" ? "tableRules" : "rules";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') ||
                    main.querySelector('[data-pmk-section-id="rules"]');
                if (section) window.setTimeout(function () { section.scrollIntoView({ block: "start", behavior: "smooth" }); }, 0);
            }
        };
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;

        const active = currentConfig.rules.find(ruleApplies);
        const tableActive = currentConfig.tableRules.find(tableRuleApplies);
        let anchor = null;
        let sectionId = "rules";

        if (active) {
            const preferredSelector = active.actionMode === "existing-trigger" && active.triggerSelector
                ? active.triggerSelector
                : active.selector;
            try { anchor = document.querySelector(preferredSelector) || document.querySelector(active.selector); } catch (_) {}
        }

        if (!anchor && tableActive) {
            sectionId = "tableRules";
            try {
                anchor = document.querySelector(tableButtonSelector(tableActive)) ||
                    document.querySelector(tableActive.tableSelector);
            } catch (_) {}
        }

        anchor = anchor || document.querySelector("h1") || document.querySelector("#breadcrumbs");
        if (!anchor || (!active && !tableActive)) return;

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: anchor,
            position: "after",
            contextKey: "copy-actions-" + normalizePath(window.location.pathname),
            context: { sectionId: sectionId, pagePath: window.location.pathname }
        });
    }

    async function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return clone(DEFAULT_CONFIG);
        try { return await window.PMKConfig.getConfig(MODULE_ID); } catch (_) { return clone(DEFAULT_CONFIG); }
    }

    async function startWithCore() {
        if (!window.PMKConfig) return;
        registerPickerAdapter();
        registerVisualEditorAdapter();
        if (!registered && typeof window.PMKConfig.registerModule === "function") {
            window.PMKConfig.registerModule(moduleDefinition());
            registered = true;
        }
        const config = normalizeConfig(await loadConfig());
        applyAll(config);
        startObserver(config);
        mountContextAccess();
        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (next) {
                const normalized = normalizeConfig(next);
                applyAll(normalized);
                startObserver(normalized);
                mountContextAccess();
            });
        }
    }

    function startWithoutCore() {
        const config = normalizeConfig(DEFAULT_CONFIG);
        applyAll(config);
        startObserver(config);
    }

    window.PMK006CopyActions = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        normalizeConfig: normalizeConfig,
        moduleDefinition: moduleDefinition,
        apply: applyAll,
        pickElement: fallbackPicker
    };

    function boot() {
        if (window.PMKConfig) startWithCore();
        else {
            startWithoutCore();
            window.addEventListener("pmk:config-ready", startWithCore, { once: true });
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true });
    else boot();
})();

;window.PMKNonPlugin.loaded.push("006-copy-patron-identifiers.js");
} catch (error) { window.PMKNonPlugin.errors.push("006-copy-patron-identifiers.js: "+error.message); console.error("[PMK] 006-copy-patron-identifiers.js",error); };
try {
/* ============================================================
   007-highlight-readingrec.js
   Module fonctionnel : Repères de l’historique des prêts
   Identifiant        : history-row-highlights
   Phase              : script isolé préparatoire à PimpMyKoha
   Version            : 2.5.0
   Date               : 2026-09-17

   Fonction :
   - enrichit les historiques de circulation d'un lecteur et d'une notice sans modifier les données ;
   - calcule les durées à partir des dates techniques Koha ;
   - indique la durée d'un prêt rendu, la durée d'un prêt en cours et son retard ;
   - conserve la mise en couleur historique du script 007 d'origine :
     vert clair pour un prêt normal, rouge clair pour un prêt en retard ;
   - conserve l'icône livre sur les prêts encore en cours ;
   - peut également signaler un retour tardif ou une incohérence chronologique ;
   - fournit des libellés français et anglais entièrement modifiables ;
   - permet de personnaliser visuellement les couleurs de fond et de l'icône ;
   - conserve une détection de colonnes en français et en anglais ;
   - possède des adaptateurs Koha distincts pour readingrec.pl et issuehistory.pl ;
   - utilise les fallbacks historiques 8/11/12 sur readingrec.pl et 5/6/7 sur issuehistory.pl ;
   - conserve la compatibilité avec les anciennes configurations Firestore du 007 ;
   - réagit proprement aux redraws DataTables ;
   - fonctionne en français et en anglais ;
   - n'impose aucun tri et n'ajoute aucune colonne ;
   - s'enregistre dans l'administration PMK sur toutes les pages Koha ;
   - utilise la configuration commune window.PMKConfig lorsqu'elle est disponible ;
   - fonctionne avec ses valeurs par défaut si le socle n'est pas chargé.

   Fail-safe :
   - hors pages readingrec.pl et issuehistory.pl : retour immédiat ;
   - table ou colonnes non identifiées avec une confiance suffisante : aucune modification ;
   - date invalide : aucune règle dépendante de cette date n'est appliquée.
   ============================================================ */

(function () {
    "use strict";

    const GLOBAL_GUARD = "__PMK_007_HISTORY_ROW_HIGHLIGHTS__";
    const MODULE_ID = "history-row-highlights";
    const MODULE_VERSION = "2.5.0";
    const STYLE_ID = "pmk-007-history-row-highlights-style";

    const PAGES = {
        "members.readingrec": {
            id: "members.readingrec",
            path: "/cgi-bin/koha/members/readingrec.pl",
            tableId: "table_readingrec",
            labelFr: "Historique d'un lecteur",
            labelEn: "Patron circulation history",
            fallback: { checkout: 8, due: 11, returned: 12 },
            headingSelectors: ["body#pat_readingrec h1", "main h1", "h1"]
        },
        "catalogue.issuehistory": {
            id: "catalogue.issuehistory",
            path: "/cgi-bin/koha/catalogue/issuehistory.pl",
            tableId: "table_issues",
            labelFr: "Historique des prêts d'une notice",
            labelEn: "Bibliographic record loan history",
            fallback: { checkout: 5, due: 6, returned: 7 },
            headingSelectors: ["body#catalog_issuehistory h1", "main h1", "h1"]
        }
    };
    const CONTAINER_CLASS = "pmk-history-indicators";
    const INDICATOR_CLASS = "pmk-history-indicator";
    const CURRENT_ICON_CLASS = "pmk-history-current-icon";
    const BG_OK_CLASS = "pmk-history-bg-ok";
    const BG_DANGER_CLASS = "pmk-history-bg-danger";
    const LEGEND_CLASS = "pmk-history-legend";

    if (window[GLOBAL_GUARD]) return;

    window[GLOBAL_GUARD] = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        initialized: false,
        table: null,
        unsubscribe: null
    };

    const RULES = {
        "loan-duration-returned": {
            tone: "neutral",
            labelFr: "Durée du prêt : {days}",
            labelEn: "Loan duration: {days}"
        },
        "loan-duration-current": {
            tone: "neutral",
            labelFr: "Durée du prêt : {days}",
            labelEn: "Loan duration: {days}"
        },
        "overdue-current": {
            tone: "danger",
            labelFr: "Retard : {days}",
            labelEn: "Overdue: {days}"
        },
        "returned-late": {
            tone: "warning",
            labelFr: "Retour après échéance : {days}",
            labelEn: "Returned after due date: {days}"
        },
        "return-before-checkout": {
            tone: "danger",
            labelFr: "Incohérence : retour antérieur à l'emprunt",
            labelEn: "Inconsistency: return date precedes checkout"
        }
    };

    const DEFAULT_CONFIG = {
        enabled: true,

        /*
         * Réglages métier exposés dans l'administration PMK.
         * La structure pages/indicators reste interne pour préserver la
         * compatibilité avec les versions préparatoires précédentes.
         */
        language: "auto",
        highlightBackground: true,
        showLegend: true,
        normalBackgroundColor: "#d4f8d4",
        overdueBackgroundColor: "#f8d4d4",
        currentLoanIconColor: "#4caf50",

        enableReadingrec: true,
        enableIssuehistory: true,

        returnedDurationLabelFr: RULES["loan-duration-returned"].labelFr,
        returnedDurationLabelEn: RULES["loan-duration-returned"].labelEn,
        currentDurationLabelFr: RULES["loan-duration-current"].labelFr,
        currentDurationLabelEn: RULES["loan-duration-current"].labelEn,
        currentOverdueLabelFr: RULES["overdue-current"].labelFr,
        currentOverdueLabelEn: RULES["overdue-current"].labelEn,
        returnedLateLabelFr: RULES["returned-late"].labelFr,
        returnedLateLabelEn: RULES["returned-late"].labelEn,
        chronologyWarningLabelFr: RULES["return-before-checkout"].labelFr,
        chronologyWarningLabelEn: RULES["return-before-checkout"].labelEn,

        showReturnedDuration: true,
        showCurrentDuration: true,
        showCurrentOverdue: true,
        showReturnedLate: true,
        showChronologyWarning: true,

        pages: [
            {
                id: "members.readingrec",
                enabled: true,
                path: "/cgi-bin/koha/members/readingrec.pl",
                labelFr: "Historique d'un lecteur",
                labelEn: "Patron circulation history",
                indicators: [
                    { id: "loan-duration-returned", enabled: true, labelFr: RULES["loan-duration-returned"].labelFr, labelEn: RULES["loan-duration-returned"].labelEn },
                    { id: "loan-duration-current", enabled: true, labelFr: RULES["loan-duration-current"].labelFr, labelEn: RULES["loan-duration-current"].labelEn },
                    { id: "overdue-current", enabled: true, labelFr: RULES["overdue-current"].labelFr, labelEn: RULES["overdue-current"].labelEn },
                    { id: "returned-late", enabled: true, labelFr: RULES["returned-late"].labelFr, labelEn: RULES["returned-late"].labelEn },
                    { id: "return-before-checkout", enabled: true, labelFr: RULES["return-before-checkout"].labelFr, labelEn: RULES["return-before-checkout"].labelEn }
                ]
            },
            {
                id: "catalogue.issuehistory",
                enabled: true,
                path: "/cgi-bin/koha/catalogue/issuehistory.pl",
                labelFr: "Historique des prêts d'une notice",
                labelEn: "Bibliographic record loan history",
                indicators: [
                    { id: "loan-duration-returned", enabled: true, labelFr: RULES["loan-duration-returned"].labelFr, labelEn: RULES["loan-duration-returned"].labelEn },
                    { id: "loan-duration-current", enabled: true, labelFr: RULES["loan-duration-current"].labelFr, labelEn: RULES["loan-duration-current"].labelEn },
                    { id: "overdue-current", enabled: true, labelFr: RULES["overdue-current"].labelFr, labelEn: RULES["overdue-current"].labelEn },
                    { id: "returned-late", enabled: true, labelFr: RULES["returned-late"].labelFr, labelEn: RULES["returned-late"].labelEn },
                    { id: "return-before-checkout", enabled: true, labelFr: RULES["return-before-checkout"].labelFr, labelEn: RULES["return-before-checkout"].labelEn }
                ]
            }
        ]
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let currentPageConfig = null;
    let currentPage = null;
    let coreRegistered = false;
    let coreStarted = false;
    let fallbackStarted = false;
    let tableState = null;
    let unsubscribeConfig = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function detectLanguage() {
        const configured =
            currentConfig &&
            typeof currentConfig.language === "string"
                ? currentConfig.language.toLowerCase()
                : "auto";

        if (configured === "fr" || configured === "en") {
            return configured;
        }

        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            const coreLanguage = String(window.PMKConfig.getLanguage() || "").toLowerCase();
            if (coreLanguage.startsWith("fr")) return "fr";
            if (coreLanguage.startsWith("en")) return "en";
        }

        const lang = (
            document.documentElement.getAttribute("lang") ||
            navigator.language ||
            ""
        ).toLowerCase();

        return lang.startsWith("fr") ? "fr" : "en";
    }

    function normalizeText(value) {
        return String(value === undefined || value === null ? "" : value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\u00a0/g, " ")
            .replace(/[^a-zA-Z0-9]+/g, " ")
            .trim()
            .toLowerCase();
    }

    function detectCurrentPage() {
        const path = window.location.pathname;
        const configured=(currentConfig?.pages || []).find(page=>page.path===path);
        return configured ? Object.assign({},PAGES[configured.id] || {},configured) : null;
    }

    function isTargetPage() {
        return !!detectCurrentPage();
    }

    function getPageConfig(config) {
        if (!config || config.enabled === false || !Array.isArray(config.pages)) return null;
        const page = currentPage || detectCurrentPage();
        if (!page) return null;

        const pageConfig = config.pages.find(function (item) {
            return item && item.id === page.id;
        });
        const switchKey=page.id==='members.readingrec'?'enableReadingrec':'enableIssuehistory';
        if (!pageConfig || config[switchKey]===false) return null;
        return pageConfig;
    }

    function normalizeConfig(config) {
        const incoming = config && typeof config === "object" ? config : {};
        const result = clone(DEFAULT_CONFIG);

        if (incoming.enabled === false) result.enabled = false;

        if (["auto", "fr", "en"].includes(String(incoming.language || "").toLowerCase())) {
            result.language = String(incoming.language).toLowerCase();
        }

        result.highlightBackground = incoming.highlightBackground !== false;
        result.showLegend = incoming.showLegend !== false;

        const normalizeHexColor = function (value, fallback) {
            const candidate = String(value || "").trim().toLowerCase();
            return /^#[0-9a-f]{6}$/i.test(candidate) ? candidate : fallback;
        };

        result.normalBackgroundColor = normalizeHexColor(
            incoming.normalBackgroundColor,
            DEFAULT_CONFIG.normalBackgroundColor
        );
        result.overdueBackgroundColor = normalizeHexColor(
            incoming.overdueBackgroundColor,
            DEFAULT_CONFIG.overdueBackgroundColor
        );
        result.currentLoanIconColor = normalizeHexColor(
            incoming.currentLoanIconColor,
            DEFAULT_CONFIG.currentLoanIconColor
        );

        result.enableReadingrec = incoming.enableReadingrec !== false;
        result.enableIssuehistory = incoming.enableIssuehistory !== false;

        const incomingPages = Array.isArray(incoming.pages) ? incoming.pages : [];
        result.migrations=Object.assign({},incoming.migrations || {},{historyActivationUnified:1});

        result.pages.forEach(function (page) {
            const sourcePage = incomingPages.find(function (candidate) {
                return candidate && candidate.id === page.id;
            });

            const switchKey=page.id==='members.readingrec'?'enableReadingrec':'enableIssuehistory';
            if(incoming.migrations?.historyActivationUnified!==1 && sourcePage?.enabled===false)result[switchKey]=false;
            page.enabled=true;

            const native=PAGES[page.id];
            page.tableSelector=sourcePage?.tableSelector || '#'+native.tableId;
            page.columnSelectors=Object.assign({checkout:'',due:'',returned:''},sourcePage?.columnSelectors || {});
            page.fallback=Object.assign({},native.fallback,sourcePage?.fallback || {});
            if (sourcePage) {
                if(typeof sourcePage.path==='string' && sourcePage.path.trim())page.path=sourcePage.path.trim();
                if (typeof sourcePage.labelFr === "string" && sourcePage.labelFr.trim()) {
                    page.labelFr = sourcePage.labelFr.trim();
                }
                if (typeof sourcePage.labelEn === "string" && sourcePage.labelEn.trim()) {
                    page.labelEn = sourcePage.labelEn.trim();
                }

                if (Array.isArray(sourcePage.indicators)) {
                    const savedById = new Map();
                    sourcePage.indicators.forEach(function (rule) {
                        if (rule && RULES[rule.id]) savedById.set(rule.id, rule);
                    });

                    page.indicators = page.indicators.map(function (defaultRule) {
                        const saved = savedById.get(defaultRule.id);
                        if (!saved) return defaultRule;
                        const base = RULES[defaultRule.id];
                        return {
                            id: defaultRule.id,
                            enabled: saved.enabled !== false,
                            labelFr: typeof saved.labelFr === "string" && saved.labelFr.trim()
                                ? saved.labelFr.trim()
                                : base.labelFr,
                            labelEn: typeof saved.labelEn === "string" && saved.labelEn.trim()
                                ? saved.labelEn.trim()
                                : base.labelEn
                        };
                    });
                }
            }
        });

        const directSettings = [
            ["showReturnedDuration", "loan-duration-returned"],
            ["showCurrentDuration", "loan-duration-current"],
            ["showCurrentOverdue", "overdue-current"],
            ["showReturnedLate", "returned-late"],
            ["showChronologyWarning", "return-before-checkout"]
        ];

        directSettings.forEach(function (entry) {
            const settingKey = entry[0];
            const ruleId = entry[1];

            let enabled = DEFAULT_CONFIG[settingKey] !== false;
            if (Object.prototype.hasOwnProperty.call(incoming, settingKey)) {
                enabled = incoming[settingKey] !== false;
            }
            result[settingKey] = enabled;

            result.pages.forEach(function (page) {
                const rule = page.indicators.find(function (candidate) {
                    return candidate.id === ruleId;
                });
                if (rule) rule.enabled = enabled;
            });
        });

        const labelSettings = [
            ["returnedDurationLabelFr", "loan-duration-returned", "labelFr"],
            ["returnedDurationLabelEn", "loan-duration-returned", "labelEn"],
            ["currentDurationLabelFr", "loan-duration-current", "labelFr"],
            ["currentDurationLabelEn", "loan-duration-current", "labelEn"],
            ["currentOverdueLabelFr", "overdue-current", "labelFr"],
            ["currentOverdueLabelEn", "overdue-current", "labelEn"],
            ["returnedLateLabelFr", "returned-late", "labelFr"],
            ["returnedLateLabelEn", "returned-late", "labelEn"],
            ["chronologyWarningLabelFr", "return-before-checkout", "labelFr"],
            ["chronologyWarningLabelEn", "return-before-checkout", "labelEn"]
        ];

        labelSettings.forEach(function (entry) {
            const settingKey = entry[0];
            const ruleId = entry[1];
            const property = entry[2];
            const incomingValue = Object.prototype.hasOwnProperty.call(incoming, settingKey)
                ? String(incoming[settingKey] || "").trim()
                : "";

            const value = incomingValue || RULES[ruleId][property];
            result[settingKey] = value;

            result.pages.forEach(function (page) {
                const rule = page.indicators.find(function (candidate) {
                    return candidate.id === ruleId;
                });
                if (rule) rule[property] = value;
            });
        });

        return result;
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk-history-table .${CONTAINER_CLASS} {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: .25rem .35rem;
                margin-top: .25rem;
                max-width: 100%;
            }
            .pmk-history-table .${INDICATOR_CLASS} {
                max-width: 100%;
                white-space: normal;
                overflow-wrap: anywhere;
                line-height: 1.25;
            }
            .pmk-history-table .${INDICATOR_CLASS}.pmk-history-neutral {
                display: block;
                color: var(--bs-secondary-color, #6c757d);
                font-size: .88em;
            }
            .pmk-history-table .${INDICATOR_CLASS}.badge {
                font-size: .78em;
                font-weight: 600;
            }
            .pmk-history-table td.${BG_OK_CLASS} {
                background-color: var(--pmk-history-normal-bg, #d4f8d4) !important;
                transition: background-color .3s ease;
            }
            .pmk-history-table td.${BG_DANGER_CLASS} {
                background-color: var(--pmk-history-overdue-bg, #f8d4d4) !important;
                transition: background-color .3s ease;
            }
            .pmk-history-table .${CURRENT_ICON_CLASS} {
                margin-left: .5em;
                color: var(--pmk-history-current-icon, #4caf50) !important;
            }
            .${LEGEND_CLASS} {
                margin: .5rem 0 1rem;
                padding: .45rem .65rem;
                border: 1px solid var(--bs-border-color, #dee2e6);
                border-radius: .3rem;
                background: var(--bs-body-bg, #fff);
                font-size: .9rem;
            }
            .${LEGEND_CLASS} summary { cursor: pointer; font-weight: 600; }
            .${LEGEND_CLASS} ul { margin: .45rem 0 0; padding-left: 1.3rem; }
            @media (max-width: 768px) {
                .pmk-history-table .${CONTAINER_CLASS} {
                    align-items: flex-start;
                    flex-direction: column;
                    gap: .2rem;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function parseTechnicalDate(value) {
        const text = String(value || "").trim();
        if (!text || normalizeText(text) === "checked out") return null;

        let match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
        if (match) {
            const date = new Date(
                Number(match[1]),
                Number(match[2]) - 1,
                Number(match[3]),
                Number(match[4] || 0),
                Number(match[5] || 0),
                Number(match[6] || 0)
            );
            return Number.isNaN(date.getTime()) ? null : date;
        }

        const parsed = new Date(text);
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    }

    function parseVisibleDate(value) {
        const text = String(value || "").replace(/\u00a0/g, " ").trim();
        if (!text) return null;

        const lang = detectLanguage();
        const numeric = text.match(/\b(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
        if (!numeric) return null;

        const a = Number(numeric[1]);
        const b = Number(numeric[2]);
        const year = Number(numeric[3]);

        /*
         * Si une composante dépasse 12, le sens est non ambigu.
         * Sinon on suit la langue d'interface (FR = JJ/MM, EN = MM/JJ).
         */
        let day;
        let month;
        if (a > 12 && b <= 12) {
            day = a;
            month = b;
        } else if (b > 12 && a <= 12) {
            day = b;
            month = a;
        } else {
            day = lang === "fr" ? a : b;
            month = lang === "fr" ? b : a;
        }

        const date = new Date(
            year,
            month - 1,
            day,
            Number(numeric[4] || 0),
            Number(numeric[5] || 0),
            Number(numeric[6] || 0)
        );
        return Number.isNaN(date.getTime()) ? null : date;
    }

    function parseCellDate(cell) {
        if (!cell) return null;
        const order = cell.getAttribute("data-order");
        return parseTechnicalDate(order) || parseVisibleDate(cell.textContent || "");
    }

    function toUtcDay(date) {
        return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
    }

    function daysBetween(startDate, endDate) {
        if (!(startDate instanceof Date) || !(endDate instanceof Date)) return null;
        if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) return null;
        return Math.floor((toUtcDay(endDate) - toUtcDay(startDate)) / 86400000);
    }

    function headerLabel(th) {
        if (!th) return "";
        const cloneNode = th.cloneNode(true);
        cloneNode.querySelectorAll(".dt-column-order, .DataTables_sort_icon, .sorting_1").forEach(function (node) {
            node.remove();
        });
        return normalizeText(cloneNode.textContent || th.getAttribute("aria-label") || "");
    }

    const COLUMN_ALIASES = {
        checkout: [
            "prete le",
            "date de pret",
            "date d emprunt",
            "emprunte le",
            "emprunt",
            "checked out on",
            "checked out",
            "checkout on",
            "checkout date",
            "loan date"
        ],
        due: [
            "retour prevu",
            "date de retour prevue",
            "date d echeance",
            "echeance",
            "date due",
            "due date"
        ],
        returned: [
            "rendu le",
            "date de retour effective",
            "retour effectif",
            "return date",
            "returned on",
            "checked in on",
            "checkin on",
            "check in on",
            "checkin date",
            "check in date"
        ]
    };

    function matchesAlias(label, aliases) {
        return aliases.some(function (alias) {
            return label === alias || label.includes(alias);
        });
    }

    function resolveColumns(table) {
        const headers = Array.from(table.querySelectorAll("thead th"));
        if (!headers.length) return null;

        const labels = headers.map(headerLabel);

        const findAll = function (kind) {
            const indexes = [];
            labels.forEach(function (label, index) {
                if (matchesAlias(label, COLUMN_ALIASES[kind])) indexes.push(index);
            });
            return indexes;
        };

        const chooseUnique = function (kind) {
            const selector=currentPageConfig?.columnSelectors?.[kind];
            if(selector) {try {return headers.findIndex(header=>header.matches(selector))} catch(_){return -1}}
            const indexes = findAll(kind);
            return indexes.length === 1 ? indexes[0] : -1;
        };

        let checkout = chooseUnique("checkout");
        let due = chooseUnique("due");
        let returned = chooseUnique("returned");

        if(['checkout','due','returned'].some(kind=>currentPageConfig?.columnSelectors?.[kind] && chooseUnique(kind)<0))return null;
        const fallback = currentPage && currentPage.fallback
            ? currentPage.fallback
            : null;

        if (fallback) {
            if (checkout < 0 && headers.length > fallback.checkout) checkout = fallback.checkout;
            if (due < 0 && headers.length > fallback.due) due = fallback.due;
            if (returned < 0 && headers.length > fallback.returned) returned = fallback.returned;
        }

        if (checkout < 0 || due < 0 || returned < 0) return null;
        if (checkout === due || checkout === returned || due === returned) return null;

        return {
            checkout: checkout,
            due: due,
            returned: returned
        };
    }

    function isStillCheckedOut(returnCell) {
        if (!returnCell) return false;

        const order = normalizeText(returnCell.getAttribute("data-order"));
        const visible = normalizeText(returnCell.textContent || "");

        const states = [
            "checked out",
            "on loan",
            "prete",
            "en pret",
            "emprunte"
        ];

        if (states.some(function (state) {
            return order === state || order.includes(state);
        })) {
            return true;
        }

        if (states.some(function (state) {
            return visible === state || visible.includes(state);
        })) {
            return true;
        }

        if (returnCell.querySelector(".checked-out-badge, .onloan, .on-loan")) {
            return true;
        }

        return false;
    }

    function getEnabledRules(pageConfig) {
        if (!pageConfig || !Array.isArray(pageConfig.indicators)) return [];
        return pageConfig.indicators.filter(function (rule) {
            return rule && rule.enabled !== false && RULES[rule.id];
        });
    }

    function formattedDays(count) {
        const value = Math.abs(Number(count));
        if (!Number.isFinite(value)) return "";
        const lang = detectLanguage();
        if (lang === "fr") return value + (value === 1 ? " jour" : " jours");
        return value + (value === 1 ? " day" : " days");
    }

    function renderTemplate(template, values) {
        return String(template || "").replace(/\{([a-z]+)\}/gi, function (_match, key) {
            return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : "";
        });
    }

    function createIndicator(rule, days) {
        const def = RULES[rule.id];
        if (!def) return null;

        const lang = detectLanguage();
        const template = lang === "fr" ? rule.labelFr : rule.labelEn;
        const text = renderTemplate(template || (lang === "fr" ? def.labelFr : def.labelEn), {
            days: days === null || days === undefined ? "" : formattedDays(days)
        }).trim();
        if (!text) return null;

        const element = document.createElement(def.tone === "neutral" ? "small" : "span");
        element.className = INDICATOR_CLASS;
        element.textContent = text;
        element.dataset.pmkHistoryRule = rule.id;
        element.title = (lang === "fr" ? "Règle appliquée : " : "Applied rule: ") + rule.id;

        if (def.tone === "neutral") {
            element.classList.add("pmk-history-neutral");
        } else if (def.tone === "danger") {
            element.classList.add("badge", "bg-danger");
        } else if (def.tone === "warning") {
            element.classList.add("badge", "bg-warning", "text-dark");
        }

        return element;
    }

    function clearRow(row) {
        if (!row) return;

        row.querySelectorAll("." + CONTAINER_CLASS).forEach(function (node) {
            node.remove();
        });

        row.querySelectorAll("." + CURRENT_ICON_CLASS).forEach(function (node) {
            node.remove();
        });

        /*
         * Compatibilité avec le 007 historique : évite doublons d'icône et de
         * texte si une ancienne version a déjà touché le tableau.
         */
        row.querySelectorAll(".readingrec-note, .readingrec-book-icon").forEach(function (node) {
            node.remove();
        });

        row.querySelectorAll("." + BG_OK_CLASS + ", ." + BG_DANGER_CLASS).forEach(function (cell) {
            cell.classList.remove(BG_OK_CLASS, BG_DANGER_CLASS);
            cell.style.removeProperty("background-color");
        });
        row.removeAttribute("data-pmk-history-rules");
    }

    function addCurrentLoanIcon(returnCell) {
        if (!returnCell || returnCell.querySelector("." + CURRENT_ICON_CLASS)) return;

        const icon = document.createElement("i");
        icon.className = "fa-solid fa-book " + CURRENT_ICON_CLASS;
        icon.setAttribute("aria-hidden", "true");
        icon.title = detectLanguage() === "fr"
            ? "Prêt en cours"
            : "Currently checked out";
        returnCell.appendChild(icon);
    }

    function applyCellBackground(returnCell, cssClass, color) {
        if (!returnCell) return;
        returnCell.classList.remove(BG_OK_CLASS, BG_DANGER_CLASS);
        returnCell.classList.add(cssClass);

        /*
         * L'inline reprend le comportement du script 007 historique et garantit
         * que la couleur reste visible face aux styles DataTables/Koha.
         */
        if (color) {
            returnCell.style.setProperty("background-color", color, "important");
        }
    }

    function applyHistoricalBackground(returnCell, checkoutDate, dueDate, returnedDate, current) {
        if (!returnCell) return;

        returnCell.style.removeProperty("background-color");

        if (currentConfig.highlightBackground === false) return;

        const today = new Date();
        const okColor = currentConfig.normalBackgroundColor || DEFAULT_CONFIG.normalBackgroundColor;
        const dangerColor = currentConfig.overdueBackgroundColor || DEFAULT_CONFIG.overdueBackgroundColor;

        if (returnedDate) {
            const chronology = daysBetween(checkoutDate, returnedDate);

            if (chronology !== null && chronology < 0) {
                applyCellBackground(returnCell, BG_DANGER_CLASS, dangerColor);
                return;
            }

            /*
             * Comportement historique : un prêt rendu reçoit le fond vert de
             * durée, y compris s'il a été rendu après l'échéance.
             */
            applyCellBackground(returnCell, BG_OK_CLASS, okColor);
            return;
        }

        if (current) {
            const late = daysBetween(dueDate, today);
            if (late !== null && late > 0) {
                applyCellBackground(returnCell, BG_DANGER_CLASS, dangerColor);
            } else {
                applyCellBackground(returnCell, BG_OK_CLASS, okColor);
            }
        }
    }

    function appendRule(container, rule, days) {
        const element = createIndicator(rule, days);
        if (element) container.appendChild(element);
        return Boolean(element);
    }

    function processRow(row, columns, rules) {
        if (!row || row.classList.contains("child")) return;
        const cells = row.querySelectorAll(":scope > td");
        if (!cells.length) return;

        const maxIndex = Math.max(columns.checkout, columns.due, columns.returned);
        if (cells.length <= maxIndex) return;

        clearRow(row);

        const checkoutCell = cells[columns.checkout];
        const dueCell = cells[columns.due];
        const returnCell = cells[columns.returned];

        const checkoutDate = parseCellDate(checkoutCell);
        const dueDate = parseCellDate(dueCell);
        const returnedDate = parseCellDate(returnCell);
        const current = isStillCheckedOut(returnCell) && !returnedDate;

        if (!checkoutDate || !dueDate) return;
        if (!current && !returnedDate) return;

        if (current) {
            addCurrentLoanIcon(returnCell);
        }

        applyHistoricalBackground(
            returnCell,
            checkoutDate,
            dueDate,
            returnedDate,
            current
        );

        const byId = new Map(rules.map(function (rule) { return [rule.id, rule]; }));
        const container = document.createElement("div");
        container.className = CONTAINER_CLASS;
        const triggered = [];

        rules.forEach(function (rule) {
            if (rule.id === "return-before-checkout") {
                if (!returnedDate) return;
                const duration = daysBetween(checkoutDate, returnedDate);
                if (duration !== null && duration < 0 && appendRule(container, rule, null)) triggered.push(rule.id);
                return;
            }

            if (rule.id === "loan-duration-returned") {
                if (!returnedDate) return;
                const duration = daysBetween(checkoutDate, returnedDate);
                if (duration !== null && duration >= 0 && appendRule(container, rule, duration)) triggered.push(rule.id);
                return;
            }

            if (rule.id === "returned-late") {
                if (!returnedDate) return;
                const late = daysBetween(dueDate, returnedDate);
                if (late !== null && late > 0 && appendRule(container, rule, late)) triggered.push(rule.id);
                return;
            }

            if (rule.id === "loan-duration-current") {
                if (!current) return;
                const today = new Date();
                const late = daysBetween(dueDate, today);
                if (late !== null && late > 0 && byId.has("overdue-current") && byId.get("overdue-current").enabled !== false) {
                    return;
                }
                const duration = daysBetween(checkoutDate, today);
                if (duration !== null && duration >= 0 && appendRule(container, rule, duration)) triggered.push(rule.id);
                return;
            }

            if (rule.id === "overdue-current") {
                if (!current) return;
                const late = daysBetween(dueDate, new Date());
                if (late !== null && late > 0 && appendRule(container, rule, late)) triggered.push(rule.id);
            }
        });

        if (triggered.length) row.setAttribute("data-pmk-history-rules", triggered.join(","));
        if (container.childNodes.length) returnCell.appendChild(container);
    }

    function renderLegend(table, rules) {
        document.querySelectorAll("." + LEGEND_CLASS).forEach(function (node) { node.remove(); });
        if (!table || currentConfig.showLegend === false || !rules.length) return;
        const details = document.createElement("details");
        details.className = LEGEND_CLASS;
        const summary = document.createElement("summary");
        summary.textContent = detectLanguage() === "fr" ? "Légende des repères de prêt" : "Loan indicator legend";
        const list = document.createElement("ul");
        rules.forEach(function (rule) {
            const def = RULES[rule.id];
            const item = document.createElement("li");
            const template = detectLanguage() === "fr" ? rule.labelFr : rule.labelEn;
            item.textContent = renderTemplate(template || (detectLanguage() === "fr" ? def.labelFr : def.labelEn), {days: detectLanguage() === "fr" ? "nombre de jours" : "number of days"});
            item.dataset.pmkHistoryRule = rule.id;
            list.appendChild(item);
        });
        if (currentConfig.highlightBackground !== false) {
            const colors = document.createElement("li");
            colors.textContent = detectLanguage() === "fr"
                ? "Fond vert : prêt normal ou rendu ; fond rouge : prêt en retard ou chronologie incohérente."
                : "Green background: normal or returned loan; red background: overdue loan or inconsistent chronology.";
            list.appendChild(colors);
        }
        details.append(summary, list);
        table.insertAdjacentElement("beforebegin", details);
    }

    function processTable() {
        const state = tableState;
        if (!state || !state.table || !document.body.contains(state.table)) return;

        const columns = resolveColumns(state.table);
        if (!columns) {
            state.columns = null;
            window[GLOBAL_GUARD].runtime = {
                active: false,
                reason: "columns-not-found",
                rows: state.table.querySelectorAll("tbody tr").length
            };
            state.table.querySelectorAll("tbody tr").forEach(clearRow);
            return;
        }
        state.columns = columns;

        const rules = getEnabledRules(currentPageConfig);
        const rows = state.table.querySelectorAll("tbody tr");
        rows.forEach(function (row) {
            processRow(row, columns, rules);
        });
        renderLegend(state.table, rules);

        window[GLOBAL_GUARD].runtime = {
            active: true,
            reason: "ok",
            pageId: currentPage ? currentPage.id : null,
            columns: {
                checkout: columns.checkout,
                due: columns.due,
                returned: columns.returned
            },
            rows: rows.length,
            rules: rules.map(function (rule) { return rule.id; })
        };
    }

    function bindDataTables(table) {
        if (!window.jQuery || !window.jQuery.fn) return;
        const $table = window.jQuery(table);
        $table.off("draw.dt.pmk007");
        $table.on("draw.dt.pmk007", function () {
            window.requestAnimationFrame(processTable);
        });
    }

    function unbindDataTables() {
        if (!tableState || !tableState.table || !window.jQuery || !window.jQuery.fn) return;
        window.jQuery(tableState.table).off("draw.dt.pmk007");
    }

    function clearInjectedIndicators() {
        document.querySelectorAll("." + LEGEND_CLASS).forEach(function (node) { node.remove(); });
        const tables=new Set([tableState?.table,...Object.values(PAGES).map(page=>document.getElementById(page.tableId))]);
        tables.forEach(function (table) {
            if (!table) return;

            table.querySelectorAll("tbody tr").forEach(function (row) {
                clearRow(row);
            });

            table.classList.remove("pmk-history-table");
            table.style.removeProperty("--pmk-history-normal-bg");
            table.style.removeProperty("--pmk-history-overdue-bg");
            table.style.removeProperty("--pmk-history-current-icon");
        });
    }

    function mountContextAccess() {
        if (!currentPage || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;

        let heading = null;
        (currentPage.headingSelectors || []).some(function (selector) {
            heading = document.querySelector(selector);
            return !!heading;
        });
        if (!heading) return;

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: heading,
            position: "append",
            contextKey: currentPage.id,
            context: {
                pageId: currentPage.id,
                sectionId: "pages"
            }
        });
    }

    function setupTable(table) {
        if (!currentPage || !table) return false;

        if (tableState && tableState.table !== table) {
            unbindDataTables();
        }

        tableState = { table: table, columns: null, pageId: currentPage.id };
        window[GLOBAL_GUARD].table = table;
        window[GLOBAL_GUARD].pageId = currentPage.id;
        injectStyles();
        table.classList.add("pmk-history-table");

        table.style.setProperty(
            "--pmk-history-normal-bg",
            currentConfig.normalBackgroundColor || DEFAULT_CONFIG.normalBackgroundColor
        );
        table.style.setProperty(
            "--pmk-history-overdue-bg",
            currentConfig.overdueBackgroundColor || DEFAULT_CONFIG.overdueBackgroundColor
        );
        table.style.setProperty(
            "--pmk-history-current-icon",
            currentConfig.currentLoanIconColor || DEFAULT_CONFIG.currentLoanIconColor
        );

        bindDataTables(table);
        processTable();
        mountContextAccess();
        return true;
    }

    function configuredTable() {
        try {return document.querySelector(currentPageConfig?.tableSelector || '#'+currentPage.tableId)} catch(_){return null}
    }
    function waitForTable(timeoutMs) {
        if (!currentPage) return Promise.resolve(null);

        const existing = configuredTable();
        if (existing) return Promise.resolve(existing);

        return new Promise(function (resolve) {
            let finished = false;
            const observer = new MutationObserver(function () {
                const table = configuredTable();
                if (!table || finished) return;
                finished = true;
                observer.disconnect();
                resolve(table);
            });

            observer.observe(document.documentElement, { childList: true, subtree: true });
            window.setTimeout(function () {
                if (finished) return;
                finished = true;
                observer.disconnect();
                resolve(configuredTable());
            }, timeoutMs || 4000);
        });
    }

    async function applyConfig(config) {
        clearInjectedIndicators();
        unbindDataTables();
        currentConfig = normalizeConfig(config);
        currentPage = detectCurrentPage();
        currentPageConfig = getPageConfig(currentConfig);

        if (!currentPageConfig) {
            clearInjectedIndicators();
            unbindDataTables();
            return;
        }

        const table = await waitForTable(4000);
        if (!table) {
            clearInjectedIndicators();
            return;
        }

        setupTable(table);
    }

    function validateModuleConfig(config) {
        for(const page of config?.pages || []) {
            if(page.path && !/^\/cgi-bin\/koha\/[\w/-]+\.pl$/.test(page.path))return {ok:false,message:'Chemin de page Koha invalide.'};
            for(const selector of [page.tableSelector,...Object.values(page.columnSelectors || {})].filter(Boolean)) {
                try {document.querySelector(selector)} catch(_){return {ok:false,message:'Cible de tableau ou de colonne invalide.'}}
            }
        }
        if (!config || typeof config !== "object") {
            return {
                ok: false,
                message: detectLanguage() === "fr"
                    ? "La configuration du module est invalide."
                    : "The module configuration is invalid."
            };
        }

        if (
            Object.prototype.hasOwnProperty.call(config, "language") &&
            !["auto", "fr", "en"].includes(String(config.language || "").toLowerCase())
        ) {
            return {
                ok: false,
                message: detectLanguage() === "fr"
                    ? "La langue choisie n’est pas valide."
                    : "The selected language is invalid."
            };
        }

        const colorKeys = [
            "normalBackgroundColor",
            "overdueBackgroundColor",
            "currentLoanIconColor"
        ];

        for (const key of colorKeys) {
            if (
                Object.prototype.hasOwnProperty.call(config, key) &&
                !/^#[0-9a-f]{6}$/i.test(String(config[key] || "").trim())
            ) {
                return {
                    ok: false,
                    message: detectLanguage() === "fr"
                        ? "Une couleur doit être saisie au format #RRGGBB."
                        : "Colors must use the #RRGGBB format."
                };
            }
        }

        const labelKeys = [
            "returnedDurationLabelFr",
            "returnedDurationLabelEn",
            "currentDurationLabelFr",
            "currentDurationLabelEn",
            "currentOverdueLabelFr",
            "currentOverdueLabelEn",
            "returnedLateLabelFr",
            "returnedLateLabelEn",
            "chronologyWarningLabelFr",
            "chronologyWarningLabelEn"
        ];

        for (const key of labelKeys) {
            if (
                Object.prototype.hasOwnProperty.call(config, key) &&
                !String(config[key] || "").trim()
            ) {
                return {
                    ok: false,
                    message: detectLanguage() === "fr"
                        ? "Les libellés français et anglais ne peuvent pas être vides."
                        : "French and English labels cannot be empty."
                };
            }
        }

        return { ok: true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 5,
            name: {
                fr: "Repères de l’historique des prêts",
                en: "Loan history indicators"
            },
            description: {
                fr: "Ajoute des indicateurs de durée, de retard et de cohérence dans les historiques de prêt d’un lecteur et d’une notice.",
                en: "Adds duration, overdue and consistency indicators to patron and bibliographic-record loan histories."
            },
            category: {
                fr: "Circulation / historique",
                en: "Circulation / history"
            },
            supportedPages: ["members.readingrec", "catalogue.issuehistory"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateModuleConfig,
            schema: [
                {
                    type: "section",
                    id: "presentation",
                    label: {
                        fr: "Langue et présentation",
                        en: "Language and presentation"
                    },
                    description: {
                        fr: "Réglages généraux des indicateurs affichés dans l’historique.",
                        en: "General settings for indicators shown in the circulation history."
                    },
                    fields: [
                        {
                            key: "language",
                            type: "select",
                            label: {
                                fr: "Langue des indicateurs",
                                en: "Indicator language"
                            },
                            options: [
                                {
                                    value: "auto",
                                    label: {
                                        fr: "Automatique — suivre la langue de Koha",
                                        en: "Automatic — follow Koha language"
                                    }
                                },
                                {
                                    value: "fr",
                                    label: {
                                        fr: "Français",
                                        en: "French"
                                    }
                                },
                                {
                                    value: "en",
                                    label: {
                                        fr: "Anglais",
                                        en: "English"
                                    }
                                }
                            ]
                        },
                        {
                            key: "highlightBackground",
                            type: "boolean",
                            label: {
                                fr: "Conserver la mise en couleur historique",
                                en: "Keep the original background highlighting"
                            },
                            help: {
                                fr: "Applique une couleur de fond à la cellule de retour, comme dans le script 007 d’origine.",
                                en: "Applies a background color to the return cell, as in the original 007 script."
                            }
                        },
                        {
                            key: "showLegend",
                            type: "boolean",
                            label: {
                                fr: "Afficher la légende des règles actives",
                                en: "Show the active-rule legend"
                            }
                        },
                        {
                            key: "normalBackgroundColor",
                            type: "color",
                            label: {
                                fr: "Couleur — prêt normal",
                                en: "Color — normal loan"
                            },
                            when: function (rootObject) {
                                return rootObject.highlightBackground !== false;
                            }
                        },
                        {
                            key: "overdueBackgroundColor",
                            type: "color",
                            label: {
                                fr: "Couleur — prêt en retard",
                                en: "Color — overdue loan"
                            },
                            when: function (rootObject) {
                                return rootObject.highlightBackground !== false;
                            }
                        },
                        {
                            key: "currentLoanIconColor",
                            type: "color",
                            label: {
                                fr: "Couleur de l’icône prêt en cours",
                                en: "Current-loan icon color"
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "pages",
                    label: {
                        fr: "Pages actives",
                        en: "Active pages"
                    },
                    description: {
                        fr: "Le même module pilote les indicateurs sur les deux historiques Koha. Chaque page peut être activée indépendamment.",
                        en: "The same module controls indicators on both Koha history pages. Each page can be enabled independently."
                    },
                    fields: [
                        {
                            key: "enableReadingrec",
                            type: "boolean",
                            label: {
                                fr: "Historique d'un lecteur — members/readingrec.pl",
                                en: "Patron history — members/readingrec.pl"
                            }
                        },
                        {
                            key: "enableIssuehistory",
                            type: "boolean",
                            label: {
                                fr: "Historique des prêts d'une notice — catalogue/issuehistory.pl",
                                en: "Bibliographic record loan history — catalogue/issuehistory.pl"
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "display",
                    label: {
                        fr: "Indicateurs et libellés",
                        en: "Indicators and labels"
                    },
                    description: {
                        fr: "Chaque indicateur peut être activé séparément. Les textes français et anglais sont modifiables. Utilise {days} à l’endroit où le nombre de jours doit apparaître.",
                        en: "Each indicator can be enabled separately. French and English texts are editable. Use {days} where the day count should appear."
                    },
                    fields: [
                        {
                            type: "section",
                            id: "returned-duration",
                            label: {
                                fr: "Durée des prêts rendus",
                                en: "Duration of returned loans"
                            },
                            fields: [
                                {
                                    key: "showReturnedDuration",
                                    type: "boolean",
                                    label: { fr: "Afficher cet indicateur", en: "Show this indicator" }
                                },
                                {
                                    key: "returnedDurationLabelFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" },
                                    placeholder: { fr: "Durée du prêt : {days}", en: "Durée du prêt : {days}" }
                                },
                                {
                                    key: "returnedDurationLabelEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" },
                                    placeholder: { fr: "Loan duration: {days}", en: "Loan duration: {days}" }
                                }
                            ]
                        },
                        {
                            type: "section",
                            id: "current-duration",
                            label: {
                                fr: "Durée des prêts en cours",
                                en: "Duration of current loans"
                            },
                            fields: [
                                {
                                    key: "showCurrentDuration",
                                    type: "boolean",
                                    label: { fr: "Afficher cet indicateur", en: "Show this indicator" }
                                },
                                {
                                    key: "currentDurationLabelFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" }
                                },
                                {
                                    key: "currentDurationLabelEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" }
                                }
                            ]
                        },
                        {
                            type: "section",
                            id: "current-overdue",
                            label: {
                                fr: "Retard des prêts en cours",
                                en: "Overdue current loans"
                            },
                            fields: [
                                {
                                    key: "showCurrentOverdue",
                                    type: "boolean",
                                    label: { fr: "Afficher cet indicateur", en: "Show this indicator" }
                                },
                                {
                                    key: "currentOverdueLabelFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" }
                                },
                                {
                                    key: "currentOverdueLabelEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" }
                                }
                            ]
                        },
                        {
                            type: "section",
                            id: "returned-late",
                            label: {
                                fr: "Retour après échéance",
                                en: "Returned after due date"
                            },
                            fields: [
                                {
                                    key: "showReturnedLate",
                                    type: "boolean",
                                    label: { fr: "Afficher cet indicateur", en: "Show this indicator" }
                                },
                                {
                                    key: "returnedLateLabelFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" }
                                },
                                {
                                    key: "returnedLateLabelEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" }
                                }
                            ]
                        },
                        {
                            type: "section",
                            id: "chronology-warning",
                            label: {
                                fr: "Incohérence chronologique",
                                en: "Date inconsistency"
                            },
                            fields: [
                                {
                                    key: "showChronologyWarning",
                                    type: "boolean",
                                    label: { fr: "Afficher cet indicateur", en: "Show this indicator" }
                                },
                                {
                                    key: "chronologyWarningLabelFr",
                                    type: "text",
                                    label: { fr: "Libellé français", en: "French label" }
                                },
                                {
                                    key: "chronologyWarningLabelEn",
                                    type: "text",
                                    label: { fr: "Libellé anglais", en: "English label" }
                                }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main || !context || !PAGES[context.pageId]) return;
                const sectionId = context.sectionId || "pages";
                const section = main.querySelector('[data-pmk-section-id="' + sectionId + '"]')
                    || main.querySelector('[data-pmk-section-id="display"]');
                if (section) {
                    window.setTimeout(function () {
                        section.scrollIntoView({ block: "start", behavior: "smooth" });
                    }, 0);
                }
            }
        };
    }

    async function startWithCore() {
        if (!window.PMKConfig) return;

        /*
         * Enregistrement volontairement effectué sur TOUTES les pages Koha :
         * le module doit toujours être visible dans l'administration PMK,
         * même si son exécution fonctionnelle reste limitée à readingrec.pl et issuehistory.pl.
         */
        if (!coreRegistered) {
            window.PMKConfig.registerModule(moduleDefinition());
            coreRegistered = true;
        }

        if (coreStarted) return;
        coreStarted = true;

        try {
            const config = await window.PMKConfig.getConfig(MODULE_ID);
            await applyConfig(config);
        } catch (_) {
            await applyConfig(DEFAULT_CONFIG);
        }

        if (typeof window.PMKConfig.subscribe === "function" && !unsubscribeConfig) {
            unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
                applyConfig(newConfig);
            });
            window[GLOBAL_GUARD].unsubscribe = unsubscribeConfig;
        }

        window[GLOBAL_GUARD].initialized = true;
    }

    async function startWithoutCore() {
        if (fallbackStarted || !isTargetPage()) return;
        fallbackStarted = true;
        await applyConfig(DEFAULT_CONFIG);
        window[GLOBAL_GUARD].initialized = true;
    }

    function onDomReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else {
            callback();
        }
    }

    onDomReady(function () {
        if (window.PMKConfig) {
            startWithCore();
        } else {
            /*
             * Sans socle PMK, le comportement reste autonome sur
             * readingrec.pl et issuehistory.pl. Si le socle arrive ensuite, on enregistre alors
             * le module dans l'administration centrale.
             */
            if (isTargetPage()) {
                startWithoutCore();
            }

            window.addEventListener("pmk:config-ready", function () {
                startWithCore();
            }, { once: true });
        }
    });
})();

;window.PMKNonPlugin.loaded.push("007-highlight-readingrec.js");
} catch (error) { window.PMKNonPlugin.errors.push("007-highlight-readingrec.js: "+error.message); console.error("[PMK] 007-highlight-readingrec.js",error); };
try {
/* ============================================================
   008-issuehistory-timeline.js
   Module fonctionnel : Historique des prêts et des retours
   Identifiant PMK     : loan-history-timeline
   Phase               : script isolé préparatoire à PimpMyKoha
   Version             : 3.1.0
   Date                : 2026-09-17

   Remplace l'ancien 008 D3 et prépare la convergence fonctionnelle
   avec 128-timeline-historiques-pret.js.

   Pages prises en charge :
   - /cgi-bin/koha/catalogue/issuehistory.pl
   - /cgi-bin/koha/members/readingrec.pl

   Principes :
   - aucune dépendance D3 ou CDN ;
   - conserve les tableaux Koha comme source et vue de référence ;
   - identification des colonnes par identité/labels FR+EN, jamais par
     position seule ;
   - enrichissements API facultatifs : la timeline reste utilisable si
     l'API est indisponible ;
   - configuration unique PMK, enregistrée sur toutes les pages Koha ;
   - libellés d'interface FR/EN entièrement personnalisables ;
   - rendu responsive intégré visuellement à Koha ;
   - idempotent, DataTables-aware et fail-safe ;
   - aucune trace console en production.

   Stockage :
   - configuration : window.PMKConfig si disponible ;
   - fallback : valeurs par défaut embarquées ;
   - Firestore reste géré uniquement par le socle PMK pré-plugin.
   ============================================================ */

(function () {
    "use strict";

    const GLOBAL_GUARD = "__PMK_008_LOAN_HISTORY_TIMELINE__";
    const MODULE_ID = "loan-history-timeline";
    const MODULE_VERSION = "3.1.0";
    const STYLE_ID = "pmk-008-loan-history-timeline-style";
    const PANEL_ID_BIBLIO = "pmk-lht-biblio-timeline";
    const PANEL_ID_READER = "pmk-lht-reader-timeline";
    const RETURN_INFO_CLASS = "pmk-lht-return-library";
    const LEGACY_128_GUARD = "__kohaCirculationTimelineLoaded";

    const TRANSFER_REPORT_SQL = `SELECT
    bt.branchtransfer_id AS Transfer_ID,
    bt.itemnumber AS Item_ID,
    bt.frombranch AS From_Site,
    bt.tobranch AS To_Site,
    bt.daterequested AS Demande_le,
    bt.datesent AS Envoye_le,
    bt.datearrived AS Arrive_le,
    bt.datecancelled AS Annule_le,
    bt.reason AS Raison,
    bt.cancellation_reason AS Raison_annulation
FROM branchtransfers bt
INNER JOIN items i ON i.itemnumber = bt.itemnumber
WHERE i.biblionumber = <<Biblionumber>>
  AND bt.branchtransfer_id > <<Après ID>>
ORDER BY bt.branchtransfer_id ASC
LIMIT 500`;

    const TRANSFER_REPORT_SETUP_FR = "Pour afficher les transferts historiques : 1) ouvre Rapports > Rapports guidés dans Koha ; 2) crée un nouveau rapport SQL ; 3) colle exactement le SQL fourni ci-dessous ; 4) enregistre le rapport ; 5) relève son numéro dans Koha ; 6) saisis ce numéro dans le champ ‘ID du rapport SQL des transferts’. Ne remplace pas les paramètres <<Biblionumber>> et <<Après ID>> : le module les renseigne automatiquement.";
    const TRANSFER_REPORT_SETUP_EN = "To display historical transfers: 1) open Reports > Guided reports in Koha; 2) create a new SQL report; 3) paste the SQL shown below exactly; 4) save the report; 5) note its Koha report number; 6) enter that number in ‘Transfer SQL report ID’. Do not replace <<Biblionumber>> or <<Après ID>>: the module supplies them automatically.";

    const PAGE_DEFINITIONS = {
        "catalogue.issuehistory": {
            id: "catalogue.issuehistory",
            path: "/cgi-bin/koha/catalogue/issuehistory.pl",
            tableSelector: "#table_issues",
            kind: "biblio"
        },
        "members.readingrec": {
            id: "members.readingrec",
            path: "/cgi-bin/koha/members/readingrec.pl",
            tableSelector: "#table_readingrec",
            kind: "reader"
        }
    };

    const DEFAULT_TEXTS = {
        panelTitleBiblio: {
            fr: "Parcours des exemplaires",
            en: "Item circulation history"
        },
        panelSubtitleBiblio: {
            fr: "Prêts, retours et événements connus sur une même échelle temporelle.",
            en: "Loans, returns and known item events on a shared timeline."
        },
        panelTitleReader: {
            fr: "Parcours des prêts du lecteur",
            en: "Patron loan history"
        },
        panelSubtitleReader: {
            fr: "Une lecture chronologique des emprunts, retours et renouvellements.",
            en: "A chronological view of checkouts, returns and renewals."
        },
        hide: { fr: "Masquer", en: "Hide" },
        show: { fr: "Afficher", en: "Show" },
        filterPlaceholder: {
            fr: "Filtrer par titre, code-barres ou site…",
            en: "Filter by title, barcode or library…"
        },
        clearFilter: { fr: "Effacer", en: "Clear" },
        rangeAuto: { fr: "Auto", en: "Auto" },
        range6m: { fr: "6 mois", en: "6 months" },
        range1y: { fr: "1 an", en: "1 year" },
        range3y: { fr: "3 ans", en: "3 years" },
        rangeAll: { fr: "Tout", en: "All" },
        legendCompleted: { fr: "prêt terminé", en: "completed loan" },
        legendCurrent: { fr: "prêt en cours", en: "current loan" },
        legendCross: { fr: "retour inter-sites", en: "returned at another library" },
        legendRenewal: { fr: "renouvellement", en: "renewal" },
        legendAcquisition: { fr: "acquisition", en: "acquisition" },
        legendTransfer: { fr: "transfert", en: "transfer" },
        legendLastSeen: { fr: "dernière activité", en: "last activity" },
        axisItem: { fr: "Exemplaire", en: "Item" },
        axisDocument: { fr: "Document", en: "Document" },
        summaryItemsBiblio: { fr: "exemplaire(s)", en: "item(s)" },
        summaryLoansBiblio: { fr: "prêt(s)", en: "loan(s)" },
        summaryLoansReader: { fr: "prêt(s) dans l’historique", en: "loan(s) in history" },
        summaryItemsReader: { fr: "exemplaire(s) différent(s)", en: "distinct item(s)" },
        summaryCurrent: { fr: "prêt(s) en cours", en: "current loan(s)" },
        summaryCross: { fr: "retour(s) inter-sites", en: "cross-library return(s)" },
        statusCurrent: { fr: "Prêt en cours", en: "Current loan" },
        statusCompleted: { fr: "Prêt terminé", en: "Completed loan" },
        tooltipCheckout: { fr: "Prêt", en: "Checkout" },
        tooltipCheckoutLibrary: { fr: "Site de prêt", en: "Checkout library" },
        tooltipReturn: { fr: "Retour", en: "Check-in" },
        tooltipReturnLibrary: { fr: "Site de retour", en: "Check-in library" },
        tooltipDuration: { fr: "Durée", en: "Duration" },
        tooltipRenewals: { fr: "Renouvellement(s)", en: "Renewal(s)" },
        tooltipLastRenewed: { fr: "Dernier renouvellement", en: "Last renewal" },
        tooltipCurrentReturn: { fr: "en cours", en: "current" },
        tooltipCrossWarning: { fr: "Retour dans un autre site", en: "Returned at another library" },
        returnLibraryLabel: { fr: "Lieu de retour", en: "Check-in library" },
        acquisitionEvent: { fr: "Acquisition / entrée dans Koha", en: "Acquisition / added to Koha" },
        lastSeenEvent: { fr: "Dernière activité connue", en: "Last known activity" },
        transferRequestedEvent: { fr: "Transfert demandé", en: "Transfer requested" },
        transferSentEvent: { fr: "Transfert envoyé", en: "Transfer sent" },
        transferArrivedEvent: { fr: "Transfert arrivé", en: "Transfer arrived" },
        transferCancelledEvent: { fr: "Transfert annulé", en: "Transfer cancelled" },
        eventDate: { fr: "Date", en: "Date" },
        eventLibrary: { fr: "Site", en: "Library" },
        eventReason: { fr: "Motif", en: "Reason" },
        emptyPeriod: { fr: "Aucun prêt sur cette période.", en: "No loans in this period." },
        emptyFilter: {
            fr: "Aucun prêt ne correspond au filtre sur cette période.",
            en: "No loans match the filter in this period."
        },
        limitNote: {
            fr: "Pour préserver la lisibilité, les {limit} prêts les plus récents sont affichés ({total} au total). Le tableau Koha reste complet.",
            en: "For readability, the {limit} most recent loans are displayed ({total} total). The Koha table remains complete."
        },
        itemPrefix: { fr: "Exemplaire", en: "Item" },
        daySingular: { fr: "jour", en: "day" },
        dayPlural: { fr: "jours", en: "days" },
        legacyBlocked: {
            fr: "Une autre timeline de circulation est déjà active sur cette page.",
            en: "Another circulation timeline is already active on this page."
        }
    };

    function textDefault(key, lang) {
        const entry = DEFAULT_TEXTS[key] || {};
        return entry[lang] || entry.fr || entry.en || key;
    }

    const DEFAULT_CONFIG = {
        enabled: true,
        language: "auto",

        issuehistoryEnabled: true,
        readingrecEnabled: true,
        issuehistoryPathInfo: "/cgi-bin/koha/catalogue/issuehistory.pl",
        readingrecPathInfo: "/cgi-bin/koha/members/readingrec.pl",

        defaultRange: "auto",
        maxReaderRows: 120,
        showSummary: true,
        showFilter: true,
        showLegend: true,
        showCollapseButton: true,
        showReturnLibraryInTable: true,
        showRenewals: true,
        highlightCrossLibraryReturns: true,
        hideNativeIssuehistoryTimeline: true,

        enrichWithApi: true,
        showAcquisition: true,
        showTransfers: false,
        showLastSeen: true,
        transferReportId: 0,
        transferReportSetupFr: TRANSFER_REPORT_SETUP_FR,
        transferReportSetupEn: TRANSFER_REPORT_SETUP_EN,
        transferReportSql: TRANSFER_REPORT_SQL,

        primaryColor: "#2f78a8",
        crossLibraryColor: "#b26a16",
        renewalColor: "#6b4f9d",
        acquisitionColor: "#568132",
        transferColor: "#4b78a0",
        lastSeenColor: "#7a6597",
        cancelledColor: "#a24e47",

        panelTitleBiblioFr: textDefault("panelTitleBiblio", "fr"),
        panelTitleBiblioEn: textDefault("panelTitleBiblio", "en"),
        panelSubtitleBiblioFr: textDefault("panelSubtitleBiblio", "fr"),
        panelSubtitleBiblioEn: textDefault("panelSubtitleBiblio", "en"),
        panelTitleReaderFr: textDefault("panelTitleReader", "fr"),
        panelTitleReaderEn: textDefault("panelTitleReader", "en"),
        panelSubtitleReaderFr: textDefault("panelSubtitleReader", "fr"),
        panelSubtitleReaderEn: textDefault("panelSubtitleReader", "en"),

        hideLabelFr: textDefault("hide", "fr"),
        hideLabelEn: textDefault("hide", "en"),
        showLabelFr: textDefault("show", "fr"),
        showLabelEn: textDefault("show", "en"),
        filterPlaceholderFr: textDefault("filterPlaceholder", "fr"),
        filterPlaceholderEn: textDefault("filterPlaceholder", "en"),
        clearFilterLabelFr: textDefault("clearFilter", "fr"),
        clearFilterLabelEn: textDefault("clearFilter", "en"),

        rangeAutoLabelFr: textDefault("rangeAuto", "fr"),
        rangeAutoLabelEn: textDefault("rangeAuto", "en"),
        range6mLabelFr: textDefault("range6m", "fr"),
        range6mLabelEn: textDefault("range6m", "en"),
        range1yLabelFr: textDefault("range1y", "fr"),
        range1yLabelEn: textDefault("range1y", "en"),
        range3yLabelFr: textDefault("range3y", "fr"),
        range3yLabelEn: textDefault("range3y", "en"),
        rangeAllLabelFr: textDefault("rangeAll", "fr"),
        rangeAllLabelEn: textDefault("rangeAll", "en"),

        legendCompletedLabelFr: textDefault("legendCompleted", "fr"),
        legendCompletedLabelEn: textDefault("legendCompleted", "en"),
        legendCurrentLabelFr: textDefault("legendCurrent", "fr"),
        legendCurrentLabelEn: textDefault("legendCurrent", "en"),
        legendCrossLabelFr: textDefault("legendCross", "fr"),
        legendCrossLabelEn: textDefault("legendCross", "en"),
        legendRenewalLabelFr: textDefault("legendRenewal", "fr"),
        legendRenewalLabelEn: textDefault("legendRenewal", "en"),
        legendAcquisitionLabelFr: textDefault("legendAcquisition", "fr"),
        legendAcquisitionLabelEn: textDefault("legendAcquisition", "en"),
        legendTransferLabelFr: textDefault("legendTransfer", "fr"),
        legendTransferLabelEn: textDefault("legendTransfer", "en"),
        legendLastSeenLabelFr: textDefault("legendLastSeen", "fr"),
        legendLastSeenLabelEn: textDefault("legendLastSeen", "en"),

        axisItemLabelFr: textDefault("axisItem", "fr"),
        axisItemLabelEn: textDefault("axisItem", "en"),
        axisDocumentLabelFr: textDefault("axisDocument", "fr"),
        axisDocumentLabelEn: textDefault("axisDocument", "en"),

        summaryItemsBiblioLabelFr: textDefault("summaryItemsBiblio", "fr"),
        summaryItemsBiblioLabelEn: textDefault("summaryItemsBiblio", "en"),
        summaryLoansBiblioLabelFr: textDefault("summaryLoansBiblio", "fr"),
        summaryLoansBiblioLabelEn: textDefault("summaryLoansBiblio", "en"),
        summaryLoansReaderLabelFr: textDefault("summaryLoansReader", "fr"),
        summaryLoansReaderLabelEn: textDefault("summaryLoansReader", "en"),
        summaryItemsReaderLabelFr: textDefault("summaryItemsReader", "fr"),
        summaryItemsReaderLabelEn: textDefault("summaryItemsReader", "en"),
        summaryCurrentLabelFr: textDefault("summaryCurrent", "fr"),
        summaryCurrentLabelEn: textDefault("summaryCurrent", "en"),
        summaryCrossLabelFr: textDefault("summaryCross", "fr"),
        summaryCrossLabelEn: textDefault("summaryCross", "en"),

        statusCurrentLabelFr: textDefault("statusCurrent", "fr"),
        statusCurrentLabelEn: textDefault("statusCurrent", "en"),
        statusCompletedLabelFr: textDefault("statusCompleted", "fr"),
        statusCompletedLabelEn: textDefault("statusCompleted", "en"),
        tooltipCheckoutLabelFr: textDefault("tooltipCheckout", "fr"),
        tooltipCheckoutLabelEn: textDefault("tooltipCheckout", "en"),
        tooltipCheckoutLibraryLabelFr: textDefault("tooltipCheckoutLibrary", "fr"),
        tooltipCheckoutLibraryLabelEn: textDefault("tooltipCheckoutLibrary", "en"),
        tooltipReturnLabelFr: textDefault("tooltipReturn", "fr"),
        tooltipReturnLabelEn: textDefault("tooltipReturn", "en"),
        tooltipReturnLibraryLabelFr: textDefault("tooltipReturnLibrary", "fr"),
        tooltipReturnLibraryLabelEn: textDefault("tooltipReturnLibrary", "en"),
        tooltipDurationLabelFr: textDefault("tooltipDuration", "fr"),
        tooltipDurationLabelEn: textDefault("tooltipDuration", "en"),
        tooltipRenewalsLabelFr: textDefault("tooltipRenewals", "fr"),
        tooltipRenewalsLabelEn: textDefault("tooltipRenewals", "en"),
        tooltipLastRenewedLabelFr: textDefault("tooltipLastRenewed", "fr"),
        tooltipLastRenewedLabelEn: textDefault("tooltipLastRenewed", "en"),
        tooltipCurrentReturnLabelFr: textDefault("tooltipCurrentReturn", "fr"),
        tooltipCurrentReturnLabelEn: textDefault("tooltipCurrentReturn", "en"),
        tooltipCrossWarningLabelFr: textDefault("tooltipCrossWarning", "fr"),
        tooltipCrossWarningLabelEn: textDefault("tooltipCrossWarning", "en"),
        returnLibraryLabelFr: textDefault("returnLibraryLabel", "fr"),
        returnLibraryLabelEn: textDefault("returnLibraryLabel", "en"),

        acquisitionEventLabelFr: textDefault("acquisitionEvent", "fr"),
        acquisitionEventLabelEn: textDefault("acquisitionEvent", "en"),
        lastSeenEventLabelFr: textDefault("lastSeenEvent", "fr"),
        lastSeenEventLabelEn: textDefault("lastSeenEvent", "en"),
        transferRequestedEventLabelFr: textDefault("transferRequestedEvent", "fr"),
        transferRequestedEventLabelEn: textDefault("transferRequestedEvent", "en"),
        transferSentEventLabelFr: textDefault("transferSentEvent", "fr"),
        transferSentEventLabelEn: textDefault("transferSentEvent", "en"),
        transferArrivedEventLabelFr: textDefault("transferArrivedEvent", "fr"),
        transferArrivedEventLabelEn: textDefault("transferArrivedEvent", "en"),
        transferCancelledEventLabelFr: textDefault("transferCancelledEvent", "fr"),
        transferCancelledEventLabelEn: textDefault("transferCancelledEvent", "en"),
        eventDateLabelFr: textDefault("eventDate", "fr"),
        eventDateLabelEn: textDefault("eventDate", "en"),
        eventLibraryLabelFr: textDefault("eventLibrary", "fr"),
        eventLibraryLabelEn: textDefault("eventLibrary", "en"),
        eventReasonLabelFr: textDefault("eventReason", "fr"),
        eventReasonLabelEn: textDefault("eventReason", "en"),

        emptyPeriodLabelFr: textDefault("emptyPeriod", "fr"),
        emptyPeriodLabelEn: textDefault("emptyPeriod", "en"),
        emptyFilterLabelFr: textDefault("emptyFilter", "fr"),
        emptyFilterLabelEn: textDefault("emptyFilter", "en"),
        limitNoteLabelFr: textDefault("limitNote", "fr"),
        limitNoteLabelEn: textDefault("limitNote", "en"),
        itemPrefixLabelFr: textDefault("itemPrefix", "fr"),
        itemPrefixLabelEn: textDefault("itemPrefix", "en"),
        daySingularLabelFr: textDefault("daySingular", "fr"),
        daySingularLabelEn: textDefault("daySingular", "en"),
        dayPluralLabelFr: textDefault("dayPlural", "fr"),
        dayPluralLabelEn: textDefault("dayPlural", "en")
    };

    if (window[GLOBAL_GUARD]) return;

    const state = {
        config: null,
        page: null,
        table: null,
        rows: [],
        panel: null,
        tooltip: null,
        libraries: { byCode: new Map(), byName: new Map() },
        apiCheckouts: [],
        sourceReads: {},
        lifeByItem: new Map(),
        drawBound: false,
        refreshTimer: null,
        requestTail: Promise.resolve(),
        lastRequestEnd: 0,
        coreRegistered: false,
        coreStarted: false,
        fallbackStarted: false,
        unsubscribe: null,
        legacyGuardClaimed: false,
        blockedByExistingTimeline: false
    };

    window[GLOBAL_GUARD] = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        initialized: false,
        runtime: null,
        destroy: destroyRuntime,
        refresh: scheduleRefresh
    };

    function deepClone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) return Array.isArray(override) ? deepClone(override) : deepClone(base);
        if (!isObject(base)) return override === undefined ? deepClone(base) : deepClone(override);
        const out = deepClone(base) || {};
        if (!isObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            if (Array.isArray(override[key])) out[key] = deepClone(override[key]);
            else if (isObject(override[key]) && isObject(out[key])) out[key] = deepMerge(out[key], override[key]);
            else out[key] = deepClone(override[key]);
        });
        return out;
    }

    function normalizeText(value) {
        return String(value == null ? "" : value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\u00a0/g, " ")
            .replace(/[\u200B-\u200D\uFEFF]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function cleanText(value) {
        return String(value == null ? "" : value)
            .replace(/\u00a0/g, " ")
            .replace(/[\u200B-\u200D\uFEFF]/g, "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function detectPage() {
        const path = window.location.pathname || "";
        return Object.values(PAGE_DEFINITIONS).find(function (page) {
            return page.path === path;
        }) || null;
    }

    function detectLanguage(config) {
        const requested = String(config && config.language || "auto").toLowerCase();
        if (requested === "fr" || requested === "en") return requested;

        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            const coreLang = String(window.PMKConfig.getLanguage() || "").toLowerCase();
            if (coreLang.startsWith("en")) return "en";
            if (coreLang.startsWith("fr")) return "fr";
        }

        const htmlLang = String(document.documentElement.lang || "").toLowerCase();
        if (htmlLang.startsWith("en")) return "en";
        return "fr";
    }

    function cfgText(key) {
        const lang = detectLanguage(state.config || DEFAULT_CONFIG);
        const suffix = lang === "en" ? "En" : "Fr";
        const value = state.config && state.config[key + suffix];
        if (value !== undefined && value !== null && String(value).trim()) return String(value).trim();

        const defaultValue = DEFAULT_CONFIG[key + suffix];
        if (defaultValue !== undefined && defaultValue !== null) return String(defaultValue);
        return key;
    }

    function replaceTokens(template, values) {
        return String(template || "").replace(/\{([a-zA-Z0-9_]+)\}/g, function (_, key) {
            return Object.prototype.hasOwnProperty.call(values || {}, key) ? String(values[key]) : "{" + key + "}";
        });
    }

    function isPageEnabled(config, page) {
        if (!config || config.enabled === false || !page) return false;
        if (page.id === "catalogue.issuehistory") return config.issuehistoryEnabled !== false;
        if (page.id === "members.readingrec") return config.readingrecEnabled !== false;
        return false;
    }

    function createEl(tag, className, text) {
        const el = document.createElement(tag);
        if (className) el.className = className;
        if (text !== undefined && text !== null) el.textContent = String(text);
        return el;
    }

    function parseKohaDate(value) {
        if(window.PMKDates)return window.PMKDates.parse(value);
        if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
        if (!value) return null;
        const raw = cleanText(value);
        if (!raw || /^(checked out|en cours|current)$/i.test(raw)) return null;

        let match = raw.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
        if (match) {
            const date = new Date(
                Number(match[1]),
                Number(match[2]) - 1,
                Number(match[3]),
                Number(match[4] || 0),
                Number(match[5] || 0),
                Number(match[6] || 0)
            );
            return Number.isNaN(date.getTime()) ? null : date;
        }

        match = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?/);
        if (match) {
            const date = new Date(
                Number(match[3]),
                Number(match[2]) - 1,
                Number(match[1]),
                Number(match[4] || 0),
                Number(match[5] || 0),
                Number(match[6] || 0)
            );
            return Number.isNaN(date.getTime()) ? null : date;
        }

        const parsed = new Date(raw);
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    }

    function formatDateTime(date) {
        if (!date) return "—";
        const locale = detectLanguage(state.config) === "en" ? "en-GB" : "fr-FR";
        try {
            return new Intl.DateTimeFormat(locale, {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            }).format(date);
        } catch (_) {
            return date.toLocaleString();
        }
    }

    function formatAxisDate(date, rangeKey) {
        if (!date) return "";
        const locale = detectLanguage(state.config) === "en" ? "en-GB" : "fr-FR";
        const options = (rangeKey === "6m" || rangeKey === "1y")
            ? { month: "short", year: "2-digit" }
            : { month: "short", year: "numeric" };
        try {
            return new Intl.DateTimeFormat(locale, options).format(date).replace(".", "");
        } catch (_) {
            return date.toLocaleDateString();
        }
    }

    function daysBetween(start, end) {
        if (!start || !end) return null;
        return Math.max(0, Math.round((end.getTime() - start.getTime()) / 86400000));
    }

    function durationText(days) {
        if (!Number.isFinite(days)) return "";
        const key = Math.abs(days) === 1 ? "daySingularLabel" : "dayPluralLabel";
        return days + " " + cfgText(key);
    }

    function getCellValue(cell) {
        if (!cell) return "";
        return cleanText(
            cell.dataset.order ||
            cell.getAttribute("data-sort") ||
            cell.getAttribute("data-order") ||
            cell.textContent ||
            ""
        );
    }

    const COLUMN_DEFS = {
        title: {
            technical: ["title", "biblio_title", "bibliographic_title"],
            aliases: ["titre", "title", "document", "bibliographic record"]
        },
        barcode: {
            technical: ["barcode", "external_id", "item_barcode"],
            aliases: ["code a barres", "code-barres", "barcode", "bar code"]
        },
        checkoutSite: {
            technical: ["checkout_library", "library", "library_id", "branch"],
            aliases: ["emprunte a", "emprunté à", "site de pret", "site de prêt", "checked out from", "checkout library", "library"]
        },
        checkoutDate: {
            technical: ["checkout_date", "checkout_on", "issuedate", "issue_date"],
            aliases: ["emprunte le", "emprunté le", "date de pret", "date de prêt", "checked out on", "checkout on", "checkout date", "checkout"]
        },
        dueDate: {
            technical: ["due_date", "date_due", "duedate"],
            aliases: ["retour prevu", "retour prévu", "date de retour prevue", "date de retour prévue", "due date", "expected return"]
        },
        returnDate: {
            technical: ["checkin_date", "return_date", "returndate", "checkin_on"],
            aliases: ["retour effectif", "rendu le", "retourne le", "retourné le", "returned on", "check-in date", "checkin date", "checkin on", "actual return"]
        },
        renewals: {
            technical: ["renewals", "renewals_count", "renewed"],
            aliases: ["renouvele", "renouvelé", "nombre de renouvellements", "renewals", "renewed"]
        }
    };

    function headerIdentity(th) {
        const values = [
            th.dataset.colname,
            th.dataset.pmkColname,
            th.dataset.column,
            th.getAttribute("data-colname"),
            th.getAttribute("data-column"),
            th.getAttribute("name"),
            th.id,
            th.getAttribute("aria-label"),
            th.querySelector(".dt-column-title")?.textContent,
            th.textContent
        ].filter(Boolean).map(normalizeText);
        return values;
    }

    function resolveColumn(table, defKey) {
        const def = COLUMN_DEFS[defKey];
        if (!def) return -1;
        const technical = def.technical.map(normalizeText);
        const aliases = def.aliases.map(normalizeText);
        const headers = Array.from(table.querySelectorAll("thead tr:first-child th"));

        let index = headers.findIndex(function (th) {
            const identities = headerIdentity(th);
            return identities.some(function (identity) {
                return technical.some(function (key) {
                    return identity === key || identity.includes(key);
                });
            });
        });
        if (index >= 0) return index;

        index = headers.findIndex(function (th) {
            const identities = headerIdentity(th);
            return identities.some(function (identity) {
                return aliases.some(function (alias) {
                    return identity === alias || identity.startsWith(alias + ":") || identity.includes(alias);
                });
            });
        });
        return index;
    }

    function resolveColumns(table, page) {
        const columns = {
            title: page.kind === "reader" ? resolveColumn(table, "title") : -1,
            barcode: resolveColumn(table, "barcode"),
            checkoutSite: resolveColumn(table, "checkoutSite"),
            checkoutDate: resolveColumn(table, "checkoutDate"),
            dueDate: resolveColumn(table, "dueDate"),
            returnDate: resolveColumn(table, "returnDate"),
            renewals: resolveColumn(table, "renewals")
        };

        if (columns.barcode < 0 || columns.checkoutDate < 0 || columns.returnDate < 0) return null;
        if (page.kind === "reader" && columns.title < 0) return null;
        return columns;
    }

    function getItemnumber(row) {
        const link = row.querySelector('a[href*="itemnumber="], a[href*="item_id="]');
        if (!link) return null;
        try {
            const url = new URL(link.getAttribute("href"), window.location.origin);
            return url.searchParams.get("itemnumber") || url.searchParams.get("item_id");
        } catch (_) {
            return null;
        }
    }

    function getBiblioPageTitle() {
        const selectors = [
            "#catalogue_detail_biblio h1",
            "main h1",
            "#main_intranet-main h1",
            "h1"
        ];
        for (const selector of selectors) {
            const value = cleanText(document.querySelector(selector)?.textContent || "");
            if (value) return value;
        }
        return "";
    }

    function parseRows(table, page) {
        const columns = resolveColumns(table, page);
        if (!columns) return [];
        const rows = [];
        const pageTitle = page.kind === "biblio" ? getBiblioPageTitle() : "";

        table.querySelectorAll("tbody tr").forEach(function (tr, index) {
            const cells = tr.cells;
            if (!cells || !cells.length) return;
            const barcodeCell = cells[columns.barcode];
            const checkoutCell = cells[columns.checkoutDate];
            const returnCell = cells[columns.returnDate];
            if (!barcodeCell || !checkoutCell || !returnCell) return;

            const start = parseKohaDate(getCellValue(checkoutCell));
            if (!start) return;

            const end = parseKohaDate(getCellValue(returnCell));
            const current = !end;
            const itemId = getItemnumber(tr);
            const barcode = cleanText(barcodeCell.textContent) || itemId || String(index + 1);
            const title = page.kind === "reader"
                ? cleanText(cells[columns.title]?.querySelector(".biblio-title")?.textContent || cells[columns.title]?.textContent || "")
                : pageTitle;
            const checkoutSite = columns.checkoutSite >= 0 ? cleanText(cells[columns.checkoutSite]?.textContent || "") : "";
            const dueDate = columns.dueDate >= 0 ? parseKohaDate(getCellValue(cells[columns.dueDate])) : null;
            const renewalsRaw = columns.renewals >= 0 ? cleanText(cells[columns.renewals]?.textContent || "") : "";
            let renewalsCount = 0;
            if (/^\d+$/.test(renewalsRaw)) renewalsCount = Number(renewalsRaw);
            else if (/^(oui|yes|true)\b/i.test(renewalsRaw)) renewalsCount = 1;

            rows.push({
                rowElement: tr,
                returnCell: returnCell,
                itemId: itemId ? String(itemId) : null,
                barcode: barcode,
                title: title,
                checkoutSite: checkoutSite,
                checkoutSiteCode: null,
                returnSite: "",
                returnSiteCode: null,
                start: start,
                dueDate: dueDate,
                end: end,
                current: current,
                renewalsCount: renewalsCount,
                lastRenewedDate: null,
                apiCheckout: null
            });
        });

        return rows;
    }

    function waitForTable(selector, timeoutMs) {
        const timeout = Number.isFinite(timeoutMs) ? timeoutMs : 12000;
        return new Promise(function (resolve) {
            const start = Date.now();
            const find = function () {
                const table = document.querySelector(selector);
                if (!table) return null;
                const hasRows = Array.from(table.querySelectorAll("tbody tr")).some(function (row) {
                    return row.cells && row.cells.length > 1;
                });
                return hasRows ? table : null;
            };

            const immediate = find();
            if (immediate) {
                resolve(immediate);
                return;
            }

            const observer = new MutationObserver(function () {
                const found = find();
                if (found || Date.now() - start >= timeout) {
                    observer.disconnect();
                    resolve(found || document.querySelector(selector));
                }
            });

            observer.observe(document.documentElement, { childList: true, subtree: true });
            window.setTimeout(function () {
                observer.disconnect();
                resolve(find() || document.querySelector(selector));
            }, timeout);
        });
    }

    function queueRequest(task) {
        const MIN_GAP = 250;
        const job = state.requestTail.catch(function () {}).then(async function () {
            const wait = Math.max(0, MIN_GAP - (Date.now() - state.lastRequestEnd));
            if (wait) await new Promise(function (resolve) { window.setTimeout(resolve, wait); });
            try {
                return await task();
            } finally {
                state.lastRequestEnd = Date.now();
            }
        });
        state.requestTail = job.catch(function () {});
        return job;
    }

    async function fetchJson(url, options) {
        const opts = options || {};
        return queueRequest(async function () {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 15000);
            try {
                const response = await fetch(url, {
                    method: "GET", credentials: "same-origin", signal: controller.signal,
                    headers: Object.assign({ Accept: "application/json" }, opts.headers || {})
                });
                if (!response.ok) throw Object.assign(new Error("koha_api_error"), { status: response.status });
                return { response, data: await response.json() };
            } finally { clearTimeout(timer); }
        });
    }

    async function fetchPaged(baseUrl) {
        const output = [], perPage = 100;
        const source = { status: 'loading', count: 0 };
        state.sourceReads[baseUrl] = source;
        try {
            for(let page=1;page<=100;page++) {
                const url = new URL(baseUrl, window.location.origin);
                url.searchParams.set("_page", String(page));
                url.searchParams.set("_per_page", String(perPage));
                const result = await fetchJson(url.toString());
                if (!Array.isArray(result.data)) throw new Error('invalid_api_rows');
                output.push(...result.data);source.count=output.length;
                const total = Number(result.response.headers.get("X-Total-Count") || 0);
                if ((total && output.length >= total) || result.data.length < perPage) {
                    source.status='complete';return output;
                }
            }
            source.status='partial';return output;
        } catch(error) {
            source.status=output.length?'partial':'unavailable';
            if(output.length)return output;
            throw error;
        }
    }

    async function loadLibraries() {
        try {
            const result = await fetchJson("/api/v1/public/libraries");
            if(!Array.isArray(result.data))throw new Error('invalid_library_rows');
            const list = result.data;
            state.sourceReads.libraries={status:'complete',count:list.length};
            const byCode = new Map();
            const byName = new Map();
            list.forEach(function (library) {
                if (!library || !library.library_id) return;
                const code = String(library.library_id);
                const name = library.name || code;
                byCode.set(code, name);
                byName.set(normalizeText(code), code);
                byName.set(normalizeText(name), code);
            });
            return { byCode: byCode, byName: byName };
        } catch (_) {
            state.sourceReads.libraries={status:'unavailable',count:0};
            return { byCode: new Map(), byName: new Map() };
        }
    }

    async function loadHistoricalCheckouts(page) {
        if (!state.config.enrichWithApi) return [];
        const params = new URLSearchParams(window.location.search);

        if (page.kind === "biblio") {
            const biblioId = params.get("biblionumber");
            if (!biblioId) return [];
            try {
                return await fetchPaged("/api/v1/biblios/" + encodeURIComponent(biblioId) + "/checkouts?checked_in=true");
            } catch (_) {
                return [];
            }
        }

        const patronId = params.get("borrowernumber");
        if (!patronId) return [];

        try {
            return await fetchPaged("/api/v1/checkouts?patron_id=" + encodeURIComponent(patronId) + "&checked_in=true");
        } catch (_) {
            try {
                return await fetchPaged("/api/v1/patrons/" + encodeURIComponent(patronId) + "/checkouts");
            } catch (_) {
                return [];
            }
        }
    }

    async function loadBiblioItems(page) {
        if (!state.config.enrichWithApi || page.kind !== "biblio") return [];
        if (!state.config.showAcquisition && !state.config.showLastSeen) return [];
        const biblioId = new URLSearchParams(window.location.search).get("biblionumber");
        if (!biblioId) return [];
        try {
            return await fetchPaged("/api/v1/public/biblios/" + encodeURIComponent(biblioId) + "/items");
        } catch (_) {
            return [];
        }
    }

    async function loadBiblioTransfers(page) {
        if (!state.config.enrichWithApi || page.kind !== "biblio") return [];
        if (!state.config.showTransfers) return [];
        const reportId = Number(state.config.transferReportId || 0);
        if (!Number.isInteger(reportId) || reportId <= 0) {
            state.sourceReads.transfers={status:'not-configured',count:0};return [];
        }

        const biblioId = new URLSearchParams(window.location.search).get("biblionumber");
        if (!biblioId) return [];
        const all = [];
        const source=state.sourceReads.transfers={status:'complete',count:0};
        let cursor = 0;
        let lots = 0;

        try {
            while (lots < 200) {
                lots += 1;
                const url = new URL("/cgi-bin/koha/svc/report", window.location.origin);
                url.searchParams.set("id", String(reportId));
                url.searchParams.set("annotated", "1");
                url.searchParams.append("param_names", "Biblionumber");
                url.searchParams.append("sql_params", String(biblioId));
                url.searchParams.append("param_names", "Après ID");
                url.searchParams.append("sql_params", String(cursor));
                const result = await fetchJson(url.toString());
                if (!Array.isArray(result.data)) throw new Error('invalid_transfer_rows');
                if (!result.data.length) break;
                all.push.apply(all, result.data);source.count=all.length;
                const last = Number(
                    result.data[result.data.length - 1].Transfer_ID ??
                    result.data[result.data.length - 1].transfer_id ??
                    0
                );
                if (!Number.isFinite(last) || last <= cursor) {source.status='partial';break;}
                cursor = last;
                if (result.data.length < 500) break;
                if(lots===200)source.status='partial';
            }
        } catch (_) {
            source.status=all.length?'partial':'unavailable';
        }
        return all;
    }

    function dateMs(value) {
        const date = value instanceof Date ? value : parseKohaDate(value);
        return date ? date.getTime() : null;
    }

    function matchCheckout(row, checkouts) {
        if (!row.itemId || !Array.isArray(checkouts) || !checkouts.length) return null;
        const sameItem = checkouts.filter(function (checkout) {
            return String(checkout && checkout.item_id) === String(row.itemId);
        });
        if (!sameItem.length) return null;

        const startMs = row.start.getTime();
        const endMs = row.end ? row.end.getTime() : null;
        return sameItem.map(function (checkout) {
            const apiStart = dateMs(checkout.checkout_date);
            const apiEnd = dateMs(checkout.checkin_date);
            let score = apiStart === null ? 1000000000 : Math.abs(apiStart - startMs);
            if (endMs !== null) score += apiEnd === null ? 1000000000 : Math.abs(apiEnd - endMs);
            return { checkout: checkout, score: score };
        }).sort(function (a, b) {
            return a.score - b.score;
        })[0].checkout;
    }

    function enrichRows(rows, checkouts, libraries) {
        rows.forEach(function (row) {
            if (row.checkoutSite) {
                row.checkoutSiteCode = libraries.byName.get(normalizeText(row.checkoutSite)) || null;
            }
            const checkout = matchCheckout(row, checkouts);
            if (!checkout) return;
            row.apiCheckout = checkout;

            if (checkout.checkin_library_id) {
                row.returnSiteCode = String(checkout.checkin_library_id);
                row.returnSite = libraries.byCode.get(row.returnSiteCode) || row.returnSiteCode;
            }
            if (!row.checkoutSiteCode && checkout.library_id) row.checkoutSiteCode = String(checkout.library_id);
            if (!row.checkoutSite && row.checkoutSiteCode) {
                row.checkoutSite = libraries.byCode.get(row.checkoutSiteCode) || row.checkoutSiteCode;
            }
            const apiRenewals = Number(checkout.renewals_count);
            if (Number.isFinite(apiRenewals)) row.renewalsCount = apiRenewals;
            row.lastRenewedDate = parseKohaDate(checkout.last_renewed_date);
        });
    }

    function itemValue(item) {
        const keys = Array.prototype.slice.call(arguments, 1);
        for (const key of keys) {
            if (item && item[key] !== undefined && item[key] !== null && item[key] !== "") return item[key];
        }
        return null;
    }

    function buildLifeByItem(items, transfers, libraries) {
        const map = new Map();
        (items || []).forEach(function (item) {
            const itemId = String(itemValue(item, "item_id", "itemnumber") || "");
            if (!itemId) return;
            map.set(itemId, {
                acquisition: parseKohaDate(itemValue(item, "acquisition_date", "dateaccessioned")),
                lastSeen: parseKohaDate(itemValue(item, "last_seen_date", "datelastseen")),
                homeCode: String(itemValue(item, "home_library_id", "homebranch") || ""),
                holdingCode: String(itemValue(item, "holding_library_id", "holdingbranch") || ""),
                points: []
            });
        });

        (transfers || []).forEach(function (transfer) {
            const itemId = String(transfer.Item_ID ?? transfer.item_id ?? transfer.itemnumber ?? "");
            if (!itemId) return;
            if (!map.has(itemId)) {
                map.set(itemId, { acquisition: null, lastSeen: null, homeCode: "", holdingCode: "", points: [] });
            }
            const target = map.get(itemId);
            const from = String(transfer.From_Site ?? transfer.from_site ?? transfer.frombranch ?? "");
            const to = String(transfer.To_Site ?? transfer.to_site ?? transfer.tobranch ?? "");
            const route = [from, to].filter(Boolean).map(function (code) {
                return libraries.byCode.get(code) || code;
            }).join(" → ");
            const reason = String(transfer.Raison ?? transfer.reason ?? "");
            const cancelledReason = String(transfer.Raison_annulation ?? transfer.cancellation_reason ?? "");

            function add(dateValue, type, labelKey, extra) {
                const date = parseKohaDate(dateValue);
                if (!date) return;
                target.points.push({
                    date: date,
                    type: type,
                    labelKey: labelKey,
                    site: route,
                    extra: extra || ""
                });
            }

            add(transfer.Demande_le ?? transfer.daterequested, "transfer", "transferRequestedEventLabel", reason);
            add(transfer.Envoye_le ?? transfer.datesent, "transfer", "transferSentEventLabel", reason);
            add(transfer.Arrive_le ?? transfer.datearrived, "transfer", "transferArrivedEventLabel", reason);
            add(transfer.Annule_le ?? transfer.datecancelled, "cancelled", "transferCancelledEventLabel", cancelledReason || reason);
        });

        map.forEach(function (life) {
            if (state.config.showAcquisition && life.acquisition) {
                const site = life.homeCode ? (libraries.byCode.get(life.homeCode) || life.homeCode) : "";
                life.points.push({ date: life.acquisition, type: "acquisition", labelKey: "acquisitionEventLabel", site: site, extra: "" });
            }
            if (state.config.showLastSeen && life.lastSeen) {
                const code = life.holdingCode || life.homeCode;
                const site = code ? (libraries.byCode.get(code) || code) : "";
                life.points.push({ date: life.lastSeen, type: "seen", labelKey: "lastSeenEventLabel", site: site, extra: "" });
            }
            life.points.sort(function (a, b) { return a.date - b.date; });
        });
        return map;
    }

    function isCrossLibrary(row) {
        if (!row.end || !row.returnSite) return false;
        if (row.checkoutSiteCode && row.returnSiteCode) return row.checkoutSiteCode !== row.returnSiteCode;
        if (!row.checkoutSite) return false;
        return normalizeText(row.checkoutSite) !== normalizeText(row.returnSite);
    }

    function clearReturnAnnotations() {
        document.querySelectorAll("." + RETURN_INFO_CLASS).forEach(function (el) { el.remove(); });
    }

    function annotateReturnCells(rows) {
        clearReturnAnnotations();
        if (!state.config.showReturnLibraryInTable) return;
        rows.forEach(function (row) {
            if (!row.end || !row.returnSite || !row.returnCell) return;
            const info = createEl("div", RETURN_INFO_CLASS);
            info.appendChild(document.createTextNode(cfgText("returnLibraryLabel") + " : "));
            const strong = createEl("strong", "", row.returnSite);
            info.appendChild(strong);
            if (row.returnSiteCode) info.title = row.returnSiteCode;
            row.returnCell.appendChild(info);
        });
    }

    function computeRange(rangeKey, rows) {
        const now = new Date();
        let start = new Date(now);

        if (rangeKey === "6m") start.setMonth(start.getMonth() - 6);
        else if (rangeKey === "1y") start.setFullYear(start.getFullYear() - 1);
        else if (rangeKey === "3y") start.setFullYear(start.getFullYear() - 3);
        else {
            let earliest = now.getTime();
            rows.forEach(function (row) { earliest = Math.min(earliest, row.start.getTime()); });
            if (state.page && state.page.kind === "biblio") {
                state.lifeByItem.forEach(function (life) {
                    (life.points || []).forEach(function (point) {
                        earliest = Math.min(earliest, point.date.getTime());
                    });
                });
            }

            if (rangeKey === "all") {
                start = new Date(earliest);
                start.setDate(start.getDate() - 7);
            } else {
                /*
                 * Zoom automatique : conserve toute l'histoire lorsqu'elle
                 * tient dans trois ans ; au-delà, ouvre sur les trois dernières
                 * années. Le bouton « Tout » reste disponible pour remonter plus loin.
                 */
                const threeYearsAgo = new Date(now);
                threeYearsAgo.setFullYear(threeYearsAgo.getFullYear() - 3);
                start = earliest >= threeYearsAgo.getTime() ? new Date(earliest) : threeYearsAgo;
                if (earliest >= threeYearsAgo.getTime()) start.setDate(start.getDate() - 7);
            }
        }

        const end = new Date(now);
        end.setDate(end.getDate() + 2);
        return { start: start, end: end };
    }

    function rowIntersects(row, range) {
        const rowEnd = row.end || new Date();
        return row.start <= range.end && rowEnd >= range.start;
    }

    function positionPct(date, range) {
        const total = range.end.getTime() - range.start.getTime();
        if (total <= 0) return 0;
        return Math.max(0, Math.min(100, ((date.getTime() - range.start.getTime()) / total) * 100));
    }

    function makeTicks(range, count) {
        const output = [];
        const total = range.end.getTime() - range.start.getTime();
        const safeCount = Math.max(2, count || 6);
        for (let index = 0; index <= safeCount; index += 1) {
            output.push(new Date(range.start.getTime() + total * index / safeCount));
        }
        return output;
    }

    function groupRows(rows, range) {
        const visible = rows.filter(function (row) { return rowIntersects(row, range); });
        if (state.page.kind === "biblio") {
            const map = new Map();
            visible.forEach(function (row) {
                const key = row.itemId || row.barcode;
                if (!map.has(key)) {
                    map.set(key, {
                        key: key,
                        main: row.barcode,
                        sub: row.itemId ? cfgText("itemPrefixLabel") + " " + row.itemId : "",
                        events: [],
                        points: state.lifeByItem.get(String(row.itemId || ""))?.points || []
                    });
                }
                map.get(key).events.push(row);
            });
            return Array.from(map.values()).sort(function (a, b) {
                return a.main.localeCompare(b.main, detectLanguage(state.config), { numeric: true });
            });
        }

        return visible.sort(function (a, b) { return b.start - a.start; })
            .slice(0, Math.max(1, Number(state.config.maxReaderRows || 120)))
            .map(function (row, index) {
                return {
                    key: String(row.itemId || row.barcode) + "-" + row.start.getTime() + "-" + index,
                    main: row.title || row.barcode,
                    sub: row.title ? row.barcode : (row.itemId ? cfgText("itemPrefixLabel") + " " + row.itemId : ""),
                    events: [row],
                    points: []
                };
            });
    }

    function summaryValues(rows) {
        const distinctItems = new Set(rows.map(function (row) { return row.itemId || row.barcode; })).size;
        const current = rows.filter(function (row) { return row.current; }).length;
        const hasReturnSite = rows.some(function (row) { return Boolean(row.returnSite); });
        const cross = rows.filter(isCrossLibrary).length;
        const crossValue = hasReturnSite ? cross : "—";

        if (state.page.kind === "biblio") {
            return [
                [distinctItems, cfgText("summaryItemsBiblioLabel")],
                [rows.length, cfgText("summaryLoansBiblioLabel")],
                [current, cfgText("summaryCurrentLabel")],
                [crossValue, cfgText("summaryCrossLabel")]
            ];
        }
        return [
            [rows.length, cfgText("summaryLoansReaderLabel")],
            [distinctItems, cfgText("summaryItemsReaderLabel")],
            [current, cfgText("summaryCurrentLabel")],
            [crossValue, cfgText("summaryCrossLabel")]
        ];
    }

    function buildLoanTooltip(row) {
        const lines = [];
        lines.push(row.current ? cfgText("statusCurrentLabel") : cfgText("statusCompletedLabel"));
        lines.push(cfgText("tooltipCheckoutLabel") + " : " + formatDateTime(row.start));
        if (row.checkoutSite) lines.push(cfgText("tooltipCheckoutLibraryLabel") + " : " + row.checkoutSite);
        if (row.end) {
            lines.push(cfgText("tooltipReturnLabel") + " : " + formatDateTime(row.end));
            if (row.returnSite) lines.push(cfgText("tooltipReturnLibraryLabel") + " : " + row.returnSite);
            const duration = daysBetween(row.start, row.end);
            if (duration !== null) lines.push(cfgText("tooltipDurationLabel") + " : " + durationText(duration));
        } else {
            lines.push(cfgText("tooltipReturnLabel") + " : " + cfgText("tooltipCurrentReturnLabel"));
        }
        if (state.config.showRenewals && row.renewalsCount > 0) {
            lines.push(cfgText("tooltipRenewalsLabel") + " : " + row.renewalsCount);
        }
        if (state.config.showRenewals && row.lastRenewedDate) {
            lines.push(cfgText("tooltipLastRenewedLabel") + " : " + formatDateTime(row.lastRenewedDate));
        }
        if (state.config.highlightCrossLibraryReturns && isCrossLibrary(row)) {
            lines.push("⚠ " + cfgText("tooltipCrossWarningLabel"));
        }
        return lines.join("\n");
    }

    function buildPointTooltip(point) {
        const lines = [cfgText(point.labelKey)];
        lines.push(cfgText("eventDateLabel") + " : " + formatDateTime(point.date));
        if (point.site) lines.push(cfgText("eventLibraryLabel") + " : " + point.site);
        if (point.extra) lines.push(cfgText("eventReasonLabel") + " : " + point.extra);
        return lines.join("\n");
    }

    function injectStyles() {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }
        const config = state.config || DEFAULT_CONFIG;
        style.textContent = `
            .pmk-lht-panel {
                --pmk-lht-primary: ${config.primaryColor};
                --pmk-lht-cross: ${config.crossLibraryColor};
                --pmk-lht-renewal: ${config.renewalColor};
                --pmk-lht-acquisition: ${config.acquisitionColor};
                --pmk-lht-transfer: ${config.transferColor};
                --pmk-lht-seen: ${config.lastSeenColor};
                --pmk-lht-cancelled: ${config.cancelledColor};
                margin: 1rem 0;
                border: 1px solid var(--bs-border-color, #d6dde3);
                border-radius: .35rem;
                background: var(--bs-body-bg, #fff);
                color: var(--bs-body-color, #212529);
                box-shadow: 0 1px 2px rgba(0,0,0,.04);
                overflow: hidden;
            }
            .pmk-lht-header {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: .75rem;
                padding: .75rem 1rem;
                border-bottom: 1px solid var(--bs-border-color, #dee2e6);
                background: var(--bs-tertiary-bg, #f8f9fa);
            }
            .pmk-lht-title-wrap { min-width: 0; flex: 1; }
            .pmk-lht-title { margin: 0; font-size: 1.05rem; font-weight: 700; color: inherit; }
            .pmk-lht-subtitle { margin-top: .15rem; color: var(--bs-secondary-color, #6c757d); font-size: .86rem; }
            .pmk-lht-header-actions { display: flex; align-items: center; gap: .25rem; flex: 0 0 auto; }
            .pmk-lht-body[hidden] { display: none !important; }
            .pmk-lht-summary {
                display: grid;
                grid-template-columns: repeat(4, minmax(110px, 1fr));
                gap: .5rem;
                padding: .75rem 1rem .25rem;
            }
            .pmk-lht-card {
                min-width: 0;
                padding: .55rem .65rem;
                border: 1px solid var(--bs-border-color, #e3e8ed);
                border-radius: .3rem;
                background: var(--bs-body-bg, #fff);
            }
            .pmk-lht-card-value { display: block; font-size: 1.12rem; line-height: 1.1; font-weight: 700; }
            .pmk-lht-card-label { display: block; margin-top: .2rem; color: var(--bs-secondary-color, #6c757d); font-size: .76rem; }
            .pmk-lht-toolbar {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                gap: .55rem 1rem;
                padding: .65rem 1rem .75rem;
            }
            .pmk-lht-filter { display: flex; align-items: center; gap: .35rem; flex: 1 1 260px; max-width: 480px; }
            .pmk-lht-filter input { min-width: 0; }
            .pmk-lht-toolbar-right { display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-end; gap: .45rem .8rem; }
            .pmk-lht-ranges { display: flex; flex-wrap: wrap; gap: .25rem; }
            .pmk-lht-ranges .btn.is-active { color: #fff; background: var(--pmk-lht-primary); border-color: var(--pmk-lht-primary); }
            .pmk-lht-legend { display: flex; flex-wrap: wrap; gap: .35rem .7rem; color: var(--bs-secondary-color, #6c757d); font-size: .76rem; }
            .pmk-lht-legend-item { white-space: nowrap; }
            .pmk-lht-dot, .pmk-lht-line { display: inline-block; vertical-align: middle; margin-right: .25rem; }
            .pmk-lht-dot { width: .55rem; height: .55rem; border-radius: 50%; background: var(--pmk-lht-primary); }
            .pmk-lht-line { width: 1.2rem; height: .25rem; border-radius: 1rem; background: var(--pmk-lht-primary); }
            .pmk-lht-line.current { background: repeating-linear-gradient(90deg,var(--pmk-lht-primary) 0 6px,transparent 6px 10px); }
            .pmk-lht-line.cross { background: var(--pmk-lht-cross); }
            .pmk-lht-scroll { overflow-x: auto; overscroll-behavior-inline: contain; padding: 0 1rem .8rem; }
            .pmk-lht-chart { min-width: 900px; }
            .pmk-lht-axis, .pmk-lht-row { display: grid; grid-template-columns: 210px minmax(650px, 1fr); }
            .pmk-lht-axis { position: sticky; top: 0; z-index: 4; background: var(--bs-body-bg, #fff); border-block: 1px solid var(--bs-border-color, #e1e5e8); }
            .pmk-lht-axis-label { padding: .55rem .5rem .45rem 0; color: var(--bs-secondary-color, #6c757d); font-size: .75rem; font-weight: 600; }
            .pmk-lht-axis-track { position: relative; height: 36px; }
            .pmk-lht-tick, .pmk-lht-grid-line { position: absolute; top: 0; bottom: 0; width: 1px; background: var(--bs-border-color-translucent, #e8ecef); pointer-events: none; }
            .pmk-lht-tick-label { position: absolute; top: .45rem; transform: translateX(-50%); white-space: nowrap; color: var(--bs-secondary-color, #6c757d); font-size: .7rem; }
            .pmk-lht-tick-label.first { transform: none; }
            .pmk-lht-tick-label.last { transform: translateX(-100%); }
            .pmk-lht-row { min-height: 56px; border-bottom: 1px solid var(--bs-border-color-translucent, #eef1f4); }
            .pmk-lht-row-label { min-width: 0; padding: .45rem .65rem .4rem 0; }
            .pmk-lht-row-main, .pmk-lht-row-sub { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .pmk-lht-row-main { font-size: .83rem; font-weight: 600; }
            .pmk-lht-row-sub { margin-top: .1rem; color: var(--bs-secondary-color, #6c757d); font-size: .7rem; }
            .pmk-lht-track { position: relative; min-height: 56px; background-image: linear-gradient(to bottom, transparent 27px, var(--bs-border-color-translucent, #eff2f4) 28px, transparent 29px); }
            .pmk-lht-event { position: absolute; top: 17px; height: 22px; min-width: 5px; cursor: pointer; }
            .pmk-lht-event-line { position: absolute; inset: 8px 0 auto; height: 5px; border-radius: 1rem; background: var(--pmk-lht-primary); opacity: .92; }
            .pmk-lht-event.cross .pmk-lht-event-line { background: var(--pmk-lht-cross); }
            .pmk-lht-event.current .pmk-lht-event-line { background: repeating-linear-gradient(90deg,var(--pmk-lht-primary) 0 8px,transparent 8px 12px); }
            .pmk-lht-event-start, .pmk-lht-event-end {
                position: absolute; top: 4px; width: 12px; height: 12px;
                border: 2px solid var(--bs-body-bg, #fff); border-radius: 50%;
                background: var(--pmk-lht-primary); box-shadow: 0 0 0 1px var(--pmk-lht-primary);
            }
            .pmk-lht-event-start { left: -5px; }
            .pmk-lht-event-end { right: -5px; }
            .pmk-lht-event.cross .pmk-lht-event-end { background: var(--pmk-lht-cross); box-shadow: 0 0 0 1px var(--pmk-lht-cross); }
            .pmk-lht-event.current .pmk-lht-event-end {
                width: 0; height: 0; top: 2px; right: -3px; border-radius: 0;
                border-top: 8px solid transparent; border-bottom: 8px solid transparent;
                border-left: 10px solid var(--pmk-lht-primary); border-right: 0; background: transparent; box-shadow: none;
            }
            .pmk-lht-renewal { position: absolute; top: -7px; transform: translateX(-50%); color: var(--pmk-lht-renewal); font-size: .78rem; font-weight: 800; line-height: 1; }
            .pmk-lht-event-site { position: absolute; top: 20px; white-space: nowrap; color: var(--bs-secondary-color, #6c757d); font-size: .64rem; }
            .pmk-lht-event-site.start { left: -4px; }
            .pmk-lht-event-site.end { right: -4px; text-align: right; }
            .pmk-lht-event-warning { position: absolute; top: -8px; right: -8px; font-size: .7rem; }
            .pmk-lht-point { position: absolute; top: 7px; width: 14px; height: 14px; transform: translateX(-50%); border: 2px solid var(--bs-body-bg, #fff); border-radius: 50%; box-shadow: 0 0 0 1px currentColor; cursor: pointer; z-index: 3; }
            .pmk-lht-point.acquisition { color: var(--pmk-lht-acquisition); background: var(--pmk-lht-acquisition); }
            .pmk-lht-point.transfer { color: var(--pmk-lht-transfer); background: var(--pmk-lht-transfer); border-radius: 3px; transform: translateX(-50%) rotate(45deg); }
            .pmk-lht-point.seen { color: var(--pmk-lht-seen); background: var(--pmk-lht-seen); }
            .pmk-lht-point.cancelled { color: var(--pmk-lht-cancelled); background: var(--pmk-lht-cancelled); }
            .pmk-lht-empty, .pmk-lht-limit { padding: .8rem 1rem; color: var(--bs-secondary-color, #6c757d); font-size: .82rem; }
            .pmk-lht-limit { border-top: 1px solid var(--bs-border-color-translucent, #eef1f4); background: var(--bs-tertiary-bg, #fafbfc); }
            .pmk-lht-tooltip {
                position: fixed; z-index: 1090; max-width: min(330px, calc(100vw - 24px)); pointer-events: none;
                border: 1px solid rgba(20,32,42,.15); border-radius: .35rem; background: rgba(30,39,47,.96); color: #fff;
                padding: .45rem .6rem; box-shadow: 0 .35rem 1rem rgba(0,0,0,.2); font-size: .76rem; line-height: 1.4; white-space: pre-line;
            }
            .pmk-lht-tooltip[hidden] { display: none !important; }
            .${RETURN_INFO_CLASS} { margin-top: .2rem; color: var(--bs-secondary-color, #5c6770); font-size: .84em; line-height: 1.25; }
            .${RETURN_INFO_CLASS} strong { color: var(--pmk-lht-primary, ${config.primaryColor}); font-weight: 600; }
            .${RETURN_INFO_CLASS}::before { content: "↳ "; color: var(--bs-secondary-color, #6c757d); }
            @media (max-width: 900px) {
                .pmk-lht-summary { grid-template-columns: repeat(2, minmax(110px, 1fr)); }
                .pmk-lht-header { align-items: center; }
            }
            @media (max-width: 600px) {
                .pmk-lht-header { padding: .65rem .75rem; }
                .pmk-lht-summary { grid-template-columns: 1fr 1fr; padding: .65rem .75rem .2rem; }
                .pmk-lht-toolbar { padding: .55rem .75rem .65rem; align-items: stretch; }
                .pmk-lht-filter, .pmk-lht-toolbar-right { max-width: none; width: 100%; }
                .pmk-lht-toolbar-right { justify-content: flex-start; }
                .pmk-lht-scroll { padding-inline: .75rem; }
                .pmk-lht-event-site { display: none; }
            }
            @media (max-width: 420px) {
                .pmk-lht-summary { grid-template-columns: 1fr; }
                .pmk-lht-filter { flex-wrap: wrap; }
                .pmk-lht-filter .btn { width: 100%; }
            }
        `;
    }

    function getPanelTitleKey() {
        return state.page.kind === "reader" ? "panelTitleReader" : "panelTitleBiblio";
    }

    function getPanelSubtitleKey() {
        return state.page.kind === "reader" ? "panelSubtitleReader" : "panelSubtitleBiblio";
    }

    function buildLegend() {
        const legend = createEl("div", "pmk-lht-legend");
        function addLine(className, label) {
            const item = createEl("span", "pmk-lht-legend-item");
            item.append(createEl("span", "pmk-lht-line " + className), document.createTextNode(label));
            legend.appendChild(item);
        }
        function addDot(className, label) {
            const item = createEl("span", "pmk-lht-legend-item");
            const dot = createEl("span", "pmk-lht-dot");
            if (className === "acquisition") dot.style.background = state.config.acquisitionColor;
            if (className === "transfer") dot.style.background = state.config.transferColor;
            if (className === "seen") dot.style.background = state.config.lastSeenColor;
            item.append(dot, document.createTextNode(label));
            legend.appendChild(item);
        }
        addLine("", cfgText("legendCompletedLabel"));
        addLine("current", cfgText("legendCurrentLabel"));
        if (state.config.highlightCrossLibraryReturns) addLine("cross", cfgText("legendCrossLabel"));
        if (state.config.showRenewals) {
            const item = createEl("span", "pmk-lht-legend-item", "↻ " + cfgText("legendRenewalLabel"));
            legend.appendChild(item);
        }
        if (state.page.kind === "biblio") {
            if (state.config.showAcquisition) addDot("acquisition", cfgText("legendAcquisitionLabel"));
            if (state.config.showTransfers && Number(state.config.transferReportId) > 0) addDot("transfer", cfgText("legendTransferLabel"));
            if (state.config.showLastSeen) addDot("seen", cfgText("legendLastSeenLabel"));
        }
        return legend;
    }

    function ensureTooltip() {
        if (state.tooltip && document.body.contains(state.tooltip)) return state.tooltip;
        const tooltip = createEl("div", "pmk-lht-tooltip");
        tooltip.hidden = true;
        tooltip.setAttribute("role", "tooltip");
        document.body.appendChild(tooltip);
        state.tooltip = tooltip;
        return tooltip;
    }

    function hideTooltip() {
        const tooltip = ensureTooltip();
        tooltip.hidden = true;
    }

    function moveTooltip(event) {
        const tooltip = ensureTooltip();
        if (tooltip.hidden) return;
        const margin = 12;
        const rect = tooltip.getBoundingClientRect();
        let x = Number(event.clientX || 0) + 12;
        let y = Number(event.clientY || 0) + 12;
        if (x + rect.width > window.innerWidth - margin) x = Number(event.clientX || 0) - rect.width - 12;
        if (y + rect.height > window.innerHeight - margin) y = Number(event.clientY || 0) - rect.height - 12;
        tooltip.style.left = Math.max(margin, x) + "px";
        tooltip.style.top = Math.max(margin, y) + "px";
    }

    function showTooltip(event, text) {
        const tooltip = ensureTooltip();
        tooltip.textContent = text;
        tooltip.hidden = false;
        moveTooltip(event);
    }

    function bindTooltipTarget(target, text) {
        target.tabIndex = 0;
        target.setAttribute("aria-label", String(text).replace(/\n/g, ". "));
        target.addEventListener("pointerenter", function (event) { showTooltip(event, text); });
        target.addEventListener("pointermove", moveTooltip);
        target.addEventListener("pointerleave", hideTooltip);
        target.addEventListener("focus", function () {
            const rect = target.getBoundingClientRect();
            showTooltip({ clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 }, text);
        });
        target.addEventListener("blur", hideTooltip);
        target.addEventListener("click", function (event) {
            event.stopPropagation();
            const tooltip = ensureTooltip();
            if (!tooltip.hidden && tooltip.textContent === text) hideTooltip();
            else showTooltip(event, text);
        });
    }

    function createTimelinePanel(rows) {
        const panel = createEl("section", "page-section pmk-lht-panel");
        panel.id = state.page.kind === "reader" ? PANEL_ID_READER : PANEL_ID_BIBLIO;
        panel.dataset.pmkModule = MODULE_ID;
        panel.dataset.pmkPage = state.page.id;

        const header = createEl("div", "pmk-lht-header");
        const titleWrap = createEl("div", "pmk-lht-title-wrap");
        titleWrap.append(
            createEl("h3", "pmk-lht-title", cfgText(getPanelTitleKey())),
            createEl("div", "pmk-lht-subtitle", cfgText(getPanelSubtitleKey()))
        );
        const headerActions = createEl("div", "pmk-lht-header-actions");
        let collapse = null;
        if (state.config.showCollapseButton) {
            collapse = createEl("button", "btn btn-sm btn-outline-secondary pmk-lht-collapse", cfgText("hideLabel"));
            collapse.type = "button";
            collapse.setAttribute("aria-expanded", "true");
            headerActions.appendChild(collapse);
        }
        header.append(titleWrap, headerActions);

        const body = createEl("div", "pmk-lht-body");
        const en=detectLanguage(state.config)==='en';
        const provenance=createEl('details','pmk-lht-provenance');
        provenance.appendChild(createEl('summary','',en?'Sources and scope':'Sources et périmètre'));
        provenance.appendChild(createEl('p','',en
            ? rows.length+' loans read from the currently loaded Koha table rows. Filters, pagination and unreadable dates can limit this view. API data enriches these loans; this is not a complete circulation audit.'
            : rows.length+' prêts reconnus dans les lignes actuellement chargées du tableau Koha. Les filtres, la pagination et les dates illisibles peuvent limiter cette vue. Les API complètent ces prêts ; cet affichage ne constitue pas un audit complet de la circulation.'));
        const statuses=en?{complete:'loaded',partial:'partially loaded',unavailable:'unavailable','not-configured':'report not configured'}:{complete:'chargées',partial:'chargement partiel',unavailable:'indisponibles','not-configured':'rapport non configuré'};
        for(const [key,source] of Object.entries(state.sourceReads)) {
            const label=key==='libraries'?(en?'Library names':'Noms des sites'):key==='transfers'?(en?'Transfer report':'Rapport de transferts'):key.includes('checkouts')?(en?'Loan API':'API des prêts'):(en?'Item API':'API des exemplaires');
            provenance.appendChild(createEl('div','',label+' : '+(statuses[source.status]||source.status)+' ('+source.count+').'));
        }
        if(!state.config.enrichWithApi)provenance.appendChild(createEl('p','',en?'API enrichment is disabled.':'L’enrichissement par API est désactivé.'));
        body.appendChild(provenance);
        const summary = createEl("div", "pmk-lht-summary");
        const toolbar = createEl("div", "pmk-lht-toolbar");
        const scroll = createEl("div", "pmk-lht-scroll");
        const chart = createEl("div", "pmk-lht-chart");
        scroll.appendChild(chart);

        const filter = createEl("div", "pmk-lht-filter");
        const filterInput = createEl("input", "form-control form-control-sm pmk-lht-filter-input");
        filterInput.type = "search";
        filterInput.placeholder = cfgText("filterPlaceholder");
        filterInput.setAttribute("aria-label", cfgText("filterPlaceholder"));
        const filterClear = createEl("button", "btn btn-sm btn-outline-secondary pmk-lht-filter-clear", cfgText("clearFilterLabel"));
        filterClear.type = "button";
        filterClear.hidden = true;
        filter.append(filterInput, filterClear);

        const toolbarRight = createEl("div", "pmk-lht-toolbar-right");
        const ranges = createEl("div", "pmk-lht-ranges");
        [
            ["auto", "rangeAutoLabel"],
            ["6m", "range6mLabel"],
            ["1y", "range1yLabel"],
            ["3y", "range3yLabel"],
            ["all", "rangeAllLabel"]
        ].forEach(function (entry) {
            const button = createEl("button", "btn btn-sm btn-outline-secondary", cfgText(entry[1]));
            button.type = "button";
            button.dataset.range = entry[0];
            ranges.appendChild(button);
        });
        toolbarRight.appendChild(ranges);
        if (state.config.showLegend) toolbarRight.appendChild(buildLegend());
        if (state.config.showFilter) toolbar.append(filter, toolbarRight);
        else toolbar.appendChild(toolbarRight);

        if (state.config.showSummary) body.appendChild(summary);
        body.append(toolbar, scroll);
        panel.append(header, body);

        let currentRange = ["auto", "6m", "1y", "3y", "all"].includes(state.config.defaultRange)
            ? state.config.defaultRange
            : "auto";

        function rowMatchesFilter(row, query) {
            if (!query) return true;
            return normalizeText([
                row.title,
                row.barcode,
                row.itemId,
                row.checkoutSite,
                row.checkoutSiteCode,
                row.returnSite,
                row.returnSiteCode
            ].filter(Boolean).join(" ")).includes(query);
        }

        function renderSummary(filteredRows) {
            if (!state.config.showSummary) return;
            summary.replaceChildren();
            summaryValues(filteredRows).forEach(function (entry) {
                const card = createEl("div", "pmk-lht-card");
                card.append(
                    createEl("span", "pmk-lht-card-value", entry[0]),
                    createEl("span", "pmk-lht-card-label", entry[1])
                );
                summary.appendChild(card);
            });
        }

        function render(rangeKey) {
            currentRange = rangeKey || currentRange;
            chart.replaceChildren();
            hideTooltip();

            ranges.querySelectorAll("button[data-range]").forEach(function (button) {
                button.classList.toggle("is-active", button.dataset.range === currentRange);
                button.setAttribute("aria-pressed", button.dataset.range === currentRange ? "true" : "false");
            });

            const query = normalizeText(filterInput.value);
            const filteredRows = rows.filter(function (row) { return rowMatchesFilter(row, query); });
            filterClear.hidden = !query;
            renderSummary(filteredRows);

            const rangeBase = filteredRows.length ? filteredRows : rows;
            const range = computeRange(currentRange, rangeBase);
            const groups = groupRows(filteredRows, range);
            const ticks = makeTicks(range, 6);

            const axis = createEl("div", "pmk-lht-axis");
            axis.appendChild(createEl("div", "pmk-lht-axis-label", state.page.kind === "reader" ? cfgText("axisDocumentLabel") : cfgText("axisItemLabel")));
            const axisTrack = createEl("div", "pmk-lht-axis-track");
            ticks.forEach(function (tick, index) {
                const pct = positionPct(tick, range);
                const line = createEl("div", "pmk-lht-tick");
                line.style.left = pct + "%";
                axisTrack.appendChild(line);
                const label = createEl("div", "pmk-lht-tick-label", formatAxisDate(tick, currentRange));
                label.style.left = pct + "%";
                if (index === 0) label.classList.add("first");
                if (index === ticks.length - 1) label.classList.add("last");
                axisTrack.appendChild(label);
            });
            axis.appendChild(axisTrack);
            chart.appendChild(axis);

            if (!groups.length) {
                chart.appendChild(createEl("div", "pmk-lht-empty", query ? cfgText("emptyFilterLabel") : cfgText("emptyPeriodLabel")));
                return;
            }

            groups.forEach(function (group) {
                const rowEl = createEl("div", "pmk-lht-row");
                const label = createEl("div", "pmk-lht-row-label");
                label.append(
                    createEl("span", "pmk-lht-row-main", group.main),
                    createEl("span", "pmk-lht-row-sub", group.sub)
                );
                const track = createEl("div", "pmk-lht-track");
                ticks.forEach(function (tick) {
                    const grid = createEl("div", "pmk-lht-grid-line");
                    grid.style.left = positionPct(tick, range) + "%";
                    track.appendChild(grid);
                });

                group.events.forEach(function (loan) {
                    const visualStart = loan.start < range.start ? range.start : loan.start;
                    const rawEnd = loan.end || new Date();
                    const visualEnd = rawEnd > range.end ? range.end : rawEnd;
                    const left = positionPct(visualStart, range);
                    const right = positionPct(visualEnd, range);
                    const width = Math.max(.55, right - left);
                    const event = createEl("div", "pmk-lht-event");
                    event.style.left = left + "%";
                    event.style.width = width + "%";
                    if (loan.current) event.classList.add("current");
                    if (state.config.highlightCrossLibraryReturns && isCrossLibrary(loan)) event.classList.add("cross");
                    event.append(
                        createEl("span", "pmk-lht-event-line"),
                        createEl("span", "pmk-lht-event-start"),
                        createEl("span", "pmk-lht-event-end")
                    );

                    const startSite = loan.checkoutSiteCode || loan.checkoutSite;
                    const endSite = loan.returnSiteCode || loan.returnSite;
                    if (startSite) event.appendChild(createEl("span", "pmk-lht-event-site start", startSite));
                    if (endSite && !loan.current && width >= 4) event.appendChild(createEl("span", "pmk-lht-event-site end", endSite));

                    if (state.config.showRenewals && loan.renewalsCount > 0) {
                        const renewal = createEl("span", "pmk-lht-renewal", loan.renewalsCount > 1 ? "↻" + loan.renewalsCount : "↻");
                        if (loan.lastRenewedDate && loan.lastRenewedDate >= visualStart && loan.lastRenewedDate <= visualEnd) {
                            const globalPct = positionPct(loan.lastRenewedDate, range);
                            const localPct = width > 0 ? ((globalPct - left) / width) * 100 : 50;
                            renewal.style.left = Math.max(0, Math.min(100, localPct)) + "%";
                        } else renewal.style.left = "50%";
                        event.appendChild(renewal);
                    }
                    if (state.config.highlightCrossLibraryReturns && isCrossLibrary(loan)) {
                        event.appendChild(createEl("span", "pmk-lht-event-warning", "⚠"));
                    }
                    bindTooltipTarget(event, buildLoanTooltip(loan));
                    track.appendChild(event);
                });

                if (state.page.kind === "biblio" && Array.isArray(group.points)) {
                    group.points.forEach(function (point) {
                        if (point.date < range.start || point.date > range.end) return;
                        if (point.type === "acquisition" && !state.config.showAcquisition) return;
                        if (point.type === "seen" && !state.config.showLastSeen) return;
                        if ((point.type === "transfer" || point.type === "cancelled") && !state.config.showTransfers) return;
                        const marker = createEl("span", "pmk-lht-point " + point.type);
                        marker.style.left = positionPct(point.date, range) + "%";
                        bindTooltipTarget(marker, buildPointTooltip(point));
                        track.appendChild(marker);
                    });
                }

                rowEl.append(label, track);
                chart.appendChild(rowEl);
            });

            if (state.page.kind === "reader") {
                const totalVisible = filteredRows.filter(function (row) { return rowIntersects(row, range); }).length;
                const limit = Math.max(1, Number(state.config.maxReaderRows || 120));
                if (totalVisible > limit) {
                    chart.appendChild(createEl(
                        "div",
                        "pmk-lht-limit",
                        replaceTokens(cfgText("limitNoteLabel"), { limit: limit, total: totalVisible })
                    ));
                }
            }
        }

        ranges.addEventListener("click", function (event) {
            const button = event.target.closest("button[data-range]");
            if (!button) return;
            render(button.dataset.range);
        });
        filterInput.addEventListener("input", function () { render(currentRange); });
        filterClear.addEventListener("click", function () {
            filterInput.value = "";
            filterInput.focus();
            render(currentRange);
        });
        if (collapse) {
            collapse.addEventListener("click", function () {
                body.hidden = !body.hidden;
                collapse.textContent = body.hidden ? cfgText("showLabel") : cfgText("hideLabel");
                collapse.setAttribute("aria-expanded", body.hidden ? "false" : "true");
            });
        }

        const params = new URLSearchParams(window.location.search);
        const requestedBarcode = cleanText(params.get("krt_barcode") || params.get("pmk_barcode") || "");
        const requestedItem = cleanText(params.get("krt_itemnumber") || params.get("pmk_itemnumber") || "");
        if (state.page.kind === "biblio" && (requestedBarcode || requestedItem)) {
            filterInput.value = requestedBarcode || requestedItem;
        }

        render(currentRange);
        state.panel = panel;
        window.setTimeout(function () { mountContextButton(headerActions); }, 0);
        return panel;
    }

    function findNativeTimeline() {
        if (!state.page || state.page.kind !== "biblio") return null;
        const candidates = Array.from(document.querySelectorAll(".searchresults .timeline-container-wrapper"));
        return candidates.find(function (el) {
            return !el.closest(".pmk-lht-panel") && !el.dataset.pmkModule;
        }) || null;
    }

    function hideNativeTimelineIfConfigured() {
        const native = findNativeTimeline();
        if (!native) return;
        if (state.config.hideNativeIssuehistoryTimeline) {
            if (!native.hasAttribute("data-pmk-lht-original-display")) {
                native.setAttribute("data-pmk-lht-original-display", native.style.display || "");
            }
            native.dataset.pmkLhtHidden = "1";
            native.style.display = "none";
        } else if (native.dataset.pmkLhtHidden === "1") {
            native.style.display = native.getAttribute("data-pmk-lht-original-display") || "";
            delete native.dataset.pmkLhtHidden;
        }
    }

    function restoreNativeTimeline() {
        document.querySelectorAll('[data-pmk-lht-hidden="1"]').forEach(function (native) {
            native.style.display = native.getAttribute("data-pmk-lht-original-display") || "";
            delete native.dataset.pmkLhtHidden;
        });
    }

    function insertPanel(panel, table) {
        if (!panel || !table) return false;
        if (state.page.kind === "biblio") {
            const native = findNativeTimeline();
            if (native && native.parentNode) {
                native.parentNode.insertBefore(panel, native);
                hideNativeTimelineIfConfigured();
                return true;
            }
        }
        const wrapper = table.closest(".dt-container") || table.closest(".page-section") || table.closest(".dataTables_wrapper") || table;
        wrapper.insertAdjacentElement("afterend", panel);
        return true;
    }

    function removePanel() {
        document.getElementById(PANEL_ID_BIBLIO)?.remove();
        document.getElementById(PANEL_ID_READER)?.remove();
        state.panel = null;
        if (state.tooltip) {
            state.tooltip.remove();
            state.tooltip = null;
        }
    }

    function unbindDataTable() {
        if (!state.table || !window.jQuery || !window.jQuery.fn || !window.jQuery.fn.dataTable) return;
        try {
            window.jQuery(state.table).off("draw.dt.pmkLoanHistoryTimeline");
        } catch (_) {}
        state.drawBound = false;
    }

    function bindDataTable() {
        if (!state.table || !window.jQuery || !window.jQuery.fn || !window.jQuery.fn.dataTable) return;
        try {
            window.jQuery(state.table)
                .off("draw.dt.pmkLoanHistoryTimeline")
                .on("draw.dt.pmkLoanHistoryTimeline", function () {
                    scheduleRefresh(80);
                });
            state.drawBound = true;
        } catch (_) {}
    }

    function scheduleRefresh(delay) {
        if (state.refreshTimer) window.clearTimeout(state.refreshTimer);
        state.refreshTimer = window.setTimeout(function () {
            state.refreshTimer = null;
            refreshFromDom();
        }, Number.isFinite(Number(delay)) ? Number(delay) : 80);
    }

    function refreshFromDom() {
        if (!state.table || !state.page || !state.config || !isPageEnabled(state.config, state.page)) return;
        const rows = parseRows(state.table, state.page);
        if (!rows.length) { state.rows=[]; removePanel(); return; }
        state.rows = rows;
        enrichRows(state.rows, state.apiCheckouts, state.libraries);
        annotateReturnCells(state.rows);
        removePanel();
        const panel = createTimelinePanel(state.rows);
        insertPanel(panel, state.table);
    }

    function mountContextButton(anchor) {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (!anchor) return;
        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: anchor,
            position: "inside",
            contextKey: state.page ? state.page.id : "timeline",
            context: {
                pageId: state.page ? state.page.id : null,
                sectionId: state.page && state.page.kind === "reader" ? "page-readingrec" : "page-issuehistory"
            }
        });
    }

    function detectExisting128Timeline() {
        return Boolean(
            document.getElementById("krt-biblio-timeline") ||
            document.getElementById("krt-reader-timeline")
        );
    }

    function destroyRuntime(options) {
        const opts = options || {};
        if (state.refreshTimer) {
            window.clearTimeout(state.refreshTimer);
            state.refreshTimer = null;
        }
        unbindDataTable();
        removePanel();
        clearReturnAnnotations();
        if (!opts.keepNativeHidden) restoreNativeTimeline();
        state.table = null;
        state.rows = [];
        state.apiCheckouts = [];
        state.sourceReads = {};
        state.lifeByItem = new Map();
        state.blockedByExistingTimeline = false;
        window[GLOBAL_GUARD].runtime = { active: false };
    }

    async function initializeFunctionalPage(config) {
        state.page = detectPage();
        state.config = deepMerge(DEFAULT_CONFIG, config || {});
        injectStyles();

        if (!state.page || !isPageEnabled(state.config, state.page)) {
            destroyRuntime();
            return;
        }

        /*
         * Migration douce : si le 128 a déjà rendu sa timeline avant nous,
         * on ne détruit pas sa vue ni ses gestionnaires. Dans l'ordre de
         * chargement recommandé, 008 est placé avant 128 et revendique le
         * guard de compatibilité après initialisation, ce qui évite le doublon.
         */
        if (detectExisting128Timeline() && !state.legacyGuardClaimed) {
            state.blockedByExistingTimeline = true;
            window[GLOBAL_GUARD].runtime = {
                active: false,
                reason: "legacy-128-already-active",
                pageId: state.page.id
            };
            return;
        }

        const table = await waitForTable(state.page.tableSelector, 12000);
        if (!table) {
            destroyRuntime();
            window[GLOBAL_GUARD].runtime = { active: false, reason: "table-not-found", pageId: state.page.id };
            return;
        }

        const rows = parseRows(table, state.page);
        if (!rows.length) {
            destroyRuntime();
            window[GLOBAL_GUARD].runtime = { active: false, reason: "columns-or-rows-not-recognized", pageId: state.page.id };
            return;
        }

        destroyRuntime({ keepNativeHidden: true });
        state.page = detectPage();
        state.config = deepMerge(DEFAULT_CONFIG, config || {});
        state.table = table;
        state.rows = rows;
        injectStyles();

        state.libraries = state.config.enrichWithApi ? await loadLibraries() : { byCode: new Map(), byName: new Map() };
        state.apiCheckouts = await loadHistoricalCheckouts(state.page);
        enrichRows(state.rows, state.apiCheckouts, state.libraries);

        if (state.page.kind === "biblio") {
            const items = await loadBiblioItems(state.page);
            const transfers = await loadBiblioTransfers(state.page);
            state.lifeByItem = buildLifeByItem(items, transfers, state.libraries);
        } else {
            state.lifeByItem = new Map();
        }

        annotateReturnCells(state.rows);
        const panel = createTimelinePanel(state.rows);
        if (!insertPanel(panel, state.table)) {
            destroyRuntime();
            return;
        }
        bindDataTable();

        /* Compatibilité avec le 128 chargé plus tard dans l'ancien loader. */
        window[LEGACY_128_GUARD] = true;
        state.legacyGuardClaimed = true;

        window[GLOBAL_GUARD].initialized = true;
        window[GLOBAL_GUARD].runtime = {
            active: true,
            pageId: state.page.id,
            rows: state.rows.length,
            apiEnriched: state.apiCheckouts.length > 0,
            moduleId: MODULE_ID,
            version: MODULE_VERSION
        };
    }

    async function applyConfig(config) {
        const merged = deepMerge(DEFAULT_CONFIG, config || {});
        state.config = merged;
        await initializeFunctionalPage(merged);
    }

    function validateModuleConfig(config) {
        if (!config || typeof config !== "object") {
            return { ok: false, message: "Configuration invalide / Invalid configuration." };
        }
        const language = String(config.language || "auto").toLowerCase();
        if (!["auto", "fr", "en"].includes(language)) {
            return { ok: false, message: language === "fr" ? "Langue invalide." : "Invalid language." };
        }
        if (!["auto", "6m", "1y", "3y", "all"].includes(String(config.defaultRange || "auto"))) {
            return { ok: false, message: detectLanguage(config) === "fr" ? "Période initiale invalide." : "Invalid default range." };
        }
        const maxReaderRows = Number(config.maxReaderRows);
        if (!Number.isInteger(maxReaderRows) || maxReaderRows < 10 || maxReaderRows > 1000) {
            return { ok: false, message: detectLanguage(config) === "fr" ? "Le nombre maximal de prêts lecteur doit être compris entre 10 et 1000." : "Maximum patron loans must be between 10 and 1000." };
        }
        const reportId = Number(config.transferReportId || 0);
        if (!Number.isInteger(reportId) || reportId < 0) {
            return { ok: false, message: detectLanguage(config) === "fr" ? "L’identifiant du rapport de transferts doit être 0 ou un entier positif." : "Transfer report ID must be 0 or a positive integer." };
        }
        [
            "primaryColor", "crossLibraryColor", "renewalColor", "acquisitionColor",
            "transferColor", "lastSeenColor", "cancelledColor"
        ].forEach(function (key) {
            if (!/^#[0-9a-f]{6}$/i.test(String(config[key] || ""))) {
                throw Object.assign(new Error("invalid_color"), { configKey: key });
            }
        });

        const labelKeys = Object.keys(DEFAULT_CONFIG).filter(function (key) {
            return /(?:LabelFr|LabelEn|TitleBiblioFr|TitleBiblioEn|SubtitleBiblioFr|SubtitleBiblioEn|TitleReaderFr|TitleReaderEn|SubtitleReaderFr|SubtitleReaderEn)$/.test(key);
        });
        for (const key of labelKeys) {
            if (!String(config[key] == null ? "" : config[key]).trim()) {
                return { ok: false, message: detectLanguage(config) === "fr" ? "Les libellés français et anglais ne peuvent pas être vides." : "French and English labels cannot be empty." };
            }
        }
        return { ok: true };
    }

    function safeValidate(config) {
        try {
            return validateModuleConfig(config);
        } catch (_) {
            return {
                ok: false,
                message: detectLanguage(config) === "fr"
                    ? "Les couleurs doivent utiliser le format #RRGGBB."
                    : "Colors must use the #RRGGBB format."
            };
        }
    }

    function labelPairFields(baseKey, labelFr, labelEn, help) {
        return [
            {
                key: baseKey + "Fr",
                type: "text",
                label: { fr: labelFr + " — français", en: labelEn + " — French" },
                help: help || undefined
            },
            {
                key: baseKey + "En",
                type: "text",
                label: { fr: labelFr + " — anglais", en: labelEn + " — English" },
                help: help || undefined
            }
        ];
    }

    function moduleDefinition() {
        const schema = [
            {
                type: "section",
                id: "general",
                label: { fr: "Général", en: "General" },
                description: {
                    fr: "Réglages communs au module Historique des prêts et des retours. L’affichage reste un complément au tableau Koha.",
                    en: "Settings shared by the Circulation history module. The timeline remains an enhancement to the Koha table."
                },
                fields: [
                    { key: "enabled", type: "boolean", label: { fr: "Module actif", en: "Module enabled" } },
                    {
                        key: "language",
                        type: "select",
                        label: { fr: "Langue de l’interface ajoutée", en: "Language of the added interface" },
                        options: [
                            { value: "auto", label: { fr: "Automatique — suivre Koha", en: "Automatic — follow Koha" } },
                            { value: "fr", label: { fr: "Français", en: "French" } },
                            { value: "en", label: { fr: "Anglais", en: "English" } }
                        ]
                    },
                    {
                        key: "defaultRange",
                        type: "select",
                        label: { fr: "Période affichée au départ", en: "Default displayed range" },
                        options: [
                            { value: "auto", label: { fr: "Automatique — tout si ≤ 3 ans, sinon 3 ans", en: "Automatic — all if ≤ 3 years, otherwise 3 years" } },
                            { value: "6m", label: { fr: "6 mois", en: "6 months" } },
                            { value: "1y", label: { fr: "1 an", en: "1 year" } },
                            { value: "3y", label: { fr: "3 ans", en: "3 years" } },
                            { value: "all", label: { fr: "Tout", en: "All" } }
                        ]
                    },
                    { key: "showSummary", type: "boolean", label: { fr: "Afficher le résumé chiffré", en: "Show summary cards" } },
                    { key: "showFilter", type: "boolean", label: { fr: "Afficher le filtre", en: "Show filter" } },
                    { key: "showLegend", type: "boolean", label: { fr: "Afficher la légende", en: "Show legend" } },
                    { key: "showCollapseButton", type: "boolean", label: { fr: "Permettre de replier la timeline", en: "Allow timeline collapse" } }
                ]
            },
            {
                type: "section",
                id: "pages",
                label: { fr: "Pages configurées", en: "Configured pages" },
                description: {
                    fr: "Les deux adaptateurs partagent la même configuration du module. Les chemins sont informatifs et ne sont pas modifiables.",
                    en: "Both adapters share the same module configuration. Paths are informative and are not editable."
                },
                fields: [
                    {
                        type: "section",
                        id: "page-issuehistory",
                        label: { fr: "Historique d’une notice", en: "Bibliographic record loan history" },
                        fields: [
                            { key: "issuehistoryEnabled", type: "boolean", label: { fr: "Actif sur cette page", en: "Enabled on this page" } },
                            { key: "issuehistoryPathInfo", type: "readonly", label: { fr: "Page Koha", en: "Koha page" }, default: PAGE_DEFINITIONS["catalogue.issuehistory"].path },
                            { key: "hideNativeIssuehistoryTimeline", type: "boolean", label: { fr: "Masquer la timeline native de Koha lorsqu’elle existe", en: "Hide Koha's native timeline when present" } },
                            { key: "showAcquisition", type: "boolean", label: { fr: "Afficher l’acquisition", en: "Show acquisition" } },
                            { key: "showLastSeen", type: "boolean", label: { fr: "Afficher la dernière activité connue", en: "Show last known activity" } },
                            { key: "showTransfers", type: "boolean", label: { fr: "Afficher les transferts historiques", en: "Show historical transfers" } },
                            {
                                key: "transferReportSetupFr",
                                type: "readonly",
                                label: { fr: "Installation du rapport SQL", en: "SQL report setup" },
                                when: function (root) { return root.showTransfers === true && detectLanguage(root) !== "en"; }
                            },
                            {
                                key: "transferReportSetupEn",
                                type: "readonly",
                                label: { fr: "Installation du rapport SQL", en: "SQL report setup" },
                                when: function (root) { return root.showTransfers === true && detectLanguage(root) === "en"; }
                            },
                            {
                                key: "transferReportSql",
                                type: "readonly",
                                code: true,
                                copyable: true,
                                label: { fr: "SQL à copier-coller dans le rapport guidé Koha", en: "SQL to copy into the Koha guided report" },
                                when: function (root) { return root.showTransfers === true; }
                            },
                            {
                                key: "transferReportId",
                                type: "number",
                                min: 0,
                                step: 1,
                                label: { fr: "ID du rapport SQL des transferts", en: "Transfer SQL report ID" },
                                help: { fr: "Après avoir créé le rapport ci-dessus, saisis ici son numéro Koha. 0 = désactivé.", en: "After creating the report above, enter its Koha report number here. 0 = disabled." },
                                when: function (root) { return root.showTransfers === true; }
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "page-readingrec",
                        label: { fr: "Historique d’un lecteur", en: "Patron circulation history" },
                        fields: [
                            { key: "readingrecEnabled", type: "boolean", label: { fr: "Actif sur cette page", en: "Enabled on this page" } },
                            { key: "readingrecPathInfo", type: "readonly", label: { fr: "Page Koha", en: "Koha page" }, default: PAGE_DEFINITIONS["members.readingrec"].path },
                            { key: "maxReaderRows", type: "number", min: 10, max: 1000, step: 10, label: { fr: "Nombre maximal de prêts affichés", en: "Maximum displayed loans" } }
                        ]
                    }
                ]
            },
            {
                type: "section",
                id: "data",
                label: { fr: "Données et enrichissements", en: "Data and enrichments" },
                description: {
                    fr: "La timeline fonctionne d’abord avec le tableau Koha. Les API ajoutent les sites de retour, renouvellements et événements d’exemplaire lorsqu’ils sont accessibles.",
                    en: "The timeline first works from the Koha table. APIs add check-in libraries, renewals and item events when available."
                },
                fields: [
                    { key: "enrichWithApi", type: "boolean", label: { fr: "Enrichir avec les API Koha", en: "Enrich with Koha APIs" } },
                    { key: "showReturnLibraryInTable", type: "boolean", label: { fr: "Afficher le lieu de retour dans le tableau Koha", en: "Show check-in library in the Koha table" } },
                    { key: "showRenewals", type: "boolean", label: { fr: "Afficher les renouvellements", en: "Show renewals" } },
                    { key: "highlightCrossLibraryReturns", type: "boolean", label: { fr: "Signaler les retours dans un autre site", en: "Highlight returns at another library" } }
                ]
            },
            {
                type: "section",
                id: "appearance",
                label: { fr: "Couleurs", en: "Colors" },
                description: {
                    fr: "Les valeurs par défaut sont sobres et compatibles avec l’interface Koha. Elles peuvent être adaptées à la charte locale.",
                    en: "Default colors are deliberately restrained and Koha-friendly. They can be adapted to local branding."
                },
                fields: [
                    { key: "primaryColor", type: "color", label: { fr: "Prêts", en: "Loans" } },
                    { key: "crossLibraryColor", type: "color", label: { fr: "Retours inter-sites", en: "Cross-library returns" } },
                    { key: "renewalColor", type: "color", label: { fr: "Renouvellements", en: "Renewals" } },
                    { key: "acquisitionColor", type: "color", label: { fr: "Acquisitions", en: "Acquisitions" } },
                    { key: "transferColor", type: "color", label: { fr: "Transferts", en: "Transfers" } },
                    { key: "lastSeenColor", type: "color", label: { fr: "Dernière activité", en: "Last activity" } },
                    { key: "cancelledColor", type: "color", label: { fr: "Transferts annulés", en: "Cancelled transfers" } }
                ]
            }
        ];

        function pushTextSection(id, frLabel, enLabel, fields) {
            schema.push({
                type: "section",
                id: id,
                label: { fr: frLabel, en: enLabel },
                description: {
                    fr: "Tous les textes visibles sont disponibles en français et en anglais. Ils peuvent être adaptés sans modifier le JavaScript.",
                    en: "All visible texts are available in French and English and can be changed without editing JavaScript."
                },
                fields: fields
            });
        }

        pushTextSection("labels-headings", "Libellés — titres et commandes", "Labels — headings and controls", [].concat(
            labelPairFields("panelTitleBiblio", "Titre — historique notice", "Title — record history"),
            labelPairFields("panelSubtitleBiblio", "Sous-titre — historique notice", "Subtitle — record history"),
            labelPairFields("panelTitleReader", "Titre — historique lecteur", "Title — patron history"),
            labelPairFields("panelSubtitleReader", "Sous-titre — historique lecteur", "Subtitle — patron history"),
            labelPairFields("hideLabel", "Bouton Masquer", "Hide button"),
            labelPairFields("showLabel", "Bouton Afficher", "Show button"),
            labelPairFields("filterPlaceholder", "Champ de filtre", "Filter field"),
            labelPairFields("clearFilterLabel", "Bouton Effacer", "Clear button")
        ));

        pushTextSection("labels-ranges", "Libellés — périodes et légende", "Labels — ranges and legend", [].concat(
            labelPairFields("rangeAutoLabel", "Période Auto", "Auto range"),
            labelPairFields("range6mLabel", "Période 6 mois", "6-month range"),
            labelPairFields("range1yLabel", "Période 1 an", "1-year range"),
            labelPairFields("range3yLabel", "Période 3 ans", "3-year range"),
            labelPairFields("rangeAllLabel", "Période Tout", "All range"),
            labelPairFields("legendCompletedLabel", "Légende prêt terminé", "Completed-loan legend"),
            labelPairFields("legendCurrentLabel", "Légende prêt en cours", "Current-loan legend"),
            labelPairFields("legendCrossLabel", "Légende retour inter-sites", "Cross-library legend"),
            labelPairFields("legendRenewalLabel", "Légende renouvellement", "Renewal legend"),
            labelPairFields("legendAcquisitionLabel", "Légende acquisition", "Acquisition legend"),
            labelPairFields("legendTransferLabel", "Légende transfert", "Transfer legend"),
            labelPairFields("legendLastSeenLabel", "Légende dernière activité", "Last-activity legend")
        ));

        pushTextSection("labels-summary", "Libellés — axes et résumé", "Labels — axes and summary", [].concat(
            labelPairFields("axisItemLabel", "Axe exemplaire", "Item axis"),
            labelPairFields("axisDocumentLabel", "Axe document", "Document axis"),
            labelPairFields("summaryItemsBiblioLabel", "Résumé exemplaires — notice", "Item summary — record"),
            labelPairFields("summaryLoansBiblioLabel", "Résumé prêts — notice", "Loan summary — record"),
            labelPairFields("summaryLoansReaderLabel", "Résumé prêts — lecteur", "Loan summary — patron"),
            labelPairFields("summaryItemsReaderLabel", "Résumé exemplaires — lecteur", "Item summary — patron"),
            labelPairFields("summaryCurrentLabel", "Résumé prêts en cours", "Current-loan summary"),
            labelPairFields("summaryCrossLabel", "Résumé retours inter-sites", "Cross-library summary")
        ));

        pushTextSection("labels-tooltips", "Libellés — infobulles et retour", "Labels — tooltips and check-in", [].concat(
            labelPairFields("statusCurrentLabel", "Statut prêt en cours", "Current-loan status"),
            labelPairFields("statusCompletedLabel", "Statut prêt terminé", "Completed-loan status"),
            labelPairFields("tooltipCheckoutLabel", "Infobulle — prêt", "Tooltip — checkout"),
            labelPairFields("tooltipCheckoutLibraryLabel", "Infobulle — site de prêt", "Tooltip — checkout library"),
            labelPairFields("tooltipReturnLabel", "Infobulle — retour", "Tooltip — check-in"),
            labelPairFields("tooltipReturnLibraryLabel", "Infobulle — site de retour", "Tooltip — check-in library"),
            labelPairFields("tooltipDurationLabel", "Infobulle — durée", "Tooltip — duration"),
            labelPairFields("tooltipRenewalsLabel", "Infobulle — renouvellements", "Tooltip — renewals"),
            labelPairFields("tooltipLastRenewedLabel", "Infobulle — dernier renouvellement", "Tooltip — last renewal"),
            labelPairFields("tooltipCurrentReturnLabel", "Infobulle — retour en cours", "Tooltip — current return"),
            labelPairFields("tooltipCrossWarningLabel", "Avertissement retour inter-sites", "Cross-library warning"),
            labelPairFields("returnLibraryLabel", "Libellé du lieu de retour dans le tableau", "Check-in library label in table")
        ));

        pushTextSection("labels-events", "Libellés — événements d’exemplaire", "Labels — item events", [].concat(
            labelPairFields("acquisitionEventLabel", "Événement acquisition", "Acquisition event"),
            labelPairFields("lastSeenEventLabel", "Événement dernière activité", "Last-activity event"),
            labelPairFields("transferRequestedEventLabel", "Transfert demandé", "Transfer requested"),
            labelPairFields("transferSentEventLabel", "Transfert envoyé", "Transfer sent"),
            labelPairFields("transferArrivedEventLabel", "Transfert arrivé", "Transfer arrived"),
            labelPairFields("transferCancelledEventLabel", "Transfert annulé", "Transfer cancelled"),
            labelPairFields("eventDateLabel", "Champ Date", "Date field"),
            labelPairFields("eventLibraryLabel", "Champ Site", "Library field"),
            labelPairFields("eventReasonLabel", "Champ Motif", "Reason field")
        ));

        pushTextSection("labels-misc", "Libellés — messages et unités", "Labels — messages and units", [].concat(
            labelPairFields("emptyPeriodLabel", "Aucun prêt sur la période", "No loans in range"),
            labelPairFields("emptyFilterLabel", "Aucun résultat du filtre", "No filter result"),
            labelPairFields("limitNoteLabel", "Message de limitation lecteur", "Patron limit note", {
                fr: "Variables disponibles : {limit}, {total}.",
                en: "Available placeholders: {limit}, {total}."
            }),
            labelPairFields("itemPrefixLabel", "Préfixe exemplaire", "Item prefix"),
            labelPairFields("daySingularLabel", "Unité jour — singulier", "Day unit — singular"),
            labelPairFields("dayPluralLabel", "Unité jour — pluriel", "Day unit — plural")
        ));

        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr: "Historique des prêts et des retours", en: "Circulation history" },
            description: {
                fr: "Ajoute une timeline des prêts et de la vie des exemplaires sur les historiques notice et lecteur, sans remplacer les tableaux Koha.",
                en: "Adds a loan and item-life timeline to record and patron history pages without replacing Koha tables."
            },
            category: { fr: "Circulation / historiques", en: "Circulation / history" },
            supportedPages: ["catalogue.issuehistory", "members.readingrec"],
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULT_CONFIG),
            validate: safeValidate,
            schema: schema,
            focusContext: function (main, context) {
                if (!main || !context) return;
                const sectionId = context.sectionId || (
                    context.pageId === "members.readingrec" ? "page-readingrec" :
                    context.pageId === "catalogue.issuehistory" ? "page-issuehistory" : null
                );
                if (!sectionId) return;
                const section = main.querySelector('[data-pmk-section-id="' + sectionId + '"]');
                if (section) {
                    window.setTimeout(function () {
                        section.scrollIntoView({ block: "start", behavior: "smooth" });
                    }, 0);
                }
            }
        };
    }

    function registerWithCore() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        if (state.coreRegistered) return true;
        const registered = window.PMKConfig.registerModule(moduleDefinition());
        state.coreRegistered = registered !== false;
        return state.coreRegistered;
    }

    async function startWithCore() {
        if (!registerWithCore()) return;
        if (state.coreStarted) return;
        state.coreStarted = true;

        if (detectPage()) {
            try {
                const config = await window.PMKConfig.getConfig(MODULE_ID);
                await applyConfig(config);
            } catch (_) {
                await applyConfig(DEFAULT_CONFIG);
            }
        }

        if (typeof window.PMKConfig.subscribe === "function" && !state.unsubscribe) {
            state.unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
                applyConfig(newConfig);
            });
            window[GLOBAL_GUARD].unsubscribe = state.unsubscribe;
        }
    }

    async function startWithoutCore() {
        if (state.fallbackStarted || !detectPage()) return;
        state.fallbackStarted = true;
        await applyConfig(DEFAULT_CONFIG);
    }

    function onReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else callback();
    }

    document.addEventListener("click", function (event) {
        if (!state.tooltip || state.tooltip.hidden) return;
        if (event.target.closest(".pmk-lht-event, .pmk-lht-point, .pmk-lht-tooltip")) return;
        hideTooltip();
    });

    window.addEventListener("resize", hideTooltip);

    /*
     * Enregistrement PMK immédiat : la fiche doit être visible dans
     * l'administration même avant DOMContentLoaded et hors pages fonctionnelles.
     */
    if (window.PMKConfig) {
        registerWithCore();
    } else {
        window.addEventListener("pmk:config-ready", function () {
            registerWithCore();
            if (document.readyState !== "loading") startWithCore();
        }, { once: true });
    }

    onReady(function () {
        if (window.PMKConfig) {
            startWithCore();
        } else {
            startWithoutCore();
        }
    });

    window.PMK008LoanHistoryTimeline = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULT_CONFIG),
        getRuntime: function () { return deepClone(window[GLOBAL_GUARD].runtime); },
        refresh: function () { scheduleRefresh(0); },
        destroy: function () { destroyRuntime(); }
    };
})();

;window.PMKNonPlugin.loaded.push("008-issuehistory-timeline.js");
} catch (error) { window.PMKNonPlugin.errors.push("008-issuehistory-timeline.js: "+error.message); console.error("[PMK] 008-issuehistory-timeline.js",error); };
try {
/* ============================================================
   PimpMyKoha - Pré-plugin - 009 - Résumé enrichi / 4ème de couverture
   Fichier : 009-4eme-de-couv.js
   Version : 2.2.0
   Date    : 2026-09-17
   Auteur  : équipe PimpMyKoha

   Fonction :
   - détecte un résumé Electre déjà injecté dans la page détail Koha ;
   - le déplace dans un bloc repliable accessible et discret ;
   - reprend le placement historique : zone 330, sinon 215, sinon première section ;
   - conserve le résumé à son emplacement d'origine si la page n'est pas
     reconnue avec suffisamment de certitude ;
   - fonctionne seul avec ses valeurs par défaut ;
   - se connecte automatiquement à window.PMKConfig lorsqu'il est présent.

   Important : ce module NE récupère PAS le résumé auprès d'Electre.
   Il présente un contenu Electre déjà présent dans le DOM.
   ============================================================ */

(function () {
    "use strict";

    const GLOBAL_GUARD = "__PMK_009_DETAIL_FOURTH_COVER__";
    if (window[GLOBAL_GUARD]) return;

    const MODULE_ID = "detail-fourth-cover";
    const MODULE_VERSION = "2.2.0";
    const PAGE_ID = "catalogue.detail";
    const PAGE_PATH = "/cgi-bin/koha/catalogue/detail.pl";
    const WRAPPER_ID = "pmk-detail-fourth-cover";
    const BODY_ID = "pmk-detail-fourth-cover-body";
    const STYLE_ID = "pmk-detail-fourth-cover-style";
    const SOURCE_WAIT_MS = 20000;

    const SOURCE_SELECTORS = [
        "span.results_summary.electre",
        "span.results_summary.electre-resume"
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        language: "auto",
        titleFr: "4ème de couverture",
        titleEn: "Back cover",
        defaultExpanded: false,
        hideSourceLabel: true,
        placement: "historical-zone-330-215",
        targetSelector: "",
        targetPlacement: "after",
        sourceSelector: "",
        emptySourceSelector: "",
        unavailableSourceSelector: "",
        provider: "Electre",
        page: "catalogue/detail.pl — catalogue.detail",

        // Le rendu ci-dessous reprend le résultat visuel historique
        // obtenu par 009 + la couche de finition du 107.
        appearance: {
            wrapperMargin: "10px 0 0",
            headerBackgroundMode: "gradient",
            headerBackground: "#f7f7f7",
            headerGradientStart: "#eceff1",
            headerGradientEnd: "#f5f7fa",
            headerHoverBackground: "#e1e6e9",
            headerBorder: "1px solid #ccc",
            headerBorderLeft: "3px solid #78909c",
            headerBorderRadius: "3px",
            headerPadding: "5px 10px",
            headerFontSize: "0.88em",
            headerFontWeight: "600",
            headerColor: "#37474f",
            bodyBackground: "transparent",
            bodyBorder: "1px solid #ccc",
            bodyBorderTop: "none",
            bodyBorderLeft: "3px solid #eceff1",
            bodyBorderRadius: "0 0 5px 5px",
            bodyPadding: "10px",
            bodyMarginTop: "4px",
            bodyFontSize: "0.90em",
            bodyColor: "#424242"
        }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let sourceObserver = null;
    let sourceWaitTimer = null;
    let sourceWaitCancel = null;
    let configUnsubscribe = null;
    let contextButton = null;
    let activeSource = null;
    let originalParent = null;
    let originalNextSibling = null;
    let sourceLabel = null;
    let sourceLabelWasHidden = false;
    let runToken = 0;
    let coreRegistered = false;
    let coreStarted = false;
    let fallbackStarted = false;

    window[GLOBAL_GUARD] = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        pageId: PAGE_ID,
        initialized: false,
        active: false,
        status: "created"
    };

    function clone(value) {
        if (value === undefined) return undefined;
        return JSON.parse(JSON.stringify(value));
    }

    function normalizeLanguage(value) {
        const lang = String(value || "auto").toLowerCase();
        return ["auto", "fr", "en"].includes(lang) ? lang : "auto";
    }

    function detectKohaLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            const pmkLang = String(window.PMKConfig.getLanguage() || "").toLowerCase();
            if (pmkLang === "fr" || pmkLang === "en") return pmkLang;
        }

        const candidates = [
            document.documentElement && document.documentElement.lang,
            document.body && document.body.getAttribute("lang"),
            navigator.language
        ];

        for (const candidate of candidates) {
            const lang = String(candidate || "").toLowerCase();
            if (lang.startsWith("fr")) return "fr";
            if (lang.startsWith("en")) return "en";
        }
        return "fr";
    }

    function getDisplayLanguage(config) {
        const configured = normalizeLanguage(config && config.language);
        return configured === "auto" ? detectKohaLanguage() : configured;
    }

    function text(fr, en, config) {
        return getDisplayLanguage(config || currentConfig) === "en" ? en : fr;
    }

    function normalizeAppearance(value) {
        const source = value && typeof value === "object" ? value : {};
        return Object.assign({}, DEFAULT_CONFIG.appearance, source);
    }

    function normalizeConfig(config) {
        const source = config && typeof config === "object" ? config : {};
        return {
            enabled: source.enabled !== false,
            language: normalizeLanguage(source.language),
            titleFr: String(source.titleFr || DEFAULT_CONFIG.titleFr).trim() || DEFAULT_CONFIG.titleFr,
            titleEn: String(source.titleEn || DEFAULT_CONFIG.titleEn).trim() || DEFAULT_CONFIG.titleEn,
            defaultExpanded: source.defaultExpanded === true,
            hideSourceLabel: source.hideSourceLabel !== false,
            placement: "historical-zone-330-215",
            targetSelector: String(source.targetSelector || '').trim(),
            targetPlacement: ['after','before','append','prepend'].includes(source.targetPlacement)?source.targetPlacement:'after',
            sourceSelector: String(source.sourceSelector || '').trim(),
            emptySourceSelector: String(source.emptySourceSelector || '').trim(),
            unavailableSourceSelector: String(source.unavailableSourceSelector || '').trim(),
            provider: "Electre",
            page: "catalogue/detail.pl — catalogue.detail",
            appearance: normalizeAppearance(source.appearance)
        };
    }

    function isTargetPage() {
        const path = String(window.location.pathname || "");
        if (path !== PAGE_PATH) return false;
        const body = document.body;
        return !body || body.id === "catalog_detail" || body.classList.contains("catalog");
    }

    function getTitle(config) {
        const lang = getDisplayLanguage(config);
        return lang === "en" ? config.titleEn : config.titleFr;
    }

    function getElectreSummary(config = currentConfig) {
        if(config.sourceSelector) {
            const source=document.querySelector(config.sourceSelector);
            return source && hasMeaningfulContent(source) ? source : null;
        }
        for (const selector of SOURCE_SELECTORS) {
            const direct = document.querySelector(selector);
            if (direct && hasMeaningfulContent(direct)) return direct;
        }

        const inner = document.querySelector("span#electre-resume");
        if (!inner || !hasMeaningfulContent(inner)) return null;
        return inner.closest("span.results_summary") || inner;
    }

    function sourceDiagnostic(config = currentConfig) {
        if(!isTargetPage())return 'other-page';
        try {
            if(getElectreSummary(config))return 'available';
            const visible=selector=>selector && Array.from(document.querySelectorAll(selector)).some(node=>!node.hidden && node.getClientRects().length>0);
            if(visible(config.unavailableSourceSelector))return 'unavailable';
            if(visible(config.emptySourceSelector))return 'empty';
            return 'unknown';
        } catch(_) {return 'invalid-selector';}
    }
    window[GLOBAL_GUARD].diagnoseSource=sourceDiagnostic;

    function hasMeaningfulContent(element) {
        if (!element) return false;
        const copy = element.cloneNode(true);
        copy.querySelectorAll("span.label").forEach(function (label) { label.remove(); });
        return String(copy.textContent || "").replace(/\s+/g, " ").trim().length > 0;
    }

    function getHistoricalTarget() {
        if(currentConfig.targetSelector){
            try{const element=document.querySelector(currentConfig.targetSelector);return element?{element,placement:currentConfig.targetPlacement,matched:'custom'}:null}catch(_){return null;}
        }
        /*
         * Placement historique du script 009 :
         * 1. dans la zone MARC 330 si elle est présente ;
         * 2. sinon dans la zone MARC 215 ;
         * 3. sinon dans la première section de la fiche notice.
         *
         * On conserve volontairement ce comportement pour que le module
         * retrouve sa place habituelle dans l'interface d’origine.
         */
        const zone330 = document.querySelector("li[title='Zone : 330']");
        if (zone330) return { element: zone330, placement: "append", matched: "330" };

        const zone215 = document.querySelector("li[title='Zone : 215']");
        if (zone215) return { element: zone215, placement: "append", matched: "215" };

        const section = document.querySelector("#catalogue_detail_biblio .page-section") ||
            document.querySelector(".page-section");
        if (section) return { element: section, placement: "append", matched: "fallback" };

        return null;
    }

    function clearSourceWait() {
        if (sourceObserver) {
            sourceObserver.disconnect();
            sourceObserver = null;
        }
        if (sourceWaitTimer) {
            window.clearTimeout(sourceWaitTimer);
            sourceWaitTimer = null;
        }
        const cancel = sourceWaitCancel;
        sourceWaitCancel = null;
        if (cancel) cancel();
    }

    function waitForElectreSummary(timeoutMs) {
        if(['empty','unavailable','invalid-selector'].includes(sourceDiagnostic()))return Promise.resolve(null);
        const existing = getElectreSummary();
        if (existing) return Promise.resolve(existing);

        return new Promise(function (resolve) {
            let finished = false;
            const root = document.getElementById("catalogue_detail_biblio") || document.body || document.documentElement;

            function finish(value) {
                if (finished) return;
                finished = true;
                if (sourceObserver) { sourceObserver.disconnect(); sourceObserver = null; }
                if (sourceWaitTimer) { window.clearTimeout(sourceWaitTimer); sourceWaitTimer = null; }
                sourceWaitCancel = null;
                resolve(value || null);
            }

            sourceWaitCancel = function () { finish(null); };
            sourceObserver = new MutationObserver(function () {
                const found = getElectreSummary();
                if (found) finish(found);
                else if(['empty','unavailable','invalid-selector'].includes(sourceDiagnostic()))finish(null);
            });
            sourceObserver.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['hidden','class','style'] });

            sourceWaitTimer = window.setTimeout(function () {
                finish(getElectreSummary());
            }, timeoutMs || SOURCE_WAIT_MS);
        });
    }

    function cssText(value, fallback) {
        const text = String(value == null ? "" : value).trim();
        return text || fallback;
    }

    function injectStyles(config) {
        const old = document.getElementById(STYLE_ID);
        if (old) old.remove();

        const a = normalizeAppearance(config && config.appearance);
        const headerBackground = a.headerBackgroundMode === "solid"
            ? cssText(a.headerBackground, "#f7f7f7")
            : "linear-gradient(90deg, " + cssText(a.headerGradientStart, "#eceff1") +
              " 0%, " + cssText(a.headerGradientEnd, "#f5f7fa") + " 100%)";

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #${WRAPPER_ID} {
                margin: ${cssText(a.wrapperMargin, "10px 0 0")};
                min-width: 0;
            }
            #${WRAPPER_ID} .pmk-fourth-cover-heading {
                display: flex;
                align-items: center;
                gap: .15rem;
                margin: 0;
                min-width: 0;
            }
            #${WRAPPER_ID} .pmk-fourth-cover-toggle {
                appearance: none;
                width: auto;
                min-height: 0;
                display: inline-flex;
                align-items: center;
                gap: .3rem;
                padding: ${cssText(a.headerPadding, "5px 10px")};
                border: ${cssText(a.headerBorder, "1px solid #ccc")};
                border-left: ${cssText(a.headerBorderLeft, "3px solid #78909c")};
                border-radius: ${cssText(a.headerBorderRadius, "3px")};
                background: ${headerBackground};
                color: ${cssText(a.headerColor, "#37474f")};
                font: inherit;
                font-size: ${cssText(a.headerFontSize, "0.88em")};
                font-weight: ${cssText(a.headerFontWeight, "600")};
                line-height: 1.35;
                text-align: left;
                cursor: pointer;
                box-shadow: none;
                user-select: none;
            }
            #${WRAPPER_ID} .pmk-fourth-cover-toggle:hover {
                background: ${cssText(a.headerHoverBackground, "#e1e6e9")};
            }
            #${WRAPPER_ID} .pmk-fourth-cover-toggle:focus-visible {
                outline: 2px solid rgba(13,110,253,.35);
                outline-offset: 2px;
            }
            #${WRAPPER_ID} .pmk-fourth-cover-chevron {
                flex: 0 0 auto;
                color: currentColor;
                font-size: .88em;
                line-height: 1;
                transition: transform .15s ease;
            }
            #${WRAPPER_ID} .pmk-fourth-cover-toggle[aria-expanded="true"] .pmk-fourth-cover-chevron {
                transform: rotate(90deg);
            }
            #${WRAPPER_ID} .pmk-fourth-cover-title {
                min-width: 0;
                overflow-wrap: anywhere;
            }
            #${BODY_ID} {
                margin-top: ${cssText(a.bodyMarginTop, "4px")};
                padding: ${cssText(a.bodyPadding, "10px")};
                border: ${cssText(a.bodyBorder, "1px solid #ccc")};
                border-top: ${cssText(a.bodyBorderTop, "none")};
                border-left: ${cssText(a.bodyBorderLeft, "3px solid #eceff1")};
                border-radius: ${cssText(a.bodyBorderRadius, "0 0 5px 5px")};
                background: ${cssText(a.bodyBackground, "transparent")};
                color: ${cssText(a.bodyColor, "#424242")};
                font-size: ${cssText(a.bodyFontSize, "0.90em")};
                min-width: 0;
                overflow-wrap: anywhere;
            }
            #${BODY_ID}[hidden] {
                display: none !important;
            }
            #${BODY_ID} img { max-width:100%; height:auto; }
            #${BODY_ID} pre { white-space:pre-wrap; overflow-wrap:anywhere; }
            @media (prefers-reduced-motion: reduce) {
                #${WRAPPER_ID} .pmk-fourth-cover-chevron { transition:none; }
            }
            #${BODY_ID} > .results_summary,
            #${BODY_ID} .results_summary {
                display: block;
                max-width: 100%;
                margin: 0;
                padding: 0;
                white-space: normal;
                overflow-wrap: anywhere;
            }
            #${WRAPPER_ID} .pmk-context-config {
                flex: 0 0 auto;
                opacity: .28;
                padding: 0 .2rem !important;
                margin-left: .05rem !important;
            }
            #${WRAPPER_ID} .pmk-context-config:hover,
            #${WRAPPER_ID} .pmk-context-config:focus {
                opacity: .8;
            }
            @media (max-width: 576px) {
                #${WRAPPER_ID} {
                    max-width: 100%;
                }
                #${WRAPPER_ID} .pmk-fourth-cover-toggle {
                    max-width: 100%;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function restoreSource() {
        if (!activeSource) return;

        if (sourceLabel) {
            sourceLabel.hidden = sourceLabelWasHidden;
        }

        if (originalParent && document.documentElement.contains(originalParent)) {
            const reference = originalNextSibling && originalNextSibling.parentNode === originalParent
                ? originalNextSibling
                : null;
            originalParent.insertBefore(activeSource, reference);
        }

        activeSource = null;
        originalParent = null;
        originalNextSibling = null;
        sourceLabel = null;
        sourceLabelWasHidden = false;
    }

    function removeInjectedUi(options) {
        const opts = options || {};
        runToken += 1;
        clearSourceWait();

        const wrapper = document.getElementById(WRAPPER_ID);
        if (wrapper && activeSource && wrapper.contains(activeSource)) {
            restoreSource();
        } else if (activeSource) {
            restoreSource();
        }

        if (wrapper) wrapper.remove();
        if (contextButton && contextButton.isConnected) contextButton.remove();
        contextButton = null;

        if (opts.removeStyles === true) {
            const style = document.getElementById(STYLE_ID);
            if (style) style.remove();
        }

        window[GLOBAL_GUARD].active = false;
    }

    function setExpanded(button, body, expanded) {
        const open = expanded === true;
        button.setAttribute("aria-expanded", open ? "true" : "false");
        body.hidden = !open;
    }

    function mountContextAccess(heading) {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        if (!heading) return;

        contextButton = window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: heading,
            position: "append",
            contextKey: PAGE_ID,
            context: {
                pageId: PAGE_ID,
                sectionId: "presentation"
            }
        });
    }

    function buildUi(source, target, config) {
        if (!source || !target || document.getElementById(WRAPPER_ID)) return false;

        injectStyles(config);

        originalParent = source.parentNode;
        originalNextSibling = source.nextSibling;
        activeSource = source;

        sourceLabel = source.querySelector ? source.querySelector("span.label") : null;
        if (sourceLabel) {
            sourceLabelWasHidden = sourceLabel.hidden;
            sourceLabel.hidden = sourceLabelWasHidden || config.hideSourceLabel === true;
        }

        const wrapper = document.createElement("div");
        wrapper.id = WRAPPER_ID;
        wrapper.className = "pmk-detail-fourth-cover";
        wrapper.setAttribute("data-pmk-module", MODULE_ID);
        wrapper.setAttribute("data-pmk-page", PAGE_ID);

        const heading = document.createElement("div");
        heading.className = "pmk-fourth-cover-heading";

        const button = document.createElement("button");
        button.type = "button";
        button.className = "pmk-fourth-cover-toggle";
        button.id = WRAPPER_ID + '-toggle';
        button.setAttribute("aria-controls", BODY_ID);

        const chevron = document.createElement("span");
        chevron.className = "pmk-fourth-cover-chevron";
        chevron.setAttribute("aria-hidden", "true");
        chevron.textContent = "›";

        const title = document.createElement("span");
        title.className = "pmk-fourth-cover-title";
        title.textContent = getTitle(config);

        button.appendChild(chevron);
        button.appendChild(title);
        heading.appendChild(button);

        const body = document.createElement("div");
        body.id = BODY_ID;
        body.className = "pmk-fourth-cover-body";
        body.setAttribute('role','region');
        body.setAttribute('aria-labelledby',button.id);
        body.appendChild(source);

        wrapper.appendChild(heading);
        wrapper.appendChild(body);

        if (target.placement === "append") {
            target.element.appendChild(wrapper);
        } else if(target.placement==='prepend') {
            target.element.prepend(wrapper);
        } else {
            target.element.insertAdjacentElement(target.placement==='before'?'beforebegin':'afterend', wrapper);
        }

        setExpanded(button, body, config.defaultExpanded === true);
        button.addEventListener("click", function () {
            const expanded = button.getAttribute("aria-expanded") === "true";
            setExpanded(button, body, !expanded);
        });

        mountContextAccess(heading);
        window[GLOBAL_GUARD].active = true;
        window[GLOBAL_GUARD].status = "active";
        return true;
    }

    async function applyConfig(config) {
        currentConfig = normalizeConfig(config);

        if (!isTargetPage()) return;

        removeInjectedUi();
        const activeToken = ++runToken;

        if (!currentConfig.enabled) {
            window[GLOBAL_GUARD].status = "disabled";
            return;
        }

        const target = getHistoricalTarget();
        if (!target) {
            window[GLOBAL_GUARD].status = "safe-target-not-found";
            return;
        }

        const source = await waitForElectreSummary(SOURCE_WAIT_MS);
        if (activeToken !== runToken) return;
        if (!source) {
            window[GLOBAL_GUARD].status = "source-" + sourceDiagnostic();
            return;
        }

        const refreshedTarget = getHistoricalTarget();
        if (!refreshedTarget) {
            window[GLOBAL_GUARD].status = "safe-target-lost";
            return;
        }

        if(source===refreshedTarget.element || source.contains(refreshedTarget.element)){
            window[GLOBAL_GUARD].status='invalid-target';return;
        }
        buildUi(source, refreshedTarget, currentConfig);
    }

    function validateModuleConfig(config) {
        if (!config || typeof config !== "object") {
            return {
                ok: false,
                message: detectKohaLanguage() === "en"
                    ? "The module configuration is invalid."
                    : "La configuration du module est invalide."
            };
        }

        if (Object.prototype.hasOwnProperty.call(config, "language") &&
            !["auto", "fr", "en"].includes(String(config.language || "").toLowerCase())) {
            return {
                ok: false,
                message: detectKohaLanguage() === "en"
                    ? "The selected language is invalid."
                    : "La langue choisie n’est pas valide."
            };
        }

        for (const key of ["titleFr", "titleEn"]) {
            if (Object.prototype.hasOwnProperty.call(config, key) && !String(config[key] || "").trim()) {
                return {
                    ok: false,
                    message: detectKohaLanguage() === "en"
                        ? "French and English titles cannot be empty."
                        : "Les titres français et anglais ne peuvent pas être vides."
                };
            }
        }

        for(const key of ['targetSelector','sourceSelector','emptySourceSelector','unavailableSourceSelector']) {
            if(config[key]){try{document.createDocumentFragment().querySelector(config[key])}catch(_){return {ok:false,message:'Une cible du résumé est invalide : '+key}}}
        }
        return { ok: true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 3,
            name: {
                fr: "Résumé enrichi / 4ème de couverture",
                en: "Enriched summary / back cover"
            },
            description: {
                fr: "Présente dans un bloc repliable le résumé Electre déjà injecté dans la page détail. Le module ne contacte pas Electre lui-même.",
                en: "Presents an Electre summary already injected into the record-detail page in a collapsible block. The module does not contact Electre itself."
            },
            category: {
                fr: "Catalogue / détail de notice",
                en: "Catalog / record detail"
            },
            supportedPages: [PAGE_ID],
            prerequisites: [
                {
                    fr: "Un résumé Electre doit déjà être injecté dans la page par l’intégration de l’installation.",
                    en: "An Electre summary must already be injected into the page by the installation integration."
                }
            ],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validateModuleConfig,
            schema: [
                {
                    type: "section",
                    id: "presentation",
                    label: { fr: "Présentation", en: "Presentation" },
                    description: {
                        fr: "Personnalise le titre et l’état initial du bloc. Les valeurs par défaut reproduisent le comportement historique du 009.",
                        en: "Customize the block title and initial state. Defaults preserve the original 009 behavior."
                    },
                    fields: [
                        {
                            key: "language",
                            type: "select",
                            label: { fr: "Langue du bloc", en: "Block language" },
                            options: [
                                { value: "auto", label: { fr: "Automatique — suivre Koha", en: "Automatic — follow Koha" } },
                                { value: "fr", label: { fr: "Français", en: "French" } },
                                { value: "en", label: { fr: "Anglais", en: "English" } }
                            ]
                        },
                        {
                            key: "titleFr",
                            type: "text",
                            label: { fr: "Titre français", en: "French title" }
                        },
                        {
                            key: "titleEn",
                            type: "text",
                            label: { fr: "Titre anglais", en: "English title" }
                        },
                        {
                            key: "defaultExpanded",
                            type: "boolean",
                            label: { fr: "Ouvrir le bloc par défaut", en: "Open the block by default" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "appearance",
                    label: { fr: "Style de l’accordéon", en: "Accordion style" },
                    description: {
                        fr: "Les valeurs par défaut reproduisent le rendu historique obtenu avec le 107. Tous les réglages appartiennent désormais au 009 et restent modifiables.",
                        en: "Defaults reproduce the historical rendering provided by 107. All styling now belongs to module 009 and remains configurable."
                    },
                    fields: [
                        {
                            key: "appearance.headerBackgroundMode",
                            type: "select",
                            refreshOnChange: true,
                            label: { fr: "Fond de l’en-tête", en: "Header background" },
                            options: [
                                { value: "gradient", label: { fr: "Dégradé", en: "Gradient" } },
                                { value: "solid", label: { fr: "Couleur unie", en: "Solid color" } }
                            ]
                        },
                        { key: "appearance.headerBackground", type: "color", label: { fr: "Couleur unie", en: "Solid color" }, when: function (root) { return root.appearance && root.appearance.headerBackgroundMode === "solid"; } },
                        { key: "appearance.headerGradientStart", type: "color", label: { fr: "Début du dégradé", en: "Gradient start" }, when: function (root) { return !root.appearance || root.appearance.headerBackgroundMode !== "solid"; } },
                        { key: "appearance.headerGradientEnd", type: "color", label: { fr: "Fin du dégradé", en: "Gradient end" }, when: function (root) { return !root.appearance || root.appearance.headerBackgroundMode !== "solid"; } },
                        { key: "appearance.headerHoverBackground", type: "color", label: { fr: "Fond au survol", en: "Hover background" } },
                        { key: "appearance.headerColor", type: "color", label: { fr: "Couleur du titre", en: "Title color" } },
                        { key: "appearance.headerBorder", type: "text", label: { fr: "Bordure de l’en-tête", en: "Header border" }, advanced: true },
                        { key: "appearance.headerBorderLeft", type: "text", label: { fr: "Bordure gauche de l’en-tête", en: "Header left border" }, advanced: true },
                        { key: "appearance.headerBorderRadius", type: "text", label: { fr: "Arrondi de l’en-tête", en: "Header radius" }, advanced: true },
                        { key: "appearance.headerPadding", type: "text", label: { fr: "Espacement interne de l’en-tête", en: "Header padding" }, advanced: true },
                        { key: "appearance.headerFontSize", type: "text", label: { fr: "Taille du titre", en: "Title size" } },
                        { key: "appearance.headerFontWeight", type: "text", label: { fr: "Graisse du titre", en: "Title weight" }, advanced: true },
                        { key: "appearance.bodyBackground", type: "text", label: { fr: "Fond du contenu", en: "Body background" }, help: { fr: "Couleur CSS ou transparent.", en: "CSS color or transparent." } },
                        { key: "appearance.bodyColor", type: "color", label: { fr: "Couleur du contenu", en: "Body color" } },
                        { key: "appearance.bodyBorder", type: "text", label: { fr: "Bordure du contenu", en: "Body border" }, advanced: true },
                        { key: "appearance.bodyBorderTop", type: "text", label: { fr: "Bordure haute du contenu", en: "Body top border" }, advanced: true },
                        { key: "appearance.bodyBorderLeft", type: "text", label: { fr: "Bordure gauche du contenu", en: "Body left border" }, advanced: true },
                        { key: "appearance.bodyBorderRadius", type: "text", label: { fr: "Arrondi du contenu", en: "Body radius" }, advanced: true },
                        { key: "appearance.bodyPadding", type: "text", label: { fr: "Espacement interne du contenu", en: "Body padding" }, advanced: true },
                        { key: "appearance.bodyMarginTop", type: "text", label: { fr: "Espace avant le contenu", en: "Space before body" }, advanced: true },
                        { key: "appearance.bodyFontSize", type: "text", label: { fr: "Taille du contenu", en: "Body text size" } },
                        { key: "appearance.wrapperMargin", type: "text", label: { fr: "Marge du bloc", en: "Block margin" }, advanced: true }
                    ]
                },
                {
                    type: "section",
                    id: "source",
                    label: { fr: "Source du contenu", en: "Content source" },
                    description: {
                        fr: "La détection technique d’Electre est gérée par le module et n’a pas à être configurée avec des sélecteurs CSS.",
                        en: "Technical Electre detection is handled by the module and does not require CSS-selector configuration."
                    },
                    fields: [
                        {
                            key: "provider",
                            type: "text",
                            readOnly: true,
                            label: { fr: "Fournisseur pris en charge", en: "Supported provider" }
                        },
                        {
                            key: "hideSourceLabel",
                            type: "boolean",
                            label: { fr: "Masquer le libellé d’origine Electre", en: "Hide the original Electre label" },
                            help: {
                                fr: "Le contenu du résumé est conservé ; seul le libellé déjà présent dans le bloc source est masqué.",
                                en: "The summary content is preserved; only the label already present in the source block is hidden."
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "placement",
                    label: { fr: "Emplacement", en: "Placement" },
                    description: {
                        fr: "Le résumé reprend automatiquement l’emplacement historique du script 009 : zone 330, sinon zone 215, puis repli dans la première section disponible.",
                        en: "The summary automatically uses the historical 009 placement: field 330, then field 215, then the first available section as fallback."
                    },
                    fields: [
                        {
                            key: "placement",
                            type: "text",
                            readOnly: true,
                            label: { fr: "Position utilisée", en: "Position used" },
                            help: {
                                fr: "Ce placement est volontairement fixe pour conserver le rendu historique.",
                                en: "This placement is intentionally fixed to preserve the historical layout."
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "pages",
                    label: { fr: "Pages configurées", en: "Configured pages" },
                    description: {
                        fr: "Ce module est volontairement limité à la page de détail d’une notice.",
                        en: "This module is intentionally limited to the record-detail page."
                    },
                    fields: [
                        {
                            key: "page",
                            type: "text",
                            readOnly: true,
                            label: { fr: "Page active", en: "Active page" }
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main || !context || context.pageId !== PAGE_ID) return;
                const wanted = context.sectionId || "presentation";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') ||
                    main.querySelector('[data-pmk-section-id="presentation"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    async function startWithCore() {
        if (!window.PMKConfig) return;

        if (!coreRegistered) {
            window.PMKConfig.registerModule(moduleDefinition());
            coreRegistered = true;
        }

        if (coreStarted || !isTargetPage()) return;
        coreStarted = true;

        let config = DEFAULT_CONFIG;
        try {
            config = await window.PMKConfig.getConfig(MODULE_ID);
        } catch (_) {
            config = DEFAULT_CONFIG;
        }

        await applyConfig(config);

        if (typeof window.PMKConfig.subscribe === "function" && !configUnsubscribe) {
            configUnsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (newConfig) {
                applyConfig(newConfig);
            });
            window[GLOBAL_GUARD].unsubscribe = configUnsubscribe;
        }

        window[GLOBAL_GUARD].initialized = true;
    }

    async function startWithoutCore() {
        if (fallbackStarted || !isTargetPage()) return;
        fallbackStarted = true;
        await applyConfig(DEFAULT_CONFIG);
        window[GLOBAL_GUARD].initialized = true;
    }

    function start() {
        if (window.PMKConfig) startWithCore();
        else startWithoutCore();
    }

    function onDomReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else {
            callback();
        }
    }

    onDomReady(start);

    window.addEventListener("pmk:config-ready", function () {
        if (!coreRegistered || !coreStarted) startWithCore();
    }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("009-4eme-de-couv.js");
} catch (error) { window.PMKNonPlugin.errors.push("009-4eme-de-couv.js: "+error.message); console.error("[PMK] 009-4eme-de-couv.js",error); };
try {
/* ============================================================
   Nom du fichier : 010-boutons-recherche-externe.js
   Module PMK      : external-links
   Version         : 2.4.5
   Mise à jour     : 2026-09-21
   Auteur          : équipe PimpMyKoha

   Fonction :
   - conserve par défaut le comportement historique du script 010 :
     reprise des liens déjà présents dans les blocs .liens_externes ;
   - permet en plus de créer autant de liens externes configurables
     que nécessaire à partir de modèles d'URL ;
   - chaque lien peut utiliser du texte, une icône Font Awesome ou
     une image ;
   - le bouton principal peut lui aussi utiliser une icône, une image
     ou uniquement du texte ;
   - fonctionne sur les résultats de recherche et le détail notice ;
   - peut créer son propre point d'ancrage lorsqu'aucun bloc
     .liens_externes n'existe mais que des liens configurés sont actifs ;
   - absorbe le legacy 037 « Rechercher ailleurs » dans le même module ;
   - conserve deux rendus séparés : liens de notice près des notices,
     « Rechercher ailleurs » dans une zone distincte de search.pl ;
   - permet des placements desktop/mobile indépendants pour le bloc 037 ;
   - utilise la configuration commune PMK lorsqu'elle est disponible.

   Préparation PimpMyKoha :
   - identifiant fonctionnel stable : external-links ;
   - adaptateurs : catalogue.search / catalogue.detail ;
   - Firestore n'est jamais appelé directement par ce module ;
   - la couche de configuration est fournie par window.PMKConfig.
   ============================================================ */
(function () {
    "use strict";

    const MODULE_ID = "external-links";
    const MODULE_VERSION = "2.4.5";
    const STYLE_ID = "pmk-external-links-styles";
    const SOURCE_HIDDEN_CLASS = "pmk-external-links-source-hidden";
    const WRAPPER_CLASS = "pmk-external-links-wrapper";
    const MENU_CLASS = "pmk-external-links-menu";
    const TOGGLE_CLASS = "pmk-external-links-toggle";
    const GENERATED_HOST_CLASS = "pmk-external-links-generated-host";

    const HISTORICAL_BUTTON_IMAGE =
        "https://cdn-icons-png.flaticon.com/512/15955/15955603.png";

    const HISTORICAL_LINK_IMAGES = {
        electre: "",
        babelio: "",
        google: ""
    };

    const HISTORICAL_CUSTOM_LINKS = [
        { id: "electre", enabled: true, labelFr: "Electre", labelEn: "Electre",
          urlTemplate: "https://www.electre-ng.com/#/search?q%3D(identifiant%3A%22{ISBN_FORMATTED}%22)%26debut%3D0%26resultat-max%3D50%26perimetre%3D%5Bperimetre-hors-numerique%5DHors%20num%C3%A9rique__%26tri.champ%3D%22date-parution%22%26tri.sens%3D%22desc%22%26inclure-embargos%3D%22true%22%26type%3D%22rapide%22",
          scope: "all", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-external-link", imageUrl: HISTORICAL_LINK_IMAGES.electre },
        { id: "babelio", enabled: true, labelFr: "Babelio", labelEn: "Babelio",
          urlTemplate: "https://www.google.com/search?q=babelio+{AUTHOR}+{TITLE}%20",
          scope: "all", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-external-link", imageUrl: HISTORICAL_LINK_IMAGES.babelio },
        { id: "google", enabled: true, labelFr: "Google", labelEn: "Google",
          urlTemplate: "https://www.google.com/search?q={AUTHOR}%20{TITLE}%20",
          scope: "all", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-external-link", imageUrl: HISTORICAL_LINK_IMAGES.google }
    ];

    const HISTORICAL_SEARCH_ELSE_LINKS = [
        { id: "babelio-google", enabled: true, labelFr: "Babelio via Google", labelEn: "Babelio via Google", urlTemplate: "https://www.google.com/search?q=babelio+{QUERY}", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-book", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "allocine", enabled: true, labelFr: "Allociné", labelEn: "AlloCiné", urlTemplate: "https://www.allocine.fr/rechercher/?q={QUERY}", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-film", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "google", enabled: true, labelFr: "Google", labelEn: "Google", urlTemplate: "https://www.google.com/search?q={QUERY}", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-search", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "google-books", enabled: true, labelFr: "Google Books", labelEn: "Google Books", urlTemplate: "https://www.google.com/search?tbm=bks&q={QUERY}", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-book-open", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "wikipedia", enabled: true, labelFr: "Wikipedia", labelEn: "Wikipedia", urlTemplate: "https://fr.wikipedia.org/w/index.php?search={QUERY}&title=Sp%C3%A9cial%3ARecherche&ns0=1", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-globe", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "amazon-general", enabled: true, labelFr: "Amazon (général)", labelEn: "Amazon (general)", urlTemplate: "https://www.amazon.com/s?k={QUERY}", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-cart-shopping", imageUrl: "", branchesMode: "all", branchCodes: "" },
        { id: "amazon-books", enabled: true, labelFr: "Amazon Livres", labelEn: "Amazon Books", urlTemplate: "https://www.amazon.com/s?k={QUERY}&i=stripbooks", newWindow: true, showLabel: true, iconType: "fa", iconClass: "fa fa-book", imageUrl: "", branchesMode: "all", branchCodes: "" }
    ];

    const PAGE_ADAPTERS = {
        "catalogue.search": {
            id: "catalogue.search",
            label: {
                fr: "Résultats de recherche",
                en: "Search results"
            },
            path: "catalogue/search.pl",
            matches: function () {
                return /\/catalogue\/search\.pl$/.test(window.location.pathname);
            },
            sectionSelector: ".liens_externes"
        },
        "catalogue.detail": {
            id: "catalogue.detail",
            label: {
                fr: "Détail d’une notice",
                en: "Record detail"
            },
            path: "catalogue/detail.pl",
            matches: function () {
                return /\/catalogue\/detail\.pl$/.test(window.location.pathname);
            },
            sectionSelector: ".liens_externes"
        }
    };

    /*
     * Valeurs par défaut :
     * - l'ancien script affichait un bouton "Partager" avec cette image ;
     * - il déplaçait dans son menu les <li> contenant un lien target=_blank
     *   ou une image.
     *
     * Le nouveau module conserve donc ce comportement par défaut tout en
     * corrigeant la structure HTML et en ajoutant les nouvelles fonctions.
     */
    const DEFAULT_CONFIG = {
        enabled: true,

        buttonLabelFr: "Partager",
        buttonLabelEn: "Share",
        buttonShowLabel: false,
        buttonVisualType: "image",
        buttonIconClass: "fa fa-share-alt",
        buttonImageUrl: HISTORICAL_BUTTON_IMAGE,
        buttonShowCaret: false,

        includeExistingLinks: true,
        existingLinksMode: "historical",

        customLinks: HISTORICAL_CUSTOM_LINKS.map(function (item) { return Object.assign({}, item); }),

        searchElse: {
            enabled: true,
            titleFr: "Rechercher ailleurs",
            titleEn: "Search elsewhere",
            desktopPlacement: "sidebar",
            mobilePlacement: "before-results",
            mobileBreakpoint: 768,
            presentation: "list",
            links: HISTORICAL_SEARCH_ELSE_LINKS.map(function (item) { return Object.assign({}, item); })
        },

        pages: [
            {
                pageId: "catalogue.search",
                enabled: true,
                path: "catalogue/search.pl",
                presentation: "menu",
                columns: 2,
                gap: "6px",
                linkPadding: "6px 8px",
                linkJustifyContent: "center",
                linkTextAlign: "center",
                iconGap: "4px",
                linkBackground: "#eceff1",
                linkHoverBackground: "#e1e6e9",
                linkColor: "#455a64",
                linkHoverColor: "#455a64",
                linkBorder: "0",
                linkBorderRadius: "6px",
                linkFontSize: "0.78em",
                linkFontWeight: "600",
                linkBoxShadow: "0 1px 3px rgba(96,125,139,0.18)",
                linkHoverBoxShadow: "0 2px 5px rgba(96,125,139,0.24)",
                hoverTranslateY: "-1px",
                imageRadius: "4px",
                imageBoxShadow: "0 1px 3px rgba(0,0,0,0.15)",
                imageHoverBoxShadow: "0 3px 8px rgba(0,0,0,0.25)",
                imageHoverScale: 1.12
            },
            {
                pageId: "catalogue.detail",
                enabled: true,
                path: "catalogue/detail.pl",
                // Rendu initial du 010 : bouton compact qui
                // ouvre/masque les liens. La grille du 107 reste disponible
                // comme option dans PMK, mais n'est plus imposée par défaut.
                presentation: "menu",
                columns: 2,
                gap: "6px",
                linkPadding: "6px 8px",
                linkJustifyContent: "center",
                linkTextAlign: "center",
                iconGap: "4px",
                linkBackground: "#eceff1",
                linkHoverBackground: "#e1e6e9",
                linkColor: "#455a64",
                linkHoverColor: "#455a64",
                linkBorder: "0",
                linkBorderRadius: "6px",
                linkFontSize: "0.78em",
                linkFontWeight: "600",
                linkBoxShadow: "0 1px 3px rgba(96,125,139,0.18)",
                linkHoverBoxShadow: "0 2px 5px rgba(96,125,139,0.24)",
                hoverTranslateY: "-1px",
                imageRadius: "4px",
                imageBoxShadow: "0 1px 3px rgba(0,0,0,0.15)",
                imageHoverBoxShadow: "0 3px 8px rgba(0,0,0,0.25)",
                imageHoverScale: 1.12
            }
        ]
    };

    const TEMPLATE_TOKENS = [
        "BIBLIONUMBER",
        "TITLE",
        "AUTHOR",
        "ISBN",
        "ISBN10",
        "ISBN13",
        "ISSN",
        "EAN",
        "CONTROLNUMBER",
        "OCLC_NO",
        "QUERY",
        "CURRENT_URL",
        "ISBN_FORMATTED"
    ];

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function currentLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const htmlLang = (document.documentElement.getAttribute("lang") || "").toLowerCase();
        if (htmlLang.startsWith("fr")) return "fr";
        if (htmlLang.startsWith("en")) return "en";
        return (navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function translated(fr, en) {
        return currentLanguage() === "en" ? en : fr;
    }

    function cleanText(value) {
        return String(value === undefined || value === null ? "" : value)
            .replace(/\s+/g, " ")
            .trim();
    }

    function buttonLabel(config) {
        return currentLanguage() === "en"
            ? (cleanText(config.buttonLabelEn) || cleanText(config.buttonLabelFr) || "Share")
            : (cleanText(config.buttonLabelFr) || cleanText(config.buttonLabelEn) || "Partager");
    }

    function customLinkLabel(link) {
        return currentLanguage() === "en"
            ? (cleanText(link.labelEn) || cleanText(link.labelFr))
            : (cleanText(link.labelFr) || cleanText(link.labelEn));
    }

    function pageOptions() {
        return Object.keys(PAGE_ADAPTERS).map(function (pageId) {
            const page = PAGE_ADAPTERS[pageId];
            return {
                value: page.id,
                label: page.label
            };
        });
    }

    function nextMissingPage(rootObject) {
        const configured = new Set(
            Array.isArray(rootObject && rootObject.pages)
                ? rootObject.pages.map(function (item) { return item && item.pageId; })
                : []
        );
        return Object.keys(PAGE_ADAPTERS).find(function (pageId) {
            return !configured.has(pageId);
        }) || "catalogue.search";
    }

    function pagePath(pageId) {
        return PAGE_ADAPTERS[pageId] ? PAGE_ADAPTERS[pageId].path : "";
    }

    function pagePresentationDefaults(pageId) {
        const found = DEFAULT_CONFIG.pages.find(function (item) {
            return item && item.pageId === pageId;
        });
        return found ? clone(found) : {
            pageId: pageId,
            enabled: true,
            path: pagePath(pageId),
            presentation: "menu",
            columns: 2,
            gap: "6px",
            linkPadding: "6px 8px",
            linkJustifyContent: "center",
            linkTextAlign: "center",
            iconGap: "4px",
            linkBackground: "#eceff1",
            linkHoverBackground: "#e1e6e9",
            linkColor: "#455a64",
            linkHoverColor: "#455a64",
            linkBorder: "0",
            linkBorderRadius: "6px",
            linkFontSize: "0.78em",
            linkFontWeight: "600",
            linkBoxShadow: "0 1px 3px rgba(96,125,139,0.18)",
            linkHoverBoxShadow: "0 2px 5px rgba(96,125,139,0.24)",
            hoverTranslateY: "-1px",
            imageRadius: "4px",
            imageBoxShadow: "0 1px 3px rgba(0,0,0,0.15)",
            imageHoverBoxShadow: "0 3px 8px rgba(0,0,0,0.25)",
            imageHoverScale: 1.12
        };
    }

    function currentPagePresentation(config) {
        const defaults = pagePresentationDefaults(adapter ? adapter.id : "");
        const pages = Array.isArray(config && config.pages) ? config.pages : [];
        const saved = pages.find(function (item) {
            return item && adapter && item.pageId === adapter.id;
        }) || {};
        return Object.assign({}, defaults, saved);
    }


    function customLinkAt(rootObject, path) {
        if (!rootObject || !Array.isArray(rootObject.customLinks)) return null;
        const index = path && path.length ? path[path.length - 1] : -1;
        return Number.isInteger(index) ? rootObject.customLinks[index] : null;
    }


    function searchElseLinkAt(rootObject, path) {
        if (!rootObject || !rootObject.searchElse || !Array.isArray(rootObject.searchElse.links)) return null;
        const index = path && path.length ? path[path.length - 1] : -1;
        return Number.isInteger(index) ? rootObject.searchElse.links[index] : null;
    }

    function searchElseLabel(link) {
        return currentLanguage() === "en"
            ? (cleanText(link && link.labelEn) || cleanText(link && link.labelFr))
            : (cleanText(link && link.labelFr) || cleanText(link && link.labelEn));
    }

    function visualTypeOptions() {
        return [
            {
                value: "none",
                label: { fr: "Aucune icône / image", en: "No icon / image" }
            },
            {
                value: "fa",
                label: { fr: "Icône Font Awesome", en: "Font Awesome icon" }
            },
            {
                value: "image",
                label: { fr: "Image", en: "Image" }
            }
        ];
    }

    function normalizeModuleConfig(config) {
        const source = config && typeof config === "object" ? config : {};
        const normalized = Object.assign({}, clone(DEFAULT_CONFIG), source);

        normalized.searchElse = Object.assign({}, clone(DEFAULT_CONFIG.searchElse), source.searchElse || {});
        normalized.customLinks = Array.isArray(source.customLinks)
            ? source.customLinks.map(function (item) { return Object.assign({}, item); })
            : clone(DEFAULT_CONFIG.customLinks);

        const suppliedPages = Array.isArray(source.pages) ? source.pages : [];
        normalized.pages = Object.keys(PAGE_ADAPTERS).map(function (pageId) {
            const defaults = pagePresentationDefaults(pageId);
            const saved = suppliedPages.find(function (item) { return item && item.pageId === pageId; }) || {};
            return Object.assign({}, defaults, saved, {
                pageId: pageId,
                path: pagePath(pageId),
                enabled: saved.enabled !== false
            });
        });

        return normalized;
    }

    function prepareRuntimeConfig(config) {
        // Stored presentation choices always take precedence over newer defaults.
        return {config: normalizeModuleConfig(config)};
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 5,
            name: {
                fr: "Liens externes",
                en: "External links"
            },
            description: {
                fr: "Regroupe les liens externes liés aux notices et le bloc distinct « Rechercher ailleurs » issu du legacy 037. Les deux fonctions partagent le même moteur mais restent affichées à des emplacements différents.",
                en: "Groups record external links and the separate “Search elsewhere” block from legacy 037. Both features share one engine while remaining displayed in different page locations."
            },
            category: {
                fr: "Catalogue / liens externes",
                en: "Catalog / external links"
            },
            supportedPages: [
                "catalogue.search",
                "catalogue.detail"
            ],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeModuleConfig,
            validate: function (config) {
                const lang = currentLanguage();
                const fail = function (fr, en) {
                    return {
                        ok: false,
                        message: lang === "en" ? en : fr
                    };
                };

                if (!config || typeof config !== "object") {
                    return fail(
                        "La configuration du module n’est pas valide.",
                        "The module configuration is invalid."
                    );
                }

                if (!cleanText(config.buttonLabelFr) && !cleanText(config.buttonLabelEn)) {
                    return fail(
                        "Le bouton doit avoir au moins un libellé.",
                        "The button must have at least one label."
                    );
                }

                if (!["none", "fa", "image"].includes(config.buttonVisualType)) {
                    return fail(
                        "Le type d’illustration du bouton n’est pas valide.",
                        "The button visual type is invalid."
                    );
                }

                if (config.buttonVisualType === "fa" && !cleanText(config.buttonIconClass)) {
                    return fail(
                        "Indique une classe Font Awesome pour le bouton.",
                        "Enter a Font Awesome class for the button."
                    );
                }

                if (config.buttonVisualType === "image" && !cleanText(config.buttonImageUrl)) {
                    return fail(
                        "Indique l’URL de l’image du bouton.",
                        "Enter the button image URL."
                    );
                }

                if (!["historical", "all"].includes(config.existingLinksMode)) {
                    return fail(
                        "Le mode de reprise des liens existants n’est pas valide.",
                        "The existing-links mode is invalid."
                    );
                }

                if (!Array.isArray(config.customLinks)) {
                    return fail(
                        "La liste des liens personnalisés n’est pas valide.",
                        "The custom-links list is invalid."
                    );
                }

                for (let i = 0; i < config.customLinks.length; i += 1) {
                    const link = config.customLinks[i] || {};
                    if (!cleanText(link.labelFr) && !cleanText(link.labelEn)) {
                        return fail(
                            "Chaque lien personnalisé doit avoir au moins un libellé.",
                            "Each custom link must have at least one label."
                        );
                    }
                    if (!cleanText(link.urlTemplate)) {
                        return fail(
                            "Chaque lien personnalisé doit avoir une structure d’URL.",
                            "Each custom link must have a URL template."
                        );
                    }
                    if (!["all", "catalogue.search", "catalogue.detail"].includes(link.scope)) {
                        return fail(
                            "La portée d’un lien personnalisé n’est pas valide.",
                            "A custom link scope is invalid."
                        );
                    }
                    if (!["none", "fa", "image"].includes(link.iconType)) {
                        return fail(
                            "Le type d’icône d’un lien personnalisé n’est pas valide.",
                            "A custom link icon type is invalid."
                        );
                    }
                    if (link.iconType === "fa" && !cleanText(link.iconClass)) {
                        return fail(
                            "Un lien configuré avec Font Awesome doit indiquer une classe d’icône.",
                            "A link configured with Font Awesome must provide an icon class."
                        );
                    }
                    if (link.iconType === "image" && !cleanText(link.imageUrl)) {
                        return fail(
                            "Un lien configuré avec une image doit indiquer l’URL de cette image.",
                            "A link configured with an image must provide its image URL."
                        );
                    }
                }

                const searchElse = config.searchElse || {};
                if (!["sidebar", "before-results", "after-breadcrumbs"].includes(searchElse.desktopPlacement)) {
                    return fail("L’emplacement bureau de « Rechercher ailleurs » n’est pas valide.", "The desktop Search elsewhere placement is invalid.");
                }
                if (!["before-results", "after-breadcrumbs", "sidebar"].includes(searchElse.mobilePlacement)) {
                    return fail("L’emplacement mobile de « Rechercher ailleurs » n’est pas valide.", "The mobile Search elsewhere placement is invalid.");
                }
                if (!["list", "buttons"].includes(searchElse.presentation)) {
                    return fail("La présentation de « Rechercher ailleurs » n’est pas valide.", "The Search elsewhere presentation is invalid.");
                }
                if (!Array.isArray(searchElse.links)) {
                    return fail("La liste « Rechercher ailleurs » n’est pas valide.", "The Search elsewhere link list is invalid.");
                }
                for (let i = 0; i < searchElse.links.length; i += 1) {
                    const link = searchElse.links[i] || {};
                    if (!cleanText(link.labelFr) && !cleanText(link.labelEn)) {
                        return fail("Chaque lien « Rechercher ailleurs » doit avoir un libellé.", "Each Search elsewhere link must have a label.");
                    }
                    if (!cleanText(link.urlTemplate)) {
                        return fail("Chaque lien « Rechercher ailleurs » doit avoir une structure d’URL.", "Each Search elsewhere link must have a URL template.");
                    }
                    if (!["all", "include", "exclude"].includes(link.branchesMode || "all")) {
                        return fail("Le filtre par site d’un lien « Rechercher ailleurs » n’est pas valide.", "A Search elsewhere branch filter is invalid.");
                    }
                    if (!["none", "fa", "image"].includes(link.iconType || "none")) {
                        return fail("Le type d’icône d’un lien « Rechercher ailleurs » n’est pas valide.", "A Search elsewhere icon type is invalid.");
                    }
                }

                if (!Array.isArray(config.pages)) {
                    return fail(
                        "La liste des pages configurées n’est pas valide.",
                        "Configured pages are invalid."
                    );
                }

                const seen = new Set();
                for (const page of config.pages) {
                    if (!page || !PAGE_ADAPTERS[page.pageId]) {
                        return fail(
                            "Une page configurée n’est pas prise en charge par ce module.",
                            "One configured page is not supported by this module."
                        );
                    }
                    if (seen.has(page.pageId)) {
                        return fail(
                            "Une même page ne peut pas être configurée deux fois.",
                            "The same page cannot be configured twice."
                        );
                    }
                    if (page.presentation && !["menu", "inline", "inline-grid"].includes(page.presentation)) {
                        return fail(
                            "La présentation des liens d’une page n’est pas valide.",
                            "A page link presentation is invalid."
                        );
                    }
                    const columns = Number(page.columns || 2);
                    if (!Number.isFinite(columns) || columns < 1 || columns > 8) {
                        return fail(
                            "Le nombre de colonnes doit être compris entre 1 et 8.",
                            "The number of columns must be between 1 and 8."
                        );
                    }
                    seen.add(page.pageId);
                }

                return { ok: true };
            },
            schema: [
                {
                    type: "section",
                    id: "presentation",
                    label: {
                        fr: "Bouton principal",
                        en: "Main button"
                    },
                    description: {
                        fr: "Par défaut, le bouton reprend le comportement historique : image du script d’origine, sans texte visible, avec le libellé accessible « Partager ».",
                        en: "By default, the button keeps the historical behavior: the original script image, no visible text, with the accessible label “Share”."
                    },
                    fields: [
                        {
                            key: "buttonLabelFr",
                            type: "text",
                            label: {
                                fr: "Libellé français du bouton",
                                en: "French button label"
                            }
                        },
                        {
                            key: "buttonLabelEn",
                            type: "text",
                            label: {
                                fr: "Libellé anglais du bouton",
                                en: "English button label"
                            }
                        },
                        {
                            key: "buttonShowLabel",
                            type: "boolean",
                            label: {
                                fr: "Afficher le texte du bouton",
                                en: "Show button text"
                            }
                        },
                        {
                            key: "buttonVisualType",
                            type: "select",
                            refreshOnChange: true,
                            label: {
                                fr: "Illustration du bouton",
                                en: "Button visual"
                            },
                            options: visualTypeOptions()
                        },
                        {
                            key: "buttonIconClass",
                            type: "text",
                            label: {
                                fr: "Classe Font Awesome",
                                en: "Font Awesome class"
                            },
                            placeholder: {
                                fr: "Ex. fa fa-external-link",
                                en: "E.g. fa fa-external-link"
                            },
                            when: function (rootObject) {
                                return rootObject.buttonVisualType === "fa";
                            }
                        },
                        {
                            key: "buttonImageUrl",
                            type: "imageUrl",
                            label: {
                                fr: "Image du bouton",
                                en: "Button image"
                            },
                            help: {
                                fr: "URL HTTPS, URL relative Koha ou image data: locale. La valeur historique est préconfigurée.",
                                en: "HTTPS URL, relative Koha URL or local data: image. The historical value is preconfigured."
                            },
                            when: function (rootObject) {
                                return rootObject.buttonVisualType === "image";
                            }
                        },
                        {
                            key: "buttonShowCaret",
                            type: "boolean",
                            label: {
                                fr: "Afficher la flèche de menu",
                                en: "Show menu caret"
                            }
                        },
                        {
                            type: "visualPreview",
                            label: { fr: "Aperçu du bouton", en: "Button preview" },
                            help: {
                                fr: "Aperçu fourni par le moteur visuel commun PMK. Utilise ensuite « Aperçu sur la page » pour vérifier le bouton et « Rechercher ailleurs » dans leur vrai contexte Koha.",
                                en: "Preview provided by the shared PMK visual engine. Then use ‘Preview on page’ to check the button and Search elsewhere in their real Koha context."
                            }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "legacy",
                    label: {
                        fr: "Liens déjà présents dans Koha",
                        en: "Links already present in Koha"
                    },
                    description: {
                        fr: "Cette source assure la compatibilité avec le script historique. Les liens existants conservent leur texte et leurs images/icônes.",
                        en: "This source preserves compatibility with the historical script. Existing links keep their text and images/icons."
                    },
                    fields: [
                        {
                            key: "includeExistingLinks",
                            type: "boolean",
                            label: {
                                fr: "Inclure les liens existants",
                                en: "Include existing links"
                            }
                        },
                        {
                            key: "existingLinksMode",
                            type: "select",
                            label: {
                                fr: "Détection des liens existants",
                                en: "Existing link detection"
                            },
                            options: [
                                {
                                    value: "historical",
                                    label: {
                                        fr: "Compatibilité historique : lien nouvel onglet ou élément avec image",
                                        en: "Historical compatibility: new-tab link or item containing an image"
                                    }
                                },
                                {
                                    value: "all",
                                    label: {
                                        fr: "Tous les liens du bloc .liens_externes",
                                        en: "All links in the .liens_externes block"
                                    }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "custom-links",
                    label: {
                        fr: "Liens personnalisés",
                        en: "Custom links"
                    },
                    description: {
                        fr: "Ajoute autant de liens que nécessaire. La structure d’URL accepte les variables {BIBLIONUMBER}, {TITLE}, {AUTHOR}, {ISBN}, {ISBN10}, {ISBN13}, {ISSN}, {EAN}, {CONTROLNUMBER}, {OCLC_NO}, {QUERY} et {CURRENT_URL}. Les valeurs sont encodées pour une URL ; ajoute _RAW au nom pour insérer la valeur brute, par exemple {TITLE_RAW}.",
                        en: "Add as many links as needed. URL templates accept {BIBLIONUMBER}, {TITLE}, {AUTHOR}, {ISBN}, {ISBN10}, {ISBN13}, {ISSN}, {EAN}, {CONTROLNUMBER}, {OCLC_NO}, {QUERY}, and {CURRENT_URL}. Values are URL-encoded; append _RAW for the raw value, for example {TITLE_RAW}."
                    },
                    fields: [
                        {
                            key: "customLinks",
                            type: "repeater",
                            label: {
                                fr: "Liens",
                                en: "Links"
                            },
                            addLabel: {
                                fr: "Ajouter un lien",
                                en: "Add a link"
                            },
                            emptyLabel: {
                                fr: "Aucun lien personnalisé. Les liens historiques restent disponibles si leur reprise est activée.",
                                en: "No custom link. Historical links remain available when existing-link import is enabled."
                            },
                            reorder: true,
                            newItem: function () {
                                return {
                                    enabled: true,
                                    labelFr: "Nouveau lien",
                                    labelEn: "New link",
                                    urlTemplate: "https://example.org/search?q={TITLE}",
                                    scope: "all",
                                    newWindow: true,
                                    showLabel: true,
                                    iconType: "none",
                                    iconClass: "fa fa-external-link",
                                    imageUrl: ""
                                };
                            },
                            itemTitle: function (item, index, lang) {
                                if (!item) return (lang === "en" ? "Link " : "Lien ") + (index + 1);
                                return lang === "en"
                                    ? (cleanText(item.labelEn) || cleanText(item.labelFr) || ("Link " + (index + 1)))
                                    : (cleanText(item.labelFr) || cleanText(item.labelEn) || ("Lien " + (index + 1)));
                            },
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: {
                                        fr: "Lien actif",
                                        en: "Link enabled"
                                    }
                                },
                                {
                                    key: "labelFr",
                                    type: "text",
                                    label: {
                                        fr: "Libellé français",
                                        en: "French label"
                                    }
                                },
                                {
                                    key: "labelEn",
                                    type: "text",
                                    label: {
                                        fr: "Libellé anglais",
                                        en: "English label"
                                    }
                                },
                                {
                                    key: "urlTemplate",
                                    type: "text",
                                    label: {
                                        fr: "Structure de l’URL",
                                        en: "URL template"
                                    },
                                    placeholder: {
                                        fr: "https://exemple.fr/recherche?q={ISBN}",
                                        en: "https://example.org/search?q={ISBN}"
                                    },
                                    help: {
                                        fr: "Un lien n’est pas affiché si une variable utilisée dans sa structure est absente de la notice.",
                                        en: "A link is not displayed when a variable used by its template is unavailable for the record."
                                    }
                                },
                                {
                                    key: "scope",
                                    type: "select",
                                    label: {
                                        fr: "Pages d’utilisation",
                                        en: "Pages"
                                    },
                                    options: [
                                        {
                                            value: "all",
                                            label: {
                                                fr: "Résultats + détail notice",
                                                en: "Search results + record detail"
                                            }
                                        },
                                        {
                                            value: "catalogue.search",
                                            label: {
                                                fr: "Résultats de recherche uniquement",
                                                en: "Search results only"
                                            }
                                        },
                                        {
                                            value: "catalogue.detail",
                                            label: {
                                                fr: "Détail notice uniquement",
                                                en: "Record detail only"
                                            }
                                        }
                                    ]
                                },
                                {
                                    key: "newWindow",
                                    type: "boolean",
                                    label: {
                                        fr: "Ouvrir dans un nouvel onglet",
                                        en: "Open in a new tab"
                                    }
                                },
                                {
                                    key: "showLabel",
                                    type: "boolean",
                                    label: {
                                        fr: "Afficher le texte du lien",
                                        en: "Show link text"
                                    }
                                },
                                {
                                    key: "iconType",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: {
                                        fr: "Icône / image du lien",
                                        en: "Link icon / image"
                                    },
                                    options: visualTypeOptions()
                                },
                                {
                                    key: "iconClass",
                                    type: "text",
                                    label: {
                                        fr: "Classe Font Awesome",
                                        en: "Font Awesome class"
                                    },
                                    placeholder: {
                                        fr: "Ex. fa fa-book",
                                        en: "E.g. fa fa-book"
                                    },
                                    when: function (rootObject, path) {
                                        const item = customLinkAt(rootObject, path);
                                        return Boolean(item && item.iconType === "fa");
                                    }
                                },
                                {
                                    key: "imageUrl",
                                    type: "imageUrl",
                                    label: {
                                        fr: "Image du lien",
                                        en: "Link image"
                                    },
                                    when: function (rootObject, path) {
                                        const item = customLinkAt(rootObject, path);
                                        return Boolean(item && item.iconType === "image");
                                    }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "search-else",
                    label: { fr: "Rechercher ailleurs", en: "Search elsewhere" },
                    description: {
                        fr: "Fonction issue du script 037. Ce bloc est indépendant des liens de notice : il relance la recherche Koha courante sur des services externes et est volontairement rendu dans une autre zone de la page.",
                        en: "Feature migrated from script 037. This block is independent from record links: it relaunches the current Koha search on external services and is intentionally rendered elsewhere on the page."
                    },
                    fields: [
                        { key: "searchElse.enabled", type: "boolean", label: { fr: "Activer « Rechercher ailleurs »", en: "Enable Search elsewhere" } },
                        { key: "searchElse.titleFr", type: "text", label: { fr: "Titre français", en: "French title" } },
                        { key: "searchElse.titleEn", type: "text", label: { fr: "Titre anglais", en: "English title" } },
                        {
                            key: "searchElse.desktopPlacement", type: "select",
                            label: { fr: "Emplacement sur grand écran", en: "Desktop placement" },
                            options: [
                                { value: "sidebar", label: { fr: "Barre latérale", en: "Sidebar" } },
                                { value: "before-results", label: { fr: "Au-dessus des résultats", en: "Above results" } },
                                { value: "after-breadcrumbs", label: { fr: "Après le fil d’Ariane", en: "After breadcrumbs" } }
                            ]
                        },
                        {
                            key: "searchElse.mobilePlacement", type: "select",
                            label: { fr: "Emplacement sur petit écran", en: "Mobile placement" },
                            options: [
                                { value: "before-results", label: { fr: "Au-dessus des résultats", en: "Above results" } },
                                { value: "after-breadcrumbs", label: { fr: "Après le fil d’Ariane", en: "After breadcrumbs" } },
                                { value: "sidebar", label: { fr: "Barre latérale si disponible", en: "Sidebar when available" } }
                            ]
                        },
                        { key: "searchElse.mobileBreakpoint", type: "number", advanced: true, label: { fr: "Seuil mobile (px)", en: "Mobile breakpoint (px)" } },
                        {
                            key: "searchElse.presentation", type: "select",
                            label: { fr: "Présentation des liens", en: "Link presentation" },
                            options: [
                                { value: "list", label: { fr: "Liste verticale", en: "Vertical list" } },
                                { value: "buttons", label: { fr: "Boutons", en: "Buttons" } }
                            ]
                        },
                        {
                            key: "searchElse.links",
                            type: "repeater",
                            label: { fr: "Sources externes", en: "External sources" },
                            addLabel: { fr: "Ajouter une source", en: "Add a source" },
                            emptyLabel: { fr: "Aucune source externe configurée.", en: "No external source configured." },
                            reorder: true,
                            newItem: function () {
                                return { enabled: true, labelFr: "Nouvelle source", labelEn: "New source", urlTemplate: "https://example.org/search?q={QUERY}", newWindow: true, showLabel: true, iconType: "none", iconClass: "fa fa-external-link", imageUrl: "", branchesMode: "all", branchCodes: "" };
                            },
                            itemTitle: function (item, index, lang) {
                                if (!item) return (lang === "en" ? "Source " : "Source ") + (index + 1);
                                return lang === "en" ? (cleanText(item.labelEn) || cleanText(item.labelFr) || ("Source " + (index + 1))) : (cleanText(item.labelFr) || cleanText(item.labelEn) || ("Source " + (index + 1)));
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Source active", en: "Source enabled" } },
                                { key: "labelFr", type: "text", label: { fr: "Libellé français", en: "French label" } },
                                { key: "labelEn", type: "text", label: { fr: "Libellé anglais", en: "English label" } },
                                { key: "urlTemplate", type: "text", label: { fr: "Structure de l’URL", en: "URL template" }, help: { fr: "Variables : {QUERY}, {INDEX}, {BRANCH}, {CURRENT_URL}. Elles sont encodées automatiquement. Ajoutez _RAW pour insérer une valeur brute.", en: "Variables: {QUERY}, {INDEX}, {BRANCH}, {CURRENT_URL}. They are URL-encoded automatically. Append _RAW for raw insertion." } },
                                { key: "newWindow", type: "boolean", label: { fr: "Ouvrir dans un nouvel onglet", en: "Open in a new tab" } },
                                { key: "showLabel", type: "boolean", label: { fr: "Afficher le texte", en: "Show text" } },
                                { key: "iconType", type: "select", label: { fr: "Icône / image", en: "Icon / image" }, options: visualTypeOptions() },
                                { key: "iconClass", type: "text", label: { fr: "Classe Font Awesome", en: "Font Awesome class" } },
                                { key: "imageUrl", type: "imageUrl", label: { fr: "Image", en: "Image" } },
                                {
                                    key: "branchesMode", type: "select", label: { fr: "Disponibilité par site", en: "Branch availability" },
                                    options: [
                                        { value: "all", label: { fr: "Tous les sites", en: "All branches" } },
                                        { value: "include", label: { fr: "Uniquement les sites indiqués", en: "Only listed branches" } },
                                        { value: "exclude", label: { fr: "Tous sauf les sites indiqués", en: "All except listed branches" } }
                                    ]
                                },
                                { key: "branchCodes", type: "text", label: { fr: "Codes sites", en: "Branch codes" }, placeholder: { fr: "DRA, ARC, MUY", en: "DRA, ARC, MUY" }, help: { fr: "Codes séparés par des virgules, espaces ou points-virgules.", en: "Codes separated by commas, spaces or semicolons." } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "pages",
                    label: {
                        fr: "Pages configurées",
                        en: "Configured pages"
                    },
                    description: {
                        fr: "Active ou désactive le module page par page. Les détails techniques de détection restent gérés par l’adaptateur Koha.",
                        en: "Enable or disable the module per page. Technical detection details remain handled by the Koha adapter."
                    },
                    fields: [
                        {
                            key: "pages",
                            type: "repeater",
                            label: {
                                fr: "Pages",
                                en: "Pages"
                            },
                            addLabel: {
                                fr: "Ajouter une page",
                                en: "Add a page"
                            },
                            emptyLabel: {
                                fr: "Aucune page activée pour ce module.",
                                en: "No page configured for this module."
                            },
                            reorder: false,
                            canAdd: function (_rootObject, _fieldPath, items) {
                                return Array.isArray(items) && items.length < Object.keys(PAGE_ADAPTERS).length;
                            },
                            newItem: function (rootObject) {
                                const pageId = nextMissingPage(rootObject);
                                return pagePresentationDefaults(pageId);
                            },
                            itemTitle: function (item, index, lang) {
                                const page = item && PAGE_ADAPTERS[item.pageId];
                                if (!page) return "Page " + (index + 1);
                                return page.label[lang] || page.label.fr || page.id;
                            },
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: {
                                        fr: "Activer sur cette page",
                                        en: "Enable on this page"
                                    }
                                },
                                {
                                    key: "pageId",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: {
                                        fr: "Page Koha",
                                        en: "Koha page"
                                    },
                                    options: pageOptions(),
                                    onChange: function (rootObject, fieldPath, value) {
                                        const index = fieldPath[fieldPath.length - 2];
                                        if (!Array.isArray(rootObject.pages) || !rootObject.pages[index]) return;
                                        const previousEnabled = rootObject.pages[index].enabled !== false;
                                        rootObject.pages[index] = Object.assign(pagePresentationDefaults(value), {
                                            pageId: value,
                                            enabled: previousEnabled,
                                            path: pagePath(value)
                                        });
                                    }
                                },
                                {
                                    key: "path",
                                    type: "text",
                                    readOnly: true,
                                    label: {
                                        fr: "Chemin Koha",
                                        en: "Koha path"
                                    }
                                },
                                {
                                    key: "presentation",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Présentation des liens", en: "Link presentation" },
                                    options: [
                                        { value: "menu", label: { fr: "Menu compact", en: "Compact menu" } },
                                        { value: "inline", label: { fr: "Liens toujours visibles en ligne", en: "Always-visible inline links" } },
                                        { value: "inline-grid", label: { fr: "Grille de boutons", en: "Button grid" } }
                                    ],
                                    help: {
                                        fr: "Sur detail.pl, le menu compact est la valeur par défaut historique du 010. La grille 2×2 héritée du 107 reste disponible en option.",
                                        en: "On detail.pl, the compact menu is the historical 010 default. The 2×2 grid inherited from 107 remains available as an option."
                                    }
                                },
                                {
                                    key: "columns",
                                    type: "number",
                                    min: 1,
                                    max: 8,
                                    step: 1,
                                    label: { fr: "Nombre de colonnes", en: "Number of columns" },
                                    when: function (root, path) {
                                        const index = path[path.length - 2];
                                        return Boolean(root.pages && root.pages[index] && root.pages[index].presentation === "inline-grid");
                                    }
                                },
                                { key: "gap", type: "text", label: { fr: "Espace entre les liens", en: "Gap between links" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkPadding", type: "text", label: { fr: "Espacement interne des liens", en: "Link padding" }, advanced: true, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkJustifyContent", type: "text", advanced: true, label: { fr: "Alignement du contenu", en: "Content alignment" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkTextAlign", type: "text", advanced: true, label: { fr: "Alignement du texte", en: "Text alignment" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "iconGap", type: "text", advanced: true, label: { fr: "Espace icône / texte", en: "Icon / text gap" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkBackground", type: "color", label: { fr: "Fond des liens", en: "Link background" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkHoverBackground", type: "color", label: { fr: "Fond au survol", en: "Hover background" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkColor", type: "color", label: { fr: "Couleur du texte", en: "Text color" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkHoverColor", type: "color", label: { fr: "Couleur du texte au survol", en: "Hover text color" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkBorder", type: "text", advanced: true, label: { fr: "Bordure", en: "Border" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkBorderRadius", type: "text", label: { fr: "Arrondi", en: "Radius" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkFontSize", type: "text", label: { fr: "Taille du texte", en: "Text size" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkFontWeight", type: "text", advanced: true, label: { fr: "Graisse du texte", en: "Font weight" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkBoxShadow", type: "text", advanced: true, label: { fr: "Ombre", en: "Shadow" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "linkHoverBoxShadow", type: "text", advanced: true, label: { fr: "Ombre au survol", en: "Hover shadow" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "hoverTranslateY", type: "text", advanced: true, label: { fr: "Déplacement vertical au survol", en: "Hover vertical shift" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "imageRadius", type: "text", advanced: true, label: { fr: "Arrondi des images", en: "Image radius" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "imageBoxShadow", type: "text", advanced: true, label: { fr: "Ombre des images", en: "Image shadow" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "imageHoverBoxShadow", type: "text", advanced: true, label: { fr: "Ombre des images au survol", en: "Image hover shadow" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } },
                                { key: "imageHoverScale", type: "number", min: 1, max: 2, step: 0.01, advanced: true, label: { fr: "Agrandissement des images au survol", en: "Image hover scale" }, when: function (root, path) { const i = path[path.length - 2]; return Boolean(root.pages && root.pages[i] && root.pages[i].presentation !== "menu"); } }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main || !context) return;
                const wanted = context.sectionId || "custom-links";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    function registerVisualEditorWithPMK() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: { inlinePreview: true, livePreview: true },
            canPreview: function () { return Boolean(adapter); },
            previewModel: function (context) {
                const cfg = context && context.rootObject ? context.rootObject : DEFAULT_CONFIG;
                const lang = currentLanguage();
                const label = lang === "en" ? (cfg.buttonLabelEn || cfg.buttonLabelFr || "Share") : (cfg.buttonLabelFr || cfg.buttonLabelEn || "Partager");
                const icon = cfg.buttonVisualType === "image"
                    ? { type: "image", url: cfg.buttonImageUrl || "", position: "before", size: 20 }
                    : cfg.buttonVisualType === "fa"
                        ? { type: "fa", className: cfg.buttonIconClass || "fa fa-share-alt", position: "before", size: 16 }
                        : { type: "none" };
                return {
                    text: cfg.buttonShowLabel === true ? label : "",
                    title: label,
                    icon: icon,
                    style: { fontSize: "14px", fontWeight: "600", color: "#212529" }
                };
            },
            previewDraft: function (draft) {
                if (!adapter) throw new Error("visual_preview_wrong_page");
                const before = clone(state.config || DEFAULT_CONFIG);
                state.config = clone(draft || DEFAULT_CONFIG);
                rebuildAll();
                return function () {
                    state.config = before;
                    rebuildAll();
                };
            }
        });
        return true;
    }

    function registerWithPMK() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        window.PMKConfig.registerModule(moduleDefinition());
        registerVisualEditorWithPMK();
        return true;
    }

    registerWithPMK();
    window.addEventListener("pmk:config-ready", registerWithPMK, { once: true });

    const adapter = Object.values(PAGE_ADAPTERS).find(function (candidate) {
        return candidate.matches();
    });

    /* Fail-safe et performance : aucune initialisation métier sur les autres pages. */
    if (!adapter) return;

    if (window.__PMK_EXTERNAL_LINKS_010__) {
        if (typeof window.__PMK_EXTERNAL_LINKS_010__.refresh === "function") {
            window.__PMK_EXTERNAL_LINKS_010__.refresh();
        }
        return;
    }

    const state = {
        adapter: adapter,
        config: clone(DEFAULT_CONFIG),
        observer: null,
        unsubscribe: null,
        rebuildTimer: null,
        outsideListenerAdded: false,
        viewportListenerAdded: false,
        currentOpenMenu: null,
        currentOpenButton: null,
        initialized: false
    };

    function pageIsEnabled(config) {
        if (!config || config.enabled === false) return false;
        const pages = Array.isArray(config.pages) ? config.pages : [];
        const page = pages.find(function (item) {
            return item && item.pageId === adapter.id;
        });
        return Boolean(page && page.enabled !== false);
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .${SOURCE_HIDDEN_CLASS} {
                display: none !important;
            }
            .${GENERATED_HOST_CLASS} {
                display: inline;
            }
            .${WRAPPER_CLASS} {
                display: inline-flex;
                align-items: center;
                gap: .15rem;
                margin-left: .25rem;
                vertical-align: middle;
            }
            .${TOGGLE_CLASS} {
                display: inline-flex !important;
                align-items: center;
                justify-content: center;
                gap: .38rem;
                max-width: 100%;
                white-space: nowrap;
            }
            .${TOGGLE_CLASS}.pmk-external-links-icon-only {
                width: 40px;
                min-width: 40px;
                height: 40px;
                min-height: 40px;
                padding: 5px !important;
            }
            .${TOGGLE_CLASS} .pmk-external-links-button-image {
                width: 20px;
                height: 20px;
                max-width: 20px;
                max-height: 20px;
                object-fit: contain;
                display: block;
                flex: 0 0 auto;
            }
            .${TOGGLE_CLASS} .pmk-external-links-label {
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .${MENU_CLASS} {
                position: fixed;
                z-index: 1085;
                display: none;
                min-width: 12rem;
                max-width: min(26rem, calc(100vw - 1rem));
                max-height: min(70vh, 34rem);
                overflow: auto;
                padding: .35rem 0;
                margin: 0;
                background: var(--bs-body-bg, #fff);
                color: var(--bs-body-color, #212529);
                border: 1px solid rgba(0, 0, 0, .18);
                border-radius: .35rem;
                box-shadow: 0 .35rem 1rem rgba(0, 0, 0, .16);
                list-style: none;
                box-sizing: border-box;
            }
            .${MENU_CLASS}.is-open {
                display: block;
            }
            .${MENU_CLASS} > li {
                display: block;
                margin: 0;
                padding: 0;
                list-style: none;
            }
            .${MENU_CLASS} > li > a {
                display: flex;
                align-items: center;
                gap: .5rem;
                width: 100%;
                min-width: 0;
                min-height: 2.2rem;
                padding: .45rem .75rem;
                color: inherit;
                text-decoration: none;
                overflow-wrap: anywhere;
                box-sizing: border-box;
            }
            .${MENU_CLASS} > li > a:hover,
            .${MENU_CLASS} > li > a:focus {
                background: rgba(13, 110, 253, .08);
                text-decoration: none;
                outline: none;
            }
            .${MENU_CLASS} img,
            .${MENU_CLASS} .pmk-external-links-custom-image {
                max-width: 1.35rem;
                max-height: 1.35rem;
                width: auto;
                height: auto;
                object-fit: contain;
                flex: 0 0 auto;
            }
            .${MENU_CLASS} .pmk-external-links-custom-icon {
                width: 1.35rem;
                text-align: var(--pmk-ext-text-align, center);
                flex: 0 0 auto;
            }
            .${MENU_CLASS} .pmk-external-links-custom-label {
                min-width: 0;
                overflow-wrap: anywhere;
            }
            @media (max-width: 576px) {
                .${TOGGLE_CLASS} {
                    min-height: 2.25rem;
                }
                .${MENU_CLASS} {
                    max-width: calc(100vw - .75rem);
                }
            }
            .pmk-external-links-inline {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: var(--pmk-ext-gap, 6px);
                margin: 4px 0 8px;
                padding: 0;
                list-style: none;
            }
            .pmk-external-links-inline.is-grid {
                display: grid;
                grid-template-columns: repeat(var(--pmk-ext-columns, 2), minmax(0, 1fr));
            }
            .pmk-external-links-inline > li {
                margin: 0;
                padding: 0;
                list-style: none;
                min-width: 0;
            }
            .pmk-external-links-inline > li > a {
                display: flex;
                align-items: center;
                justify-content: var(--pmk-ext-link-justify, center);
                gap: var(--pmk-ext-icon-gap, 4px);
                min-width: 0;
                width: 100%;
                box-sizing: border-box;
                padding: var(--pmk-ext-link-padding, 6px 8px);
                background: var(--pmk-ext-link-bg, #eceff1);
                color: var(--pmk-ext-link-color, #455a64);
                border: var(--pmk-ext-link-border, 0);
                border-radius: var(--pmk-ext-link-radius, 6px);
                font-size: var(--pmk-ext-link-size, .78em);
                font-weight: var(--pmk-ext-link-weight, 600);
                text-align: center;
                text-decoration: none;
                box-shadow: var(--pmk-ext-link-shadow, 0 1px 3px rgba(96,125,139,.18));
                transition: background .15s, color .15s, box-shadow .15s, transform .1s;
                overflow-wrap: anywhere;
            }
            .pmk-external-links-inline > li > a:hover,
            .pmk-external-links-inline > li > a:focus {
                background: var(--pmk-ext-link-hover-bg, #e1e6e9);
                color: var(--pmk-ext-link-hover-color, #455a64);
                box-shadow: var(--pmk-ext-link-hover-shadow, 0 2px 5px rgba(96,125,139,.24));
                transform: translateY(var(--pmk-ext-hover-y, -1px));
                text-decoration: none;
            }
            .pmk-external-links-inline img {
                width: auto;
                height: auto;
                max-width: 1.35rem;
                max-height: 1.35rem;
                border-radius: var(--pmk-ext-image-radius, 4px);
                box-shadow: var(--pmk-ext-image-shadow, 0 1px 3px rgba(0,0,0,.15));
                transition: transform .15s, box-shadow .15s;
                object-fit: contain;
            }
            .pmk-external-links-inline a:hover img,
            .pmk-external-links-inline a:focus img {
                transform: scale(var(--pmk-ext-image-scale, 1.12));
                box-shadow: var(--pmk-ext-image-hover-shadow, 0 3px 8px rgba(0,0,0,.25));
            }
            @media (max-width: 576px) {
                .pmk-external-links-inline.is-grid {
                    grid-template-columns: 1fr;
                }
            }

            #pmk-search-else {
                display: block;
                width: 100%;
                box-sizing: border-box;
                margin: .5rem 0 1rem;
                border: 1px solid #cfd8d1;
                border-radius: .45rem;
                background: #fff;
                overflow: hidden;
            }
            #pmk-search-else .pmk-search-else-title {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: .5rem;
                margin: 0;
                padding: .55rem .7rem;
                font-size: .92rem;
                font-weight: 700;
                background: #e9f1eb;
                border-bottom: 1px solid #cfd8d1;
            }
            #pmk-search-else .pmk-search-else-query {
                display: block;
                padding: .45rem .7rem 0;
                color: #59636b;
                font-size: .8rem;
                overflow-wrap: anywhere;
            }
            #pmk-search-else .pmk-search-else-links {
                display: flex;
                flex-direction: column;
                gap: .15rem;
                margin: 0;
                padding: .45rem .6rem .6rem;
                list-style: none;
            }
            #pmk-search-else.pmk-search-else-buttons .pmk-search-else-links {
                flex-direction: row;
                flex-wrap: wrap;
                gap: .4rem;
            }
            #pmk-search-else .pmk-search-else-link {
                display: inline-flex;
                align-items: center;
                gap: .4rem;
                min-width: 0;
                padding: .28rem .35rem;
                text-decoration: none;
                overflow-wrap: anywhere;
            }
            #pmk-search-else.pmk-search-else-buttons .pmk-search-else-link {
                border: 1px solid #ced4da;
                border-radius: .35rem;
                background: #f8f9fa;
                padding: .35rem .55rem;
            }
            #pmk-search-else .pmk-search-else-image {
                width: 20px;
                height: 20px;
                object-fit: contain;
                flex: 0 0 auto;
            }
            @media (max-width: 768px) {
                #pmk-search-else { margin: .65rem 0; }
                #pmk-search-else .pmk-search-else-links { gap: .3rem; }
                #pmk-search-else .pmk-search-else-link { min-height: 38px; }
            }
        `;
        document.head.appendChild(style);
    }

    function normalizeAnchor(anchor) {
        if (!anchor || !anchor.getAttribute) return null;
        const rawHref = cleanText(anchor.getAttribute("href"));
        if (!rawHref || rawHref === "#" || /^javascript:/i.test(rawHref) || /^data:/i.test(rawHref)) return null;
        return anchor;
    }

    function safeImageUrl(value) {
        const raw = cleanText(value);
        if (!raw) return "";
        if (/^data:image\//i.test(raw)) return raw;
        if (/^(https?:)?\/\//i.test(raw)) return raw;
        if (/^(\/|\.\/|\.\.\/)/.test(raw)) return raw;
        return "";
    }

    function sanitizeFaClasses(value, fallback) {
        const classes = cleanText(value)
            .split(/\s+/)
            .filter(function (part) {
                return /^[a-z0-9_-]+$/i.test(part);
            });
        if (!classes.length) return fallback || "fa fa-external-link";
        return classes.join(" ");
    }

    function sourceEntries(section) {
        if (!state.config.includeExistingLinks) return [];

        const entries = [];
        const seen = new Set();
        const mode = state.config.existingLinksMode === "all" ? "all" : "historical";

        section.querySelectorAll("li").forEach(function (li) {
            if (mode === "historical") {
                const historicalMatch =
                    li.querySelector('a[target="_blank"]') ||
                    li.querySelector("img");
                if (!historicalMatch) return;
            }

            const anchor = normalizeAnchor(li.querySelector("a[href]"));
            if (!anchor) return;

            const key = cleanText(anchor.href || anchor.getAttribute("href"));
            if (seen.has(key)) return;
            seen.add(key);
            entries.push({
                kind: "existing",
                source: li,
                anchor: anchor,
                hrefKey: key
            });
        });

        /*
         * Le mode "all" accepte aussi les structures sans <li>.
         * Le mode historique reste strictement compatible avec l'ancien script.
         */
        if (mode === "all" && !entries.length) {
            section.querySelectorAll("a[href]").forEach(function (anchor) {
                const valid = normalizeAnchor(anchor);
                if (!valid) return;
                const key = cleanText(valid.href || valid.getAttribute("href"));
                if (seen.has(key)) return;
                seen.add(key);
                entries.push({
                    kind: "existing",
                    source: valid,
                    anchor: valid,
                    hrefKey: key
                });
            });
        }

        return entries;
    }

    function sanitizeClonedAnchor(anchor) {
        window.PMKWorkbench?.describeLink(anchor);
        if (!anchor) return;
        anchor.removeAttribute("id");
        anchor.querySelectorAll("[id]").forEach(function (node) {
            node.removeAttribute("id");
        });

        if (anchor.getAttribute("target") === "_blank") {
            const rel = new Set(cleanText(anchor.getAttribute("rel")).split(/\s+/).filter(Boolean));
            rel.add("noopener");
            rel.add("noreferrer");
            anchor.setAttribute("rel", Array.from(rel).join(" "));
        }

        const visibleText = cleanText(anchor.textContent);
        if (!visibleText && !anchor.getAttribute("aria-label")) {
            const image = anchor.querySelector("img[alt]");
            const imageAlt = image ? cleanText(image.getAttribute("alt")) : "";
            if (imageAlt) {
                anchor.setAttribute("aria-label", imageAlt);
            } else {
                try {
                    anchor.setAttribute("aria-label", new URL(anchor.href, window.location.href).hostname);
                } catch (_) {
                    anchor.setAttribute("aria-label", buttonLabel(state.config));
                }
            }
        }
    }

    function existingMenuItem(entry) {
        if (entry.source && String(entry.source.tagName || "").toLowerCase() === "li") {
            const item = entry.source.cloneNode(true);

            /*
             * Le <li> source est masqué juste avant sa copie dans le menu PMK.
             * cloneNode() recopie donc aussi SOURCE_HIDDEN_CLASS : le clone
             * devient invisible à son tour. C'était particulièrement visible
             * avec Electre, souvent repris depuis le lien historique Koha alors
             * que Babelio/Google étaient reconstruits comme liens custom.
             */
            item.classList.remove(SOURCE_HIDDEN_CLASS);
            item.removeAttribute("data-pmk-external-links-source");
            delete item.dataset.pmkExternalLinksSource;

            item.removeAttribute("id");
            item.querySelectorAll("[id]").forEach(function (node) {
                node.removeAttribute("id");
            });
            item.querySelectorAll("a[href]").forEach(sanitizeClonedAnchor);
            return item;
        }

        const item = document.createElement("li");
        const cloned = entry.anchor.cloneNode(true);
        sanitizeClonedAnchor(cloned);
        item.appendChild(cloned);
        return item;
    }

    function sectionRecordRoot(section) {
        if (adapter.id === "catalogue.detail") return document;

        return (
            section.closest("tr") ||
            section.closest('[id^="title_summary_"]') ||
            section.closest(".bibliocol") ||
            section.parentElement ||
            document
        );
    }

    function firstElement(root, selectors) {
        if (!root || !root.querySelector) return null;
        for (const selector of selectors) {
            const found = root.querySelector(selector);
            if (found) return found;
        }
        return null;
    }

    function firstText(root, selectors) {
        const element = firstElement(root, selectors);
        return element ? cleanText(element.textContent) : "";
    }

    function firstAttribute(root, selectors, attribute) {
        const element = firstElement(root, selectors);
        return element ? cleanText(element.getAttribute(attribute)) : "";
    }

    function parseCoins(root) {
        const output = {};
        if (!root || !root.querySelector) return output;

        const coin = root.querySelector(".Z3988[title]");
        if (!coin) return output;

        const raw = cleanText(coin.getAttribute("title")).replace(/&amp;/g, "&");
        if (!raw) return output;

        try {
            const params = new URLSearchParams(raw);
            params.forEach(function (value, key) {
                if (!(key in output) && cleanText(value)) output[key] = cleanText(value);
            });
        } catch (_) {
            return {};
        }
        return output;
    }

    function isbnDigits(value) {
        return cleanText(value)
            .replace(/^ISBN(?:-1[03])?\s*:?\s*/i, "")
            .replace(/[^0-9Xx]/g, "")
            .toUpperCase();
    }

    function issnDigits(value) {
        const raw = cleanText(value).replace(/^ISSN\s*:?\s*/i, "");
        const compact = raw.replace(/[^0-9Xx]/g, "").toUpperCase();
        if (compact.length !== 8) return compact;
        return compact.slice(0, 4) + "-" + compact.slice(4);
    }

    function isbn10To13(value) {
        const isbn10 = isbnDigits(value);
        if (!/^[0-9]{9}[0-9X]$/.test(isbn10)) return "";

        const base = "978" + isbn10.slice(0, 9);
        let sum = 0;
        for (let i = 0; i < 12; i += 1) {
            sum += Number(base[i]) * (i % 2 === 0 ? 1 : 3);
        }
        const check = (10 - (sum % 10)) % 10;
        return base + String(check);
    }

    function isbn13To10(value) {
        const isbn13 = isbnDigits(value);
        if (!/^978[0-9]{10}$/.test(isbn13)) return "";

        const body = isbn13.slice(3, 12);
        let sum = 0;
        for (let i = 0; i < 9; i += 1) {
            sum += Number(body[i]) * (10 - i);
        }
        const remainder = 11 - (sum % 11);
        const check = remainder === 10 ? "X" : (remainder === 11 ? "0" : String(remainder));
        return body + check;
    }

    function extractFormattedIsbn(root) {
        if (!root) return "";

        const direct = firstText(root, [
            ".isbn-result",
            ".tech-isbn",
            ".isbn",
            ".ISBN"
        ]);
        if (direct) {
            const match = direct.match(/(?:ISBN(?:-1[03])?\s*:?\s*)?([0-9Xx][0-9Xx\s-]{8,20})/i);
            if (match) return cleanText(match[1]).replace(/\s+/g, "");
        }

        const dataIsbn = firstAttribute(root, ["[data-isbn]"], "data-isbn");
        if (dataIsbn) return cleanText(dataIsbn).replace(/\s+/g, "");

        const text = cleanText(root.textContent);
        const match = text.match(/\bISBN(?:-1[03])?\s*:?\s*([0-9Xx][0-9Xx\s-]{8,20})/i);
        return match ? cleanText(match[1]).replace(/\s+/g, "") : "";
    }

    function existingElectreHref(root) {
        if (!root || !root.querySelector) return "";
        const anchor = root.querySelector(
            'a[href*="electre-ng.com/#/search"], a[href*="electre-ng.com"][href*="identifiant"]'
        );
        return anchor ? cleanText(anchor.href || anchor.getAttribute("href")) : "";
    }

    function isbnFromElectreHref(root) {
        const href = existingElectreHref(root);
        if (!href) return "";
        let decoded = href;
        try { decoded = decodeURIComponent(href); } catch (_) {}
        const match = decoded.match(/identifiant\s*:\s*["“]?([^"&)%]+)["”]?/i);
        if (!match) return "";
        return cleanText(match[1]).replace(/\s+/g, "");
    }

    function electreCompatibleIsbn(formatted, isbn, isbn13) {
        let value = cleanText(formatted);
        const compact = isbnDigits(value || isbn);
        if (compact.length === 13) return value || compact;
        if (compact.length === 10 && isbn13) return cleanText(isbn13);
        return value || cleanText(isbn13) || cleanText(isbn);
    }

    function extractBiblionumber(root) {
        if (adapter.id === "catalogue.detail") {
            try {
                const value = new URLSearchParams(window.location.search).get("biblionumber");
                if (value) return cleanText(value);
            } catch (_) {
                /* silence */
            }
        }

        const titleSummary =
            (root && root.matches && root.matches('[id^="title_summary_"]') ? root : null) ||
            (root && root.querySelector ? root.querySelector('[id^="title_summary_"]') : null);

        if (titleSummary && /^title_summary_(\d+)$/.test(titleSummary.id || "")) {
            return RegExp.$1;
        }

        const checkbox = firstElement(root, [
            'input[name="biblionumber"][value]',
            'input.cb[value]'
        ]);
        if (checkbox && cleanText(checkbox.value)) return cleanText(checkbox.value);

        const detailLink = firstElement(root, [
            'a.title[href*="biblionumber="]',
            'a[href*="/catalogue/detail.pl?biblionumber="]',
            'a[href*="detail.pl?biblionumber="]'
        ]);
        if (detailLink) {
            try {
                return cleanText(new URL(detailLink.href, window.location.href).searchParams.get("biblionumber"));
            } catch (_) {
                /* silence */
            }
        }

        return "";
    }

    function extractStandardNumberFromText(root, label) {
        if (!root) return "";
        const text = cleanText(root.textContent);
        if (!text) return "";

        if (label === "ISBN") {
            const match = text.match(/\bISBN(?:-1[03])?\s*:?\s*([0-9Xx][0-9Xx\s-]{8,20})/i);
            return match ? isbnDigits(match[1]) : "";
        }
        if (label === "ISSN") {
            const match = text.match(/\bISSN\s*:?\s*([0-9Xx]{4}\s*-?\s*[0-9Xx]{4})/i);
            return match ? issnDigits(match[1]) : "";
        }
        return "";
    }

    function recordContext(section) {
        const root = sectionRecordRoot(section);
        const coins = parseCoins(root);

        let biblionumber = extractBiblionumber(root);

        let title =
            cleanText(coins["rft.title"]) ||
            cleanText(coins["rft.btitle"]) ||
            firstText(root, [
                "a.title",
                ".title",
                'a[href*="/catalogue/detail.pl?biblionumber="]',
                'a[href*="detail.pl?biblionumber="]'
            ]);

        let author =
            cleanText(coins["rft.au"]) ||
            [coins["rft.aulast"], coins["rft.aufirst"]].filter(Boolean).join(" ").trim() ||
            firstText(root, [
                ".author.resource_list a",
                ".author a",
                ".author",
                ".byAuthor + .author",
                '[class*="author"] a'
            ]);

        const bibliographicRoot =
            adapter.id === "catalogue.detail"
                ? (document.querySelector("#catalogue_detail_biblio") || root)
                : root;

        const formattedIsbnFromDom = extractFormattedIsbn(bibliographicRoot);
        const legacyElectreIsbn = isbnFromElectreHref(bibliographicRoot);

        const isbnSourceText =
            cleanText(legacyElectreIsbn) ||
            cleanText(coins["rft.isbn"]) ||
            cleanText(formattedIsbnFromDom) ||
            cleanText(firstText(bibliographicRoot, [".isbn-result", ".tech-isbn", ".isbn", ".ISBN"])) ||
            cleanText(firstAttribute(bibliographicRoot, ["[data-isbn]"], "data-isbn"));

        let isbn =
            isbnDigits(isbnSourceText) ||
            extractStandardNumberFromText(bibliographicRoot, "ISBN");

        let isbnFormatted = cleanText(legacyElectreIsbn || formattedIsbnFromDom || isbnSourceText)
            .replace(/^ISBN(?:-1[03])?\s*:?\s*/i, "")
            .replace(/\s+/g, "")
            .trim();
        if (!isbnFormatted) isbnFormatted = isbn;

        let issn =
            issnDigits(coins["rft.issn"]) ||
            issnDigits(firstText(root, [".issn", ".ISSN"])) ||
            extractStandardNumberFromText(root, "ISSN");

        let controlnumber =
            cleanText(coins["rft_id"]) ||
            firstText(root, [".control-number", ".controlnumber", ".controlNumber"]);

        let oclc = "";
        const possibleOclc = [
            coins["rft.oclcnum"],
            coins["oclcnum"],
            controlnumber
        ].filter(Boolean).join(" ");
        const oclcMatch = cleanText(possibleOclc).match(/(?:OCoLC|oclcnum[\/:=]?|OCLC\s*)?(\d{5,})/i);
        if (oclcMatch) oclc = oclcMatch[1];

        const isbn10 =
            isbn.length === 10
                ? isbn
                : (isbn.length === 13 ? isbn13To10(isbn) : "");
        const isbn13 =
            isbn.length === 13
                ? isbn
                : (isbn.length === 10 ? isbn10To13(isbn) : "");

        // Electre attend un identifiant exploitable. Lorsque Koha ne fournit
        // qu'un ISBN10 dans data-isbn, on bascule vers l'ISBN13 calculé.
        isbnFormatted = electreCompatibleIsbn(isbnFormatted, isbn, isbn13);

        const ean =
            cleanText(firstAttribute(root, ["[data-ean]"], "data-ean")).replace(/\D/g, "") ||
            isbn13;

        if (!title && adapter.id === "catalogue.detail") {
            title = firstText(document, [
                "#catalogue_detail_biblio h1",
                "#catalogue_detail_biblio a.title",
                "#catalogue_detail_biblio .title"
            ]);
        }

        if (!author && adapter.id === "catalogue.detail") {
            author = firstText(document, [
                "#catalogue_detail_biblio .author.resource_list a",
                "#catalogue_detail_biblio .author a",
                "#catalogue_detail_biblio .author"
            ]);
        }

        const query = [title, author].filter(Boolean).join(" ");

        return {
            BIBLIONUMBER: cleanText(biblionumber),
            TITLE: cleanText(title),
            AUTHOR: cleanText(author),
            ISBN: cleanText(isbn),
            ISBN_FORMATTED: cleanText(isbnFormatted),
            ISBN10: cleanText(isbn10),
            ISBN13: cleanText(isbn13),
            ISSN: cleanText(issn),
            EAN: cleanText(ean),
            CONTROLNUMBER: cleanText(controlnumber),
            OCLC_NO: cleanText(oclc),
            QUERY: cleanText(query),
            CURRENT_URL: window.location.href
        };
    }

    function renderUrlTemplate(template, context) {
        if(window.PMKWorkbench) return window.PMKWorkbench.renderTemplate(template,Object.fromEntries(TEMPLATE_TOKENS.map(key=>[key,cleanText(context[key])])),{uppercase:true,required:TEMPLATE_TOKENS,absolute:true,protocols:['http:','https:','mailto:','tel:','ftp:']});
        const rawTemplate = cleanText(template);
        if (!rawTemplate) return null;

        let missing = false;
        const rendered = rawTemplate.replace(/\{([A-Z0-9_]+)\}/gi, function (_match, rawKey) {
            let key = String(rawKey || "").toUpperCase();
            let rawMode = false;

            if (key.endsWith("_RAW")) {
                rawMode = true;
                key = key.slice(0, -4);
            }

            if (!TEMPLATE_TOKENS.includes(key)) {
                missing = true;
                return "";
            }

            const value = cleanText(context[key]);
            if (!value) {
                missing = true;
                return "";
            }

            return rawMode ? value : encodeURIComponent(value);
        });

        if (missing) return null;
        if (/\{[A-Z0-9_]+\}/i.test(rendered)) return null;

        try {
            const url = new URL(rendered, window.location.href);
            if (!["http:", "https:", "mailto:", "tel:", "ftp:"].includes(url.protocol)) return null;
            return url.href;
        } catch (_) {
            return null;
        }
    }

    function scopeMatches(link) {
        return link.scope === "all" || link.scope === adapter.id;
    }

    function customEntries(section) {
        const links = Array.isArray(state.config.customLinks)
            ? state.config.customLinks
            : [];

        if (!links.length) return [];

        const context = recordContext(section);
        const entries = [];

        links.forEach(function (link, index) {
            if (!link || link.enabled === false || !scopeMatches(link)) return;

            let href = renderUrlTemplate(link.urlTemplate, context);

            // Sécurisation Electre : si un lien historique existe déjà dans
            // le DOM, on le réutilise directement. Cela évite de perdre
            // Electre quand un XSLT Koha expose l'identifiant différemment.
            if (!href && cleanText(link.id).toLowerCase() === "electre") {
                href = existingElectreHref(sectionRecordRoot(section)) ||
                    existingElectreHref(section) ||
                    "";
            }
            if (!href) return;

            const label = customLinkLabel(link);
            if (!label) return;

            entries.push({
                kind: "custom",
                index: index,
                href: href,
                hrefKey: href,
                label: label,
                link: link
            });
        });

        return entries;
    }

    function customMenuItem(entry) {
        const link = entry.link || {};
        const item = document.createElement("li");
        item.className = "pmk-external-links-custom-item";

        const anchor = document.createElement("a");
        anchor.href = entry.href;

        if (link.newWindow !== false) {
            anchor.target = "_blank";
            anchor.rel = "noopener noreferrer";
        }

        const iconType = ["fa", "image"].includes(link.iconType) ? link.iconType : "none";

        if (iconType === "fa") {
            const icon = document.createElement("i");
            icon.className = sanitizeFaClasses(link.iconClass, "fa fa-external-link") +
                " pmk-external-links-custom-icon";
            icon.setAttribute("aria-hidden", "true");
            anchor.appendChild(icon);
        } else if (iconType === "image") {
            const src = safeImageUrl(link.imageUrl);
            if (src) {
                const image = document.createElement("img");
                image.className = "pmk-external-links-custom-image";
                image.src = src;
                image.alt = "";
                image.setAttribute("aria-hidden", "true");
                anchor.appendChild(image);
            }
        }

        if (link.showLabel !== false) {
            const label = document.createElement("span");
            label.className = "pmk-external-links-custom-label";
            label.textContent = entry.label;
            anchor.appendChild(label);
        } else {
            anchor.setAttribute("aria-label", entry.label);
            anchor.title = entry.label;
        }

        /*
         * Si l'utilisateur demande volontairement "icône seule" mais qu'aucune
         * illustration exploitable n'est disponible, on conserve le texte pour
         * éviter un lien visuellement vide.
         */
        if (link.showLabel === false && !anchor.children.length) {
            const fallback = document.createElement("span");
            fallback.className = "pmk-external-links-custom-label";
            fallback.textContent = entry.label;
            anchor.appendChild(fallback);
        }

        window.PMKWorkbench?.describeLink(anchor);
        item.appendChild(anchor);
        return item;
    }

    function closeCurrentMenu(returnFocus) {
        const menu = state.currentOpenMenu;
        const button = state.currentOpenButton;
        if (!menu) return;

        menu.classList.remove("is-open");
        menu.setAttribute("aria-hidden", "true");
        if (button) button.setAttribute("aria-expanded", "false");

        state.currentOpenMenu = null;
        state.currentOpenButton = null;

        if (returnFocus && button && document.contains(button)) {
            button.focus();
        }
    }

    function positionMenu(button, menu) {
        if (!button || !menu || !menu.classList.contains("is-open")) return;

        const viewportPadding = 6;
        const gap = 4;
        const rect = button.getBoundingClientRect();

        menu.style.visibility = "hidden";
        menu.style.left = "0px";
        menu.style.top = "0px";
        menu.style.width = "";

        const menuRect = menu.getBoundingClientRect();
        const width = Math.min(
            Math.max(menuRect.width || 192, Math.min(rect.width, 192)),
            Math.max(160, window.innerWidth - (viewportPadding * 2))
        );

        menu.style.width = width + "px";

        let left = rect.right - width;
        left = Math.max(viewportPadding, Math.min(left, window.innerWidth - width - viewportPadding));

        const measuredHeight = menu.getBoundingClientRect().height;
        let top = rect.bottom + gap;
        if (
            top + measuredHeight > window.innerHeight - viewportPadding &&
            rect.top - measuredHeight - gap >= viewportPadding
        ) {
            top = rect.top - measuredHeight - gap;
        }

        top = Math.max(
            viewportPadding,
            Math.min(top, window.innerHeight - measuredHeight - viewportPadding)
        );

        menu.style.left = Math.round(left) + "px";
        menu.style.top = Math.round(top) + "px";
        menu.style.visibility = "visible";
    }

    function openMenu(button, menu, focusFirst) {
        if (state.currentOpenMenu && state.currentOpenMenu !== menu) {
            closeCurrentMenu(false);
        }

        menu.classList.add("is-open");
        menu.setAttribute("aria-hidden", "false");
        button.setAttribute("aria-expanded", "true");
        state.currentOpenMenu = menu;
        state.currentOpenButton = button;
        positionMenu(button, menu);

        if (focusFirst) {
            const first = menu.querySelector("a[href]");
            if (first) first.focus();
        }
    }

    function toggleMenu(button, menu) {
        if (menu.classList.contains("is-open")) closeCurrentMenu(false);
        else openMenu(button, menu, false);
    }

    function installGlobalListeners() {
        if (!state.outsideListenerAdded) {
            document.addEventListener("click", function (event) {
                const target = event.target;
                if (
                    target &&
                    target.closest &&
                    (
                        target.closest("." + WRAPPER_CLASS) ||
                        target.closest("." + MENU_CLASS)
                    )
                ) {
                    return;
                }
                closeCurrentMenu(false);
            });

            document.addEventListener("keydown", function (event) {
                if (event.key === "Escape" && state.currentOpenMenu) {
                    event.preventDefault();
                    closeCurrentMenu(true);
                }
            });
            state.outsideListenerAdded = true;
        }

        if (!state.viewportListenerAdded) {
            let resizeTimer = null;
            let lastCompactState = null;
            const reposition = function () {
                if (state.currentOpenMenu && state.currentOpenButton) {
                    positionMenu(state.currentOpenButton, state.currentOpenMenu);
                }

                const cfg = state.config && state.config.searchElse ? state.config.searchElse : null;
                const breakpoint = Math.max(320, Number(cfg && cfg.mobileBreakpoint) || 768);
                const compact = window.innerWidth <= breakpoint;
                if (lastCompactState === null) {
                    lastCompactState = compact;
                    return;
                }
                if (compact !== lastCompactState) {
                    lastCompactState = compact;
                    if (resizeTimer !== null) window.clearTimeout(resizeTimer);
                    resizeTimer = window.setTimeout(function () {
                        resizeTimer = null;
                        scheduleRebuild();
                    }, 120);
                }
            };
            window.addEventListener("resize", reposition, { passive: true });
            window.addEventListener("scroll", reposition, { passive: true, capture: true });
            reposition();
            state.viewportListenerAdded = true;
        }
    }

    function createButtonVisual(button, config) {
        const label = buttonLabel(config);
        const type = ["fa", "image"].includes(config.buttonVisualType)
            ? config.buttonVisualType
            : "none";

        let visualAdded = false;

        if (type === "fa") {
            const icon = document.createElement("i");
            icon.className = sanitizeFaClasses(config.buttonIconClass, "fa fa-external-link");
            icon.setAttribute("aria-hidden", "true");
            button.appendChild(icon);
            visualAdded = true;
        } else if (type === "image") {
            const src = safeImageUrl(config.buttonImageUrl);
            if (src) {
                const image = document.createElement("img");
                image.className = "pmk-external-links-button-image";
                image.src = src;
                image.alt = "";
                image.setAttribute("aria-hidden", "true");
                image.addEventListener("error", function () {
                    if (!document.contains(image)) return;
                    const fallback = document.createElement("i");
                    fallback.className = "fa fa-external-link";
                    fallback.setAttribute("aria-hidden", "true");
                    image.replaceWith(fallback);
                }, { once: true });
                button.appendChild(image);
                visualAdded = true;
            }
        }

        if (config.buttonShowLabel !== false) {
            const text = document.createElement("span");
            text.className = "pmk-external-links-label";
            text.textContent = label;
            button.appendChild(text);
        } else {
            button.classList.add("pmk-external-links-icon-only");
        }

        if (!visualAdded && config.buttonShowLabel === false) {
            const fallback = document.createElement("i");
            fallback.className = "fa fa-external-link";
            fallback.setAttribute("aria-hidden", "true");
            button.appendChild(fallback);
        }

        if (config.buttonShowCaret === true) {
            const caret = document.createElement("i");
            caret.className = "fa fa-caret-down";
            caret.setAttribute("aria-hidden", "true");
            button.appendChild(caret);
        }
    }

    function customLinksPotentiallyActive() {
        const links = Array.isArray(state.config.customLinks)
            ? state.config.customLinks
            : [];
        return links.some(function (link) {
            return link && link.enabled !== false && scopeMatches(link);
        });
    }

    function ensureGeneratedHosts() {
        if (!customLinksPotentiallyActive()) return;

        if (adapter.id === "catalogue.detail") {
            if (document.querySelector(adapter.sectionSelector)) return;
            if (document.querySelector("." + GENERATED_HOST_CLASS)) return;

            const target =
                document.querySelector("#catalogue_detail_biblio .page-section") ||
                document.querySelector("#catalogue_detail_biblio");
            if (!target) return;

            const host = document.createElement("span");
            host.className = GENERATED_HOST_CLASS;
            host.dataset.pmkExternalLinksGenerated = "1";
            target.appendChild(host);
            return;
        }

        const resultBlocks = Array.from(
            document.querySelectorAll('[id^="title_summary_"]')
        );

        resultBlocks.forEach(function (result) {
            if (result.querySelector(adapter.sectionSelector)) return;
            if (result.querySelector("." + GENERATED_HOST_CLASS)) return;

            const host = document.createElement("span");
            host.className = GENERATED_HOST_CLASS;
            host.dataset.pmkExternalLinksGenerated = "1";
            result.appendChild(host);
        });
    }

    function collectSections() {
        ensureGeneratedHosts();
        return Array.from(
            document.querySelectorAll(
                adapter.sectionSelector + ", ." + GENERATED_HOST_CLASS
            )
        );
    }

    function buildInlinePresentation(section, index, entries, pageConfig) {
        const uid =
            "pmk-external-links-" +
            adapter.id.replace(/[^a-z0-9]+/gi, "-") +
            "-" + index + "-" + Math.random().toString(36).slice(2, 8);

        const list = document.createElement("ul");
        list.className = "pmk-external-links-inline" +
            (pageConfig.presentation === "inline-grid" ? " is-grid" : "");
        list.dataset.pmkExternalLinksOwner = uid;
        list.style.setProperty("--pmk-ext-columns", String(Math.max(1, Math.min(8, Number(pageConfig.columns) || 2))));
        list.style.setProperty("--pmk-ext-gap", cleanText(pageConfig.gap) || "6px");
        list.style.setProperty("--pmk-ext-link-padding", cleanText(pageConfig.linkPadding) || "6px 8px");
        list.style.setProperty("--pmk-ext-link-justify", cleanText(pageConfig.linkJustifyContent) || "center");
        list.style.setProperty("--pmk-ext-text-align", cleanText(pageConfig.linkTextAlign) || "center");
        list.style.setProperty("--pmk-ext-icon-gap", cleanText(pageConfig.iconGap) || "4px");
        list.style.setProperty("--pmk-ext-link-bg", cleanText(pageConfig.linkBackground) || "#eceff1");
        list.style.setProperty("--pmk-ext-link-hover-bg", cleanText(pageConfig.linkHoverBackground) || "#e1e6e9");
        list.style.setProperty("--pmk-ext-link-color", cleanText(pageConfig.linkColor) || "#455a64");
        list.style.setProperty("--pmk-ext-link-hover-color", cleanText(pageConfig.linkHoverColor) || cleanText(pageConfig.linkColor) || "#455a64");
        list.style.setProperty("--pmk-ext-link-border", cleanText(pageConfig.linkBorder) || "0");
        list.style.setProperty("--pmk-ext-link-radius", cleanText(pageConfig.linkBorderRadius) || "6px");
        list.style.setProperty("--pmk-ext-link-size", cleanText(pageConfig.linkFontSize) || "0.78em");
        list.style.setProperty("--pmk-ext-link-weight", cleanText(pageConfig.linkFontWeight) || "600");
        list.style.setProperty("--pmk-ext-link-shadow", cleanText(pageConfig.linkBoxShadow) || "0 1px 3px rgba(96,125,139,0.18)");
        list.style.setProperty("--pmk-ext-link-hover-shadow", cleanText(pageConfig.linkHoverBoxShadow) || "0 2px 5px rgba(96,125,139,0.24)");
        list.style.setProperty("--pmk-ext-hover-y", cleanText(pageConfig.hoverTranslateY) || "-1px");
        list.style.setProperty("--pmk-ext-image-radius", cleanText(pageConfig.imageRadius) || "4px");
        list.style.setProperty("--pmk-ext-image-shadow", cleanText(pageConfig.imageBoxShadow) || "0 1px 3px rgba(0,0,0,0.15)");
        list.style.setProperty("--pmk-ext-image-hover-shadow", cleanText(pageConfig.imageHoverBoxShadow) || "0 3px 8px rgba(0,0,0,0.25)");
        list.style.setProperty("--pmk-ext-image-scale", String(Number(pageConfig.imageHoverScale) || 1.12));

        entries.forEach(function (entry) {
            let item;
            if (entry.kind === "existing") {
                if (entry.source) {
                    entry.source.classList.add(SOURCE_HIDDEN_CLASS);
                    entry.source.dataset.pmkExternalLinksSource = uid;
                }
                item = existingMenuItem(entry);
            } else {
                item = customMenuItem(entry);
            }
            if (!item) return;
            const anchor = item.querySelector("a[href]");
            if (anchor) anchor.removeAttribute("role");
            list.appendChild(item);
        });

        section.appendChild(list);
        section.dataset.pmkExternalLinksEnhanced = "1";
        return list;
    }


    function knownServiceKey(entry) {
        if (!entry) return "";

        if (entry.kind === "custom") {
            const customId = cleanText(entry.link && entry.link.id).toLowerCase();
            if (["electre", "babelio", "google"].includes(customId)) {
                return "service:" + customId;
            }
            if (customId) return "custom-id:" + customId;
        }

        const href = cleanText(
            entry.href ||
            entry.hrefKey ||
            (entry.anchor && (entry.anchor.href || entry.anchor.getAttribute("href")))
        );
        let extra = "";

        if (entry.anchor) {
            extra += " " + cleanText(entry.anchor.textContent);
            extra += " " + cleanText(entry.anchor.getAttribute("title"));
            extra += " " + cleanText(entry.anchor.getAttribute("aria-label"));
            entry.anchor.querySelectorAll("img").forEach(function (img) {
                extra += " " + cleanText(img.getAttribute("src"));
                extra += " " + cleanText(img.getAttribute("alt"));
                extra += " " + cleanText(img.getAttribute("title"));
            });
        }

        const fingerprint = (href + " " + extra).toLowerCase();

        // Babelio est historiquement lancé via une recherche Google :
        // on le détecte donc AVANT le service Google générique.
        if (/babelio/.test(fingerprint)) return "service:babelio";
        if (/electre(?:-ng)?\.com|electre/.test(fingerprint)) return "service:electre";
        if (/google\.[a-z.]+/.test(fingerprint)) return "service:google";

        return "";
    }

    function dedupeEntries(existing, custom) {
        const entries = [];
        const seenHref = new Set();
        const seenService = new Set();

        // Priorité aux liens historiques déjà produits par Koha/XSLT :
        // ils portent souvent l'identifiant exact attendu par le service.
        existing.concat(custom).forEach(function (entry) {
            const hrefKey = cleanText(entry && entry.hrefKey);
            const serviceKey = knownServiceKey(entry);

            if (!hrefKey) return;
            if (seenHref.has(hrefKey)) return;
            if (serviceKey && seenService.has(serviceKey)) return;

            seenHref.add(hrefKey);
            if (serviceKey) seenService.add(serviceKey);
            entries.push(entry);
        });

        return entries;
    }

    function enhanceSection(section, index) {
        if (!section || section.dataset.pmkExternalLinksEnhanced === "1") return null;

        const existing = section.matches(adapter.sectionSelector)
            ? sourceEntries(section)
            : [];
        const custom = customEntries(section);

        const entries = dedupeEntries(existing, custom);

        if (!entries.length) return null;

        const pageConfig = currentPagePresentation(state.config);
        if (pageConfig.presentation === "inline" || pageConfig.presentation === "inline-grid") {
            return buildInlinePresentation(section, index, entries, pageConfig);
        }

        const label = buttonLabel(state.config);
        const uid =
            "pmk-external-links-" +
            adapter.id.replace(/[^a-z0-9]+/gi, "-") +
            "-" +
            index +
            "-" +
            Math.random().toString(36).slice(2, 8);

        const wrapper = document.createElement("span");
        wrapper.className = WRAPPER_CLASS;
        wrapper.dataset.pmkPage = adapter.id;
        wrapper.dataset.pmkExternalLinksOwner = uid;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn btn-default btn-sm " + TOGGLE_CLASS;
        button.setAttribute("aria-haspopup", "menu");
        button.setAttribute("aria-expanded", "false");
        button.setAttribute("aria-controls", uid + "-menu");
        button.setAttribute("aria-label", label);
        button.title = label;
        createButtonVisual(button, state.config);

        const menu = document.createElement("ul");
        menu.id = uid + "-menu";
        menu.className = MENU_CLASS;
        menu.setAttribute("role", "menu");
        menu.setAttribute("aria-hidden", "true");
        menu.dataset.pmkExternalLinksOwner = uid;

        entries.forEach(function (entry) {
            if (entry.kind === "existing") {
                if (entry.source) {
                    entry.source.classList.add(SOURCE_HIDDEN_CLASS);
                    entry.source.dataset.pmkExternalLinksSource = uid;
                }
                menu.appendChild(existingMenuItem(entry));
            } else {
                menu.appendChild(customMenuItem(entry));
            }
        });

        menu.querySelectorAll("a[href]").forEach(function (anchor) {
            anchor.setAttribute("role", "menuitem");
        });

        button.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();
            toggleMenu(button, menu);
        });

        button.addEventListener("keydown", function (event) {
            if (event.key === "ArrowDown") {
                event.preventDefault();
                openMenu(button, menu, true);
            }
        });

        menu.addEventListener("keydown", function (event) {
            const links = Array.from(menu.querySelectorAll("a[href]"));
            if (!links.length) return;
            const currentIndex = links.indexOf(document.activeElement);

            if (event.key === "ArrowDown") {
                event.preventDefault();
                links[(currentIndex + 1 + links.length) % links.length].focus();
            } else if (event.key === "ArrowUp") {
                event.preventDefault();
                links[(currentIndex - 1 + links.length) % links.length].focus();
            } else if (event.key === "Home") {
                event.preventDefault();
                links[0].focus();
            } else if (event.key === "End") {
                event.preventDefault();
                links[links.length - 1].focus();
            } else if (event.key === "Tab") {
                closeCurrentMenu(false);
            }
        });

        wrapper.appendChild(button);
        section.appendChild(wrapper);
        document.body.appendChild(menu);
        section.dataset.pmkExternalLinksEnhanced = "1";

        return button;
    }

    function cleanupEnhancements() {
        closeCurrentMenu(false);

        document.querySelectorAll("." + SOURCE_HIDDEN_CLASS).forEach(function (node) {
            node.classList.remove(SOURCE_HIDDEN_CLASS);
            delete node.dataset.pmkExternalLinksSource;
        });

        document.querySelectorAll("." + WRAPPER_CLASS).forEach(function (node) {
            node.remove();
        });

        document.querySelectorAll("." + MENU_CLASS).forEach(function (node) {
            node.remove();
        });

        document.querySelectorAll(".pmk-external-links-inline").forEach(function (node) {
            node.remove();
        });

        document.querySelectorAll('[data-pmk-external-links-enhanced="1"]').forEach(function (node) {
            delete node.dataset.pmkExternalLinksEnhanced;
        });

        document.querySelectorAll("." + GENERATED_HOST_CLASS).forEach(function (node) {
            node.remove();
        });

        document.querySelectorAll("#pmk-search-else").forEach(function (node) {
            node.remove();
        });
    }

    function searchElseBranchAllowed(link, branchCode) {
        const mode = cleanText(link && link.branchesMode) || "all";
        if (mode === "all") return true;
        const codes = cleanText(link && link.branchCodes)
            .split(/[\s,;]+/)
            .map(function (value) { return value.trim().toUpperCase(); })
            .filter(Boolean);
        const found = codes.includes(cleanText(branchCode).toUpperCase());
        return mode === "include" ? found : !found;
    }

    function getSearchContext() {
        const params = new URLSearchParams(window.location.search || "");
        const qValues = params.getAll("q").map(cleanText).filter(Boolean);
        const idxValues = params.getAll("idx").map(cleanText).filter(Boolean);
        let query = qValues.join(" ").trim();
        let index = idxValues.join(", ").trim();

        if (!query) {
            try { query = cleanText(localStorage.getItem("searchbox_value")); } catch (_) {}
        }
        if (!index) {
            try { index = cleanText(localStorage.getItem("cat_search_pulldown_selection")); } catch (_) {}
        }
        if (!query) {
            const field = document.querySelector("#cat-search-block #search-form, #search-form");
            if (field) query = cleanText(field.value);
        }
        if (!query) {
            const crumb = document.querySelector("#breadcrumbs");
            const textValue = cleanText(crumb && crumb.textContent);
            const match = textValue.match(/[«\"']([^«»\"']+)[»\"']/);
            if (match) query = cleanText(match[1]);
        }

        const branchNode = document.querySelector(".logged-in-branch-code");
        const branch = cleanText(branchNode && branchNode.textContent);
        return { QUERY: query, INDEX: index, BRANCH: branch, CURRENT_URL: window.location.href };
    }

    function renderSearchElseTemplate(template, context) {
        if(window.PMKWorkbench) return window.PMKWorkbench.renderTemplate(template,context,{uppercase:true,required:['QUERY'],absolute:true});
        const rawTemplate = cleanText(template);
        if (!rawTemplate) return null;
        const allowed = ["QUERY", "INDEX", "BRANCH", "CURRENT_URL"];
        let invalid = false;
        const rendered = rawTemplate.replace(/\{([A-Z0-9_]+)\}/gi, function (_match, rawKey) {
            let key = String(rawKey || "").toUpperCase();
            let rawMode = false;
            if (key.endsWith("_RAW")) { rawMode = true; key = key.slice(0, -4); }
            if (!allowed.includes(key)) { invalid = true; return ""; }
            const value = cleanText(context[key]);
            if (!value && key === "QUERY") { invalid = true; return ""; }
            return rawMode ? value : encodeURIComponent(value);
        });
        if (invalid || /\{[A-Z0-9_]+\}/i.test(rendered)) return null;
        try {
            const url = new URL(rendered, window.location.href);
            if (!["http:", "https:"].includes(url.protocol)) return null;
            return url.href;
        } catch (_) { return null; }
    }

    function searchElsePlacementTarget(placement) {
        if (placement === "after-breadcrumbs") {
            const breadcrumbs = document.querySelector("#breadcrumbs");
            return breadcrumbs ? { target: breadcrumbs, mode: "after" } : null;
        }
        if (placement === "sidebar") {
            const aside = document.querySelector("aside");
            if (aside && !aside.closest(".liens_externes") && !aside.closest("." + WRAPPER_CLASS)) {
                return { target: aside, mode: "append" };
            }
        }
        const results = document.querySelector("#catalog_results, #bookbag_form, #searchresults");
        if (results) return { target: results, mode: "before" };
        const main = document.querySelector("main, #main");
        return main ? { target: main, mode: "prepend" } : null;
    }

    function placeSearchElse(block, placement) {
        let resolved = searchElsePlacementTarget(placement);
        if (!resolved && placement !== "before-results") resolved = searchElsePlacementTarget("before-results");
        if (!resolved) return false;
        if (resolved.target.closest && (resolved.target.closest(".liens_externes") || resolved.target.closest("." + WRAPPER_CLASS))) return false;
        if (resolved.mode === "after") resolved.target.insertAdjacentElement("afterend", block);
        else if (resolved.mode === "before") resolved.target.insertAdjacentElement("beforebegin", block);
        else if (resolved.mode === "prepend") resolved.target.prepend(block);
        else resolved.target.appendChild(block);
        return true;
    }

    function renderSearchElse() {
        document.querySelectorAll("#pmk-search-else").forEach(function (node) { node.remove(); });
        if (adapter.id !== "catalogue.search") return null;
        const cfg = state.config && state.config.searchElse ? state.config.searchElse : null;
        if (!cfg || cfg.enabled === false) return null;

        const context = getSearchContext();
        if (!context.QUERY) return null;
        const links = Array.isArray(cfg.links) ? cfg.links : [];
        const entries = [];
        links.forEach(function (link) {
            if (!link || link.enabled === false || !searchElseBranchAllowed(link, context.BRANCH)) return;
            const href = renderSearchElseTemplate(link.urlTemplate, context);
            const label = searchElseLabel(link);
            if (!href || !label) return;
            entries.push({ link: link, href: href, label: label });
        });
        if (!entries.length) return null;

        const block = document.createElement("section");
        block.id = "pmk-search-else";
        block.className = cfg.presentation === "buttons" ? "pmk-search-else-buttons" : "pmk-search-else-list";
        block.dataset.pmkExternalLinksSearchElse = "1";

        const heading = document.createElement("h3");
        heading.className = "pmk-search-else-title";
        heading.textContent = currentLanguage() === "en" ? (cleanText(cfg.titleEn) || cleanText(cfg.titleFr) || "Search elsewhere") : (cleanText(cfg.titleFr) || cleanText(cfg.titleEn) || "Rechercher ailleurs");
        block.appendChild(heading);

        const queryInfo = document.createElement("span");
        queryInfo.className = "pmk-search-else-query";
        queryInfo.textContent = translated("Recherche : ", "Search: ") + context.QUERY;
        block.appendChild(queryInfo);

        const list = document.createElement("ul");
        list.className = "pmk-search-else-links";
        entries.forEach(function (entry) {
            const li = document.createElement("li");
            const a = document.createElement("a");
            a.className = "pmk-search-else-link";
            a.href = entry.href;
            if (entry.link.newWindow !== false) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
            if (entry.link.iconType === "fa") {
                const icon = document.createElement("i");
                icon.className = sanitizeFaClasses(entry.link.iconClass, "fa fa-external-link");
                icon.setAttribute("aria-hidden", "true");
                a.appendChild(icon);
            } else if (entry.link.iconType === "image") {
                const src = safeImageUrl(entry.link.imageUrl);
                if (src) {
                    const img = document.createElement("img");
                    img.className = "pmk-search-else-image";
                    img.src = src;
                    img.alt = "";
                    img.setAttribute("aria-hidden", "true");
                    a.appendChild(img);
                }
            }
            if (entry.link.showLabel !== false) a.appendChild(document.createTextNode(entry.label));
            else { a.title = entry.label; a.setAttribute("aria-label", entry.label); }
            window.PMKWorkbench?.describeLink(a);
            li.appendChild(a);
            list.appendChild(li);
        });
        block.appendChild(list);

        const breakpoint = Math.max(320, Number(cfg.mobileBreakpoint) || 768);
        const placement = window.innerWidth <= breakpoint ? (cfg.mobilePlacement || "before-results") : (cfg.desktopPlacement || "sidebar");
        if (!placeSearchElse(block, placement)) return null;

        if (window.PMKConfig && typeof window.PMKConfig.mountContextButton === "function") {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: heading,
                position: "after",
                contextKey: "catalogue.search.search-else",
                context: { pageId: "catalogue.search", sectionId: "search-else" }
            });
        }
        return block;
    }

    function mountContextAccess(firstButton) {
        if (
            !firstButton ||
            !window.PMKConfig ||
            typeof window.PMKConfig.mountContextButton !== "function"
        ) {
            return;
        }

        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: firstButton,
            position: "after",
            contextKey: adapter.id,
            context: {
                pageId: adapter.id,
                sectionId: "custom-links"
            }
        });
    }

    function enhanceAll() {
        if (!pageIsEnabled(state.config)) return;

        injectStyles();
        installGlobalListeners();

        const sections = collectSections();
        let firstButton = null;

        sections.forEach(function (section, index) {
            const button = enhanceSection(section, index);
            if (!firstButton && button) firstButton = button;
        });

        renderSearchElse();
        mountContextAccess(firstButton);
    }

    function reconnectObserver() {
        if (!state.observer || !document.body) return;
        state.observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    function rebuildAll() {
        if (state.observer) state.observer.disconnect();
        cleanupEnhancements();
        enhanceAll();
        reconnectObserver();
    }

    function scheduleRebuild() {
        if (state.rebuildTimer !== null) return;
        state.rebuildTimer = window.setTimeout(function () {
            state.rebuildTimer = null;
            rebuildAll();
        }, 80);
    }

    function mutationMayAffectExternalLinks(mutation) {
        return Array.from(mutation.addedNodes || []).some(function (node) {
            if (!node || node.nodeType !== 1) return false;

            if (node.matches) {
                if (node.matches(adapter.sectionSelector)) return true;
                if (node.matches('[id^="title_summary_"]')) return true;
                if (adapter.id === "catalogue.search" && node.matches("#catalog_results, #bookbag_form, #breadcrumbs, aside")) return true;
            }

            if (node.querySelector) {
                if (node.querySelector(adapter.sectionSelector)) return true;
                if (node.querySelector('[id^="title_summary_"]')) return true;
                if (adapter.id === "catalogue.search" && node.querySelector("#catalog_results, #bookbag_form, #breadcrumbs, aside")) return true;
            }

            return false;
        });
    }

    function startObserver() {
        if (state.observer || !document.body) return;

        state.observer = new MutationObserver(function (mutations) {
            if (mutations.some(mutationMayAffectExternalLinks)) {
                scheduleRebuild();
            }
        });

        reconnectObserver();
    }

    async function loadConfiguration() {
        registerWithPMK();

        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            state.config = prepareRuntimeConfig(clone(DEFAULT_CONFIG)).config;
            return;
        }

        const prepared = prepareRuntimeConfig(
            await window.PMKConfig.getConfig(MODULE_ID)
        );
        state.config = prepared.config;

        if (!state.unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            state.unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (nextConfig) {
                state.config = prepareRuntimeConfig(nextConfig || clone(DEFAULT_CONFIG)).config;
                rebuildAll();
            });
        }
    }

    async function initialize() {
        if (state.initialized) return;
        state.initialized = true;

        await loadConfiguration();
        rebuildAll();
        startObserver();
    }

    function onReady(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
        } else {
            callback();
        }
    }

    window.__PMK_EXTERNAL_LINKS_010__ = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        refresh: function () {
            scheduleRebuild();
        },
        rebuild: rebuildAll,
        getConfig: function () {
            return clone(state.config);
        },
        getRecordContext: function (section) {
            return clone(recordContext(section || document.body));
        },
        getSearchContext: function () {
            return clone(getSearchContext());
        },
        renderSearchElse: renderSearchElse
    };

    onReady(function () {
        initialize();
    });
})();

;window.PMKNonPlugin.loaded.push("010-boutons-recherche-externe.js");
} catch (error) { window.PMKNonPlugin.errors.push("010-boutons-recherche-externe.js: "+error.message); console.error("[PMK] 010-boutons-recherche-externe.js",error); };
try {
/* ============================================================
   Nom du fichier : 011-moredetail-layout.js
   Module PMK      : moredetail-layout
   Version         : 3.3.0
   Mise à jour     : 2026-09-17
   Auteur          : équipe PimpMyKoha

   Fonction :
   - améliore la présentation de catalogue/moredetail.pl sans cloner
     ni détruire le DOM natif Koha ;
   - présente les exemplaires sous forme de cartes responsives ;
   - permet d'afficher/masquer, renommer, déplacer et mettre en
     évidence des éléments ciblés ;
   - permet de sélectionner visuellement un élément directement
     sur la page Koha depuis la configuration PMK ;
   - conserve les formulaires, événements et interactions natives ;
   - applique par défaut les adaptations historiques d’origine.

   Préparation PimpMyKoha :
   - identifiant fonctionnel stable : moredetail-layout ;
   - adaptateur : catalogue.moredetail ;
   - Firestore n'est jamais appelé directement par ce module ;
   - la couche de configuration est fournie par window.PMKConfig.
   ============================================================ */
(function () {
    "use strict";

    const MODULE_ID = "moredetail-layout";
    const MODULE_VERSION = "3.3.0";
    const STYLE_ID = "pmk-moredetail-layout-styles";
    const GRID_ID = "pmk-moredetail-items-grid";
    const PAGE_ID = "catalogue.moredetail";

    const KNOWN_FIELD_CLASSES = new Set([
        "biblionumber", "itemtype", "rentalcharge", "rentalcharge_daily",
        "rentalcharge_hourly", "isbn", "publication_details", "volume",
        "physical_details", "biblio_note", "item_count", "homebranch", "itype",
        "ccode", "itemcallnumber", "copynumber", "location", "replacementprice",
        "materials", "holdingbranch", "checkout_status", "renewals_count", "lost",
        "damaged", "withdrawn", "local_holds_priority", "bookable", "order_info",
        "dateaccessioned", "invoice", "issues", "datelastseen", "datelastborrowed",
        "previous_borrowers", "paidfor", "enumchron", "itemnotes",
        "itemnotes_nonpublic"
    ]);

    const GENERIC_CLASSES = new Set([
        "page-section", "clearfix", "listgroup", "rows", "bibliodetails", "label",
        "expanded", "collapsed", "form-control", "form-select", "btn", "btn-primary",
        "btn-xs", "inline", "hint", "help-block", "alert", "alert-info", "alert-warning"
    ]);

    const DEFAULT_STRUCTURE = {"root": "#catalogue_detail_biblio", "biblioSection": ":scope > .page-section", "items": ":scope > div[id^=\"container\"]", "itemHeading": ":scope > h3[id^=\"item\"]", "itemContent": ":scope > .page-section[id^=\"collapse_item\"]", "groups": ":scope > .listgroup", "groupHeading": ":scope > h4", "groupRows": ":scope > .rows", "fieldList": "ol.bibliodetails", "field": "li", "label": ".label"};
    const DEFAULT_CONFIG = {
        enabled: true,
        structure: clone(DEFAULT_STRUCTURE),
        pages: [
            {
                pageId: PAGE_ID,
                enabled: true,
                path: "catalogue/moredetail.pl"
            }
        ],
        layout: {
            mode: "cards",
            desktopColumns: 3,
            tabletColumns: 2,
            mobileColumns: 1,
            gap: 20,
            outerPadding: 10,
            showBibliographicBlock: true,
            numberItems: true,
            itemNumberLabelFr: "Exemplaire",
            itemNumberLabelEn: "Item",
            cardBackground: "#f1f1f1",
            pageBackground: "#f9f9f9",
            sectionBackground: "#ffffff",
            borderColor: "#cccccc"
        },
        highlight: {
            enabled: true,
            storageKey: "searchbox_value",
            backgroundColor: "#7abf87",
            scrollIntoView: false
        },
        catalogueInfo: {
            enabled: true,
            selector: ".catalogue-info",
            waitMs: 5000
        },
        sections: [
            {
                key: "information",
                visible: true,
                labelFr: "",
                labelEn: "",
                collapsible: false,
                collapsedByDefault: false
            },
            {
                key: "statuses",
                visible: true,
                labelFr: "",
                labelEn: "",
                collapsible: false,
                collapsedByDefault: false
            },
            {
                key: "priority",
                visible: true,
                labelFr: "",
                labelEn: "",
                collapsible: false,
                collapsedByDefault: false
            },
            {
                key: "history",
                visible: true,
                labelFr: "",
                labelEn: "",
                collapsible: false,
                collapsedByDefault: false
            }
        ],
        fieldRules: [
            {
                enabled: true,
                targetName: "Numéro de copie / Copy number",
                targetKind: "field",
                scope: "item",
                selector: ".copynumber",
                visible: true,
                labelFr: "Sous-localisation",
                labelEn: "Sub-location",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Statut perdu / Lost status",
                targetKind: "field",
                scope: "item",
                selector: ".lost",
                visible: true,
                labelFr: "Motif d'exclusion",
                labelEn: "Exclusion reason",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Énumération du périodique / Serial enumeration",
                targetKind: "field",
                scope: "item",
                selector: ".enumchron",
                visible: true,
                labelFr: "Etage",
                labelEn: "Floor",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Statut de prêt / Checkout status",
                targetKind: "field",
                scope: "item",
                selector: ".checkout_status",
                visible: true,
                labelFr: "Informations de prêt",
                labelEn: "Checkout information",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Coût du prêt / Rental charge",
                targetKind: "field",
                scope: "biblio",
                selector: ".rentalcharge",
                visible: false,
                labelFr: "",
                labelEn: "",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Coût du prêt par jour / Daily rental charge",
                targetKind: "field",
                scope: "biblio",
                selector: ".rentalcharge_daily",
                visible: false,
                labelFr: "",
                labelEn: "",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            },
            {
                enabled: true,
                targetName: "Frais de location horaires / Hourly rental charge",
                targetKind: "field",
                scope: "biblio",
                selector: ".rentalcharge_hourly",
                visible: false,
                labelFr: "",
                labelEn: "",
                destinationGroup: "keep",
                order: null,
                hideWhenEmpty: false,
                emphasis: "normal",
                highlight: false
            }
        ]
    };

    const state = {
        config: null,
        root: null,
        biblioSection: null,
        items: [],
        originalItemsParent: null,
        originalAfterItems: null,
        movedNodes: [],
        renamedLabels: new Map(),
        renamedHeadings: new Map(),
        addedNodes: [],
        touchedNodes: new Set(),
        catalogueObserver: null,
        unsubscribe: null,
        applied: false
    };

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function currentLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const htmlLang = (document.documentElement.getAttribute("lang") || "").toLowerCase();
        if (htmlLang.startsWith("fr")) return "fr";
        if (htmlLang.startsWith("en")) return "en";
        return (navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function structure(config) { return Object.assign({}, DEFAULT_STRUCTURE, (config || state.config || {}).structure || {}); }
    function query(root, selector) { return safeQueryAll(root, selector)[0] || null; }
    function normalizedPage(path) {
        const value=String(path || '').trim();return value.startsWith('/cgi-bin/koha/')?value:'/cgi-bin/koha/'+value.replace(/^\/+/, '');
    }
    function matchingPage(config) { return ((config || state.config || DEFAULT_CONFIG).pages || []).find(page=>normalizedPage(page.path)===location.pathname); }
    function isMoreDetailPage(config) { return !!matchingPage(config); }
    function pageEnabled(config) { const page=matchingPage(config);return config && config.enabled!==false && page && page.enabled!==false; }
    function containingItem(element) { return state.items.find(item=>item===element || item.contains(element)) || null; }
    function itemContent(item) { return query(item,structure().itemContent); }

    function clampInteger(value, min, max, fallback) {
        const number = Number(value);
        if (!Number.isFinite(number)) return fallback;
        return Math.min(max, Math.max(min, Math.round(number)));
    }

    function cleanText(value) {
        return String(value === undefined || value === null ? "" : value).trim();
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (char) {
            return "\\" + char;
        });
    }

    function safeQueryAll(root, selector) {
        if (!root || !selector) return [];
        try {
            return Array.from(root.querySelectorAll(selector));
        } catch (_) {
            return [];
        }
    }

    function pagePath() {
        return (state.config || DEFAULT_CONFIG).pages?.[0]?.path || "catalogue/moredetail.pl";
    }

    function newFieldRule() {
        return {
            enabled: true,
            targetName: "",
            targetKind: "field",
            scope: "item",
            selector: "",
            visible: true,
            labelFr: "",
            labelEn: "",
            destinationGroup: "keep",
            order: null,
            hideWhenEmpty: false,
            emphasis: "normal",
            highlight: false
        };
    }

    function fieldRuleFromPath(rootObject, path) {
        if (!rootObject || !Array.isArray(rootObject.fieldRules)) return null;
        const index = path[path.length - 2];
        return Number.isInteger(index) ? rootObject.fieldRules[index] : null;
    }

    function visualPickerResultTarget(rawTarget,request) {
        if (!rawTarget || !(rawTarget instanceof Element)) return null;
        if(request?.fieldPath?.[0]==='structure')return rawTarget;
        const cfg=request?.draft || state.config || DEFAULT_CONFIG,dom=structure(cfg);
        const items=state.items.length?state.items:safeQueryAll(query(document,dom.root),dom.items);
        const item=items.find(node=>node===rawTarget||node.contains(rawTarget));
        if(request?.fieldPath?.includes('sections')){
            const content=item && query(item,dom.itemContent);return safeQueryAll(content,dom.groups).find(group=>group===rawTarget||group.contains(rawTarget)) || rawTarget;
        }
        if(item)return rawTarget.closest(dom.field) || rawTarget;
        return rawTarget.closest(dom.field) || rawTarget;
    }
    function detectPickerScope(element,config) {
        if(!element)return 'page';
        if(containingItem(element))return 'item';
        const dom=structure(config),root=query(document,dom.root);
        if(safeQueryAll(root,dom.items).some(item=>item===element||item.contains(element)))return 'item';
        if(state.biblioSection?.contains(element) || query(root,dom.biblioSection)?.contains(element))return 'biblio';
        return 'page';
    }

    function detectTargetKind(element) {
        if (!element) return "custom";
        if (element.matches(structure().field)) return "field";
        if (safeQueryAll(itemContent(containingItem(element)),structure().groups).includes(element)) return "section";
        if (element.matches("h2,h3,h4")) return "heading";
        return "custom";
    }

    function bestTargetName(element) {
        if (!element) return "";
        const label = query(element,structure().label);
        if (label && cleanText(label.textContent)) return cleanText(label.textContent).replace(/\s*:\s*$/, "");

        if (element.matches && element.matches(".listgroup")) {
            const heading = element.querySelector(":scope > h4");
            if (heading) return cleanText(heading.textContent).replace(/\s+/g, " ").slice(0, 100);
        }

        const text = cleanText(element.textContent).replace(/\s+/g, " ");
        return text.slice(0, 100);
    }

    function selectorFromElement(element, scope) {
        if (!element) return "";

        if (element.matches(structure().field)) {
            const classes = Array.from(element.classList || []);
            const known = classes.find(function (className) {
                return KNOWN_FIELD_CLASSES.has(className);
            });
            if (known) return "." + known;

            const stableClass = classes.find(function (className) {
                return className && !GENERIC_CLASSES.has(className) && !/^pmk-/.test(className);
            });
            if (stableClass) return "." + stableClass;
        }

        if (element.id && !/^(item|container|collapse_item)\d+$/.test(element.id)) {
            return "#" + cssEscape(element.id);
        }

        const classes = Array.from(element.classList || []).filter(function (className) {
            return className && !GENERIC_CLASSES.has(className) && !/^pmk-/.test(className);
        });
        if (classes.length) return "." + classes.map(cssEscape).join(".");

        const root = scope === "item"
            ? containingItem(element)
            : (scope === "biblio" ? state.biblioSection : document.body);

        if (!root) return "";

        const parts = [];
        let current = element;
        while (current && current !== root && current.nodeType === 1) {
            let part = current.tagName.toLowerCase();
            const parent = current.parentElement;
            if (parent) {
                const sameTag = Array.from(parent.children).filter(function (child) {
                    return child.tagName === current.tagName;
                });
                if (sameTag.length > 1) {
                    part += ":nth-of-type(" + (sameTag.indexOf(current) + 1) + ")";
                }
            }
            parts.unshift(part);
            current = parent;
        }
        return parts.join(" > ");
    }

    function registerCommonPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== "function") return false;
        service.register(MODULE_ID, {
            getOptions: function () {
                return {
                    rootSelector: "body",
                    bannerText: currentLanguage() === "en"
                        ? "Click the Koha element to configure — Esc cancels"
                        : "Clique sur l’élément Koha à configurer — Échap annule"
                };
            },
            resolveTarget: function (element,request) {
                return visualPickerResultTarget(element,request);
            },
            buildResult: function (element, base, request) {
                const scope = detectPickerScope(element,request?.draft);
                let selector = selectorFromElement(element, scope) || base.selector;
                if(request?.fieldPath?.[0]==='structure' || request?.fieldPath?.includes('sections')){
                    const classes=Array.from(element.classList).filter(name=>!name.startsWith('pmk-')&&!GENERIC_CLASSES.has(name));
                    selector=classes.length?'.'+classes.map(cssEscape).join('.'):base.selector;
                    if(request.fieldPath.at(-1)==='items' && /^container\d+$/.test(element.id))selector=':scope > div[id^="container"]';
                }
                return Object.assign({}, base, {
                    value: selector,
                    selector: selector,
                    scope: scope,
                    targetKind: detectTargetKind(element),
                    targetName: bestTargetName(element)
                });
            },
            applyPending: function (draft, pending, picked) {
                onPickedTarget(draft, pending && pending.fieldPath || [], picked || {});
                return draft;
            }
        });
        return true;
    }

    function visualElementPicker(context) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }
        registerCommonPickerAdapter();
        const ctx = context || {};
        return service.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: (ctx.rootObject?.pages || [])[0]?.path || pagePath(),
            rootObject: ctx.rootObject || {},
            fieldPath: Array.isArray(ctx.fieldPath) ? ctx.fieldPath : [],
            adminContext: { sectionId: "elements" },
            options: { rootSelector: "body" }, persistAfterPick: false
        });
    }

    function onPickedTarget(rootObject, fieldPath, result) {
        const rule = fieldRuleFromPath(rootObject, fieldPath);
        if (!rule || !result) return;
        if (result.scope) rule.scope = result.scope;
        if (result.targetKind) rule.targetKind = result.targetKind;
        if (result.targetName) rule.targetName = result.targetName;
    }

    function destinationOptions() {
        return [
            { value: "keep", label: { fr: "Conserver son bloc actuel", en: "Keep current section" } },
            { value: "information", label: { fr: "Informations exemplaire", en: "Item information" } },
            { value: "statuses", label: { fr: "Statuts", en: "Statuses" } },
            { value: "priority", label: { fr: "Priorité", en: "Priority" } },
            { value: "history", label: { fr: "Historique", en: "History" } }
        ];
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 3,
            name: {
                fr: "Présentation des détails des exemplaires",
                en: "Item details layout"
            },
            description: {
                fr: "Réorganise moredetail.pl sans casser le DOM natif Koha et permet de cibler directement les éléments à afficher, masquer, renommer ou déplacer.",
                en: "Reorganizes moredetail.pl without breaking Koha's native DOM and lets you directly target elements to show, hide, rename or move."
            },
            category: {
                fr: "Catalogue / exemplaires",
                en: "Catalog / items"
            },
            supportedPages: [PAGE_ID],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer le module", en: "Enable module" }
                        },
                        {
                            key: "pages",
                            type: "repeater",
                            label: { fr: "Pages", en: "Pages" },
                            reorder: false,
                            removable: false,
                            canAdd: function () { return false; },
                            cannotAddHelp: {
                                fr: "Ce module est volontairement limité à moredetail.pl.",
                                en: "This module is intentionally limited to moredetail.pl."
                            },
                            itemTitle: function () {
                                return currentLanguage() === "en" ? "Item details" : "Détails des exemplaires";
                            },
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: { fr: "Activer sur cette page", en: "Enable on this page" }
                                },
                                {
                                    key: "pageId",
                                    type: "text",
                                    readOnly: true,
                                    advanced: true,
                                    label: { fr: "Identifiant page", en: "Page identifier" }
                                },
                                {
                                    key: "path",
                                    type: "text",
                                    readOnly: true,
                                    label: { fr: "Chemin Koha", en: "Koha path" }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "layout",
                    label: { fr: "Mise en page", en: "Layout" },
                    description: {
                        fr: "La présentation en cartes déplace les nœuds Koha réels : aucun formulaire ni événement natif n'est cloné.",
                        en: "Card layout moves the real Koha nodes: no native form or event is cloned."
                    },
                    fields: [
                        {
                            key: "layout.mode",
                            type: "select",
                            label: { fr: "Présentation des exemplaires", en: "Item presentation" },
                            options: [
                                { value: "cards", label: { fr: "Cartes responsives", en: "Responsive cards" } },
                                { value: "native", label: { fr: "Présentation native Koha", en: "Native Koha layout" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "layout-details",
                    label: { fr: "Réglages des cartes", en: "Card settings" },
                    fields: [
                        { key: "layout.desktopColumns", type: "number", label: { fr: "Colonnes grand écran", en: "Desktop columns" } },
                        { key: "layout.tabletColumns", type: "number", label: { fr: "Colonnes écran moyen", en: "Tablet columns" } },
                        { key: "layout.mobileColumns", type: "number", label: { fr: "Colonnes mobile", en: "Mobile columns" } },
                        { key: "layout.gap", type: "number", label: { fr: "Espacement entre cartes (px)", en: "Card gap (px)" } },
                        { key: "layout.outerPadding", type: "number", label: { fr: "Marge intérieure générale (px)", en: "Outer padding (px)" } },
                        { key: "layout.showBibliographicBlock", type: "boolean", label: { fr: "Afficher le bloc bibliographique", en: "Show bibliographic block" } },
                        { key: "layout.numberItems", type: "boolean", label: { fr: "Afficher « Exemplaire 1, 2… »", en: "Show “Item 1, 2…”" } },
                        { key: "layout.itemNumberLabelFr", type: "text", label: { fr: "Libellé français de la numérotation", en: "French numbering label" } },
                        { key: "layout.itemNumberLabelEn", type: "text", label: { fr: "Libellé anglais de la numérotation", en: "English numbering label" } },
                        { key: "layout.pageBackground", type: "color", label: { fr: "Fond de la zone", en: "Area background" } },
                        { key: "layout.cardBackground", type: "color", label: { fr: "Fond des cartes", en: "Card background" } },
                        { key: "layout.sectionBackground", type: "color", label: { fr: "Fond du bloc bibliographique", en: "Bibliographic block background" } },
                        { key: "layout.borderColor", type: "color", label: { fr: "Couleur des bordures", en: "Border color" } }
                    ]
                },
                {
                    type: "section",
                    id: "sections",
                    label: { fr: "Blocs des exemplaires", en: "Item sections" },
                    description: {
                        fr: "L'ordre des cartes ci-dessous détermine l'ordre des blocs dans chaque exemplaire.",
                        en: "The order of the cards below determines the section order inside each item."
                    },
                    fields: [
                        {
                            key: "sections",
                            type: "repeater",
                            label: { fr: "Blocs", en: "Sections" },
                            reorder: true,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function (item, index, lang) {
                                const names = {
                                    information: { fr: "Informations exemplaire", en: "Item information" },
                                    statuses: { fr: "Statuts", en: "Statuses" },
                                    priority: { fr: "Priorité", en: "Priority" },
                                    history: { fr: "Historique", en: "History" }
                                };
                                const label = names[item && item.key];
                                return label ? (label[lang] || label.fr) : "Bloc " + (index + 1);
                            },
                            fields: [
                                { key: "visible", type: "boolean", label: { fr: "Afficher ce bloc", en: "Show this section" } },
                                { key: "labelFr", type: "text", label: { fr: "Nouveau titre français (vide = Koha)", en: "French title (blank = Koha)" } },
                                { key: "labelEn", type: "text", label: { fr: "Nouveau titre anglais (vide = Koha)", en: "English title (blank = Koha)" } },
                                { key: "collapsible", type: "boolean", label: { fr: "Permettre de replier ce bloc", en: "Allow this section to collapse" } },
                                { key: "collapsedByDefault", type: "boolean", label: { fr: "Replié par défaut", en: "Collapsed by default" } },
                                { key: "key", type: "text", readOnly: true, advanced: true, label: { fr: "Identifiant technique", en: "Technical identifier" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "elements",
                    label: { fr: "Éléments ciblés", en: "Targeted elements" },
                    description: {
                        fr: "Ajoute une règle puis utilise « Choisir sur la page » pour viser un champ Koha sans connaître son sélecteur CSS.",
                        en: "Add a rule then use “Choose on page” to target a Koha field without knowing its CSS selector."
                    },
                    fields: [
                        {
                            key: "fieldRules",
                            type: "repeater",
                            label: { fr: "Règles d'affichage", en: "Display rules" },
                            addLabel: { fr: "Ajouter une règle / cibler un élément", en: "Add rule / target an element" },
                            reorder: true,
                            newItem: newFieldRule,
                            itemTitle: function (item, index) {
                                return cleanText(item && item.targetName) || cleanText(item && item.selector) || "Règle " + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "targetName", type: "text", label: { fr: "Nom dans la configuration", en: "Configuration name" } },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    label: { fr: "Élément à cibler", en: "Element to target" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Choose on page" },
                                    emptyLabel: { fr: "Aucun élément choisi", en: "No element selected" },
                                    help: {
                                        fr: "Le sélecteur est généré automatiquement. Le mode avancé permet aussi de le saisir manuellement.",
                                        en: "The selector is generated automatically. Advanced mode also allows manual entry."
                                    },
                                    allowManual: true,
                                    pick: visualElementPicker,
                                    onPick: onPickedTarget
                                },
                                {
                                    key: "scope",
                                    type: "select",
                                    label: { fr: "Zone de recherche", en: "Search scope" },
                                    options: [
                                        { value: "item", label: { fr: "Dans chaque exemplaire", en: "Inside each item" } },
                                        { value: "biblio", label: { fr: "Bloc bibliographique", en: "Bibliographic block" } },
                                        { value: "page", label: { fr: "Toute la page", en: "Whole page" } }
                                    ]
                                },
                                { key: "visible", type: "boolean", label: { fr: "Afficher l'élément", en: "Show element" } },
                                { key: "labelFr", type: "text", label: { fr: "Nouveau libellé français (vide = conserver)", en: "French label (blank = keep)" } },
                                { key: "labelEn", type: "text", label: { fr: "Nouveau libellé anglais (vide = conserver)", en: "English label (blank = keep)" } },
                                {
                                    key: "destinationGroup",
                                    type: "select",
                                    label: { fr: "Déplacer dans", en: "Move to" },
                                    options: destinationOptions()
                                },
                                {
                                    key: "order",
                                    type: "number",
                                    label: { fr: "Position dans le bloc (vide = conserver)", en: "Position inside section (blank = keep)" },
                                    help: { fr: "1 place l'élément en premier, 2 en deuxième, etc.", en: "1 places the element first, 2 second, and so on." }
                                },
                                { key: "hideWhenEmpty", type: "boolean", label: { fr: "Masquer si la valeur est vide", en: "Hide when value is empty" } },
                                {
                                    key: "emphasis",
                                    type: "select",
                                    label: { fr: "Présentation", en: "Presentation" },
                                    options: [
                                        { value: "normal", label: { fr: "Normale", en: "Normal" } },
                                        { value: "muted", label: { fr: "Discrète", en: "Muted" } },
                                        { value: "accent", label: { fr: "Accentué", en: "Emphasized" } }
                                    ]
                                },
                                { key: "highlight", type: "boolean", label: { fr: "Mettre en évidence", en: "Highlight" } },
                                { key: "targetKind", type: "text", readOnly: true, advanced: true, label: { fr: "Type détecté", en: "Detected type" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "highlight",
                    label: { fr: "Exemplaire recherché", en: "Searched item" },
                    fields: [
                        { key: "highlight.enabled", type: "boolean", label: { fr: "Mettre en évidence le code-barres mémorisé", en: "Highlight remembered barcode" } },
                        { key: "highlight.backgroundColor", type: "color", label: { fr: "Couleur de surbrillance", en: "Highlight color" } },
                        { key: "highlight.scrollIntoView", type: "boolean", label: { fr: "Faire défiler jusqu'à l'exemplaire", en: "Scroll to highlighted item" } },
                        { key: "highlight.storageKey", type: "text", advanced: true, label: { fr: "Clé localStorage", en: "localStorage key" } }
                    ]
                },
                {
                    type: "section",
                    id: "catalogue-info",
                    label: { fr: "Bloc catalogue-info", en: "catalogue-info block" },
                    description: {
                        fr: "Compatibilité avec le bloc facultatif ajouté par d'autres personnalisations.",
                        en: "Compatibility with the optional block added by other customizations."
                    },
                    fields: [
                        { key: "catalogueInfo.enabled", type: "boolean", label: { fr: "Replacer ce bloc avec les informations bibliographiques", en: "Move this block with bibliographic information" } },
                        { key: "catalogueInfo.selector", type: "text", advanced: true, label: { fr: "Sélecteur du bloc", en: "Block selector" } },
                        { key: "catalogueInfo.waitMs", type: "number", advanced: true, label: { fr: "Durée maximale d'attente (ms)", en: "Maximum wait time (ms)" } }
                    ]
                }
            ],
            focusContext: function (main, context) {
                if (!main || !context) return;
                const wanted = context.sectionId || "elements";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    function validateConfig(config) {
        const lang = currentLanguage();
        const fail = function (fr, en) {
            return { ok: false, message: lang === "en" ? en : fr };
        };

        if (!config || typeof config !== "object") {
            return fail("La configuration du module n'est pas valide.", "The module configuration is invalid.");
        }

        const layout = config.layout || {};
        const desktop = Number(layout.desktopColumns);
        const tablet = Number(layout.tabletColumns);
        const mobile = Number(layout.mobileColumns);
        if (![desktop, tablet, mobile].every(function (value) { return Number.isFinite(value) && value >= 1 && value <= 6; })) {
            return fail("Le nombre de colonnes doit être compris entre 1 et 6.", "Column counts must be between 1 and 6.");
        }

        if (layout.mode !== "cards" && layout.mode !== "native") {
            return fail("Le mode de mise en page est invalide.", "The layout mode is invalid.");
        }

        if (!Array.isArray(config.fieldRules)) {
            return fail("La liste des éléments ciblés est invalide.", "The targeted element list is invalid.");
        }

        for (const rule of config.fieldRules) {
            if (!rule || rule.enabled === false) continue;
            if (!cleanText(rule.selector)) {
                return fail("Une règle active ne cible aucun élément.", "An enabled rule does not target any element.");
            }
            if (!["item", "biblio", "page"].includes(rule.scope)) {
                return fail("Une règle utilise une zone de recherche inconnue.", "A rule uses an unknown search scope.");
            }
            try {
                document.createDocumentFragment().querySelector(rule.selector);
            } catch (_) {
                return fail("Un sélecteur CSS configuré n'est pas valide : " + rule.selector, "A configured CSS selector is invalid: " + rule.selector);
            }
        }

        return { ok: true };
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                livePreview: true
            },
            canPreview: function () { return isMoreDetailPage(); },
            previewDraft: function (draft) {
                if (!isMoreDetailPage()) throw new Error("visual_preview_wrong_page");
                const before = clone(state.config || DEFAULT_CONFIG);
                applyConfig(draft);
                return function () {
                    applyConfig(before);
                };
            }
        });
        return true;
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        window.PMKConfig.registerModule(moduleDefinition());
        registerCommonPickerAdapter();
        return true;
    }

    function waitForPMKConfig(timeout) {
        const max = Number(timeout) || 6000;
        if (registerModule()) return Promise.resolve(true);

        return new Promise(function (resolve) {
            let done = false;
            const finish = function (value) {
                if (done) return;
                done = true;
                window.removeEventListener("pmk:config-ready", onReady);
                resolve(value);
            };
            const onReady = function () {
                finish(registerModule());
            };
            window.addEventListener("pmk:config-ready", onReady, { once: true });
            window.setTimeout(function () { finish(registerModule()); }, max);
        });
    }

    function identifyStructure() {
        const dom=structure(),root=query(document,dom.root);if(!root)return null;
        const biblioSection=query(root,dom.biblioSection);
        const candidates=safeQueryAll(root,dom.items).filter(item=>item!==root && item!==biblioSection && !item.contains(biblioSection) && !!query(item,dom.itemContent));
        const items=candidates.filter(item=>!candidates.some(other=>other!==item && item.contains(other)));
        if(!items.length)return null;
        return {root,biblioSection,items};
    }
    function sectionKey(listgroup) {
        if(!listgroup)return null;
        for(const rule of state.config?.sections || [])if(rule.selector){try{if(listgroup.matches(rule.selector)||query(listgroup,rule.selector))return rule.key}catch(_){}}
        const defaults={information:'.homebranch, .itype, .ccode, .itemcallnumber, .copynumber, .location, .replacementprice, .materials',statuses:'.holdingbranch, .checkout_status, .renewals_count, .lost, .damaged, .withdrawn',priority:'.local_holds_priority, .bookable',history:'.issues, .datelastseen, .datelastborrowed, .enumchron, .itemnotes, .itemnotes_nonpublic, .dateaccessioned'};
        return Object.keys(defaults).find(key=>query(listgroup,defaults[key])) || null;
    }
    function findSection(item,key) {
        return safeQueryAll(itemContent(item),structure().groups).find(group=>sectionKey(group)===key) || null;
    }

    function rememberMove(node) {
        if (!node || !node.parentNode) return;
        state.movedNodes.push({
            node: node,
            parent: node.parentNode,
            nextSibling: node.nextSibling
        });
    }

    function rememberLabel(label) {
        if (!label || state.renamedLabels.has(label)) return;
        state.renamedLabels.set(label, label.textContent);
    }

    function rememberHeading(heading) {
        if (!heading || state.renamedHeadings.has(heading)) return;
        const target = heading.querySelector(":scope > span") || Array.from(heading.childNodes).find(function (node) {
            return node.nodeType === Node.TEXT_NODE && cleanText(node.textContent);
        });
        if (!target) return;
        state.renamedHeadings.set(heading, {
            target: target,
            text: target.textContent
        });
    }

    function setHeadingLabel(group, label) {
        if (!group || !label) return;
        const heading = query(group,structure().groupHeading);
        if (!heading) return;
        rememberHeading(heading);

        const stored = state.renamedHeadings.get(heading);
        if (!stored || !stored.target) return;
        stored.target.textContent = label + (stored.target.nodeType === Node.TEXT_NODE ? " " : "");
    }

    function injectStyles(config) {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }

        const layout = config.layout || {};
        const desktopColumns = clampInteger(layout.desktopColumns, 1, 6, 3);
        const tabletColumns = clampInteger(layout.tabletColumns, 1, 6, Math.min(2, desktopColumns));
        const mobileColumns = clampInteger(layout.mobileColumns, 1, 3, 1);
        const gap = clampInteger(layout.gap, 0, 80, 20);
        const padding = clampInteger(layout.outerPadding, 0, 80, 10);
        const pageBackground = cleanText(layout.pageBackground) || "#f9f9f9";
        const cardBackground = cleanText(layout.cardBackground) || "#f1f1f1";
        const sectionBackground = cleanText(layout.sectionBackground) || "#ffffff";
        const borderColor = cleanText(layout.borderColor) || "#cccccc";
        const highlightColor = cleanText(config.highlight && config.highlight.backgroundColor) || "#7abf87";

        style.textContent = `
            .pmk-md-active {
                padding: ${padding}px;
                background: ${pageBackground};
                border: 1px solid ${borderColor};
                box-sizing: border-box;
            }
            .pmk-md-active .pmk-md-biblio {
                padding: 10px;
                border: 1px solid ${borderColor};
                border-radius: 4px;
                background: ${sectionBackground};
                box-sizing: border-box;
                margin-bottom: ${gap}px;
            }
            #${GRID_ID} {
                display: grid;
                grid-template-columns: repeat(${desktopColumns}, minmax(0, 1fr));
                gap: ${gap}px;
                align-items: start;
            }
            #${GRID_ID} > .pmk-md-item-card {
                min-width: 0;
                box-sizing: border-box;
                padding: 10px;
                border: 1px solid ${borderColor};
                border-radius: 4px;
                background: ${cardBackground};
            }
            #${GRID_ID} > .pmk-md-item-card > .pmk-md-item-heading {
                margin-top: 0;
            }
            .pmk-md-item-sequence {
                font-weight: 700;
                margin: 0 0 .35rem;
            }
            .pmk-md-hidden { display: none !important; }
            .pmk-md-field-muted { opacity: .62; }
            .pmk-md-field-accent {
                border-left: 4px solid ${highlightColor};
                padding-left: .45rem;
            }
            .pmk-md-field-highlight {
                background: ${highlightColor} !important;
                border-radius: .2rem;
                padding: .15rem .35rem;
            }
            .pmk-md-item-highlight {
                background: ${highlightColor} !important;
                box-shadow: 0 0 0 2px ${highlightColor};
            }
            .pmk-md-section-toggle {
                border: 0;
                background: transparent;
                padding: .1rem .35rem;
                margin-left: .35rem;
                font-size: .9em;
            }
            .pmk-md-section-collapsed .pmk-md-group-rows { display: none !important; }
            @media (max-width: 1200px) {
                #${GRID_ID} { grid-template-columns: repeat(${tabletColumns}, minmax(0, 1fr)); }
            }
            @media (max-width: 768px) {
                .pmk-md-active { padding: ${Math.min(padding, 6)}px; }
                #${GRID_ID} { grid-template-columns: repeat(${mobileColumns}, minmax(0, 1fr)); }
                #${GRID_ID} > .pmk-md-item-card { padding: 8px; }
            }
        `;
    }

    function removeStyles() {
        const style = document.getElementById(STYLE_ID);
        if (style) style.remove();
    }

    function cleanup() {
        if (state.catalogueObserver) {
            state.catalogueObserver.disconnect();
            state.catalogueObserver = null;
        }

        state.addedNodes.forEach(function (node) {
            if (node && node.parentNode) node.remove();
        });
        state.addedNodes = [];

        Array.from(state.renamedLabels.entries()).forEach(function (entry) {
            const label = entry[0];
            if (label && label.isConnected) label.textContent = entry[1];
        });
        state.renamedLabels.clear();

        Array.from(state.renamedHeadings.entries()).forEach(function (entry) {
            const stored = entry[1];
            if (stored && stored.target && stored.target.isConnected) stored.target.textContent = stored.text;
        });
        state.renamedHeadings.clear();

        state.touchedNodes.forEach(function (node) {
            if (!node || !node.classList) return;
            node.classList.remove(
                "pmk-md-hidden",
                "pmk-md-field-muted",
                "pmk-md-field-accent",
                "pmk-md-field-highlight",
                "pmk-md-item-highlight",
                "pmk-md-section-collapsed",
                "pmk-md-item-card",
                "pmk-md-biblio", "pmk-md-item-heading", "pmk-md-group-rows"
            );
            node.removeAttribute("data-pmk-md-order");
        });
        state.touchedNodes.clear();

        for (let index = state.movedNodes.length - 1; index >= 0; index -= 1) {
            const record = state.movedNodes[index];
            if (!record || !record.node || !record.parent || !record.parent.isConnected) continue;
            const next = record.nextSibling && record.nextSibling.parentNode === record.parent
                ? record.nextSibling
                : null;
            record.parent.insertBefore(record.node, next);
        }
        state.movedNodes = [];

        const grid = document.getElementById(GRID_ID);
        if (grid && !grid.children.length) grid.remove();
        else if (grid) {
            const parent = state.originalItemsParent;
            if (parent) {
                Array.from(grid.children).forEach(function (child) {
                    parent.insertBefore(child, state.originalAfterItems && state.originalAfterItems.parentNode === parent ? state.originalAfterItems : null);
                });
            }
            grid.remove();
        }

        if (state.root) state.root.classList.remove("pmk-md-active");
        removeStyles();
        state.applied = false;
        state.root=null;state.biblioSection=null;state.items=[];
    }

    function buildCards(config) {
        if (!state.root || !state.items.length) return;
        const layout = config.layout || {};

        state.root.classList.add("pmk-md-active");
        if(state.biblioSection){state.biblioSection.classList.add("pmk-md-biblio");state.touchedNodes.add(state.biblioSection);}

        if (layout.showBibliographicBlock === false && state.biblioSection) {
            state.biblioSection.classList.add("pmk-md-hidden");
        }

        if (layout.mode !== "cards") return;

        const grid = document.createElement("div");
        grid.id = GRID_ID;
        grid.setAttribute("data-pmk-module", MODULE_ID);

        let anchor=state.items[0];
        while(anchor.parentElement && anchor.parentElement!==state.root)anchor=anchor.parentElement;
        state.originalItemsParent=state.root;
        state.originalAfterItems=anchor;
        state.root.insertBefore(grid,anchor);

        state.items.forEach(function (item, index) {
            item.classList.add("pmk-md-item-card");
            state.touchedNodes.add(item);
            rememberMove(item);
            grid.appendChild(item);
            const heading=query(item,structure().itemHeading);if(heading){heading.classList.add('pmk-md-item-heading');state.touchedNodes.add(heading);}

            if (layout.numberItems !== false) {
                const label = document.createElement("div");
                label.className = "pmk-md-item-sequence";
                const base = currentLanguage() === "en"
                    ? (cleanText(layout.itemNumberLabelEn) || "Item")
                    : (cleanText(layout.itemNumberLabelFr) || "Exemplaire");
                label.textContent = base + " " + (index + 1);
                item.insertBefore(label, item.firstChild);
                state.addedNodes.push(label);
            }
        });
    }

    function applySectionRules(config) {
        const rules = Array.isArray(config.sections) ? config.sections : [];
        if (!rules.length) return;

        state.items.forEach(function (item) {
            const pageSection = itemContent(item);
            if (!pageSection) return;

            const groupMap = new Map();
            safeQueryAll(pageSection,structure().groups).forEach(function (group) {
                const key = sectionKey(group);
                if (key) groupMap.set(key, group);
            });

            rules.forEach(function (rule) {
                const group = groupMap.get(rule && rule.key);
                if (!group) return;
                state.touchedNodes.add(group);

                if (rule.visible === false) group.classList.add("pmk-md-hidden");

                const customLabel = currentLanguage() === "en"
                    ? cleanText(rule.labelEn)
                    : cleanText(rule.labelFr);
                if (customLabel) setHeadingLabel(group, customLabel);

                if (rule.collapsible === true) {
                    const heading = query(group,structure().groupHeading);
                    const rows = query(group,structure().groupRows);
                    if(rows){rows.classList.add('pmk-md-group-rows');state.touchedNodes.add(rows);}
                    if (heading && rows) {
                        const button = document.createElement("button");
                        button.type = "button";
                        button.className = "pmk-md-section-toggle";
                        button.setAttribute("aria-expanded", rule.collapsedByDefault ? "false" : "true");
                        button.title = currentLanguage() === "en" ? "Expand/collapse section" : "Déplier/replier le bloc";
                        button.innerHTML = '<i class="fa fa-caret-down" aria-hidden="true"></i>';
                        button.addEventListener("click", function (event) {
                            event.preventDefault();
                            event.stopPropagation();
                            const collapsed = group.classList.toggle("pmk-md-section-collapsed");
                            button.setAttribute("aria-expanded", collapsed ? "false" : "true");
                            const icon = button.querySelector("i");
                            if (icon) {
                                icon.classList.toggle("fa-caret-right", collapsed);
                                icon.classList.toggle("fa-caret-down", !collapsed);
                            }
                        });
                        heading.appendChild(button);
                        state.addedNodes.push(button);
                        if (rule.collapsedByDefault) {
                            group.classList.add("pmk-md-section-collapsed");
                            const icon = button.querySelector("i");
                            if (icon) {
                                icon.classList.remove("fa-caret-down");
                                icon.classList.add("fa-caret-right");
                            }
                        }
                    }
                }
            });

            const ordered = rules.map(function (rule) {
                return groupMap.get(rule && rule.key);
            }).filter(Boolean);

            ordered.forEach(function (group) {
                rememberMove(group);
                pageSection.appendChild(group);
            });
        });
    }

    function selectedLabel(rule) {
        return currentLanguage() === "en" ? cleanText(rule.labelEn) : cleanText(rule.labelFr);
    }

    /*
     * Retrouve le libellé métier lié à une cible, même si la règle vise
     * directement le span.label, un formulaire, un select ou un autre
     * descendant du <li>. Cela rend le renommage indépendant du niveau
     * exact choisi avec le sélecteur visuel / CSS manuel.
     */
    function findLabelNode(target) {
        if (!target || !target.matches) return null;

        if (target.matches(structure().label)) return target;

        let label = null;
        try {
            label = query(target,structure().label);
        } catch (_) {
            label = null;
        }
        if (label) return label;

        if (target.querySelector) {
            label = query(target,structure().label);
            if (label) return label;
        }

        const field = target.closest(structure().field);
        if (field) {
            try {
                label = query(field,structure().label);
            } catch (_) {
                label = null;
            }
            if (label) return label;
            label = query(field,structure().label);
            if (label) return label;
        }

        return null;
    }

    function applyLabelReplacement(target, rule) {
        const labelText = selectedLabel(rule);
        if (!labelText || !target) return false;

        const label = findLabelNode(target);
        if (label) {
            rememberLabel(label);
            const original = cleanText(label.textContent);
            const suffix = /:\s*$/.test(original) ? ":" : "";
            label.textContent = labelText + suffix;
            return true;
        }

        if (safeQueryAll(itemContent(containingItem(target)),structure().groups).includes(target)) {
            setHeadingLabel(target, labelText);
            return true;
        }

        const heading = target.matches && target.matches("h2,h3,h4")
            ? target
            : (target.closest ? target.closest("h2,h3,h4") : null);
        if (heading) {
            rememberHeading(heading);
            const storedHeading = state.renamedHeadings.get(heading);
            if (storedHeading && storedHeading.target) {
                storedHeading.target.textContent = labelText +
                    (storedHeading.target.nodeType === Node.TEXT_NODE ? " " : "");
                return true;
            }
        }

        return false;
    }

    function isEffectivelyEmpty(element) {
        if (!element) return true;
        if (element.querySelector("input:not([type='hidden']), select, textarea, button, a")) return false;
        const cloneNode = element.cloneNode(true);
        safeQueryAll(cloneNode, structure().label).forEach(function (label) { label.remove(); });
        return cleanText(cloneNode.textContent).replace(/[:\u00a0]/g, "").trim() === "";
    }

    function targetRootsForRule(rule) {
        if (rule.scope === "biblio") return state.biblioSection ? [state.biblioSection] : [];
        if (rule.scope === "page") return [document];
        return state.items.slice();
    }

    function moveTargetToGroup(target, rule) {
        if (!target || rule.scope !== "item" || !rule.destinationGroup || rule.destinationGroup === "keep") return;
        const item = containingItem(target);
        if (!item) return;
        const group = findSection(item, rule.destinationGroup);
        const list = group && query(query(group,structure().groupRows),structure().fieldList);
        if (!list || target.parentNode === list) return;
        rememberMove(target);
        list.appendChild(target);
    }

    function applyOneFieldRule(rule, index) {
        if (!rule || rule.enabled === false || !cleanText(rule.selector)) return;
        const roots = targetRootsForRule(rule);
        roots.forEach(function (root) {
            safeQueryAll(root, rule.selector).forEach(function (target) {
                if (!target || target.closest("#pmk-config-overlay")) return;
                state.touchedNodes.add(target);

                if (rule.visible === false) target.classList.add("pmk-md-hidden");
                if (rule.hideWhenEmpty === true && isEffectivelyEmpty(target)) target.classList.add("pmk-md-hidden");

                applyLabelReplacement(target, rule);

                if (rule.emphasis === "muted") target.classList.add("pmk-md-field-muted");
                if (rule.emphasis === "accent") target.classList.add("pmk-md-field-accent");
                if (rule.highlight === true) target.classList.add("pmk-md-field-highlight");

                moveTargetToGroup(target, rule);

                const order = Number(rule.order);
                if (Number.isFinite(order) && order > 0 && target.matches(structure().field)) {
                    target.setAttribute("data-pmk-md-order", String(order));
                    target.setAttribute("data-pmk-md-rule-index", String(index));
                }
            });
        });
    }

    function applyConfiguredOrder() {
        const lists = new Set();
        state.touchedNodes.forEach(function (node) {
            if (node && node.matches && node.matches(structure().field) && node.parentElement && node.parentElement.matches(structure().fieldList)) {
                lists.add(node.parentElement);
            }
        });

        lists.forEach(function (list) {
            const children = Array.from(list.children);
            const ordered = children.filter(function (child) {
                return child.hasAttribute("data-pmk-md-order");
            }).sort(function (a, b) {
                const ao = Number(a.getAttribute("data-pmk-md-order")) || 9999;
                const bo = Number(b.getAttribute("data-pmk-md-order")) || 9999;
                if (ao !== bo) return ao - bo;
                const ai = Number(a.getAttribute("data-pmk-md-rule-index")) || 0;
                const bi = Number(b.getAttribute("data-pmk-md-rule-index")) || 0;
                return ai - bi;
            });

            ordered.forEach(function (node) {
                const wanted = Math.max(0, (Number(node.getAttribute("data-pmk-md-order")) || 1) - 1);
                const reference = list.children[wanted] || null;
                if (reference === node) return;
                rememberMove(node);
                list.insertBefore(node, reference);
            });
        });
    }

    function applyFieldRules(config) {
        const rules = Array.isArray(config.fieldRules) ? config.fieldRules : [];
        rules.forEach(applyOneFieldRule);
        applyConfiguredOrder();
    }

    function applyBarcodeHighlight(config) {
        const highlight = config.highlight || {};
        if (highlight.enabled === false) return;
        const storageKey = cleanText(highlight.storageKey) || "searchbox_value";
        let value = "";
        try {
            value = cleanText(window.localStorage.getItem(storageKey));
        } catch (_) {
            value = "";
        }
        if (!value) return;

        const normalized = value.toLowerCase();
        const item = state.items.find(function (container) {
            const heading = query(container,structure().itemHeading);
            return heading && cleanText(heading.textContent).toLowerCase().includes(normalized);
        });
        if (!item) return;

        item.classList.add("pmk-md-item-highlight");
        state.touchedNodes.add(item);
        if (highlight.scrollIntoView === true) {
            window.setTimeout(function () {
                item.scrollIntoView({ behavior: "smooth", block: "center" });
            }, 0);
        }
    }

    function moveCatalogueInfoNow(config) {
        const info = config.catalogueInfo || {};
        if (info.enabled === false || !state.biblioSection) return false;
        const selector = cleanText(info.selector) || ".catalogue-info";
        let block = null;
        try {
            block = document.querySelector(selector);
        } catch (_) {
            return false;
        }
        if (!block || state.biblioSection.contains(block)) return Boolean(block);

        const list = state.biblioSection.querySelector("ol.bibliodetails");
        if (!list) return false;
        rememberMove(block);
        list.insertAdjacentElement("afterend", block);
        return true;
    }

    function monitorCatalogueInfo(config) {
        const info = config.catalogueInfo || {};
        if (info.enabled === false) return;
        if (moveCatalogueInfoNow(config)) return;

        const waitMs = clampInteger(info.waitMs, 0, 30000, 5000);
        if (waitMs <= 0) return;

        state.catalogueObserver = new MutationObserver(function () {
            if (moveCatalogueInfoNow(config) && state.catalogueObserver) {
                state.catalogueObserver.disconnect();
                state.catalogueObserver = null;
            }
        });
        state.catalogueObserver.observe(document.body, { childList: true, subtree: true });
        window.setTimeout(function () {
            if (state.catalogueObserver) {
                state.catalogueObserver.disconnect();
                state.catalogueObserver = null;
            }
        }, waitMs);
    }

    function applyConfig(config) {
        cleanup();
        state.config = clone(config || DEFAULT_CONFIG);
        if (!isMoreDetailPage(state.config) || !pageEnabled(state.config)) return false;

        const structure = identifyStructure();
        if (!structure) return false;

        state.root = structure.root;
        state.biblioSection = structure.biblioSection;
        state.items = structure.items;

        injectStyles(state.config);
        buildCards(state.config);
        applySectionRules(state.config);
        applyFieldRules(state.config);
        applyBarcodeHighlight(state.config);
        monitorCatalogueInfo(state.config);
        state.applied = true;
        return true;
    }

    function diagnoseFieldRules(config) {
        const cfg = config || state.config || DEFAULT_CONFIG;
        const rules = Array.isArray(cfg.fieldRules) ? cfg.fieldRules : [];
        return rules.map(function (rule, index) {
            const roots = targetRootsForRule(rule || {});
            const matches = [];
            roots.forEach(function (root) {
                safeQueryAll(root, cleanText(rule && rule.selector)).forEach(function (target) {
                    const label = findLabelNode(target);
                    matches.push({
                        tag: target.tagName || "",
                        className: target.className || "",
                        currentLabel: label ? cleanText(label.textContent) : ""
                    });
                });
            });
            return {
                index: index,
                enabled: !(rule && rule.enabled === false),
                selector: cleanText(rule && rule.selector),
                scope: cleanText(rule && rule.scope) || "item",
                expectedLabel: rule ? selectedLabel(rule) : "",
                matchCount: matches.length,
                matches: matches.slice(0, 12)
            };
        });
    }

    function mountContextButton() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const heading = query(state.biblioSection,'h1,h2,h3,h4') || state.root;
        if (!heading) return;
        window.PMKConfig.mountContextButton({
            moduleId: MODULE_ID,
            anchor: heading,
            position: "after",
            contextKey: "moredetail-layout",
            context: { sectionId: "elements" }
        });
    }

    async function start() {
        await waitForPMKConfig(6000);

        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            applyConfig(DEFAULT_CONFIG);
            return;
        }

        state.config = await window.PMKConfig.getConfig(MODULE_ID);
        applyConfig(state.config);
        mountContextButton();

        if (typeof window.PMKConfig.subscribe === "function") {
            state.unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (nextConfig) {
                applyConfig(nextConfig);
                mountContextButton();
            });
        }
    }

    function boot() {
        registerVisualEditorAdapter();
        registerModule();
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", start, { once: true });
        } else {
            start();
        }
    }

    window.PMK011MoreDetail = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        pagePath: pagePath,
        moduleDefinition: moduleDefinition,
        pickElement: visualElementPicker,
        apply: function (config) {
            return applyConfig(config || state.config || DEFAULT_CONFIG);
        },
        diagnoseFieldRules: function () {
            return diagnoseFieldRules(state.config || DEFAULT_CONFIG);
        },
        cleanup: cleanup,
        refresh: function () {
            return applyConfig(state.config || DEFAULT_CONFIG);
        },
        getState: function () {
            return {
                applied: state.applied,
                itemCount: state.items.length,
                page: isMoreDetailPage()
            };
        }
    };

    boot();
})();

;window.PMKNonPlugin.loaded.push("011-moredetail-layout.js");
} catch (error) { window.PMKNonPlugin.errors.push("011-moredetail-layout.js: "+error.message); console.error("[PMK] 011-moredetail-layout.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.shuttle;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 013-estmation-passage-navette.js
 Dépendances: aucune
 Date de dernière modification: 2026-02-21
 Auteur: équipe PimpMyKoha
 Description: Estime le prochain passage de la navette pour les exemplaires selon le site et ajoute une colonne 'Prochain passage navette'.
*/

(function(){
    (function (callback) {
        if (document.readyState !== 'loading') callback.call(document);
        else document.addEventListener('DOMContentLoaded', callback, { once: true });
    })(function(){
        (function(){})('013-estmation-passage-navette: loaded');

if (window.location.pathname.includes("moremember.pl") || window.location.pathname.includes("circulation.pl")) {
    // schedule can be overridden by window.NAVETTE_SCHEDULE (object)
    const DEFAULT_JOURS_PASSAGE = {
        "Mardi": {
            "Matin": ["DRAGUIGNAN", "FIGANIERES", "BARGEMON", "CALLAS", "LA MOTTE", "DRAGUIGNAN"],
            "Après-midi": ["DRAGUIGNAN", "LE MUY", "VIDAUBAN", "LORGUES", "SALERNES", "FLAYOSC", "DRAGUIGNAN"]
        },
        "Mercredi": {
            "Matin": ["DRAGUIGNAN", "AMPUS", "MONTFERRAT", "COMPS-SUR-ARTUBY", "CLAVIERS", "DRAGUIGNAN"]
        },
        "Vendredi": {
            "Matin": ["DRAGUIGNAN", "LE MUY", "VIDAUBAN", "LORGUES", "SALERNES", "FLAYOSC", "DRAGUIGNAN"],
            "Après-midi": ["DRAGUIGNAN", "FIGANIERES", "BARGEMON", "CALLAS", "LA MOTTE", "DRAGUIGNAN"]
        }
    };

    if(typeof options.schedule==='string')options.schedule=options.schedule.trim()?JSON.parse(options.schedule):{};
    if(Object.values(options.schedule||{}).some(periods=>!periods||typeof periods!=='object'||Object.values(periods).some(sites=>!Array.isArray(sites))))throw new Error('Tournées invalides : chaque période doit contenir une liste de sites.');
    const JOURS_PASSAGE = (Object.keys(options.schedule || {}).length ? options.schedule : null) || window.NAVETTE_SCHEDULE || DEFAULT_JOURS_PASSAGE;

    // return {date: Date, jour: 'Mardi', periode: 'Matin'} or null
    function calculerProchaineDateNavette(site) {
        if (!site) return null;
        site = site.trim().toUpperCase();
        const now = new Date();

        // skip week 52 by ISO week
        const semaineActuelle = getISOWeekNumber(now);
        if (String(options.excludedWeeks).split(/[,;\s]+/).map(Number).includes(semaineActuelle)) return null;

        // find matching jour & periode
        let matchJour = null;
        let matchPeriode = null;
        for (const jour in JOURS_PASSAGE) {
            for (const periode in JOURS_PASSAGE[jour]) {
                const arr = JOURS_PASSAGE[jour][periode].map(s => s.toUpperCase());
                if (arr.includes(site)) {
                    matchJour = jour;
                    matchPeriode = periode;
                    break;
                }
            }
            if (matchJour) break;
        }
        if (!matchJour) return null;

        // compute next date for the weekday of matchJour
        const targetWeekday = getJourSemaine(matchJour); // 0..6
        let candidate = new Date(now.getTime());

        // if today is before target weekday, move forward; if same day, consider period and hour
        const todayWeekday = candidate.getDay();
        if (todayWeekday !== targetWeekday) {
            // advance day by day until match
            let daysToAdd = (targetWeekday - todayWeekday + 7) % 7;
            if (daysToAdd === 0) daysToAdd = 7;
            candidate.setDate(candidate.getDate() + daysToAdd);
        } else {
            // same weekday: check period cutoff
            const hour = candidate.getHours();
            if (matchPeriode === 'Matin' && hour >= Number(options.morningCutoff)) {
                candidate.setDate(candidate.getDate() + 7);
            } else if (matchPeriode === 'Après-midi' && hour >= Number(options.afternoonCutoff)) {
                candidate.setDate(candidate.getDate() + 7);
            }
        }

        // if candidate is Thursday (4), skip to next day (business rule preserved)
        while(String(options.excludedWeeks).split(/[,;\s]+/).map(Number).includes(getISOWeekNumber(candidate))) candidate.setDate(candidate.getDate()+7);

        return { date: candidate, jour: matchJour, periode: matchPeriode };
    }

    // Fonction pour obtenir l'indice du jour de la semaine (0 = Dimanche, 1 = Lundi, ..., 6 = Samedi)
    function getJourSemaine(jour) {
        const joursSemaine = {
            "dimanche": 0,
            "lundi": 1,
            "mardi": 2,
            "mercredi": 3,
            "jeudi": 4,
            "vendredi": 5,
            "samedi": 6
        };
        return joursSemaine[(jour || '').toLowerCase()] || 0;
    }

    // Fonction pour obtenir la semaine de l'année
    // ISO week number
    function getISOWeekNumber(date) {
        const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        // Set to nearest Thursday: current date + 4 - current day number
        d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
        const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
        const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
        return weekNo;
    }

    // Fonction pour calculer le nombre de jours entre aujourd'hui et la date donnée
    // days difference using UTC day boundaries
    function dateOnlyUTC(d) {
        return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate());
    }
    function calculerNombreDeJours(dateArrivee) {
        if (!(dateArrivee instanceof Date) || isNaN(dateArrivee)) return NaN;
        const aujourd = new Date();
        const diff = dateOnlyUTC(dateArrivee) - dateOnlyUTC(aujourd);
        return Math.ceil(diff / (1000 * 3600 * 24));
    }

    // Fonction pour ajouter l'en-tête de la colonne et la colonne avec la prochaine date de navette
    function detectColumnIndices() {
        const headerRow = document.querySelector('#holds-table thead tr');
        const headers = headerRow ? Array.from(headerRow.querySelectorAll('th')).map(th => (th.textContent || '').trim().toLowerCase()) : [];
        const idx = nameFragments => {
            for (let i = 0; i < headers.length; i++) {
                const h = headers[i];
                if (!h) continue;
                for (const frag of nameFragments) {
                    if (h.includes(frag)) return i;
                }
            }
            return -1;
        };
        return {
            borrowed: idx(['emprunt', 'emprunté']) >= 0 ? idx(['emprunt', 'emprunté']) : 8,
            site: idx(['site', 'localisation', 'location', 'info', 'emprunté à']) >= 0 ? idx(['site', 'localisation', 'location', 'info', 'emprunté à']) : 5,
            status: idx(['statut', 'status', 'etat', 'état', 'prêté', 'state']) >= 0 ? idx(['statut', 'status', 'etat', 'état', 'prêté', 'state']) : 10
        };
    }

    function ajouterColonneDateNavette() {
        const table = document.querySelector('#holds-table');
        if (!table) return;
        const enTete = table.querySelector('thead tr');
        if (enTete && !enTete.querySelector('th.prochaine-date-navette')) {
            const nouvelleCellule = document.createElement('th');
            nouvelleCellule.classList.add('prochaine-date-navette');
            nouvelleCellule.textContent = 'Prochain passage navette';
            nouvelleCell.style.textAlign = 'center';
            nouvelleCell.style.backgroundColor = 'white';
            nouvelleCell.style.fontWeight = 'bold';
            nouvelleCell.style.border = '1px solid #ddd';
            enTete.appendChild(nouvelleCellule);
        }

        const cols = detectColumnIndices();
        const lignes = table.querySelectorAll('tbody tr');
        lignes.forEach((ligne) => {
            if (ligne.dataset.navetteAdded === 'true') return; // idempotence per row

            const celluleStatut = ligne.cells[cols.status];
            const celluleSite = ligne.cells[cols.site];

            if (!celluleStatut || !celluleSite) {
                ligne.dataset.navetteAdded = 'true';
                return;
            }

            const statutText = (celluleStatut.textContent || '').trim().toLowerCase();
            if (!statutText || statutText.includes('exemplaire en attente') || statutText.includes('en attente')) {
                ligne.dataset.navetteAdded = 'true';
                return;
            }

            // create cell only if not already present
            const nouvelleCellule = document.createElement('td');
            nouvelleCellule.style.textAlign = 'center';
            nouvelleCellule.style.padding = '8px';

            const site = (celluleSite.textContent || '').trim();
            const info = calculerProchaineDateNavette(site);
            if (!info || !info.date) {
                nouvelleCellule.innerHTML = "Date d'arrivée estimée : <br/>N/A";
            } else {
                const nombreDeJours = calculerNombreDeJours(info.date);
                const prefixe = "Date d'arrivée estimée : <br/>";
                const peri = info.periode ? ` (${info.periode})` : '';
                const suffixe = Number.isFinite(nombreDeJours) ? `dans ${nombreDeJours} jours` : '';
                nouvelleCellule.innerHTML = `${prefixe}${info.date.toLocaleDateString('fr-FR')}${peri} <br/>${suffixe}`;
                nouvelleCellule.title = `Jour: ${info.jour}${peri} — ${info.date.toLocaleString('fr-FR')}`;
            }

            ligne.appendChild(nouvelleCellule);
            ligne.dataset.navetteAdded = 'true';
        });
    }

    // Remplacer le timer par une attente non‑bloquante de l'apparition des lignes du tableau
    function waitForSelector(selector, timeout = 3000) {
        return new Promise((resolve, reject) => {
            const el = document.querySelector(selector);
            if (el) return resolve(el);
            const obs = new MutationObserver(() => {
                const found = document.querySelector(selector);
                if (found) { obs.disconnect(); resolve(found); }
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(() => { obs.disconnect(); reject(new Error('timeout')); }, timeout);
        });
    }

    const holdsTab = document.getElementById('holds-tab');
    function observeHoldsTable() {
        const tableBody = document.querySelector('#holds-table tbody');
        if (!tableBody) return;
        // run once immediately
        ajouterColonneDateNavette();
        // create a scoped MutationObserver to watch for changes inside the tbody
        const mo = new MutationObserver(() => {
            // when rows change, try to add column data for new rows
            ajouterColonneDateNavette();
        });
        mo.observe(tableBody, { childList: true, subtree: true });
        // store observer to disconnect later if needed
        tableBody._navetteObserver = mo;
    }

    if (holdsTab) {
        holdsTab.addEventListener('click', function () {
            // wait for the specific table rows
            waitForSelector('#holds-table tbody tr', 2000)
              .then(() => observeHoldsTable())
              .catch(() => requestAnimationFrame(() => observeHoldsTable()));
        });
    } else {
        // if no tab (page rendered directly), try to observe immediately
        waitForSelector('#holds-table tbody tr', 2000).then(() => observeHoldsTable()).catch(()=>{});
    }
}
  });
})();
})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("013-estmation-passage-navette.js");
} catch (error) { window.PMKNonPlugin.errors.push("013-estmation-passage-navette.js: "+error.message); console.error("[PMK] 013-estmation-passage-navette.js",error); };
try {
/* Compatibility entry point. Settings and rendering are unified in relative-dates.
 * Existing Firestore documents are read and preserved by 000; no document is deleted. */
(function () {
    'use strict';
    if (window.VC_DATE_UTILS || document.querySelector('script[data-pmk-date-runtime]')) return;
    const current=document.currentScript;
    if (!current || !current.src) return;
    const script=document.createElement('script');
    script.dataset.pmkDateRuntime='1';
    script.src=new URL('070-date-utils.js',current.src).href;
    document.head.appendChild(script);
})();

;window.PMKNonPlugin.loaded.push("014-calcule-dates-reservations.js");
} catch (error) { window.PMKNonPlugin.errors.push("014-calcule-dates-reservations.js: "+error.message); console.error("[PMK] 014-calcule-dates-reservations.js",error); };
try {
/*
 Nom du fichier: 017-gestion-litiges-select.js
 Version: 3.2.1
 Date de dernière modification: 2026-09-19
 Auteur: équipe PimpMyKoha / adaptation PimpMyKoha
 Description:
 - Moteur transversal « Aides à la saisie ».
 - Fusionne le 017 historique et le 047-request-dropdowns.js.
 - Conserve strictement les valeurs prédéfinies des deux scripts historiques.
 - Le 017 reste en mode ajout de texte dans #borrower_message.
 - Le 047 devient un profil structuré sur #holdnotes.
 - Chaque liste choisit désormais son effet sur la cible : ajouter ou remplacer tout le contenu.
 - Chaque profil choisit la disposition des listes : côte à côte ou les unes sous les autres.
 - Ne remplace plus jamais #non_priority_list_item.
 - Cible et emplacement sélectionnables avec le picker commun PMK.
 - Aperçu intégré + aperçu live via PMKConfig.visualEditor.
 - Configuration centralisée via 000-pmk-config-firestore.js.
*/
(function () {
    "use strict";

    if (window.__PMK017_INPUT_HELPERS__) return;
    window.__PMK017_INPUT_HELPERS__ = true;
    window.__PMK_047_MERGED_INTO_017__ = true;

    const MODULE_ID = "patron-message-templates";
    const MODULE_VERSION = "3.2.1";
    const WRAPPER_CLASS = "pmk-input-helper";
    const STYLE_ID = "pmk-input-helper-styles";

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        const htmlLang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function i18n(fr, en) {
        return language() === "en" ? en : fr;
    }

    function makeId(prefix) {
        return String(prefix || "profile") + "-" + Date.now().toString(36) + "-" +
            Math.random().toString(36).slice(2, 8);
    }

    const LEGACY_017_GROUPS = [
        {
            enabled: true,
            label: "Gestion des litiges",
            targetAction: "append",
            messages: [
                { enabled: true, label: "Adhérent contacté", text: "Adhérent contacté" },
                { enabled: true, label: "Document perdu : [Numéro exemplaire]", text: "Document perdu : [Numéro exemplaire]" },
                { enabled: true, label: "Document abîmé : [Numéro exemplaire]", text: "Document abîmé : [Numéro exemplaire]" },
                { enabled: true, label: "Demande de consigne de rachat effectuée", text: "Demande de consigne de rachat effectuée" },
                { enabled: true, label: "Rachat à l'identique demandé : [EAN Attendu]", text: "Rachat à l'identique demandé : [EAN Attendu]" },
                { enabled: true, label: "Rachat à document équivalent demandé : [EAN Attendu]", text: "Rachat à document équivalent demandé : [EAN Attendu]" },
                { enabled: true, label: "Documents proposé incorrect :", text: "Documents proposé incorrect :" },
                { enabled: true, label: "Adhérent contacté pour rachat", text: "Adhérent contacté pour rachat" },
                { enabled: true, label: "Document racheté réceptionné. (pensez à supprimer ce message après traitement)", text: "Document racheté réceptionné. (pensez à supprimer ce message après traitement)" },
                { enabled: true, label: "Appelé pour TP4", text: "Appelé pour TP4" },
                { enabled: true, label: "Document neuf réceptionné. En attente de traitement", text: "Document neuf réceptionné. En attente de traitement" },
                { enabled: true, label: "Lettre TP4 à la signature", text: "Lettre TP4 à la signature" },
                { enabled: true, label: "Lettre TP4 envoyée", text: "Lettre TP4 envoyée" },
                { enabled: true, label: "Transmis au service finances", text: "Transmis au service finances" },
                { enabled: true, label: "Note libre :", text: "Note libre :" }
            ]
        }
    ];

    const LEGACY_047_GROUPS = [
        {
            enabled: true,
            label: "Raison de la réservation:",
            targetAction: "replace",
            prefix: "Raison de la réservation: ",
            labelColor: "red",
            messages: [
                { enabled: true, label: "Réservation pour adhérents", text: "Réservation pour adhérents" },
                { enabled: true, label: "Réservation Perso sur carte pro", text: "Réservation Perso sur carte pro" },
                { enabled: true, label: "Réservation Pro Cube", text: "Réservation Pro Cube" },
                { enabled: true, label: "Réservation Pro Portage", text: "Réservation Pro Portage" },
                { enabled: true, label: "Réservation Pro Club lecture", text: "Réservation Pro Club lecture" },
                { enabled: true, label: "Réservation Pro EAC", text: "Réservation Pro EAC" },
                { enabled: true, label: "Réservation Pro Animation", text: "Réservation Pro Animation" },
                { enabled: true, label: "Réservation Pro Gestion des collections", text: "Réservation Pro Gestion des collections" },
                { enabled: true, label: "Réservation Pro Vérification exemplaire", text: "Réservation Pro Vérification exemplaire" },
                { enabled: true, label: "Réservation pour suggestion", text: "Réservation pour suggestion" },
                { enabled: true, label: "Autre", text: "Autre" }
            ]
        },
        {
            enabled: true,
            label: "Site de retrait MEDIABUS",
            targetAction: "append",
            prefix: "Site de retrait MEDIABUS: ",
            labelColor: "blue",
            messages: [
                { enabled: true, label: "Chateaudouble", text: "Chateaudouble" },
                { enabled: true, label: "Bargeme", text: "Bargeme" },
                { enabled: true, label: "St-Antonin", text: "St-Antonin" },
                { enabled: true, label: "Sillans la cascade", text: "Sillans la cascade" },
                { enabled: true, label: "La Bastide", text: "La Bastide" },
                { enabled: true, label: "La Roque-Esclapon", text: "La Roque-Esclapon" },
                { enabled: true, label: "Claviers", text: "Claviers" },
                { enabled: true, label: "Taradeau", text: "Taradeau" },
                { enabled: true, label: "Trans", text: "Trans" },
                { enabled: true, label: "Les Arcs", text: "Les Arcs" }
            ]
        },
        {
            enabled: true,
            label: "Priorité",
            targetAction: "append",
            prefix: "Priorité: ",
            labelColor: "blue",
            messages: [
                { enabled: true, label: "Urgente", text: "Urgente" },
                { enabled: true, label: "Normale", text: "Normale" },
                { enabled: true, label: "Long terme", text: "Long terme" },
                { enabled: true, label: "Test", text: "Test" }
            ]
        }
    ];

    const LEGACY_017_PROFILE = {
        id: "legacy-017-patron-messages",
        enabled: true,
        label: "Messages lecteur — Gestion des litiges",
        mode: "append",
        pages: [
            { pageId: "members.moremember", enabled: true, path: "members/moremember.pl" },
            { pageId: "circ.circulation", enabled: true, path: "circ/circulation.pl" }
        ],
        targetSelector: "#borrower_message",
        targetName: "Message lecteur",
        anchorSelector: "#select_patron_messages",
        anchorName: "Liste native des messages lecteur",
        insertPosition: "after",
        showHeading: true,
        headingFr: "Messages prédéfinis",
        headingEn: "Predefined messages",
        placeholder: "Sélectionnez un message",
        defaultTextIfEmpty: "",
        preserveManualText: true,
        listsLayout: "horizontal",
        groups: LEGACY_017_GROUPS
    };

    const LEGACY_047_PROFILE = {
        id: "legacy-047-holdnotes",
        enabled: true,
        label: "Notes de réservation",
        mode: "compose",
        pages: [
            { pageId: "reserve.request", enabled: true, path: "reserve/request.pl" }
        ],
        targetSelector: "#holdnotes",
        targetName: "Notes",
        anchorSelector: "#holdnotes",
        anchorName: "Notes",
        insertPosition: "after",
        showHeading: false,
        headingFr: "",
        headingEn: "",
        placeholder: " - ",
        defaultTextIfEmpty: "Réservation pour adhérents",
        preserveManualText: true,
        listsLayout: "horizontal",
        groups: LEGACY_047_GROUPS
    };

    const DEFAULT_CONFIG = {
        enabled: true,
        profiles: [
            clone(LEGACY_017_PROFILE),
            clone(LEGACY_047_PROFILE)
        ]
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let observer = null;
    let unsubscribe = null;
    let injectScheduled = false;
    let composeStates = new WeakMap();

    function normalizePage(page, index) {
        const source = page && typeof page === "object" ? page : {};
        return {
            pageId: String(source.pageId || ("custom.page." + (index + 1))),
            enabled: source.enabled !== false,
            path: String(source.path || "")
        };
    }

    function normalizeMessage(message) {
        const source = message && typeof message === "object" ? message : {};
        return {
            enabled: source.enabled !== false,
            label: source.label === undefined || source.label === null ? "" : String(source.label),
            text: source.text === undefined || source.text === null ? "" : String(source.text)
        };
    }

    function defaultTargetActionForGroup(source) {
        const explicit = String(source && source.targetAction || "").toLowerCase();
        if (explicit === "replace") return "replace";
        if (explicit === "append") return "append";

        // Migration des configurations 017+047 déjà enregistrées avant la v3.1.0.
        // La seule liste historique qui remplace toute la cible par défaut est « Raison de la réservation: ».
        const marker = (
            String(source && source.label || "") + " " +
            String(source && source.prefix || "")
        ).toLowerCase();
        return marker.includes("raison de la réservation") ? "replace" : "append";
    }

    function normalizeGroup(group, mode) {
        const source = group && typeof group === "object" ? group : {};
        return {
            enabled: source.enabled !== false,
            label: source.label === undefined || source.label === null ? "" : String(source.label),
            targetAction: defaultTargetActionForGroup(source),
            prefix: mode === "compose"
                ? (source.prefix === undefined || source.prefix === null ? "" : String(source.prefix))
                : "",
            labelColor: source.labelColor === undefined || source.labelColor === null ? "" : String(source.labelColor),
            messages: Array.isArray(source.messages) ? source.messages.map(normalizeMessage) : []
        };
    }

    function normalizeProfile(profile, index) {
        const source = profile && typeof profile === "object" ? profile : {};
        const mode = source.mode === "compose" ? "compose" : "append";
        return {
            id: String(source.id || ("input-profile-" + (index + 1))),
            enabled: source.enabled !== false,
            label: source.label === undefined || source.label === null
                ? "Profil " + (index + 1)
                : String(source.label),
            mode: mode,
            pages: Array.isArray(source.pages) ? source.pages.map(normalizePage) : [],
            targetSelector: String(source.targetSelector || ""),
            targetName: String(source.targetName || ""),
            anchorSelector: String(source.anchorSelector || ""),
            anchorName: String(source.anchorName || ""),
            insertPosition: source.insertPosition === "before" ? "before" : "after",
            showHeading: source.showHeading !== false,
            headingFr: source.headingFr === undefined || source.headingFr === null ? "" : String(source.headingFr),
            headingEn: source.headingEn === undefined || source.headingEn === null ? "" : String(source.headingEn),
            placeholder: source.placeholder === undefined || source.placeholder === null ? "" : String(source.placeholder),
            defaultTextIfEmpty: source.defaultTextIfEmpty === undefined || source.defaultTextIfEmpty === null
                ? ""
                : String(source.defaultTextIfEmpty),
            preserveManualText: source.preserveManualText !== false,
            listsLayout: source.listsLayout === "vertical" ? "vertical" : "horizontal",
            groups: Array.isArray(source.groups)
                ? source.groups.map(function (group) { return normalizeGroup(group, mode); })
                : []
        };
    }

    function normalizeConfig(config) {
        const source = config && typeof config === "object" ? clone(config) : {};
        let profiles = Array.isArray(source.profiles)
            ? source.profiles.map(normalizeProfile)
            : clone(DEFAULT_CONFIG.profiles);

        const hasLegacy017 =
            Object.prototype.hasOwnProperty.call(source, "groups") ||
            Object.prototype.hasOwnProperty.call(source, "pages") ||
            Object.prototype.hasOwnProperty.call(source, "placeholder");

        if (hasLegacy017) {
            const patron = clone(LEGACY_017_PROFILE);
            if (Array.isArray(source.pages)) patron.pages = clone(source.pages);
            if (Object.prototype.hasOwnProperty.call(source, "placeholder")) {
                patron.placeholder = source.placeholder === null || source.placeholder === undefined
                    ? ""
                    : String(source.placeholder);
            }
            if (Array.isArray(source.groups)) patron.groups = clone(source.groups);

            const index = profiles.findIndex(function (profile) {
                return profile && profile.id === LEGACY_017_PROFILE.id;
            });
            if (index >= 0) profiles[index] = normalizeProfile(patron, index);
            else profiles.unshift(normalizeProfile(patron, 0));

            if (!profiles.some(function (profile) {
                return profile && profile.id === LEGACY_047_PROFILE.id;
            })) {
                profiles.push(normalizeProfile(clone(LEGACY_047_PROFILE), profiles.length));
            }
        }

        return {
            enabled: source.enabled !== false,
            profiles: profiles.map(normalizeProfile)
        };
    }

    function currentPathKey() {
        return String(window.location.pathname || "").replace(/^\/cgi-bin\/koha\//, "");
    }

    function pageMatchesEntry(page) {
        if (!page || page.enabled === false) return false;
        const raw = String(page.path || "").trim();
        if (!raw) return false;
        let wanted = raw;
        if (/^https?:\/\//i.test(raw)) {
            try {
                const url = new URL(raw);
                wanted = url.pathname + url.search;
            } catch (_) {
                return false;
            }
        }
        if (wanted.charAt(0) !== "/") wanted = "/cgi-bin/koha/" + wanted.replace(/^cgi-bin\/koha\//, "");

        let wantedUrl;
        try {
            wantedUrl = new URL(wanted, window.location.origin);
        } catch (_) {
            return false;
        }
        if (wantedUrl.pathname !== window.location.pathname) return false;

        const current = new URL(window.location.href);
        let ok = true;
        wantedUrl.searchParams.forEach(function (value, key) {
            if (current.searchParams.get(key) !== value) ok = false;
        });
        return ok;
    }

    function profileMatchesPage(profile) {
        return Boolean(
            profile &&
            profile.enabled !== false &&
            Array.isArray(profile.pages) &&
            profile.pages.some(pageMatchesEntry)
        );
    }

    function activeProfiles(config) {
        if (!config || config.enabled === false || !Array.isArray(config.profiles)) return [];
        return config.profiles.filter(profileMatchesPage);
    }

    function activeGroups(profile) {
        if (!profile || !Array.isArray(profile.groups)) return [];
        return profile.groups.filter(function (group) {
            return group && group.enabled !== false && String(group.label || "").trim();
        });
    }

    function activeMessages(group) {
        if (!group || !Array.isArray(group.messages)) return [];
        return group.messages.filter(function (message) {
            return message &&
                message.enabled !== false &&
                String(message.label || "").trim() &&
                String(message.text || "").trim();
        });
    }

    function safeQueryAll(root, selector) {
        const value = String(selector || "").trim();
        if (!value) return [];
        try {
            return Array.from((root || document).querySelectorAll(value));
        } catch (_) {
            return [];
        }
    }

    function scopeForTarget(target) {
        return target && (target.closest("form,.modal,fieldset,.page-section") || document);
    }

    function resolveAnchor(target, profile) {
        if (!target) return null;
        const selector = String(profile && profile.anchorSelector || "").trim();
        if (!selector) return target;
        const scope = scopeForTarget(target);
        try {
            return (scope && scope.querySelector(selector)) || document.querySelector(selector) || target;
        } catch (_) {
            return target;
        }
    }

    function insertionNode(anchor) {
        if (!anchor) return null;
        return anchor.closest("li.form-group, li, div.form-group, .form-group") || anchor;
    }

    function notifyTargetChange(target) {
        if (!target) return;
        try { target.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
        try { target.dispatchEvent(new Event("change", { bubbles: true })); } catch (_) {}
    }

    function appendMessage(target, text) {
        const value = String(text || "").trim();
        if (!target || !value) return;
        const existing = String(target.value || "");
        target.value = existing ? existing.replace(/\s+$/, "") + "\n" + value : value;
        notifyTargetChange(target);
        try { target.focus(); } catch (_) {}
    }

    function replaceMessage(target, text) {
        const value = String(text || "").trim();
        if (!target || !value) return;
        target.value = value;
        notifyTargetChange(target);
        try { target.focus(); } catch (_) {}
    }

    function stripManagedSuffix(currentValue, lastGenerated) {
        const current = String(currentValue || "");
        const managed = String(lastGenerated || "");
        if (!managed) return current;
        if (current === managed) return "";
        if (current.endsWith("\n" + managed)) {
            return current.slice(0, -(managed.length + 1)).replace(/\s+$/, "");
        }
        return current;
    }

    function updateCompositeTarget(target, profile, selections) {
        if (!target) return;
        let state = composeStates.get(target);
        if (!state) {
            state = { lastGenerated: "" };
            composeStates.set(target, state);
        }

        let manual = String(target.value || "");
        if (profile.preserveManualText !== false) {
            manual = stripManagedSuffix(manual, state.lastGenerated);
        } else {
            manual = "";
        }

        const lines = [];
        activeGroups(profile).forEach(function (group, groupIndex) {
            const text = selections[groupIndex] || "";
            if (!text) return;
            lines.push(String(group.prefix || "") + text);
        });
        const generated = lines.join("\n");

        target.value = manual
            ? (generated ? manual.replace(/\s+$/, "") + "\n" + generated : manual)
            : generated;

        state.lastGenerated = generated;
        notifyTargetChange(target);
    }

    function ensureHistoricalDefault(target, profile) {
        if (!target || profile.mode !== "compose") return;
        const initial = String(profile.defaultTextIfEmpty || "");
        if (!initial || String(target.value || "").trim()) return;
        target.value = initial;
        composeStates.set(target, { lastGenerated: "" });
        notifyTargetChange(target);
    }

    function buildSelect(target, profile, group, groupIndex, selections) {
        const block = document.createElement("div");
        block.className = "pmk-input-helper-group";
        block.dataset.pmkGroupIndex = String(groupIndex);

        const groupLabel = document.createElement("label");
        groupLabel.className = "col-form-label pmk-input-helper-group-label";
        groupLabel.textContent = String(group.label || "");
        if (String(group.labelColor || "").trim()) {
            groupLabel.style.color = String(group.labelColor);
        }

        const select = document.createElement("select");
        select.className = "form-select form-select-sm pmk-input-helper-select";
        select.setAttribute(
            "aria-label",
            (language() === "en" ? "Input helper — " : "Aide à la saisie — ") + String(group.label || "")
        );

        const placeholder = document.createElement("option");
        placeholder.value = "";
        placeholder.textContent = String(profile.placeholder || "") ||
            (language() === "en" ? "Select a value" : "Sélectionnez une valeur");
        select.appendChild(placeholder);

        activeMessages(group).forEach(function (message, messageIndex) {
            const option = document.createElement("option");
            option.value = String(messageIndex);
            option.textContent = String(message.label);
            option.dataset.pmkMessageText = String(message.text);
            select.appendChild(option);
        });

        select.addEventListener("change", function () {
            if (!select.value) return;
            const option = select.options[select.selectedIndex];
            const rawText = option && option.dataset ? String(option.dataset.pmkMessageText || "") : "";
            if (!rawText) return;

            const formattedText = profile.mode === "compose"
                ? String(group.prefix || "") + rawText
                : rawText;
            const action = group.targetAction === "replace" ? "replace" : "append";

            if (profile.mode !== "compose") {
                if (action === "replace") replaceMessage(target, formattedText);
                else appendMessage(target, formattedText);
                select.value = "";
                return;
            }

            if (action === "replace") {
                // « Remplacer » signifie bien remplacer TOUT le contenu de la zone cible.
                // Les autres sélections gérées sont annulées pour que l'interface reste cohérente.
                for (let i = 0; i < selections.length; i += 1) selections[i] = "";
                selections[groupIndex] = rawText;
                replaceMessage(target, formattedText);
                composeStates.set(target, { lastGenerated: formattedText });

                const groupsRoot = select.closest(".pmk-input-helper-groups");
                if (groupsRoot) {
                    groupsRoot.querySelectorAll(".pmk-input-helper-select").forEach(function (otherSelect) {
                        if (otherSelect !== select) otherSelect.value = "";
                    });
                }
                return;
            }

            selections[groupIndex] = rawText;
            updateCompositeTarget(target, profile, selections);
        });

        block.appendChild(groupLabel);
        const effect=document.createElement('small');effect.className='pmk-input-helper-effect';effect.style.display='block';
        effect.textContent=group.targetAction==='replace'?i18n('Remplace tout le contenu du champ.', 'Replaces the entire field content.'):i18n('Ajoute au contenu du champ.', 'Adds to the field content.');
        const texts=activeMessages(group).map(message=>String(message.text));
        const duplicates=texts.length-new Set(texts).size;
        if(duplicates)effect.textContent+=' '+duplicates+' '+i18n('valeur(s) répétée(s) dans cette liste ; les choix sont conservés.','repeated value(s) in this list; all choices are retained.');
        effect.id=makeId('pmk-input-effect');select.setAttribute('aria-describedby',effect.id);block.appendChild(effect);
        if(texts.length>20){
            const search=document.createElement('input');search.type='search';search.className='form-control form-control-sm pmk-input-helper-search';
            search.placeholder=i18n('Rechercher dans cette liste','Search this list');search.setAttribute('aria-label',search.placeholder+' — '+String(group.label||''));
            const options=Array.from(select.options);
            search.addEventListener('input',()=>{const value=select.value,query=search.value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase();select.replaceChildren(...options.filter(option=>!option.value||option.value===value||(option.textContent+' '+(option.dataset.pmkMessageText||'')).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().includes(query)));select.value=value;});
            block.appendChild(search);
        }
        block.appendChild(select);
        return block;
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk-input-helper {
                display: block;
                box-sizing: border-box;
                width: 100%;
                max-width: 48rem;
                margin-top: .55rem;
            }
            .pmk-input-helper-heading {
                display: flex;
                align-items: center;
                gap: .35rem;
                font-weight: 600;
                margin-bottom: .45rem;
            }
            .pmk-input-helper-groups {
                display: grid;
                gap: .6rem .75rem;
                align-items: end;
                width: 100%;
            }
            .pmk-input-helper-groups--horizontal {
                grid-template-columns: repeat(auto-fit, minmax(13rem, 1fr));
            }
            .pmk-input-helper-groups--vertical {
                grid-template-columns: minmax(0, 1fr);
            }
            .pmk-input-helper-group {
                min-width: 0;
            }
            .pmk-input-helper-group-label {
                display: block;
                font-weight: 600;
                margin-bottom: .2rem;
                padding-top: 0;
            }
            .pmk-input-helper-select {
                width: 100%;
                max-width: 100%;
            }
            @media (max-width: 576px) {
                .pmk-input-helper {
                    max-width: 100%;
                }
                .pmk-input-helper-groups--horizontal {
                    grid-template-columns: 1fr;
                }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function wrapperSelector(profileId) {
        return "." + WRAPPER_CLASS + '[data-pmk-profile-id="' +
            String(profileId || "").replace(/"/g, '\\"') + '"]';
    }

    function mountContextButton(wrapper, profile) {
        if (!wrapper || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = wrapper.querySelector(".pmk-input-helper-heading, .pmk-input-helper-group-label");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "input-helper-" + String(profile.id || "profile"),
                context: {
                    pageId: currentPathKey(),
                    sectionId: "profiles",
                    profileId: profile.id
                }
            });
        } catch (_) {}
    }

    function injectProfileForTarget(profile, target, targetIndex) {
        if (!profile || !target) return false;
        const scope = scopeForTarget(target);
        const existing = scope && scope.querySelector(wrapperSelector(profile.id) + '[data-pmk-target-index="' + targetIndex + '"]');
        if (existing) return false;

        const anchor = resolveAnchor(target, profile);
        const reference = insertionNode(anchor);
        if (!reference || !reference.parentNode) return false;

        const tag = reference.tagName === "LI" ? "li" : "div";
        const wrapper = document.createElement(tag);
        wrapper.className = "form-group form-row " + WRAPPER_CLASS;
        wrapper.dataset.pmkModule = MODULE_ID;
        wrapper.dataset.pmkProfileId = String(profile.id || "");
        wrapper.dataset.pmkTargetIndex = String(targetIndex);

        if (profile.showHeading !== false) {
            const heading = document.createElement("div");
            heading.className = "pmk-input-helper-heading";
            heading.textContent = language() === "en"
                ? String(profile.headingEn || profile.headingFr || profile.label || "")
                : String(profile.headingFr || profile.headingEn || profile.label || "");
            wrapper.appendChild(heading);
        }

        const groupsWrap = document.createElement("div");
        groupsWrap.className = "pmk-input-helper-groups pmk-input-helper-groups--" +
            (profile.listsLayout === "vertical" ? "vertical" : "horizontal");
        const selections = [];
        activeGroups(profile).forEach(function (group, groupIndex) {
            groupsWrap.appendChild(buildSelect(target, profile, group, groupIndex, selections));
        });
        wrapper.appendChild(groupsWrap);

        if (profile.insertPosition === "before") reference.parentNode.insertBefore(wrapper, reference);
        else reference.parentNode.insertBefore(wrapper, reference.nextSibling);

        ensureHistoricalDefault(target, profile);
        mountContextButton(wrapper, profile);
        return true;
    }

    function clearInjected() {
        document.querySelectorAll("." + WRAPPER_CLASS).forEach(function (node) {
            try { node.remove(); } catch (_) {}
        });
        composeStates = new WeakMap();
    }

    function injectAll() {
        injectScheduled = false;
        clearInjected();

        const profiles = activeProfiles(currentConfig);
        profiles.forEach(function (profile) {
            const targets = safeQueryAll(document, profile.targetSelector);
            targets.forEach(function (target, index) {
                injectProfileForTarget(profile, target, index);
            });
        });
    }

    function scheduleInject() {
        if (injectScheduled) return;
        injectScheduled = true;
        window.requestAnimationFrame(injectAll);
    }

    function mutationIsRelevant(mutation) {
        if (!mutation || mutation.type !== "childList" || !mutation.addedNodes || !mutation.addedNodes.length) return false;
        const profiles = currentConfig && Array.isArray(currentConfig.profiles) ? currentConfig.profiles : [];
        return Array.from(mutation.addedNodes).some(function (node) {
            if (!(node instanceof Element)) return false;
            if (node.closest && node.closest("." + WRAPPER_CLASS)) return false;
            for (let i = 0; i < profiles.length; i += 1) {
                const profile = profiles[i];
                if (!profile || profile.enabled === false) continue;
                const selectors = [profile.targetSelector, profile.anchorSelector].filter(Boolean);
                for (let j = 0; j < selectors.length; j += 1) {
                    try {
                        if (node.matches(selectors[j]) || (node.querySelector && node.querySelector(selectors[j]))) return true;
                    } catch (_) {}
                }
            }
            return false;
        });
    }

    function observeDom() {
        if (observer || !document.documentElement) return;
        observer = new MutationObserver(function (mutations) {
            if (mutations.some(mutationIsRelevant)) scheduleInject();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    function refreshConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULT_CONFIG);
        scheduleInject();
    }

    function profileIndex(path) {
        if (!Array.isArray(path)) return -1;
        const pos = path.indexOf("profiles");
        if (pos < 0) return -1;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function profileAt(root, path) {
        const index = profileIndex(path);
        return root && Array.isArray(root.profiles) && index >= 0 ? root.profiles[index] : null;
    }

    function pageToUrl(path) {
        const raw = String(path || "").trim();
        if (!raw) return window.location.pathname + window.location.search;
        if (/^https?:\/\//i.test(raw)) {
            try {
                const url = new URL(raw);
                return url.pathname + url.search;
            } catch (_) {}
        }
        if (raw.charAt(0) === "/") return raw;
        return "/cgi-bin/koha/" + raw.replace(/^cgi-bin\/koha\//, "");
    }

    function targetUrlForProfile(profile) {
        const pages = profile && Array.isArray(profile.pages) ? profile.pages : [];
        const page = pages.find(function (entry) { return entry && entry.enabled !== false && String(entry.path || "").trim(); }) ||
            pages.find(function (entry) { return entry && String(entry.path || "").trim(); });
        return pageToUrl(page && page.path);
    }

    function applyPickerMetadata(root, path, result) {
        const profile = profileAt(root, path);
        if (!profile || !result) return;
        const key = String(path[path.length - 1] || "");
        if (key === "targetSelector") {
            profile.targetName = String(result.targetName || result.selector || profile.targetName || "");
        } else if (key === "anchorSelector") {
            profile.anchorName = String(result.targetName || result.selector || profile.anchorName || "");
        }
    }

    function pickForProfile(context) {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.pickForConfig !== "function") {
            return Promise.reject(new Error("pmk_common_picker_unavailable"));
        }
        const root = context && context.rootObject ? context.rootObject : {};
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath.slice() : [];
        const profile = profileAt(root, path);
        return picker.pickForConfig({
            moduleId: MODULE_ID,
            targetUrl: targetUrlForProfile(profile),
            rootObject: root,
            fieldPath: path,
            persistAfterPick: false,
            adminContext: { sectionId: "profiles", profileIndex: profileIndex(path) },
            options: {
                bannerText: i18n(
                    "Clique sur l’élément Koha à utiliser — Échap annule",
                    "Click the Koha element to use — Esc cancels"
                )
            }
        });
    }

    function registerPickerAdapter() {
        const picker = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!picker || typeof picker.register !== "function") return false;
        picker.register(MODULE_ID, {
            applyPending: function (draft, pending, picked) {
                applyPickerMetadata(draft, pending && pending.fieldPath || [], picked);
                return draft;
            }
        });
        return true;
    }

    function renderVisualPreview(context) {
        const profile = profileAt(context && context.rootObject, context && context.fieldPath) || LEGACY_017_PROFILE;
        const root = document.createElement("div");
        root.className = "pmk-input-helper";
        root.style.marginTop = "0";
        root.style.maxWidth = "100%";

        if (profile.showHeading !== false) {
            const heading = document.createElement("div");
            heading.className = "pmk-input-helper-heading";
            heading.textContent = language() === "en"
                ? String(profile.headingEn || profile.headingFr || profile.label || "")
                : String(profile.headingFr || profile.headingEn || profile.label || "");
            root.appendChild(heading);
        }

        const groups = document.createElement("div");
        groups.className = "pmk-input-helper-groups pmk-input-helper-groups--" +
            (profile.listsLayout === "vertical" ? "vertical" : "horizontal");
        activeGroups(profile).forEach(function (group) {
            const block = document.createElement("div");
            block.className = "pmk-input-helper-group";
            const label = document.createElement("label");
            label.className = "pmk-input-helper-group-label";
            label.textContent = String(group.label || "");
            if (String(group.labelColor || "").trim()) label.style.color = String(group.labelColor);
            const select = document.createElement("select");
            select.className = "form-select form-select-sm pmk-input-helper-select";
            select.disabled = true;
            const empty = document.createElement("option");
            empty.textContent = String(profile.placeholder || "");
            select.appendChild(empty);
            activeMessages(group).forEach(function (message) {
                const option = document.createElement("option");
                option.textContent = String(message.label || "");
                select.appendChild(option);
            });
            block.appendChild(label);
            block.appendChild(select);
            groups.appendChild(block);
        });
        root.appendChild(groups);
        return root;
    }

    function registerVisualEditorAdapter() {
        const editor = window.PMKConfig && window.PMKConfig.visualEditor;
        if (!editor || typeof editor.register !== "function") return false;
        editor.register(MODULE_ID, {
            capabilities: {
                inlinePreview: true,
                styleEyedropper: false,
                livePreview: true
            },
            renderPreview: renderVisualPreview,
            canPreview: function () {
                return activeProfiles(currentConfig).some(function (profile) {
                    return safeQueryAll(document, profile.targetSelector).length > 0;
                });
            },
            previewDraft: function (draft) {
                const before = clone(currentConfig || DEFAULT_CONFIG);
                const snapshots = [];
                const seen = new Set();
                [before, normalizeConfig(draft || DEFAULT_CONFIG)].forEach(function (cfg) {
                    (cfg.profiles || []).forEach(function (profile) {
                        safeQueryAll(document, profile.targetSelector).forEach(function (target) {
                            if (!target || seen.has(target)) return;
                            seen.add(target);
                            snapshots.push({ target: target, value: target.value });
                        });
                    });
                });

                refreshConfig(draft);
                return function () {
                    refreshConfig(before);
                    snapshots.forEach(function (snapshot) {
                        if (!snapshot.target || !snapshot.target.isConnected) return;
                        snapshot.target.value = snapshot.value;
                        notifyTargetChange(snapshot.target);
                    });
                };
            }
        });
        return true;
    }

    function newPage() {
        return {
            pageId: "custom.page." + Date.now().toString(36),
            enabled: true,
            path: String(window.location.pathname || "").replace(/^\/cgi-bin\/koha\//, "")
        };
    }

    function newMessage() {
        return { enabled: true, label: "", text: "" };
    }

    function newGroup() {
        return { enabled: true, label: "", targetAction: "append", prefix: "", labelColor: "", messages: [] };
    }

    function newProfile() {
        return {
            id: makeId("input-profile"),
            enabled: true,
            label: "Nouvelle aide à la saisie",
            mode: "append",
            pages: [newPage()],
            targetSelector: "",
            targetName: "",
            anchorSelector: "",
            anchorName: "",
            insertPosition: "after",
            showHeading: true,
            headingFr: "Aide à la saisie",
            headingEn: "Input helper",
            placeholder: "Sélectionnez une valeur",
            defaultTextIfEmpty: "",
            preserveManualText: true,
            listsLayout: "horizontal",
            groups: []
        };
    }

    function validate(config) {
        const cfg = normalizeConfig(config);
        const ids = new Set();
        if (!Array.isArray(cfg.profiles)) return { ok: false, message: i18n("La liste des aides à la saisie est invalide.", "The input helper list is invalid.") };
        for (const profile of cfg.profiles) {
            if (!profile.id || ids.has(profile.id)) return { ok: false, message: i18n("Chaque profil doit avoir un identifiant unique.", "Each profile must have a unique identifier.") };
            ids.add(profile.id);
            if (!String(profile.label || "").trim()) return { ok: false, message: i18n("Chaque profil doit avoir un nom.", "Each profile must have a name.") };
            if (!Array.isArray(profile.pages) || !profile.pages.some(function (page) { return String(page && page.path || "").trim(); })) {
                return { ok: false, message: i18n("Chaque profil doit indiquer au moins une page Koha.", "Each profile must specify at least one Koha page.") };
            }
            if (!String(profile.targetSelector || "").trim()) return { ok: false, message: i18n("Chaque profil doit cibler un champ Koha.", "Each profile must target a Koha field.") };
            if (!Array.isArray(profile.groups)) return { ok: false, message: i18n("La liste des groupes est invalide.", "The group list is invalid.") };
            for (const group of profile.groups) {
                if (!group || !String(group.label || "").trim()) return { ok: false, message: i18n("Chaque groupe doit avoir un libellé.", "Each group must have a label.") };
                if (!Array.isArray(group.messages)) return { ok: false, message: i18n("Chaque groupe doit contenir une liste de valeurs valide.", "Each group must contain a valid value list.") };
                for (const message of group.messages) {
                    if (!message || !String(message.label || "").trim()) return { ok: false, message: i18n("Chaque valeur doit avoir un libellé.", "Each value must have a label.") };
                    if (!String(message.text || "").trim()) return { ok: false, message: i18n("Chaque valeur doit avoir un texte à insérer.", "Each value must have insertion text.") };
                }
            }
        }
        return { ok: true };
    }

    function modeOf(root, path) {
        const profile = profileAt(root, path);
        return profile ? profile.mode : "append";
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 4,
            name: { fr: "Ajouter des listes de valeurs prédéfinies pour le remplissage automatique d’un champ", en: "Predefined values for automatic field filling" },
            description: {
                fr: "Ajoute à côté des champs Koha des listes de valeurs prédéfinies permettant de remplir automatiquement le champ sélectionné.",
                en: "Adds predefined-value lists next to Koha fields. Historical modules 017 and 047 are merged here without changing their preset values."
            },
            category: { fr: "Interface / saisie", en: "Interface / input" },
            supportedPages: ["members.moremember", "circ.circulation", "reserve.request"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "profiles",
                    label: { fr: "Aides à la saisie", en: "Input helpers" },
                    description: {
                        fr: "Chaque profil choisit les pages Koha, le champ à alimenter et les listes proposées. Le champ cible et l’emplacement du panneau peuvent être sélectionnés directement sur la page.",
                        en: "Each profile chooses Koha pages, the target field and proposed lists. The target field and panel anchor can be selected directly on the page."
                    },
                    fields: [
                        {
                            key: "profiles",
                            type: "repeater",
                            label: { fr: "Profils", en: "Profiles" },
                            addLabel: { fr: "Ajouter une aide", en: "Add helper" },
                            reorder: true,
                            newItem: newProfile,
                            itemTitle: function (item, index, lang) {
                                return String(item && item.label || "").trim() ||
                                    (lang === "en" ? "Helper " : "Aide ") + (index + 1);
                            },
                            liveTitleKey: "label",
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Profil actif", en: "Profile enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom du profil", en: "Profile name" } },
                                {
                                    key: "mode",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Mode de saisie", en: "Input mode" },
                                    options: [
                                        { value: "append", label: { fr: "Listes simples", en: "Simple lists" } },
                                        { value: "compose", label: { fr: "Listes structurées (préfixes / texte initial)", en: "Structured lists (prefixes / initial text)" } }
                                    ]
                                },
                                {
                                    key: "pages",
                                    type: "repeater",
                                    label: { fr: "Pages Koha", en: "Koha pages" },
                                    addLabel: { fr: "Ajouter une page", en: "Add page" },
                                    reorder: true,
                                    newItem: newPage,
                                    itemTitle: function (item, index) {
                                        return String(item && item.path || "").trim() || "Page " + (index + 1);
                                    },
                                    fields: [
                                        { key: "enabled", type: "boolean", label: { fr: "Active", en: "Enabled" } },
                                        { key: "pageId", type: "text", advanced: true, label: { fr: "Identifiant page", en: "Page identifier" } },
                                        { key: "path", type: "text", label: { fr: "Chemin Koha", en: "Koha path" } }
                                    ]
                                },
                                {
                                    key: "targetSelector",
                                    type: "elementPicker",
                                    label: { fr: "Champ Koha à alimenter", en: "Koha field to fill" },
                                    pickLabel: { fr: "Choisir le champ sur la page", en: "Choose field on page" },
                                    emptyLabel: { fr: "Aucun champ choisi", en: "No field selected" },
                                    allowManual: true,
                                    pick: pickForProfile,
                                    onPick: applyPickerMetadata
                                },
                                { key: "targetName", type: "text", readOnly: true, advanced: true, label: { fr: "Champ détecté", en: "Detected field" } },
                                {
                                    key: "anchorSelector",
                                    type: "elementPicker",
                                    label: { fr: "Emplacement du panneau", en: "Panel anchor" },
                                    pickLabel: { fr: "Choisir l’emplacement sur la page", en: "Choose panel anchor on page" },
                                    emptyLabel: { fr: "Même emplacement que le champ cible", en: "Same as target field" },
                                    allowManual: true,
                                    clearable: true,
                                    pick: pickForProfile,
                                    onPick: applyPickerMetadata,
                                    help: {
                                        fr: "Optionnel. Si vide, le panneau est placé à côté du champ cible.",
                                        en: "Optional. If empty, the panel is placed next to the target field."
                                    }
                                },
                                { key: "anchorName", type: "text", readOnly: true, advanced: true, label: { fr: "Emplacement détecté", en: "Detected anchor" } },
                                {
                                    key: "insertPosition",
                                    type: "select",
                                    label: { fr: "Position du panneau", en: "Panel position" },
                                    options: [
                                        { value: "after", label: { fr: "Après le champ / emplacement", en: "After the field / anchor" } },
                                        { value: "before", label: { fr: "Avant le champ / emplacement", en: "Before the field / anchor" } }
                                    ]
                                },
                                {
                                    key: "listsLayout",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Disposition des listes", en: "List layout" },
                                    options: [
                                        { value: "horizontal", label: { fr: "Les unes à côté des autres", en: "Side by side" } },
                                        { value: "vertical", label: { fr: "Les unes sous les autres", en: "Stacked vertically" } }
                                    ],
                                    help: {
                                        fr: "En mode côte à côte, l’affichage reste responsive : les listes repassent automatiquement les unes sous les autres sur un écran étroit.",
                                        en: "In side-by-side mode, the layout remains responsive: lists automatically stack on narrow screens."
                                    }
                                },
                                { key: "showHeading", type: "boolean", refreshOnChange: true, label: { fr: "Afficher un titre au-dessus des listes", en: "Show a heading above the lists" } },
                                {
                                    key: "headingFr", type: "text",
                                    label: { fr: "Titre — français", en: "Heading — French" },
                                    when: function (root, path) { const p = profileAt(root, path); return Boolean(p && p.showHeading !== false); }
                                },
                                {
                                    key: "headingEn", type: "text",
                                    label: { fr: "Titre — anglais", en: "Heading — English" },
                                    when: function (root, path) { const p = profileAt(root, path); return Boolean(p && p.showHeading !== false); }
                                },
                                { key: "placeholder", type: "text", label: { fr: "Choix vide", en: "Empty choice" } },
                                {
                                    key: "defaultTextIfEmpty",
                                    type: "text",
                                    label: { fr: "Texte initial si le champ est vide", en: "Initial text when the field is empty" },
                                    when: function (root, path) { return modeOf(root, path) === "compose"; }
                                },
                                {
                                    key: "preserveManualText",
                                    type: "boolean",
                                    label: { fr: "Préserver le texte saisi manuellement", en: "Preserve manually entered text" },
                                    when: function (root, path) { return modeOf(root, path) === "compose"; }
                                },
                                { type: "visualPreview", label: { fr: "Aperçu du panneau", en: "Panel preview" } },
                                {
                                    key: "groups",
                                    type: "repeater",
                                    label: { fr: "Listes proposées", en: "Proposed lists" },
                                    addLabel: { fr: "Ajouter une liste", en: "Add list" },
                                    reorder: true,
                                    newItem: newGroup,
                                    itemTitle: function (item, index) {
                                        return String(item && item.label || "").trim() || "Liste " + (index + 1);
                                    },
                                    liveTitleKey: "label",
                                    fields: [
                                        { key: "enabled", type: "boolean", label: { fr: "Liste active", en: "List enabled" } },
                                        { key: "label", type: "text", label: { fr: "Libellé de la liste", en: "List label" } },
                                        {
                                            key: "targetAction",
                                            type: "select",
                                            label: { fr: "Effet du choix sur la zone cible", en: "Effect on target field" },
                                            options: [
                                                { value: "append", label: { fr: "Ajouter au contenu existant", en: "Append to existing content" } },
                                                { value: "replace", label: { fr: "Remplacer tout le contenu", en: "Replace all content" } }
                                            ],
                                            help: {
                                                fr: "Réglage propre à cette liste. Par défaut, une nouvelle liste ajoute son choix. La liste historique « Raison de la réservation: » remplace tout le contenu.",
                                                en: "This setting applies only to this list. New lists append by default. The historical ‘Raison de la réservation:’ list replaces all content."
                                            }
                                        },
                                        {
                                            key: "prefix",
                                            type: "text",
                                            label: { fr: "Préfixe ajouté dans le texte", en: "Prefix added to text" },
                                            when: function (root, path) { return modeOf(root, path) === "compose"; }
                                        },
                                        {
                                            key: "labelColor",
                                            type: "text",
                                            advanced: true,
                                            label: { fr: "Couleur du libellé", en: "Label color" }
                                        },
                                        {
                                            key: "messages",
                                            type: "repeater",
                                            label: { fr: "Valeurs", en: "Values" },
                                            addLabel: { fr: "Ajouter une valeur", en: "Add value" },
                                            reorder: true,
                                            newItem: newMessage,
                                            itemTitle: function (item, index) {
                                                return String(item && item.label || "").trim() || "Valeur " + (index + 1);
                                            },
                                            liveTitleKey: "label",
                                            fields: [
                                                { key: "enabled", type: "boolean", label: { fr: "Valeur active", en: "Value enabled" } },
                                                { key: "label", type: "text", label: { fr: "Libellé dans la liste", en: "Label in the list" } },
                                                {
                                                    key: "text",
                                                    type: "textarea",
                                                    label: { fr: "Texte inséré", en: "Inserted text" },
                                                    help: {
                                                        fr: "Le texte est utilisé exactement tel qu’il est saisi.",
                                                        en: "The text is used exactly as entered."
                                                    }
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main) {
                if (!main) return;
                const section = main.querySelector('[data-pmk-section-id="profiles"]');
                if (!section) return;
                window.setTimeout(function () {
                    section.scrollIntoView({ block: "start", behavior: "smooth" });
                }, 0);
            }
        };
    }

    function registerDefinition() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        window.PMKConfig.registerModule(moduleDefinition());
        return true;
    }

    async function loadConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            refreshConfig(DEFAULT_CONFIG);
            return;
        }
        try {
            const config = await window.PMKConfig.getConfig(MODULE_ID);
            refreshConfig(config);
        } catch (_) {
            refreshConfig(DEFAULT_CONFIG);
        }

        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, refreshConfig);
        }
    }

    function start() {
        injectStyles();
        registerDefinition();
        registerPickerAdapter();
        registerVisualEditorAdapter();
        observeDom();
        loadConfig();
        scheduleInject();

        document.addEventListener("shown.bs.modal", scheduleInject);
        document.addEventListener("click", function (event) {
            const button = event.target.closest && event.target.closest("#toolbar_addnewmessageLabel");
            if (button) window.requestAnimationFrame(scheduleInject);
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }

    window.addEventListener("pmk:config-ready", function () {
        registerDefinition();
        registerPickerAdapter();
        registerVisualEditorAdapter();
        loadConfig();
    });

    const publicApi = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        refresh: scheduleInject,
        defaults: clone(DEFAULT_CONFIG),
        normalize: normalizeConfig
    };

    window.PMK017MessageTemplates = publicApi;
    window.PMK017InputHelpers = publicApi;
})();

;window.PMKNonPlugin.loaded.push("017-gestion-litiges-select.js");
} catch (error) { window.PMKNonPlugin.errors.push("017-gestion-litiges-select.js: "+error.message); console.error("[PMK] 017-gestion-litiges-select.js",error); };
