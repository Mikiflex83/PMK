/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.titles;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 095-page-title-enhancements.js
 Dépendances: KOHA_UTILS.waitFor (fallback included)
 Date de dernière modification: 2026-02-21
 Auteur: équipe PimpMyKoha
 Description: Améliore les titres de page pour `detail.pl` et `search.pl`.
*/

(function(){
  'use strict';
  try{
    (function(){})('095-page-title-enhancements: loaded');
    const waitFor = (selector, timeout) => {
      if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === 'function') return window.KOHA_UTILS.waitFor(selector, timeout);
      return new Promise((resolve, reject) => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        const obs = new MutationObserver(() => { const found = document.querySelector(selector); if (found) { obs.disconnect(); resolve(found); } });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        setTimeout(() => { obs.disconnect(); reject(new Error('timeout')); }, timeout || 3000);
      });
    };

    if (window.location.pathname && window.location.pathname.includes('/detail.pl')){
      waitFor('.biblio_header h1', 3000).then(h => { try{ if (h) document.title = `${(h.textContent||'').trim()} — ${options.suffix}`; }catch(e){ (function(){})('095: set title failed', e); } }).catch(()=>{});
    }

    if (window.location.pathname && window.location.pathname.includes('/search.pl')){
      waitFor('.result, body', 2000).then(() => {
        try{
          const results = document.querySelectorAll('.result').length;
          const q = new URLSearchParams(location.search).get('q') || '';
          if (q) document.title = `Recherche pour « ${q} » — ${options.suffix}`;
        }catch(e){ (function(){})('095: set search title failed', e); }
      }).catch(()=>{});
    }

  }catch(e){ (function(){})('095-page-title-enhancements: failed', e); }
})();

})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("095-page-title-enhancements.js");
} catch (error) { window.PMKNonPlugin.errors.push("095-page-title-enhancements.js: "+error.message); console.error("[PMK] 095-page-title-enhancements.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.tree;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 097-extract-tree-content-page-114.js
 Dépendances: KOHA_UTILS.waitFor (fallback included)
 Date de dernière modification: 2026-02-21
 Auteur: équipe PimpMyKoha
 Description: Transforme l'arborescence sur la page `page_id=114` en panneau collapsable.
*/

(function(){
  'use strict';
  try{
    (function(){})('097-extract-tree-content-page-114: loaded');
    const pageId = new URLSearchParams(location.search).get('page_id'); if (pageId !== String(options.pageId)) return;

    const waitFor = (selector, timeout) => {
      if (window.KOHA_UTILS && typeof window.KOHA_UTILS.waitFor === 'function') return window.KOHA_UTILS.waitFor(selector, timeout);
      return new Promise((resolve, reject) => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        const obs = new MutationObserver(() => { const found = document.querySelector(selector); if (found) { obs.disconnect(); resolve(found); } });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        setTimeout(() => { obs.disconnect(); reject(new Error('timeout')); }, timeout || 3000);
      });
    };

    waitFor(options.target, 3000).then(tree => {
      try{
        if (!tree) return;
        tree.querySelectorAll('li').forEach(li => { const a = li.querySelector('a'); if (a && a.nextElementSibling && a.nextElementSibling.tagName === 'UL'){ a.style.cursor='pointer'; a.addEventListener('click', function(e){ e.preventDefault(); this.nextElementSibling.classList.toggle('collapsed'); }); a.nextElementSibling.classList.add('collapsed'); } });

        const header = document.createElement('div'); header.className='panel panel-default'; header.innerHTML = '<div class="panel-heading"><strong>Arborescence extraite</strong></div>';
        if (tree.parentNode) tree.parentNode.insertBefore(header, tree);
        header.appendChild(tree);
      }catch(e){ (function(){})('097: tree processing failed', e); }
    }).catch(()=>{});

  }catch(e){ (function(){})('097-extract-tree-content-page-114: failed', e); }
})();

})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("097-extract-tree-content-page-114.js");
} catch (error) { window.PMKNonPlugin.errors.push("097-extract-tree-content-page-114.js: "+error.message); console.error("[PMK] 097-extract-tree-content-page-114.js",error); };
try {
/*
 Nom du fichier: 098-age-calculation-member-detail.js
 Version: 3.0.0-pmk-isolated
 Date de dernière modification: 2026-09-22
 Auteur: équipe PimpMyKoha
 Module PMK: patron-age-display

 Description:
   Personnalise l'affichage de l'âge d'un lecteur à partir de sa date de naissance.

   Pages prises en charge :
   - /cgi-bin/koha/members/moremember.pl
   - /cgi-bin/koha/circ/circulation.pl
   - /cgi-bin/koha/members/memberentry.pl

   Principes :
   - conserve l'élément natif Koha .age_years lorsqu'il existe ;
   - ne casse pas le module 049 (signe astrologique), qui s'appuie sur ce même élément ;
   - propose années / années+mois / années+mois+jours ;
   - aperçu dynamique sur memberentry.pl ;
   - configuration PMKConfig avec valeurs locales de secours ;
   - FR / EN ;
   - idempotent et sans dépendance externe.
*/
(function () {
    "use strict";

    const MODULE_ID = "patron-age-display";
    const VERSION = "3.2.0-pmk-custom-pages";
    const SCRIPT_GUARD = "__pmk098PatronAgeDisplayV3";
    const GENERATED_ATTR = "data-pmk098-generated";
    const ACTIVE_ATTR = "data-pmk098-age-display";
    const ORIGINAL_ATTR = "data-pmk098-original-text";

    const PAGE_DEFS = {
        moremember: {
            id: "members.moremember",
            path: "/cgi-bin/koha/members/moremember.pl"
        },
        circulation: {
            id: "circ.circulation",
            path: "/cgi-bin/koha/circ/circulation.pl"
        },
        memberentry: {
            id: "members.memberentry",
            path: "/cgi-bin/koha/members/memberentry.pl"
        }
    };

    const DEFAULTS = {
        enabled: true,
        format: "years",
        language: "auto",
        parentheses: true,
        additionalPaths: "",
        pages: {
            moremember: { enabled: true },
            circulation: { enabled: true },
            memberentry: { enabled: true }
        }
    };

    if (window[SCRIPT_GUARD]) return;
    if (window.PMK098LegacyRuntime && typeof window.PMK098LegacyRuntime.destroy === 'function') window.PMK098LegacyRuntime.destroy();
    window[SCRIPT_GUARD] = true;

    let currentConfig = clone(DEFAULTS);
    let observer = null;
    let refreshQueued = false;
    let dateInput = null;
    let dateInputHandler = null;
    let configRevision = 0;
    let unsubscribeConfig = null;
    let pmkConnectTimer = null;
    let disposed = false;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function merge(base, extra) {
        const out = clone(base);
        if (!isObject(extra)) return out;
        Object.keys(extra).forEach(function (key) {
            if (isObject(extra[key]) && isObject(out[key])) out[key] = merge(out[key], extra[key]);
            else if (extra[key] !== undefined) out[key] = clone(extra[key]);
        });
        return out;
    }

    function normalizeConfig(config) {
        const value = merge(DEFAULTS, config || {});
        value.enabled = value.enabled !== false;
        if (!["years", "years_months", "years_months_days"].includes(value.format)) {
            value.format = DEFAULTS.format;
        }
        if (!["auto", "fr", "en"].includes(value.language)) value.language = DEFAULTS.language;
        value.parentheses = value.parentheses !== false;
        value.pages = merge(DEFAULTS.pages, value.pages || {});
        Object.keys(DEFAULTS.pages).forEach(function (key) {
            value.pages[key].enabled = value.pages[key].enabled !== false;
        });
        return value;
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function languageOf(config) {
        if (config.language === "fr" || config.language === "en") return config.language;
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try {
                const lang = String(api.getLanguage() || "").toLowerCase();
                if (lang.startsWith("en")) return "en";
                if (lang.startsWith("fr")) return "fr";
            } catch (_) {}
        }
        return String(document.documentElement.lang || "").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function pathAllowed(value) {
        if (typeof value !== "string" || !value.startsWith("/cgi-bin/koha/")) return false;
        if (/[?#\\*]/.test(value) || value.includes("..") || /\s/.test(value)) return false;
        return /^\/cgi-bin\/koha\/[a-z0-9_/-]+\.pl$/i.test(value);
    }

    function additionalPaths(config) {
        return String(config.additionalPaths || "").split(/[\n,;]+/)
            .map(function (path) { return path.trim(); })
            .filter(pathAllowed);
    }

    function isCustomPage(config) {
        return additionalPaths(config).includes(window.location.pathname || "");
    }

    function currentPageKey() {
        const path = window.location.pathname || "";
        return Object.keys(PAGE_DEFS).find(function (key) {
            return path === PAGE_DEFS[key].path;
        }) || "";
    }

    function pageEnabled(config) {
        const key = currentPageKey();
        return Boolean((key && config.pages && config.pages[key] && config.pages[key].enabled !== false) || isCustomPage(config));
    }

    function normaliseSpaces(value) {
        return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    }

    function makeDate(year, month, day) {
        year = Number(year);
        month = Number(month);
        day = Number(day);
        if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
        if (year < 1800 || year > 2200 || month < 1 || month > 12 || day < 1 || day > 31) return null;
        const date = new Date(Date.UTC(year, month - 1, day));
        if (
            date.getUTCFullYear() !== year ||
            date.getUTCMonth() !== month - 1 ||
            date.getUTCDate() !== day
        ) return null;
        return date;
    }

    function parseDate(value) {
        const text = normaliseSpaces(value);
        let match = text.match(/(?:^|\D)(\d{4})-(\d{1,2})-(\d{1,2})(?:\D|$)/);
        if (match) return makeDate(match[1], match[2], match[3]);

        match = text.match(/(?:^|\D)(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})(?:\D|$)/);
        if (match) return makeDate(match[3], match[2], match[1]);
        return null;
    }

    function daysInMonthUtc(year, monthZeroBased) {
        return new Date(Date.UTC(year, monthZeroBased + 1, 0)).getUTCDate();
    }

    function addYearsClamped(date, years) {
        const year = date.getUTCFullYear() + years;
        const month = date.getUTCMonth();
        const day = Math.min(date.getUTCDate(), daysInMonthUtc(year, month));
        return new Date(Date.UTC(year, month, day));
    }

    function addMonthsClamped(date, months) {
        const raw = date.getUTCMonth() + months;
        const year = date.getUTCFullYear() + Math.floor(raw / 12);
        const month = ((raw % 12) + 12) % 12;
        const day = Math.min(date.getUTCDate(), daysInMonthUtc(year, month));
        return new Date(Date.UTC(year, month, day));
    }

    function todayUtc() {
        const now = new Date();
        return new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
    }

    function calculateAgeParts(birth) {
        const today = todayUtc();
        if (!birth || birth.getTime() > today.getTime()) return null;

        let years = today.getUTCFullYear() - birth.getUTCFullYear();
        let afterYears = addYearsClamped(birth, years);
        if (afterYears.getTime() > today.getTime()) {
            years--;
            afterYears = addYearsClamped(birth, years);
        }

        let months = 0;
        while (months < 11) {
            const candidate = addMonthsClamped(afterYears, months + 1);
            if (candidate.getTime() > today.getTime()) break;
            months++;
        }

        const afterMonths = addMonthsClamped(afterYears, months);
        const days = Math.floor((today.getTime() - afterMonths.getTime()) / 86400000);

        if (years < 0 || years > 130 || months < 0 || months > 11 || days < 0 || days > 31) return null;
        return { years: years, months: months, days: days };
    }

    function unit(value, singular, plural) {
        return value + " " + (value === 1 ? singular : plural);
    }

    function formatAge(parts, config) {
        const lang = languageOf(config);
        let chunks;

        if (lang === "en") {
            chunks = [unit(parts.years, "year", "years")];
            if (config.format !== "years") chunks.push(unit(parts.months, "month", "months"));
            if (config.format === "years_months_days") chunks.push(unit(parts.days, "day", "days"));
        } else {
            chunks = [unit(parts.years, "an", "ans")];
            if (config.format !== "years") chunks.push(unit(parts.months, "mois", "mois"));
            if (config.format === "years_months_days") chunks.push(unit(parts.days, "jour", "jours"));
        }

        const text = chunks.join(" ");
        return config.parentheses ? "(" + text + ")" : text;
    }

    function rememberOriginal(span) {
        if (!span || span.hasAttribute(ORIGINAL_ATTR)) return;
        span.setAttribute(ORIGINAL_ATTR, span.textContent || "");
    }

    function restoreExistingSpans() {
        document.querySelectorAll('.age_years[' + ACTIVE_ATTR + '="1"]').forEach(function (span) {
            if (span.hasAttribute(ORIGINAL_ATTR)) {
                span.textContent = span.getAttribute(ORIGINAL_ATTR) || "";
                span.removeAttribute(ORIGINAL_ATTR);
            }
            span.removeAttribute(ACTIVE_ATTR);
            span.removeAttribute("data-pmk098-age-years");
            span.removeAttribute("data-pmk098-version");
        });
    }

    function removeGenerated() {
        document.querySelectorAll('[' + GENERATED_ATTR + '="1"]').forEach(function (node) {
            node.remove();
        });
    }

    function birthFromContainer(container) {
        if (!container) return null;
        const cloneNode = container.cloneNode(true);
        cloneNode.querySelectorAll('.age_years, [data-koha-astro-sign], .pmk-astro049-sign, .pmk-context-config').forEach(function (el) {
            el.remove();
        });
        return parseDate(cloneNode.textContent || "");
    }

    function birthForAgeSpan(span) {
        if (!span) return null;

        const container = span.closest("li, dd, .patrondateofbirth, .form-group, .form-row");
        const fromContainer = birthFromContainer(container);
        if (fromContainer) return fromContainer;

        let node = span.previousSibling;
        let hops = 0;
        while (node && hops < 8) {
            const parsed = parseDate(node.textContent || "");
            if (parsed) return parsed;
            node = node.previousSibling;
            hops++;
        }
        return null;
    }

    function renderNativeAgeSpans(config) {
        let count = 0;
        document.querySelectorAll(".age_years").forEach(function (span) {
            if (span.getAttribute(GENERATED_ATTR) === "1") return;
            const birth = birthForAgeSpan(span);
            const parts = calculateAgeParts(birth);
            if (!parts) return;

            const wanted = formatAge(parts, config);
            rememberOriginal(span);
            if ((span.textContent || "") !== wanted) span.textContent = wanted;
            span.setAttribute(ACTIVE_ATTR, "1");
            span.setAttribute("data-pmk098-age-years", String(parts.years));
            span.setAttribute("data-pmk098-version", VERSION);
            count++;
        });
        return count;
    }

    function findDateInput() {
        return document.querySelector(
            '#dateofbirth, input[name="dateofbirth"], input[name="borrower_dateofbirth"], input[data-patron-field="dateofbirth"]'
        );
    }

    function renderMemberEntryPreview(config) {
        const input = findDateInput();
        if (!input) return 0;

        const birth = parseDate(input.value || input.getAttribute("value") || "");
        const parts = calculateAgeParts(birth);
        let preview = document.querySelector('.pmk098-age-preview[' + GENERATED_ATTR + '="1"]');

        if (!parts) {
            if (preview) preview.hidden = true;
            return 0;
        }

        if (!preview) {
            preview = document.createElement("span");
            preview.className = "age_years pmk098-age-preview";
            preview.setAttribute(GENERATED_ATTR, "1");
            preview.setAttribute(ACTIVE_ATTR, "1");
            preview.setAttribute("data-pmk098-version", VERSION);
            preview.style.marginInlineStart = ".5rem";
            input.insertAdjacentElement("afterend", preview);
        }

        preview.textContent = formatAge(parts, config);
        preview.setAttribute("data-pmk098-age-years", String(parts.years));
        preview.hidden = false;
        return 1;
    }

    function bindDateInput() {
        const input = findDateInput();
        if (!input || input === dateInput) return;

        unbindDateInput();
        dateInput = input;
        dateInputHandler = function () { scheduleRefresh(); };
        input.addEventListener("input", dateInputHandler);
        input.addEventListener("change", dateInputHandler);
    }

    function unbindDateInput() {
        if (dateInput && dateInputHandler) {
            dateInput.removeEventListener("input", dateInputHandler);
            dateInput.removeEventListener("change", dateInputHandler);
        }
        dateInput = null;
        dateInputHandler = null;
    }

    function mountConfigShortcut() {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;

        const pageKey = currentPageKey();
        let anchor = null;

        if (pageKey === "moremember" || pageKey === "circulation") {
            anchor = document.querySelector("#patron-information .patroninfo-heading, #patron-information h2, .patroninfo-heading");
        } else if (pageKey === "memberentry") {
            anchor = document.querySelector("#memberentry_identity legend, #memberentry_identity h2, #memberentry_identity");
        }
        if (!anchor) return;

        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: PAGE_DEFS[pageKey].id,
                context: {
                    sectionId: "format",
                    pageId: PAGE_DEFS[pageKey].id
                }
            });
        } catch (_) {}
    }

    function cleanup() {
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        unbindDateInput();
        restoreExistingSpans();
        removeGenerated();
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config);

        if (!currentConfig.enabled || !pageEnabled(currentConfig)) {
            cleanup();
            return;
        }

        const pageKey = currentPageKey();
        if (!pageKey && !isCustomPage(currentConfig)) return;

        if (pageKey === "memberentry") {
            bindDateInput();
            renderMemberEntryPreview(currentConfig);
        } else {
            renderNativeAgeSpans(currentConfig);
        }

        mountConfigShortcut();
        ensureObserver();
    }

    function refresh() {
        if (!currentConfig.enabled || !pageEnabled(currentConfig)) return;
        const pageKey = currentPageKey();
        if (pageKey === "memberentry") {
            bindDateInput();
            renderMemberEntryPreview(currentConfig);
        } else {
            renderNativeAgeSpans(currentConfig);
        }
        mountConfigShortcut();
    }

    function scheduleRefresh() {
        if (refreshQueued) return;
        refreshQueued = true;
        window.requestAnimationFrame(function () {
            refreshQueued = false;
            refresh();
        });
    }

    function ensureObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                if (mutation.type !== "childList") return false;
                return Array.from(mutation.addedNodes || []).some(function (node) {
                    if (!node || node.nodeType !== 1) return false;
                    return (
                        node.matches && node.matches(".age_years, #dateofbirth, [name=dateofbirth]")
                    ) || (
                        node.querySelector && node.querySelector(".age_years, #dateofbirth, [name=dateofbirth]")
                    );
                });
            });
            if (relevant) scheduleRefresh();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function connectPmkConfig(attempt) {
        attempt = attempt || 0;
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            if (attempt < 40) {
                pmkConnectTimer = window.setTimeout(function () {
                    pmkConnectTimer = null;
                    if (!disposed) connectPmkConfig(attempt + 1);
                }, 100);
                return;
            }
            applyConfig(DEFAULTS);
            return;
        }

        mountConfigShortcut();

        try {
            if (typeof api.subscribe === "function") {
                const unsub = api.subscribe(MODULE_ID, function (config) {
                    if (disposed) return;
                    configRevision++;
                    applyConfig(config);
                });
                if (typeof unsub === "function") unsubscribeConfig = unsub;
            }
        } catch (_) {}

        const revisionAtRead = configRevision;
        Promise.resolve(api.getConfig(MODULE_ID))
            .then(function (config) { if (!disposed && revisionAtRead === configRevision) applyConfig(config); })
            .catch(function () { if (!disposed && revisionAtRead === configRevision) applyConfig(DEFAULTS); });
    }

    function destroy() {
        disposed = true;
        if (pmkConnectTimer) window.clearTimeout(pmkConnectTimer);
        if (typeof unsubscribeConfig === "function") unsubscribeConfig();
        cleanup();
        delete window[SCRIPT_GUARD];
    }

    function start() {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", function () {
                connectPmkConfig(0);
            }, { once: true });
        } else {
            connectPmkConfig(0);
        }
    }

    window.PMK098PatronAgeDisplay = {
        version: VERSION,
        moduleId: MODULE_ID,
        refresh: scheduleRefresh,
        destroy: destroy,
        getConfig: function () { return clone(currentConfig); }
    };

    start();
})();

;window.PMKNonPlugin.loaded.push("098-age-calculation-member-detail.js");
} catch (error) { window.PMKNonPlugin.errors.push("098-age-calculation-member-detail.js: "+error.message); console.error("[PMK] 098-age-calculation-member-detail.js",error); };
try {
(function () {
  'use strict';

  const KT = window.KohaTools;
  if (!KT || !KT.Config) return;

  const MODULE_ID = 'patron-age-display';
  const CFG = KT.Config.getCanonical(MODULE_ID);
  const Scope = KT.getService && KT.getService('scope');

  if (!CFG || !CFG.enabled || !['shadow', 'live'].includes(CFG.mode)) return;
  if (Scope && !Scope.match(CFG.general && CFG.general.scope).ok) return;

  const runtime = {
    id: MODULE_ID,
    description: 'Personnalise l’âge affiché par Koha depuis la date de naissance, avec choix entre années, années + mois ou années + mois + jours.',
    sourceFiles: ['098-age-calculation-member-detail.js'],
    parity: 'adapted-current-koha',
    reloadRequiredOnConfigChange: true,

    init: function () {
      if (window.PMKConfig || window.PMK098PatronAgeDisplay) return;
      if (window['__KT_PARITY_' + MODULE_ID]) return;
      window['__KT_PARITY_' + MODULE_ID] = true;

      const path = window.location.pathname || '';
      const isMoremember = /\/members\/moremember\.pl$/.test(path);
      const isMemberentry = /\/members\/memberentry\.pl$/.test(path);
      const isMemberdetails = /\/members\/memberdetails\.pl$/.test(path);

      if (!isMoremember && !isMemberentry && !isMemberdetails) return;

      const state = {
        generated: [],
        modified: [],
        boundInputs: []
      };

      function record(level, kind, extra) {
        if (typeof KT.record === 'function') {
          KT.record(Object.assign({ module: MODULE_ID, level: level, kind: kind }, extra || {}));
        }
      }

      function normaliseSpaces(value) {
        return String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      }

      function parseDate(value) {
        if(window.PMKDates)return window.PMKDates.parse(value);
        const text = normaliseSpaces(value);
        let m;

        // Formats Koha les plus courants : JJ/MM/AAAA, JJ-MM-AAAA, AAAA-MM-JJ.
        m = text.match(/(?:^|\D)(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})(?:\D|$)/);
        if (m) {
          return validDate(parseInt(m[3], 10), parseInt(m[2], 10), parseInt(m[1], 10));
        }

        m = text.match(/(?:^|\D)(\d{4})-(\d{1,2})-(\d{1,2})(?:\D|$)/);
        if (m) {
          return validDate(parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10));
        }

        return null;
      }

      function validDate(year, month, day) {
        if (!year || !month || !day || year < 1800 || year > 2200 || month < 1 || month > 12 || day < 1 || day > 31) {
          return null;
        }
        const d = new Date(year, month - 1, day);
        if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
        return d;
      }

      function calculateAge(birth, now) {
        now = now || new Date();
        let age = now.getFullYear() - birth.getFullYear();
        const monthDelta = now.getMonth() - birth.getMonth();
        if (monthDelta < 0 || (monthDelta === 0 && now.getDate() < birth.getDate())) age--;
        return age >= 0 && age <= 130 ? age : null;
      }

      function ageText(age) {
        const lang = String(document.documentElement.lang || '').toLowerCase();
        if (lang.indexOf('en') === 0) return '(' + age + ' years)';
        return '(' + age + ' ans)';
      }

      function rememberOriginal(span) {
        if (!span || span.dataset.pmk098OriginalText !== undefined) return;
        span.dataset.pmk098OriginalText = span.textContent || '';
        state.modified.push(span);
      }

      function updateExistingAgeSpan(span, birth) {
        if (!span || !birth) return false;
        const age = calculateAge(birth);
        if (age === null) return false;

        rememberOriginal(span);

        // Important : on conserve LE MÊME élément .age_years.
        // Le module 049 y attache ses classes, attributs et événements.
        span.textContent = ageText(age);
        span.dataset.pmk098AgeDisplay = '1';
        span.dataset.pmk098Age = String(age);
        return true;
      }

      function makeGeneratedAge(birth) {
        const age = calculateAge(birth);
        if (age === null) return null;

        const span = document.createElement('span');
        span.className = 'age_years pmk098-age-display';
        span.dataset.pmk098Generated = '1';
        span.dataset.pmk098AgeDisplay = '1';
        span.dataset.pmk098Age = String(age);
        span.style.marginLeft = '8px';
        span.style.color = '#555';
        span.textContent = ageText(age);
        state.generated.push(span);
        return span;
      }

      function textWithoutAgeAndAstro(container) {
        if (!container) return '';
        const clone = container.cloneNode(true);
        clone.querySelectorAll('.age_years, [data-koha-astro-sign="1"], .pmk-astro049-sign').forEach(function (el) {
          el.remove();
        });
        return normaliseSpaces(clone.textContent || '');
      }

      function birthFromAgeSpan(span) {
        if (!span) return null;

        const row = span.closest('li, dd, .form-group, .form-row, .rows, .patroninfo-section');
        if (row) {
          const parsed = parseDate(textWithoutAgeAndAstro(row));
          if (parsed) return parsed;
        }

        let node = span.previousSibling;
        let hops = 0;
        while (node && hops < 6) {
          const parsed = parseDate(node.textContent || '');
          if (parsed) return parsed;
          node = node.previousSibling;
          hops++;
        }
        return null;
      }

      function labelLooksLikeDob(text) {
        return /date\s+de\s+naissance|date\s+of\s+birth|birth\s*date|birthdate/i.test(normaliseSpaces(text));
      }

      function findDobRows() {
        const rows = [];

        document.querySelectorAll('li, dt, label, .form-group, .form-row').forEach(function (node) {
          if (!labelLooksLikeDob(node.textContent || '')) return;

          let container = node;
          if (node.tagName === 'DT' && node.nextElementSibling) container = node.nextElementSibling;
          else if (node.tagName === 'LABEL') container = node.closest('li, .form-group, .form-row') || node.parentElement;

          if (container && rows.indexOf(container) === -1) rows.push(container);
        });

        return rows;
      }

      function applyMoremember() {
        let applied = 0;
        const spans = Array.from(document.querySelectorAll('.age_years'));

        spans.forEach(function (span) {
          const birth = birthFromAgeSpan(span);
          if (birth && updateExistingAgeSpan(span, birth)) applied++;
        });

        // Fallback : si Koha n'affiche plus .age_years mais garde la date de naissance,
        // on ajoute l'âge sans toucher au reste du contenu.
        if (!spans.length) {
          findDobRows().forEach(function (row) {
            const birth = parseDate(textWithoutAgeAndAstro(row));
            if (!birth || row.querySelector('.age_years')) return;
            const span = makeGeneratedAge(birth);
            if (span) {
              row.appendChild(document.createTextNode(' '));
              row.appendChild(span);
              applied++;
            }
          });
        }

        return applied;
      }

      function findDobInput() {
        return document.querySelector(
          '#dateofbirth, input[name="dateofbirth"], input[name="borrower_dateofbirth"], input[data-patron-field="dateofbirth"]'
        );
      }

      function ensureInputAge(input) {
        if (!input) return 0;
        const birth = parseDate(input.value || input.getAttribute('value') || '');
        const host = input.closest('li, .form-group, .form-row') || input.parentElement;
        if (!host) return 0;

        let span = host.querySelector('.pmk098-age-display[data-pmk098-generated="1"]');

        if (!birth) {
          if (span) span.hidden = true;
          return 0;
        }

        const age = calculateAge(birth);
        if (age === null) {
          if (span) span.hidden = true;
          return 0;
        }

        if (!span) {
          span = makeGeneratedAge(birth);
          if (!span) return 0;
          input.insertAdjacentElement('afterend', span);
        } else {
          span.textContent = ageText(age);
          span.dataset.pmk098Age = String(age);
        }

        span.hidden = false;
        return 1;
      }

      function bindInput(input) {
        if (!input || input.dataset.pmk098Bound === '1') return;
        input.dataset.pmk098Bound = '1';
        const handler = function () { ensureInputAge(input); };
        input.addEventListener('input', handler);
        input.addEventListener('change', handler);
        state.boundInputs.push({ input: input, handler: handler });
      }

      function applyMemberentry() {
        const input = findDobInput();
        if (!input) return 0;
        bindInput(input);
        return ensureInputAge(input);
      }

      function applyMemberdetails() {
        let applied = 0;

        document.querySelectorAll('.age_years').forEach(function (span) {
          const birth = birthFromAgeSpan(span);
          if (birth && updateExistingAgeSpan(span, birth)) applied++;
        });

        if (applied) return applied;

        findDobRows().forEach(function (row) {
          const birth = parseDate(textWithoutAgeAndAstro(row));
          if (!birth || row.querySelector('.age_years')) return;
          const span = makeGeneratedAge(birth);
          if (!span) return;
          row.appendChild(document.createTextNode(' '));
          row.appendChild(span);
          applied++;
        });

        return applied;
      }

      function apply() {
        let applied = 0;
        if (isMoremember) applied = applyMoremember();
        else if (isMemberentry) applied = applyMemberentry();
        else if (isMemberdetails) applied = applyMemberdetails();

        record('info', 'patron-age-applied', {
          path: path,
          targets: applied
        });
      }

      // Koha peut finir certains blocs après DOMContentLoaded : une passe immédiate,
      // puis une seconde très courte suffit sans observer toute la page en continu.
      apply();
      window.setTimeout(apply, 250);

      runtime._state = state;
    },

    destroy: function () {
      const state = runtime._state;
      if (!state) return true;

      state.boundInputs.forEach(function (entry) {
        entry.input.removeEventListener('input', entry.handler);
        entry.input.removeEventListener('change', entry.handler);
        delete entry.input.dataset.pmk098Bound;
      });

      state.generated.forEach(function (el) {
        if (el && el.parentNode) el.remove();
      });

      state.modified.forEach(function (span) {
        if (!span) return;
        if (span.dataset.pmk098OriginalText !== undefined) {
          span.textContent = span.dataset.pmk098OriginalText;
          delete span.dataset.pmk098OriginalText;
        }
        delete span.dataset.pmk098AgeDisplay;
        delete span.dataset.pmk098Age;
      });

      runtime._state = null;
      delete window['__KT_PARITY_' + MODULE_ID];
      return true;
    },

    onConfigChange: function () {
      return { reloadRequired: true };
    }
  };

  window.PMK098LegacyRuntime = runtime;
  window.PMK098LegacyConfiguration = JSON.parse(JSON.stringify(CFG));
  KT.registerModule(runtime);

  if (CFG.mode === 'shadow') {
    if (typeof KT.record === 'function') {
      KT.record({
        module: MODULE_ID,
        level: 'info',
        kind: 'shadow-current-koha-adaptation',
        sources: runtime.sourceFiles
      });
    }
    return;
  }

  runtime.init();
})();

;window.PMKNonPlugin.loaded.push("098-patron-age-display.js");
} catch (error) { window.PMKNonPlugin.errors.push("098-patron-age-display.js: "+error.message); console.error("[PMK] 098-patron-age-display.js",error); };
try {
/* ============================================================
   099-efficiency-indicators.js
   Version : 3.0.0-pmk-isolated
   Date : 2026-09-20
   Auteur historique : équipe PimpMyKoha

   Indicateurs d'efficacité des exemplaires et des notices.

   Refonte préparatoire PimpMyKoha :
   - aucune dépendance obligatoire à 129 ;
   - API Koha comme source principale ;
   - fonctionnement autonome sur detail.pl et search.pl ;
   - conservation des icônes historiques : 👑 🔥 ✅ ⚠️ 🛏️ ❌ ;
   - conservation du calcul historique et de ses valeurs par défaut ;
   - domaines, localisations, pondérations, seuils et couleurs configurables ;
   - 099$a utilisé par défaut comme source MARC du domaine ;
   - page d'aide historique reconstruite dynamiquement depuis la configuration ;
   - aucun délai fixe de 5 secondes ;
   - idempotent et compatible avec les redraw DataTables de detail.pl.
   ============================================================ */
(function () {
    "use strict";

    const MODULE_ID = "efficiency-indicators";
    const MODULE_VERSION = "3.0.0";
    const GLOBAL_GUARD = "__PMK_099_EFFICIENCY_V3__";
    const DETAIL_PATH = "/cgi-bin/koha/catalogue/detail.pl";
    const SEARCH_PATH = "/cgi-bin/koha/catalogue/search.pl";
    const STYLE_ID = "pmk-099-efficiency-style";
    const HELP_CLASS = "pmk-099-help-link";
    const ITEM_INDICATOR_CLASS = "pmk-099-item-indicator";
    const GLOBAL_INDICATOR_CLASS = "global-efficiency-indicator"; // classe historique conservée
    const GLOBAL_OWN_CLASS = "pmk-099-global-indicator";
    const DONE_ATTR = "data-pmk099-done";

    if (window[GLOBAL_GUARD]) return;
    window[GLOBAL_GUARD] = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        config: null,
        itemCache: new Map(),
        itemCoverage: new Map(),
        marcCache: new Map(),
        biblioCache: new Map(),
        running: false,
        refreshTimer: null
    };

    const state = window[GLOBAL_GUARD];

    const ICONS = Object.freeze({
        exceptional: "👑",
        excellent: "🔥",
        good: "✅",
        medium: "⚠️",
        dormant: "🛏️",
        low: "❌"
    });

    const DEFAULTS = {
        enabled: true,
        language: "auto",
        pages: {
            detail: { enabled: true, path: DETAIL_PATH },
            search: { enabled: true, path: SEARCH_PATH }
        },
        api: {
            perPage: 100,
            maxPages: 20,
            concurrency: 4,
            requestTimeoutMs: 10000,
            useStrings: true
        },
        sources: {
            domainMode: "marc_api_then_dom",
            domainMarcTag: "099",
            domainMarcSubfield: "a",
            domDomainFallback: true,
            fallbackToBiblioCreationDate: true,
            domCreationDateFallback: true,
            itemRuleFields: "location\nholding_library_id\nhome_library_id"
        },
        calculation: {
            minAgeYears: 1,
            recentLoanDays: 365,
            middleLoanDays: 1095,
            recentWeight: 1,
            middleWeight: 0.5,
            oldWeight: 0.2,
            neverLoanedWeight: 0.2,
            decimals: 2
        },
        exclusions: {
            ignoredKeywords: [
                "tri", "Zone de tri", "Magasin", "Magasin/reserve",
                "MBA-BIB", "Bibliothèque", "MBA-J", "Espace Jeunesse",
                "MBA-R1", "Réserve 1", "MBA-R2", "Réserve 2",
                "Espace consultation", "Collectivités", "conservation",
                "Conservation", "bureaux", "Bureaux", "anim", "Animations",
                "Service archéologique"
            ].join("\n"),
            specialKeywords: [
                "Parents et compagnie", "parents-enfants", "réservoir",
                "reserv_", "parents", "réserv", "reservoir adulte",
                "reservoir jeunesse", "Réservoir Jeunesse", "Réservoir Adulte"
            ].join("\n")
        },
        domains: {
            lowRotation: [
                "Littérature", "Les Arts", "Arts", "Arts du spectacle",
                "Poésie et Théâtre", "Musique à lire", "Vie pratique",
                "Hommes et Société", "Sciences et Techniques",
                "Les civilisations", "Le Var", "La Région Sud"
            ].join("\n"),
            normalRotation: [
                "Bande dessinée", "Romans Ados", "Romans adultes",
                "Romans jeunesse", "Albums", "Contes", "Cinéma",
                "Musique", "Vivre ensemble", "Découvrir le monde",
                "Mon quotidien", "Parents et compagnie", "Objets",
                "Grandeur nature", "Informatique", "Lire autrement",
                "Pop-Up", "V.O"
            ].join("\n")
        },
        thresholds: {
            low: { exceptional: 10, excellent: 3, good: 1, medium: 0.3 },
            normal: { exceptional: 20, excellent: 7, good: 2, medium: 0.5 },
            fallback: { exceptional: 15, excellent: 5, good: 1.5, medium: 0.4 },
            special: { exceptional: 10, excellent: 3, good: 1, medium: 0.3 }
        },
        display: {
            showItemIndicatorsOnDetail: true,
            showNoticeIndicator: true,
            showHelpQuestion: true,
            showApproximationMarker: true,
            showExcludedLock: true,
            helpNewTab: true,
            colors: {
                exceptionalBg: "#fffdf0",
                exceptionalBorder: "#ffd700",
                excellentBg: "#f0fff0",
                excellentBorder: "#8fbc8f",
                goodBg: "#f0f8ff",
                goodBorder: "#add8e6",
                mediumBg: "#fffdf0",
                mediumBorder: "#e6e6a0",
                dormantBg: "#ffe0c2",
                dormantBorder: "#ffb564",
                lowBg: "#fff0f0",
                lowBorder: "#e6a0a0",
                approximation: "#1976d2",
                special: "#ff9800",
                lowDomain: "#9c27b0",
                normalDomain: "#4caf50",
                excluded: "#4caf50"
            }
        }
    };

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function merge(base, extra) {
        const out = clone(base);
        if (!isObject(extra)) return out;
        Object.keys(extra).forEach(function (key) {
            if (Array.isArray(extra[key])) out[key] = clone(extra[key]);
            else if (isObject(extra[key]) && isObject(out[key])) out[key] = merge(out[key], extra[key]);
            else if (extra[key] !== undefined) out[key] = extra[key];
        });
        return out;
    }

    function clampNumber(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function clampInteger(value, min, max, fallback) {
        return Math.round(clampNumber(value, min, max, fallback));
    }

    function normalizeListString(value, fallback) {
        if (Array.isArray(value)) return value.map(String).join("\n");
        if (value == null) return fallback;
        return String(value);
    }

    function normalizeConfig(input) {
        const cfg = merge(DEFAULTS, isObject(input) ? input : {});
        cfg.enabled = cfg.enabled !== false;
        cfg.language = ["auto", "fr", "en"].includes(cfg.language) ? cfg.language : "auto";

        cfg.pages.detail.enabled = cfg.pages.detail.enabled !== false;
        cfg.pages.search.enabled = cfg.pages.search.enabled !== false;
        cfg.pages.detail.path = DETAIL_PATH;
        cfg.pages.search.path = SEARCH_PATH;

        cfg.api.perPage = clampInteger(cfg.api.perPage, 10, 500, DEFAULTS.api.perPage);
        cfg.api.maxPages = clampInteger(cfg.api.maxPages, 1, 100, DEFAULTS.api.maxPages);
        cfg.api.concurrency = clampInteger(cfg.api.concurrency, 1, 10, DEFAULTS.api.concurrency);
        cfg.api.requestTimeoutMs = clampInteger(cfg.api.requestTimeoutMs, 1500, 60000, DEFAULTS.api.requestTimeoutMs);
        cfg.api.useStrings = cfg.api.useStrings !== false;

        cfg.sources.domainMode = ["marc_api_then_dom", "dom_then_marc_api", "marc_api", "dom", "none"].includes(cfg.sources.domainMode)
            ? cfg.sources.domainMode : DEFAULTS.sources.domainMode;
        cfg.sources.domainMarcTag = String(cfg.sources.domainMarcTag || DEFAULTS.sources.domainMarcTag).trim().padStart(3, "0").slice(-3);
        cfg.sources.domainMarcSubfield = String(cfg.sources.domainMarcSubfield || DEFAULTS.sources.domainMarcSubfield).trim().slice(0, 1) || "a";
        cfg.sources.domDomainFallback = cfg.sources.domDomainFallback !== false;
        cfg.sources.fallbackToBiblioCreationDate = cfg.sources.fallbackToBiblioCreationDate !== false;
        cfg.sources.domCreationDateFallback = cfg.sources.domCreationDateFallback !== false;
        cfg.sources.itemRuleFields = normalizeListString(cfg.sources.itemRuleFields, DEFAULTS.sources.itemRuleFields);

        cfg.calculation.minAgeYears = clampNumber(cfg.calculation.minAgeYears, 0.01, 100, DEFAULTS.calculation.minAgeYears);
        cfg.calculation.recentLoanDays = clampInteger(cfg.calculation.recentLoanDays, 1, 36500, DEFAULTS.calculation.recentLoanDays);
        cfg.calculation.middleLoanDays = clampInteger(cfg.calculation.middleLoanDays, cfg.calculation.recentLoanDays, 36500, DEFAULTS.calculation.middleLoanDays);
        cfg.calculation.recentWeight = clampNumber(cfg.calculation.recentWeight, 0, 100, DEFAULTS.calculation.recentWeight);
        cfg.calculation.middleWeight = clampNumber(cfg.calculation.middleWeight, 0, 100, DEFAULTS.calculation.middleWeight);
        cfg.calculation.oldWeight = clampNumber(cfg.calculation.oldWeight, 0, 100, DEFAULTS.calculation.oldWeight);
        cfg.calculation.neverLoanedWeight = clampNumber(cfg.calculation.neverLoanedWeight, 0, 100, DEFAULTS.calculation.neverLoanedWeight);
        cfg.calculation.decimals = clampInteger(cfg.calculation.decimals, 0, 6, DEFAULTS.calculation.decimals);

        cfg.exclusions.ignoredKeywords = normalizeListString(cfg.exclusions.ignoredKeywords, DEFAULTS.exclusions.ignoredKeywords);
        cfg.exclusions.specialKeywords = normalizeListString(cfg.exclusions.specialKeywords, DEFAULTS.exclusions.specialKeywords);
        cfg.domains.lowRotation = normalizeListString(cfg.domains.lowRotation, DEFAULTS.domains.lowRotation);
        cfg.domains.normalRotation = normalizeListString(cfg.domains.normalRotation, DEFAULTS.domains.normalRotation);

        ["low", "normal", "fallback", "special"].forEach(function (key) {
            const def = DEFAULTS.thresholds[key];
            const t = cfg.thresholds[key] || {};
            t.exceptional = clampNumber(t.exceptional, 0, 1000000, def.exceptional);
            t.excellent = clampNumber(t.excellent, 0, t.exceptional, def.excellent);
            t.good = clampNumber(t.good, 0, t.excellent, def.good);
            t.medium = clampNumber(t.medium, 0, t.good, def.medium);
            cfg.thresholds[key] = t;
        });

        cfg.display.showItemIndicatorsOnDetail = cfg.display.showItemIndicatorsOnDetail !== false;
        cfg.display.showNoticeIndicator = cfg.display.showNoticeIndicator !== false;
        cfg.display.showHelpQuestion = cfg.display.showHelpQuestion !== false;
        cfg.display.showApproximationMarker = cfg.display.showApproximationMarker !== false;
        cfg.display.showExcludedLock = cfg.display.showExcludedLock !== false;
        cfg.display.helpNewTab = cfg.display.helpNewTab !== false;
        cfg.display.colors = merge(DEFAULTS.display.colors, cfg.display.colors || {});
        return cfg;
    }

    function splitList(value) {
        return String(value || "")
            .split(/[\n;,]+/)
            .map(function (v) { return v.trim(); })
            .filter(Boolean);
    }

    function norm(value) {
        return String(value || "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function language(cfg) {
        if (cfg.language === "fr" || cfg.language === "en") return cfg.language;
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            }
        } catch (_) {}
        const htmlLang = String(document.documentElement.lang || "").toLowerCase();
        return htmlLang.startsWith("en") ? "en" : "fr";
    }

    function roundScore(value, cfg) {
        const p = Math.pow(10, cfg.calculation.decimals);
        return Math.round((Number(value) + Number.EPSILON) * p) / p;
    }

    function parseDate(value) {
        if (!value) return null;
        if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
        const raw = String(value).trim();
        if (!raw) return null;
        const iso = raw.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
        if (iso) return validatedDate(iso[1], iso[2], iso[3]);
        const dmy = raw.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/);
        if (dmy) return validatedDate(dmy[3], dmy[2], dmy[1]);
        const parsed = new Date(raw);
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    }

    function validatedDate(y, m, d) {
        const year = Number(y), month = Number(m), day = Number(d);
        const date = new Date(year, month - 1, day);
        if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
        return date;
    }

    function ageInYears(date, cfg) {
        if (!(date instanceof Date) || Number.isNaN(date.getTime())) return null;
        const rawAge = (Date.now() - date.getTime()) / 31557600000;
        return Math.max(rawAge, cfg.calculation.minAgeYears);
    }

    function inactivityWeight(lastLoanDate, cfg) {
        if (!(lastLoanDate instanceof Date) || Number.isNaN(lastLoanDate.getTime())) return cfg.calculation.neverLoanedWeight;
        const diffDays = (Date.now() - lastLoanDate.getTime()) / 86400000;
        if (diffDays <= cfg.calculation.recentLoanDays) return cfg.calculation.recentWeight;
        if (diffDays <= cfg.calculation.middleLoanDays) return cfg.calculation.middleWeight;
        return cfg.calculation.oldWeight;
    }

    function getString(item, key) {
        const v = item && item._strings ? item._strings[key] : null;
        if (typeof v === "string") return v;
        if (v && typeof v === "object") return String(v.str || v.description || v.name || "");
        return "";
    }

    function itemFieldValues(item, cfg) {
        const fields = splitList(cfg.sources.itemRuleFields);
        const values = [];
        fields.forEach(function (field) {
            let raw = "";
            if (field === "holding_library_id") raw = getString(item, field) || item.holding_library?.name || item.holding_library_id || "";
            else if (field === "home_library_id") raw = getString(item, field) || item.home_library?.name || item.home_library_id || "";
            else raw = getString(item, field) || item[field] || "";
            if (raw !== null && raw !== undefined && String(raw).trim()) values.push(String(raw).trim());
        });
        return values;
    }

    function anyKeyword(values, keywords) {
        const normalizedKeywords = keywords.map(norm).filter(Boolean);
        return values.some(function (value) {
            const v = norm(value);
            return normalizedKeywords.some(function (k) { return v.includes(k); });
        });
    }

    function isIgnored(item, cfg) {
        return anyKeyword(itemFieldValues(item, cfg), splitList(cfg.exclusions.ignoredKeywords));
    }

    function isSpecial(item, cfg) {
        return anyKeyword(itemFieldValues(item, cfg), splitList(cfg.exclusions.specialKeywords));
    }

    function domainProfile(domain, hasSpecial, cfg) {
        if (hasSpecial) return "special";
        const d = norm(domain);
        if (d && splitList(cfg.domains.lowRotation).some(function (v) { return norm(v) === d; })) return "low";
        if (d && splitList(cfg.domains.normalRotation).some(function (v) { return norm(v) === d; })) return "normal";
        return "fallback";
    }

    function classify(score, profile, cfg) {
        const t = cfg.thresholds[profile] || cfg.thresholds.fallback;
        if (score >= t.exceptional) return { key: "exceptional", icon: ICONS.exceptional };
        if (score >= t.excellent) return { key: "excellent", icon: ICONS.excellent };
        if (score >= t.good) return { key: "good", icon: ICONS.good };
        if (score >= t.medium) return { key: "medium", icon: ICONS.medium };
        if (score > 0) return { key: "dormant", icon: ICONS.dormant };
        return { key: "low", icon: ICONS.low };
    }

    function qualitativeLabel(key, cfg) {
        const en = language(cfg) === "en";
        const labels = {
            exceptional: en ? "Exceptional" : "Exceptionnel",
            excellent: en ? "Excellent" : "Excellent",
            good: en ? "Good" : "Bon",
            medium: en ? "Average" : "Moyen",
            dormant: en ? "Dormant" : "Dormant",
            low: en ? "Low" : "Faible"
        };
        return labels[key] || key;
    }

    function indicatorText(classification, cfg) {
        return classification.icon + " " + qualitativeLabel(classification.key, cfg);
    }

    function apiHeaders(cfg, accept) {
        const headers = { Accept: accept || "application/json" };
        if ((accept || "application/json") === "application/json" && cfg.api.useStrings) headers["x-koha-embed"] = "+strings";
        return headers;
    }

    async function fetchWithTimeout(url, options, timeoutMs) {
        const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
        const timer = controller ? window.setTimeout(function () { controller.abort(); }, timeoutMs) : null;
        try {
            return await fetch(url, Object.assign({}, options || {}, controller ? { signal: controller.signal } : {}));
        } finally {
            if (timer) window.clearTimeout(timer);
        }
    }

    async function fetchItemsPage(biblioNumber, page, cfg, withStrings) {
        const url = `/api/v1/biblios/${encodeURIComponent(biblioNumber)}/items?_page=${page}&_per_page=${cfg.api.perPage}`;
        const headers = { Accept: "application/json" };
        if (withStrings) headers["x-koha-embed"] = "+strings";
        const response = await fetchWithTimeout(url, { credentials: "same-origin", headers: headers }, cfg.api.requestTimeoutMs);
        if (!response.ok) throw new Error(`Koha API items ${response.status}`);
        const items=await response.json();if(!Array.isArray(items))throw new Error('Réponse exemplaires invalide');
        const raw=response.headers.get('x-total-count'),total=raw!==null&&/^\d+$/.test(raw)?Number(raw):null;
        return {items,total};
    }

    async function fetchAllItems(biblioNumber, cfg) {
        const cacheKey = String(biblioNumber);
        if (state.itemCache.has(cacheKey)) return clone(state.itemCache.get(cacheKey));

        async function load(withStrings) {
            const all = [];let total=null,complete=false,reason='limite de pages';
            for (let page = 1; page <= cfg.api.maxPages; page += 1) {
                let result;
                try{result=await fetchItemsPage(biblioNumber,page,cfg,withStrings);}catch(error){if(!all.length)throw error;reason='lecture interrompue';break;}
                const items=result.items;if(result.total!==null)total=result.total;
                all.push(...items);
                if(total!==null&&all.length>=total){complete=true;break;}
                if(!items.length){complete=total===null||all.length>=total;reason='page vide avant le total annoncé';break;}
                if(total===null&&items.length<cfg.api.perPage){complete=true;break;}
            }
            state.itemCoverage.set(cacheKey,{source:'api',loaded:all.length,total,complete,reason:complete?'':reason});
            return all;
        }

        let items;
        try { items = await load(cfg.api.useStrings); }
        catch (e) {
            if (!cfg.api.useStrings) throw e;
            items = await load(false);
        }
        if(state.itemCoverage.get(cacheKey)?.complete)state.itemCache.set(cacheKey, clone(items));
        return items;
    }

    async function fetchMarc(biblioNumber, cfg) {
        const key = String(biblioNumber);
        if (state.marcCache.has(key)) return clone(state.marcCache.get(key));
        const response = await fetchWithTimeout(`/api/v1/biblios/${encodeURIComponent(biblioNumber)}`, {
            credentials: "same-origin",
            headers: { Accept: "application/marc-in-json" }
        }, cfg.api.requestTimeoutMs);
        if (!response.ok) throw new Error(`Koha API MARC ${response.status}`);
        const marc = await response.json();
        state.marcCache.set(key, clone(marc));
        return marc;
    }

    async function fetchBiblioJson(biblioNumber, cfg) {
        const key = String(biblioNumber);
        if (state.biblioCache.has(key)) return clone(state.biblioCache.get(key));
        const response = await fetchWithTimeout(`/api/v1/biblios/${encodeURIComponent(biblioNumber)}`, {
            credentials: "same-origin",
            headers: { Accept: "application/json" }
        }, cfg.api.requestTimeoutMs);
        if (!response.ok) throw new Error(`Koha API biblio ${response.status}`);
        const obj = await response.json();
        state.biblioCache.set(key, clone(obj));
        return obj;
    }

    function marcSubfield(marc, tag, code) {
        const fields = marc && Array.isArray(marc.fields) ? marc.fields : [];
        for (const field of fields) {
            const value = field && field[tag];
            if (!value) continue;
            const subfields = Array.isArray(value.subfields) ? value.subfields : [];
            for (const subfield of subfields) {
                if (subfield && subfield[code] !== undefined) return String(subfield[code]).trim();
            }
        }
        return "";
    }

    function domainFromDom(scope) {
        const root = scope || document;
        const direct = root.querySelector('.kx-notice-meta-acquisition a[href*="idx=f099a"], .technique-text a[href*="idx=f099a"], a[href*="idx=f099a"]');
        if (direct && direct.textContent.trim()) return direct.textContent.trim();
        const candidates = root.querySelectorAll("li");
        for (const li of candidates) {
            const text = String(li.textContent || "").replace(/\s+/g, " ").trim();
            const match = text.match(/Domaine\s*:\s*(.+?)(?:\s{2,}|$)/i);
            if (match && match[1]) return match[1].trim();
        }
        return "";
    }

    async function resolveDomain(biblioNumber, scope, cfg) {
        const mode = cfg.sources.domainMode;
        const dom = function () { return cfg.sources.domDomainFallback ? domainFromDom(scope) : ""; };
        const marc = async function () {
            try {
                const record = await fetchMarc(biblioNumber, cfg);
                return marcSubfield(record, cfg.sources.domainMarcTag, cfg.sources.domainMarcSubfield);
            } catch (_) { return ""; }
        };
        if (mode === "none") return "";
        if (mode === "dom") return dom();
        if (mode === "marc_api") return await marc();
        if (mode === "dom_then_marc_api") return dom() || await marc();
        return (await marc()) || dom();
    }

    function creationDateFromDom(scope) {
        const root = scope || document;
        const selectors = ["li.date-creation-tech", ".date-creation-tech", "[data-pmk-biblio-created]"];
        for (const selector of selectors) {
            for (const el of root.querySelectorAll(selector)) {
                const text = String(el.textContent || "");
                const m = text.match(/(\d{1,2}[\/.-]\d{1,2}[\/.-]\d{4}|\d{4}[\/.-]\d{1,2}[\/.-]\d{1,2})/);
                if (m) return parseDate(m[1]);
            }
        }
        return null;
    }

    async function resolveBiblioCreationDate(biblioNumber, scope, cfg) {
        if (!cfg.sources.fallbackToBiblioCreationDate) return null;
        try {
            const b = await fetchBiblioJson(biblioNumber, cfg);
            const candidates = [b.creation_date, b.datecreated, b.created_on, b.created_at, b.timestamp];
            for (const value of candidates) {
                const d = parseDate(value);
                if (d) return d;
            }
        } catch (_) {}
        return cfg.sources.domCreationDateFallback ? creationDateFromDom(scope) : null;
    }

    function getBiblioNumberFromPage() {
        const url = new URL(window.location.href);
        const q = url.searchParams.get("biblionumber") || url.searchParams.get("biblio_id");
        if (q && /^\d+$/.test(q)) return q;
        const candidate = document.querySelector('[data-biblionumber], input[name="biblionumber"], a[href*="biblionumber="]');
        if (candidate) {
            const data = candidate.getAttribute("data-biblionumber") || candidate.value || "";
            if (/^\d+$/.test(data)) return data;
            const href = candidate.getAttribute("href");
            if (href) {
                try {
                    const n = new URL(href, window.location.origin).searchParams.get("biblionumber");
                    if (n && /^\d+$/.test(n)) return n;
                } catch (_) {}
            }
        }
        return "";
    }

    function calculateItem(item, biblioCreationDate, domain, cfg) {
        const ignored = isIgnored(item, cfg);
        const special = isSpecial(item, cfg);
        if (ignored) return { ignored: true, special: special, item: item };

        const loansRaw = item.checkouts_count;
        const hasLoansValue = loansRaw !== null && loansRaw !== undefined && String(loansRaw).trim() !== "" && Number.isFinite(Number(loansRaw));
        if (!hasLoansValue) return { error: "loans", special: special, item: item };
        const loans = Number(loansRaw);

        let acquisition = parseDate(item.acquisition_date);
        let approximate = false;
        if (!acquisition && biblioCreationDate) {
            acquisition = biblioCreationDate;
            approximate = true;
        }
        if (!acquisition) return { error: "acquisition", loans: loans, special: special, item: item };

        const age = ageInYears(acquisition, cfg);
        if (!age) return { error: "age", loans: loans, special: special, item: item };
        const lastLoan = parseDate(item.last_checkout_date);
        const weight = inactivityWeight(lastLoan, cfg);
        const score = roundScore((loans / age) * weight, cfg);
        const profile = domainProfile(domain, special, cfg);
        const classification = classify(score, profile, cfg);

        return {
            ignored: false,
            error: null,
            item: item,
            loans: loans,
            acquisition: acquisition,
            lastLoan: lastLoan,
            age: age,
            weight: weight,
            score: score,
            profile: profile,
            classification: classification,
            special: special,
            approximate: approximate,
            values: itemFieldValues(item, cfg)
        };
    }

    function aggregate(results, domain, cfg) {
        const counted = results.filter(function (r) { return !r.ignored && !r.error; });
        const ignored = results.filter(function (r) { return r.ignored; });
        const errors = results.filter(function (r) { return !r.ignored && r.error; });
        const special = counted.some(function (r) { return r.special; });
        const approximate = counted.some(function (r) { return r.approximate; });
        if (!counted.length) return { counted: counted, ignored: ignored, errors: errors, special: special, approximate: approximate, domain: domain };

        const sum = function (key) { return counted.reduce(function (acc, r) { return acc + Number(r[key] || 0); }, 0); };
        const score = roundScore(sum("score") / counted.length, cfg); // moyenne des scores déjà arrondis : comportement historique
        const profile = domainProfile(domain, special, cfg);
        return {
            counted: counted,
            ignored: ignored,
            errors: errors,
            special: special,
            approximate: approximate,
            domain: domain,
            loans: sum("loans"),
            averageAge: sum("age") / counted.length,
            averageWeight: sum("weight") / counted.length,
            averageLoans: sum("loans") / counted.length,
            score: score,
            profile: profile,
            classification: classify(score, profile, cfg)
        };
    }

    function profileName(profile, cfg) {
        const en = language(cfg) === "en";
        if (profile === "low") return en ? "low rotation" : "rotation faible";
        if (profile === "normal") return en ? "normal rotation" : "rotation normale";
        if (profile === "special") return en ? "special location / low rotation" : "localisation spéciale / rotation faible";
        return en ? "default" : "par défaut";
    }

    function scaleText(profile, domain, cfg) {
        const t = cfg.thresholds[profile] || cfg.thresholds.fallback;
        const en = language(cfg) === "en";
        if (en) {
            return `Evaluation scale (${profileName(profile, cfg)}${domain ? ` — ${domain}` : ""})\nScore ≥${t.exceptional} | ${ICONS.exceptional} Exceptional\nScore ≥${t.excellent} and <${t.exceptional} | ${ICONS.excellent} Excellent\nScore ≥${t.good} and <${t.excellent} | ${ICONS.good} Good\nScore ≥${t.medium} and <${t.good} | ${ICONS.medium} Average\nScore >0 and <${t.medium} | ${ICONS.dormant} Dormant\nScore ≤0 | ${ICONS.low} Low`;
        }
        return `Échelle d'évaluation (${profileName(profile, cfg)}${domain ? ` — ${domain}` : ""})\nScore ≥${t.exceptional} | ${ICONS.exceptional} Exceptionnel\nScore ≥${t.excellent} et <${t.exceptional} | ${ICONS.excellent} Excellent\nScore ≥${t.good} et <${t.excellent} | ${ICONS.good} Bon\nScore ≥${t.medium} et <${t.good} | ${ICONS.medium} Moyen\nScore >0 et <${t.medium} | ${ICONS.dormant} Dormant\nScore ≤0 | ${ICONS.low} Faible`;
    }

    function itemTooltip(result, domain, cfg) {
        const en = language(cfg) === "en";
        if (result.ignored) {
            return en
                ? `🔒 Item excluded from efficiency calculation\nMatched values: ${result.values?.join(" / ") || itemFieldValues(result.item, cfg).join(" / ") || "—"}`
                : `🔒 Exemplaire non pris en compte\nValeurs détectées : ${result.values?.join(" / ") || itemFieldValues(result.item, cfg).join(" / ") || "—"}\nCes exemplaires ne sont pas inclus dans le calcul d'efficacité.`;
        }
        if (result.error) {
            return en ? `Calculation impossible (${result.error}).` : `🚫 Calcul impossible pour cet exemplaire (${result.error}).`;
        }
        const source = result.approximate ? (en ? "bibliographic record creation date (approximation)" : "date de création de la notice (approximation)") : (en ? "item acquisition date" : "date d'acquisition");
        return en
            ? `📊 Item efficiency${result.approximate ? " (approximate)" : ""}\n${domain ? `📌 Domain: ${domain}\n` : ""}${result.special ? "📍 Special location\n" : ""}- Cumulative checkouts: ${result.loans}\n- Item age: ${result.age.toFixed(2)} years\n- Age source: ${source}\n- Inactivity weight: ${result.weight}\n- Score: ${result.score}\n- Indicator: ${indicatorText(result.classification, cfg)}\n\n${scaleText(result.profile, domain, cfg)}`
            : `📊 Efficacité de l'exemplaire${result.approximate ? " (approximative)" : " (indicatif)"}\n${domain ? `📌 Domaine : ${domain}\n` : ""}${result.special ? "📍 Localisation spéciale\n" : ""}- Nombre de prêts (cumulés) : ${result.loans}\n- Âge de l'exemplaire : ${result.age.toFixed(2)} ans\n- Source de l'âge : ${source}\n- Pondération d'inactivité appliquée : ${result.weight}\n- Efficacité = (Prêts / Âge) × Pondération\n  → Score calculé : ${result.score}\n- Indicateur qualitatif : ${indicatorText(result.classification, cfg)}\n\n${scaleText(result.profile, domain, cfg)}\n⚠️ Score indicatif. À interpréter avec le contexte du fonds, de la politique documentaire et des spécificités du public.`;
    }

    function globalTooltip(agg, cfg) {
        const en = language(cfg) === "en";
        if (!agg.counted.length) {
            return en
                ? `No item could be evaluated. Excluded: ${agg.ignored.length}; errors: ${agg.errors.length}.`
                : `Aucun exemplaire n'a pu être évalué. Exemplaires ignorés : ${agg.ignored.length} ; erreurs : ${agg.errors.length}.`;
        }
        return en
            ? `📊 Average item efficiency for the record${agg.approximate ? " (approximate)" : ""}\n${agg.domain ? `📌 Domain: ${agg.domain}\n` : ""}${agg.special ? "📍 Special location detected\n" : ""}- Items included: ${agg.counted.length}\n- Items excluded: ${agg.ignored.length}\n- Total checkouts: ${agg.loans}\n- Average age: ${agg.averageAge.toFixed(2)} years\n- Average inactivity weight: ${agg.averageWeight.toFixed(2)}\n- Average checkouts per item: ${agg.averageLoans.toFixed(2)}\n- Average efficiency score: ${agg.score}\n- Indicator: ${indicatorText(agg.classification, cfg)}\n\n${scaleText(agg.profile, agg.domain, cfg)}`
            : `📊 Efficacité moyenne des exemplaires de la notice${agg.approximate ? " (approximative)" : " (indicatif)"}\n${agg.domain ? `📌 Domaine : ${agg.domain}\n` : ""}${agg.special ? "📍 Localisation spéciale détectée\n" : ""}${agg.ignored.length ? `⚠️ ${agg.ignored.length} exemplaire(s) ignoré(s)\n` : ""}${agg.approximate ? "≈ Calcul utilisant la date de création de notice pour au moins un exemplaire\n" : ""}\nNotion clé : ce score est une MOYENNE PAR EXEMPLAIRE.\nIl est comparable entre notices avec 1 exemplaire et celles avec plusieurs.\n\nDonnées agrégées :\n- Nombre d'exemplaires pris en compte : ${agg.counted.length}\n- Exemplaires ignorés : ${agg.ignored.length}\n- Nombre total de prêts : ${agg.loans}\n- Âge moyen des exemplaires : ${agg.averageAge.toFixed(2)} ans\n- Pondération moyenne d'inactivité : ${agg.averageWeight.toFixed(2)}\n- Prêts moyens par exemplaire : ${agg.averageLoans.toFixed(2)}\n\nCalcul :\n- Efficacité exemplaire = (Prêts / Âge) × Pondération d'inactivité.\n- Efficacité moyenne notice = moyenne des efficacités des exemplaires.\n  → Score calculé : ${agg.score}\n  → Indicateur qualitatif : ${indicatorText(agg.classification, cfg)}\n\n${scaleText(agg.profile, agg.domain, cfg)}\n⚠️ Score indicatif. Il doit être confronté aux usages locaux, à la politique documentaire, à la saisonnalité et au rôle du titre dans le fonds.`;
    }

    function injectStyles(cfg) {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }
        style.textContent = `
.${ITEM_INDICATOR_CLASS}{margin-top:15px;display:inline-flex;align-items:center;gap:.22rem;margin-left:5px;cursor:help;vertical-align:middle}
.${GLOBAL_OWN_CLASS}{margin:5px 5px;padding:4px 6px;border-radius:3px;font-weight:bold;font-size:12px;color:#333;display:inline-flex;align-items:center;gap:.28rem;max-width:100%;box-sizing:border-box}
.${GLOBAL_OWN_CLASS}.pmk099-detail{margin:10px 0;padding:8px;font-size:inherit}
.${HELP_CLASS}{font-size:.8em;margin-left:5px;text-decoration:none!important;color:#007bff!important;opacity:.7;cursor:pointer;font-weight:normal;border:0;background:transparent;padding:0 .1rem;line-height:1}
.${HELP_CLASS}:hover,.${HELP_CLASS}:focus{opacity:1;text-decoration:underline!important}
.pmk099-approx{font-weight:bold;color:${cssColor(cfg.display.colors.approximation, "#1976d2")}}
.pmk099-excluded{color:${cssColor(cfg.display.colors.excluded, "#4caf50")};font-weight:bold}
@media(max-width:768px){.${GLOBAL_OWN_CLASS}{white-space:normal;overflow-wrap:anywhere}}
        `;
    }

    function cssColor(value, fallback) {
        const v = String(value || "").trim();
        return /^#[0-9a-f]{3,8}$/i.test(v) || /^(rgb|hsl)a?\(/i.test(v) || /^[a-z]+$/i.test(v) ? v : fallback;
    }

    function resultColors(classification, cfg) {
        const c = cfg.display.colors;
        const key = classification?.key || "low";
        const map = {
            exceptional: [c.exceptionalBg, c.exceptionalBorder],
            excellent: [c.excellentBg, c.excellentBorder],
            good: [c.goodBg, c.goodBorder],
            medium: [c.mediumBg, c.mediumBorder],
            dormant: [c.dormantBg, c.dormantBorder],
            low: [c.lowBg, c.lowBorder]
        };
        return map[key] || map.low;
    }

    function decorateDomainBorders(el, profile, special, approximate, cfg, detailMode) {
        const c = cfg.display.colors;
        if (profile === "low") el.style[detailMode ? "borderTop" : "borderLeft"] = `3px solid ${cssColor(c.lowDomain, "#9c27b0")}`;
        if (profile === "normal") el.style[detailMode ? "borderTop" : "borderLeft"] = `3px solid ${cssColor(c.normalDomain, "#4caf50")}`;
        if (special) {
            el.style.borderRight = `3px solid ${cssColor(c.special, "#ff9800")}`;
            el.style.backgroundColor = "#fff8e1";
        }
        if (approximate && detailMode) {
            el.style.borderLeft = `4px solid ${cssColor(c.approximation, "#1976d2")}`;
            el.style.fontStyle = "italic";
        }
    }

    function createHelpLink(cfg) {
        if (!cfg.display.showHelpQuestion) return null;
        const a = document.createElement("a");
        a.href = "#";
        a.className = HELP_CLASS;
        a.textContent = "?";
        a.title = language(cfg) === "en" ? "Efficiency indicator help" : "Aide sur l'indicateur d'efficacité";
        a.setAttribute("aria-label", a.title);
        a.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();
            openDynamicHelp(cfg);
        });
        return a;
    }

    function createItemIndicator(result, domain, cfg) {
        const span = document.createElement("span");
        span.className = ITEM_INDICATOR_CLASS;
        span.setAttribute("data-pmk099-item-id", String(result.item.item_id || result.item.itemnumber || result.item.item_id || ""));
        if (result.ignored) {
            if (!cfg.display.showExcludedLock) return null;
            span.classList.add("pmk099-excluded");
            span.textContent = "🔒";
        } else if (result.error) {
            span.textContent = ICONS.low;
            span.style.color = "#d32f2f";
            span.style.fontWeight = "bold";
        } else {
            span.textContent = result.classification.icon + (result.approximate && cfg.display.showApproximationMarker ? " ≈" : "");
            if (result.approximate) span.classList.add("pmk099-approx");
            if (result.special) {
                span.style.borderLeft = `2px solid ${cssColor(cfg.display.colors.special, "#ff9800")}`;
                span.style.paddingLeft = "3px";
            }
        }
        span.title = itemTooltip(result, domain, cfg);
        const help = createHelpLink(cfg);
        if (help) span.appendChild(help);
        return span;
    }

    function createGlobalIndicator(agg, cfg, detailMode) {
        const div = document.createElement("div");
        div.className = `${GLOBAL_INDICATOR_CLASS} ${GLOBAL_OWN_CLASS}${detailMode ? " pmk099-detail" : ""}`;
        div.setAttribute(DONE_ATTR, "1");

        if (agg.counted.length) {
            const colors = resultColors(agg.classification, cfg);
            div.style.backgroundColor = cssColor(colors[0], "#f9f9f9");
            div.style.border = `1px solid ${cssColor(colors[1], "#ccc")}`;
            decorateDomainBorders(div, agg.profile, agg.special, agg.approximate, cfg, detailMode);
            const prefix = detailMode ? `${agg.approximate && cfg.display.showApproximationMarker ? "≈ " : ""}📊 Eff. moyenne ex. notice : ` : "";
            div.appendChild(document.createTextNode(`${prefix}${agg.score} (${indicatorText(agg.classification, cfg)})`));
        } else if (agg.ignored.length && agg.ignored.length === agg.ignored.length + agg.errors.length) {
            div.style.cssText += `;background:#e8f5e8;border:2px solid ${cssColor(cfg.display.colors.excluded,"#4caf50")};color:#2e7d32`;
            div.appendChild(document.createTextNode(detailMode ? "🔒 Tous les exemplaires sont en magasin/réserve/consultation" : "🔒 Hors calcul (magasin/réserve)"));
        } else {
            div.style.cssText += ";background:#fff0f0;border:2px solid #d32f2f;color:#d32f2f";
            div.appendChild(document.createTextNode(`${ICONS.low} Calcul impossible`));
        }
        div.title = globalTooltip(agg, cfg);
        if(agg.coverage){
            const c=agg.coverage,en=language(cfg)==='en';
            const text=en?(c.source==='dom'?'Source: visible page rows':'Source: Koha API')+' — '+c.loaded+(c.total!==null?' / '+c.total:'')+' item(s)'+(c.complete?'':' — partial calculation'):(c.source==='dom'?'Source : lignes de la page':'Source : API Koha')+' — '+c.loaded+(c.total!==null?' / '+c.total:'')+' exemplaire(s)'+(c.complete?'':' — calcul partiel');
            div.title+='\n'+text+(c.reason?' ('+c.reason+')':'')+'\n'+(en?'Calculation errors: ':'Exemplaires non calculables : ')+agg.errors.length;
            const note=document.createElement('small');note.className='pmk099-coverage';note.textContent=text;div.appendChild(note);
        }
        div.setAttribute('aria-label',div.title);
        const help = createHelpLink(cfg);
        if (help) div.appendChild(help);
        return div;
    }

    function escapeHtml(value) {
        return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function formatNum(value) {
        const n = Number(value);
        if (!Number.isFinite(n)) return "—";
        return String(n).replace(".", ",");
    }

    function helpHtml(cfg) {
        const tLow = cfg.thresholds.low;
        const tNormal = cfg.thresholds.normal;
        const calc = cfg.calculation;
        const lowExample = splitList(cfg.domains.lowRotation)[0] || "Arts";
        const normalExample = splitList(cfg.domains.normalRotation)[0] || "Romans";
        const specialExample = splitList(cfg.exclusions.specialKeywords)[0] || "Parents";
        const ignored = splitList(cfg.exclusions.ignoredKeywords).slice(0, 6).join(", ") || "—";
        const c = cfg.display.colors;
        return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Outil d'Évaluation de l'Efficacité des Documents</title></head><body style="margin:0;padding:10px;background:#fff;">
<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; padding: 15px; border: 1px solid #ddd; border-radius: 6px; max-width: 900px; margin: 10px auto; background-color: #f9f9f9;">
<h1 style="color: #004d99; border-bottom: 3px solid #004d99; padding-bottom: 10px; font-size: 24px;">🛠️ Outil d'Évaluation de l'Efficacité des Documents (Koha)</h1>
<p>Cet outil vise à fournir une <strong>mesure quantitative</strong> de la performance de circulation (rotation) de chaque exemplaire et de chaque notice bibliographique. Il vous aide à identifier rapidement les documents qui circulent bien et ceux qui sont sous-utilisés (dormants) afin de faciliter la gestion des collections.</p>
<hr style="border:0;height:1px;background:#ccc;margin:15px 0;">
<h2 style="color:#007bff;border-bottom:1px solid #ccc;padding-bottom:5px;margin-top:25px;font-size:20px;">📊 Score d'Efficacité : La Logique de l'Outil</h2>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">1. La Formule de l'Efficacité (Par Exemplaire)</h3>
<p>Le Score d'Efficacité est un <strong>indice de rotation annuel pondéré</strong>. Il répond à la question : « Combien de fois cet exemplaire est-il prêté par an, en tenant compte de son âge et de son activité récente ? »</p>
<div style="font-size:1.1em;background:#e9f7ff;padding:15px;border-radius:5px;text-align:center;margin:20px 0;border:1px solid #b3e0ff;"><strong style="font-style:italic;">Efficacité</strong> = <span style="display:inline-block;vertical-align:middle;text-align:center;margin:0 10px;padding:0 5px;"><span style="border-bottom:1px solid #333;padding-bottom:3px;display:block;white-space:nowrap;">Nombre de Prêts cumulés</span><span style="padding-top:3px;display:block;white-space:nowrap;">Âge en Années</span></span> × Pondération d'Inactivité</div>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">2. Les Facteurs du Calcul</h3>
<table style="width:100%;border-collapse:collapse;margin:15px 0;font-size:.9em;"><thead><tr style="background:#f2f2f2;"><th style="border:1px solid #ddd;padding:10px;text-align:left;">Facteur</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Description</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Rôle dans le Calcul</th></tr></thead><tbody>
<tr><td style="border:1px solid #ddd;padding:10px;"><strong>Âge en Années</strong></td><td style="border:1px solid #ddd;padding:10px;">Temps écoulé depuis la Date d'Acquisition (min. ${escapeHtml(formatNum(calc.minAgeYears))} an${calc.minAgeYears > 1 ? "s" : ""}).</td><td style="border:1px solid #ddd;padding:10px;"><strong>Normalisation par le temps</strong> (Dénominateur).</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;"><strong>Pondération d'Inactivité</strong></td><td style="border:1px solid #ddd;padding:10px;">Facteur ajusté qui pénalise les documents n'ayant pas circulé récemment.</td><td style="border:1px solid #ddd;padding:10px;"><strong>Mesure de la pertinence actuelle</strong>.</td></tr></tbody></table>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">3. Les Seuils de la Pondération d'Inactivité</h3>
<table style="width:100%;border-collapse:collapse;margin:15px 0;font-size:.9em;"><thead><tr style="background:#f2f2f2;"><th style="border:1px solid #ddd;padding:10px;text-align:left;">Dernier Prêt</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Pondération</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Signification</th></tr></thead><tbody>
<tr><td style="border:1px solid #ddd;padding:10px;"><strong>≤ ${calc.recentLoanDays} jours</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>${formatNum(calc.recentWeight)}</strong></td><td style="border:1px solid #ddd;padding:10px;">Circulation active. Pas de pénalité.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;"><strong>&gt; ${calc.recentLoanDays} et ≤ ${calc.middleLoanDays} jours</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>${formatNum(calc.middleWeight)}</strong></td><td style="border:1px solid #ddd;padding:10px;">Circulation faible mais récente. Pénalité modérée.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;"><strong>&gt; ${calc.middleLoanDays} jours</strong> ou <strong>Jamais prêté</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>${formatNum(calc.oldWeight)}</strong> / jamais prêté : <strong>${formatNum(calc.neverLoanedWeight)}</strong></td><td style="border:1px solid #ddd;padding:10px;">Dormant. Score fortement réduit.</td></tr></tbody></table>
<hr style="border:0;height:1px;background:#ccc;margin:15px 0;">
<h2 style="color:#007bff;border-bottom:1px solid #ccc;padding-bottom:5px;margin-top:25px;font-size:20px;">📚 Interprétation du Score et Échelles d'Évaluation</h2>
<p>L'outil affiche un <strong>Indicateur Qualitatif</strong> (émoji) qui classe le score d'efficacité selon deux types de rotation : <strong>Normale</strong> (haute demande) ou <strong>Faible</strong> (référence/patrimoine).</p>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">Échelle d'Interprétation Détaillée</h3>
<table style="width:100%;border-collapse:collapse;margin:15px 0;font-size:.9em;"><thead><tr style="background:#f2f2f2;"><th style="border:1px solid #ddd;padding:10px;text-align:left;">Indicateur Qualitatif</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Seuil Rotation Faible (Ex: ${escapeHtml(lowExample)})</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Seuil Rotation Normale (Ex: ${escapeHtml(normalExample)})</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Signification</th></tr></thead><tbody>
${helpThresholdRow(ICONS.exceptional,"Exceptionnel",`Score ≥ ${tLow.exceptional}`,`Score ≥ ${tNormal.exceptional}`,"Rotation très élevée, succès majeur.")}
${helpThresholdRow(ICONS.excellent,"Excellent",`Score ≥ ${tLow.excellent}`,`Score ≥ ${tNormal.excellent}`,"Rotation forte, supérieure à la moyenne.")}
${helpThresholdRow(ICONS.good,"Bon",`Score ≥ ${tLow.good}`,`Score ≥ ${tNormal.good}`,"Circulation saine, atteint les attentes du domaine.")}
${helpThresholdRow(ICONS.medium,"Moyen",`Score ≥ ${tLow.medium}`,`Score ≥ ${tNormal.medium}`,"Circulation faible, mais évite le statut de dormant.")}
${helpThresholdRow(ICONS.dormant,"Dormant",`Score > 0 et < ${tLow.medium}`,`Score > 0 et < ${tNormal.medium}`,"Circulation critique (très faible). Cible de désherbage potentiel.")}
${helpThresholdRow(ICONS.low,"Faible","Score = 0","Score = 0","Jamais prêté (ou prêts annulés) et âge supérieur au minimum configuré.")}
</tbody></table>
<hr style="border:0;height:1px;background:#ccc;margin:15px 0;">
<h2 style="color:#007bff;border-bottom:1px solid #ccc;padding-bottom:5px;margin-top:25px;font-size:20px;">💻 Affichage des Résultats dans Koha</h2>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">1. Sur la Page de Détail de la Notice (<code style="background:#eee;padding:2px 4px;border-radius:3px;">/catalogue/detail.pl</code>)</h3>
<ul style="padding-left:20px;"><li style="margin-bottom:8px;"><strong>Indicateur par Exemplaire :</strong> Émoji et score ajoutés à côté du nombre de prêts. La souris affiche l'info-bulle détaillée.</li><li style="margin-bottom:8px;"><strong>Score Global de la Notice :</strong> Un encadré affiche l'<strong>Efficacité Moyenne des Exemplaires</strong> pour l'ensemble du titre.</li></ul>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">2. Mises en Garde et Symboles</h3>
<ul style="padding-left:20px;"><li style="margin-bottom:8px;">Symbole <strong style="color:${cssColor(c.approximation,"#1976d2")};">≈</strong> : Indique une approximation (la Date de Création de la Notice a été utilisée comme date d'acquisition).</li><li style="margin-bottom:8px;">Émoji <span style="font-size:1.2em;">🔒</span> : Indique que l'exemplaire est <strong>ignoré</strong> et n'est pas inclus dans la moyenne. Mots-clés actuels : ${escapeHtml(ignored)}.</li></ul>
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">3. Signification des Couleurs de Bordure / Fond</h3>
<p>La couleur des indicateurs est un indice visuel rapide de la performance du document par rapport à son domaine ou à sa localisation spéciale :</p>
<table style="width:100%;border-collapse:collapse;margin:15px 0;font-size:.9em;"><thead><tr style="background:#f2f2f2;"><th style="border:1px solid #ddd;padding:10px;text-align:left;">Couleur / Emplacement</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Signification & des Informations Complémentaires</th></tr></thead><tbody>
<tr><td style="border:1px solid #ddd;padding:10px;background:#e9f7ff;border-left:5px solid ${cssColor(c.approximation,"#1976d2")};"><strong>Bordure Gauche (Bleu)</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Approximation d'Âge</strong> : date de création de la notice utilisée en l'absence de date d'acquisition.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;background:#fff8e1;border-right:5px solid ${cssColor(c.special,"#ff9800")};"><strong>Bordure Droite (Orange) / Fond Jaune</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Localisation Spéciale</strong> : règle spécifique détectée (ex. « ${escapeHtml(specialExample)} »). L'échelle spéciale configurée est appliquée.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;background:#e6ffe6;border-top:5px solid ${cssColor(c.normalDomain,"#4CAF50")};"><strong>Bordure Sup. (Vert)</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Domaine de Haute Rotation</strong> : échelle de Rotation Normale.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;background:#f2f2f2;border-top:5px solid ${cssColor(c.lowDomain,"#9c27b0")};"><strong>Bordure Sup. (Violet)</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Domaine de Faible Rotation</strong> : échelle de Rotation Faible.</td></tr>
</tbody></table>
<hr style="border:0;height:1px;background:#ccc;margin:15px 0;">
<h3 style="color:#28a745;margin-top:20px;font-size:18px;">4. Couleurs de l'Indicateur Qualitatif (Score)</h3>
<p>Applicable au score global de la notice et aux scores par exemplaire :</p>
<table style="width:100%;border-collapse:collapse;margin:15px 0;font-size:.9em;"><thead><tr style="background:#f2f2f2;"><th style="border:1px solid #ddd;padding:10px;text-align:left;">Couleur du Résultat</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Indicateurs Qualitatifs (Émojis)</th><th style="border:1px solid #ddd;padding:10px;text-align:left;">Signification</th></tr></thead><tbody>
<tr><td style="border:1px solid #ddd;padding:10px;background:${cssColor(c.goodBg,"#e6ffe6")};"><strong>Vert / Bleu clair</strong></td><td style="border:1px solid #ddd;padding:10px;"><span style="font-size:1.2em;">${ICONS.exceptional}</span> <strong>Exceptionnel</strong>, <span style="font-size:1.2em;">${ICONS.excellent}</span> <strong>Excellent</strong>, <span style="font-size:1.2em;">${ICONS.good}</span> <strong>Bon</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Circulation saine & forte</strong>. Le document est performant selon l'échelle de son domaine.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;background:${cssColor(c.mediumBg,"#fff8e1")};"><strong>Jaune / Orange</strong></td><td style="border:1px solid #ddd;padding:10px;"><span style="font-size:1.2em;">${ICONS.medium}</span> <strong>Moyen</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Circulation faible/irrégulière</strong>. À surveiller ou évaluer.</td></tr>
<tr><td style="border:1px solid #ddd;padding:10px;background:${cssColor(c.lowBg,"#ffebe6")};"><strong>Rouge / Rose</strong></td><td style="border:1px solid #ddd;padding:10px;"><span style="font-size:1.2em;">${ICONS.dormant}</span> <strong>Dormant</strong>, <span style="font-size:1.2em;">${ICONS.low}</span> <strong>Faible</strong></td><td style="border:1px solid #ddd;padding:10px;"><strong>Circulation critique</strong>. Cible à étudier en priorité pour le désherbage ou le transfert en magasin.</td></tr>
</tbody></table>
<hr style="border:0;height:1px;background:#ccc;margin:15px 0;">
<div style="padding:10px;margin:15px 0;border-left:5px solid #ffc107;background:#fff3cd;color:#856404;border-radius:3px;"><strong>⚠️ RAPPEL IMPORTANT :</strong> Le Score d'Efficacité est une <strong>aide à la décision</strong> et non une règle absolue. Un score faible pour un fonds de référence est souvent normal.</div>
</div></body></html>`;
    }

    function helpThresholdRow(icon, label, low, normal, meaning) {
        return `<tr><td style="border:1px solid #ddd;padding:10px;"><span style="font-size:1.2em;margin-right:5px;">${icon}</span> <strong>${escapeHtml(label)}</strong></td><td style="border:1px solid #ddd;padding:10px;">${escapeHtml(low)}</td><td style="border:1px solid #ddd;padding:10px;">${escapeHtml(normal)}</td><td style="border:1px solid #ddd;padding:10px;">${escapeHtml(meaning)}</td></tr>`;
    }

    function openDynamicHelp(cfg) {
        const html = helpHtml(cfg);
        const target = cfg.display.helpNewTab ? "_blank" : "pmk099-help";
        const w = window.open("", target);
        if (w && w.document) {
            w.document.open();
            w.document.write(html);
            w.document.close();
            try { w.focus(); } catch (_) {}
            return;
        }
        // Repli si le navigateur bloque l'onglet.
        const overlay = document.createElement("div");
        overlay.style.cssText = "position:fixed;inset:0;z-index:20000;background:rgba(0,0,0,.45);padding:2vh;overflow:auto";
        const box = document.createElement("div");
        box.style.cssText = "background:#fff;max-width:980px;margin:auto;border-radius:6px;position:relative";
        const close = document.createElement("button");
        close.type = "button";
        close.textContent = "×";
        close.style.cssText = "position:sticky;top:8px;float:right;margin:8px;font-size:24px;z-index:2";
        close.addEventListener("click", function () { overlay.remove(); });
        const content = document.createElement("div");
        content.innerHTML = html.match(/<body[^>]*>([\s\S]*)<\/body>/i)?.[1] || html;
        box.appendChild(close);
        box.appendChild(content);
        overlay.appendChild(box);
        overlay.addEventListener("click", function (e) { if (e.target === overlay) overlay.remove(); });
        document.body.appendChild(overlay);
    }

    function clearInjected(root) {
        (root || document).querySelectorAll(`.${ITEM_INDICATOR_CLASS}, .${GLOBAL_OWN_CLASS}`).forEach(function (el) { el.remove(); });
    }

    function findNativeItemsTable() {
        return document.querySelector("#holdings_table, #holdingst, table.items_table, table.holdingst, table#items");
    }

    function rowDataFromDataTable(table, row) {
        try {
            if (window.jQuery && window.jQuery.fn && window.jQuery.fn.dataTable && window.jQuery.fn.dataTable.isDataTable(table)) {
                const api = window.jQuery(table).DataTable();
                return api.row(row).data() || null;
            }
        } catch (_) {}
        return null;
    }

    function itemId(item) {
        return String(item?.item_id ?? item?.itemnumber ?? item?.item_number ?? "").trim();
    }

    function barcode(item) {
        return String(item?.external_id ?? item?.barcode ?? "").trim();
    }

    function findResultForRow(row, results, table) {
        const data = rowDataFromDataTable(table, row);
        const dataId = itemId(data);
        if (dataId) {
            const byId = results.find(function (r) { return itemId(r.item) === dataId; });
            if (byId) return byId;
        }
        const idFromDom = row.getAttribute("data-item-id") || row.dataset.itemnumber || row.dataset.itemId || "";
        if (idFromDom) {
            const byId = results.find(function (r) { return itemId(r.item) === String(idFromDom); });
            if (byId) return byId;
        }
        const rowText = String(row.textContent || "");
        const byBarcode = results.find(function (r) { const b = barcode(r.item); return b && rowText.includes(b); });
        return byBarcode || null;
    }

    function insertDetailItemIndicators(table, results, domain, cfg) {
        if (!cfg.display.showItemIndicatorsOnDetail || !table) return;
        const rows = Array.from(table.querySelectorAll("tbody tr"));
        rows.forEach(function (row) {
            row.querySelectorAll(`.${ITEM_INDICATOR_CLASS}`).forEach(function (el) { el.remove(); });
            const result = findResultForRow(row, results, table);
            if (!result) return;
            const cell = row.querySelector("td.issues") || findCellByHeader(table, row, ["nombre de prêts", "checkouts", "issues"]);
            if (!cell) return;
            const el = createItemIndicator(result, domain, cfg);
            if (!el) return;
            cell.appendChild(document.createElement("br"));
            cell.appendChild(el);
        });
    }

    function findCellByHeader(table, row, labels) {
        const headers = Array.from(table.querySelectorAll("thead th"));
        const wanted = labels.map(norm);
        const index = headers.findIndex(function (th) {
            const text = norm(th.textContent);
            return wanted.some(function (x) { return text.includes(x); });
        });
        return index >= 0 ? row.children[index] || null : null;
    }

    function insertDetailGlobal(table, agg, cfg) {
        if (!cfg.display.showNoticeIndicator || !table) return;
        table.parentElement?.querySelectorAll(`:scope > .${GLOBAL_OWN_CLASS}`).forEach(function (el) { el.remove(); });
        const div = createGlobalIndicator(agg, cfg, true);
        table.parentNode.insertBefore(div, table);
        mountConfigButton(div, "detail");
    }

    function mountConfigButton(anchor, contextKey) {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.mountContextButton === "function") {
                window.PMKConfig.mountContextButton({
                    moduleId: MODULE_ID,
                    anchor: anchor,
                    position: "append",
                    contextKey: `catalogue.${contextKey}`,
                    context: { sectionId: "calculation", pageId: `catalogue.${contextKey}` }
                });
            }
        } catch (_) {}
    }

    async function runDetail(cfg) {
        const biblioNumber = getBiblioNumberFromPage();
        if (!biblioNumber) return;
        const table = await waitForElement(function () { return findNativeItemsTable(); }, 20000);
        if (!table) return;
        const [items, domain] = await Promise.all([
            fetchAllItems(biblioNumber, cfg).catch(function () { return []; }),
            resolveDomain(biblioNumber, document, cfg)
        ]);
        if (!items.length) return runDetailDomFallback(table, domain, cfg);
        const needsFallback = cfg.sources.fallbackToBiblioCreationDate && items.some(function (i) { return !parseDate(i.acquisition_date); });
        const creationDate = needsFallback ? await resolveBiblioCreationDate(biblioNumber, document, cfg) : null;
        const results = items.map(function (item) { return calculateItem(item, creationDate, domain, cfg); });
        const agg = aggregate(results, domain, cfg);
        agg.coverage=state.itemCoverage.get(String(biblioNumber));
        injectStyles(cfg);
        clearInjected(document);
        insertDetailGlobal(table, agg, cfg);
        insertDetailItemIndicators(table, results, domain, cfg);
        bindDataTableRedraw(table, results, domain, cfg);
        dispatchResults("detail", biblioNumber, agg, results);
    }

    function bindDataTableRedraw(table, results, domain, cfg) {
        try {
            if (!window.jQuery) return;
            const $table = window.jQuery(table);
            $table.off("draw.dt.pmk099").on("draw.dt.pmk099", function () {
                insertDetailItemIndicators(table, results, domain, cfg);
            });
        } catch (_) {}
    }

    function legacyDomItemFromRow(row, table) {
        const loansCell = row.querySelector("td.issues") || findCellByHeader(table, row, ["prêt", "checkouts", "issues"]);
        const acqCell = row.querySelector("td.dateaccessioned") || findCellByHeader(table, row, ["acquisition", "date acquired"]);
        const lastCell = row.querySelector("td.datelastborrowed") || findCellByHeader(table, row, ["dernier emprunt", "date last borrowed"]);
        const location = row.querySelector("td.location")?.textContent || row.querySelector("span.shelvingloc")?.textContent || "";
        const home = row.querySelector("td.homebranch")?.textContent || "";
        const holding = row.querySelector("td.holdingbranch")?.textContent || "";
        const loanText = String(loansCell?.childNodes?.[0]?.textContent || loansCell?.textContent || "").trim();
        const loans = /^\s*\d+/.test(loanText) ? Number(loanText.match(/\d+/)[0]) : null;
        return {
            item_id: row.dataset.itemnumber || "",
            checkouts_count: loans,
            acquisition_date: acqCell?.textContent?.trim() || null,
            last_checkout_date: lastCell?.textContent?.trim() || null,
            location: location.trim(),
            home_library_id: home.trim(),
            holding_library_id: holding.trim(),
            _pmkRow: row
        };
    }

    async function runDetailDomFallback(table, domain, cfg) {
        const biblioNumber = getBiblioNumberFromPage();
        const items = Array.from(table.querySelectorAll("tbody tr")).map(function (row) { return legacyDomItemFromRow(row, table); });
        const creationDate = cfg.sources.fallbackToBiblioCreationDate ? await resolveBiblioCreationDate(biblioNumber, document, cfg) : null;
        const results = items.map(function (item) { return calculateItem(item, creationDate, domain, cfg); });
        const agg = aggregate(results, domain, cfg);
        agg.coverage={source:'dom',loaded:items.length,total:null,complete:false,reason:'lignes présentes dans la page uniquement'};
        injectStyles(cfg);
        clearInjected(document);
        insertDetailGlobal(table, agg, cfg);
        if (cfg.display.showItemIndicatorsOnDetail) {
            results.forEach(function (r) {
                const row = r.item._pmkRow;
                const cell = row ? (row.querySelector("td.issues") || findCellByHeader(table, row, ["prêt", "checkouts"])) : null;
                const el = cell ? createItemIndicator(r, domain, cfg) : null;
                if (cell && el) { cell.appendChild(document.createElement("br")); cell.appendChild(el); }
            });
        }
        dispatchResults("detail-dom-fallback", biblioNumber, agg, results);
    }

    function searchRows() {
        return Array.from(document.querySelectorAll('#searchresults tr[id^="row"], tr[id^="row"]')).filter(function (row) { return /^row\d+$/.test(row.id || ""); });
    }

    function biblioNumberFromRow(row) {
        const m = String(row.id || "").match(/^row(\d+)$/);
        return m ? m[1] : "";
    }

    function searchIndicatorAnchor(row) {
        return row.querySelector("td:nth-child(3) .kx-notice-cell") || row.querySelector("td:nth-child(3)") || row.querySelector("td");
    }

    function insertSearchGlobal(row, agg, cfg) {
        if (!cfg.display.showNoticeIndicator) return;
        row.querySelectorAll(`.${GLOBAL_OWN_CLASS}`).forEach(function (el) { el.remove(); });
        const anchor = searchIndicatorAnchor(row);
        if (!anchor) return;
        const div = createGlobalIndicator(agg, cfg, false);
        const copy = anchor.querySelector("span.copy-ean-result");
        if (copy && copy.parentNode) copy.parentNode.insertBefore(div, copy.nextSibling);
        else anchor.appendChild(div);
        mountConfigButton(div, "search");
    }

    async function processSearchRow(row, cfg) {
        const biblioNumber = biblioNumberFromRow(row);
        if (!biblioNumber) return;
        const [items, domain] = await Promise.all([
            fetchAllItems(biblioNumber, cfg).catch(function () { return []; }),
            resolveDomain(biblioNumber, row, cfg)
        ]);
        if (!items.length) return runSearchLegacyDomFallback(row, domain, cfg);
        const needsFallback = cfg.sources.fallbackToBiblioCreationDate && items.some(function (i) { return !parseDate(i.acquisition_date); });
        const creationDate = needsFallback ? await resolveBiblioCreationDate(biblioNumber, row, cfg) : null;
        const results = items.map(function (item) { return calculateItem(item, creationDate, domain, cfg); });
        const agg = aggregate(results, domain, cfg);
        agg.coverage=state.itemCoverage.get(String(biblioNumber));
        insertSearchGlobal(row, agg, cfg);
        dispatchResults("search", biblioNumber, agg, results);
    }

    async function runSearchLegacyDomFallback(row, domain, cfg) {
        const blocks = Array.from(row.querySelectorAll(".bloc-exemplaire, .kxri-item"));
        if (!blocks.length) return;
        const items = blocks.map(function (block) {
            const labels = {};
            block.querySelectorAll("li, .kxri-detail-label").forEach(function (node) {
                if (node.classList.contains("kxri-detail-label")) {
                    const value = node.nextElementSibling;
                    labels[norm(node.textContent)] = value ? value.textContent.trim() : "";
                } else {
                    const strong = node.querySelector("strong");
                    if (strong) labels[norm(strong.textContent.replace(/[:\s]+$/, ""))] = node.textContent.replace(strong.textContent, "").trim();
                }
            });
            const get = function (names) {
                for (const name of names) if (labels[norm(name)] !== undefined) return labels[norm(name)];
                return "";
            };
            return {
                item_id: block.dataset.itemId || "",
                checkouts_count: get(["Nombre de prêts", "Prêts", "Checkouts"]),
                acquisition_date: get(["Date de création", "Création", "Date d'acquisition"]),
                last_checkout_date: get(["Dernier emprunt", "Last checkout"]),
                location: get(["Localisation", "Location"]),
                holding_library_id: get(["Site actuel", "Holding library"]),
                home_library_id: get(["Site propriétaire", "Home library"])
            };
        });
        const biblioNumber = biblioNumberFromRow(row);
        const creationDate = cfg.sources.fallbackToBiblioCreationDate ? await resolveBiblioCreationDate(biblioNumber, row, cfg) : null;
        const results = items.map(function (item) { return calculateItem(item, creationDate, domain, cfg); });
        const agg = aggregate(results, domain, cfg);
        agg.coverage={source:'dom',loaded:items.length,total:null,complete:false,reason:'lignes présentes dans la page uniquement'};
        insertSearchGlobal(row, agg, cfg);
        dispatchResults("search-dom-fallback", biblioNumber, agg, results);
    }

    async function runSearch(cfg) {
        const rows = await waitForRows(20000);
        if (!rows.length) return;
        injectStyles(cfg);
        document.querySelectorAll(`.${GLOBAL_OWN_CLASS}`).forEach(function (el) { el.remove(); });
        await mapLimit(rows, cfg.api.concurrency, function (row) { return processSearchRow(row, cfg); });
    }

    async function mapLimit(values, limit, worker) {
        let index = 0;
        const runners = Array.from({ length: Math.min(limit, values.length) }, async function () {
            while (index < values.length) {
                const i = index++;
                try { await worker(values[i], i); } catch (_) {}
            }
        });
        await Promise.all(runners);
    }

    function waitForElement(getter, maxWaitMs) {
        return new Promise(function (resolve) {
            const existing = getter();
            if (existing) return resolve(existing);
            let done = false;
            const observer = new MutationObserver(function () {
                const el = getter();
                if (!el || done) return;
                done = true;
                observer.disconnect();
                resolve(el);
            });
            observer.observe(document.documentElement, { childList: true, subtree: true });
            window.setTimeout(function () {
                if (done) return;
                done = true;
                observer.disconnect();
                resolve(getter() || null);
            }, maxWaitMs || 10000);
        });
    }

    async function waitForRows(maxWaitMs) {
        const el = await waitForElement(function () { return searchRows()[0] || null; }, maxWaitMs);
        return el ? searchRows() : [];
    }

    function dispatchResults(page, biblioNumber, agg, results) {
        try {
            window.dispatchEvent(new CustomEvent("pmk:efficiency-results", {
                detail: {
                    moduleId: MODULE_ID,
                    page: page,
                    biblioNumber: String(biblioNumber || ""),
                    aggregate: clone(agg),
                    items: clone(results.map(function (r) {
                        return {
                            itemId: itemId(r.item),
                            score: r.score ?? null,
                            ignored: !!r.ignored,
                            error: r.error || null,
                            approximate: !!r.approximate,
                            special: !!r.special,
                            profile: r.profile || null,
                            classification: r.classification ? clone(r.classification) : null
                        };
                    }))
                }
            }));
        } catch (_) {}
    }

    async function applyConfig(input) {
        const cfg = normalizeConfig(input);
        state.config = cfg;
        clearInjected(document);
        if (!cfg.enabled) return;
        if (window.location.pathname === DETAIL_PATH && cfg.pages.detail.enabled) await runDetail(cfg);
        if (window.location.pathname === SEARCH_PATH && cfg.pages.search.enabled) await runSearch(cfg);
    }

    function scheduleRefresh() {
        if (state.refreshTimer) window.clearTimeout(state.refreshTimer);
        state.refreshTimer = window.setTimeout(function () {
            if (state.config) applyConfig(state.config).catch(function () {});
        }, 80);
    }

    function connectConfig() {
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            applyConfig(DEFAULTS).catch(function () {});
            return;
        }
        try {
            if (typeof window.PMKConfig.subscribe === "function") {
                window.PMKConfig.subscribe(MODULE_ID, function (cfg) { applyConfig(cfg).catch(function () {}); });
            }
        } catch (_) {}
        window.PMKConfig.getConfig(MODULE_ID).then(applyConfig).catch(function () { return applyConfig(DEFAULTS); });
    }

    function start() {
        if (window.location.pathname !== DETAIL_PATH && window.location.pathname !== SEARCH_PATH) return;
        connectConfig();
        // Les résultats de recherche peuvent être redessinés par d'autres modules ;
        // le 099 reste autonome et se recalcule sans dépendre de leur présence.
        const root = window.location.pathname === SEARCH_PATH ? (document.getElementById("searchresults") || document.body) : document.body;
        const observer = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (m) {
                return Array.from(m.addedNodes || []).some(function (n) {
                    return n instanceof Element && !n.closest?.(`.${GLOBAL_OWN_CLASS}`) && (n.matches?.('tr[id^="row"], table.items_table, #holdings_table') || n.querySelector?.('tr[id^="row"], table.items_table, #holdings_table'));
                });
            });
            if (relevant) scheduleRefresh();
        });
        observer.observe(root, { childList: true, subtree: true });
    }

    // API publique minimale, utile pour recette et future intégration plugin.
    window.PMK099Efficiency = Object.freeze({
        version: MODULE_VERSION,
        icons: ICONS,
        defaults: clone(DEFAULTS),
        normalizeConfig: normalizeConfig,
        calculateItem: function (item, creationDate, domain, cfg) { return calculateItem(item, creationDate, domain, normalizeConfig(cfg || DEFAULTS)); },
        helpHtml: function (cfg) { return helpHtml(normalizeConfig(cfg || state.config || DEFAULTS)); },
        refresh: scheduleRefresh
    });

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
})();

;window.PMKNonPlugin.loaded.push("099-efficiency-indicators.js");
} catch (error) { window.PMKNonPlugin.errors.push("099-efficiency-indicators.js: "+error.message); console.error("[PMK] 099-efficiency-indicators.js",error); };
try {
/*
 Nom du fichier : 101-koha-log.js
 Module PMK      : Journal Koha
 ID PMK          : log-viewer
 Version         : 2.1.0-pmk-isolated
 Date            : 2026-09-20

 Objectif :
 - améliorer la lisibilité de /tools/viewlog.pl sans remplacer les rendus natifs Koha ;
 - conserver les couleurs, badges et filtres rapides du 101 historique ;
 - utiliser les codes stables Koha pour les modules/actions ;
 - conserver les parseurs historiques $VAR1 / MARC uniquement comme fallbacks ;
 - respecter la colonne Diff native et les rendus structurés natifs des versions récentes ;
 - s'enregistrer directement dans PMK sans modification du socle 000.

 Principe impératif :
   KOHA NATIF D'ABORD -> AMELIORATION PMK -> FALLBACK LEGACY EN DERNIER.
*/
(function () {
    "use strict";

    const MODULE_ID = "log-viewer";
    const MODULE_VERSION = "2.1.0-pmk-isolated";
    const SCRIPT_GUARD = "__pmk101KohaLogV2";
    const STYLE_ID = "pmk101-koha-log-style";
    const PAGE_PATH = "/cgi-bin/koha/tools/viewlog.pl";
    const PAGE_ID = "tools.viewlog";
    const TOOLBAR_ID = "pmk101-log-toolbar";
    const GENERATED_ATTR = "data-pmk101-generated";

    if (window[SCRIPT_GUARD]) return;
    window[SCRIPT_GUARD] = true;

    /*
     * Valeurs historiques du 101.
     * Les actions sont maintenant identifiées par leurs codes Koha,
     * pas par leurs traductions visibles.
     */
    const ACTION_STYLE_KEY = {
        "ADD": "add",
        "CREATE": "create",
        "ADD_BASKET": "add",
        "CREATE_ORDER": "add",
        "CREATE_INVOICE_ADJUSTMENT": "add",
        "CREATE_FUND": "add",
        "CREATE_RESTRICTION": "delete",
        "ADDCIRCMESSAGE": "add",

        "DELETE": "delete",
        "CANCEL_ORDER": "delete",
        "DELETE_INVOICE_ADJUSTMENT": "delete",
        "DELETE_FUND": "delete",
        "DELCIRCMESSAGE": "delete",

        "MODIFY": "modify",
        "MODIFY_BASKET": "modify",
        "MODIFY_BASKET_HEADER": "modify",
        "MODIFY_BASKET_USERS": "modify",
        "MODIFY_ORDER": "modify",
        "UPDATE_INVOICE_ADJUSTMENT": "modify",
        "MODIFY_BUDGET": "modify",
        "MODIFY_FUND": "modify",
        "MODIFY_RESTRICTION": "modify",
        "MODCIRCMESSAGE": "modify",
        "MODIFY_CARDNUMBER": "modify",
        "CHANGE PASS": "modify",
        "RESET PASS": "modify",
        "RESET 2FA": "modify",
        "EDIT_MAPPINGS": "modify",
        "RESET_MAPPINGS": "modify",

        "ISSUE": "issue",
        "RENEW": "issue",
        "RENEWAL": "issue",

        "RETURN": "return",
        "RECEIVE_ORDER": "return",

        "CANCEL": "cancel",
        "SUSPEND": "cancel",

        "FILL": "create",
        "RESUME": "return",
        "Run": "cron",
        "RUN": "cron",
        "End": "cron",
        "END": "cron"
    };

    const DEFAULTS = {
        enabled: true,
        pages: {
            viewlog: {
                enabled: true,
                pageId: PAGE_ID,
                path: PAGE_PATH
            }
        },

        presentation: {
            colorRows: true,
            actionBadges: true,
            moduleBadges: true,
            compactInfo: true
        },

        filters: {
            enabled: true,
            showClearButton: true,
            showCronToggle: true,
            cronFilterTarget: "interface",
            moduleButtons: [
                { id: "cron", enabled: true, code: "CRONJOBS", labelFr: "Cron", labelEn: "Cron" },
                { id: "holds", enabled: true, code: "HOLDS", labelFr: "Réservations", labelEn: "Holds" },
                { id: "circulation", enabled: true, code: "CIRCULATION", labelFr: "Circulation", labelEn: "Circulation" },
                { id: "members", enabled: true, code: "MEMBERS", labelFr: "Adhérents", labelEn: "Patrons" },
                { id: "cataloguing", enabled: true, code: "CATALOGUING", labelFr: "Catalogage", labelEn: "Cataloging" },
                { id: "system-preferences", enabled: true, code: "SYSTEMPREFERENCE", labelFr: "Préf. système", labelEn: "System prefs" },
                { id: "acquisitions", enabled: true, code: "ACQUISITIONS", labelFr: "Acquisitions", labelEn: "Acquisitions" }
            ],
            actionButtons: [
                { id: "adds", enabled: true, codes: "ADD|CREATE", labelFr: "＋ Ajouts", labelEn: "＋ Adds" },
                { id: "deletes", enabled: true, codes: "DELETE", labelFr: "✕ Suppressions", labelEn: "✕ Deletes" },
                { id: "modifies", enabled: true, codes: "MODIFY", labelFr: "✎ Modifications", labelEn: "✎ Modifications" }
            ]
        },

        legacy: {
            enabled: true,
            parsePerlDump: true,
            parseMarcBeforeAfter: true,
            hideRawWhenEnhanced: true,
            minMarcTags: 8
        },

        colors: {
            rowAdd: "#d4edda",
            rowDelete: "#f8d7da",
            rowModify: "#fff3cd",
            rowCreate: "#cce5ff",
            rowIssue: "#d1ecf1",
            rowReturn: "#e8f5e9",
            rowCron: "#f3e5f5",
            rowCancel: "#f5f5f5",

            badgeAdd: "#28a745",
            badgeDelete: "#dc3545",
            badgeModify: "#fd7e14",
            badgeCreate: "#007bff",
            badgeIssue: "#17a2b8",
            badgeReturn: "#20c997",
            badgeCron: "#6f42c1",
            badgeCancel: "#868e96",

            moduleBorderAlpha: "55"
        },

        moduleStyles: [
            { code: "CRONJOBS", bg: "#e8eaf6", fg: "#3949ab" },
            { code: "HOLDS", bg: "#e3f2fd", fg: "#1565c0" },
            { code: "MEMBERS", bg: "#f3e5f5", fg: "#6a1b9a" },
            { code: "CATALOGUING", bg: "#e8f5e9", fg: "#2e7d32" },
            { code: "CIRCULATION", bg: "#fff8e1", fg: "#e65100" },
            { code: "SYSTEMPREFERENCE", bg: "#fce4ec", fg: "#ad1457" },
            { code: "ACQUISITIONS", bg: "#e0f2f1", fg: "#00695c" },
            { code: "AUTHORITIES", bg: "#f1f8e9", fg: "#558b2f" },
            { code: "AUTH", bg: "#fff3e0", fg: "#bf360c" },
            { code: "FINES", bg: "#efebe9", fg: "#4e342e" },
            { code: "SERIAL", bg: "#e8eaf6", fg: "#283593" },
            { code: "NOTICES", bg: "#f9fbe7", fg: "#827717" },
            { code: "REPORTS", bg: "#e0f7fa", fg: "#006064" },
            { code: "NEWS", bg: "#fffde7", fg: "#f57f17" },
            { code: "SUGGESTION", bg: "#fbe9e7", fg: "#bf360c" },
            { code: "ILL", bg: "#f0f4c3", fg: "#827717" },
            { code: "CLAIMS", bg: "#fce4ec", fg: "#880e4f" },
            { code: "RECALLS", bg: "#e1f5fe", fg: "#01579b" },
            { code: "SEARCHENGINE", bg: "#ede7f6", fg: "#4527a0" }
        ],

        behavior: {
            initDelayMs: 150,
            retryDelayMs: 300,
            retryCount: 20,
            observeMutations: true
        }
    };

    let currentConfig = clone(DEFAULTS);
    let pmkRegistered = false;
    let unsubscribe = null;
    let mutationObserver = null;
    let retryTimer = null;
    let started = false;
    let boundTableNode = null;

    const LEGACY_MODULE_LABELS = {
        "tâches cron": "CRONJOBS",
        "taches cron": "CRONJOBS",
        "cron jobs": "CRONJOBS",
        "réservations": "HOLDS",
        "reservations": "HOLDS",
        "holds": "HOLDS",
        "adhérents": "MEMBERS",
        "adherents": "MEMBERS",
        "patrons": "MEMBERS",
        "catalogage": "CATALOGUING",
        "cataloging": "CATALOGUING",
        "circulation": "CIRCULATION",
        "préférences système": "SYSTEMPREFERENCE",
        "preferences systeme": "SYSTEMPREFERENCE",
        "system preferences": "SYSTEMPREFERENCE",
        "acquisitions": "ACQUISITIONS",
        "autorités": "AUTHORITIES",
        "autorites": "AUTHORITIES",
        "authorities": "AUTHORITIES",
        "authentification": "AUTH",
        "authentication": "AUTH",
        "amendes": "FINES",
        "fines": "FINES",
        "périodiques": "SERIAL",
        "periodiques": "SERIAL",
        "serials": "SERIAL",
        "rapports": "REPORTS",
        "reports": "REPORTS",
        "annonces": "NEWS",
        "additional content": "NEWS",
        "suggestions": "SUGGESTION",
        "prêt entre bibliothèques": "ILL",
        "pret entre bibliotheques": "ILL",
        "interlibrary loans": "ILL",
        "réclamations": "CLAIMS",
        "reclamations": "CLAIMS",
        "claims": "CLAIMS",
        "rappels": "RECALLS",
        "recalls": "RECALLS",
        "moteur de recherche": "SEARCHENGINE",
        "search engine": "SEARCHENGINE"
    };

    const LEGACY_ACTION_LABELS = {
        "ajouter": "ADD",
        "add": "ADD",
        "créer": "CREATE",
        "creer": "CREATE",
        "create": "CREATE",
        "supprimer": "DELETE",
        "delete": "DELETE",
        "modifier": "MODIFY",
        "modify": "MODIFY",
        "prêt": "ISSUE",
        "pret": "ISSUE",
        "checkout": "ISSUE",
        "retour": "RETURN",
        "check-in": "RETURN",
        "check in": "RETURN",
        "renouveler": "RENEW",
        "renew": "RENEW",
        "annuler": "CANCEL",
        "cancel": "CANCEL",
        "remplir": "FILL",
        "fill": "FILL",
        "suspendre": "SUSPEND",
        "suspend": "SUSPEND",
        "reprendre": "RESUME",
        "resume": "RESUME",
        "exécuter": "Run",
        "executer": "Run",
        "run": "Run",
        "date de fin": "End",
        "end": "End",
        "changer le mot de passe": "CHANGE PASS",
        "change password": "CHANGE PASS",
        "réinitialiser le mot de passe": "RESET PASS",
        "reinitialiser le mot de passe": "RESET PASS",
        "reset password": "RESET PASS",
        "ajouter un message de circulation": "ADDCIRCMESSAGE",
        "add circulation message": "ADDCIRCMESSAGE",
        "modifier un message de circulation": "MODCIRCMESSAGE",
        "modify circulation message": "MODCIRCMESSAGE",
        "supprimer un message de circulation": "DELCIRCMESSAGE",
        "delete circulation message": "DELCIRCMESSAGE",
        "recevoir une commande": "RECEIVE_ORDER",
        "receive an order": "RECEIVE_ORDER",
        "ajouter une commande": "CREATE_ORDER",
        "create an order": "CREATE_ORDER",
        "annuler une commande": "CANCEL_ORDER",
        "cancel an order": "CANCEL_ORDER",
        "modifier une commande": "MODIFY_ORDER",
        "modify an order": "MODIFY_ORDER"
    };

    const KEY_FIELDS = [
        "borrowernumber", "biblionumber", "itemnumber",
        "reserve_id", "branchcode", "timestamp",
        "reservedate", "issuedate", "returndate", "date_due"
    ];

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function object(value) {
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    }

    function merge(base, extra) {
        const out = clone(base);
        if (!extra || typeof extra !== "object") return out;
        Object.keys(extra).forEach(function (key) {
            const incoming = extra[key];
            if (Array.isArray(incoming)) {
                out[key] = clone(incoming);
            } else if (
                incoming && typeof incoming === "object" && !Array.isArray(incoming) &&
                out[key] && typeof out[key] === "object" && !Array.isArray(out[key])
            ) {
                out[key] = merge(out[key], incoming);
            } else if (incoming !== undefined) {
                out[key] = incoming;
            }
        });
        return out;
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function normalizeText(value) {
        const raw = clean(value).toLowerCase();
        if (!raw) return "";
        try {
            return raw.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ");
        } catch (_) {
            return raw.replace(/\s+/g, " ");
        }
    }

    function normalizeCode(value) {
        return clean(value).toUpperCase();
    }

    function validColor(value, fallback) {
        const v = clean(value);
        return /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : fallback;
    }

    function clamp(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, Math.round(n)));
    }

    function language() {
        const api = pmkApi();
        if (api && typeof api.getLanguage === "function") {
            try { return api.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const htmlLang = clean(document.documentElement.getAttribute("lang")).toLowerCase();
        return htmlLang.indexOf("en") === 0 ? "en" : "fr";
    }

    function labelFor(item, fallbackCode) {
        const lang = language();
        const specific = lang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
        if (specific) return specific;
        return nativeModuleLabel(fallbackCode) || nativeActionLabel(fallbackCode) || fallbackCode;
    }

    function normalizeModuleButton(item, index) {
        const src = object(item);
        return {
            id: clean(src.id) || "module-" + (index + 1),
            enabled: src.enabled !== false,
            code: normalizeCode(src.code),
            labelFr: clean(src.labelFr),
            labelEn: clean(src.labelEn)
        };
    }

    function normalizeActionButton(item, index) {
        const src = object(item);
        const codes = clean(src.codes)
            .split("|")
            .map(function (v) { return normalizeCode(v); })
            .filter(Boolean)
            .join("|");
        return {
            id: clean(src.id) || "action-" + (index + 1),
            enabled: src.enabled !== false,
            codes: codes,
            labelFr: clean(src.labelFr),
            labelEn: clean(src.labelEn)
        };
    }

    function normalizeModuleStyle(item) {
        const src = object(item);
        return {
            code: normalizeCode(src.code),
            bg: validColor(src.bg, "#e9ecef"),
            fg: validColor(src.fg, "#495057")
        };
    }

    function normalizeConfig(config) {
        const cfg = merge(DEFAULTS, object(config));

        cfg.enabled = cfg.enabled !== false;
        cfg.pages = merge(DEFAULTS.pages, object(cfg.pages));
        cfg.pages.viewlog = merge(DEFAULTS.pages.viewlog, object(cfg.pages.viewlog));
        // Fold the former page switch once; retain its original value and all custom fields.
        if (!cfg.activationUnified) {
            cfg.activationBeforeUnification = {enabled:cfg.enabled, pageEnabled:cfg.pages.viewlog.enabled};
            cfg.enabled = cfg.enabled && cfg.pages.viewlog.enabled !== false;
            cfg.activationUnified = true;
        }
        cfg.pages.viewlog.enabled = true;
        cfg.pages.viewlog.pageId = PAGE_ID;
        cfg.pages.viewlog.path = PAGE_PATH;

        cfg.presentation = merge(DEFAULTS.presentation, object(cfg.presentation));
        cfg.presentation.colorRows = cfg.presentation.colorRows !== false;
        cfg.presentation.actionBadges = cfg.presentation.actionBadges !== false;
        cfg.presentation.moduleBadges = cfg.presentation.moduleBadges !== false;
        cfg.presentation.compactInfo = cfg.presentation.compactInfo !== false;

        cfg.filters = merge(DEFAULTS.filters, object(cfg.filters));
        cfg.filters.enabled = cfg.filters.enabled !== false;
        cfg.filters.showClearButton = cfg.filters.showClearButton !== false;
        cfg.filters.showCronToggle = cfg.filters.showCronToggle !== false;
        cfg.filters.cronFilterTarget = cfg.filters.cronFilterTarget === "module" ? "module" : "interface";
        cfg.filters.moduleButtons = Array.isArray(cfg.filters.moduleButtons)
            ? cfg.filters.moduleButtons.map(normalizeModuleButton)
            : clone(DEFAULTS.filters.moduleButtons);
        cfg.filters.actionButtons = Array.isArray(cfg.filters.actionButtons)
            ? cfg.filters.actionButtons.map(normalizeActionButton)
            : clone(DEFAULTS.filters.actionButtons);

        cfg.legacy = merge(DEFAULTS.legacy, object(cfg.legacy));
        cfg.legacy.enabled = cfg.legacy.enabled !== false;
        cfg.legacy.parsePerlDump = cfg.legacy.parsePerlDump !== false;
        cfg.legacy.parseMarcBeforeAfter = cfg.legacy.parseMarcBeforeAfter !== false;
        cfg.legacy.hideRawWhenEnhanced = cfg.legacy.hideRawWhenEnhanced !== false;
        cfg.legacy.minMarcTags = clamp(cfg.legacy.minMarcTags, 2, 100, DEFAULTS.legacy.minMarcTags);

        cfg.colors = merge(DEFAULTS.colors, object(cfg.colors));
        Object.keys(DEFAULTS.colors).forEach(function (key) {
            if (key === "moduleBorderAlpha") return;
            cfg.colors[key] = validColor(cfg.colors[key], DEFAULTS.colors[key]);
        });
        cfg.colors.moduleBorderAlpha = /^[0-9a-f]{2}$/i.test(clean(cfg.colors.moduleBorderAlpha))
            ? clean(cfg.colors.moduleBorderAlpha).toLowerCase()
            : DEFAULTS.colors.moduleBorderAlpha;

        cfg.moduleStyles = Array.isArray(cfg.moduleStyles)
            ? cfg.moduleStyles.map(normalizeModuleStyle).filter(function (x) { return x.code; })
            : clone(DEFAULTS.moduleStyles);

        cfg.behavior = merge(DEFAULTS.behavior, object(cfg.behavior));
        cfg.behavior.initDelayMs = clamp(cfg.behavior.initDelayMs, 0, 5000, DEFAULTS.behavior.initDelayMs);
        cfg.behavior.retryDelayMs = clamp(cfg.behavior.retryDelayMs, 50, 3000, DEFAULTS.behavior.retryDelayMs);
        cfg.behavior.retryCount = clamp(cfg.behavior.retryCount, 1, 100, DEFAULTS.behavior.retryCount);
        cfg.behavior.observeMutations = cfg.behavior.observeMutations !== false;

        return cfg;
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        const ids = {};
        for (let i = 0; i < cfg.filters.moduleButtons.length; i += 1) {
            const item = cfg.filters.moduleButtons[i];
            if (!item.enabled) continue;
            if (!item.code) return { ok: false, message: "Chaque filtre de module actif doit avoir un code Koha." };
            if (ids["m:" + item.id]) return { ok: false, message: "Chaque filtre de module doit avoir un identifiant unique." };
            ids["m:" + item.id] = true;
        }
        for (let i = 0; i < cfg.filters.actionButtons.length; i += 1) {
            const item = cfg.filters.actionButtons[i];
            if (!item.enabled) continue;
            if (!item.codes) return { ok: false, message: "Chaque filtre d’action actif doit contenir au moins un code Koha." };
            if (ids["a:" + item.id]) return { ok: false, message: "Chaque filtre d’action doit avoir un identifiant unique." };
            ids["a:" + item.id] = true;
        }
        return { ok: true };
    }

    function pmkApi() {
        return window.PMKConfig && typeof window.PMKConfig === "object" ? window.PMKConfig : null;
    }

    function newModuleFilter() {
        return {
            id: "module-" + Date.now().toString(36),
            enabled: true,
            code: "",
            labelFr: "",
            labelEn: ""
        };
    }

    function newActionFilter() {
        return {
            id: "action-" + Date.now().toString(36),
            enabled: true,
            codes: "",
            labelFr: "",
            labelEn: ""
        };
    }

    function newModuleStyle() {
        return {
            code: "",
            bg: "#e9ecef",
            fg: "#495057"
        };
    }

    function registerPmkDefinition() {
        const api = pmkApi();
        if (!api || typeof api.registerModule !== "function") return false;
        if (pmkRegistered) return true;

        try {
            api.registerModule({
                id: MODULE_ID,
                schemaVersion: 2,
                compactActivation: true,
                hidePageCount: true,
                name: {
                    fr: "Journal des modifications Koha",
                    en: "Koha change log"
                },
                description: {
                    fr: "Améliore la lisibilité du visualiseur de logs sans remplacer les fonctions natives de Koha. Les rendus structurés et la colonne Diff natives restent prioritaires ; les parseurs historiques ne servent qu’en fallback.",
                    en: "Improves the Koha log viewer without replacing native features. Native structured rendering and Diff stay authoritative; historical parsers are fallback-only."
                },
                category: {
                    fr: "Outils / administration",
                    en: "Tools / administration"
                },
                supportedPages: [PAGE_ID],
                prerequisites: [],
                dependencies: [],
                defaults: clone(DEFAULTS),
                normalize: normalizeConfig,
                validate: validateConfig,
                schema: [
                    {
                        type: "section",
                        id: "activation",
                        label: { fr: "Activation", en: "Activation" },
                        fields: [
                            { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                            { key: "pages.viewlog.path", type: "readonly", advanced: true, label: { fr: "Page Koha", en: "Koha page" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "presentation",
                        label: { fr: "Présentation", en: "Presentation" },
                        description: {
                            fr: "Ces réglages reprennent par défaut le rendu historique du 101, sans toucher aux contenus natifs Koha.",
                            en: "Defaults preserve the historical 101 appearance without replacing native Koha content."
                        },
                        fields: [
                            { key: "presentation.colorRows", type: "boolean", label: { fr: "Colorer les lignes selon l’action", en: "Color rows by action" } },
                            { key: "presentation.actionBadges", type: "boolean", label: { fr: "Afficher les actions sous forme de badges", en: "Show action badges" } },
                            { key: "presentation.moduleBadges", type: "boolean", label: { fr: "Afficher les modules sous forme de badges", en: "Show module badges" } },
                            { key: "presentation.compactInfo", type: "boolean", label: { fr: "Limiter la largeur de la zone Info", en: "Keep Info area compact" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "filters",
                        label: { fr: "Filtres rapides", en: "Quick filters" },
                        description: {
                            fr: "Les filtres utilisent les codes Koha stables et non les traductions affichées. Vous pouvez ajouter vos propres modules/actions.",
                            en: "Filters use stable Koha codes rather than displayed translations. You can add your own modules/actions."
                        },
                        fields: [
                            { key: "filters.enabled", type: "boolean", label: { fr: "Afficher la barre de filtres", en: "Show filter toolbar" } },
                            { key: "filters.showClearButton", type: "boolean", label: { fr: "Afficher « Effacer les filtres »", en: "Show “Clear filters”" } },
                            { key: "filters.showCronToggle", type: "boolean", label: { fr: "Afficher « Masquer cron »", en: "Show “Hide cron”" } },
                            {
                                key: "filters.cronFilterTarget",
                                type: "select",
                                advanced: true,
                                label: { fr: "Ce que « Masquer cron » filtre", en: "What “Hide cron” filters" },
                                options: [
                                    { value: "interface", label: { fr: "Interface CRON (comportement historique)", en: "CRON interface (historical behavior)" } },
                                    { value: "module", label: { fr: "Module CRONJOBS", en: "CRONJOBS module" } }
                                ]
                            },
                            {
                                key: "filters.moduleButtons",
                                type: "repeater",
                                label: { fr: "Boutons de modules", en: "Module buttons" },
                                addLabel: { fr: "Ajouter un module", en: "Add module" },
                                emptyLabel: { fr: "Aucun filtre de module.", en: "No module filter." },
                                reorder: true,
                                newItem: newModuleFilter,
                                itemTitle: function (item, index, lang) {
                                    const label = lang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
                                    return label || clean(item && item.code) || ((lang === "en" ? "Module " : "Module ") + (index + 1));
                                },
                                fields: [
                                    { key: "enabled", type: "boolean", label: { fr: "Actif", en: "Enabled" } },
                                    { key: "code", type: "text", label: { fr: "Code Koha", en: "Koha code" }, help: { fr: "Ex. CATALOGUING, MEMBERS, HOLDS.", en: "E.g. CATALOGUING, MEMBERS, HOLDS." } },
                                    { key: "labelFr", type: "text", label: { fr: "Libellé FR (vide = libellé Koha)", en: "French label (blank = Koha label)" } },
                                    { key: "labelEn", type: "text", label: { fr: "Libellé EN (vide = libellé Koha)", en: "English label (blank = Koha label)" } }
                                ]
                            },
                            {
                                key: "filters.actionButtons",
                                type: "repeater",
                                label: { fr: "Boutons d’actions", en: "Action buttons" },
                                addLabel: { fr: "Ajouter un filtre d’action", en: "Add action filter" },
                                emptyLabel: { fr: "Aucun filtre d’action.", en: "No action filter." },
                                reorder: true,
                                newItem: newActionFilter,
                                itemTitle: function (item, index, lang) {
                                    const label = lang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
                                    return label || clean(item && item.codes) || ((lang === "en" ? "Action " : "Action ") + (index + 1));
                                },
                                fields: [
                                    { key: "enabled", type: "boolean", label: { fr: "Actif", en: "Enabled" } },
                                    { key: "codes", type: "text", label: { fr: "Codes Koha", en: "Koha codes" }, help: { fr: "Séparer plusieurs codes par |. Ex. ADD|CREATE.", en: "Separate multiple codes with |. E.g. ADD|CREATE." } },
                                    { key: "labelFr", type: "text", label: { fr: "Libellé FR", en: "French label" } },
                                    { key: "labelEn", type: "text", label: { fr: "Libellé EN", en: "English label" } }
                                ]
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "legacy",
                        label: { fr: "Compatibilité avec les anciens logs", en: "Legacy log compatibility" },
                        description: {
                            fr: "Ces fonctions ne s’activent que lorsque Koha n’a pas déjà fourni un rendu structuré ou un Diff natif.",
                            en: "These functions activate only when Koha has not already supplied structured rendering or a native Diff."
                        },
                        fields: [
                            { key: "legacy.enabled", type: "boolean", label: { fr: "Activer les fallbacks historiques", en: "Enable historical fallbacks" } },
                            { key: "legacy.parsePerlDump", type: "boolean", label: { fr: "Structurer les anciens dumps $VAR1", en: "Structure old $VAR1 dumps" } },
                            { key: "legacy.parseMarcBeforeAfter", type: "boolean", label: { fr: "Comparer les anciens blocs MARC BEFORE/AFTER", en: "Compare old MARC BEFORE/AFTER blocks" } },
                            { key: "legacy.hideRawWhenEnhanced", type: "boolean", label: { fr: "Masquer le texte brut lorsqu’un fallback lisible est disponible", en: "Hide raw text when a readable fallback is available" } },
                            { key: "legacy.minMarcTags", type: "number", advanced: true, min: 2, max: 100, label: { fr: "Nombre minimal de tags MARC pour reconnaître un bloc", en: "Minimum MARC tags to recognize a block" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "colors",
                        label: { fr: "Couleurs", en: "Colors" },
                        description: {
                            fr: "Valeurs par défaut identiques au 101 historique.",
                            en: "Default values match the historical 101."
                        },
                        fields: [
                            { key: "colors.rowAdd", type: "color", label: { fr: "Ligne — ajout", en: "Row — add" } },
                            { key: "colors.rowDelete", type: "color", label: { fr: "Ligne — suppression", en: "Row — delete" } },
                            { key: "colors.rowModify", type: "color", label: { fr: "Ligne — modification", en: "Row — modify" } },
                            { key: "colors.rowCreate", type: "color", label: { fr: "Ligne — création", en: "Row — create" } },
                            { key: "colors.rowIssue", type: "color", label: { fr: "Ligne — prêt/renouvellement", en: "Row — checkout/renewal" } },
                            { key: "colors.rowReturn", type: "color", label: { fr: "Ligne — retour", en: "Row — check-in" } },
                            { key: "colors.rowCron", type: "color", label: { fr: "Ligne — cron", en: "Row — cron" } },
                            { key: "colors.rowCancel", type: "color", label: { fr: "Ligne — annulation/suspension", en: "Row — cancel/suspend" } },

                            { key: "colors.badgeAdd", type: "color", advanced: true, label: { fr: "Badge — ajout", en: "Badge — add" } },
                            { key: "colors.badgeDelete", type: "color", advanced: true, label: { fr: "Badge — suppression", en: "Badge — delete" } },
                            { key: "colors.badgeModify", type: "color", advanced: true, label: { fr: "Badge — modification", en: "Badge — modify" } },
                            { key: "colors.badgeCreate", type: "color", advanced: true, label: { fr: "Badge — création", en: "Badge — create" } },
                            { key: "colors.badgeIssue", type: "color", advanced: true, label: { fr: "Badge — prêt", en: "Badge — checkout" } },
                            { key: "colors.badgeReturn", type: "color", advanced: true, label: { fr: "Badge — retour", en: "Badge — check-in" } },
                            { key: "colors.badgeCron", type: "color", advanced: true, label: { fr: "Badge — cron", en: "Badge — cron" } },
                            { key: "colors.badgeCancel", type: "color", advanced: true, label: { fr: "Badge — annulation", en: "Badge — cancel" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "modules",
                        label: { fr: "Couleurs des modules", en: "Module colors" },
                        fields: [
                            {
                                key: "moduleStyles",
                                type: "repeater",
                                label: { fr: "Styles des modules", en: "Module styles" },
                                addLabel: { fr: "Ajouter un module", en: "Add module" },
                                emptyLabel: { fr: "Aucun style spécifique.", en: "No specific style." },
                                reorder: true,
                                newItem: newModuleStyle,
                                itemTitle: function (item, index) {
                                    return clean(item && item.code) || ("Module " + (index + 1));
                                },
                                fields: [
                                    { key: "code", type: "text", label: { fr: "Code Koha", en: "Koha code" } },
                                    { key: "bg", type: "color", label: { fr: "Fond", en: "Background" } },
                                    { key: "fg", type: "color", label: { fr: "Texte / bordure", en: "Text / border" } }
                                ]
                            }
                        ]
                    },
                    {
                        type: "section",
                        id: "behavior",
                        label: { fr: "Compatibilité technique", en: "Technical compatibility" },
                        fields: [
                            { key: "behavior.observeMutations", type: "boolean", label: { fr: "Suivre les reconstructions du tableau", en: "Watch table rebuilds" } },
                            { key: "behavior.initDelayMs", type: "number", advanced: true, min: 0, max: 5000, label: { fr: "Délai initial (ms)", en: "Initial delay (ms)" } },
                            { key: "behavior.retryDelayMs", type: "number", advanced: true, min: 50, max: 3000, label: { fr: "Délai entre tentatives (ms)", en: "Retry delay (ms)" } },
                            { key: "behavior.retryCount", type: "number", advanced: true, min: 1, max: 100, label: { fr: "Nombre maximal de tentatives", en: "Maximum retry count" } }
                        ]
                    }
                ],
                focusContext: function (main, context) {
                    if (!main) return;
                    const wanted = context && context.sectionId ? context.sectionId : "presentation";
                    const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                    if (!section) return;
                    window.setTimeout(function () {
                        try { section.scrollIntoView({ block: "start", behavior: "smooth" }); } catch (_) {}
                    }, 60);
                }
            });
            pmkRegistered = true;
            return true;
        } catch (_) {
            return false;
        }
    }

    if (!registerPmkDefinition()) {
        window.addEventListener("pmk:config-ready", function () {
            registerPmkDefinition();
        }, { once: true });
    }

    function onTargetPage() {
        return (window.location.pathname || "").indexOf("/tools/viewlog.pl") !== -1;
    }

    function cssVars(config) {
        const c = config.colors;
        return [
            "--pmk101-row-add:" + c.rowAdd,
            "--pmk101-row-delete:" + c.rowDelete,
            "--pmk101-row-modify:" + c.rowModify,
            "--pmk101-row-create:" + c.rowCreate,
            "--pmk101-row-issue:" + c.rowIssue,
            "--pmk101-row-return:" + c.rowReturn,
            "--pmk101-row-cron:" + c.rowCron,
            "--pmk101-row-cancel:" + c.rowCancel,

            "--pmk101-badge-add:" + c.badgeAdd,
            "--pmk101-badge-delete:" + c.badgeDelete,
            "--pmk101-badge-modify:" + c.badgeModify,
            "--pmk101-badge-create:" + c.badgeCreate,
            "--pmk101-badge-issue:" + c.badgeIssue,
            "--pmk101-badge-return:" + c.badgeReturn,
            "--pmk101-badge-cron:" + c.badgeCron,
            "--pmk101-badge-cancel:" + c.badgeCancel
        ].join(";");
    }

    function ensureStyle(config) {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }

        style.textContent = [
            ":root{" + cssVars(config) + "}",
            "#logst tbody tr.pmk101-row-add{background-color:var(--pmk101-row-add)!important}",
            "#logst tbody tr.pmk101-row-delete{background-color:var(--pmk101-row-delete)!important}",
            "#logst tbody tr.pmk101-row-modify{background-color:var(--pmk101-row-modify)!important}",
            "#logst tbody tr.pmk101-row-create{background-color:var(--pmk101-row-create)!important}",
            "#logst tbody tr.pmk101-row-issue{background-color:var(--pmk101-row-issue)!important}",
            "#logst tbody tr.pmk101-row-return{background-color:var(--pmk101-row-return)!important}",
            "#logst tbody tr.pmk101-row-cron{background-color:var(--pmk101-row-cron)!important}",
            "#logst tbody tr.pmk101-row-cancel{background-color:var(--pmk101-row-cancel)!important}",
            "#logst tbody tr[class*='pmk101-row-']:hover{filter:brightness(.96)}",

            ".pmk101-action-badge,.pmk101-module-badge{display:inline-flex;align-items:center;max-width:100%;padding:.16rem .48rem;border-radius:.28rem;font-size:.82em;font-weight:650;line-height:1.25;white-space:normal}",
            ".pmk101-action-badge{color:#fff;border:1px solid transparent}",
            ".pmk101-action-add{background:var(--pmk101-badge-add)}",
            ".pmk101-action-delete{background:var(--pmk101-badge-delete)}",
            ".pmk101-action-modify{background:var(--pmk101-badge-modify)}",
            ".pmk101-action-create{background:var(--pmk101-badge-create)}",
            ".pmk101-action-issue{background:var(--pmk101-badge-issue)}",
            ".pmk101-action-return{background:var(--pmk101-badge-return)}",
            ".pmk101-action-cron{background:var(--pmk101-badge-cron)}",
            ".pmk101-action-cancel{background:var(--pmk101-badge-cancel)}",

            ".pmk101-info-compact{max-width:420px}",
".pmk101-plain-info{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,\"Liberation Mono\",monospace;font-size:.82em;background:#f8f9fa;padding:.2rem .45rem;border:1px solid #dee2e6;border-radius:.25rem;white-space:pre-wrap;word-break:break-word}",
            ".pmk101-legacy-raw-hidden>.pmk101-native-raw{display:none}",
            ".pmk101-legacy-helper{margin-top:.35rem}",
            ".pmk101-legacy-actions{display:flex;gap:.35rem;flex-wrap:wrap;margin:.25rem 0}",
            ".pmk101-toggle{font-size:.78em;padding:.12rem .45rem;border:1px solid #adb5bd;border-radius:.25rem;background:var(--bs-body-bg,#fff);color:inherit;cursor:pointer}",
            ".pmk101-toggle:hover{background:rgba(0,0,0,.05)}",
            ".pmk101-chips{display:flex;flex-wrap:wrap;gap:.25rem;margin:.25rem 0}",
            ".pmk101-chip{background:#e9ecef;padding:.08rem .38rem;border-radius:.22rem;font-size:.8em;line-height:1.65}",
            ".pmk101-detail-table{font-size:.82em;border-collapse:collapse;width:100%;margin-top:.35rem}",
            ".pmk101-detail-table td{padding:.15rem .45rem;border-bottom:1px solid #eee;vertical-align:top}",
            ".pmk101-detail-table td:first-child{color:#6c757d;white-space:nowrap;font-weight:600;width:1%}",
            ".pmk101-raw{font-size:.78em;margin-top:.3rem;padding:.35rem .5rem;background:#f8f9fa;border:1px solid #dee2e6;border-radius:.25rem;max-height:180px;overflow:auto;white-space:pre-wrap;word-break:break-word}",
            ".pmk101-marc{border:1px solid #d7dde4;border-radius:.45rem;background:#fcfdff;overflow:hidden;margin-top:.35rem}",
            ".pmk101-marc-head{display:flex;justify-content:space-between;gap:.5rem;padding:.4rem .55rem;background:#f4f7fb;border-bottom:1px solid #e5e9ef;font-size:.82em}",
            ".pmk101-marc-title{font-weight:700}",
            ".pmk101-marc-stats{color:#64748b}",
            ".pmk101-marc-compare{display:grid;grid-template-columns:64px 1fr 1fr}",
            ".pmk101-marc-compare>div{padding:.35rem .48rem;border-top:1px dotted #edf2f7;min-width:0;word-break:break-word}",
            ".pmk101-marc-compare .pmk101-tag{font-weight:700;color:#1d4ed8}",
            ".pmk101-diff-added{background:#e8f8ec}",
            ".pmk101-diff-removed{background:#fdecee}",
            ".pmk101-diff-changed{background:#fff9e7}",
            ".pmk101-diff-summary{margin:0 0 .35rem;padding:.3rem .45rem;border-left:3px solid #6c8ebf;background:#f4f7fb;font-size:.8em}",
            ".pmk101-diff-summary.is-missing{border-left-color:#c58a00;background:#fff9e7}",
            ".pmk101-marc-colhead{font-size:.78em;font-weight:700;color:#475569;background:#f8fafc;border-top:0!important}",

            "#" + TOOLBAR_ID + "{margin:.5rem 0 .65rem;padding:.5rem .65rem;background:rgba(0,0,0,.025);border:1px solid #dee2e6;border-radius:.35rem;display:flex;flex-wrap:wrap;gap:.28rem;align-items:center}",
            "#" + TOOLBAR_ID + " .pmk101-lbl{font-size:.8em;font-weight:700;color:#6c757d;margin-right:.08rem}",
            "#" + TOOLBAR_ID + " .pmk101-sep{border-left:1px solid #ced4da;height:1.15rem;margin:0 .25rem}",
            "#" + TOOLBAR_ID + " button{font-size:.8em;padding:.17rem .5rem}",
            "#" + TOOLBAR_ID + " button.pmk101-active{background:#343a40;color:#fff;border-color:#343a40}",
            "@media(max-width:768px){#"+TOOLBAR_ID+"{align-items:stretch}.pmk101-marc-compare{grid-template-columns:48px 1fr 1fr}.pmk101-info-compact{max-width:none}}"
        ].join("\n");
    }

    function nativeModuleLabel(code) {
        const c = normalizeCode(code);
        try {
            if (window.module_labels && window.module_labels[c]) {
                const tmp = document.createElement("div");
                tmp.innerHTML = String(window.module_labels[c]);
                return clean(tmp.textContent) || c;
            }
        } catch (_) {}
        return "";
    }

    function nativeActionLabel(code) {
        const c = clean(code);
        try {
            if (window.action_labels) {
                if (window.action_labels[c]) {
                    const tmp = document.createElement("div");
                    tmp.innerHTML = String(window.action_labels[c]);
                    return clean(tmp.textContent) || c;
                }
                const upper = normalizeCode(c);
                if (window.action_labels[upper]) {
                    const tmp2 = document.createElement("div");
                    tmp2.innerHTML = String(window.action_labels[upper]);
                    return clean(tmp2.textContent) || upper;
                }
            }
        } catch (_) {}
        return "";
    }

    function reverseLookupLabel(mapObject, visibleText) {
        if (!mapObject || typeof mapObject !== "object") return "";
        const wanted = normalizeText(visibleText);
        const keys = Object.keys(mapObject);
        for (let i = 0; i < keys.length; i += 1) {
            const tmp = document.createElement("div");
            tmp.innerHTML = String(mapObject[keys[i]]);
            if (normalizeText(tmp.textContent) === wanted) return keys[i];
        }
        return "";
    }

    function inferModuleCode(visibleText) {
        try {
            const code = reverseLookupLabel(window.module_labels, visibleText);
            if (code) return normalizeCode(code);
        } catch (_) {}
        return LEGACY_MODULE_LABELS[normalizeText(visibleText)] || normalizeCode(visibleText);
    }

    function inferActionCode(visibleText) {
        try {
            const code = reverseLookupLabel(window.action_labels, visibleText);
            if (code) return clean(code);
        } catch (_) {}
        return LEGACY_ACTION_LABELS[normalizeText(visibleText)] || clean(visibleText);
    }

    function getDT() {
        try {
            if (
                window.jQuery &&
                window.jQuery.fn &&
                window.jQuery.fn.dataTable &&
                window.jQuery.fn.dataTable.isDataTable("#logst")
            ) {
                return window.jQuery("#logst").DataTable();
            }
        } catch (_) {}
        return null;
    }

    function columnIndexByData(dt, key, fallback) {
        try {
            if (dt && dt.settings) {
                const settings = dt.settings()[0];
                const columns = settings && settings.aoColumns ? settings.aoColumns : [];
                for (let i = 0; i < columns.length; i += 1) {
                    const dataKey = columns[i].mData != null ? columns[i].mData : columns[i].data;
                    if (dataKey === key) return i;
                }
            }
        } catch (_) {}

        const table = document.querySelector("#logst");
        if (table) {
            const headers = Array.from(table.querySelectorAll("thead th"));
            const aliases = {
                module: ["module"],
                action: ["action"],
                info: ["info"],
                interface: ["interface"],
                diff: ["diff"]
            };
            for (let i = 0; i < headers.length; i += 1) {
                const dataColname = clean(headers[i].getAttribute("data-colname")).toLowerCase();
                if (dataColname === key) return i;
                const text = normalizeText(headers[i].textContent);
                if ((aliases[key] || []).some(function (a) { return text === a; })) return i;
            }
        }
        return fallback;
    }

    function rowData(dt, row) {
        try {
            if (dt) return dt.row(row).data() || null;
        } catch (_) {}
        return null;
    }

    function unwrapGenerated(root) {
        const scope = root || document;
        Array.from(scope.querySelectorAll("[" + GENERATED_ATTR + "='badge']")).forEach(function (node) {
            const parent = node.parentNode;
            if (!parent) return;
            while (node.firstChild) parent.insertBefore(node.firstChild, node);
            parent.removeChild(node);
        });
        Array.from(scope.querySelectorAll("[" + GENERATED_ATTR + "='legacy']")).forEach(function (node) {
            try { node.remove(); } catch (_) {
                if (node.parentNode) node.parentNode.removeChild(node);
            }
        });
        Array.from(scope.querySelectorAll(".pmk101-native-raw")).forEach(function (node) {
            node.classList.remove("pmk101-native-raw");
            node.style.display = "";
        });
        Array.from(scope.querySelectorAll(".pmk101-legacy-raw-hidden")).forEach(function (node) {
            node.classList.remove("pmk101-legacy-raw-hidden");
        });
        Array.from(scope.querySelectorAll(".pmk101-info-compact")).forEach(function (node) {
            node.classList.remove("pmk101-info-compact");
        });
        Array.from(scope.querySelectorAll(".pmk101-plain-info")).forEach(function (node) {
            node.classList.remove("pmk101-plain-info");
        });
        Array.from(scope.querySelectorAll("#logst tbody tr")).forEach(function (row) {
            [
                "pmk101-row-add", "pmk101-row-delete", "pmk101-row-modify", "pmk101-row-create",
                "pmk101-row-issue", "pmk101-row-return", "pmk101-row-cron", "pmk101-row-cancel",
                "pmk101-enhanced"
            ].forEach(function (cls) { row.classList.remove(cls); });
        });
    }

    function wrapCellBadge(cell, className, style) {
        if (!cell || cell.querySelector("[" + GENERATED_ATTR + "='badge']")) return;
        const span = document.createElement("span");
        span.setAttribute(GENERATED_ATTR, "badge");
        span.className = className;
        if (style) {
            if (style.background) span.style.background = style.background;
            if (style.color) span.style.color = style.color;
            if (style.borderColor) span.style.borderColor = style.borderColor;
        }
        while (cell.firstChild) span.appendChild(cell.firstChild);
        cell.appendChild(span);
    }

    function moduleStyleFor(code, config) {
        const wanted = normalizeCode(code);
        for (let i = 0; i < config.moduleStyles.length; i += 1) {
            if (normalizeCode(config.moduleStyles[i].code) === wanted) return config.moduleStyles[i];
        }
        return null;
    }

    function actionStyleKey(code) {
        const raw = clean(code);
        return ACTION_STYLE_KEY[raw] || ACTION_STYLE_KEY[normalizeCode(raw)] || "";
    }

    function enhanceRow(row, dt, config) {
        if (!row || !config.enabled) return;
        const cells = row.querySelectorAll("td");
        if (!cells.length) return;

        const moduleIndex = columnIndexByData(dt, "module", 2);
        const actionIndex = columnIndexByData(dt, "action", 3);
        const infoIndex = columnIndexByData(dt, "info", 5);
        const diffIndex = columnIndexByData(dt, "diff", 7);

        const data = rowData(dt, row);
        const moduleCell = cells[moduleIndex];
        const actionCell = cells[actionIndex];
        const infoCell = cells[infoIndex];
        const diffCell = cells[diffIndex];

        const moduleCode = data && data.module != null
            ? normalizeCode(data.module)
            : inferModuleCode(moduleCell ? moduleCell.textContent : "");
        const actionCode = data && data.action != null
            ? clean(data.action)
            : inferActionCode(actionCell ? actionCell.textContent : "");
        const styleKey = actionStyleKey(actionCode);

        if (config.presentation.colorRows && styleKey) {
            row.classList.add("pmk101-row-" + styleKey);
        }

        if (config.presentation.actionBadges && actionCell && styleKey) {
            wrapCellBadge(actionCell, "pmk101-action-badge pmk101-action-" + styleKey);
        }

        if (config.presentation.moduleBadges && moduleCell && moduleCode) {
            const moduleStyle = moduleStyleFor(moduleCode, config);
            if (moduleStyle) {
                wrapCellBadge(moduleCell, "pmk101-module-badge", {
                    background: moduleStyle.bg,
                    color: moduleStyle.fg,
                    borderColor: moduleStyle.fg + config.colors.moduleBorderAlpha
                });
            }
        }

        if (config.presentation.compactInfo && infoCell) {
            const logInfo = infoCell.querySelector(".loginfo") || infoCell;
            logInfo.classList.add("pmk101-info-compact");
        }

        if (config.legacy.enabled && infoCell) {
            enhanceLegacyInfo(row, infoCell, diffCell, data, config);
        }

        summarizeNativeDiff(row, diffCell, data, actionCode);

        row.classList.add("pmk101-enhanced");
    }

    function enhanceAllRows(config) {
        if (!onTargetPage()) return;
        const table = document.querySelector("#logst");
        if (!table) return;
        const dt = getDT();
        Array.from(table.querySelectorAll("tbody tr")).forEach(function (row) {
            // Les redraws remplacent souvent les lignes. Pour une ligne existante,
            // repartir proprement permet d'appliquer immédiatement une nouvelle config.
            if (row.classList.contains("pmk101-enhanced")) {
                unwrapGenerated(row);
            }
            enhanceRow(row, dt, config);
        });
    }

    function isNativeStructured(logInfo) {
        if (!logInfo) return false;
        return Boolean(
            logInfo.querySelector(
                ".loginfo-struct, .forced, .confirmed, .struct-diff, table.struct-diff"
            )
        );
    }

    function hasNativeDiff(row, diffCell, data) {
        if (data && clean(data.diff)) return true;
        if (!diffCell) return false;
        if (diffCell.querySelector(".struct-diff, table, ins, del")) return true;
        return clean(diffCell.textContent).length > 0;
    }

    function summarizeNativeDiff(row, diffCell, data, actionCode) {
        if (!diffCell || diffCell.querySelector("[" + GENERATED_ATTR + "='diff-summary']")) return;
        const hasDiff = hasNativeDiff(row, diffCell, data);
        const modify = actionStyleKey(actionCode) === "modify";
        if (!hasDiff) {
            if (!modify) return;
            const missing = document.createElement("div");
            missing.className = "pmk101-diff-summary is-missing";
            missing.setAttribute(GENERATED_ATTR, "diff-summary");
            missing.textContent = language() === "en" ? "Before/after data was not supplied by Koha for this entry." : "Données avant/après non fournies par Koha pour cette entrée.";
            diffCell.prepend(missing);
            return;
        }
        const fields = [];
        diffCell.querySelectorAll("table tr").forEach(function (line) {
            const cells = Array.from(line.querySelectorAll("th,td"));
            if (cells.length < 3 || cells.every(cell => cell.tagName === "TH")) return;
            const field = clean(cells[0].textContent);
            const before = clean(cells[1].textContent);
            const after = clean(cells[2].textContent);
            if (field && before !== after) fields.push(field);
        });
        if (!fields.length) return;
        const unique = Array.from(new Set(fields));
        const summary = document.createElement("div");
        summary.className = "pmk101-diff-summary";
        summary.setAttribute(GENERATED_ATTR, "diff-summary");
        summary.textContent = language() === "en"
            ? unique.length + " changed field(s): " + unique.join(", ")
            : unique.length + " champ(s) modifié(s) : " + unique.join(", ");
        diffCell.prepend(summary);
    }

    function rawTextFromLogInfo(logInfo) {
        if (!logInfo) return "";
        const cloneNode = logInfo.cloneNode(true);
        Array.from(cloneNode.querySelectorAll("[" + GENERATED_ATTR + "]")).forEach(function (n) { n.remove(); });
        return clean(cloneNode.textContent);
    }

    function parsePerlDump(raw) {
        const out = {};
        const text = String(raw || "");
        const re = /['"]?([A-Za-z_][A-Za-z0-9_]*)['"]?\s*=>\s*(?:'((?:\\'|[^'])*)'|"((?:\\"|[^"])*)"|(undef|-?\d+(?:\.\d+)?))/g;
        let match;
        while ((match = re.exec(text))) {
            const key = match[1];
            let value = match[2] != null ? match[2] : (match[3] != null ? match[3] : match[4]);
            if (value === "undef") value = null;
            if (!(key in out)) out[key] = value;
        }
        return out;
    }

    function buildPerlHelper(raw, config) {
        const parsed = parsePerlDump(raw);
        const keys = Object.keys(parsed);
        if (!keys.length) return null;

        const wrap = document.createElement("div");
        wrap.className = "pmk101-legacy-helper";
        wrap.setAttribute(GENERATED_ATTR, "legacy");

        const chips = document.createElement("div");
        chips.className = "pmk101-chips";
        let hasChips = false;
        KEY_FIELDS.forEach(function (key) {
            if (!(key in parsed) || parsed[key] == null) return;
            hasChips = true;
            const chip = document.createElement("span");
            chip.className = "pmk101-chip";
            const b = document.createElement("b");
            b.textContent = key + ": ";
            chip.appendChild(b);
            chip.appendChild(document.createTextNode(String(parsed[key])));
            chips.appendChild(chip);
        });
        if (hasChips) wrap.appendChild(chips);

        const actions = document.createElement("div");
        actions.className = "pmk101-legacy-actions";

        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = "btn btn-default btn-xs pmk101-toggle";
        toggle.textContent = language() === "en" ? "▼ details" : "▼ détails";

        const rawBtn = document.createElement("button");
        rawBtn.type = "button";
        rawBtn.className = "btn btn-default btn-xs pmk101-toggle";
        rawBtn.textContent = language() === "en" ? "{ raw }" : "{ brut }";

        actions.appendChild(toggle);
        actions.appendChild(rawBtn);
        wrap.appendChild(actions);

        const detail = document.createElement("div");
        detail.style.display = "none";
        const table = document.createElement("table");
        table.className = "pmk101-detail-table";
        const tbody = document.createElement("tbody");
        keys.forEach(function (key) {
            if (parsed[key] == null) return;
            const tr = document.createElement("tr");
            const td1 = document.createElement("td");
            const td2 = document.createElement("td");
            td1.textContent = key;
            td2.textContent = String(parsed[key]);
            tr.appendChild(td1);
            tr.appendChild(td2);
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        detail.appendChild(table);
        wrap.appendChild(detail);

        const rawPre = document.createElement("pre");
        rawPre.className = "pmk101-raw";
        rawPre.textContent = raw;
        rawPre.style.display = "none";
        wrap.appendChild(rawPre);

        toggle.addEventListener("click", function () {
            const open = detail.style.display !== "none";
            detail.style.display = open ? "none" : "block";
            toggle.textContent = language() === "en"
                ? (open ? "▼ details" : "▲ collapse")
                : (open ? "▼ détails" : "▲ réduire");
        });

        rawBtn.addEventListener("click", function () {
            const open = rawPre.style.display !== "none";
            rawPre.style.display = open ? "none" : "block";
            rawBtn.textContent = language() === "en"
                ? (open ? "{ raw }" : "{ hide raw }")
                : (open ? "{ brut }" : "{ masquer brut }");
        });

        return wrap;
    }

    function extractBeforeAfterSections(raw) {
        const rawText = String(raw || "");
        const markerRe = /(BEFORE|AFTER)\s*=\s*>/ig;
        const markers = [];
        let match;

        while ((match = markerRe.exec(rawText)) !== null) {
            markers.push({
                type: match[1].toUpperCase(),
                start: match.index,
                contentStart: match.index + match[0].length
            });
        }

        const out = {
            contextLabel: "",
            beforeText: "",
            afterText: "",
            hasBefore: false,
            hasAfter: false
        };

        if (!markers.length) return out;

        out.contextLabel = clean(rawText.slice(0, markers[0].start));

        for (let i = 0; i < markers.length; i += 1) {
            const marker = markers[i];
            const chunkEnd = (i + 1 < markers.length) ? markers[i + 1].start : rawText.length;
            const chunk = clean(rawText.slice(marker.contentStart, chunkEnd));
            if (!chunk) continue;

            if (marker.type === "BEFORE") {
                out.hasBefore = true;
                out.beforeText += (out.beforeText ? "\n" : "") + chunk;
            } else {
                out.hasAfter = true;
                out.afterText += (out.afterText ? "\n" : "") + chunk;
            }
        }

        return out;
    }

    function parseMarcLines(text) {
        /*
         * Reprend volontairement la logique historique du 101 :
         * beaucoup d'anciens logs MARC ont été aplatis sur une seule ligne.
         * Une lecture strictement "une ligne = un champ" perdrait donc des tags.
         */
        const normalized = String(text || "").replace(/\s+/g, " ").trim();
        const out = [];
        const re = /(LDR|\d{3})\s([\s\S]*?)(?=(?:\s(?:LDR|\d{3})\s)|$)/g;
        let match;
        while ((match = re.exec(normalized)) !== null) {
            const tag = clean(match[1]).toUpperCase();
            const value = clean(match[2]);
            if (!tag || !value) continue;
            out.push({ tag: tag, value: value });
        }
        return out;
    }

    function countMarcTags(text) {
        const matches = String(text || "").match(/(?:\bLDR\b|\b\d{3}\b)\s/g);
        return matches ? matches.length : 0;
    }

    function groupMarc(rows) {
        const map = {};
        const order = [];
        rows.forEach(function (row) {
            if (!map[row.tag]) {
                map[row.tag] = [];
                order.push(row.tag);
            }
            map[row.tag].push(row.value);
        });
        return { map: map, order: order };
    }

    function buildMarcHelper(raw) {
        const sections = extractBeforeAfterSections(raw);
        let beforeRows = parseMarcLines(sections.beforeText);
        let afterRows = parseMarcLines(sections.afterText);

        if (!beforeRows.length && !afterRows.length) {
            const allRows = parseMarcLines(raw);
            if (!allRows.length) return null;
            afterRows = allRows;
        }

        const before = groupMarc(beforeRows);
        const after = groupMarc(afterRows);
        const order = before.order.slice();
        after.order.forEach(function (tag) {
            if (order.indexOf(tag) < 0) order.push(tag);
        });

        let changed = 0, added = 0, removed = 0, same = 0;

        const wrap = document.createElement("div");
        wrap.className = "pmk101-legacy-helper";
        wrap.setAttribute(GENERATED_ATTR, "legacy");

        const actions = document.createElement("div");
        actions.className = "pmk101-legacy-actions";

        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = "btn btn-default btn-xs pmk101-toggle";
        toggle.textContent = language() === "en" ? "▼ structured record" : "▼ notice structurée";

        const rawBtn = document.createElement("button");
        rawBtn.type = "button";
        rawBtn.className = "btn btn-default btn-xs pmk101-toggle";
        rawBtn.textContent = language() === "en" ? "{ raw }" : "{ brut }";

        actions.appendChild(toggle);
        actions.appendChild(rawBtn);
        wrap.appendChild(actions);

        const box = document.createElement("div");
        box.className = "pmk101-marc";
        box.style.display = "none";

        const head = document.createElement("div");
        head.className = "pmk101-marc-head";
        const title = document.createElement("div");
        title.className = "pmk101-marc-title";
        if (sections.contextLabel) {
            title.textContent = (language() === "en" ? "Record " : "Notice ") + sections.contextLabel;
        } else {
            title.textContent = language() === "en" ? "Structured MARC (legacy fallback)" : "MARC structuré (fallback historique)";
        }
        const stats = document.createElement("div");
        stats.className = "pmk101-marc-stats";
        head.appendChild(title);
        head.appendChild(stats);
        box.appendChild(head);

        const grid = document.createElement("div");
        grid.className = "pmk101-marc-compare";

        const hTag = document.createElement("div");
        hTag.className = "pmk101-marc-colhead";
        hTag.textContent = "Tag";
        const hBefore = document.createElement("div");
        hBefore.className = "pmk101-marc-colhead";
        hBefore.textContent = language() === "en" ? "Before" : "Avant";
        const hAfter = document.createElement("div");
        hAfter.className = "pmk101-marc-colhead";
        hAfter.textContent = language() === "en" ? "After / content" : "Après / contenu";
        grid.appendChild(hTag);
        grid.appendChild(hBefore);
        grid.appendChild(hAfter);

        order.forEach(function (tag) {
            const bArr = before.map[tag] || [];
            const aArr = after.map[tag] || [];
            const maxLen = Math.max(bArr.length, aArr.length);

            for (let i = 0; i < maxLen; i += 1) {
                const b = bArr[i];
                const a = aArr[i];

                const tagCell = document.createElement("div");
                tagCell.className = "pmk101-tag";
                tagCell.textContent = tag + (maxLen > 1 ? " #" + (i + 1) : "");

                const beforeCell = document.createElement("div");
                const afterCell = document.createElement("div");
                beforeCell.textContent = b || "—";
                afterCell.textContent = a || "—";

                if (!b && a) {
                    afterCell.classList.add("pmk101-diff-added");
                    added += 1;
                } else if (b && !a) {
                    beforeCell.classList.add("pmk101-diff-removed");
                    removed += 1;
                } else if (b === a) {
                    same += 1;
                } else {
                    beforeCell.classList.add("pmk101-diff-changed");
                    afterCell.classList.add("pmk101-diff-changed");
                    changed += 1;
                }

                grid.appendChild(tagCell);
                grid.appendChild(beforeCell);
                grid.appendChild(afterCell);
            }
        });

        stats.textContent = language() === "en"
            ? changed + " changed, " + added + " added, " + removed + " removed, " + same + " unchanged"
            : changed + " modifié(s), " + added + " ajouté(s), " + removed + " supprimé(s), " + same + " identique(s)";

        box.appendChild(grid);
        wrap.appendChild(box);

        const rawPre = document.createElement("pre");
        rawPre.className = "pmk101-raw";
        rawPre.textContent = raw;
        rawPre.style.display = "none";
        wrap.appendChild(rawPre);

        toggle.addEventListener("click", function () {
            const open = box.style.display !== "none";
            box.style.display = open ? "none" : "block";
            toggle.textContent = language() === "en"
                ? (open ? "▼ structured record" : "▲ collapse record")
                : (open ? "▼ notice structurée" : "▲ réduire la notice");
        });

        rawBtn.addEventListener("click", function () {
            const open = rawPre.style.display !== "none";
            rawPre.style.display = open ? "none" : "block";
            rawBtn.textContent = language() === "en"
                ? (open ? "{ raw }" : "{ hide raw }")
                : (open ? "{ brut }" : "{ masquer brut }");
        });

        return wrap;
    }

    function markRawNode(logInfo, config) {
        // On ne détruit jamais le nœud natif : on le marque seulement.
        logInfo.classList.add("pmk101-native-raw");
        if (config.legacy.hideRawWhenEnhanced) {
            logInfo.parentElement && logInfo.parentElement.classList.add("pmk101-legacy-raw-hidden");
        }
    }

    function enhanceLegacyInfo(row, infoCell, diffCell, data, config) {
        const logInfo = infoCell.querySelector(".loginfo");
        if (!logInfo) return;

        // Koha moderne a déjà fait le travail : on ne touche pas au contenu.
        if (isNativeStructured(logInfo)) return;

        const existingHelper = infoCell.querySelector("[" + GENERATED_ATTR + "='legacy']");
        if (existingHelper) return;

        const raw = data && data.info != null ? clean(data.info) : rawTextFromLogInfo(logInfo);
        if (!raw) return;

        if (config.legacy.parsePerlDump && raw.indexOf("$VAR1") !== -1) {
            const helper = buildPerlHelper(raw, config);
            if (helper) {
                markRawNode(logInfo, config);
                infoCell.appendChild(helper);
                return;
            }
        }

        if (
            config.legacy.parseMarcBeforeAfter &&
            !hasNativeDiff(row, diffCell, data) &&
            (
                /(?:BEFORE|AFTER)\s*=>/i.test(raw) ||
                countMarcTags(raw) >= config.legacy.minMarcTags
            )
        ) {
            const helper = buildMarcHelper(raw);
            if (helper) {
                markRawNode(logInfo, config);
                infoCell.appendChild(helper);
                return;
            }
        }

        // Ancien 101 : les informations textuelles simples étaient présentées
        // dans un bloc monospace. Ici on applique seulement une classe au
        // contenu natif, sans le vider ni le reconstruire.
        if (config.presentation.compactInfo) {
            logInfo.classList.add("pmk101-plain-info");
        }
    }

    function escapeRegex(value) {
        return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function codesRegex(codes) {
        const values = String(codes || "")
            .split("|")
            .map(function (v) { return clean(v); })
            .filter(Boolean)
            .map(escapeRegex);
        if (!values.length) return "";
        return "^(?:" + values.join("|") + ")$";
    }

    function applyColumnSearch(dt, dataKey, regex) {
        if (!dt) return;
        const idx = columnIndexByData(
            dt,
            dataKey,
            dataKey === "module" ? 2 :
            dataKey === "action" ? 3 :
            dataKey === "interface" ? 6 : -1
        );
        if (idx < 0) return;
        try {
            dt.column(idx).search(regex || "", true, false);
        } catch (_) {}
    }

    function currentToolbarState(toolbar) {
        if (!toolbar.__pmk101State) {
            toolbar.__pmk101State = {
                moduleCode: "",
                actionCodes: "",
                cronHidden: false
            };
        }
        return toolbar.__pmk101State;
    }

    function redrawWithFilters(toolbar, config) {
        const dt = getDT();
        if (!dt) return;
        const state = currentToolbarState(toolbar);

        applyColumnSearch(dt, "module", state.moduleCode ? codesRegex(state.moduleCode) : "");
        applyColumnSearch(dt, "action", state.actionCodes ? codesRegex(state.actionCodes) : "");

        if (config.filters.showCronToggle && state.cronHidden) {
            if (config.filters.cronFilterTarget === "module") {
                // Si un filtre de module est déjà actif, conserver ce filtre.
                if (!state.moduleCode) {
                    applyColumnSearch(dt, "module", "^(?!CRONJOBS$).*$");
                }
            } else {
                applyColumnSearch(dt, "interface", "^(?!cron$).*$");
            }
        } else if (config.filters.cronFilterTarget === "interface") {
            applyColumnSearch(dt, "interface", "");
        }

        try { dt.draw(); } catch (_) {}
    }

    function button(text, extraClass) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn-default btn-xs " + (extraClass || "");
        b.textContent = text;
        return b;
    }

    function sep(toolbar) {
        const s = document.createElement("span");
        s.className = "pmk101-sep";
        toolbar.appendChild(s);
    }

    function label(toolbar, text) {
        const s = document.createElement("span");
        s.className = "pmk101-lbl";
        s.textContent = text;
        toolbar.appendChild(s);
    }

    function removeToolbar() {
        const old = document.getElementById(TOOLBAR_ID);
        if (old) old.remove();
    }

    function buildToolbar(config) {
        removeToolbar();
        if (!config.enabled || !config.filters.enabled || !onTargetPage()) return;

        const table = document.querySelector("#logst");
        if (!table) return;

        const toolbar = document.createElement("div");
        toolbar.id = TOOLBAR_ID;
        toolbar.setAttribute(GENERATED_ATTR, "toolbar");

        const state = currentToolbarState(toolbar);
        const lang = language();

        label(toolbar, lang === "en" ? "Module:" : "Module :");

        const allModules = button(lang === "en" ? "All" : "Tous", "pmk101-module-filter pmk101-active");
        allModules.dataset.code = "";
        toolbar.appendChild(allModules);

        const moduleButtons = [allModules];
        config.filters.moduleButtons.filter(function (x) {
            return x.enabled && x.code;
        }).forEach(function (item) {
            const b = button(labelFor(item, item.code), "pmk101-module-filter");
            b.dataset.code = item.code;
            toolbar.appendChild(b);
            moduleButtons.push(b);
        });

        moduleButtons.forEach(function (b) {
            b.addEventListener("click", function () {
                moduleButtons.forEach(function (x) { x.classList.remove("pmk101-active"); });
                b.classList.add("pmk101-active");
                state.moduleCode = b.dataset.code || "";
                redrawWithFilters(toolbar, config);
            });
        });

        const activeActions = config.filters.actionButtons.filter(function (x) {
            return x.enabled && x.codes;
        });

        if (activeActions.length) {
            sep(toolbar);
            label(toolbar, lang === "en" ? "Action:" : "Action :");

            const actionButtons = [];
            activeActions.forEach(function (item) {
                const b = button(labelFor(item, item.codes), "pmk101-action-filter");
                b.dataset.codes = item.codes;
                toolbar.appendChild(b);
                actionButtons.push(b);
            });

            actionButtons.forEach(function (b) {
                b.addEventListener("click", function () {
                    const wasActive = b.classList.contains("pmk101-active");
                    actionButtons.forEach(function (x) { x.classList.remove("pmk101-active"); });
                    if (wasActive) {
                        state.actionCodes = "";
                    } else {
                        b.classList.add("pmk101-active");
                        state.actionCodes = b.dataset.codes || "";
                    }
                    redrawWithFilters(toolbar, config);
                });
            });
        }

        if (config.filters.showCronToggle) {
            sep(toolbar);
            label(toolbar, lang === "en" ? "Display:" : "Affichage :");
            const cron = button(lang === "en" ? "Hide cron" : "Masquer cron", "pmk101-cron-filter");
            toolbar.appendChild(cron);
            cron.addEventListener("click", function () {
                state.cronHidden = !state.cronHidden;
                cron.classList.toggle("pmk101-active", state.cronHidden);
                redrawWithFilters(toolbar, config);
            });
        }

        if (config.filters.showClearButton) {
            sep(toolbar);
            const clear = button(lang === "en" ? "Clear filters" : "Effacer les filtres", "pmk101-clear-filter");
            toolbar.appendChild(clear);
            clear.addEventListener("click", function () {
                state.moduleCode = "";
                state.actionCodes = "";
                state.cronHidden = false;
                Array.from(toolbar.querySelectorAll("button")).forEach(function (b) {
                    b.classList.remove("pmk101-active");
                });
                allModules.classList.add("pmk101-active");
                const dt = getDT();
                if (dt) {
                    applyColumnSearch(dt, "module", "");
                    applyColumnSearch(dt, "action", "");
                    applyColumnSearch(dt, "interface", "");
                    try { dt.draw(); } catch (_) {}
                }
            });
        }

        const wrapper = document.querySelector("#logst_wrapper");
        if (wrapper && wrapper.parentNode) {
            wrapper.parentNode.insertBefore(toolbar, wrapper);
        } else if (table.parentNode) {
            table.parentNode.insertBefore(toolbar, table);
        }
    }

    function detachTableEvents() {
        if (!window.jQuery || !boundTableNode) return;
        try {
            window.jQuery(boundTableNode).off(".pmk101");
        } catch (_) {}
        boundTableNode = null;
    }

    function bindTableEvents(config) {
        detachTableEvents();
        const table = document.querySelector("#logst");
        if (!table || !window.jQuery) return;
        boundTableNode = table;

        try {
            window.jQuery(table).on("draw.dt.pmk101", function () {
                window.setTimeout(function () {
                    enhanceAllRows(currentConfig);
                }, 0);
            });
            window.jQuery(table).on("init.dt.pmk101", function () {
                window.setTimeout(function () {
                    buildToolbar(currentConfig);
                    enhanceAllRows(currentConfig);
                    mountContextAccess();
                }, 0);
            });
        } catch (_) {}
    }

    function stopMutationObserver() {
        if (mutationObserver) {
            try { mutationObserver.disconnect(); } catch (_) {}
            mutationObserver = null;
        }
    }

    function startMutationObserver(config) {
        stopMutationObserver();
        if (!config.behavior.observeMutations) return;
        const table = document.querySelector("#logst");
        if (!table) return;

        mutationObserver = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                return Array.from(mutation.addedNodes || []).some(function (node) {
                    return node.nodeType === 1 && !(node.getAttribute && node.getAttribute(GENERATED_ATTR));
                });
            });
            if (!relevant) return;
            window.setTimeout(function () {
                enhanceAllRows(currentConfig);
            }, 0);
        });

        mutationObserver.observe(table, { childList: true, subtree: true });
    }

    function mountContextAccess() {
        const api = pmkApi();
        if (!api || typeof api.mountContextButton !== "function") return;
        if (!onTargetPage()) return;
        const anchor = document.querySelector("#logst_wrapper, #logst");
        if (!anchor) return;
        try {
            api.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "before",
                contextKey: PAGE_ID,
                context: { sectionId: "presentation", pageId: PAGE_ID }
            });
        } catch (_) {}
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config || DEFAULTS);

        removeToolbar();
        unwrapGenerated(document);
        stopMutationObserver();
        detachTableEvents();

        if (!onTargetPage()) return;
        if (!currentConfig.enabled || !currentConfig.pages.viewlog.enabled) return;

        ensureStyle(currentConfig);
        bindTableEvents(currentConfig);
        buildToolbar(currentConfig);
        enhanceAllRows(currentConfig);
        startMutationObserver(currentConfig);
        mountContextAccess();
    }

    function connectPmkConfig() {
        registerPmkDefinition();
        const api = pmkApi();
        if (!api || typeof api.getConfig !== "function") {
            applyConfig(DEFAULTS);
            return false;
        }

        api.getConfig(MODULE_ID)
            .then(function (config) { applyConfig(config || DEFAULTS); })
            .catch(function () { applyConfig(DEFAULTS); });

        if (!unsubscribe && typeof api.subscribe === "function") {
            try {
                unsubscribe = api.subscribe(MODULE_ID, function (config) {
                    applyConfig(config || DEFAULTS);
                });
            } catch (_) {}
        }
        return true;
    }

    function retryInit(config) {
        if (retryTimer) window.clearInterval(retryTimer);
        let tries = 0;

        retryTimer = window.setInterval(function () {
            tries += 1;

            if (!currentConfig.enabled || !currentConfig.pages.viewlog.enabled) {
                window.clearInterval(retryTimer);
                retryTimer = null;
                return;
            }

            const table = document.querySelector("#logst");
            if (table) {
                bindTableEvents(currentConfig);
                buildToolbar(currentConfig);
                enhanceAllRows(currentConfig);
                startMutationObserver(currentConfig);
                mountContextAccess();

                const dt = getDT();
                if (dt || table.querySelector("tbody tr") || tries >= config.behavior.retryCount) {
                    window.clearInterval(retryTimer);
                    retryTimer = null;
                }
            } else if (tries >= config.behavior.retryCount) {
                window.clearInterval(retryTimer);
                retryTimer = null;
            }
        }, config.behavior.retryDelayMs);
    }

    const publicApi = {
        version: MODULE_VERSION,
        moduleId: MODULE_ID,
        defaults: clone(DEFAULTS),
        normalizeConfig: normalizeConfig,
        validateConfig: validateConfig,
        refresh: function () {
            applyConfig(currentConfig);
        },
        enhanceAllRows: function () {
            enhanceAllRows(currentConfig);
        },
        parsePerlDump: parsePerlDump,
        parseMarcLines: parseMarcLines,
        nativeFirst: true
    };

    window.PMK101KohaLog = publicApi;

    function start() {
        if (started) return;
        started = true;

        if (!onTargetPage()) {
            registerPmkDefinition();
            return;
        }

        if (!connectPmkConfig()) {
            window.addEventListener("pmk:config-ready", function onReady() {
                window.removeEventListener("pmk:config-ready", onReady);
                connectPmkConfig();
            }, { once: true });
        }

        window.setTimeout(function () {
            applyConfig(currentConfig);
            retryInit(currentConfig);
        }, currentConfig.behavior.initDelayMs);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("101-koha-log.js");
} catch (error) { window.PMKNonPlugin.errors.push("101-koha-log.js: "+error.message); console.error("[PMK] 101-koha-log.js",error); };
try {
/*
 Nom du fichier : 102-batchmod-mediabus-buttons.js
 Version : 3.0.0-preplugin
 Date : 2026-09-20

 PimpMyKoha — Boutons modèles exemplaires

 Principes :
 - module autonome, distinct du 110 "Exemplaire Helper" ;
 - conserve les deux boutons historiques MEDIABUS par défaut ;
 - permet de créer un nombre libre de boutons-modèles dans PMK ;
 - chaque bouton peut appliquer plusieurs valeurs à un formulaire exemplaire ;
 - ne soumet JAMAIS le formulaire Koha ;
 - respecte le mécanisme Koha `disable_input` pour une suppression en modification par lot ;
 - valide les valeurs des <select> réellement présents avant application ;
 - déclenche les événements input/change pour synchroniser Koha et Select2 ;
 - reste fail-safe : un champ/une valeur introuvable est ignoré et signalé ;
 - français / anglais ;
 - rendu compact et natif Koha, responsive.
*/
(function () {
    "use strict";

    if (window.__PMK102_ITEM_TEMPLATE_BUTTONS__) return;
    window.__PMK102_ITEM_TEMPLATE_BUTTONS__ = true;

    const MODULE_ID = "item-template-buttons";
    const MODULE_VERSION = "3.0.0-preplugin";
    const TOOLBAR_ID = "pmk-item-template-buttons";
    const STYLE_ID = "pmk-item-template-buttons-style";
    const DIALOG_ID = "pmk-item-template-buttons-dialog";

    const PAGE_DEFINITIONS = [
        {
            id: "tools.batchmod",
            path: "/cgi-bin/koha/tools/batchMod.pl",
            labelFr: "Modification d’exemplaires par lot",
            labelEn: "Batch item modification",
            enabled: true
        },
        {
            id: "cataloguing.additem",
            path: "/cgi-bin/koha/cataloguing/additem.pl",
            labelFr: "Création / modification d’exemplaire",
            labelEn: "Item creation / editing",
            enabled: true
        }
    ];

    /*
     * Liste d'aide pour la configuration.
     * Le moteur runtime n'est PAS limité à cette liste :
     * `__custom__` accepte n'importe quel kohafield réellement présent dans le formulaire.
     */
    const FIELD_OPTIONS = [
        { value: "items.homebranch", fr: "Bibliothèque propriétaire", en: "Home library" },
        { value: "items.holdingbranch", fr: "Bibliothèque actuelle", en: "Current library" },
        { value: "items.enumchron", fr: "Énumération / chronologie", en: "Enumeration / chronology" },
        { value: "items.location", fr: "Localisation", en: "Shelving location" },
        { value: "items.copynumber", fr: "Numéro de copie / sous-localisation locale", en: "Copy number / local sub-location" },
        { value: "items.itemcallnumber", fr: "Cote", en: "Call number" },
        { value: "items.barcode", fr: "Code-barres", en: "Barcode" },
        { value: "items.itype", fr: "Type d’exemplaire", en: "Item type" },
        { value: "items.ccode", fr: "Code collection", en: "Collection code" },
        { value: "items.more_subfields_xml_q", fr: "Public (champ local)", en: "Audience (local field)" },
        { value: "items.notforloan", fr: "Statut non prêtable", en: "Not for loan status" },
        { value: "items.itemlost", fr: "Statut perdu", en: "Lost status" },
        { value: "items.withdrawn", fr: "Statut retiré", en: "Withdrawn status" },
        { value: "items.damaged", fr: "Statut endommagé", en: "Damaged status" },
        { value: "items.restricted", fr: "Restriction", en: "Restriction" },
        { value: "items.more_subfields_xml_t", fr: "Achat / don (champ local)", en: "Purchase / donation (local field)" },
        { value: "items.more_subfields_xml_A", fr: "Fournisseur (champ local)", en: "Vendor (local field)" },
        { value: "items.replacementprice", fr: "Prix de remplacement", en: "Replacement price" },
        { value: "items.price", fr: "Prix", en: "Price" },
        { value: "items.dateaccessioned", fr: "Date d’acquisition", en: "Acquisition date" },
        { value: "items.itemnotes_nonpublic", fr: "Note interne", en: "Internal note" },
        { value: "items.itemnotes", fr: "Note publique / OPAC", en: "Public / OPAC note" },
        { value: "items.uri", fr: "URI", en: "URI" },
        { value: "items.more_subfields_xml_v", fr: "Numéro de revue (champ local)", en: "Issue number (local field)" },
        { value: "items.more_subfields_xml_y", fr: "Sous-localisation / valeur locale y", en: "Local y value" },
        { value: "__custom__", fr: "Autre kohafield…", en: "Other kohafield…" }
    ];

    const HISTORICAL_MODELS = [
        /*
         * L'ordre reproduit le rendu historique réel du script 102 :
         * les deux insertAdjacentElement('afterend') successifs faisaient apparaître
         * "Envoyer" avant "Sortir".
         */
        {
            id: "mediabus-send-reservoir",
            enabled: true,
            labelFr: "Envoyer au reservoir MEDIABUS",
            labelEn: "Send to MEDIABUS reservoir",
            descriptionFr: "Applique les valeurs historiques utilisées pour envoyer un exemplaire au réservoir MEDIABUS.",
            descriptionEn: "Applies the historical values used to send an item to the MEDIABUS reservoir.",
            showOnBatchMod: true,
            showOnAddItem: true,
            groupFr: "",
            groupEn: "",
            iconClass: "",
            variant: "default",
            customBackground: "#408540",
            customTextColor: "#ffffff",
            customBorderColor: "#397a39",
            confirmBeforeApply: false,
            confirmTitleFr: "Appliquer ce modèle ?",
            confirmTitleEn: "Apply this template?",
            confirmMessageFr: "Les champs du formulaire seront préparés, mais Koha ne sera pas enregistré automatiquement.",
            confirmMessageEn: "The form fields will be prepared, but Koha will not be saved automatically.",
            assignments: [
                { enabled: true, target: "items.homebranch", customTarget: "", action: "set", value: "RMDB" },
                { enabled: true, target: "items.holdingbranch", customTarget: "", action: "set", value: "RMDB" },
                { enabled: true, target: "items.enumchron", customTarget: "", action: "set", value: "Sous-sol" },
                { enabled: true, target: "items.notforloan", customTarget: "", action: "set", value: "1" }
            ]
        },
        {
            id: "mediabus-remove-reservoir",
            enabled: true,
            labelFr: "Sortir du reservoir MEDIABUS",
            labelEn: "Remove from MEDIABUS reservoir",
            descriptionFr: "Applique les valeurs historiques utilisées pour sortir un exemplaire du réservoir MEDIABUS.",
            descriptionEn: "Applies the historical values used to remove an item from the MEDIABUS reservoir.",
            showOnBatchMod: true,
            showOnAddItem: true,
            groupFr: "",
            groupEn: "",
            iconClass: "",
            variant: "default",
            customBackground: "#408540",
            customTextColor: "#ffffff",
            customBorderColor: "#397a39",
            confirmBeforeApply: false,
            confirmTitleFr: "Appliquer ce modèle ?",
            confirmTitleEn: "Apply this template?",
            confirmMessageFr: "Les champs du formulaire seront préparés, mais Koha ne sera pas enregistré automatiquement.",
            confirmMessageEn: "The form fields will be prepared, but Koha will not be saved automatically.",
            assignments: [
                { enabled: true, target: "items.homebranch", customTarget: "", action: "set", value: "MDB" },
                { enabled: true, target: "items.holdingbranch", customTarget: "", action: "set", value: "MDB" },
                { enabled: true, target: "items.enumchron", customTarget: "", action: "set", value: "RDC" },
                { enabled: true, target: "items.notforloan", customTarget: "", action: "set", value: "0" }
            ]
        }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: PAGE_DEFINITIONS.map(function (page) {
            return {
                id: page.id,
                path: page.path,
                enabled: page.enabled
            };
        }),
        toolbar: {
            showTitle: false,
            titleFr: "Modèles rapides",
            titleEn: "Quick templates",
            compactButtons: true,
            gapPx: 8,
            marginTopPx: 8,
            marginBottomPx: 10,
            showSuccessMessage: false,
            showWarnings: true,
            previewBeforeApply: true
        },
        models: clone(HISTORICAL_MODELS)
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let configRegistered = false;
    let unsubscribe = null;
    let observer = null;
    let mountTimer = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return Boolean(value) && typeof value === "object" && !Array.isArray(value);
    }

    function deepMerge(base, override) {
        if (Array.isArray(base)) {
            return Array.isArray(override) ? clone(override) : clone(base);
        }
        if (!isObject(base)) {
            return override === undefined ? clone(base) : clone(override);
        }
        const out = clone(base);
        if (!isObject(override)) return out;
        Object.keys(override).forEach(function (key) {
            out[key] = Object.prototype.hasOwnProperty.call(base, key)
                ? deepMerge(base[key], override[key])
                : clone(override[key]);
        });
        return out;
    }

    function normalizeText(value) {
        return String(value || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function detectLanguage() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            } catch (_) {}
        }
        const lang = String(document.documentElement.lang || navigator.language || "").toLowerCase();
        return lang.startsWith("en") ? "en" : "fr";
    }

    function textByLanguage(fr, en) {
        return detectLanguage() === "en" ? (en || fr || "") : (fr || en || "");
    }

    function isSupportedPath() {
        return PAGE_DEFINITIONS.some(function (page) {
            return page.path === window.location.pathname;
        });
    }

    function pageConfig() {
        const pages = Array.isArray(currentConfig.pages) ? currentConfig.pages : [];
        return pages.find(function (page) {
            return page && page.path === window.location.pathname;
        }) || null;
    }

    function moduleEnabledHere() {
        if (currentConfig.enabled === false) return false;
        const page = pageConfig();
        return Boolean(page && page.enabled !== false);
    }

    function modelVisibleHere(model) {
        if (!model || model.enabled === false) return false;
        if (window.location.pathname === "/cgi-bin/koha/tools/batchMod.pl") {
            return model.showOnBatchMod !== false;
        }
        if (window.location.pathname === "/cgi-bin/koha/cataloguing/additem.pl") {
            return model.showOnAddItem !== false;
        }
        return false;
    }

    function safeNumber(value, fallback, min, max) {
        let n = Number(value);
        if (!Number.isFinite(n)) n = fallback;
        if (Number.isFinite(min)) n = Math.max(min, n);
        if (Number.isFinite(max)) n = Math.min(max, n);
        return n;
    }

    function injectStyles() {
        let style = document.getElementById(STYLE_ID);
        if (style) return style;

        style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            #${TOOLBAR_ID} {
                --pmk102-gap: 8px;
                --pmk102-mt: 8px;
                --pmk102-mb: 10px;
                display: block;
                box-sizing: border-box;
                width: 100%;
                margin-top: var(--pmk102-mt);
                margin-bottom: var(--pmk102-mb);
            }
            #${TOOLBAR_ID} .pmk102-title {
                margin: 0 0 .35rem;
                font-size: .9rem;
                font-weight: 600;
                color: #495057;
            }
            #${TOOLBAR_ID} .pmk102-groups {
                display: flex;
                flex-wrap: wrap;
                align-items: flex-end;
                gap: var(--pmk102-gap);
            }
            #${TOOLBAR_ID} .pmk102-group {
                display: inline-flex;
                flex-wrap: wrap;
                align-items: center;
                gap: var(--pmk102-gap);
                min-width: 0;
            }
            #${TOOLBAR_ID} .pmk102-group-label {
                font-size: .78rem;
                font-weight: 600;
                color: #6c757d;
                margin-right: .1rem;
            }
            #${TOOLBAR_ID} .pmk102-button {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: .35rem;
                white-space: normal;
                text-align: center;
                line-height: 1.2;
            }
            #${TOOLBAR_ID}.pmk102-compact .pmk102-button {
                min-height: 30px;
                padding-top: .25rem;
                padding-bottom: .25rem;
            }
            #${TOOLBAR_ID} .pmk102-button[data-pmk-variant="custom"] {
                background: var(--pmk102-btn-bg, #408540) !important;
                color: var(--pmk102-btn-text, #fff) !important;
                border-color: var(--pmk102-btn-border, #397a39) !important;
            }
            #${TOOLBAR_ID} .pmk102-button[data-pmk-variant="custom"]:hover,
            #${TOOLBAR_ID} .pmk102-button[data-pmk-variant="custom"]:focus {
                filter: brightness(.95);
            }
            #${TOOLBAR_ID} .pmk102-status {
                display: none;
                margin-top: .45rem;
                padding: .38rem .55rem;
                border: 1px solid #dee2e6;
                border-radius: .25rem;
                background: #f8f9fa;
                color: #495057;
                font-size: .82rem;
                line-height: 1.35;
            }
            #${TOOLBAR_ID} .pmk102-status.is-visible { display: block; }
            #${TOOLBAR_ID} .pmk102-status.is-warning {
                border-color: #ffe69c;
                background: #fff3cd;
                color: #664d03;
            }
            #${TOOLBAR_ID} .pmk102-status.is-success {
                border-color: #badbcc;
                background: #d1e7dd;
                color: #0f5132;
            }
            #${TOOLBAR_ID} .pmk102-status ul {
                margin: .2rem 0 0 1.1rem;
                padding: 0;
            }
            #${TOOLBAR_ID} .pmk102-config-anchor {
                display: inline-flex;
                align-items: center;
                min-height: 30px;
            }

            #${DIALOG_ID} {
                position: fixed;
                inset: 0;
                z-index: 2147483000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 1rem;
                background: rgba(0,0,0,.42);
            }
            #${DIALOG_ID} .pmk102-dialog {
                width: min(34rem, calc(100vw - 2rem));
                max-height: calc(100vh - 2rem);
                overflow: auto;
                background: #fff;
                border: 1px solid #dee2e6;
                border-radius: .4rem;
                box-shadow: 0 .5rem 1.5rem rgba(0,0,0,.18);
            }
            #${DIALOG_ID} .pmk102-dialog-head,
            #${DIALOG_ID} .pmk102-dialog-body,
            #${DIALOG_ID} .pmk102-dialog-actions {
                padding: .8rem 1rem;
            }
            #${DIALOG_ID} .pmk102-dialog-head {
                border-bottom: 1px solid #e9ecef;
            }
            #${DIALOG_ID} .pmk102-dialog-head h3 {
                margin: 0;
                font-size: 1rem;
            }
            #${DIALOG_ID} .pmk102-dialog-body {
                white-space: pre-wrap;
            }
            #${DIALOG_ID} .pmk102-dialog-actions {
                display: flex;
                justify-content: flex-end;
                gap: .5rem;
                border-top: 1px solid #e9ecef;
            }

            @media (max-width: 576px) {
                #${TOOLBAR_ID} .pmk102-groups,
                #${TOOLBAR_ID} .pmk102-group {
                    width: 100%;
                }
                #${TOOLBAR_ID} .pmk102-button {
                    flex: 1 1 12rem;
                    max-width: 100%;
                }
                #${DIALOG_ID} .pmk102-dialog-actions {
                    flex-direction: column-reverse;
                }
                #${DIALOG_ID} .pmk102-dialog-actions .btn {
                    width: 100%;
                }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
        return style;
    }

    function removeToolbar() {
        const toolbar = document.getElementById(TOOLBAR_ID);
        if (toolbar) toolbar.remove();
    }

    function findHistoricalAnchor() {
        const path = window.location.pathname;

        if (path === "/cgi-bin/koha/cataloguing/additem.pl") {
            const legacy = document.getElementById("edititem");
            if (legacy) return legacy;

            const field = document.querySelector('[name="items.homebranch"], [name="items.holdingbranch"], [name="items.barcode"]');
            if (field) {
                const form = field.closest("form");
                if (form) {
                    const heading = form.querySelector("h1, h2, h3, legend");
                    if (heading) return heading;
                }
            }

            return document.querySelector("main h1, main h2, h1, h2");
        }

        if (path === "/cgi-bin/koha/tools/batchMod.pl") {
            const headings = Array.from(document.querySelectorAll("h1, h2, h3"));
            const patterns = [
                "modifier les exemplaires",
                "modification des exemplaires",
                "modify items",
                "batch item modification"
            ];

            const legacyHeading = headings.find(function (heading) {
                const txt = normalizeText(heading.textContent);
                return patterns.some(function (pattern) {
                    return txt.indexOf(normalizeText(pattern)) !== -1;
                });
            });
            if (legacyHeading) return legacyHeading;

            const field = document.querySelector('[name="items.homebranch"], [name="items.holdingbranch"], [name="items.barcode"]');
            if (field) {
                const form = field.closest("form");
                if (form) {
                    let node = form.previousElementSibling;
                    while (node) {
                        if (/^H[1-3]$/.test(node.tagName || "")) return node;
                        node = node.previousElementSibling;
                    }
                    const heading = form.querySelector("h1, h2, h3, legend");
                    if (heading) return heading;
                }
            }

            return document.querySelector("main h1, main h2, h1, h2");
        }

        return null;
    }

    function targetName(assignment) {
        if (!assignment) return "";
        if (assignment.target === "__custom__") {
            return String(assignment.customTarget || "").trim();
        }
        return String(assignment.target || "").trim();
    }

    function fieldOptionLabel(name) {
        const option = FIELD_OPTIONS.find(function (item) {
            return item.value === name;
        });
        return option
            ? textByLanguage(option.fr, option.en)
            : name;
    }

    function findSubfieldLineByKohafield(kohafield) {
        if (!kohafield) return null;
        const lines = document.querySelectorAll(".subfield_line");
        for (const line of lines) {
            const hidden = line.querySelector('input[name="kohafield"]');
            if (hidden && String(hidden.value || "").trim() === kohafield) {
                return line;
            }
        }
        return null;
    }

    function controlsByExactName(name) {
        if (!name) return [];
        return Array.from(document.querySelectorAll("input, select, textarea")).filter(function (node) {
            return String(node.getAttribute("name") || "") === name &&
                String(node.type || "").toLowerCase() !== "hidden";
        });
    }

    function resolveField(target) {
        const line = findSubfieldLineByKohafield(target);
        let controls = [];

        if (line) {
            controls = Array.from(line.querySelectorAll("input, select, textarea")).filter(function (node) {
                return String(node.getAttribute("name") || "") === target &&
                    String(node.type || "").toLowerCase() !== "hidden";
            });

            if (!controls.length) {
                controls = Array.from(line.querySelectorAll("input, select, textarea")).filter(function (node) {
                    const type = String(node.type || "").toLowerCase();
                    const name = String(node.getAttribute("name") || "");
                    return type !== "hidden" &&
                        name !== "disable_input" &&
                        name !== "tag" &&
                        name !== "subfield" &&
                        name !== "kohafield" &&
                        name !== "important";
                });
            }
        }

        if (!controls.length) {
            controls = controlsByExactName(target);
        }

        if (!controls.length) {
            return {
                ok: false,
                reason: textByLanguage(
                    "champ introuvable dans ce formulaire",
                    "field not found in this form"
                ),
                target: target,
                line: line,
                control: null
            };
        }

        /*
         * Si Koha expose plusieurs contrôles portant le même nom, privilégier celui
         * qui se trouve dans le formulaire/éditeur visible puis le premier contrôle.
         */
        const preferred = controls.find(function (node) {
            const style = window.getComputedStyle ? window.getComputedStyle(node) : null;
            return !style || (style.display !== "none" && style.visibility !== "hidden");
        }) || controls[0];

        return {
            ok: true,
            target: target,
            line: line || preferred.closest(".subfield_line"),
            control: preferred
        };
    }

    function getDeleteCheckbox(resolved) {
        const line = resolved && resolved.line
            ? resolved.line
            : (resolved && resolved.control && resolved.control.closest
                ? resolved.control.closest(".subfield_line")
                : null);
        return line ? line.querySelector('input[name="disable_input"]') : null;
    }

    function dispatchFieldEvents(control) {
        if (!control) return;

        try {
            control.dispatchEvent(new Event("input", { bubbles: true }));
        } catch (_) {}

        try {
            control.dispatchEvent(new Event("change", { bubbles: true }));
        } catch (_) {}

        /*
         * Certaines versions de Koha / Select2 écoutent également l'événement jQuery.
         * Le déclenchement est complémentaire, jamais obligatoire.
         */
        try {
            if (window.jQuery) {
                window.jQuery(control).trigger("change");
            }
        } catch (_) {}
    }

    function cancelPendingDeletion(resolved) {
        const checkbox = getDeleteCheckbox(resolved);
        if (!checkbox || !checkbox.checked) return;

        try {
            checkbox.click();
        } catch (_) {
            checkbox.checked = false;
            try {
                checkbox.dispatchEvent(new Event("change", { bubbles: true }));
            } catch (_) {}
        }
    }

    function setSelectValue(select, desired) {
        const raw = String(desired == null ? "" : desired);
        const options = Array.from(select.options || []);

        let option = options.find(function (item) {
            return String(item.value) === raw;
        });

        if (!option) {
            const wanted = normalizeText(raw);
            option = options.find(function (item) {
                return normalizeText(item.textContent) === wanted;
            });
        }

        if (!option) {
            return {
                ok: false,
                reason: textByLanguage(
                    "valeur indisponible dans la liste Koha",
                    "value unavailable in the Koha list"
                )
            };
        }

        select.value = option.value;
        dispatchFieldEvents(select);

        return {
            ok: true,
            value: option.value,
            label: String(option.textContent || "").trim()
        };
    }

    function setControlValue(control, value) {
        if (!control) {
            return {
                ok: false,
                reason: textByLanguage("contrôle absent", "control missing")
            };
        }

        const tag = String(control.tagName || "").toLowerCase();
        const type = String(control.type || "").toLowerCase();

        if (tag === "select") {
            return setSelectValue(control, value);
        }

        if (type === "checkbox") {
            const wanted = ["1", "true", "yes", "on"].includes(normalizeText(value));
            control.checked = wanted;
            dispatchFieldEvents(control);
            return { ok: true, value: wanted ? "1" : "0", label: wanted ? "true" : "false" };
        }

        if (type === "radio") {
            const name = control.getAttribute("name");
            const radios = name
                ? Array.from(document.querySelectorAll('input[type="radio"]')).filter(function (node) {
                    return node.getAttribute("name") === name;
                })
                : [control];
            const wanted = String(value == null ? "" : value);
            const radio = radios.find(function (node) {
                return String(node.value) === wanted;
            });
            if (!radio) {
                return {
                    ok: false,
                    reason: textByLanguage(
                        "valeur radio indisponible",
                        "radio value unavailable"
                    )
                };
            }
            radio.checked = true;
            dispatchFieldEvents(radio);
            return { ok: true, value: wanted, label: wanted };
        }

        control.value = String(value == null ? "" : value);
        dispatchFieldEvents(control);
        return {
            ok: true,
            value: control.value,
            label: control.value
        };
    }

    function clearResolvedField(resolved) {
        const control = resolved.control;
        const deleteCheckbox = getDeleteCheckbox(resolved);

        /*
         * batchMod : utiliser la mécanique native Koha.
         * Cela permet au module 031 de jouer son rôle s'il est actif.
         */
        if (window.location.pathname === "/cgi-bin/koha/tools/batchMod.pl" && deleteCheckbox) {
            if (!deleteCheckbox.checked) {
                try {
                    deleteCheckbox.click();
                } catch (_) {
                    deleteCheckbox.checked = true;
                    try {
                        deleteCheckbox.dispatchEvent(new Event("change", { bubbles: true }));
                    } catch (_) {}
                }
            }

            return {
                ok: true,
                pending: true,
                reason: textByLanguage(
                    "suppression demandée via le mécanisme Koha",
                    "clear requested through Koha's mechanism"
                )
            };
        }

        /*
         * additem : vider le contrôle est la mécanique normale du formulaire.
         * Aucune sauvegarde n'est déclenchée par ce module.
         */
        if (control.tagName && String(control.tagName).toLowerCase() === "select") {
            const emptyOption = Array.from(control.options || []).find(function (option) {
                return String(option.value) === "";
            });
            if (!emptyOption) {
                return {
                    ok: false,
                    reason: textByLanguage(
                        "aucune valeur vide n’est disponible dans cette liste",
                        "no empty value is available in this list"
                    )
                };
            }
        }

        return setControlValue(control, "");
    }

    function applyAssignment(assignment) {
        if (!assignment || assignment.enabled === false) {
            return { skipped: true };
        }

        const target = targetName(assignment);
        if (!target) {
            return {
                ok: false,
                target: "",
                label: textByLanguage("Champ non défini", "Undefined field"),
                reason: textByLanguage(
                    "aucun kohafield n’est configuré",
                    "no kohafield is configured"
                )
            };
        }

        const action = String(assignment.action || "set");
        if (action === "keep") {
            return { skipped: true, target: target };
        }

        const resolved = resolveField(target);
        const label = fieldOptionLabel(target);

        if (!resolved.ok) {
            return {
                ok: false,
                target: target,
                label: label,
                reason: resolved.reason
            };
        }

        if (action === "clear") {
            const cleared = clearResolvedField(resolved);
            return Object.assign({
                target: target,
                label: label
            }, cleared);
        }

        cancelPendingDeletion(resolved);
        const setResult = setControlValue(resolved.control, assignment.value);

        return Object.assign({
            target: target,
            label: label
        }, setResult);
    }

    function controlDisplayValue(control) {
        if (!control) return textByLanguage("champ absent", "missing field");
        const tag = String(control.tagName || "").toLowerCase();
        const type = String(control.type || "").toLowerCase();
        if (tag === "select") {
            const option = control.options && control.options[control.selectedIndex];
            return option ? String(option.textContent || option.value || "").trim() + " [" + option.value + "]" : String(control.value || "");
        }
        if (type === "checkbox") return control.checked ? textByLanguage("coché", "checked") : textByLanguage("non coché", "unchecked");
        if (type === "radio") {
            const checked = Array.from(document.querySelectorAll('input[type="radio"]')).find(node => node.name === control.name && node.checked);
            return checked ? String(checked.value) : textByLanguage("aucun choix", "no selection");
        }
        return String(control.value || "") || textByLanguage("vide", "empty");
    }

    function previewAssignment(assignment) {
        if (!assignment || assignment.enabled === false || String(assignment.action || "set") === "keep") return {skipped:true};
        const target = targetName(assignment);
        const label = fieldOptionLabel(target || "") || target || textByLanguage("Champ non défini", "Undefined field");
        const resolved = target ? resolveField(target) : {ok:false,reason:textByLanguage("aucun kohafield n’est configuré", "no kohafield configured")};
        if (!resolved.ok) return {ok:false,target,label,before:"—",after:"—",reason:resolved.reason};
        const before = controlDisplayValue(resolved.control);
        const action = String(assignment.action || "set");
        if (action === "clear") {
            const select = String(resolved.control.tagName || "").toLowerCase() === "select";
            const valid = !select || Array.from(resolved.control.options || []).some(option => String(option.value) === "") || Boolean(getDeleteCheckbox(resolved));
            return valid ? {ok:true,target,label,before,after:textByLanguage("vider / supprimer", "clear / delete")} : {ok:false,target,label,before,after:"—",reason:textByLanguage("aucune valeur vide n’est disponible dans cette liste", "no empty value is available in this list")};
        }
        const desired = String(assignment.value == null ? "" : assignment.value);
        const tag = String(resolved.control.tagName || "").toLowerCase();
        const type = String(resolved.control.type || "").toLowerCase();
        if (tag === "select") {
            const option = Array.from(resolved.control.options || []).find(item => String(item.value) === desired || normalizeText(item.textContent) === normalizeText(desired));
            if (!option) return {ok:false,target,label,before,after:desired,reason:textByLanguage("valeur indisponible dans la liste Koha", "value unavailable in the Koha list")};
            return {ok:true,target,label,before,after:String(option.textContent || option.value).trim() + " [" + option.value + "]"};
        }
        if (type === "radio") {
            const exists = Array.from(document.querySelectorAll('input[type="radio"]')).some(node => node.name === resolved.control.name && String(node.value) === desired);
            if (!exists) return {ok:false,target,label,before,after:desired,reason:textByLanguage("valeur radio indisponible", "radio value unavailable")};
        }
        return {ok:true,target,label,before,after:desired || textByLanguage("vide", "empty")};
    }

    function previewModel(model) {
        return (Array.isArray(model && model.assignments) ? model.assignments : []).map(previewAssignment).filter(result => !result.skipped);
    }

    function applyModel(model) {
        const assignments = Array.isArray(model.assignments) ? model.assignments : [];
        const results = assignments.map(applyAssignment).filter(function (result) {
            return !result.skipped;
        });

        const failures = results.filter(function (result) {
            return result.ok === false;
        });

        const applied = results.filter(function (result) {
            return result.ok !== false;
        });

        showApplicationResult(model, applied, failures);

        try {
            window.dispatchEvent(new CustomEvent("pmk:item-template-applied", {
                detail: {
                    moduleId: MODULE_ID,
                    modelId: model.id,
                    applied: applied.length,
                    failed: failures.length,
                    results: results
                }
            }));
        } catch (_) {}

        return {
            applied: applied,
            failures: failures
        };
    }

    function statusNode() {
        const toolbar = document.getElementById(TOOLBAR_ID);
        return toolbar ? toolbar.querySelector(".pmk102-status") : null;
    }

    function showApplicationResult(model, applied, failures) {
        const status = statusNode();
        if (!status) return;

        const toolbarConfig = currentConfig.toolbar || {};
        const showWarnings = toolbarConfig.showWarnings !== false;
        const showSuccess = toolbarConfig.showSuccessMessage === true;

        status.className = "pmk102-status";
        status.innerHTML = "";

        if (failures.length && showWarnings) {
            status.classList.add("is-visible", "is-warning");

            const strong = document.createElement("strong");
            strong.textContent = textByLanguage(
                "Modèle appliqué partiellement :",
                "Template partially applied:"
            );
            status.appendChild(strong);

            const list = document.createElement("ul");
            failures.forEach(function (failure) {
                const li = document.createElement("li");
                li.textContent = (failure.label || failure.target || "Champ") + " — " + failure.reason;
                list.appendChild(li);
            });
            status.appendChild(list);
            return;
        }

        if (showSuccess) {
            status.classList.add("is-visible", "is-success");
            status.textContent = textByLanguage(
                "Modèle « " + modelLabel(model) + " » appliqué au formulaire (" + applied.length + " champ(s)). Aucun enregistrement automatique.",
                "Template “" + modelLabel(model) + "” applied to the form (" + applied.length + " field(s)). Nothing was saved automatically."
            );
        }
    }

    function modelLabel(model) {
        return textByLanguage(model && model.labelFr, model && model.labelEn) ||
            String(model && model.id || "") ||
            textByLanguage("Modèle", "Template");
    }

    function askConfirmation(model) {
        const preview = previewModel(model);
        const previewEnabled = !currentConfig.toolbar || currentConfig.toolbar.previewBeforeApply !== false;
        if (!model || (model.confirmBeforeApply !== true && !previewEnabled)) {
            return Promise.resolve(true);
        }

        const title = textByLanguage(model.confirmTitleFr, model.confirmTitleEn) ||
            textByLanguage("Appliquer ce modèle ?", "Apply this template?");
        const baseMessage = textByLanguage(model.confirmMessageFr, model.confirmMessageEn) ||
            textByLanguage(
                "Les champs du formulaire seront modifiés, sans enregistrement automatique.",
                "The form fields will be changed without automatic saving."
            );
        const previewLines = preview.map(function (row) {
            return (row.ok === false ? "⚠ " : "• ") + row.label + " : " + row.before + " → " + row.after + (row.reason ? " — " + row.reason : "");
        });
        const message = baseMessage + (previewLines.length ? "\n\n" + textByLanguage("Aperçu avant application :", "Preview before applying:") + "\n" + previewLines.join("\n") : "");

        if (window.PMKConfig && typeof window.PMKConfig.confirmAction === "function") {
            try {
                return Promise.resolve(window.PMKConfig.confirmAction({
                    title: title,
                    message: message,
                    confirmLabel: textByLanguage("Appliquer", "Apply"),
                    cancelLabel: textByLanguage("Annuler", "Cancel"),
                    danger: false
                })).then(Boolean).catch(function () {
                    return false;
                });
            } catch (_) {}
        }

        return fallbackConfirmAction({
            title: title,
            message: message
        });
    }

    function fallbackConfirmAction(options) {
        return new Promise(function (resolve) {
            injectStyles();

            const existing = document.getElementById(DIALOG_ID);
            if (existing) existing.remove();

            const previousFocus = document.activeElement;
            const backdrop = document.createElement("div");
            backdrop.id = DIALOG_ID;

            const dialog = document.createElement("div");
            dialog.className = "pmk102-dialog";
            dialog.setAttribute("role", "dialog");
            dialog.setAttribute("aria-modal", "true");

            const head = document.createElement("div");
            head.className = "pmk102-dialog-head";

            const title = document.createElement("h3");
            title.textContent = options.title || "";
            head.appendChild(title);

            const body = document.createElement("div");
            body.className = "pmk102-dialog-body";
            body.textContent = options.message || "";

            const actions = document.createElement("div");
            actions.className = "pmk102-dialog-actions";

            const cancel = document.createElement("button");
            cancel.type = "button";
            cancel.className = "btn btn-default";
            cancel.textContent = textByLanguage("Annuler", "Cancel");

            const confirm = document.createElement("button");
            confirm.type = "button";
            confirm.className = "btn btn-primary";
            confirm.textContent = textByLanguage("Appliquer", "Apply");

            actions.appendChild(cancel);
            actions.appendChild(confirm);

            dialog.appendChild(head);
            dialog.appendChild(body);
            dialog.appendChild(actions);
            backdrop.appendChild(dialog);
            document.body.appendChild(backdrop);

            let done = false;
            function finish(value) {
                if (done) return;
                done = true;
                document.removeEventListener("keydown", onKey, true);
                backdrop.remove();
                try {
                    if (previousFocus && typeof previousFocus.focus === "function") {
                        previousFocus.focus();
                    }
                } catch (_) {}
                resolve(value);
            }

            function onKey(event) {
                if (event.key === "Escape") {
                    event.preventDefault();
                    finish(false);
                }
            }

            document.addEventListener("keydown", onKey, true);
            cancel.addEventListener("click", function () { finish(false); });
            confirm.addEventListener("click", function () { finish(true); });
            backdrop.addEventListener("click", function (event) {
                if (event.target === backdrop) finish(false);
            });

            window.setTimeout(function () {
                try { cancel.focus(); } catch (_) {}
            }, 0);
        });
    }

    function buttonVariantClass(variant) {
        switch (variant) {
            case "primary": return "btn btn-primary";
            case "success": return "btn btn-success";
            case "warning": return "btn btn-warning";
            case "danger": return "btn btn-danger";
            case "info": return "btn btn-info";
            case "secondary": return "btn btn-secondary";
            case "custom": return "btn";
            case "default":
            default:
                return "btn btn-default";
        }
    }

    function createModelButton(model) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = buttonVariantClass(model.variant) + " pmk102-button";
        button.dataset.pmkModelId = String(model.id || "");
        button.dataset.pmkVariant = String(model.variant || "default");
        button.title = textByLanguage(model.descriptionFr, model.descriptionEn) || modelLabel(model);

        if (currentConfig.toolbar && currentConfig.toolbar.compactButtons !== false) {
            button.classList.add("btn-sm");
        }

        if (model.variant === "custom") {
            button.style.setProperty("--pmk102-btn-bg", String(model.customBackground || "#408540"));
            button.style.setProperty("--pmk102-btn-text", String(model.customTextColor || "#ffffff"));
            button.style.setProperty("--pmk102-btn-border", String(model.customBorderColor || "#397a39"));
        }

        const iconClass = String(model.iconClass || "").trim();
        if (iconClass) {
            const icon = document.createElement("i");
            icon.className = iconClass;
            icon.setAttribute("aria-hidden", "true");
            button.appendChild(icon);
        }

        const label = document.createElement("span");
        label.textContent = modelLabel(model);
        button.appendChild(label);

        button.addEventListener("click", function (event) {
            event.preventDefault();

            askConfirmation(model).then(function (confirmed) {
                if (!confirmed) return;
                applyModel(model);
            });
        });

        return button;
    }

    function buildToolbar() {
        const models = Array.isArray(currentConfig.models) ? currentConfig.models : [];
        const visibleModels = models.filter(modelVisibleHere);

        if (!visibleModels.length) {
            removeToolbar();
            return null;
        }

        const wrapper = document.createElement("div");
        wrapper.id = TOOLBAR_ID;
        wrapper.dataset.pmkModule = MODULE_ID;

        const toolbarConfig = currentConfig.toolbar || {};
        wrapper.style.setProperty("--pmk102-gap", safeNumber(toolbarConfig.gapPx, 8, 0, 40) + "px");
        wrapper.style.setProperty("--pmk102-mt", safeNumber(toolbarConfig.marginTopPx, 8, 0, 80) + "px");
        wrapper.style.setProperty("--pmk102-mb", safeNumber(toolbarConfig.marginBottomPx, 10, 0, 80) + "px");

        if (toolbarConfig.compactButtons !== false) {
            wrapper.classList.add("pmk102-compact");
        }

        if (toolbarConfig.showTitle === true) {
            const title = document.createElement("div");
            title.className = "pmk102-title";
            title.textContent = textByLanguage(toolbarConfig.titleFr, toolbarConfig.titleEn) ||
                textByLanguage("Modèles rapides", "Quick templates");
            wrapper.appendChild(title);
        }

        const groups = document.createElement("div");
        groups.className = "pmk102-groups";

        /*
         * Les modèles sans groupe restent dans une barre simple, comme le 102 historique.
         * Les modèles portant le même groupe sont regroupés sans imposer de panneau.
         */
        const groupMap = new Map();

        visibleModels.forEach(function (model) {
            const groupName = textByLanguage(model.groupFr, model.groupEn).trim();
            const groupKey = groupName || "__ungrouped__";

            let group = groupMap.get(groupKey);
            if (!group) {
                group = document.createElement("div");
                group.className = "pmk102-group";
                group.dataset.group = groupKey;

                if (groupName) {
                    const groupLabel = document.createElement("span");
                    groupLabel.className = "pmk102-group-label";
                    groupLabel.textContent = groupName;
                    group.appendChild(groupLabel);
                }

                groupMap.set(groupKey, group);
                groups.appendChild(group);
            }

            group.appendChild(createModelButton(model));
        });

        const configAnchor = document.createElement("span");
        configAnchor.className = "pmk102-config-anchor";
        groups.appendChild(configAnchor);

        wrapper.appendChild(groups);

        const status = document.createElement("div");
        status.className = "pmk102-status";
        status.setAttribute("role", "status");
        wrapper.appendChild(status);

        return wrapper;
    }

    function mountContextButton(wrapper) {
        if (!wrapper || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = wrapper.querySelector(".pmk102-config-anchor");
        if (!anchor) return;

        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "item-template-buttons",
                context: {
                    pageId: window.location.pathname === "/cgi-bin/koha/tools/batchMod.pl"
                        ? "tools.batchmod"
                        : "cataloguing.additem",
                    sectionId: "models"
                }
            });
        } catch (_) {}
    }

    function render() {
        removeToolbar();

        if (!isSupportedPath() || !moduleEnabledHere()) return false;

        const anchor = findHistoricalAnchor();
        if (!anchor || !anchor.parentNode) return false;

        injectStyles();

        const toolbar = buildToolbar();
        if (!toolbar) return true;

        try {
            anchor.insertAdjacentElement("afterend", toolbar);
        } catch (_) {
            anchor.parentNode.insertBefore(toolbar, anchor.nextSibling);
        }

        mountContextButton(toolbar);
        return true;
    }

    function scheduleRender(delay) {
        if (mountTimer) window.clearTimeout(mountTimer);
        mountTimer = window.setTimeout(function () {
            mountTimer = null;
            render();
        }, typeof delay === "number" ? delay : 50);
    }

    function watchForPageChanges() {
        if (observer || !document.documentElement) return;

        observer = new MutationObserver(function (mutations) {
            if (!moduleEnabledHere()) return;

            let relevant = false;
            for (const mutation of mutations) {
                if (mutation.type !== "childList") continue;
                if (!mutation.addedNodes || !mutation.addedNodes.length) continue;

                for (const node of mutation.addedNodes) {
                    if (!(node instanceof Element)) continue;
                    if (node.id === TOOLBAR_ID || node.closest("#" + TOOLBAR_ID)) continue;

                    if (
                        node.matches(".subfield_line, form, h1, h2, h3, #edititem") ||
                        node.querySelector(".subfield_line, [name='items.homebranch'], [name='items.holdingbranch'], #edititem")
                    ) {
                        relevant = true;
                        break;
                    }
                }
                if (relevant) break;
            }

            if (relevant && !document.getElementById(TOOLBAR_ID)) {
                scheduleRender(60);
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }

    function newModel() {
        const stamp = Date.now().toString(36);
        return {
            id: "template-" + stamp,
            enabled: true,
            labelFr: "Nouveau modèle",
            labelEn: "New template",
            descriptionFr: "",
            descriptionEn: "",
            showOnBatchMod: true,
            showOnAddItem: true,
            groupFr: "",
            groupEn: "",
            iconClass: "",
            variant: "default",
            customBackground: "#408540",
            customTextColor: "#ffffff",
            customBorderColor: "#397a39",
            confirmBeforeApply: false,
            confirmTitleFr: "Appliquer ce modèle ?",
            confirmTitleEn: "Apply this template?",
            confirmMessageFr: "Les champs du formulaire seront préparés, mais Koha ne sera pas enregistré automatiquement.",
            confirmMessageEn: "The form fields will be prepared, but Koha will not be saved automatically.",
            assignments: [
                {
                    enabled: true,
                    target: "items.homebranch",
                    customTarget: "",
                    action: "set",
                    value: ""
                }
            ]
        };
    }

    function newAssignment() {
        return {
            enabled: true,
            target: "items.homebranch",
            customTarget: "",
            action: "set",
            value: ""
        };
    }

    function validateConfig(config) {
        if (!config || !Array.isArray(config.models)) {
            return {
                ok: false,
                message: textByLanguage(
                    "La liste des modèles est invalide.",
                    "The template list is invalid."
                )
            };
        }

        for (const model of config.models) {
            if (!model) continue;

            /*
             * L'identifiant est utile pour le diagnostic et l'API publique, mais il
             * n'est volontairement PAS bloquant. Une duplication de modèle depuis
             * l'interface PMK ne doit pas provoquer l'erreur historique
             * « identifiant unique ». Les boutons sont liés à leur objet de config,
             * pas à l'unicité de cet identifiant.
             */
            const id = String(model.id || "").trim();

            /*
             * Un modèle désactivé peut rester en préparation dans la configuration.
             * Les contraintes métier ne deviennent bloquantes qu'au moment où le
             * modèle est activé.
             */
            if (model.enabled === false) continue;

            if (!String(model.labelFr || model.labelEn || "").trim()) {
                return {
                    ok: false,
                    message: textByLanguage(
                        "Chaque bouton-modèle actif doit avoir un libellé.",
                        "Each enabled template button must have a label."
                    )
                };
            }

            if (!Array.isArray(model.assignments) || !model.assignments.length) {
                return {
                    ok: false,
                    message: textByLanguage(
                        "Chaque bouton-modèle doit contenir au moins une action de champ.",
                        "Each template button must contain at least one field action."
                    )
                };
            }

            const seenTargets = new Set();

            for (const assignment of model.assignments) {
                if (!assignment || assignment.enabled === false) continue;

                const target = targetName(assignment);
                if (!target) {
                    return {
                        ok: false,
                        message: textByLanguage(
                            "Une action de champ active n’a pas de kohafield.",
                            "An enabled field action has no kohafield."
                        )
                    };
                }

                const action = String(assignment.action || "set");
                if (action === "set" && String(assignment.value == null ? "" : assignment.value).trim() === "") {
                    return {
                        ok: false,
                        message: textByLanguage(
                            "Le champ « " + target + " » doit avoir une valeur, ou utiliser l’action « Vider / supprimer ».",
                            "Field “" + target + "” must have a value, or use the “Clear / delete” action."
                        )
                    };
                }

                if (seenTargets.has(target)) {
                    return {
                        ok: false,
                        message: textByLanguage(
                            "Un même modèle ne doit pas cibler deux fois le champ « " + target + " ».",
                            "A template must not target the field “" + target + "” twice."
                        )
                    };
                }
                seenTargets.add(target);
            }
        }

        return { ok: true };
    }

    function pmkFieldOptions() {
        return FIELD_OPTIONS.map(function (item) {
            return {
                value: item.value,
                label: {
                    fr: item.fr + (item.value !== "__custom__" ? " — " + item.value : ""),
                    en: item.en + (item.value !== "__custom__" ? " — " + item.value : "")
                }
            };
        });
    }

    function registerWithPMK() {
        if (!window.PMKConfig || configRegistered) return false;
        configRegistered = true;

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 3,
            name: {
                fr: "Boutons modèles exemplaires",
                en: "Item template buttons"
            },
            description: {
                fr: "Ajoute directement dans additem.pl et batchMod.pl des boutons qui appliquent des modèles complets de valeurs aux champs exemplaire, sans enregistrer automatiquement. Les deux modèles MEDIABUS historiques sont fournis par défaut.",
                en: "Adds direct buttons to additem.pl and batchMod.pl that apply complete value templates to item fields without saving automatically. The two historical MEDIABUS templates are included by default."
            },
            category: {
                fr: "Catalogue / exemplaires",
                en: "Catalog / items"
            },
            supportedPages: [
                "tools.batchmod",
                "cataloguing.additem"
            ],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    description: {
                        fr: "Le module reste autonome : il n’utilise pas l’Assistant exemplaires 110.",
                        en: "This module remains standalone and does not use item helper 110."
                    },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer les boutons modèles", en: "Enable template buttons" }
                        },
                        {
                            key: "pages",
                            type: "repeater",
                            label: { fr: "Pages Koha", en: "Koha pages" },
                            reorder: false,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function (item, index, lang) {
                                const def = PAGE_DEFINITIONS[index];
                                return def
                                    ? (lang === "en" ? def.labelEn : def.labelFr)
                                    : String(item && item.path || "Page");
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Activer sur cette page", en: "Enable on this page" } },
                                { key: "id", type: "text", readOnly: true, advanced: true, label: { fr: "Identifiant page", en: "Page identifier" } },
                                { key: "path", type: "text", readOnly: true, label: { fr: "Chemin Koha", en: "Koha path" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "toolbar",
                    label: { fr: "Présentation de la barre", en: "Toolbar appearance" },
                    description: {
                        fr: "Les boutons utilisent par défaut les styles natifs Koha et passent automatiquement à la ligne sur petit écran.",
                        en: "Buttons use Koha native styles by default and wrap automatically on small screens."
                    },
                    fields: [
                        { key: "toolbar.showTitle", type: "boolean", label: { fr: "Afficher un titre au-dessus des boutons", en: "Show a title above the buttons" } },
                        { key: "toolbar.titleFr", type: "text", label: { fr: "Titre français", en: "French title" } },
                        { key: "toolbar.titleEn", type: "text", label: { fr: "Titre anglais", en: "English title" } },
                        { key: "toolbar.compactButtons", type: "boolean", label: { fr: "Boutons compacts", en: "Compact buttons" } },
                        { key: "toolbar.gapPx", type: "number", min: 0, max: 40, label: { fr: "Espacement entre boutons (px)", en: "Gap between buttons (px)" } },
                        { key: "toolbar.marginTopPx", type: "number", min: 0, max: 80, label: { fr: "Marge supérieure (px)", en: "Top margin (px)" } },
                        { key: "toolbar.marginBottomPx", type: "number", min: 0, max: 80, label: { fr: "Marge inférieure (px)", en: "Bottom margin (px)" } },
                        { key: "toolbar.previewBeforeApply", type: "boolean", label: { fr: "Afficher l’avant/après avant application", en: "Show before/after before applying" }, help: { fr: "L’aperçu signale aussi les champs absents et les valeurs qui ne figurent pas dans les listes Koha.", en: "The preview also reports missing fields and values unavailable in Koha lists." } },
                        { key: "toolbar.showSuccessMessage", type: "boolean", label: { fr: "Afficher un message après application réussie", en: "Show a message after successful application" } },
                        { key: "toolbar.showWarnings", type: "boolean", label: { fr: "Afficher les champs/valeurs non appliqués", en: "Show fields/values that could not be applied" } }
                    ]
                },
                {
                    type: "section",
                    id: "models",
                    label: { fr: "Boutons et modèles", en: "Buttons and templates" },
                    description: {
                        fr: "Chaque bouton peut préparer autant de champs exemplaire que nécessaire. Il ne valide jamais le formulaire Koha. Pour une liste Koha, la valeur peut être le code stocké ou le libellé visible ; le moteur vérifie qu’elle existe réellement avant de l’appliquer.",
                        en: "Each button can prepare as many item fields as needed. It never submits the Koha form. For Koha lists, the value may be the stored code or visible label; the engine verifies it actually exists before applying it."
                    },
                    fields: [
                        {
                            key: "models",
                            type: "repeater",
                            label: { fr: "Boutons modèles", en: "Template buttons" },
                            addLabel: { fr: "Ajouter un bouton modèle", en: "Add template button" },
                            emptyLabel: { fr: "Aucun bouton modèle configuré.", en: "No template button configured." },
                            reorder: true,
                            newItem: newModel,
                            liveTitleKey: "labelFr",
                            itemTitle: function (item, index, lang) {
                                if (!item) return (lang === "en" ? "Template " : "Modèle ") + (index + 1);
                                return lang === "en"
                                    ? (String(item.labelEn || item.labelFr || "").trim() || "Template " + (index + 1))
                                    : (String(item.labelFr || item.labelEn || "").trim() || "Modèle " + (index + 1));
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Bouton actif", en: "Button enabled" } },
                                { key: "id", type: "text", advanced: true, label: { fr: "Identifiant technique (facultatif)", en: "Technical identifier (optional)" }, help: { fr: "Aucune unicité n’est imposée : dupliquer un modèle reste possible sans erreur.", en: "Uniqueness is not enforced, so templates can be duplicated without errors." } },
                                { key: "labelFr", type: "text", label: { fr: "Libellé français", en: "French label" } },
                                { key: "labelEn", type: "text", label: { fr: "Libellé anglais", en: "English label" } },
                                { key: "descriptionFr", type: "textarea", label: { fr: "Infobulle / description française", en: "French tooltip / description" } },
                                { key: "descriptionEn", type: "textarea", label: { fr: "Infobulle / description anglaise", en: "English tooltip / description" } },
                                { key: "showOnBatchMod", type: "boolean", label: { fr: "Afficher sur batchMod.pl", en: "Show on batchMod.pl" } },
                                { key: "showOnAddItem", type: "boolean", label: { fr: "Afficher sur additem.pl", en: "Show on additem.pl" } },
                                { key: "groupFr", type: "text", advanced: true, label: { fr: "Groupe français (facultatif)", en: "French group (optional)" } },
                                { key: "groupEn", type: "text", advanced: true, label: { fr: "Groupe anglais (facultatif)", en: "English group (optional)" } },
                                { key: "iconClass", type: "text", advanced: true, label: { fr: "Classe d’icône Font Awesome (facultatif)", en: "Font Awesome icon class (optional)" }, help: { fr: "Exemple : fa fa-archive. Vide = aucune icône, comme le 102 historique.", en: "Example: fa fa-archive. Blank = no icon, as in historical 102." } },
                                {
                                    key: "variant",
                                    type: "select",
                                    label: { fr: "Style du bouton", en: "Button style" },
                                    options: [
                                        { value: "default", label: { fr: "Koha neutre", en: "Koha neutral" } },
                                        { value: "primary", label: { fr: "Primaire", en: "Primary" } },
                                        { value: "success", label: { fr: "Succès", en: "Success" } },
                                        { value: "warning", label: { fr: "Attention", en: "Warning" } },
                                        { value: "danger", label: { fr: "Danger", en: "Danger" } },
                                        { value: "info", label: { fr: "Information", en: "Info" } },
                                        { value: "secondary", label: { fr: "Secondaire", en: "Secondary" } },
                                        { value: "custom", label: { fr: "Couleurs personnalisées", en: "Custom colors" } }
                                    ]
                                },
                                { key: "customBackground", type: "color", advanced: true, label: { fr: "Fond personnalisé", en: "Custom background" } },
                                { key: "customTextColor", type: "color", advanced: true, label: { fr: "Texte personnalisé", en: "Custom text" } },
                                { key: "customBorderColor", type: "color", advanced: true, label: { fr: "Bordure personnalisée", en: "Custom border" } },
                                { key: "confirmBeforeApply", type: "boolean", label: { fr: "Demander confirmation avant application", en: "Ask for confirmation before applying" } },
                                { key: "confirmTitleFr", type: "text", advanced: true, label: { fr: "Titre confirmation FR", en: "Confirmation title FR" } },
                                { key: "confirmTitleEn", type: "text", advanced: true, label: { fr: "Titre confirmation EN", en: "Confirmation title EN" } },
                                { key: "confirmMessageFr", type: "textarea", advanced: true, label: { fr: "Message confirmation FR", en: "Confirmation message FR" } },
                                { key: "confirmMessageEn", type: "textarea", advanced: true, label: { fr: "Message confirmation EN", en: "Confirmation message EN" } },
                                {
                                    key: "assignments",
                                    type: "repeater",
                                    label: { fr: "Champs préparés par ce bouton", en: "Fields prepared by this button" },
                                    addLabel: { fr: "Ajouter un champ", en: "Add field" },
                                    emptyLabel: { fr: "Aucun champ configuré.", en: "No field configured." },
                                    reorder: true,
                                    newItem: newAssignment,
                                    itemTitle: function (item, index, lang) {
                                        if (!item) return (lang === "en" ? "Field " : "Champ ") + (index + 1);
                                        const target = item.target === "__custom__"
                                            ? String(item.customTarget || "")
                                            : String(item.target || "");
                                        const def = FIELD_OPTIONS.find(function (option) { return option.value === target; });
                                        return def
                                            ? (lang === "en" ? def.en : def.fr)
                                            : (target || ((lang === "en" ? "Field " : "Champ ") + (index + 1)));
                                    },
                                    fields: [
                                        { key: "enabled", type: "boolean", label: { fr: "Action active", en: "Action enabled" } },
                                        {
                                            key: "target",
                                            type: "select",
                                            label: { fr: "Champ exemplaire", en: "Item field" },
                                            options: pmkFieldOptions()
                                        },
                                        {
                                            key: "customTarget",
                                            type: "text",
                                            advanced: true,
                                            label: { fr: "Kohafield personnalisé", en: "Custom kohafield" },
                                            help: {
                                                fr: "À renseigner uniquement si « Autre kohafield… » est choisi. Exemple : items.more_subfields_xml_X.",
                                                en: "Only fill this when “Other kohafield…” is selected. Example: items.more_subfields_xml_X."
                                            }
                                        },
                                        {
                                            key: "action",
                                            type: "select",
                                            label: { fr: "Action", en: "Action" },
                                            options: [
                                                { value: "set", label: { fr: "Définir cette valeur", en: "Set this value" } },
                                                { value: "clear", label: { fr: "Vider / supprimer la valeur", en: "Clear / delete the value" } },
                                                { value: "keep", label: { fr: "Ne pas modifier", en: "Keep unchanged" } }
                                            ]
                                        },
                                        {
                                            key: "value",
                                            type: "text",
                                            label: { fr: "Valeur à appliquer", en: "Value to apply" },
                                            help: {
                                                fr: "Pour une liste Koha, saisir soit le code stocké (ex. RMDB), soit exactement le libellé visible. Le moteur refuse une valeur absente du formulaire.",
                                                en: "For a Koha list, enter either the stored code (e.g. RMDB) or the exact visible label. The engine rejects values missing from the form."
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        window.PMKConfig.getConfig(MODULE_ID)
            .then(function (config) {
                currentConfig = deepMerge(DEFAULT_CONFIG, config || {});
                scheduleRender(0);
            })
            .catch(function () {
                currentConfig = clone(DEFAULT_CONFIG);
                scheduleRender(0);
            });

        if (typeof window.PMKConfig.subscribe === "function") {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (config) {
                currentConfig = deepMerge(DEFAULT_CONFIG, config || {});
                scheduleRender(0);
            });
        }

        return true;
    }

    function bootstrap() {
        if (!isSupportedPath()) {
            /*
             * On tente quand même l'enregistrement PMK si le socle est présent,
             * afin que le module soit connu de la configuration globale.
             */
            if (registerWithPMK()) return;

            window.addEventListener("pmk:config-ready", registerWithPMK, { once: true });
            return;
        }

        injectStyles();
        watchForPageChanges();

        if (registerWithPMK()) {
            scheduleRender(0);
            return;
        }

        window.addEventListener("pmk:config-ready", function () {
            registerWithPMK();
            scheduleRender(0);
        }, { once: true });

        /*
         * PMK absent : conserver le comportement historique avec les deux modèles
         * MEDIABUS par défaut.
         */
        currentConfig = clone(DEFAULT_CONFIG);
        scheduleRender(0);

        let tries = 0;
        const timer = window.setInterval(function () {
            tries += 1;
            if (registerWithPMK() || tries >= 100) {
                window.clearInterval(timer);
            }
        }, 50);
    }

    window.PMKItemTemplateButtons = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        fieldOptions: clone(FIELD_OPTIONS),
        previewModel: function (model) { return clone(previewModel(model)); },
        applyModelById: function (modelId) {
            const models = Array.isArray(currentConfig.models) ? currentConfig.models : [];
            const model = models.find(function (candidate) {
                return candidate && candidate.id === modelId;
            });
            if (!model || !modelVisibleHere(model)) return false;
            applyModel(model);
            return true;
        },
        refresh: function () {
            scheduleRender(0);
        },
        getConfig: function () {
            return clone(currentConfig);
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
    } else {
        bootstrap();
    }

    window.addEventListener("beforeunload", function () {
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        if (mountTimer) {
            window.clearTimeout(mountTimer);
            mountTimer = null;
        }
        if (typeof unsubscribe === "function") {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("102-batchmod-mediabus-buttons.js");
} catch (error) { window.PMKNonPlugin.errors.push("102-batchmod-mediabus-buttons.js: "+error.message); console.error("[PMK] 102-batchmod-mediabus-buttons.js",error); };
try {
/*
 * 103-detail-reservations-summary-style.js
 * PimpMyKoha — module autonome
 *
 * Nom fonctionnel :
 *   FR : Mise en forme conditionnelle — Réservations et listes
 *   EN : Conditional formatting — Holds and lists
 *
 * Objet :
 *   - conserver le rendu historique du 103 sur catalogue/detail.pl ;
 *   - regrouper et mettre en forme les blocs Réservations / Cours / Listes ;
 *   - permettre l'ajout de règles supplémentaires du même type ;
 *   - mettre en évidence le compteur de réservations ;
 *   - NE PLUS gérer la couleur des lignes du tableau d'exemplaires :
 *     cette responsabilité appartient au module 033.
 *
 * Le rendu historique est la configuration par défaut pour toutes les
 * installations, pas un preset spécifique d’origine.
 */
(function () {
    "use strict";

    const MODULE_ID = "detail-reservations-summary-style";
    const SCHEMA_VERSION = 3;
    const DETAIL_PATH = "/cgi-bin/koha/catalogue/detail.pl";
    const SUMMARY_SELECTOR = "span.results_summary";
    const DESTINATION_SELECTOR = ".catalogue-info";

    let registered = false;
    let booted = false;
    let currentConfig = null;
    let observer = null;
    let reapplyTimer = null;
    let applying = false;

    const movedElements = new Map();
    const originalLabels = new Map();
    const countTargets = new Map();
    const generatedWrappers = new Set();

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function cleanText(value) {
        return String(value == null ? "" : value).trim();
    }

    function normalizeText(value) {
        return cleanText(value)
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .toLowerCase();
    }

    function clampNumber(value, fallback, min, max) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function safeCssSelector(selector, fallback) {
        const candidate = cleanText(selector) || fallback;
        try {
            document.querySelector(candidate);
            return candidate;
        } catch (_) {
            return fallback;
        }
    }

    function slug(value, fallback) {
        const normalized = normalizeText(value)
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "");
        return normalized || fallback;
    }

    function detectLanguage() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                const lang = window.PMKConfig.getLanguage();
                if (lang === "en") return "en";
            }
        } catch (_) {}
        const htmlLang = cleanText(document.documentElement && document.documentElement.lang).toLowerCase();
        return htmlLang.indexOf("en") === 0 ? "en" : "fr";
    }

    function isDetailPage() {
        return window.location && window.location.pathname === DETAIL_PATH;
    }

    const DEFAULT_CONFIG = {
        enabled: true,
        page: {
            enabled: true,
            path: DETAIL_PATH
        },
        placement: {
            destinationSelector: DESTINATION_SELECTOR,
            summarySelector: SUMMARY_SELECTOR,
            mode: "append"
        },
        appearance: {
            borderRadiusPx: 5,
            paddingPx: 10,
            fontSizePx: 16,
            marginTopPx: 10,
            uppercase: true,
            centerContent: true,
            showTextMarker: true
        },
        blocks: [
            {
                id: "reservations",
                enabled: true,
                adminLabelFr: "Réservations",
                adminLabelEn: "Holds",
                matchMode: "contains",
                matchFr: "Réservations",
                matchEn: "Holds",
                selector: "",
                replacementLabelFr: "",
                replacementLabelEn: "",
                markerTextFr: "Réservations",
                markerTextEn: "Holds",
                backgroundColor: "#32cd32",
                backgroundOpacity: 0.5,
                customTextColor: false,
                textColor: "#212529"
            },
            {
                id: "courses",
                enabled: true,
                adminLabelFr: "Cours / liste d'exemplaires",
                adminLabelEn: "Courses / item list",
                matchMode: "contains",
                matchFr: "Cours ayant réservé ce titre",
                matchEn: "Courses reserving this title",
                selector: "",
                replacementLabelFr: "Est présent dans la liste d'exemplaire : ",
                replacementLabelEn: "Included in an item list: ",
                markerTextFr: "Cours / liste d’exemplaires",
                markerTextEn: "Course / item list",
                backgroundColor: "#87cefa",
                backgroundOpacity: 0.5,
                customTextColor: false,
                textColor: "#212529"
            },
            {
                id: "lists",
                enabled: true,
                adminLabelFr: "Listes contenant ce titre",
                adminLabelEn: "Lists containing this title",
                matchMode: "contains",
                matchFr: "Listes contenant ce titre",
                matchEn: "Lists containing this title",
                selector: "",
                replacementLabelFr: "",
                replacementLabelEn: "",
                markerTextFr: "Liste de notices",
                markerTextEn: "Record list",
                backgroundColor: "#fa4848",
                backgroundOpacity: 0.5,
                customTextColor: false,
                textColor: "#212529"
            }
        ],
        countHighlight: {
            enabled: true,
            primarySelector: ".number_box a",
            fallbackSelector: 'a[href*="/cgi-bin/koha/reserve/request.pl?biblionumber="]',
            warningFrom: 3,
            criticalFrom: 4,
            warningColor: "#ffa500",
            criticalColor: "#ff0000",
            bold: false
        },
        advanced: {
            watchDynamicContent: true,
            waitMs: 3500
        }
    };

    function normalizeBlock(block, index) {
        const source = block && typeof block === "object" ? block : {};
        const fallbackLabel = cleanText(source.adminLabelFr || source.adminLabelEn || source.matchFr || source.matchEn);
        return {
            id: cleanText(source.id) || slug(fallbackLabel, "rule-" + (index + 1)),
            enabled: source.enabled !== false,
            adminLabelFr: cleanText(source.adminLabelFr) || fallbackLabel || ("Règle " + (index + 1)),
            adminLabelEn: cleanText(source.adminLabelEn) || cleanText(source.adminLabelFr) || fallbackLabel || ("Rule " + (index + 1)),
            matchMode: ["contains", "exact", "regex"].includes(source.matchMode) ? source.matchMode : "contains",
            matchFr: cleanText(source.matchFr),
            matchEn: cleanText(source.matchEn),
            selector: cleanText(source.selector),
            replacementLabelFr: source.replacementLabelFr == null ? "" : String(source.replacementLabelFr),
            replacementLabelEn: source.replacementLabelEn == null ? "" : String(source.replacementLabelEn),
            markerTextFr: cleanText(source.markerTextFr) || cleanText(source.adminLabelFr) || fallbackLabel,
            markerTextEn: cleanText(source.markerTextEn) || cleanText(source.adminLabelEn) || cleanText(source.adminLabelFr) || fallbackLabel,
            backgroundColor: cleanText(source.backgroundColor) || "#ffffff",
            backgroundOpacity: clampNumber(source.backgroundOpacity, 1, 0, 1),
            customTextColor: source.customTextColor === true,
            textColor: cleanText(source.textColor) || "#212529"
        };
    }

    function normalize(config) {
        const src = config && typeof config === "object" ? clone(config) : {};
        const merged = clone(DEFAULT_CONFIG);

        if (typeof src.enabled === "boolean") merged.enabled = src.enabled;

        merged.page = Object.assign({}, merged.page, src.page || {});
        merged.page.enabled = merged.page.enabled !== false;
        merged.page.path = cleanText(merged.page.path) || DETAIL_PATH;

        merged.placement = Object.assign({}, merged.placement, src.placement || {});
        merged.placement.destinationSelector = cleanText(merged.placement.destinationSelector) || DESTINATION_SELECTOR;
        merged.placement.summarySelector = cleanText(merged.placement.summarySelector) || SUMMARY_SELECTOR;
        merged.placement.mode = merged.placement.mode === "prepend" ? "prepend" : "append";

        merged.appearance = Object.assign({}, merged.appearance, src.appearance || {});
        merged.appearance.borderRadiusPx = clampNumber(merged.appearance.borderRadiusPx, 5, 0, 50);
        merged.appearance.paddingPx = clampNumber(merged.appearance.paddingPx, 10, 0, 60);
        merged.appearance.fontSizePx = clampNumber(merged.appearance.fontSizePx, 16, 8, 48);
        merged.appearance.marginTopPx = clampNumber(merged.appearance.marginTopPx, 10, 0, 60);
        merged.appearance.uppercase = merged.appearance.uppercase !== false;
        merged.appearance.centerContent = merged.appearance.centerContent !== false;
        merged.appearance.showTextMarker = merged.appearance.showTextMarker !== false;

        if (Array.isArray(src.blocks)) {
            merged.blocks = src.blocks.map(normalizeBlock);
        } else {
            merged.blocks = merged.blocks.map(normalizeBlock);
        }

        merged.countHighlight = Object.assign({}, merged.countHighlight, src.countHighlight || {});
        merged.countHighlight.enabled = merged.countHighlight.enabled !== false;
        merged.countHighlight.primarySelector = cleanText(merged.countHighlight.primarySelector) || ".number_box a";
        merged.countHighlight.fallbackSelector = cleanText(merged.countHighlight.fallbackSelector) ||
            'a[href*="/cgi-bin/koha/reserve/request.pl?biblionumber="]';
        merged.countHighlight.warningFrom = clampNumber(merged.countHighlight.warningFrom, 3, 0, 9999);
        merged.countHighlight.criticalFrom = clampNumber(merged.countHighlight.criticalFrom, 4, 0, 9999);
        if (merged.countHighlight.criticalFrom < merged.countHighlight.warningFrom) {
            merged.countHighlight.criticalFrom = merged.countHighlight.warningFrom;
        }
        merged.countHighlight.warningColor = cleanText(merged.countHighlight.warningColor) || "#ffa500";
        merged.countHighlight.criticalColor = cleanText(merged.countHighlight.criticalColor) || "#ff0000";
        merged.countHighlight.bold = merged.countHighlight.bold === true;

        merged.advanced = Object.assign({}, merged.advanced, src.advanced || {});
        merged.advanced.watchDynamicContent = merged.advanced.watchDynamicContent !== false;
        merged.advanced.waitMs = clampNumber(merged.advanced.waitMs, 3500, 0, 15000);

        return merged;
    }

    function validate(config) {
        const lang = detectLanguage();
        const fail = function (fr, en) {
            return { ok: false, message: lang === "en" ? en : fr };
        };

        const cfg = normalize(config);

        if (!cfg.page.path) {
            return fail("La page Koha doit être définie.", "The Koha page must be defined.");
        }
        if (!cfg.placement.destinationSelector) {
            return fail("La zone de destination doit être définie.", "The destination area must be defined.");
        }
        if (!cfg.placement.summarySelector) {
            return fail("Le sélecteur des résumés Koha doit être défini.", "The Koha summary selector must be defined.");
        }
        if (!Array.isArray(cfg.blocks)) {
            return fail("La liste des règles est invalide.", "The rule list is invalid.");
        }

        const ids = new Set();
        for (let i = 0; i < cfg.blocks.length; i += 1) {
            const rule = cfg.blocks[i];
            if (!rule || rule.enabled === false) continue;
            if (!rule.id || ids.has(rule.id)) {
                return fail(
                    "Chaque règle active doit avoir un identifiant unique.",
                    "Each enabled rule must have a unique identifier."
                );
            }
            ids.add(rule.id);
            if (!rule.selector && !rule.matchFr && !rule.matchEn) {
                return fail(
                    "Chaque règle active doit avoir un sélecteur ou un texte à reconnaître.",
                    "Each enabled rule must have a selector or matching text."
                );
            }
            if (rule.matchMode === "regex") {
                const patterns = [rule.matchFr, rule.matchEn].filter(Boolean);
                for (const pattern of patterns) {
                    try { new RegExp(pattern, "i"); }
                    catch (_) {
                        return fail(
                            "Une expression régulière du module 103 n'est pas valide.",
                            "One of module 103 regular expressions is invalid."
                        );
                    }
                }
            }
        }

        if (cfg.countHighlight.criticalFrom < cfg.countHighlight.warningFrom) {
            return fail(
                "Le seuil rouge doit être supérieur ou égal au seuil orange.",
                "The red threshold must be greater than or equal to the orange threshold."
            );
        }

        return { ok: true };
    }

    function blockItemTitle(item, index, lang) {
        if (!item) return (lang === "en" ? "Rule " : "Règle ") + (index + 1);
        return cleanText(lang === "en" ? item.adminLabelEn : item.adminLabelFr) ||
            cleanText(item.id) ||
            ((lang === "en" ? "Rule " : "Règle ") + (index + 1));
    }

    function ruleConditionKey(rule) {
        if (cleanText(rule.selector)) return "selector:" + cleanText(rule.selector);
        return String(rule.matchMode || "contains") + ":" + normalizeText(rule.matchFr || rule.matchEn);
    }

    function renderRuleSimulation(context) {
        const cfg = normalize(context && context.rootObject);
        const lang = context && context.language === "en" ? "en" : "fr";
        const wrap = document.createElement("div");
        wrap.className = "pmk103-rule-simulation";
        const seen = new Map();
        const conflicts = [];
        cfg.blocks.filter(function (rule) { return rule.enabled !== false; }).forEach(function (rule) {
            const key = ruleConditionKey(rule);
            if (seen.has(key)) conflicts.push([seen.get(key), rule]);
            else seen.set(key, rule);
        });
        const intro = document.createElement("p");
        intro.textContent = lang === "en"
            ? "Read-only simulation. It shows the condition, text marker and visual result without moving any Koha element."
            : "Simulation en lecture seule : condition, repère textuel et rendu visuel, sans déplacer aucun élément Koha.";
        wrap.appendChild(intro);
        if (conflicts.length) {
            const alert = document.createElement("div");
            alert.className = "alert alert-warning";
            alert.textContent = (lang === "en" ? "Competing rules: " : "Règles concurrentes : ") + conflicts.map(function (pair) {
                return blockItemTitle(pair[0], 0, lang) + " / " + blockItemTitle(pair[1], 0, lang);
            }).join(" · ");
            wrap.appendChild(alert);
        }
        cfg.blocks.filter(function (rule) { return rule.enabled !== false; }).forEach(function (rule, index) {
            const card = document.createElement("div");
            card.style.cssText = "margin:.4rem 0;padding:.55rem .7rem;border:1px solid #d7ded9;border-radius:.35rem;background:" + hexToRgba(rule.backgroundColor, rule.backgroundOpacity);
            const condition = rule.selector
                ? (lang === "en" ? "Selector: " : "Sélecteur : ") + rule.selector
                : (lang === "en" ? "Condition: " : "Condition : ") + rule.matchMode + " — " + (lang === "en" ? (rule.matchEn || rule.matchFr) : (rule.matchFr || rule.matchEn));
            const marker = lang === "en" ? rule.markerTextEn : rule.markerTextFr;
            card.textContent = (cfg.appearance.showTextMarker && marker ? "[" + marker + "] " : "") + blockItemTitle(rule, index, lang) + " · " + condition;
            if (rule.customTextColor) card.style.color = rule.textColor;
            wrap.appendChild(card);
        });
        return wrap;
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: SCHEMA_VERSION,
            name: {
                fr: "Mise en forme conditionnelle — Réservations et listes",
                en: "Conditional formatting — Holds and lists"
            },
            description: {
                fr: "Met en forme et regroupe sur la notice les résumés Réservations, Cours et Listes, avec mise en évidence configurable du nombre de réservations. Le rendu historique du 103 est fourni par défaut. Le tableau des exemplaires reste géré par le 033.",
                en: "Formats and groups Holds, Courses and Lists summaries on the record detail page, with configurable hold-count highlighting. Legacy module 103 styling is the default. Item-table styling remains handled by module 033."
            },
            category: {
                fr: "Réservations & transferts",
                en: "Holds & transfers"
            },
            supportedPages: [DETAIL_PATH],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalize,
            validate: validate,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    description: {
                        fr: "Le module est autonome. Sa désactivation restaure la présentation Koha sans toucher au tableau des exemplaires.",
                        en: "This module is standalone. Disabling it restores Koha presentation without changing the item table."
                    },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer le module", en: "Enable module" }
                        },
                        {
                            key: "page.enabled",
                            type: "boolean",
                            label: { fr: "Activer sur la page détail de notice", en: "Enable on record detail page" }
                        },
                        {
                            key: "page.path",
                            type: "readonly",
                            advanced: true,
                            label: { fr: "Page Koha", en: "Koha page" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "appearance",
                    label: { fr: "Rendu visuel", en: "Visual appearance" },
                    description: {
                        fr: "Ces valeurs reproduisent exactement la logique visuelle historique du 103 : 5 px d'arrondi, 10 px de marge intérieure, texte 16 px centré et en majuscules.",
                        en: "These defaults reproduce legacy module 103 styling: 5 px radius, 10 px padding, centered 16 px uppercase text."
                    },
                    fields: [
                        {
                            key: "appearance.borderRadiusPx",
                            type: "number",
                            min: 0,
                            max: 50,
                            label: { fr: "Arrondi des blocs (px)", en: "Block radius (px)" }
                        },
                        {
                            key: "appearance.paddingPx",
                            type: "number",
                            min: 0,
                            max: 60,
                            label: { fr: "Marge intérieure (px)", en: "Inner padding (px)" }
                        },
                        {
                            key: "appearance.fontSizePx",
                            type: "number",
                            min: 8,
                            max: 48,
                            label: { fr: "Taille du texte (px)", en: "Text size (px)" }
                        },
                        {
                            key: "appearance.marginTopPx",
                            type: "number",
                            min: 0,
                            max: 60,
                            label: { fr: "Marge supérieure (px)", en: "Top margin (px)" }
                        },
                        {
                            key: "appearance.uppercase",
                            type: "boolean",
                            label: { fr: "Afficher en majuscules", en: "Use uppercase text" }
                        },
                        {
                            key: "appearance.centerContent",
                            type: "boolean",
                            label: { fr: "Centrer le contenu", en: "Center content" }
                        },
                        {
                            key: "appearance.showTextMarker",
                            type: "boolean",
                            label: { fr: "Afficher un repère textuel en plus de la couleur", en: "Show a text marker in addition to color" },
                            help: { fr: "Le sens du bloc reste lisible sans dépendre de la perception des couleurs.", en: "The block remains understandable without relying on color perception." }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "blocks",
                    label: { fr: "Réservations, cours et listes", en: "Holds, courses and lists" },
                    description: {
                        fr: "Les trois premières règles sont les réglages historiques du 103. Tu peux les modifier, les réordonner, les désactiver ou ajouter d'autres blocs de même nature.",
                        en: "The first three rules are legacy module 103 defaults. They can be edited, reordered, disabled, or extended with additional summary rules."
                    },
                    fields: [
                        {
                            type: "custom",
                            label: { fr: "Simulation et conflits", en: "Simulation and conflicts" },
                            render: renderRuleSimulation
                        },
                        {
                            key: "blocks",
                            type: "repeater",
                            label: { fr: "Règles de mise en forme", en: "Formatting rules" },
                            addLabel: { fr: "Ajouter une règle", en: "Add rule" },
                            emptyLabel: { fr: "Aucune règle configurée.", en: "No rule configured." },
                            reorder: true,
                            removable: true,
                            itemTitle: blockItemTitle,
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: { fr: "Activer cette règle", en: "Enable this rule" }
                                },
                                {
                                    key: "adminLabelFr",
                                    type: "text",
                                    label: { fr: "Nom de la règle — français", en: "Rule name — French" }
                                },
                                {
                                    key: "adminLabelEn",
                                    type: "text",
                                    label: { fr: "Nom de la règle — anglais", en: "Rule name — English" }
                                },
                                {
                                    key: "matchMode",
                                    type: "select",
                                    label: { fr: "Mode de reconnaissance", en: "Matching mode" },
                                    options: [
                                        { value: "contains", label: { fr: "Le texte contient", en: "Text contains" } },
                                        { value: "exact", label: { fr: "Le texte correspond", en: "Exact text" } },
                                        { value: "regex", label: { fr: "Expression régulière", en: "Regular expression" } }
                                    ]
                                },
                                {
                                    key: "matchFr",
                                    type: "text",
                                    label: { fr: "Texte reconnu — français", en: "Matching text — French" }
                                },
                                {
                                    key: "matchEn",
                                    type: "text",
                                    label: { fr: "Texte reconnu — anglais", en: "Matching text — English" }
                                },
                                {
                                    key: "replacementLabelFr",
                                    type: "text",
                                    label: { fr: "Nouveau libellé français (vide = conserver)", en: "French replacement label (blank = keep)" }
                                },
                                {
                                    key: "replacementLabelEn",
                                    type: "text",
                                    label: { fr: "Nouveau libellé anglais (vide = conserver)", en: "English replacement label (blank = keep)" }
                                },
                                {
                                    key: "markerTextFr",
                                    type: "text",
                                    label: { fr: "Repère textuel — français", en: "Text marker — French" }
                                },
                                {
                                    key: "markerTextEn",
                                    type: "text",
                                    label: { fr: "Repère textuel — anglais", en: "Text marker — English" }
                                },
                                {
                                    key: "backgroundColor",
                                    type: "color",
                                    label: { fr: "Couleur de fond", en: "Background color" }
                                },
                                {
                                    key: "backgroundOpacity",
                                    type: "number",
                                    min: 0,
                                    max: 1,
                                    step: 0.05,
                                    label: { fr: "Opacité du fond (0 à 1)", en: "Background opacity (0 to 1)" }
                                },
                                {
                                    key: "customTextColor",
                                    type: "boolean",
                                    refreshOnChange: true,
                                    label: { fr: "Forcer une couleur de texte", en: "Force a text color" }
                                },
                                {
                                    key: "textColor",
                                    type: "color",
                                    label: { fr: "Couleur du texte", en: "Text color" },
                                    when: function (root, path) {
                                        const index = path[path.length - 2];
                                        return Boolean(root.blocks && root.blocks[index] && root.blocks[index].customTextColor);
                                    }
                                },
                                {
                                    key: "selector",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Sélecteur CSS prioritaire", en: "Priority CSS selector" },
                                    help: {
                                        fr: "Optionnel. S'il correspond à un résumé Koha, il est utilisé avant la reconnaissance par texte.",
                                        en: "Optional. When it matches a Koha summary, it is used before text matching."
                                    }
                                },
                                {
                                    key: "id",
                                    type: "readonly",
                                    advanced: true,
                                    label: { fr: "Identifiant interne", en: "Internal identifier" }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "count",
                    label: { fr: "Nombre de réservations", en: "Hold count" },
                    description: {
                        fr: "Par défaut : 3 réservations = orange ; à partir de 4 = rouge. En dessous de 3, Koha conserve son apparence normale.",
                        en: "Default: 3 holds = orange; 4 or more = red. Below 3, Koha keeps its normal appearance."
                    },
                    fields: [
                        {
                            key: "countHighlight.enabled",
                            type: "boolean",
                            label: { fr: "Mettre en évidence le compteur", en: "Highlight hold count" }
                        },
                        {
                            key: "countHighlight.warningFrom",
                            type: "number",
                            min: 0,
                            max: 9999,
                            label: { fr: "Seuil orange à partir de", en: "Orange threshold from" }
                        },
                        {
                            key: "countHighlight.warningColor",
                            type: "color",
                            label: { fr: "Couleur du premier seuil", en: "First threshold color" }
                        },
                        {
                            key: "countHighlight.criticalFrom",
                            type: "number",
                            min: 0,
                            max: 9999,
                            label: { fr: "Seuil rouge à partir de", en: "Red threshold from" }
                        },
                        {
                            key: "countHighlight.criticalColor",
                            type: "color",
                            label: { fr: "Couleur du second seuil", en: "Second threshold color" }
                        },
                        {
                            key: "countHighlight.bold",
                            type: "boolean",
                            label: { fr: "Afficher le compteur en gras", en: "Display count in bold" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "advanced",
                    label: { fr: "Ciblage avancé", en: "Advanced targeting" },
                    fields: [
                        {
                            key: "placement.destinationSelector",
                            type: "text",
                            advanced: true,
                            label: { fr: "Zone de destination", en: "Destination area" }
                        },
                        {
                            key: "placement.summarySelector",
                            type: "text",
                            advanced: true,
                            label: { fr: "Résumés Koha analysés", en: "Koha summaries to inspect" }
                        },
                        {
                            key: "placement.mode",
                            type: "select",
                            advanced: true,
                            label: { fr: "Insertion dans la destination", en: "Insertion in destination" },
                            options: [
                                { value: "append", label: { fr: "À la fin", en: "At the end" } },
                                { value: "prepend", label: { fr: "Au début", en: "At the beginning" } }
                            ]
                        },
                        {
                            key: "countHighlight.primarySelector",
                            type: "text",
                            advanced: true,
                            label: { fr: "Sélecteur principal du compteur", en: "Primary count selector" }
                        },
                        {
                            key: "countHighlight.fallbackSelector",
                            type: "text",
                            advanced: true,
                            label: { fr: "Sélecteur de secours du compteur", en: "Fallback count selector" }
                        },
                        {
                            key: "advanced.watchDynamicContent",
                            type: "boolean",
                            advanced: true,
                            label: { fr: "Détecter les résumés ajoutés dynamiquement", en: "Detect dynamically added summaries" }
                        },
                        {
                            key: "advanced.waitMs",
                            type: "number",
                            min: 0,
                            max: 15000,
                            advanced: true,
                            label: { fr: "Attente maximale initiale (ms)", en: "Initial maximum wait (ms)" }
                        }
                    ]
                }
            ]
        };
    }

    function hexToRgba(hex, alpha) {
        const raw = cleanText(hex).replace("#", "");
        if (!/^[0-9a-f]{3}([0-9a-f]{3})?$/i.test(raw)) {
            return "rgba(255,255,255," + alpha + ")";
        }
        const normalized = raw.length === 3
            ? raw.split("").map(function (c) { return c + c; }).join("")
            : raw;
        const r = parseInt(normalized.slice(0, 2), 16);
        const g = parseInt(normalized.slice(2, 4), 16);
        const b = parseInt(normalized.slice(4, 6), 16);
        return "rgba(" + r + "," + g + "," + b + "," + alpha + ")";
    }

    function getRulePatterns(rule, lang) {
        const first = lang === "en" ? rule.matchEn : rule.matchFr;
        const second = lang === "en" ? rule.matchFr : rule.matchEn;
        return [first, second].map(cleanText).filter(Boolean);
    }

    function matchesRule(element, rule, lang) {
        if (!element || !rule || rule.enabled === false) return false;

        if (rule.selector) {
            try {
                if (element.matches(rule.selector) || element.querySelector(rule.selector)) return true;
            } catch (_) {}
        }

        const text = cleanText(element.textContent);
        const normalized = normalizeText(text);
        const patterns = getRulePatterns(rule, lang);
        if (!patterns.length) return false;

        if (rule.matchMode === "regex") {
            return patterns.some(function (pattern) {
                try { return new RegExp(pattern, "i").test(text); }
                catch (_) { return false; }
            });
        }

        if (rule.matchMode === "exact") {
            return patterns.some(function (pattern) {
                return normalized === normalizeText(pattern);
            });
        }

        return patterns.some(function (pattern) {
            return normalized.indexOf(normalizeText(pattern)) !== -1;
        });
    }

    function diagnoseRules(config, root) {
        const cfg = normalize(config);
        const scope = root && typeof root.querySelectorAll === "function" ? root : document;
        let candidates = [];
        try { candidates = Array.from(scope.querySelectorAll(cfg.placement.summarySelector)); }
        catch (_) { return { validSelector: false, candidates: 0, rules: [], conflicts: [] }; }
        const lang = detectLanguage();
        const rules = cfg.blocks.filter(function (rule) { return rule.enabled !== false; }).map(function (rule) {
            const matches = candidates.filter(function (element) { return matchesRule(element, rule, lang); });
            return { id: rule.id, label: lang === "en" ? rule.adminLabelEn : rule.adminLabelFr, condition: ruleConditionKey(rule), matches: matches.length };
        });
        const conflicts = candidates.map(function (element, index) {
            const ids = cfg.blocks.filter(function (rule) { return rule.enabled !== false && matchesRule(element, rule, lang); }).map(function (rule) { return rule.id; });
            return ids.length > 1 ? { candidate: index + 1, text: cleanText(element.textContent), ruleIds: ids } : null;
        }).filter(Boolean);
        return { validSelector: true, candidates: candidates.length, rules: rules, conflicts: conflicts };
    }

    function restorePreviousRun() {
        applying = true;
        try {
            countTargets.forEach(function (previous, element) {
                if (!element || !element.style) return;
                element.style.color = previous.color;
                element.style.fontWeight = previous.fontWeight;
                element.removeAttribute("data-pmk103-count");
            });
            countTargets.clear();

            originalLabels.forEach(function (originalText, label) {
                if (label && label.isConnected) label.textContent = originalText;
            });
            originalLabels.clear();

            movedElements.forEach(function (placeholder, element) {
                if (!element) return;
                element.classList.remove("pmk103-summary");
                element.removeAttribute("data-pmk103-managed");
                if (placeholder && placeholder.parentNode) {
                    placeholder.parentNode.insertBefore(element, placeholder);
                    placeholder.remove();
                }
            });
            movedElements.clear();

            generatedWrappers.forEach(function (wrapper) {
                if (wrapper && wrapper.parentNode) wrapper.remove();
            });
            generatedWrappers.clear();

            const style = document.getElementById("pmk103-style");
            if (style) style.remove();
        } finally {
            applying = false;
        }
    }

    function injectStyles(cfg) {
        const old = document.getElementById("pmk103-style");
        if (old) old.remove();

        const a = cfg.appearance;
        const style = document.createElement("style");
        style.id = "pmk103-style";
        style.textContent = [
            ".pmk103-block{",
            "position:relative;",
            "border-radius:" + a.borderRadiusPx + "px;",
            "}",
            ".pmk103-block .pmk103-summary{",
            "padding:" + a.paddingPx + "px;",
            "border-radius:" + a.borderRadiusPx + "px;",
            "display:flex;",
            "align-items:center;",
            a.centerContent ? "justify-content:center;" : "",
            "font-size:" + a.fontSizePx + "px;",
            a.uppercase ? "text-transform:uppercase;" : "text-transform:none;",
            "margin-top:" + a.marginTopPx + "px;",
            "}",
            ".pmk103-rule-marker{display:inline-flex;align-items:center;align-self:center;margin:" + a.marginTopPx + "px .45rem 0 0;padding:.18rem .42rem;border:1px solid currentColor;border-radius:.3rem;font-size:.72em;font-weight:700;text-transform:none;}",
            ".pmk103-block > .pmk-context-config{",
            "position:absolute;",
            "top:2px;",
            "right:2px;",
            "z-index:2;",
            "opacity:.38;",
            "padding:.15rem .3rem;",
            "line-height:1;",
            "}",
            ".pmk103-block > .pmk-context-config:hover,",
            ".pmk103-block > .pmk-context-config:focus{opacity:1;}"
        ].join("");
        document.head.appendChild(style);
    }

    function replacementForRule(rule, lang) {
        return cleanText(lang === "en" ? rule.replacementLabelEn : rule.replacementLabelFr);
    }

    function applyBlocks(cfg) {
        const destinationSelector = safeCssSelector(cfg.placement.destinationSelector, DESTINATION_SELECTOR);
        const summarySelector = safeCssSelector(cfg.placement.summarySelector, SUMMARY_SELECTOR);
        const destination = document.querySelector(destinationSelector);
        if (!destination) return 0;

        const candidates = Array.from(document.querySelectorAll(summarySelector))
            .filter(function (el) {
                return !el.closest(".pmk103-block");
            });

        if (!candidates.length) return 0;

        const lang = detectLanguage();
        const used = new Set();
        const wrappers = [];

        cfg.blocks.forEach(function (rule) {
            if (!rule || rule.enabled === false) return;

            const matches = candidates.filter(function (element) {
                return !used.has(element) && matchesRule(element, rule, lang);
            });
            if (!matches.length) return;

            const wrapper = document.createElement("div");
            wrapper.className = "pmk103-block pmk103-block-" + slug(rule.id, "rule");
            wrapper.setAttribute("data-pmk103-rule", rule.id);
            wrapper.style.backgroundColor = hexToRgba(rule.backgroundColor, rule.backgroundOpacity);
            wrapper.style.borderRadius = cfg.appearance.borderRadiusPx + "px";
            if (rule.customTextColor) wrapper.style.color = rule.textColor;

            if (cfg.appearance.showTextMarker) {
                const markerText = cleanText(lang === "en" ? rule.markerTextEn : rule.markerTextFr);
                if (markerText) {
                    const marker = document.createElement("span");
                    marker.className = "pmk103-rule-marker";
                    marker.textContent = markerText;
                    marker.setAttribute("aria-label", (lang === "en" ? "Formatting rule: " : "Règle de mise en forme : ") + markerText);
                    wrapper.appendChild(marker);
                }
            }

            matches.forEach(function (element) {
                used.add(element);

                const placeholder = document.createComment("pmk103:" + rule.id);
                if (element.parentNode) {
                    element.parentNode.insertBefore(placeholder, element);
                    movedElements.set(element, placeholder);
                }

                const label = element.querySelector(".label");
                const replacement = replacementForRule(rule, lang);
                if (label && replacement) {
                    if (!originalLabels.has(label)) originalLabels.set(label, label.textContent);
                    label.textContent = replacement;
                }

                element.classList.add("pmk103-summary");
                element.setAttribute("data-pmk103-managed", rule.id);
                wrapper.appendChild(element);
            });

            generatedWrappers.add(wrapper);
            wrappers.push(wrapper);
        });

        if (!wrappers.length) return 0;

        if (cfg.placement.mode === "prepend") {
            for (let i = wrappers.length - 1; i >= 0; i -= 1) {
                destination.insertBefore(wrappers[i], destination.firstChild);
            }
        } else {
            wrappers.forEach(function (wrapper) {
                destination.appendChild(wrapper);
            });
        }

        mountContextButton(wrappers[0]);
        return wrappers.length;
    }

    function parseCount(element) {
        if (!element) return NaN;

        const dataCandidates = [
            element.getAttribute("data-count"),
            element.getAttribute("data-holds-count"),
            element.getAttribute("data-reservations-count")
        ];
        for (const value of dataCandidates) {
            const n = Number(value);
            if (Number.isFinite(n)) return n;
        }

        const text = cleanText(element.textContent);
        if (!text) return NaN;

        const parenthetical = text.match(/\((\d+)\)\s*$/);
        if (parenthetical) return Number(parenthetical[1]);

        const numbers = text.match(/\d+/g);
        if (!numbers || !numbers.length) return NaN;
        return Number(numbers[numbers.length - 1]);
    }

    function findCountTarget(cfg) {
        const selectors = [
            cfg.countHighlight.primarySelector,
            cfg.countHighlight.fallbackSelector
        ].map(cleanText).filter(Boolean);

        for (const selector of selectors) {
            try {
                const elements = Array.from(document.querySelectorAll(selector));
                for (const element of elements) {
                    const count = parseCount(element);
                    if (Number.isFinite(count)) return { element: element, count: count };
                }
            } catch (_) {}
        }
        return null;
    }

    function applyCountHighlight(cfg) {
        if (!cfg.countHighlight.enabled) return false;

        const found = findCountTarget(cfg);
        if (!found) return false;

        const element = found.element;
        const count = found.count;
        const settings = cfg.countHighlight;

        if (!countTargets.has(element)) {
            countTargets.set(element, {
                color: element.style.color || "",
                fontWeight: element.style.fontWeight || ""
            });
        }

        let color = "";
        if (count >= settings.criticalFrom) {
            color = settings.criticalColor;
        } else if (count >= settings.warningFrom) {
            color = settings.warningColor;
        }

        if (!color) return false;

        element.style.color = color;
        if (settings.bold) element.style.fontWeight = "700";
        element.setAttribute("data-pmk103-count", String(count));
        return true;
    }

    function mountContextButton(anchor) {
        try {
            const pmk = window.PMKConfig;
            if (!pmk || typeof pmk.mountContextButton !== "function" || !anchor) return;
            pmk.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                contextKey: "summary",
                position: "inside",
                context: {
                    page: "catalogue.detail",
                    path: DETAIL_PATH
                }
            });
        } catch (_) {}
    }

    function applyConfig(config) {
        if (!isDetailPage()) return;

        const cfg = normalize(config);
        currentConfig = cfg;

        restorePreviousRun();

        if (!cfg.enabled || !cfg.page.enabled || cfg.page.path !== window.location.pathname) {
            stopObserver();
            return;
        }

        applying = true;
        try {
            injectStyles(cfg);
            applyBlocks(cfg);
            applyCountHighlight(cfg);
        } finally {
            applying = false;
        }

        if (cfg.advanced.watchDynamicContent) startObserver();
        else stopObserver();
    }

    function scheduleReapply() {
        if (applying || !currentConfig) return;
        window.clearTimeout(reapplyTimer);
        reapplyTimer = window.setTimeout(function () {
            if (!currentConfig) return;
            applyConfig(currentConfig);
        }, 80);
    }

    function mutationContainsNewSummary(mutation) {
        const summarySelector = safeCssSelector(
            currentConfig && currentConfig.placement && currentConfig.placement.summarySelector,
            SUMMARY_SELECTOR
        );

        for (const node of Array.from(mutation.addedNodes || [])) {
            if (!node || node.nodeType !== 1) continue;
            const element = node;
            if (element.closest && element.closest(".pmk103-block")) continue;
            try {
                if (element.matches(summarySelector) && !element.hasAttribute("data-pmk103-managed")) return true;
                if (element.querySelector && element.querySelector(summarySelector + ":not([data-pmk103-managed])")) return true;
            } catch (_) {}
        }
        return false;
    }

    function startObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(function (mutations) {
            if (applying || !currentConfig) return;
            if (mutations.some(mutationContainsNewSummary)) scheduleReapply();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function stopObserver() {
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        window.clearTimeout(reapplyTimer);
        reapplyTimer = null;
    }

    function waitThenApply(config) {
        const cfg = normalize(config);
        if (!isDetailPage()) return;

        const deadline = Date.now() + cfg.advanced.waitMs;

        function attempt() {
            const destinationSelector = safeCssSelector(cfg.placement.destinationSelector, DESTINATION_SELECTOR);
            const summarySelector = safeCssSelector(cfg.placement.summarySelector, SUMMARY_SELECTOR);
            const destination = document.querySelector(destinationSelector);
            const summaries = document.querySelectorAll(summarySelector);

            if (destination && summaries.length) {
                applyConfig(cfg);
                return;
            }

            if (Date.now() < deadline) {
                window.setTimeout(attempt, 100);
            } else {
                applyConfig(cfg);
            }
        }

        attempt();
    }

    function subscribeToConfig(pmk) {
        if (!pmk || typeof pmk.subscribe !== "function") return;
        pmk.subscribe(MODULE_ID, function (nextConfig) {
            waitThenApply(nextConfig);
        });
    }

    function bootWithPMK() {
        if (booted) return;
        const pmk = window.PMKConfig;
        if (!pmk || typeof pmk.getConfig !== "function") return;

        booted = true;

        if (!isDetailPage()) return;

        pmk.getConfig(MODULE_ID)
            .then(waitThenApply)
            .catch(function () {
                waitThenApply(DEFAULT_CONFIG);
            });

        subscribeToConfig(pmk);
    }

    function registerWithPMK() {
        if (registered) {
            bootWithPMK();
            return true;
        }

        const pmk = window.PMKConfig;
        if (!pmk || typeof pmk.registerModule !== "function") return false;

        pmk.registerModule(moduleDefinition());
        registered = true;
        bootWithPMK();
        return true;
    }

    function standaloneFallback() {
        if (registered || booted || !isDetailPage()) return;
        waitThenApply(DEFAULT_CONFIG);
    }

    function init() {
        if (registerWithPMK()) return;

        window.addEventListener("pmk:config-ready", function () {
            registerWithPMK();
        }, { once: true });

        // Compatibilité : le script reste utilisable isolément même si le
        // socle PMK n'est pas présent. Le rendu historique est alors appliqué.
        window.setTimeout(standaloneFallback, 700);
    }

    window.PMK103ConditionalFormatting = Object.freeze({
        diagnose: function (config, root) { return diagnoseRules(config || currentConfig || DEFAULT_CONFIG, root); },
        simulate: renderRuleSimulation,
        defaults: function () { return clone(DEFAULT_CONFIG); }
    });

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init, { once: true });
    } else {
        init();
    }
})();

;window.PMKNonPlugin.loaded.push("103-detail-reservations-summary-style.js");
} catch (error) { window.PMKNonPlugin.errors.push("103-detail-reservations-summary-style.js: "+error.message); console.error("[PMK] 103-detail-reservations-summary-style.js",error); };
try {
/* ============================================================
   106-scroll-buttons.js
   PimpMyKoha — module autonome
   Nom : Navigation rapide — haut / bas de page
   Version : 2.0.2-preplugin
   Date : 2026-09-20

   - conserve le rendu historique par défaut ;
   - personnalisation visuelle complète ;
   - comportement desktop/mobile configurable ;
   - scroll fluide respectant prefers-reduced-motion ;
   - aucun déblocage agressif du scroll par défaut ;
   - option avancée de réparation limitée aux styles inline résiduels ;
   - compatible avec le socle PMK et utilisable seul avec les valeurs par défaut.
   - 2.0.1 : le panneau de configuration PMK ne masque plus les boutons pendant la recette.
   - 2.0.1 : exposition d’un diagnostic runtime PMK106ScrollButtons.
   - 2.0.2 : détection des modales resserrée aux vraies fenêtres ouvertes ; suppression du faux positif générique aria-modal.
   ============================================================ */
(function () {
    "use strict";

    if (window.__PMK106_SCROLL_BUTTONS__) return;
    window.__PMK106_SCROLL_BUTTONS__ = true;

    const MODULE_ID = "scroll-buttons";
    const VERSION = "2.0.2-preplugin";
    const STYLE_ID = "pmk106-scroll-buttons-style";
    const DOWN_ID = "scroll-button-down";
    const UP_ID = "scroll-button-up";
    const DOWN_WRAP_ID = "pmk106-scroll-down-wrap";
    const UP_WRAP_ID = "pmk106-scroll-up-wrap";
    const CONFIG_HOST_ID = "pmk106-config-host";

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: {
            mode: "all",
            patterns: ""
        },
        behavior: {
            smoothScroll: true,
            respectReducedMotion: true,
            upThresholdPx: 200,
            bottomEpsilonPx: 2,
            hideWhenDialogOpen: true
        },
        desktop: {
            showDown: true,
            showUp: true,
            side: "right",
            horizontalOffsetPx: 28,
            downTopPx: 40,
            upBottomPx: 30,
            sizePx: 50
        },
        mobile: {
            breakpointPx: 768,
            showDown: false,
            showUp: true,
            side: "right",
            horizontalOffsetPx: 18,
            downTopPx: 18,
            upBottomPx: 18,
            sizePx: 50
        },
        appearance: {
            backgroundColor: "#408540",
            hoverBackgroundColor: "#0056b3",
            iconColor: "#ffffff",
            borderColor: "#408540",
            borderWidthPx: 0,
            borderRadiusPercent: 50,
            opacity: 1,
            hoverScale: 1,
            shadowEnabled: true,
            shadow: "0 2px 6px rgba(0,0,0,0.3)",
            iconMode: "symbol",
            downSymbol: "▼",
            upSymbol: "▲",
            downFaClass: "fa fa-arrow-down",
            upFaClass: "fa fa-arrow-up",
            iconSizePx: 22,
            zIndex: 10000
        },
        labels: {
            downFr: "Descendre en bas",
            downEn: "Scroll to bottom",
            upFr: "Remonter en haut",
            upEn: "Scroll to top"
        },
        advanced: {
            repairResidualScrollLock: false,
            repairCooldownMs: 1000
        }
    };

    const state = {
        config: null,
        down: null,
        up: null,
        downWrap: null,
        upWrap: null,
        configHost: null,
        ticking: false,
        lastRepairTs: 0,
        resizeObserver: null,
        abortController: null,
        contextMounted: false
    };

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function object(value) {
        return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    }

    function merge(base, override) {
        const out = clone(base);
        Object.keys(object(override)).forEach(function (key) {
            if (out[key] && typeof out[key] === "object" && !Array.isArray(out[key]) &&
                override[key] && typeof override[key] === "object" && !Array.isArray(override[key])) {
                out[key] = merge(out[key], override[key]);
            } else {
                out[key] = clone(override[key]);
            }
        });
        return out;
    }

    function num(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function text(value, fallback) {
        const s = String(value == null ? "" : value).trim();
        return s || fallback;
    }

    function normalize(config) {
        const cfg = merge(DEFAULT_CONFIG, object(config));
        cfg.enabled = cfg.enabled !== false;

        cfg.pages = merge(DEFAULT_CONFIG.pages, object(cfg.pages));
        if (!["all", "include", "exclude"].includes(cfg.pages.mode)) cfg.pages.mode = "all";
        cfg.pages.patterns = String(cfg.pages.patterns || "");

        cfg.behavior = merge(DEFAULT_CONFIG.behavior, object(cfg.behavior));
        cfg.behavior.smoothScroll = cfg.behavior.smoothScroll !== false;
        cfg.behavior.respectReducedMotion = cfg.behavior.respectReducedMotion !== false;
        cfg.behavior.hideWhenDialogOpen = cfg.behavior.hideWhenDialogOpen !== false;
        cfg.behavior.upThresholdPx = num(cfg.behavior.upThresholdPx, 0, 10000, 200);
        cfg.behavior.bottomEpsilonPx = num(cfg.behavior.bottomEpsilonPx, 0, 500, 2);

        ["desktop", "mobile"].forEach(function (section) {
            cfg[section] = merge(DEFAULT_CONFIG[section], object(cfg[section]));
            cfg[section].showDown = cfg[section].showDown !== false;
            cfg[section].showUp = cfg[section].showUp !== false;
            cfg[section].side = cfg[section].side === "left" ? "left" : "right";
            cfg[section].horizontalOffsetPx = num(cfg[section].horizontalOffsetPx, 0, 500, DEFAULT_CONFIG[section].horizontalOffsetPx);
            cfg[section].downTopPx = num(cfg[section].downTopPx, 0, 500, DEFAULT_CONFIG[section].downTopPx);
            cfg[section].upBottomPx = num(cfg[section].upBottomPx, 0, 500, DEFAULT_CONFIG[section].upBottomPx);
            cfg[section].sizePx = num(cfg[section].sizePx, 28, 100, DEFAULT_CONFIG[section].sizePx);
        });
        cfg.mobile.breakpointPx = num(cfg.mobile.breakpointPx, 320, 1600, 768);

        cfg.appearance = merge(DEFAULT_CONFIG.appearance, object(cfg.appearance));
        cfg.appearance.backgroundColor = text(cfg.appearance.backgroundColor, "#408540");
        cfg.appearance.hoverBackgroundColor = text(cfg.appearance.hoverBackgroundColor, "#0056b3");
        cfg.appearance.iconColor = text(cfg.appearance.iconColor, "#ffffff");
        cfg.appearance.borderColor = text(cfg.appearance.borderColor, cfg.appearance.backgroundColor);
        cfg.appearance.borderWidthPx = num(cfg.appearance.borderWidthPx, 0, 12, 0);
        cfg.appearance.borderRadiusPercent = num(cfg.appearance.borderRadiusPercent, 0, 50, 50);
        cfg.appearance.opacity = num(cfg.appearance.opacity, 0.15, 1, 1);
        cfg.appearance.hoverScale = num(cfg.appearance.hoverScale, 1, 1.5, 1);
        cfg.appearance.shadowEnabled = cfg.appearance.shadowEnabled !== false;
        cfg.appearance.shadow = String(cfg.appearance.shadow || DEFAULT_CONFIG.appearance.shadow);
        cfg.appearance.iconMode = cfg.appearance.iconMode === "fontawesome" ? "fontawesome" : "symbol";
        cfg.appearance.downSymbol = String(cfg.appearance.downSymbol == null ? "▼" : cfg.appearance.downSymbol).slice(0, 8) || "▼";
        cfg.appearance.upSymbol = String(cfg.appearance.upSymbol == null ? "▲" : cfg.appearance.upSymbol).slice(0, 8) || "▲";
        cfg.appearance.downFaClass = text(cfg.appearance.downFaClass, "fa fa-arrow-down");
        cfg.appearance.upFaClass = text(cfg.appearance.upFaClass, "fa fa-arrow-up");
        cfg.appearance.iconSizePx = num(cfg.appearance.iconSizePx, 10, 48, 22);
        cfg.appearance.zIndex = Math.round(num(cfg.appearance.zIndex, 100, 200000, 10000));

        cfg.labels = merge(DEFAULT_CONFIG.labels, object(cfg.labels));
        Object.keys(DEFAULT_CONFIG.labels).forEach(function (key) {
            cfg.labels[key] = text(cfg.labels[key], DEFAULT_CONFIG.labels[key]);
        });

        cfg.advanced = merge(DEFAULT_CONFIG.advanced, object(cfg.advanced));
        cfg.advanced.repairResidualScrollLock = cfg.advanced.repairResidualScrollLock === true;
        cfg.advanced.repairCooldownMs = num(cfg.advanced.repairCooldownMs, 250, 10000, 1000);
        return cfg;
    }

    function language() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            }
        } catch (_) {}
        return String(document.documentElement.lang || "fr").toLowerCase().indexOf("en") === 0 ? "en" : "fr";
    }

    function lines(value) {
        return String(value || "")
            .split(/\r?\n/)
            .map(function (line) { return line.trim(); })
            .filter(Boolean);
    }

    function wildcardMatch(value, pattern) {
        if (!pattern) return false;
        const escaped = pattern
            .replace(/[.+?^${}()|[\]\\]/g, "\\$&")
            .replace(/\*/g, ".*");
        try { return new RegExp("^" + escaped + "$").test(value); }
        catch (_) { return value === pattern; }
    }

    function pageAllowed(cfg) {
        if (!cfg.enabled) return false;
        if (cfg.pages.mode === "all") return true;
        const patterns = lines(cfg.pages.patterns);
        if (!patterns.length) return cfg.pages.mode !== "include";
        const current = window.location.pathname;
        const matched = patterns.some(function (pattern) { return wildcardMatch(current, pattern); });
        return cfg.pages.mode === "include" ? matched : !matched;
    }

    function getScrollElement() {
        return document.scrollingElement || document.documentElement || document.body;
    }

    function getScrollY() {
        const el = getScrollElement();
        return window.pageYOffset || (el && el.scrollTop) || 0;
    }

    function getMaxScrollTop() {
        const el = getScrollElement();
        if (!el) return 0;
        return Math.max(0, el.scrollHeight - el.clientHeight);
    }

    function blockingDialogs() {
        // Ne jamais utiliser [aria-modal="true"] seul : Koha/PMK peuvent conserver
        // dans le DOM des composants accessibles qui ne sont pas réellement ouverts.
        const selectors = [
            ".modal.show",
            ".modal.in",
            ".offcanvas.show",
            ".ui-dialog",
            ".pmk-shared-dialog-backdrop"
        ];
        const seen = new Set();
        const matches = [];
        selectors.forEach(function (selector) {
            Array.from(document.querySelectorAll(selector)).forEach(function (node) {
                if (!node || node === state.configHost || seen.has(node)) return;
                // Le panneau de configuration PMK ne doit jamais masquer la navigation rapide.
                if (node.closest && (node.closest(".pmk-config-overlay") || node.closest(".pmk-config-dialog") || node.closest("[data-pmk-config-root]"))) return;
                const style = window.getComputedStyle(node);
                if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity || 1) === 0) return;
                const rect = node.getBoundingClientRect();
                const intersectsViewport = rect.width > 1 && rect.height > 1 && rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
                if (!intersectsViewport) return;
                seen.add(node);
                matches.push(node);
            });
        });
        return matches;
    }

    function dialogIsVisible() {
        return blockingDialogs().length > 0;
    }

    function isMobile(cfg) {
        return window.innerWidth <= cfg.mobile.breakpointPx;
    }

    function responsiveConfig(cfg) {
        return isMobile(cfg) ? cfg.mobile : cfg.desktop;
    }

    function reducedMotion(cfg) {
        if (!cfg.behavior.respectReducedMotion || !window.matchMedia) return false;
        try { return window.matchMedia("(prefers-reduced-motion: reduce)").matches; }
        catch (_) { return false; }
    }

    function scrollToY(top) {
        const cfg = state.config || DEFAULT_CONFIG;
        const target = Math.max(0, Math.min(Number(top) || 0, getMaxScrollTop()));
        const smooth = cfg.behavior.smoothScroll && !reducedMotion(cfg);
        try {
            window.scrollTo({ top: target, behavior: smooth ? "smooth" : "auto" });
            return;
        } catch (_) {}
        try { window.scrollTo(0, target); }
        catch (_) {
            const el = getScrollElement();
            if (el) el.scrollTop = target;
        }
    }

    function iconMarkup(direction, cfg) {
        const a = cfg.appearance;
        if (a.iconMode === "fontawesome") {
            const cls = direction === "down" ? a.downFaClass : a.upFaClass;
            return '<i class="' + cls.replace(/[<>"']/g, "") + '" aria-hidden="true"></i>';
        }
        const symbol = direction === "down" ? a.downSymbol : a.upSymbol;
        const span = document.createElement("span");
        span.textContent = symbol;
        return '<span aria-hidden="true">' + span.innerHTML + '</span>';
    }

    function labels(cfg) {
        const lang = language();
        return {
            down: lang === "en" ? cfg.labels.downEn : cfg.labels.downFr,
            up: lang === "en" ? cfg.labels.upEn : cfg.labels.upFr
        };
    }

    function injectStyles(cfg) {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }
        const a = cfg.appearance;
        style.textContent = `
            .pmk106-scroll-wrap {
                position: fixed;
                z-index: ${a.zIndex};
                pointer-events: none;
            }
            .pmk106-scroll-btn {
                box-sizing: border-box;
                display: none;
                align-items: center;
                justify-content: center;
                padding: 0;
                margin: 0;
                background: ${a.backgroundColor};
                color: ${a.iconColor};
                border: ${a.borderWidthPx}px solid ${a.borderColor};
                border-radius: ${a.borderRadiusPercent}%;
                cursor: pointer;
                opacity: ${a.opacity};
                box-shadow: ${a.shadowEnabled ? a.shadow : "none"};
                line-height: 1;
                touch-action: manipulation;
                pointer-events: auto;
                transition: background-color .2s ease, opacity .2s ease, transform .15s ease, box-shadow .2s ease;
            }
            .pmk106-scroll-btn:hover,
            .pmk106-scroll-btn:focus-visible {
                background: ${a.hoverBackgroundColor};
                color: ${a.iconColor};
                transform: scale(${a.hoverScale});
            }
            .pmk106-scroll-btn:focus-visible {
                outline: 3px solid rgba(13,110,253,.35);
                outline-offset: 2px;
            }
            .pmk106-scroll-btn span,
            .pmk106-scroll-btn i {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: ${a.iconSizePx}px;
                line-height: 1;
                color: inherit;
                pointer-events: none;
            }
            #${CONFIG_HOST_ID} {
                position: fixed;
                z-index: ${a.zIndex + 1};
                display: none;
            }
            #${CONFIG_HOST_ID} .pmk-context-config {
                width: 24px;
                height: 24px;
                min-width: 24px;
                padding: 0 !important;
                margin: 0 !important;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                color: #495057;
                background: rgba(255,255,255,.88);
                border: 1px solid rgba(0,0,0,.14);
                box-shadow: 0 1px 4px rgba(0,0,0,.12);
                opacity: .28;
                pointer-events: auto;
                text-decoration: none;
            }
            #${CONFIG_HOST_ID}:hover .pmk-context-config,
            #${CONFIG_HOST_ID} .pmk-context-config:focus-visible { opacity: 1; }
            @media (prefers-reduced-motion: reduce) {
                .pmk106-scroll-btn { transition: none; }
            }
            @media print {
                .pmk106-scroll-wrap, #${CONFIG_HOST_ID} { display: none !important; }
            }
        `;
    }

    function ensureElements(cfg) {
        if (!document.body) return;
        injectStyles(cfg);

        let downWrap = document.getElementById(DOWN_WRAP_ID);
        if (!downWrap) {
            downWrap = document.createElement("div");
            downWrap.id = DOWN_WRAP_ID;
            downWrap.className = "pmk106-scroll-wrap";
            document.body.appendChild(downWrap);
        }
        let upWrap = document.getElementById(UP_WRAP_ID);
        if (!upWrap) {
            upWrap = document.createElement("div");
            upWrap.id = UP_WRAP_ID;
            upWrap.className = "pmk106-scroll-wrap";
            document.body.appendChild(upWrap);
        }

        let down = document.getElementById(DOWN_ID);
        if (!down) {
            down = document.createElement("button");
            down.type = "button";
            down.id = DOWN_ID;
            down.className = "pmk106-scroll-btn";
            down.addEventListener("click", function () {
                repairResidualScrollLock("click-down");
                scrollToY(getMaxScrollTop());
            });
            downWrap.appendChild(down);
        }

        let up = document.getElementById(UP_ID);
        if (!up) {
            up = document.createElement("button");
            up.type = "button";
            up.id = UP_ID;
            up.className = "pmk106-scroll-btn";
            up.addEventListener("click", function () {
                repairResidualScrollLock("click-up");
                scrollToY(0);
            });
            upWrap.appendChild(up);
        }

        let configHost = document.getElementById(CONFIG_HOST_ID);
        if (!configHost) {
            configHost = document.createElement("div");
            configHost.id = CONFIG_HOST_ID;
            document.body.appendChild(configHost);
        }

        state.downWrap = downWrap;
        state.upWrap = upWrap;
        state.down = down;
        state.up = up;
        state.configHost = configHost;
        refreshButtonContents(cfg);
        mountContextConfig();
    }

    function refreshButtonContents(cfg) {
        if (!state.down || !state.up) return;
        const copy = labels(cfg);
        state.down.title = copy.down;
        state.down.setAttribute("aria-label", copy.down);
        state.down.innerHTML = iconMarkup("down", cfg);
        state.up.title = copy.up;
        state.up.setAttribute("aria-label", copy.up);
        state.up.innerHTML = iconMarkup("up", cfg);
    }

    function positionElements(cfg) {
        if (!state.downWrap || !state.upWrap || !state.down || !state.up) return;
        const r = responsiveConfig(cfg);
        const size = r.sizePx + "px";
        [state.down, state.up].forEach(function (btn) {
            btn.style.width = size;
            btn.style.height = size;
        });

        [state.downWrap, state.upWrap].forEach(function (wrap) {
            wrap.style.left = "";
            wrap.style.right = "";
            wrap.style[r.side] = r.horizontalOffsetPx + "px";
        });
        state.downWrap.style.top = r.downTopPx + "px";
        state.downWrap.style.bottom = "";
        state.upWrap.style.bottom = r.upBottomPx + "px";
        state.upWrap.style.top = "";
    }

    function setButtonVisible(button, visible) {
        if (!button) return;
        button.style.setProperty("display", visible ? "flex" : "none", "important");
        button.setAttribute("aria-hidden", visible ? "false" : "true");
        button.tabIndex = visible ? 0 : -1;
    }

    function positionConfigHost(cfg, downVisible, upVisible) {
        const host = state.configHost;
        if (!host || !host.firstElementChild) return;
        if (!downVisible && !upVisible) {
            host.style.display = "none";
            return;
        }
        const r = responsiveConfig(cfg);
        const beside = Math.max(0, r.horizontalOffsetPx + r.sizePx - 10);
        host.style.display = "block";
        host.style.left = "";
        host.style.right = "";
        host.style.top = "";
        host.style.bottom = "";
        host.style[r.side] = beside + "px";
        if (upVisible) host.style.bottom = Math.max(0, r.upBottomPx + r.sizePx - 10) + "px";
        else host.style.top = Math.max(0, r.downTopPx + r.sizePx - 10) + "px";
    }

    function updateVisibility() {
        state.ticking = false;
        const cfg = state.config;
        if (!cfg || !pageAllowed(cfg) || !state.down || !state.up) return;

        positionElements(cfg);
        const r = responsiveConfig(cfg);
        const max = getMaxScrollTop();
        const y = getScrollY();
        const scrollable = max > Math.max(2, cfg.behavior.bottomEpsilonPx);
        const dialogHidden = cfg.behavior.hideWhenDialogOpen && dialogIsVisible();

        const downVisible = !dialogHidden && scrollable && r.showDown && y < max - cfg.behavior.bottomEpsilonPx;
        const upVisible = !dialogHidden && scrollable && r.showUp && y > cfg.behavior.upThresholdPx;
        setButtonVisible(state.down, downVisible);
        setButtonVisible(state.up, upVisible);
        positionConfigHost(cfg, downVisible, upVisible);
    }

    function scheduleUpdate() {
        if (state.ticking) return;
        state.ticking = true;
        window.requestAnimationFrame(updateVisibility);
    }

    function repairResidualScrollLock() {
        const cfg = state.config;
        if (!cfg || !cfg.advanced.repairResidualScrollLock) return;
        const now = Date.now();
        if (now - state.lastRepairTs < cfg.advanced.repairCooldownMs) return;
        if (dialogIsVisible()) return;

        const html = document.documentElement;
        const body = document.body;
        if (!html || !body) return;
        let changed = false;

        // Réparation volontairement prudente : uniquement les styles INLINE.
        // On ne retire ni classes Koha/Bootstrap ni règles CSS calculées.
        [html, body].forEach(function (node) {
            const overflow = String(node.style.overflow || "").toLowerCase();
            const overflowY = String(node.style.overflowY || "").toLowerCase();
            if (overflow === "hidden") { node.style.overflow = ""; changed = true; }
            if (overflowY === "hidden") { node.style.overflowY = ""; changed = true; }
        });
        if (String(body.style.position || "").toLowerCase() === "fixed") {
            body.style.position = "";
            body.style.top = "";
            body.style.left = "";
            body.style.right = "";
            body.style.width = "";
            changed = true;
        }
        if (changed) state.lastRepairTs = now;
    }

    function bindListeners() {
        if (state.abortController) state.abortController.abort();
        state.abortController = typeof AbortController === "function" ? new AbortController() : null;
        const signal = state.abortController ? { signal: state.abortController.signal } : undefined;

        window.addEventListener("scroll", scheduleUpdate, Object.assign({ passive: true }, signal || {}));
        window.addEventListener("resize", scheduleUpdate, Object.assign({ passive: true }, signal || {}));

        if (state.config && state.config.advanced.repairResidualScrollLock) {
            window.addEventListener("wheel", repairResidualScrollLock, Object.assign({ passive: true }, signal || {}));
            window.addEventListener("touchstart", repairResidualScrollLock, Object.assign({ passive: true }, signal || {}));
            window.addEventListener("keydown", function (event) {
                if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " ", "Spacebar"].includes(event.key)) {
                    repairResidualScrollLock();
                }
            }, signal || undefined);
        }

        if (state.resizeObserver) state.resizeObserver.disconnect();
        state.resizeObserver = null;
        if (typeof ResizeObserver === "function" && document.documentElement) {
            state.resizeObserver = new ResizeObserver(scheduleUpdate);
            try { state.resizeObserver.observe(document.documentElement); } catch (_) {}
            if (document.body) {
                try { state.resizeObserver.observe(document.body); } catch (_) {}
            }
        }
    }

    function mountContextConfig() {
        if (state.contextMounted || !state.configHost) return;
        try {
            const pmk = window.PMKConfig;
            if (!pmk || typeof pmk.mountContextButton !== "function") return;
            const button = pmk.mountContextButton({
                moduleId: MODULE_ID,
                anchor: state.configHost,
                contextKey: "quick-scroll",
                context: { sectionId: "visual" }
            });
            if (button) state.contextMounted = true;
        } catch (_) {}
    }

    function cleanup() {
        [DOWN_WRAP_ID, UP_WRAP_ID, CONFIG_HOST_ID, STYLE_ID].forEach(function (id) {
            const node = document.getElementById(id);
            if (node) node.remove();
        });
        if (state.abortController) state.abortController.abort();
        state.abortController = null;
        if (state.resizeObserver) state.resizeObserver.disconnect();
        state.resizeObserver = null;
        state.down = null;
        state.up = null;
        state.downWrap = null;
        state.upWrap = null;
        state.configHost = null;
        state.contextMounted = false;
    }

    function applyConfig(config) {
        const cfg = normalize(config);
        state.config = cfg;
        if (!pageAllowed(cfg)) {
            cleanup();
            state.config = cfg;
            return;
        }
        ensureElements(cfg);
        bindListeners();
        scheduleUpdate();
        registerVisualAdapter();
    }

    function previewButton(direction, cfg, size) {
        const btn = document.createElement("span");
        btn.style.display = "inline-flex";
        btn.style.alignItems = "center";
        btn.style.justifyContent = "center";
        btn.style.width = size + "px";
        btn.style.height = size + "px";
        btn.style.background = cfg.appearance.backgroundColor;
        btn.style.color = cfg.appearance.iconColor;
        btn.style.border = cfg.appearance.borderWidthPx + "px solid " + cfg.appearance.borderColor;
        btn.style.borderRadius = cfg.appearance.borderRadiusPercent + "%";
        btn.style.boxShadow = cfg.appearance.shadowEnabled ? cfg.appearance.shadow : "none";
        btn.style.opacity = String(cfg.appearance.opacity);
        btn.style.fontSize = Math.min(cfg.appearance.iconSizePx, size * 0.55) + "px";
        btn.style.lineHeight = "1";
        btn.style.boxSizing = "border-box";
        if (cfg.appearance.iconMode === "fontawesome") {
            const i = document.createElement("i");
            i.className = direction === "down" ? cfg.appearance.downFaClass : cfg.appearance.upFaClass;
            btn.appendChild(i);
        } else {
            btn.textContent = direction === "down" ? cfg.appearance.downSymbol : cfg.appearance.upSymbol;
        }
        return btn;
    }

    function registerVisualAdapter() {
        try {
            const visual = window.PMKConfig && window.PMKConfig.visualEditor;
            if (!visual || typeof visual.register !== "function") return;
            visual.register(MODULE_ID, {
                capabilities: { inlinePreview: true, livePreview: false, styleEyedropper: false },
                renderPreview: function (context) {
                    const cfg = normalize(context && context.rootObject ? context.rootObject : state.config || DEFAULT_CONFIG);
                    const wrap = document.createElement("div");
                    wrap.style.display = "flex";
                    wrap.style.alignItems = "center";
                    wrap.style.gap = "16px";
                    wrap.style.padding = "8px 4px";
                    const size = Math.max(34, Math.min(64, cfg.desktop.sizePx));
                    wrap.appendChild(previewButton("down", cfg, size));
                    wrap.appendChild(previewButton("up", cfg, size));
                    const note = document.createElement("span");
                    note.textContent = language() === "en" ? "Historical default appearance is fully editable." : "Rendu historique par défaut, entièrement personnalisable.";
                    note.style.color = "#6c757d";
                    note.style.fontSize = ".85rem";
                    wrap.appendChild(note);
                    return wrap;
                }
            });
        } catch (_) {}
    }

    function loadConfig() {
        const pmk = window.PMKConfig;
        if (!pmk || typeof pmk.getConfig !== "function") return Promise.resolve(clone(DEFAULT_CONFIG));
        return Promise.resolve(pmk.getConfig(MODULE_ID))
            .then(normalize)
            .catch(function () { return clone(DEFAULT_CONFIG); });
    }

    function runtimeDiagnostic() {
        const cfg = state.config || normalize(DEFAULT_CONFIG);
        const max = getMaxScrollTop();
        const y = getScrollY();
        const r = responsiveConfig(cfg);
        return {
            version: VERSION,
            loaded: true,
            pageAllowed: pageAllowed(cfg),
            enabled: cfg.enabled !== false,
            viewportWidth: window.innerWidth,
            mobileMode: window.innerWidth <= cfg.mobile.breakpointPx,
            showDown: !!r.showDown,
            showUp: !!r.showUp,
            scrollY: y,
            maxScrollTop: max,
            scrollable: max > Math.max(2, cfg.behavior.bottomEpsilonPx),
            dialogVisible: cfg.behavior.hideWhenDialogOpen && dialogIsVisible(),
            blockingDialogs: blockingDialogs().map(function (node) {
                return { tag: node.tagName, id: node.id || "", className: String(node.className || "") };
            }),
            downExists: !!state.down,
            upExists: !!state.up,
            downDisplay: state.down ? window.getComputedStyle(state.down).display : null,
            upDisplay: state.up ? window.getComputedStyle(state.up).display : null
        };
    }

    window.PMK106ScrollButtons = {
        version: VERSION,
        refresh: scheduleUpdate,
        diagnostic: runtimeDiagnostic
    };

    function start() {
        registerVisualAdapter();
        loadConfig().then(applyConfig);
        const pmk = window.PMKConfig;
        if (pmk && typeof pmk.subscribe === "function") {
            try { pmk.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("106-scroll-buttons.js");
} catch (error) { window.PMKNonPlugin.errors.push("106-scroll-buttons.js: "+error.message); console.error("[PMK] 106-scroll-buttons.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.holdsMessage;
if(pmkLegacy.enabled===false || options.enabled===false)return;
/*
 Nom du fichier: 108-view-holdsqueue-alert-message.js
 Dépendances: Aucune
 Date de dernière modification: 2026-06-05
 Auteur: équipe PimpMyKoha
 Description: Affiche un message d'information en haut de la zone de filtres sur view_holdsqueue.pl.
*/

(function(){
  'use strict';

  if (!window.location.pathname.includes('/circ/view_holdsqueue.pl')) return;

  const MESSAGE_ID = 'koha-holdsqueue-alert-message';
  const MESSAGE_TEXT = options.text;

  function injectMessage(){
    if (document.getElementById(MESSAGE_ID)) return true;

    const target = document.querySelector('fieldset.rows');
    if (!target) return false;

    const message = document.createElement('div');
    message.id = MESSAGE_ID;
    message.setAttribute('role', 'status');
    message.style.cssText = [
      'margin:0 0 12px 0',
      'padding:10px 12px',
      'border:1px solid #f0ad4e',
      'border-radius:4px',
      'background:#fff8e1',
      'color:#7a4b00',
      'font-weight:600'
    ].join(';');
    message.textContent = MESSAGE_TEXT;

    target.insertBefore(message, target.firstChild);
    return true;
  }

  if (!injectMessage()) {
    const observer = new MutationObserver(function(){
      if (injectMessage()) observer.disconnect();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function(){ observer.disconnect(); }, 5000);
  }
})();
})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("108-view-holdsqueue-alert-message.js");
} catch (error) { window.PMKNonPlugin.errors.push("108-view-holdsqueue-alert-message.js: "+error.message); console.error("[PMK] 108-view-holdsqueue-alert-message.js",error); };
try {
(function () {

  const firebaseConfig = {}; // Anciennes options conservées uniquement dans les sauvegardes.

  const PANEL_ID = "koha099_picker_panel";
  const CACHE_KEY = "koha099_picker_v3_last";
  const PRESETS_KEY = "koha099_picker_v3_presets";
  const PANEL_STATE_KEY = "koha099_picker_v3_panel_state";
  const SELECTED_LIST_KEY = "koha099_picker_v3_selected_list";
  const FIREBASE_PRESETS_COLLECTION = "koha099_named_presets";
  const MAX_PRESETS = 20;
  const MODULE_ID = "cataloguing-tree-assistant";
  const GENERIC_PRESETS_COLLECTION = "pmk_cataloguing_tree_presets";
  const GENERIC_CACHE_KEY = "pmk_cataloguing_tree_last";
  const GENERIC_PANEL_STATE_KEY = "pmk_cataloguing_tree_panel_state";

  // Listes 6XX historiques : copie de secours strictement identique au moteur 081-084.
  // La source prioritaire reste window.PMK6XXConfig / les <select> réellement générés par le module 6XX.
  const PMK6XX_HISTORICAL_FALLBACK_109 = {
          genre: "Abécédaires\nAction & Aventure\nAlbums pour les plus grands\nApprentissage\nAventure\nBandes originales de films\nBiographies romancées\nBlack Music\nClassiques\nComics\nComptine, chanson\nDark romance\nDocu-fictions, biographies, histoires vécues\nDystopie\nElectro\nÉrotique\nEspionnage\nFantastique/Fantasy\nFeel good\nFilm Famille\nFilm d'animation\nFilm-Vintage\nFilms - Grands classiques\nFilms-Aventure\nFilms-Action\nFilms-Courts métrages\nFilms-Drames\nFilms-Japanimation\nFilms-Regards de femmes\nFilms-Science-fiction\nFilms-Se détendre\nFilms-Western\nFilms d'horreur\nFilms historiques\nFilms muets\nFilms musicaux\nFilms noirs\nFrissons\nHistorique\nHorreur\nHumour\nImagiers\nInitiatique\nJazz\nLégendes, mythes, fables\nLivre à toucher\nLivre sonore\nLivre animé\nLivres à compter\nLivre-jeu\nMondes Imaginaires\nMystères et enquêtes\nMusique Classique\nMusique Francophone\nMusique actuelle\nMusique du monde\nNature\nNovélisation de films/séries\nNovélisation de jeux vidéo\nNouvelles\nPolicier\nPsychologique\nRéaliste\nRécits de vie\nRimes\nRomance\nScience-fiction\nSentimental\nSerie|serie\nSéries courtes\nTerroir\nThriller",
          indexation: "Adaptation litteraire|Adaptation littéraire\nAlbum sans texte\nAntivol\nBandes originales\nBD Documentaire\nBD One Shot\nBD petit format|BD Petit format\nBD sans texte\nBiographie\nBlack Music\nComics\nCorner nature\nDVD Musicaux\nDVD Théâtre\nDyslexique\nElectro\nFilm d'animation\nFilm Famille\nFilm-Drame\nFilm-Vintage\nFilms - Grands classiques\nFilms-Aventure\nFilms-Action\nFilms-Courts métrages\nFilms-Grands classiques\nFilms-Japanimation\nFilms-Regards de femmes\nFilms-Science-fiction\nFilms-Se détendre\nFilms-Western\nFilms d'horreur\nFilms historiques\nFilms muets\nFilms musicaux\nFilms noirs\nFacile a lire\nHumour\nImages de dragons\nInstruments de musique\nJazz\nJeu illustrateur\nJeux de société\nLangues etrangeres|Langues étrangères\nlitteratures|Littératures\nMangas\nMusique à Lire\nMusique actuelle\nMusique Classique\nMusique du monde\nMusique Francophone\nParents et compagnie\nPoesie et theatre|Poésie et théâtre\nPremière lecture\nPremieres cases|Premières cases\nRomans Ados\nScène locale\nserie|Série\nSéries courtes\nTextes illustrés\nvintage|Film - Vintage",
          element: "Sorcières\nLe loup\nMonstres\nSirènes\nPrinces, chevaliers et princesses\nPirates\nIndiens, Cow-boys\nSuperhéros\nMulticulturalisme et diversité",
          subject: "Acquisition de la Propreté\nAffirmation de soi et opposition\nAngoisse de séparation\nAlimentation\nAmitié\nAnimaux\nAnimaux familiers\nAnimaux sauvages\nArts et spectacles\nBain, hygiène\nBobos\nBonnes Manières\nCampagne, vie rurale, ferme\nCaractères (courageux, curiosité, rêveur, leader...)\nChâteaux forts\nCivilisations (Maya, Viking, esquimau...)\nColère\nComportements sociaux (antisémitisme, différence, entraide, relation fille-garçons..)\nConditions de vie (pauvreté, précarité, immigration et réfugiés..)\nCorps humain (cinq sens, image du corps..)\nCrèche\nDéménagement\nDinosaures\nDoudou / Tétine\nÉcologie, environnement\nÉmotions et Sentiments\nEngins et moyens de Transport\nFêtes (Noël, Pâques...)\nHistoire (grandes époques, guerres et conflits, personnages célèbres)\nIntimidation / Harcèlement\nLangage, jeux de langage, jeux de mots, contraire\nLe corps et ses différences (handicaps, neurodiversité, lunettes..)\nLe rituel du coucher\nLes conflits\nLivre et bibliothèque\nMaison, habitation, jardin et jardinage\nMaternité, naissance\nMers, marins\nMétéorologie et saisons\nMort, deuil\nNature\nNouveau bébé\nOrphelins et foyers d'accueil\nPays et continents\nPeur du noir\nPolitesse, bienséance\nPremiers apprentissages (couleurs, formes, etc)\nPréhistoire\nQuestions de genres\nRelation aux autres\nRelations dans la famille (Fratrie, Parents, Grands-parents, Familles atypiques..)\nReligions, croyances\nRentrée scolaire\nSanté et maladies\nScolarité\nSciences et techniques (espace, inventions...)\nSéparation Divorce\nSons, bruits et cris\nSport\nTerritoires (Amazonie, jungle, montagne, désert, banquise, île, forêt...)\nTransgression des interdits : inceste, maltraitance, violence, violence sexuelle, vol..\n Intimidation / Harcèlement\nTravail et métiers\nVacances\nVille (bâtiment et construction, zoo, jardin public, marché, musée..etc)\nVie quotidienne familiale (bêtises, respect des règles, éducation, fugue..)"
  };

  const DEFAULT_RUNTIME_CONFIG = {
    enabled: true,
    runtimeMode: "legacy_default",
    page: {
      path: "/cgi-bin/koha/cataloguing/addbiblio.pl",
      enabled: true
    },
    features: {
      assistant: true,
      nativeFiltering: false, legacyFiltering: true,
      preserveInvalidExistingValues: true,
      rememberSelection: true,
      rememberPanelState: true,
      showBreadcrumb: true
    },
    lists: {
      enabled: true,
      mode: "common",
      maxPresets: 20
    },
    hierarchy: {
      relationshipMode: "firebase_legacy",
      strictFiltering: true
    },
    levels: [
      {
        id: "domain",
        enabled: true,
        labelFr: "Domaine",
        labelEn: "Domain",
        tag: "099",
        subfield: "a",
        sourceType: "firebase_legacy",
        firebaseCode: "a",
        authorisedValueCategory: "",
        manualValues: ""
      },
      {
        id: "subdomain",
        enabled: true,
        labelFr: "Sous-domaine",
        labelEn: "Subdomain",
        tag: "099",
        subfield: "b",
        sourceType: "firebase_legacy",
        firebaseCode: "b",
        authorisedValueCategory: "",
        manualValues: ""
      },
      {
        id: "theme",
        enabled: true,
        labelFr: "Thème",
        labelEn: "Theme",
        tag: "099",
        subfield: "e",
        sourceType: "firebase_legacy",
        firebaseCode: "e",
        authorisedValueCategory: "",
        manualValues: ""
      },
      {
        id: "subject099",
        enabled: true,
        labelFr: "Sujet",
        labelEn: "Subject",
        tag: "099",
        subfield: "f",
        sourceType: "firebase_legacy",
        firebaseCode: "f",
        authorisedValueCategory: "",
        manualValues: ""
      }
    ],
    extraFields: [
      {
        id: "genre608",
        enabled: true,
        labelFr: "Genre littéraire",
        labelEn: "Literary genre",
        tag: "608",
        subfield: "a",
        sourceType: "pmk6xx",
        firebaseCode: "g",
        authorisedValueCategory: "",
        manualValues: "",
        filterByHierarchy: false
      },
      {
        id: "subject615",
        enabled: true,
        labelFr: "Sujet",
        labelEn: "Subject",
        tag: "615",
        subfield: "a",
        sourceType: "pmk6xx",
        firebaseCode: "s",
        authorisedValueCategory: "",
        manualValues: "",
        filterByHierarchy: false
      },
      {
        id: "character623",
        enabled: true,
        labelFr: "Personnage",
        labelEn: "Character",
        tag: "623",
        subfield: "a",
        sourceType: "pmk6xx",
        firebaseCode: "p",
        authorisedValueCategory: "",
        manualValues: "",
        filterByHierarchy: false
      }
    ],
    relationships: [],
    appearance: {
      widthPx: 360,
      mobileBreakpointPx: 576
    },
    language: "auto"
  };

  let runtimeConfig = null;
  // Une mémorisation peut porter un nom libre (champ `name`, 80 caractères max).
  // Les anciennes mémorisations sans nom restent compatibles et affichent leur chaîne de valeurs.

  let firebaseDb = null;
  let collection = null;
  let doc = null;
  let getDocs = null;
  let getDoc = null;
  let setDoc = null;
  let deleteDoc = null;
  let serverTimestamp = null;
  let runTransaction = null;

  const waitForBody = () => new Promise(resolve => {
    if (document.body) return resolve();

    const t = setInterval(() => {
      if (document.body) {
        clearInterval(t);
        resolve();
      }
    }, 100);
  });

  const norm = s => (s || "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  const escapeHTML = value => (value ?? "")
    .toString()
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

  const escapeAttr = escapeHTML;

  const getJSON = (key, fallback) => {
    try {
      const v = JSON.parse(localStorage.getItem(key) || "null");
      return v === null ? fallback : v;
    } catch (e) {
      return fallback;
    }
  };

  const setJSON = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {}
  };

  const ensureStyle = () => {
    if (document.getElementById("koha099_picker_style")) return;

    const s = document.createElement("style");
    s.id = "koha099_picker_style";

    s.textContent = `
#${PANEL_ID}{
  position:fixed;top:70px;right:20px;z-index:999999;
  background:#ffffff;border:1px solid #dfe6df;border-radius:14px;
  box-shadow:0 14px 42px rgba(24,39,27,.16),0 3px 10px rgba(20,20,40,.07);
  width:360px;font:12.5px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  color:#1f2430;overflow:hidden;user-select:none;
}

#${PANEL_ID} *{
  box-sizing:border-box;
  user-select:text;
}

#${PANEL_ID}.collapsed .body{
  display:none;
}

#${PANEL_ID} .head{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:8px;
  padding:11px 12px;
  cursor:move;
  font-weight:700;
  font-size:13px;
  background:linear-gradient(135deg,#3f8340 0%,#438d43 100%);
  color:#fff;
  letter-spacing:.2px;
  border-bottom:1px solid rgba(0,0,0,.08);
}

#${PANEL_ID} .head .title{
  display:flex;
  align-items:center;
  font-size:13.5px;
}

#${PANEL_ID} .head .subtitle{
  display:inline-block;
  font-size:10.5px;
  font-weight:500;
  color:rgba(255,255,255,.94);
  margin-top:3px;
  letter-spacing:0;
  background:rgba(255,255,255,.12);
  padding:1px 6px;
  border-radius:999px;
}

#${PANEL_ID} .head .subtitle:empty{
  display:none;
}

#${PANEL_ID} .head-btns{
  display:flex;
  gap:4px;
}

#${PANEL_ID} .head-btns button{
  background:rgba(255,255,255,.16);
  border:1px solid rgba(255,255,255,.08);
  color:#fff;
  width:24px;
  height:24px;
  border-radius:7px;
  cursor:pointer;
  font-size:13px;
  line-height:1;
  display:flex;
  align-items:center;
  justify-content:center;
  transition:background .15s,border-color .15s;
}

#${PANEL_ID} .head-btns button:hover{
  background:rgba(255,255,255,.30);
  border-color:rgba(255,255,255,.18);
}

#${PANEL_ID} .body{
  padding:12px;
  max-height:78vh;
  overflow-y:auto;
  overflow-x:hidden;
  background:#fff;
}

#${PANEL_ID} .row{
  margin:0 0 8px;
  min-width:0;
}

#${PANEL_ID} .row label{
  display:block;
  font-weight:700;
  margin-bottom:3px;
  color:#566258;
  font-size:10.5px;
  text-transform:uppercase;
  letter-spacing:.45px;
}

#${PANEL_ID} .combo-wrap{
  position:relative;
  min-width:0;
}

#${PANEL_ID} .combo-input{
  width:100%;
  min-width:0;
  max-width:100%;
  padding:7px 28px 7px 9px;
  border:1px solid #dce4dc;
  border-radius:8px;
  font:inherit;
  color:#253027;
  background:#f8faf8;
  transition:border-color .15s,background .15s,box-shadow .15s;
}

#${PANEL_ID} .combo-input:hover:not(:disabled){
  border-color:#cbd8cc;
}

#${PANEL_ID} .combo-input:focus{
  outline:none;
  border-color:#79a97b;
  background:#fff;
  box-shadow:0 0 0 2px rgba(64,133,64,.10);
}

#${PANEL_ID} .combo-input:disabled{
  background:#f0f2f0;
  border-color:#e3e7e3;
  color:#9aa29b;
  cursor:not-allowed;
}

#${PANEL_ID} .combo-input.non-authorized{
  border-color:#d59a1f!important;
  background:#fff8ea!important;
  color:#8a4b00!important;
  box-shadow:0 0 0 2px rgba(213,154,31,.08)!important;
}

#${PANEL_ID} .combo-clear{
  position:absolute;
  right:6px;
  top:50%;
  transform:translateY(-50%);
  border:none;
  background:transparent;
  color:#a8b0a9;
  cursor:pointer;
  font-size:14px;
  width:20px;
  height:20px;
  border-radius:6px;
  display:flex;
  align-items:center;
  justify-content:center;
  opacity:.62;
  transition:opacity .15s,background .15s,color .15s;
}

#${PANEL_ID} .combo-wrap:hover .combo-clear,
#${PANEL_ID} .combo-clear:focus{
  opacity:1;
}

#${PANEL_ID} .combo-clear:hover{
  background:#e9eeea;
  color:#4f5a51;
}

#${PANEL_ID} .combo-menu{
  position:absolute;
  left:0;
  right:0;
  top:calc(100% + 4px);
  background:#fff;
  border:1px solid #dfe6df;
  border-radius:9px;
  box-shadow:0 9px 24px rgba(24,39,27,.14);
  max-height:180px;
  overflow-y:auto;
  overflow-x:hidden;
  z-index:10;
  display:none;
}

#${PANEL_ID} .combo-item{
  padding:6px 10px;
  cursor:pointer;
  font-size:12px;
  display:flex;
  flex-direction:column;
  gap:2px;
  border-bottom:1px solid #f1f3f1;
}

#${PANEL_ID} .combo-item:last-child{
  border-bottom:none;
}

#${PANEL_ID} .combo-item:hover,
#${PANEL_ID} .combo-item.active{
  background:#edf6ee;
  color:#347336;
}

#${PANEL_ID} .combo-item-label{
  font-size:12px;
  color:#253027;
  font-weight:600;
}

#${PANEL_ID} .combo-item-context{
  font-size:10px;
  color:#788079;
}

#${PANEL_ID} .combo-item-note{
  font-size:10px;
  color:#a66500;
  font-style:italic;
  margin-top:2px;
}

#${PANEL_ID} .combo-empty{
  padding:7px 10px;
  color:#929a93;
  font-style:italic;
  font-size:11px;
}

#${PANEL_ID} .actions{
  display:flex;
  gap:6px;
  margin-top:9px;
  padding-top:9px;
  border-top:1px solid #e8ece8;
}

#${PANEL_ID} .actions button{
  flex:1 1 0;
  min-width:0;
  min-height:36px;
  padding:6px 7px;
  cursor:pointer;
  font:inherit;
  font-weight:700;
  font-size:11.5px;
  line-height:1.15;
  text-align:center;
  border-radius:8px;
  border:1px solid transparent;
  display:flex;
  align-items:center;
  justify-content:center;
  white-space:normal;
  transition:filter .15s,background .15s,border-color .15s,box-shadow .15s,transform .08s;
}

#${PANEL_ID} .actions button:active{
  transform:translateY(1px);
}

#${PANEL_ID} .btn-primary{
  background:#408540;
  color:#fff;
  border-color:#397a39;
  box-shadow:0 2px 5px rgba(64,133,64,.18);
}

#${PANEL_ID} .btn-primary:hover{
  filter:brightness(1.06);
  box-shadow:0 3px 7px rgba(64,133,64,.22);
}

#${PANEL_ID} .btn-secondary{
  background:#eef7ef;
  color:#347336;
  border-color:#d8ead9;
}

#${PANEL_ID} .btn-secondary:hover{
  background:#e4f2e5;
  border-color:#c8e1ca;
}

#${PANEL_ID} .btn-ghost{
  background:#f5f6f5;
  color:#646d66;
  border-color:#e8ebe8;
}

#${PANEL_ID} .btn-ghost:hover{
  background:#ecefec;
  border-color:#dce1dc;
}

#${PANEL_ID} .status{
  font-size:10.5px;
  color:#536056;
  margin-top:7px;
  white-space:pre-wrap;
  line-height:1.45;
  background:#f7f9f7;
  border-radius:8px;
  padding:7px 9px;
  border:1px solid #e5eae5;
  border-left:3px solid #a9baa9;
  max-height:100px;
  overflow-y:auto;
  overflow-x:hidden;
}

#${PANEL_ID} .status:empty{
  display:none;
}

#${PANEL_ID} .divider{
  border:none;
  border-top:1px solid #e3e8e3;
  margin:10px 0 8px;
}

#${PANEL_ID} .presets-title{
  font-weight:800;
  font-size:10.5px;
  text-transform:uppercase;
  letter-spacing:.55px;
  color:#566258;
  margin-bottom:5px;
  display:flex;
  justify-content:space-between;
  align-items:center;
}

#${PANEL_ID} .presets-count{
  color:#7d887f;
  font-weight:700;
  text-transform:none;
  letter-spacing:0;
  background:#eef2ee;
  border:1px solid #e2e7e2;
  border-radius:999px;
  padding:1px 6px;
}

#${PANEL_ID} .presets-actions{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:6px;
  margin-bottom:6px;
}

#${PANEL_ID} .presets-actions .note-presets{
  font-size:10px;
  color:#7a837c;
  flex:1;
  line-height:1.35;
}

#${PANEL_ID} .btn-small{
  padding:4px 8px;
  font-size:10.5px;
  border-radius:7px;
}

#${PANEL_ID} .preset-controls{
  padding:7px 7px 1px;
  margin-bottom:6px;
  display:none;
  background:#f7f9f7;
  border:1px solid #e8ece8;
  border-radius:8px;
}

#${PANEL_ID} .preset-controls.open{
  display:block;
}

#${PANEL_ID} .preset-controls .row{
  margin:0 0 7px;
  min-width:0;
}

#${PANEL_ID} .preset-controls .row > div{
  min-width:0;
  max-width:100%;
}

#${PANEL_ID} .preset-list{
  display:flex;
  flex-direction:column;
  gap:5px;
  max-height:132px;
  overflow-y:auto;
  overflow-x:hidden;
  padding-right:2px;
}

#${PANEL_ID} .preset-item{
  display:flex;
  align-items:center;
  gap:6px;
  min-width:0;
  background:#fff;
  border:1px solid #e3e8e3;
  border-radius:8px;
  padding:6px 7px;
  cursor:pointer;
  transition:background .15s,border-color .15s,box-shadow .15s;
}

#${PANEL_ID} .preset-item:hover{
  background:#f7fcf7;
  border-color:#bed8c0;
  box-shadow:0 1px 3px rgba(64,133,64,.07);
}

#${PANEL_ID} .preset-text{
  flex:1;
  min-width:0;
  font-size:10.5px;
  color:#667067;
  line-height:1.35;
  overflow-wrap:anywhere;
}

#${PANEL_ID} .preset-text b{
  color:#397c3b;
  font-weight:800;
}

#${PANEL_ID} .preset-name{
  display:block;
  margin-bottom:2px;
  color:#2f7132;
  font-size:11px;
  font-weight:800;
  line-height:1.3;
  overflow-wrap:anywhere;
}

#${PANEL_ID} .preset-chain{
  display:block;
  color:#667067;
  font-size:10.5px;
  line-height:1.35;
  overflow-wrap:anywhere;
}

#${PANEL_ID} .preset-rename,
#${PANEL_ID} .preset-del{
  border:none;
  background:transparent;
  color:#b0b8b1;
  cursor:pointer;
  font-size:13px;
  width:20px;
  height:20px;
  border-radius:6px;
  flex-shrink:0;
  display:flex;
  align-items:center;
  justify-content:center;
}

#${PANEL_ID} .preset-rename:hover{
  background:#edf6ee;
  color:#347336;
}

#${PANEL_ID} .preset-del:hover{
  background:#ffe8e8;
  color:#d9473f;
}

#${PANEL_ID} .preset-empty{
  color:#919991;
  font-style:italic;
  font-size:10.5px;
  padding:5px 2px;
}
`;

    document.head.appendChild(s);
  };

  const parseLevel = name => {
    const s = norm(name);

    if (/domaine\s*0?99\$?a/.test(s)) return "a";
    if (/sous[- ]domaine\s*0?99\$?b/.test(s)) return "b";
    if (/th[eè]me\s*0?99\$?e/.test(s)) return "e";
    if (/sujet\s*0?99\$?f/.test(s)) return "f";

    if (
      /(?:forme\s*\/\s*genre|genre(?:\s+litt[eè]raire)?)(?:\s*608\$?a)?/.test(s)
    ) {
      return "g";
    }

    if (/sujet\s*615\$?a/.test(s)) return "s";

    if (/(?:personnage|character)s?\s*623\$?a/.test(s)) return "p";

    return "";
  };

  const cleanLabel = s => {
    const txt = (s || "").trim();

    if (!txt) return "";

    const m = txt.match(
      /^(.*?)\s*\((?:Sous[- ]?domaine|Domaine|Th[eè]me(?:s)?|Sujet|Forme\s*\/\s*Genre|Genre(?:\s+litt[eè]raire)?|Personnage(?:s)?|Character(?:s)?)[^)]*\)/i
    );

    if (m) return m[1].trim();

    return txt
      .replace(/\s*\(\d+\)\s*$/, "")
      .trim();
  };

  const extractPathKey = node => {
    const p = (node.parentPath || node.path || node.parent || "").trim();
    return norm(p);
  };

  // Reproduit la logique d'attachement de buildTree() :
  // un noeud supprimé, ou un noeud dont la chaîne de parents n'est plus
  // rattachée à la racine, ne doit pas être utilisé par les listes 099.
  const getTreeParentPath = node => {
    if (!node) return "";

    if (typeof node.parentPath === "string") {
      return node.parentPath.trim();
    }

    if (typeof node.parent === "string") {
      return node.parent.trim();
    }

    return "";
  };

  const getTreeNodeName = node =>
    (node?.name || node?.label || "")
      .toString()
      .trim();

  const getTreeFullPath = node => {
    const name = getTreeNodeName(node);
    const parentPath = getTreeParentPath(node);

    return parentPath
      ? `${parentPath}/${name}`
      : name;
  };

  const buildActiveTreeContext = rows => {
    // 1. Exclure les documents explicitement supprimés.
    const activeRows = (rows || []).filter(row => !row.deleted);

    // 2. Reconstituer le même index de chemins que buildTree().
    const byPath = new Map();

    activeRows.forEach(row => {
      const fullPath = getTreeFullPath(row);

      if (fullPath) {
        byPath.set(fullPath, row);
      }
    });

    // 3. Ne conserver que les noeuds réellement atteignables depuis la racine.
    // Cela élimine aussi les descendants/orphelins d'un ancien noeud supprimé.
    const reachablePaths = new Set();

    activeRows.forEach(row => {
      if (getTreeParentPath(row) === "") {
        const fullPath = getTreeFullPath(row);

        if (fullPath) {
          reachablePaths.add(fullPath);
        }
      }
    });

    let changed = true;
    let guard = 0;

    while (changed && guard++ < activeRows.length + 2) {
      changed = false;

      activeRows.forEach(row => {
        const fullPath = getTreeFullPath(row);

        if (!fullPath || reachablePaths.has(fullPath)) {
          return;
        }

        const parentPath = getTreeParentPath(row);

        if (
          parentPath &&
          reachablePaths.has(parentPath) &&
          byPath.has(parentPath)
        ) {
          reachablePaths.add(fullPath);
          changed = true;
        }
      });
    }

    const reachableRows = activeRows.filter(row =>
      reachablePaths.has(getTreeFullPath(row))
    );

    return {
      allRows: rows || [],
      rows: reachableRows,
      byPath,
      reachablePaths,
      excludedDeleted: (rows || []).length - activeRows.length,
      excludedOrphans: activeRows.length - reachableRows.length
    };
  };

  const findAncestorByLevel = (node, wantedLevel, treeCtx) => {
    let parentPath = getTreeParentPath(node);
    let guard = 0;

    while (parentPath && guard++ < 100) {
      if (!treeCtx.reachablePaths.has(parentPath)) {
        return null;
      }

      const parent = treeCtx.byPath.get(parentPath);

      if (!parent) {
        return null;
      }

      if (parseLevel(getTreeNodeName(parent)) === wantedLevel) {
        return parent;
      }

      parentPath = getTreeParentPath(parent);
    }

    return null;
  };

  const getAncestorLabelKeys = (node, treeCtx) => {
    const keys = [];

    let parentPath = getTreeParentPath(node);
    let guard = 0;

    while (parentPath && guard++ < 100) {
      if (!treeCtx.reachablePaths.has(parentPath)) {
        break;
      }

      const parent = treeCtx.byPath.get(parentPath);

      if (!parent) {
        break;
      }

      const label = cleanLabel(getTreeNodeName(parent));

      if (label) {
        keys.push(norm(label));
      }

      parentPath = getTreeParentPath(parent);
    }

    return keys;
  };

  const buildIndex = rows => {
    const treeCtx = buildActiveTreeContext(rows);

    rows = treeCtx.rows;

    const idx = {
      a: [],
      bByA: new Map(),
      eByAB: new Map(),
      fByABE: new Map(),
      g: [],
      s: [],
      p: []
    };

    // ============================================================
    // Domaine 099$a
    // ============================================================

    for (const r of rows) {
      const level = parseLevel(getTreeNodeName(r));

      if (level !== "a") continue;

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      idx.a.push({
        label,
        raw: r,
        key: norm(label),
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    idx.a = [
      ...new Map(
        idx.a.map(x => [x.key, x])
      ).values()
    ].sort((x, y) =>
      x.label.localeCompare(y.label, "fr")
    );

    // ============================================================
    // Sous-domaine 099$b
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "b") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);

      if (!aRow) continue;

      const aKey = norm(
        cleanLabel(
          getTreeNodeName(aRow)
        )
      );

      const a = idx.a.find(x =>
        x.key === aKey
      );

      if (!a) continue;

      if (!idx.bByA.has(a.key)) {
        idx.bByA.set(a.key, []);
      }

      idx.bByA.get(a.key).push({
        label,
        raw: r,
        key: norm(label),
        aKey: a.key,
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    for (const [k, arr] of idx.bByA) {
      idx.bByA.set(
        k,
        [
          ...new Map(
            arr.map(x => [x.key, x])
          ).values()
        ].sort((x, y) =>
          x.label.localeCompare(y.label, "fr")
        )
      );
    }

    // ============================================================
    // Thème 099$e
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "e") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);
      const bRow = findAncestorByLevel(r, "b", treeCtx);

      if (!aRow || !bRow) continue;

      const aKey = norm(
        cleanLabel(
          getTreeNodeName(aRow)
        )
      );

      const bKey = norm(
        cleanLabel(
          getTreeNodeName(bRow)
        )
      );

      const a = idx.a.find(x =>
        x.key === aKey
      );

      if (!a) continue;

      const b = (idx.bByA.get(a.key) || [])
        .find(x =>
          x.key === bKey
        );

      if (!b) continue;

      const abKey =
        `${a.key}|||${b.key}`;

      if (!idx.eByAB.has(abKey)) {
        idx.eByAB.set(abKey, []);
      }

      idx.eByAB.get(abKey).push({
        label,
        raw: r,
        key: norm(label),
        aKey: a.key,
        bKey: b.key,
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    for (const [k, arr] of idx.eByAB) {
      idx.eByAB.set(
        k,
        [
          ...new Map(
            arr.map(x => [x.key, x])
          ).values()
        ].sort((x, y) =>
          x.label.localeCompare(y.label, "fr")
        )
      );
    }

    // ============================================================
    // Sujet 099$f
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "f") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);
      const bRow = findAncestorByLevel(r, "b", treeCtx);
      const eRow = findAncestorByLevel(r, "e", treeCtx);

      if (!aRow || !bRow || !eRow) {
        continue;
      }

      const aKey = norm(
        cleanLabel(
          getTreeNodeName(aRow)
        )
      );

      const bKey = norm(
        cleanLabel(
          getTreeNodeName(bRow)
        )
      );

      const eKey = norm(
        cleanLabel(
          getTreeNodeName(eRow)
        )
      );

      const a = idx.a.find(x =>
        x.key === aKey
      );

      if (!a) continue;

      const b = (idx.bByA.get(a.key) || [])
        .find(x =>
          x.key === bKey
        );

      if (!b) continue;

      const e = (
        idx.eByAB.get(
          `${a.key}|||${b.key}`
        ) || []
      ).find(x =>
        x.key === eKey
      );

      if (!e) continue;

      const abeKey =
        `${a.key}|||${b.key}|||${e.key}`;

      if (!idx.fByABE.has(abeKey)) {
        idx.fByABE.set(abeKey, []);
      }

      idx.fByABE.get(abeKey).push({
        label,
        raw: r,
        key: norm(label),
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    for (const [k, arr] of idx.fByABE) {
      idx.fByABE.set(
        k,
        [
          ...new Map(
            arr.map(x => [x.key, x])
          ).values()
        ].sort((x, y) =>
          x.label.localeCompare(y.label, "fr")
        )
      );
    }

    // ============================================================
    // Genre 608$a
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "g") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      idx.g.push({
        label,
        raw: r,
        key: norm(label),
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    idx.g = [
      ...new Map(
        idx.g.map(x => [
          `${x.key}|||${(x.ancestorKeys || []).join("|||")}`,
          x
        ])
      ).values()
    ].sort((x, y) =>
      x.label.localeCompare(y.label, "fr")
    );

    // ============================================================
    // Sujet 615$a
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "s") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      idx.s.push({
        label,
        raw: r,
        key: norm(label),
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    idx.s = [
      ...new Map(
        idx.s.map(x => [
          `${x.key}|||${(x.ancestorKeys || []).join("|||")}`,
          x
        ])
      ).values()
    ].sort((x, y) =>
      x.label.localeCompare(y.label, "fr")
    );

    // ============================================================
    // Personnage 623$a
    // ============================================================

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "p") {
        continue;
      }

      const label = cleanLabel(getTreeNodeName(r));

      if (!label) continue;

      idx.p.push({
        label,
        raw: r,
        key: norm(label),
        ancestorKeys: getAncestorLabelKeys(r, treeCtx)
      });
    }

    idx.p = [
      ...new Map(
        idx.p.map(x => [
          `${x.key}|||${(x.ancestorKeys || []).join("|||")}`,
          x
        ])
      ).values()
    ].sort((x, y) =>
      x.label.localeCompare(y.label, "fr")
    );

    // ============================================================
    // Diagnostic interne
    // ============================================================

    window.Koha099TreeDebug = {
      totalRows:
        treeCtx.excludedDeleted +
        treeCtx.excludedOrphans +
        rows.length,

      activeReachableRows: rows.length,

      excludedDeleted:
        treeCtx.excludedDeleted,

      excludedOrphans:
        treeCtx.excludedOrphans,

      find(text) {
        const needle = norm(text || "");

        return treeCtx.allRows
          .filter(r => {
            const hay =
              `${getTreeNodeName(r)} ${getTreeParentPath(r)}`;

            return norm(hay).includes(needle);
          })
          .map(r => ({
            id: r.id,
            name: getTreeNodeName(r),
            parentPath: getTreeParentPath(r),
            deleted: r.deleted,
            reachable:
              treeCtx.reachablePaths.has(
                getTreeFullPath(r)
              ),
            level:
              parseLevel(
                getTreeNodeName(r)
              )
          }));
      }
    };

    return idx;
  };

  // ============================================================
  // Recherche des champs Koha
  // ============================================================

  const findTagScopes = () =>
    [
      ...document.querySelectorAll(
        'li.tag.clearfix[id^="tag_099_"]'
      )
    ];

  const findFieldInScope = (scope, code) =>
    scope.querySelector(
      `select[name^="tag_099_subfield_${code}_"]`
    ) ||
    scope.querySelector(
      `input[name^="tag_099_subfield_${code}_"]`
    );

  const findFFieldInScope = scope => {
    const all = [
      ...scope.querySelectorAll(
        'select[name^="tag_099_subfield_f_"]'
      )
    ];

    if (!all.length) {
      return null;
    }

    return all.find(s => !s.value) || all[0];
  };

  const findFieldByLabel = labelText => {
    const normalized = norm(labelText);

    const label = Array
      .from(
        document.querySelectorAll(
          "label.labelsubfield"
        )
      )
      .find(el =>
        norm(el.textContent || "") === normalized
      );

    if (!label) {
      return null;
    }

    return (
      document.getElementById(
        label.getAttribute("for")
      ) || null
    );
  };

  const findGenreField = () =>
    findFieldByLabel(
      "Genre littéraire"
    );

  const findSubject615Field = () =>
    findFieldByLabel(
      "catégorie sujet"
    );

  const findCharacter623Field = () => {
    const direct =
      document.querySelector(
        '[name^="tag_623_subfield_a_"]'
      ) ||
      document.querySelector(
        '[id^="tag_623_subfield_a_"]'
      );

    if (direct) {
      return direct;
    }

    return (
      findFieldByLabel("Personnage") ||
      findFieldByLabel("Personnage (623$a)") ||
      findFieldByLabel("Character")
    );
  };

  // ============================================================
  // Correspondance avec les valeurs autorisées Koha
  // ============================================================

  const findOptionByLabel = (select, label) => {
    if (!select || !label || !select.options) {
      return null;
    }

    const target = norm(label);

    return [...select.options].find(option =>
      norm(option.textContent) === target ||
      norm(option.value) === target
    ) || null;
  };

  const triggerNativeAndJQuery = element => {
    if (!element) return;

    element.dispatchEvent(
      new Event(
        "input",
        { bubbles: true }
      )
    );

    element.dispatchEvent(
      new Event(
        "change",
        { bubbles: true }
      )
    );

    if (window.jQuery) {
      try {
        window.jQuery(element)
          .trigger("change");
      } catch (e) {}
    }
  };

  const setFieldByLabel = (field, label) => {
    if (!field) {
      return {
        ok: false,
        reason: "champ introuvable"
      };
    }

    if (field.tagName === "SELECT") {
      const opt =
        findOptionByLabel(
          field,
          label
        );

      if (!opt) {
        return {
          ok: false,
          reason:
            `aucune option ne correspond à "${label}"`
        };
      }

      field.value = opt.value;

      triggerNativeAndJQuery(field);

      return {
        ok: true,
        matched:
          opt.textContent.trim()
      };
    }

    if (
      field.tagName === "INPUT" ||
      field.tagName === "TEXTAREA"
    ) {
      field.value = label;

      triggerNativeAndJQuery(field);

      return {
        ok: true,
        matched: label
      };
    }

    return {
      ok: false,
      reason: "type de champ non supporté"
    };
  };

  const clearField = field => {
    if (!field) {
      return {
        ok: false,
        reason: "champ introuvable"
      };
    }

    if (field.tagName === "SELECT") {
      const emptyOpt = [...field.options].find(option =>
        option.value === ""
      );

      if (!emptyOpt) {
        return {
          ok: false,
          reason: "ce champ ne possède pas de valeur vide"
        };
      }

      field.value = "";
      triggerNativeAndJQuery(field);

      return { ok: true };
    }

    if (
      field.tagName === "INPUT" ||
      field.tagName === "TEXTAREA"
    ) {
      field.value = "";
      triggerNativeAndJQuery(field);

      return { ok: true };
    }

    return {
      ok: false,
      reason: "type de champ non supporté"
    };
  };

  // ============================================================
  // Combobox du panneau
  // ============================================================

  const makeCombo = (row, placeholder) => {
    row.innerHTML = `
      <div class="combo-wrap">
        <input
          type="text"
          class="combo-input"
          placeholder="${placeholder}"
          autocomplete="off"
        >
        <button
          type="button"
          class="combo-clear"
          tabindex="-1"
          title="Effacer"
        >×</button>
        <div class="combo-menu"></div>
      </div>
    `;

    const input =
      row.querySelector(".combo-input");

    const menu =
      row.querySelector(".combo-menu");

    const clearBtn =
      row.querySelector(".combo-clear");

    let items = [];
    let value = "";
    let onChangeCb = () => {};

    const renderMenu = filterText => {
      const f =
        norm(filterText || "");

      const filtered =
        f
          ? items.filter(it =>
              norm(it.label).includes(f)
            )
          : items;

      if (!items.length) {
        menu.innerHTML =
          `<div class="combo-empty">Aucune option disponible</div>`;
      } else if (!filtered.length) {
        menu.innerHTML =
          `<div class="combo-empty">Aucun résultat</div>`;
      } else {
        menu.innerHTML =
          filtered.map(it =>
            `<div class="combo-item" data-label="${escapeAttr(it.label)}">${renderComboItem(it)}</div>`
          ).join("");
      }

      menu.style.display = "block";
    };

    const refreshInputState = () => {
      /*
       * IMPORTANT :
       *
       * Une ancienne valeur présente dans la notice peut ne plus
       * exister dans l'arborescence active.
       *
       * On la signale visuellement dans le champ mais on ne la
       * réinjecte PAS dans la liste des choix.
       *
       * C'est notamment ce qui évite qu'une ancienne valeur comme
       * "Arts visuels" réapparaisse dans la liste des sous-domaines.
       */

      const hasValue =
        !!(value || "")
          .toString()
          .trim();

      const isAllowed =
        !hasValue ||
        items.some(it =>
          norm(it.label) ===
          norm(value)
        );

      const hasNonAuthorizedValue =
        hasValue &&
        !isAllowed;

      input.classList.toggle(
        "non-authorized",
        hasNonAuthorizedValue
      );

      if (hasNonAuthorizedValue) {
        input.title =
          "Valeur actuelle non autorisée / absente de l’arborescence";
      } else {
        input.title = "";
      }
    };

    const closeMenu = () => {
      menu.style.display = "none";
    };

    input.addEventListener(
      "focus",
      () => {
        if (!input.disabled) {
          renderMenu("");
        }
      }
    );

    input.addEventListener(
      "input",
      () => {
        renderMenu(input.value);
        refreshInputState();
      }
    );

    input.addEventListener(
      "keydown",
      e => {
        if (e.key === "Escape") {
          input.blur();
        }
      }
    );

    input.addEventListener(
      "blur",
      () => {
        setTimeout(() => {
          closeMenu();

          if (input.value !== value) {
            const match =
              items.find(it =>
                norm(it.label) ===
                norm(input.value)
              );

            if (match) {
              value = match.label;
              input.value =
                match.label;

              onChangeCb(value);
            } else if (
              input.value.trim() === ""
            ) {
              value = "";

              onChangeCb(value);
            } else {
              /*
               * L'utilisateur ne peut pas créer manuellement
               * une nouvelle valeur non autorisée.
               */
              input.value = value;
            }
          }
        }, 150);
      }
    );

    menu.addEventListener(
      "mousedown",
      e => {
        const item =
          e.target.closest(
            ".combo-item"
          );

        if (!item) {
          return;
        }

        e.preventDefault();

        value =
          item.dataset.label;

        input.value =
          value;

        closeMenu();
        refreshInputState();

        onChangeCb(value);
      }
    );

    clearBtn.addEventListener(
      "click",
      () => {
        if (input.disabled) {
          return;
        }

        value = "";
        input.value = "";

        refreshInputState();

        onChangeCb(value);

        input.focus();
      }
    );

    return {
      setItems(newItems) {
        items =
          newItems || [];

        refreshInputState();
      },

      setValue(label, silent) {
        value =
          label || "";

        input.value =
          value;

        refreshInputState();

        if (!silent) {
          onChangeCb(value);
        }
      },

      getValue() {
        return value;
      },

      onChange(fn) {
        onChangeCb = fn;
      },

      setDisabled(state) {
        input.disabled =
          !!state;

        input.placeholder =
          state
            ? "—"
            : placeholder;
      }
    };
  };

  const chainLabel = p =>
    `<b>${escapeHTML(p.a || "—")}</b> › ${escapeHTML(p.b || "—")} › ${escapeHTML(p.e || "—")} › ${escapeHTML(p.f || "—")} › ${escapeHTML(p.g || "—")} › ${escapeHTML(p.s || "—")} › ${escapeHTML(p.p || "—")}`;

  const renderComboItem = item => {
    const rawPathCandidates = [
      item.raw?.parentPath,
      item.raw?.path,
      item.raw?.parent,
      item.raw?.fullPath,
      item.raw?.fullpath,
      item.raw?.hierarchy
    ];

    const context =
      rawPathCandidates
        .filter(Boolean)
        .map(value =>
          value.toString()
        )
        .map(value =>
          value.split(/[\\/|>]/)
        )
        .flat()
        .map(part =>
          part
            .replace(
              /\s*\([^)]*\)\s*$/g,
              ""
            )
            .trim()
        )
        .filter(Boolean)
        .slice(-2)
        .join(" › ");

    const note =
      item.note
        ? `<div class="combo-item-note">${escapeHTML(item.note)}</div>`
        : "";

    if (!context) {
      return `
        <div class="combo-item-label">${escapeHTML(item.label)}</div>
        ${note}
      `;
    }

    return `
      <div class="combo-item-label">${escapeHTML(item.label)}</div>
      <div class="combo-item-context">${escapeHTML(context)}</div>
      ${note}
    `;
  };

  // ============================================================
  // Création du panneau
  // ============================================================

  const createLegacyPanel = async (rows, cfg) => {
    if (
      document.getElementById(PANEL_ID)
    ) {
      return;
    }

    ensureStyle();

    const idx =
      buildIndex(rows);

    // Les listes 608 / 615 / 623 doivent être strictement celles du moteur 6XX,
    // et non des branches g/s/p de l'arborescence Koha.
    const [pmk608Items, pmk615Items, pmk623Items] = await Promise.all([
      pmk6xxItemsForField109({ tag: "608", subfield: "a" }),
      pmk6xxItemsForField109({ tag: "615", subfield: "a" }),
      pmk6xxItemsForField109({ tag: "623", subfield: "a" })
    ]);
    if (pmk608Items.length) idx.g = pmk608Items;
    if (pmk615Items.length) idx.s = pmk615Items;
    if (pmk623Items.length) idx.p = pmk623Items;

    const savedPanelState =
      getJSON(
        PANEL_STATE_KEY,
        {
          collapsed: false
        }
      );

    const root =
      document.createElement("div");

    root.id =
      PANEL_ID;

    if (
      savedPanelState.collapsed
    ) {
      root.classList.add(
        "collapsed"
      );
    }

    root.innerHTML = `
      <div class="head">
        <span>
          <span class="title">Assistant catalogage</span>
          <span
            class="subtitle"
            id="koha099_current_list"
          ></span>
        </span>

        <div class="head-btns">
          <button
            type="button"
            data-act="collapse"
            title="Réduire"
          >–</button>
        </div>
      </div>

      <div class="body">

        <div
          class="row"
          data-row="scope"
          style="display:none"
        >
          <label>Champ 099 cible</label>
          <select
            class="combo-input"
            data-sel="scope"
            style="width:100%"
          ></select>
        </div>

        <div
          class="row"
          data-row="a"
        >
          <label>Domaine ($a)</label>
        </div>

        <div
          class="row"
          data-row="b"
        >
          <label>Sous-domaine ($b)</label>
        </div>

        <div
          class="row"
          data-row="e"
        >
          <label>Thème ($e)</label>
        </div>

        <div
          class="row"
          data-row="f"
        >
          <label>Sujet ($f)</label>
        </div>

        <div
          class="row"
          data-row="g"
        >
          <label>Genre littéraire (608$a)</label>
        </div>

        <div
          class="row"
          data-row="s"
        >
          <label>Sujet (615$a)</label>
        </div>

        <div
          class="row"
          data-row="p"
        >
          <label>Personnage (623$a)</label>
        </div>

        <div class="actions">
          <button
            type="button"
            class="btn-primary"
            data-act="apply"
          >
            Appliquer
          </button>

          <button
            type="button"
            class="btn-secondary"
            data-act="save"
          >
            Mémoriser
          </button>

          <button
            type="button"
            class="btn-ghost"
            data-act="clear"
          >
            Vider
          </button>
        </div>

        <div
          class="status"
          id="koha099_status"
        ></div>

        <hr class="divider">

        <div class="presets-title">
          <span>Mémorisations</span>
          <span
            class="presets-count"
            id="koha099_presets_count"
          ></span>
        </div>

        <div class="presets-actions">
          <span class="note-presets">
            Les mémorisations sont listées ci-dessous.
            Ouvrez les options pour gérer les listes.
          </span>

          <div
            style="display:flex;gap:6px;align-items:center"
          >
            <button
              type="button"
              class="btn-secondary btn-small"
              data-act="togglePresetControls"
            >
              Options
            </button>
          </div>
        </div>

        <div
          class="preset-controls"
          id="koha099_preset_controls"
        >

          <div
            class="row"
            data-row="ownerSelect"
          >
            <label>Liste nominative</label>

            <select
              class="combo-input"
              data-owner-select
              style="width:100%"
            ></select>
          </div>

          <div
            class="row"
            data-row="owner"
          >
            <label>Créer une liste</label>

            <div
              style="display:flex;gap:8px;align-items:center"
            >
              <input
                type="text"
                class="combo-input"
                data-owner-input
                placeholder="Nom Prénom (requis)"
              >

              <button
                type="button"
                class="btn-secondary btn-small"
                data-act="createList"
              >
                Créer liste
              </button>
            </div>
          </div>

          <div
            class="row"
            style="font-size:11px;color:#6a6f7a;margin-bottom:8px;"
          >
            Sélectionnez une liste existante ou saisissez votre
            nom et prénom pour en créer une nouvelle avant de mémoriser.
          </div>

        </div>

        <div
          class="preset-list"
          id="koha099_presets"
        ></div>

      </div>
    `;

    document.body.appendChild(root);

    // ============================================================
    // Déplacement du panneau
    // ============================================================

    (() => {
      const head =
        root.querySelector(".head");

      let dragging = false;
      let offX = 0;
      let offY = 0;

      head.addEventListener(
        "mousedown",
        e => {
          if (
            e.target.closest(
              ".head-btns"
            )
          ) {
            return;
          }

          dragging = true;

          const r =
            root.getBoundingClientRect();

          offX =
            e.clientX - r.left;

          offY =
            e.clientY - r.top;

          root.style.right =
            "auto";
        }
      );

      document.addEventListener(
        "mousemove",
        e => {
          if (!dragging) {
            return;
          }

          root.style.left =
            `${e.clientX - offX}px`;

          root.style.top =
            `${e.clientY - offY}px`;
        }
      );

      document.addEventListener(
        "mouseup",
        () => {
          dragging = false;
        }
      );
    })();

    const scopeSel =
      root.querySelector(
        '[data-sel="scope"]'
      );

    const scopeRow =
      root.querySelector(
        '[data-row="scope"]'
      );

    const status =
      root.querySelector(
        "#koha099_status"
      );

    const presetsList =
      root.querySelector(
        "#koha099_presets"
      );

    const presetsCount =
      root.querySelector(
        "#koha099_presets_count"
      );

    const comboA =
      makeCombo(
        root.querySelector(
          '[data-row="a"]'
        ),
        "Rechercher un domaine…"
      );

    const comboB =
      makeCombo(
        root.querySelector(
          '[data-row="b"]'
        ),
        "Rechercher un sous-domaine…"
      );

    const comboE =
      makeCombo(
        root.querySelector(
          '[data-row="e"]'
        ),
        "Rechercher un thème…"
      );

    const comboF =
      makeCombo(
        root.querySelector(
          '[data-row="f"]'
        ),
        "Rechercher un sujet…"
      );

    const comboG =
      makeCombo(
        root.querySelector(
          '[data-row="g"]'
        ),
        "Rechercher un genre littéraire 608$a…"
      );

    const comboS =
      makeCombo(
        root.querySelector(
          '[data-row="s"]'
        ),
        "Rechercher un sujet 615$a…"
      );

    const comboP =
      makeCombo(
        root.querySelector(
          '[data-row="p"]'
        ),
        "Rechercher un personnage 623$a…"
      );

    // ============================================================
    // Champs 099 disponibles sur la notice
    // ============================================================

    const refreshScopes = () => {
      const scopes =
        findTagScopes();

      const prevValue =
        scopeSel.value;

      scopeSel.innerHTML =
        scopes
          .map(
            (sc, i) =>
              `<option value="${i}">Champ 099 #${i + 1} (${escapeHTML(sc.id)})</option>`
          )
          .join("");

      scopeRow.style.display =
        scopes.length > 1
          ? ""
          : "none";

      if (
        prevValue !== "" &&
        scopes[+prevValue]
      ) {
        scopeSel.value =
          prevValue;
      }

      return scopes;
    };

    let scopes =
      refreshScopes();

    const state = {
      a: "",
      b: "",
      e: "",
      f: "",
      g: "",
      s: "",
      p: ""
    };

    const last =
      getJSON(
        CACHE_KEY,
        {}
      );

    const readCurrentFieldText = field => {
      if (!field) {
        return "";
      }

      if (
        field.tagName === "SELECT"
      ) {
        const selected =
          field.options[
            field.selectedIndex
          ];

        return selected
          ? (
              selected.textContent ||
              selected.value ||
              ""
            )
          : (
              field.value ||
              ""
            );
      }

      return field.value || "";
    };

    const readCurrentValues = (scopeOverride = null) => {
      const values = {
        a: "",
        b: "",
        e: "",
        f: "",
        g: "",
        s: "",
        p: ""
      };

      const scope =
        scopeOverride || findTagScopes()[0];

      if (scope) {
        const aField =
          findFieldInScope(
            scope,
            "a"
          );

        const bField =
          findFieldInScope(
            scope,
            "b"
          );

        const eField =
          findFieldInScope(
            scope,
            "e"
          );

        const fField =
          findFFieldInScope(
            scope
          );

        values.a =
          readCurrentFieldText(
            aField
          );

        values.b =
          readCurrentFieldText(
            bField
          );

        values.e =
          readCurrentFieldText(
            eField
          );

        values.f =
          readCurrentFieldText(
            fField
          );
      }

      const gField =
        findGenreField();

      const sField =
        findSubject615Field();

      const pField =
        findCharacter623Field();

      values.g =
        readCurrentFieldText(
          gField
        );

      values.s =
        readCurrentFieldText(
          sField
        );

      values.p =
        readCurrentFieldText(
          pField
        );

      return values;
    };

    const findMatchingLabel = (
      items,
      rawValue
    ) => {
      const value = (rawValue || "").toString().trim();

      if (!value) {
        return "";
      }

      const target = norm(value);
      const match = (items || []).find(item =>
        [item.value, item.label, item.raw?.name, item.raw?.label]
          .filter(Boolean)
          .some(candidate => norm(candidate) === target)
      );

      return match ? match.label : "";
    };

    const resolveCurrentValue = (
      code,
      rawValue
    ) => {
      if (!rawValue) {
        return "";
      }

      switch (code) {
        case "a":
          return (
            findMatchingLabel(
              idx.a,
              rawValue
            ) ||
            rawValue
          );

        case "b":
          return (
            findMatchingLabel(
              [
                ...idx.bByA.values()
              ].flat(),
              rawValue
            ) ||
            rawValue
          );

        case "e":
          return (
            findMatchingLabel(
              [
                ...idx.eByAB.values()
              ].flat(),
              rawValue
            ) ||
            rawValue
          );

        case "f":
          return (
            findMatchingLabel(
              [
                ...idx.fByABE.values()
              ].flat(),
              rawValue
            ) ||
            rawValue
          );

        case "g":
          return (
            findMatchingLabel(
              idx.g,
              rawValue
            ) ||
            rawValue
          );

        case "s":
          return (
            findMatchingLabel(
              idx.s,
              rawValue
            ) ||
            rawValue
          );

        case "p":
          return (
            findMatchingLabel(
              idx.p,
              rawValue
            ) ||
            rawValue
          );

        default:
          return "";
      }
    };

    const resetPanelSelection = () => {
      state.a = "";
      state.b = "";
      state.e = "";
      state.f = "";
      state.g = "";
      state.s = "";
      state.p = "";

      comboA.setValue("", true);
      comboB.setValue("", true);
      comboE.setValue("", true);
      comboF.setValue("", true);
      comboG.setValue("", true);
      comboS.setValue("", true);
      comboP.setValue("", true);
    };

    const initializeFromPageValues = (
      attempt = 0
    ) => {
      resetPanelSelection();

      const selectedScope =
        scopes[+scopeSel.value] || scopes[0] || null;

      const currentValues =
        readCurrentValues(selectedScope);

      const hasAnyPageValue =
        Object
          .values(currentValues)
          .some(v =>
            (v || "")
              .toString()
              .trim()
          );

      if (
        !hasAnyPageValue &&
        attempt < 6
      ) {
        setTimeout(
          () =>
            initializeFromPageValues(
              attempt + 1
            ),
          120
        );

        return;
      }

      state.a =
        resolveCurrentValue(
          "a",
          currentValues.a
        ) || "";

      state.b =
        resolveCurrentValue(
          "b",
          currentValues.b
        ) || "";

      state.e =
        resolveCurrentValue(
          "e",
          currentValues.e
        ) || "";

      state.f =
        resolveCurrentValue(
          "f",
          currentValues.f
        ) || "";

      state.g =
        resolveCurrentValue(
          "g",
          currentValues.g
        ) || "";

      state.s =
        resolveCurrentValue(
          "s",
          currentValues.s
        ) || "";

      state.p =
        resolveCurrentValue(
          "p",
          currentValues.p
        ) || "";

      comboA.setValue(
        state.a,
        true
      );

      comboB.setValue(
        state.b,
        true
      );

      comboE.setValue(
        state.e,
        true
      );

      comboF.setValue(
        state.f,
        true
      );

      comboG.setValue(
        state.g,
        true
      );

      comboS.setValue(
        state.s,
        true
      );

      comboP.setValue(
        state.p,
        true
      );

      rebuild();
    };

    // ============================================================
    // Navigation dans l'arborescence
    // ============================================================

    const getAItem = () =>
      idx.a.find(
        x =>
          x.label === state.a
      ) || null;

    const getBItem = a => {
      if (!a) {
        return null;
      }

      return (
        idx.bByA.get(
          a.key
        ) || []
      ).find(
        x =>
          x.label === state.b
      ) || null;
    };

    const getEItem = (
      a,
      b
    ) => {
      if (!a || !b) {
        return null;
      }

      return (
        idx.eByAB.get(
          `${a.key}|||${b.key}`
        ) || []
      ).find(
        x =>
          x.label === state.e
      ) || null;
    };

    const getFItem = (
      a,
      b,
      e
    ) => {
      if (!a || !b || !e) {
        return null;
      }

      return (
        idx.fByABE.get(
          `${a.key}|||${b.key}|||${e.key}`
        ) || []
      ).find(
        x =>
          x.label === state.f
      ) || null;
    };

    const getSelectionContext = () => {
      const a =
        getAItem();

      const b =
        getBItem(a);

      const e =
        getEItem(a, b);

      const f =
        getFItem(a, b, e);

      return {
        a,
        b,
        e,
        f
      };
    };

    const matchesSelectionContext = (
      item,
      context
    ) => {
      const labels = [
        context.a?.label,
        context.b?.label,
        context.e?.label,
        context.f?.label
      ].filter(Boolean);

      if (!labels.length) {
        return true;
      }

      /*
       * Avec le nouvel index, on utilise l'ascendance exacte
       * reconstruite depuis parentPath.
       */
      if (
        Array.isArray(
          item.ancestorKeys
        )
      ) {
        return labels.every(lbl =>
          item.ancestorKeys.includes(
            norm(lbl)
          )
        );
      }

      /*
       * Compatibilité avec d'anciennes données éventuelles.
       */
      const pathText = [
        item.raw?.parentPath,
        item.raw?.path,
        item.raw?.parent
      ].find(v => !!v) || "";

      return labels.every(lbl =>
        norm(pathText).includes(
          norm(lbl)
        )
      );
    };

    const filterBy099Context = (
      items,
      context
    ) =>
      items.filter(item =>
        matchesSelectionContext(
          item,
          context
        )
      );

    const isAllowedLabel = (items, label) => {
      if (!label) return true;
      const target = norm(label);
      return (items || []).some(item =>
        [item?.value, item?.label].filter(Boolean).some(candidate => norm(candidate) === target)
      );
    };

    const getAllowedItemsForCode = code => {
      const a = getAItem();
      const b = getBItem(a);
      const e = getEItem(a, b);
      const f = getFItem(a, b, e);
      const context = getSelectionContext();
      const hasInvalid099Context =
        (!!state.a && !a) ||
        (!!state.b && !b) ||
        (!!state.e && !e) ||
        (!!state.f && !f);

      switch (code) {
        case "a":
          return idx.a;
        case "b":
          return a ? (idx.bByA.get(a.key) || []) : [];
        case "e":
          return a && b
            ? (idx.eByAB.get(`${a.key}|||${b.key}`) || [])
            : [];
        case "f":
          return a && b && e
            ? (idx.fByABE.get(`${a.key}|||${b.key}|||${e.key}`) || [])
            : [];
        case "g":
          return idx.g;
        case "s":
          return idx.s;
        case "p":
          return idx.p;
        default:
          return [];
      }
    };

    const updateStatus = () => {
      status.textContent =
        `Domaines disponibles : ${idx.a.length}, genres : ${idx.g.length}, sujets 615 : ${idx.s.length}, personnages 623 : ${idx.p.length}\n` +
        `Sélection : ${state.a || "—"} / ${state.b || "—"} / ${state.e || "—"} / ${state.f || "—"} / ${state.g || "—"} / ${state.s || "—"} / ${state.p || "—"}`;
    };

    /*
     * CORRECTION IMPORTANTE
     * =====================
     *
     * Avant, le script ajoutait la valeur actuellement présente dans
     * la notice dans la liste même si celle-ci n'existait plus dans
     * Koha.
     *
     * Exemple :
     *
     *   Arts visuels
     *
     * pouvait donc être réintroduit comme choix dans le sous-domaine.
     *
     * Désormais la liste contient UNIQUEMENT les valeurs réellement
     * autorisées par l'arborescence active.
     *
     * Si une notice contient encore une ancienne valeur, le champ la
     * conserve visuellement et passe en orange, mais cette valeur
     * n'est pas proposée dans la liste.
     */
    const addNoteForNonAllowedValues = (
      items,
      currentValue,
      allowedItems
    ) => {
      return (items || []).map(it => ({
        ...it,
        note: undefined,
        isUnallowed: false
      }));
    };

    const rebuild = () => {
      // Domaine
      const aItemsWithNotes =
        addNoteForNonAllowedValues(
          idx.a,
          state.a,
          idx.a
        );

      comboA.setItems(
        aItemsWithNotes
      );

      const a =
        getAItem();

      // Sous-domaine
      const bList =
        a
          ? (
              idx.bByA.get(
                a.key
              ) || []
            )
          : [];

      const bItemsWithNotes =
        addNoteForNonAllowedValues(
          bList,
          state.b,
          bList
        );

      comboB.setItems(
        bItemsWithNotes
      );

      comboB.setDisabled(
        !a
      );

      const b =
        getBItem(a);

      // Thème
      const eList =
        a && b
          ? (
              idx.eByAB.get(
                `${a.key}|||${b.key}`
              ) || []
            )
          : [];

      const eItemsWithNotes =
        addNoteForNonAllowedValues(
          eList,
          state.e,
          eList
        );

      comboE.setItems(
        eItemsWithNotes
      );

      comboE.setDisabled(
        !(a && b)
      );

      const e =
        getEItem(
          a,
          b
        );

      // Sujet 099$f
      const fList =
        a && b && e
          ? (
              idx.fByABE.get(
                `${a.key}|||${b.key}|||${e.key}`
              ) || []
            )
          : [];

      const fItemsWithNotes =
        addNoteForNonAllowedValues(
          fList,
          state.f,
          fList
        );

      comboF.setItems(
        fItemsWithNotes
      );

      comboF.setDisabled(
        !(a && b && e)
      );

      // 608$a, 615$a et 623$a : mêmes listes indépendantes que le moteur 081-084 6XX.
      const gList = idx.g;
      const sList = idx.s;
      const pList = idx.p;

      const gItemsWithNotes =
        addNoteForNonAllowedValues(
          gList,
          state.g,
          gList
        );

      const sItemsWithNotes =
        addNoteForNonAllowedValues(
          sList,
          state.s,
          sList
        );

      const pItemsWithNotes =
        addNoteForNonAllowedValues(
          pList,
          state.p,
          pList
        );

      comboG.setItems(
        gItemsWithNotes
      );

      comboG.setDisabled(
        false
      );

      comboS.setItems(
        sItemsWithNotes
      );

      comboS.setDisabled(
        false
      );

      comboP.setItems(
        pItemsWithNotes
      );

      comboP.setDisabled(
        false
      );

      setJSON(
        CACHE_KEY,
        state
      );

      updateStatus();
    };

    comboA.onChange(val => {
      state.a = val;
      state.b = "";
      state.e = "";
      state.f = "";

      comboB.setValue("", true);
      comboE.setValue("", true);
      comboF.setValue("", true);

      rebuild();
    });

    comboB.onChange(val => {
      state.b = val;
      state.e = "";
      state.f = "";

      comboE.setValue("", true);
      comboF.setValue("", true);

      rebuild();
    });

    comboE.onChange(val => {
      state.e = val;
      state.f = "";

      comboF.setValue("", true);

      rebuild();
    });

    comboF.onChange(val => {
      state.f = val;
      rebuild();
    });

    comboG.onChange(val => {
      state.g = val;
      rebuild();
    });

    comboS.onChange(val => {
      state.s = val;
      rebuild();
    });

    comboP.onChange(val => {
      state.p = val;
      rebuild();
    });


    window.addEventListener("pmk6xx:config-changed", async () => {
      try {
        const [next608, next615, next623] = await Promise.all([
          pmk6xxItemsForField109({ tag: "608", subfield: "a" }),
          pmk6xxItemsForField109({ tag: "615", subfield: "a" }),
          pmk6xxItemsForField109({ tag: "623", subfield: "a" })
        ]);
        if (next608.length) idx.g = next608;
        if (next615.length) idx.s = next615;
        if (next623.length) idx.p = next623;
        rebuild();
      } catch (_) {}
    });

    initializeFromPageValues();

    scopeSel.addEventListener("change", () => {
      scopes = refreshScopes();
      initializeFromPageValues();
    });

    let scopeRefreshTimer = null;
    const scopeObserver = new MutationObserver(() => {
      clearTimeout(scopeRefreshTimer);
      scopeRefreshTimer = setTimeout(() => {
        const previousIds = scopes.map(scope => scope.id).join("|");
        const currentScopes = findTagScopes();
        const currentIds = currentScopes.map(scope => scope.id).join("|");

        if (previousIds !== currentIds) {
          scopes = refreshScopes();
          initializeFromPageValues();
        }
      }, 120);
    });

    const scopeObserverTarget =
      document.querySelector("#cat_addbiblio") ||
      document.querySelector('form[name="f"]') ||
      document.body;

    scopeObserver.observe(scopeObserverTarget, {
      childList: true,
      subtree: true
    });

    // ============================================================
    // Mémorisations
    // ============================================================

    const ownerInput =
      root.querySelector(
        "[data-owner-input]"
      );

    const ownerSelect =
      root.querySelector(
        "[data-owner-select]"
      );

    const createListBtn =
      root.querySelector(
        '[data-act="createList"]'
      );

    const currentListLabel =
      root.querySelector(
        "#koha099_current_list"
      );

    let currentOwnerId = "";
    let currentOwnerName = "";
    let firebaseOwnerPresets = [];


    const effectiveListMode =
      cfg && cfg.lists && cfg.lists.mode === "koha_user"
        ? "koha_user"
        : "common";

    const resolveKohaUserIdentity = () => {
      const marker = document.querySelector(
        '.loggedinusername, #logged-in-info-full .loggedinusername, #logged-in-menu .loggedinusername'
      );

      let borrowernumber = "";
      let displayName = "";

      if (marker) {
        displayName = (marker.textContent || "").trim();
        borrowernumber =
          marker.getAttribute("data-borrowernumber") ||
          marker.dataset?.borrowernumber ||
          "";

        if (!borrowernumber) {
          const href = marker.getAttribute("href") || "";
          try {
            const u = new URL(href, location.origin);
            borrowernumber = u.searchParams.get("borrowernumber") || "";
          } catch (_) {}
        }
      }

      const fallback = norm(displayName)
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_]/g, "") || "unknown";

      return {
        id: borrowernumber ? `koha_${borrowernumber}` : `koha_name_${fallback}`,
        name: displayName || (borrowernumber ? `Koha #${borrowernumber}` : "Compte Koha")
      };
    };

    const kohaUserIdentity = resolveKohaUserIdentity();

    if (effectiveListMode === "koha_user") {
      const presetControls = root.querySelector("#koha099_preset_controls");
      const togglePresetControls = root.querySelector('[data-act="togglePresetControls"]');
      const note = root.querySelector(".note-presets");

      if (presetControls) presetControls.style.display = "none";
      if (togglePresetControls) togglePresetControls.style.display = "none";
      if (note) {
        note.textContent = `Mémorisations liées automatiquement au compte Koha : ${kohaUserIdentity.name}.`;
      }
    }

    const restoreSelectedList = () => {
      const saved =
        getJSON(
          SELECTED_LIST_KEY,
          null
        );

      if (
        saved &&
        saved.ownerId
      ) {
        return saved;
      }

      return null;
    };

    const saveSelectedList = (
      ownerId,
      ownerName
    ) => {
      setJSON(
        SELECTED_LIST_KEY,
        {
          ownerId,
          ownerName
        }
      );
    };

    const ownerIdFromName = name =>
      norm(name)
        .replace(/\s+/g, "_")
        .replace(
          /[^a-z0-9_]/g,
          ""
        );

    const renderOwnerOptions = owners => {
      ownerSelect.replaceChildren();

      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Sélectionnez votre nom...";
      ownerSelect.appendChild(placeholder);

      (owners || []).forEach(owner => {
        const option = document.createElement("option");
        option.value = owner.id || "";
        option.textContent = owner.ownerName || owner.id || "";
        ownerSelect.appendChild(option);
      });
    };

    const renderPresets = () => {
      const presets =
        currentOwnerId
          ? firebaseOwnerPresets
          : getJSON(
              PRESETS_KEY,
              []
            );

      presetsCount.textContent =
        `${presets.length}/${MAX_PRESETS}`;

      if (!presets.length) {
        presetsList.innerHTML =
          `<div class="preset-empty">Aucune mémorisation pour l'instant.</div>`;

        return;
      }

      presetsList.innerHTML =
        presets
          .map(
            (p, i) => `
              <div
                class="preset-item"
                data-idx="${i}"
              >
                <span class="preset-text">
                  ${p.name
                    ? `<span class="preset-name">${escapeHTML(p.name)}</span>`
                    : ""
                  }
                  <span class="preset-chain">${chainLabel(p)}</span>
                </span>

                <button
                  type="button"
                  class="preset-rename"
                  data-rename="${i}"
                  title="Renommer cette mémorisation"
                  aria-label="Renommer cette mémorisation"
                >✎</button>

                <button
                  type="button"
                  class="preset-del"
                  data-del="${i}"
                  title="Supprimer"
                  aria-label="Supprimer cette mémorisation"
                >×</button>
              </div>
            `
          )
          .join("");
    };

    const loadOwnersFromKoha = async () => {
      if (!firebaseDb) {
        return;
      }

      if (effectiveListMode === "koha_user") {
        currentOwnerId = kohaUserIdentity.id;
        currentOwnerName = kohaUserIdentity.name;
        ownerInput.value = currentOwnerName;
        await loadOwnerPresetsFromKoha(currentOwnerId);
        updateCurrentListHeader();
        return [{ id: currentOwnerId, ownerName: currentOwnerName }];
      }

      try {
        status.textContent =
          "Chargement des listes nominatives...";

        const snapshots =
          await getDocs(
            collection(
              firebaseDb,
              FIREBASE_PRESETS_COLLECTION
            )
          );

        const owners =
          snapshots.docs.map(doc => ({
            id:
              doc.id,

            ownerName:
              doc.data().ownerName ||
              doc.id
          }));

        renderOwnerOptions(
          owners
        );

        const savedList =
          restoreSelectedList();

        if (
          savedList &&
          owners.some(
            o =>
              o.id ===
              savedList.ownerId
          )
        ) {
          ownerSelect.value =
            savedList.ownerId;

          await loadOwnerPresetsFromKoha(
            savedList.ownerId
          );

          status.textContent =
            `Liste "${savedList.ownerName}" restaurée.`;
        } else {
          status.textContent =
            `Listes nominatives chargées (${owners.length}).`;
        }

        return owners;
      } catch (e) {
        status.textContent =
          "Erreur lors du chargement des listes Koha.";

        return [];
      }
    };

    const updateCurrentListHeader = () => {
      currentListLabel.textContent =
        currentOwnerName
          ? `Liste de : ${currentOwnerName}`
          : "";
    };

    const loadOwnerPresetsFromKoha =
      async ownerId => {
        if (!firebaseDb) {
          return;
        }

        if (!ownerId) {
          currentOwnerId = "";
          currentOwnerName = "";
          firebaseOwnerPresets = [];

          renderPresets();
          updateCurrentListHeader();

          saveSelectedList(
            "",
            ""
          );

          return;
        }

        try {
          status.textContent =
            "Chargement des mémorisations...";

          const ownerDoc =
            await getDoc(
              doc(
                firebaseDb,
                FIREBASE_PRESETS_COLLECTION,
                ownerId
              )
            );

          if (!ownerDoc.exists()) {
            firebaseOwnerPresets = [];
            currentOwnerId = ownerId;
            currentOwnerName =
              ownerInput.value.trim() ||
              ownerId;
          } else {
            currentOwnerId = ownerId;

            currentOwnerName =
              ownerDoc.data().ownerName ||
              ownerId;

            firebaseOwnerPresets =
              ownerDoc.data().presets ||
              [];
          }

          ownerInput.value =
            currentOwnerName;

          renderPresets();
          updateCurrentListHeader();

          saveSelectedList(
            currentOwnerId,
            currentOwnerName
          );

          status.textContent =
            `Mémorisations pour ${currentOwnerName} chargées (${firebaseOwnerPresets.length}).`;
        } catch (e) {
          status.textContent =
            "Erreur lors de la lecture des mémorisations Koha.";
        }
      };

    const savePresetToKoha =
      async () => {
        let ownerName =
          ownerInput.value.trim();

        if (
          !ownerName &&
          currentOwnerId
        ) {
          ownerName =
            currentOwnerName;
        }

        if (!ownerName) {
          status.textContent =
            "Entrez votre nom et prénom avant de mémoriser.";

          return;
        }

        if (!firebaseDb) {
          status.textContent =
            "Koha non disponible.";

          return;
        }

        const ownerId =
          ownerIdFromName(
            ownerName
          );

        if (!ownerId) {
          status.textContent =
            "Nom invalide pour la mémorisation.";

          return;
        }

        try {
          status.textContent =
            "Enregistrement en cours...";

          const ownerRef = doc(
            firebaseDb,
            FIREBASE_PRESETS_COLLECTION,
            ownerId
          );

          const newPreset = {
            a: state.a,
            b: state.b,
            e: state.e,
            f: state.f,
            g: state.g,
            s: state.s,
            p: state.p,
            createdAt: new Date().toISOString()
          };

          const updatedPresets = await runTransaction(
            firebaseDb,
            async transaction => {
              const ownerDoc = await transaction.get(ownerRef);
              const existing = ownerDoc.exists()
                ? [...(ownerDoc.data().presets || [])]
                : [];

              const dupIdx = existing.findIndex(p =>
                p.a === newPreset.a &&
                p.b === newPreset.b &&
                p.e === newPreset.e &&
                p.f === newPreset.f &&
                p.g === newPreset.g &&
                p.s === newPreset.s &&
                (p.p || "") === (newPreset.p || "")
              );

              if (dupIdx !== -1) {
                // Si cette combinaison existait déjà et avait été nommée,
                // conserver son nom lors d'une nouvelle mémorisation.
                newPreset.name = (
                  existing[dupIdx].name || ""
                ).toString().trim().slice(0, 80);

                existing.splice(dupIdx, 1);
              }

              existing.unshift(newPreset);

              while (existing.length > MAX_PRESETS) {
                existing.pop();
              }

              transaction.set(
                ownerRef,
                {
                  ownerName,
                  presets: existing,
                  updatedAt: serverTimestamp()
                },
                { merge: true }
              );

              return existing;
            }
          );

          currentOwnerId = ownerId;
          currentOwnerName = ownerName;
          firebaseOwnerPresets = updatedPresets;

          await loadOwnersFromKoha();
          ownerSelect.value = ownerId;
          renderPresets();
          updateCurrentListHeader();

          saveSelectedList(
            currentOwnerId,
            currentOwnerName
          );

          status.textContent =
            `Sélection enregistrée pour ${ownerName}.`;
        } catch (e) {

          status.textContent =
            `Erreur lors de l'enregistrement Koha : ${e.message || e}`;
        }
      };

    const presetMatches = (candidate, targetPreset) => {
      if (!candidate || !targetPreset) {
        return false;
      }

      if (targetPreset.createdAt && candidate.createdAt) {
        return candidate.createdAt === targetPreset.createdAt;
      }

      return (
        candidate.a === targetPreset.a &&
        candidate.b === targetPreset.b &&
        candidate.e === targetPreset.e &&
        candidate.f === targetPreset.f &&
        candidate.g === targetPreset.g &&
        candidate.s === targetPreset.s &&
        (candidate.p || "") === (targetPreset.p || "")
      );
    };

    const sanitizePresetName = value =>
      (value || "")
        .toString()
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 80);

    const renameLocalPreset = index => {
      const presets = getJSON(
        PRESETS_KEY,
        []
      );

      const targetPreset = presets[index];
      if (!targetPreset) {
        return;
      }

      const proposed = window.prompt(
        "Nom de cette mémorisation :",
        targetPreset.name || ""
      );

      if (proposed === null) {
        return;
      }

      const name = sanitizePresetName(proposed);

      if (name) {
        targetPreset.name = name;
      } else {
        delete targetPreset.name;
      }

      setJSON(
        PRESETS_KEY,
        presets
      );

      renderPresets();

      status.textContent = name
        ? `Mémorisation renommée « ${name} ».`
        : "Nom de la mémorisation supprimé.";
    };

    const renameKohaPreset =
      async index => {
        if (!firebaseDb || !currentOwnerId) {
          return;
        }

        const targetPreset = firebaseOwnerPresets[index];
        if (!targetPreset) {
          return;
        }

        const proposed = window.prompt(
          "Nom de cette mémorisation :",
          targetPreset.name || ""
        );

        if (proposed === null) {
          return;
        }

        const name = sanitizePresetName(proposed);

        try {
          status.textContent =
            "Renommage de la mémorisation...";

          const ownerRef = doc(
            firebaseDb,
            FIREBASE_PRESETS_COLLECTION,
            currentOwnerId
          );

          const updatedPresets = await runTransaction(
            firebaseDb,
            async transaction => {
              const ownerDoc = await transaction.get(ownerRef);

              if (!ownerDoc.exists()) {
                return [];
              }

              const currentPresets = [
                ...(ownerDoc.data().presets || [])
              ];

              const currentIndex = currentPresets.findIndex(
                preset => presetMatches(preset, targetPreset)
              );

              if (currentIndex === -1) {
                return currentPresets;
              }

              const updatedPreset = {
                ...currentPresets[currentIndex]
              };

              if (name) {
                updatedPreset.name = name;
              } else {
                delete updatedPreset.name;
              }

              currentPresets[currentIndex] = updatedPreset;

              transaction.set(
                ownerRef,
                {
                  presets: currentPresets,
                  updatedAt: serverTimestamp()
                },
                { merge: true }
              );

              return currentPresets;
            }
          );

          firebaseOwnerPresets = updatedPresets;
          renderPresets();

          status.textContent = name
            ? `Mémorisation renommée « ${name} ».`
            : "Nom de la mémorisation supprimé.";
        } catch (e) {
          status.textContent =
            `Erreur lors du renommage Koha : ${e.message || e}`;
        }
      };

    const deleteKohaPreset =
      async index => {
        if (!firebaseDb || !currentOwnerId) {
          return;
        }

        const targetPreset = firebaseOwnerPresets[index];
        if (!targetPreset) {
          return;
        }

        const locallyLastPreset = firebaseOwnerPresets.length === 1;
        let allowDeleteList = false;

        if (locallyLastPreset) {
          allowDeleteList = window.confirm(
            "La liste nominative est désormais vide. Voulez-vous supprimer la liste elle-même ?"
          );

          if (!allowDeleteList) {
            status.textContent =
              "Suppression annulée. La liste nominative reste active.";
            return;
          }
        }

        try {
          const ownerRef = doc(
            firebaseDb,
            FIREBASE_PRESETS_COLLECTION,
            currentOwnerId
          );

          const outcome = await runTransaction(
            firebaseDb,
            async transaction => {
              const ownerDoc = await transaction.get(ownerRef);

              if (!ownerDoc.exists()) {
                return { presets: [], deletedList: true };
              }

              const currentPresets = [
                ...(ownerDoc.data().presets || [])
              ];

              const currentIndex = currentPresets.findIndex(
                preset => presetMatches(preset, targetPreset)
              );

              if (currentIndex === -1) {
                return {
                  presets: currentPresets,
                  deletedList: false
                };
              }

              currentPresets.splice(currentIndex, 1);

              if (!currentPresets.length && allowDeleteList) {
                transaction.delete(ownerRef);
                return { presets: [], deletedList: true };
              }

              transaction.set(
                ownerRef,
                {
                  presets: currentPresets,
                  updatedAt: serverTimestamp()
                },
                { merge: true }
              );

              return {
                presets: currentPresets,
                deletedList: false
              };
            }
          );

          if (outcome.deletedList) {
            currentOwnerId = "";
            currentOwnerName = "";
            ownerSelect.value = "";
            ownerInput.value = "";
            firebaseOwnerPresets = [];

            await loadOwnersFromKoha();
            renderPresets();
            updateCurrentListHeader();
            saveSelectedList("", "");

            status.textContent =
              "Liste vide supprimée.";
            return;
          }

          firebaseOwnerPresets = outcome.presets;
          renderPresets();

          status.textContent =
            `Mémorisation supprimée pour ${currentOwnerName}.`;
        } catch (e) {
          status.textContent =
            "Erreur lors de la suppression Koha.";
        }
      };

    // ============================================================
    // Changement de liste nominative
    // ============================================================

    ownerSelect.addEventListener(
      "change",
      () => {
        if (effectiveListMode === "koha_user") return;
        const selectedId =
          ownerSelect.value;

        if (selectedId) {
          loadOwnerPresetsFromKoha(
            selectedId
          );
        } else {
          currentOwnerId = "";
          currentOwnerName = "";

          firebaseOwnerPresets = [];

          renderPresets();
          updateCurrentListHeader();

          saveSelectedList(
            "",
            ""
          );

          status.textContent =
            "Aucune liste sélectionnée.";
        }
      }
    );

    // ============================================================
    // Création d'une liste nominative
    // ============================================================

    createListBtn.addEventListener(
      "click",
      async () => {
        if (effectiveListMode === "koha_user") return;
        const name =
          ownerInput.value.trim();

        if (!name) {
          status.textContent =
            "Entrez un nom complet pour créer la liste.";

          ownerInput.focus();

          return;
        }

        if (!firebaseDb) {
          status.textContent =
            "Koha non disponible.";

          return;
        }

        const ownerId =
          ownerIdFromName(
            name
          );

        if (!ownerId) {
          status.textContent =
            "Nom invalide pour la liste.";

          ownerInput.focus();

          return;
        }

        try {
          status.textContent =
            "Création de la liste en cours...";

          const ownerRef = doc(
            firebaseDb,
            FIREBASE_PRESETS_COLLECTION,
            ownerId
          );

          await runTransaction(firebaseDb, async transaction => {
            const ownerDoc = await transaction.get(ownerRef);
            const existing = ownerDoc.exists()
              ? (ownerDoc.data().presets || [])
              : [];

            transaction.set(
              ownerRef,
              {
                ownerName: name,
                presets: existing,
                updatedAt: serverTimestamp()
              },
              { merge: true }
            );
          });

          currentOwnerId = ownerId;
          currentOwnerName = name;

          await loadOwnersFromKoha();
          ownerSelect.value = ownerId;
          await loadOwnerPresetsFromKoha(ownerId);

          saveSelectedList(
            currentOwnerId,
            currentOwnerName
          );

          status.textContent =
            `Liste "${name}" créée et sélectionnée.`;
        } catch (e) {

          status.textContent =
            `Erreur lors de la création de la liste : ${e.message || e}`;
        }
      }
    );

    // ============================================================
    // Options de mémorisation
    // ============================================================

    const presetControls =
      root.querySelector(
        "#koha099_preset_controls"
      );

    const togglePresetControlsBtn =
      root.querySelector(
        '[data-act="togglePresetControls"]'
      );

    const updatePresetControlsLabel =
      () => {
        const open =
          presetControls.classList.contains(
            "open"
          );

        togglePresetControlsBtn.textContent =
          open
            ? "Masquer"
            : "Options";
      };

    togglePresetControlsBtn.addEventListener(
      "click",
      () => {
        presetControls.classList.toggle(
          "open"
        );

        updatePresetControlsLabel();
      }
    );

    updatePresetControlsLabel();

    loadOwnersFromKoha();

    // ============================================================
    // Clic sur mémorisation
    // ============================================================

    presetsList.addEventListener(
      "click",
      e => {
        const renameBtn =
          e.target.closest(
            "[data-rename]"
          );

        if (renameBtn) {
          const index =
            +renameBtn.dataset.rename;

          if (currentOwnerId) {
            renameKohaPreset(
              index
            );
          } else {
            renameLocalPreset(
              index
            );
          }

          return;
        }

        const delBtn =
          e.target.closest(
            "[data-del]"
          );

        if (delBtn) {
          const index =
            +delBtn.dataset.del;

          if (currentOwnerId) {
            deleteKohaPreset(
              index
            );
          } else {
            const presets =
              getJSON(
                PRESETS_KEY,
                []
              );

            presets.splice(
              index,
              1
            );

            setJSON(
              PRESETS_KEY,
              presets
            );

            renderPresets();
          }

          return;
        }

        const item =
          e.target.closest(
            ".preset-item"
          );

        if (!item) {
          return;
        }

        const presets =
          currentOwnerId
            ? firebaseOwnerPresets
            : getJSON(
                PRESETS_KEY,
                []
              );

        const p =
          presets[
            +item.dataset.idx
          ];

        if (!p) {
          return;
        }

        state.a = p.a || "";
        state.b = p.b || "";
        state.e = p.e || "";
        state.f = p.f || "";
        state.g = p.g || "";
        state.s = p.s || "";
        state.p = p.p || "";

        comboA.setValue(
          state.a,
          true
        );

        comboB.setValue(
          state.b,
          true
        );

        comboE.setValue(
          state.e,
          true
        );

        comboF.setValue(
          state.f,
          true
        );

        comboG.setValue(
          state.g,
          true
        );

        comboS.setValue(
          state.s,
          true
        );

        comboP.setValue(
          state.p,
          true
        );

        rebuild();

        status.textContent =
          'Mémorisation chargée. Cliquez sur "Appliquer" pour l\'utiliser.';
      }
    );

    renderPresets();

    // ============================================================
    // Appliquer dans la notice
    // ============================================================

    const applyBtn =
      root.querySelector(
        '[data-act="apply"]'
      );

    if (applyBtn) {
      applyBtn.addEventListener(
        "click",
        () => {
          scopes =
            refreshScopes();

          const scope =
            scopes[
              +scopeSel.value
            ] ||
            scopes[0];

          if (!scope) {
            status.textContent =
              "Aucun champ 099 trouvé sur la page. Ajoutez d'abord le champ 099 dans la notice.";

            return;
          }

          const results = [];

          const zoneLabel = code =>
            code === "g"
              ? "608$a"
              : (
                  code === "s"
                    ? "615$a"
                    : (
                        code === "p"
                          ? "623$a"
                          : "$" + code
                      )
                );

          const applyOne = (
            code,
            label
          ) => {
            let field;

            if (code === "f") {
              field =
                findFFieldInScope(
                  scope
                );
            } else if (code === "g") {
              field =
                findGenreField();
            } else if (code === "s") {
              field =
                findSubject615Field();
            } else if (code === "p") {
              field =
                findCharacter623Field();
            } else {
              field =
                findFieldInScope(
                  scope,
                  code
                );
            }

            if (!field) {
              results.push(
                `${zoneLabel(code)} : ✘ champ introuvable sur la page`
              );

              return;
            }

            if (!label) {
              results.push(
                `${zoneLabel(code)} : inchangé`
              );

              return;
            }

            const allowedItems =
              getAllowedItemsForCode(code);

            if (!isAllowedLabel(allowedItems, label)) {
              results.push(
                `${zoneLabel(code)} : ✘ valeur absente de l’arborescence active`
              );

              return;
            }

            const selectedItem = (allowedItems || []).find(item =>
              [item?.label, item?.value].filter(Boolean).some(candidate => norm(candidate) === norm(label))
            );

            const valueToWrite =
              code === "g" || code === "s" || code === "p"
                ? (selectedItem?.value || label)
                : label;

            const r =
              setFieldByLabel(
                field,
                valueToWrite
              );

            results.push(
              `${zoneLabel(code)} : ${
                r.ok
                  ? "✔ " + r.matched
                  : "✘ " + r.reason
              }`
            );
          };

          applyOne(
            "a",
            state.a
          );

          applyOne(
            "b",
            state.b
          );

          applyOne(
            "e",
            state.e
          );

          applyOne(
            "f",
            state.f
          );

          applyOne(
            "g",
            state.g
          );

          applyOne(
            "s",
            state.s
          );

          applyOne(
            "p",
            state.p
          );

          status.textContent =
            results.join("\n");
        }
      );
    }

    // ============================================================
    // Mémoriser
    // ============================================================

    const saveBtn =
      root.querySelector(
        '[data-act="save"]'
      );

    if (saveBtn) {
      saveBtn.addEventListener(
        "click",
        async () => {
          if (
            !state.a &&
            !state.b &&
            !state.e &&
            !state.f &&
            !state.g &&
            !state.s &&
            !state.p
          ) {
            status.textContent =
              "Rien à mémoriser : sélectionnez au moins un domaine ou un champ supplémentaire.";

            return;
          }

          if (effectiveListMode === "koha_user") {
            currentOwnerId = kohaUserIdentity.id;
            currentOwnerName = kohaUserIdentity.name;
            ownerInput.value = currentOwnerName;
            await savePresetToKoha();
            return;
          }

          const ownerName =
            ownerInput.value.trim();

          if (
            ownerName ||
            currentOwnerId
          ) {
            await savePresetToKoha();

            return;
          }

          ownerInput.focus();

          status.textContent =
            "Aucune liste sélectionnée. Sélectionnez une liste existante ou saisissez votre nom et prénom pour en créer une nouvelle.";
        }
      );
    }

    const openCreateListModalBtn =
      root.querySelector(
        '[data-act="openCreateListModal"]'
      );

    if (openCreateListModalBtn) {
      openCreateListModalBtn.addEventListener(
        "click",
        () => {
          ownerInput.focus();

          status.textContent =
            "Saisissez votre nom complet dans le champ Nom complet pour créer une nouvelle liste.";
        }
      );
    }

    // ============================================================
    // Vider
    // ============================================================

    const clearBtn =
      root.querySelector(
        '[data-act="clear"]'
      );

    if (clearBtn) {
      clearBtn.addEventListener(
        "click",
        () => {
          state.a = "";
          state.b = "";
          state.e = "";
          state.f = "";
          state.g = "";
          state.s = "";
          state.p = "";

          comboA.setValue(
            "",
            true
          );

          comboB.setValue(
            "",
            true
          );

          comboE.setValue(
            "",
            true
          );

          comboF.setValue(
            "",
            true
          );

          comboG.setValue(
            "",
            true
          );

          comboS.setValue(
            "",
            true
          );

          comboP.setValue(
            "",
            true
          );

          rebuild();

          status.textContent =
            "Sélection du panneau vidée.";
        }
      );
    }

    // ============================================================
    // Réduire le panneau
    // ============================================================

    const collapseBtn =
      root.querySelector(
        '[data-act="collapse"]'
      );

    if (collapseBtn) {
      collapseBtn.addEventListener(
        "click",
        () => {
          root.classList.toggle(
            "collapsed"
          );

          setJSON(
            PANEL_STATE_KEY,
            {
              collapsed:
                root.classList.contains(
                  "collapsed"
                )
            }
          );
        }
      );
    }
  };

  // ============================================================
  // Runtime PMK + moteur générique MARC/UNIMARC
  // ============================================================

  const deepClone109 = value => {
    try { return structuredClone(value); } catch (_) {
      return JSON.parse(JSON.stringify(value));
    }
  };

  const deepMerge109 = (base, override) => {
    if (Array.isArray(override)) return deepClone109(override);
    if (!override || typeof override !== "object") {
      return override === undefined ? deepClone109(base) : override;
    }

    const out =
      base && typeof base === "object" && !Array.isArray(base)
        ? deepClone109(base)
        : {};

    Object.keys(override).forEach(key => {
      const next = override[key];
      if (
        next &&
        typeof next === "object" &&
        !Array.isArray(next) &&
        out[key] &&
        typeof out[key] === "object" &&
        !Array.isArray(out[key])
      ) {
        out[key] = deepMerge109(out[key], next);
      } else {
        out[key] = deepClone109(next);
      }
    });

    return out;
  };

  const tr109 = (fr, en) => {
    const cfgLang = runtimeConfig && runtimeConfig.language;
    if (cfgLang === "en") return en || fr;
    if (cfgLang === "fr") return fr;

    const kohaLang =
      document.documentElement.lang ||
      document.querySelector('html')?.getAttribute('lang') ||
      "fr";

    return /^en/i.test(kohaLang) ? (en || fr) : fr;
  };

  const normalizeMarcRef109 = field => {
    const tag = String(field?.tag || "").trim();
    const subfield = String(field?.subfield || "").trim();
    if (!/^\d{3}$/.test(tag) || !subfield) return null;
    return { tag, subfield: subfield.charAt(0) };
  };

  const activeLevels109 = cfg =>
    (Array.isArray(cfg?.levels) ? cfg.levels : [])
      .filter(level => level && level.enabled !== false && normalizeMarcRef109(level));

  const activeExtras109 = cfg =>
    (Array.isArray(cfg?.extraFields) ? cfg.extraFields : [])
      .filter(field => field && field.enabled !== false && normalizeMarcRef109(field));

  const runtimeDefaults109 = () => deepClone109(DEFAULT_RUNTIME_CONFIG);

  const loadRuntimeConfig109 = async () => {
    let cfg = runtimeDefaults109();

    try {
      if (window.PMKConfig && typeof window.PMKConfig.getConfig === "function") {
        const stored = await window.PMKConfig.getConfig(MODULE_ID);
        if (stored) cfg = deepMerge109(cfg, stored);
      }
    } catch (_) {
      // Compatibilité production : une panne du socle PMK ne doit pas
      // empêcher le 109 historique de fonctionner avec ses valeurs par défaut.
    }

    return cfg;
  };

  const ensureKoha109 = async () => {
    if (firebaseDb && collection && getDocs) return firebaseDb;

    const nativeStore = window.PMKNativeData;
    collection = nativeStore.collection; doc = nativeStore.doc;
    getDocs = nativeStore.getDocs; getDoc = nativeStore.getDoc;
    setDoc = nativeStore.setDoc; deleteDoc = nativeStore.deleteDoc;
    serverTimestamp = nativeStore.serverTimestamp; runTransaction = nativeStore.runTransaction;
    firebaseDb = nativeStore.createDatabase('taxonomy');
    return firebaseDb;
  };

  const loadLegacyTreeRows109 = async () => {
    await ensureKoha109();
    const treeCollection = collection(firebaseDb, "treeData");
    const snapshot = await getDocs(treeCollection);
    const rows = [];
    snapshot.forEach(snapshotDoc => rows.push({ id: snapshotDoc.id, ...snapshotDoc.data() }));
    return rows;
  };

  const bootLegacy109 = async cfg => {
    await ensureKoha109();
    const rows = await loadLegacyTreeRows109();

    window.PMKCataloguingTreeAssistant = {
      version: "4.1.0",
      moduleId: MODULE_ID,
      mode: "legacy_default",
      config: deepClone109(cfg),
      legacyRows: rows,
      getLegacyValues: code => legacyItemsForCode109(rows, String(code || "")),
      fetchAuthorisedValues: fetchKohaAuthorisedValues109
    };

    await createLegacyPanel(rows, cfg);
  };

  // ------------------------------------------------------------
  // Accès aux valeurs autorisées Koha
  // ------------------------------------------------------------

  const authorisedValuesCache109 = new Map();

  const fetchKohaAuthorisedValues109 = async category => {
    const categoryName = String(category || "").trim();
    if (!categoryName) return [];
    if (authorisedValuesCache109.has(categoryName)) {
      return deepClone109(authorisedValuesCache109.get(categoryName));
    }

    const url =
      "/api/v1/authorised_value_categories/" +
      encodeURIComponent(categoryName) +
      "/authorised_values?_per_page=1000&_order_by=description";

    const response = await fetch(url, {
      credentials: "same-origin",
      headers: { Accept: "application/json" }
    });

    if (!response.ok) {
      throw new Error(`Koha API ${response.status}`);
    }

    const data = await response.json();
    const items = (Array.isArray(data) ? data : []).map(row => ({
      key: norm(row.value || row.description || ""),
      value: String(row.value ?? row.description ?? ""),
      label: String(row.description || row.value || ""),
      description: String(row.description || ""),
      source: "authorised_values",
      raw: row
    })).filter(item => item.value || item.label);

    authorisedValuesCache109.set(categoryName, items);
    return deepClone109(items);
  };

  const parseManualValues109 = raw =>
    String(raw || "")
      .split(/\r?\n/)
      .map(line => line.trim())
      .filter(Boolean)
      .map(line => {
        const parts = line.split("|");
        const value = String(parts.shift() || "").trim();
        const label = String(parts.join("|") || value).trim();
        return {
          key: norm(value || label),
          value: value || label,
          label: label || value,
          description: label || value,
          source: "manual",
          raw: null
        };
      });

  const dedupeItems109 = items => {
    const map = new Map();
    (items || []).forEach(item => {
      const key = norm(item?.value || item?.label || "");
      if (!key) return;
      if (!map.has(key)) map.set(key, { ...item, key });
    });
    return [...map.values()].sort((a, b) =>
      String(a.label || a.value || "").localeCompare(
        String(b.label || b.value || ""),
        "fr",
        { sensitivity: "base" }
      )
    );
  };

  const legacyItemsForCode109 = (rows, code) => {
    const treeCtx = buildActiveTreeContext(rows || []);
    return dedupeItems109(
      treeCtx.rows
        .filter(row => parseLevel(getTreeNodeName(row)) === code)
        .map(row => {
          const label = cleanLabel(getTreeNodeName(row));
          return {
            key: norm(label),
            value: label,
            label,
            description: label,
            source: "firebase_legacy",
            raw: row,
            ancestorKeys: getAncestorLabelKeys(row, treeCtx)
          };
        })
        .filter(item => item.label)
    );
  };

  // ------------------------------------------------------------
  // Localisation de zones / sous-zones MARC génériques dans addbiblio
  // ------------------------------------------------------------

  const cssEscape109 = value => {
    if (window.CSS && typeof window.CSS.escape === "function") {
      return window.CSS.escape(String(value));
    }
    return String(value).replace(/([ #;?%&,.+*~\\':"!^$[\]()=>|/@])/g, "\\$1");
  };

  const findTagScopes109 = tag => {
    const safe = cssEscape109(tag);
    return [
      ...document.querySelectorAll(
        `li.tag.clearfix[id^="tag_${safe}_"], li.tag[id^="tag_${safe}_"], [data-tag="${safe}"]`
      )
    ];
  };

  const fieldSelectors109 = (tag, subfield) => {
    const t = cssEscape109(tag);
    const s = cssEscape109(subfield);
    return [
      `[name^="tag_${t}_subfield_${s}_"]`,
      `[id^="tag_${t}_subfield_${s}_"]`,
      `[data-tag="${t}"][data-subfield="${s}"]`
    ];
  };

  const findFieldInMarcScope109 = (scope, tag, subfield) => {
    if (!scope) return null;
    for (const selector of fieldSelectors109(tag, subfield)) {
      const found = scope.querySelector(selector);
      if (found) return found;
    }
    return null;
  };

  const findGlobalMarcField109 = (tag, subfield, occurrenceIndex = 0) => {
    const scopes = findTagScopes109(tag);
    if (scopes.length) {
      const scope = scopes[Math.max(0, Math.min(occurrenceIndex, scopes.length - 1))] || scopes[0];
      const field = findFieldInMarcScope109(scope, tag, subfield);
      if (field) return field;
    }

    for (const selector of fieldSelectors109(tag, subfield)) {
      const all = [...document.querySelectorAll(selector)];
      if (all.length) return all[Math.max(0, Math.min(occurrenceIndex, all.length - 1))] || all[0];
    }

    return null;
  };

  const resolveGenericField109 = (fieldCfg, primaryTag, primaryScope, scopeIndex) => {
    const ref = normalizeMarcRef109(fieldCfg);
    if (!ref) return null;

    if (ref.tag === primaryTag && primaryScope) {
      return findFieldInMarcScope109(primaryScope, ref.tag, ref.subfield) ||
        findGlobalMarcField109(ref.tag, ref.subfield, scopeIndex);
    }

    return findGlobalMarcField109(ref.tag, ref.subfield, 0);
  };

  const readFieldValue109 = field => {
    if (!field) return { value: "", label: "" };

    if (field.tagName === "SELECT") {
      const selected = field.options[field.selectedIndex];
      return {
        value: String(field.value || ""),
        label: String(selected?.textContent || selected?.label || field.value || "").trim()
      };
    }

    return {
      value: String(field.value || ""),
      label: String(field.value || "").trim()
    };
  };

  const setGenericField109 = (field, item) => {
    if (!field || !item) return { ok: false, reason: tr109("champ introuvable", "field not found") };

    const wantedValue = String(item.value ?? "");
    const wantedLabel = String(item.label ?? wantedValue);

    if (field.tagName === "SELECT") {
      const options = [...field.options];
      const match =
        options.find(opt => String(opt.value) === wantedValue) ||
        options.find(opt => norm(opt.textContent || opt.label || "") === norm(wantedLabel)) ||
        options.find(opt => norm(opt.value || "") === norm(wantedValue || wantedLabel));

      if (!match) {
        return { ok: false, reason: tr109("valeur absente du champ Koha", "value missing from Koha field") };
      }

      field.value = match.value;
      triggerNativeAndJQuery(field);
      return { ok: true, matched: (match.textContent || match.value || "").trim() };
    }

    field.value = wantedValue || wantedLabel;
    triggerNativeAndJQuery(field);
    return { ok: true, matched: field.value };
  };

  const domItemsForField109 = fieldCfg => {
    const ref = normalizeMarcRef109(fieldCfg);
    if (!ref) return [];
    const field = findGlobalMarcField109(ref.tag, ref.subfield, 0);
    if (!field || field.tagName !== "SELECT") return [];

    return dedupeItems109(
      [...field.options]
        .filter(opt => String(opt.value || opt.textContent || "").trim())
        .map(opt => ({
          key: norm(opt.value || opt.textContent || ""),
          value: String(opt.value || opt.textContent || ""),
          label: String(opt.textContent || opt.label || opt.value || "").trim(),
          description: String(opt.textContent || opt.label || opt.value || "").trim(),
          source: "koha_dom",
          raw: opt
        }))
    );
  };

  // ------------------------------------------------------------
  // Pont vers le moteur 081-084 des listes 6XX
  // ------------------------------------------------------------

  const PMK6XX_RULE_IDS_109 = Object.freeze({
    "608$a": "legacy-081-genre",
    "610$a": "legacy-082-indexation",
    "623$a": "legacy-083-element",
    "615$a": "legacy-084-categorie"
  });

  const PMK6XX_FALLBACK_KEYS_109 = Object.freeze({
    "608$a": "genre",
    "610$a": "indexation",
    "623$a": "element",
    "615$a": "subject"
  });

  const pmk6xxRef109 = fieldCfg => {
    const ref = normalizeMarcRef109(fieldCfg);
    return ref ? `${ref.tag}$${ref.subfield}` : "";
  };

  // Même parsing que parseLegacyManualValues() dans 081-084 :
  // l'ordre source, la valeur avant | et le libellé après | sont conservés.
  const parsePmk6xxLegacyManual109 = raw =>
    String(raw || "")
      .split(/\r?\n/)
      .map(line => {
        if (!line || !line.trim() || line.trim().startsWith("#")) return null;
        const pos = line.indexOf("|");
        const rawValue = pos === -1 ? line : line.slice(0, pos);
        const rawLabel = pos === -1 ? line : line.slice(pos + 1);
        const value = String(rawValue);
        const label = String(rawLabel || rawValue);
        if (!value) return null;
        return {
          key: norm(value),
          value,
          label,
          description: label,
          source: "pmk6xx_manual",
          raw: null
        };
      })
      .filter(Boolean);

  const pmk6xxItemsFromRenderedSelect109 = fieldCfg => {
    const ref = pmk6xxRef109(fieldCfg);
    const ruleId = PMK6XX_RULE_IDS_109[ref];
    if (!ruleId) return [];

    const selector = `.pmk6xx-assistant[data-rule-id="${ruleId}"] .pmk6xx-select`;
    const select = document.querySelector(selector);
    if (!select || !select.options) return [];

    return [...select.options]
      .filter(option => String(option.value || "") !== "")
      .map(option => ({
        key: norm(option.value || option.textContent || ""),
        value: String(option.value || ""),
        label: String(option.textContent || option.label || option.value || ""),
        description: String(option.textContent || option.label || option.value || ""),
        source: "pmk6xx_dom",
        raw: option
      }));
  };

  const pmk6xxConfigSnapshot109 = async () => {
    const api = window.PMK6XXConfig;
    if (!api) return null;

    try {
      if (api.ready && typeof api.ready.then === "function") {
        await api.ready;
      }
    } catch (_) {}

    try {
      if (typeof api.get === "function") {
        const current = api.get();
        if (current) return current;
      }
    } catch (_) {}

    return api.defaults || null;
  };

  const pmk6xxFallbackItems109 = fieldCfg => {
    const key = PMK6XX_FALLBACK_KEYS_109[pmk6xxRef109(fieldCfg)];
    return key
      ? parsePmk6xxLegacyManual109(PMK6XX_HISTORICAL_FALLBACK_109[key])
      : [];
  };

  const pmk6xxLabelForKohaRow109 = (row, mode) => {
    const value = String(row?.value || "").trim();
    const description = String(row?.description || "").trim();
    const opac = String(row?.opac_description || "").trim();
    if (mode === "value") return value;
    if (mode === "opac-description") return opac || description || value;
    if (mode === "value-description") {
      const label = description || opac || value;
      return label && label !== value ? `${value} — ${label}` : value;
    }
    return description || opac || value;
  };

  const pmk6xxMergeOptions109 = (apiItems, manualItems, rule) => {
    const map = new Map();
    const order = [];
    const insensitive = rule?.deduplicateCaseInsensitive === true;
    const optionKey = value => insensitive ? norm(value) : String(value || "").trim();

    const add = (item, override) => {
      if (!item || !String(item.value || "").trim()) return;
      const key = optionKey(item.value);
      if (!key) return;
      if (!map.has(key)) order.push(key);
      if (!map.has(key) || override) map.set(key, item);
    };

    (apiItems || []).forEach(item => add(item, false));
    (manualItems || []).forEach(item => add(item, true));

    let result = order.map(key => map.get(key)).filter(Boolean);
    if (rule?.sortMode === "label") {
      result = result.slice().sort((a, b) =>
        String(a.label || "").localeCompare(String(b.label || ""), "fr", { sensitivity: "base" })
      );
    } else if (rule?.sortMode === "value") {
      result = result.slice().sort((a, b) =>
        String(a.value || "").localeCompare(String(b.value || ""), "fr", { sensitivity: "base" })
      );
    }
    return result;
  };

  const pmk6xxItemsForField109 = async fieldCfg => {
    // 1. Priorité absolue : copier le <select> réellement généré par le 6XX.
    // Cela garantit la même liste, le même ordre, les mêmes value/label.
    const rendered = pmk6xxItemsFromRenderedSelect109(fieldCfg);
    if (rendered.length) return rendered;

    // 2. Sinon lire la configuration courante du moteur 6XX.
    const ref = pmk6xxRef109(fieldCfg);
    const cfg6 = await pmk6xxConfigSnapshot109();
    const rules = Array.isArray(cfg6?.rules) ? cfg6.rules : [];
    const rule = rules.find(candidate =>
      candidate &&
      candidate.enabled !== false &&
      String(candidate.marcTag || "").trim() === String(fieldCfg.tag || "").trim() &&
      String(candidate.subfield || "").trim() === String(fieldCfg.subfield || "").trim()
    ) || rules.find(candidate => candidate?.id === PMK6XX_RULE_IDS_109[ref]);

    if (rule) {
      const sourceMode = String(rule.sourceMode || "manual");
      const manual = sourceMode === "authorised"
        ? []
        : parsePmk6xxLegacyManual109(rule.manualValues || "");

      if (sourceMode === "manual") return manual;

      const api = window.PMK6XXConfig;
      const service = api?.authorisedValues;
      const apiItems = [];

      if (service && typeof service.listValues === "function") {
        const categories = (Array.isArray(rule.categories) ? rule.categories : [])
          .filter(entry => entry && entry.enabled !== false)
          .map(entry => String(entry.manualName || entry.name || "").trim())
          .filter(Boolean);

        for (const category of categories) {
          try {
            const rows = await service.listValues(category, cfg6?.api || {});
            (rows || []).forEach(row => {
              const value = String(row?.value || "").trim();
              if (!value) return;
              const label = pmk6xxLabelForKohaRow109(row, rule.displayMode);
              apiItems.push({
                key: norm(value),
                value,
                label,
                description: label,
                source: "pmk6xx_authorised",
                raw: row
              });
            });
          } catch (_) {}
        }
      }

      const merged = pmk6xxMergeOptions109(apiItems, manual, rule);
      if (merged.length) return merged;
    }

    // 3. Dernier recours : copie exacte des presets historiques du 081-084.
    return pmk6xxFallbackItems109(fieldCfg);
  };

  const loadItemsForField109 = async (fieldCfg, legacyRows) => {
    const type = String(fieldCfg?.sourceType || "firebase_legacy");

    if (type === "authorised_values") {
      try {
        const apiItems = await fetchKohaAuthorisedValues109(fieldCfg.authorisedValueCategory);
        if (apiItems.length) return dedupeItems109(apiItems);
      } catch (_) {}

      return domItemsForField109(fieldCfg);
    }

    if (type === "manual") {
      return dedupeItems109(parseManualValues109(fieldCfg.manualValues));
    }

    if (type === "koha_field") {
      return domItemsForField109(fieldCfg);
    }

    if (type === "pmk6xx") {
      return pmk6xxItemsForField109(fieldCfg);
    }

    return legacyItemsForCode109(legacyRows || [], String(fieldCfg?.firebaseCode || ""));
  };

  // ------------------------------------------------------------
  // Relations : arêtes configurées ou reconstruction Koha historique
  // ------------------------------------------------------------

  const relationKey109 = (fromId, fromValue, toId) =>
    `${String(fromId)}\u0001${norm(fromValue)}\u0001${String(toId)}`;

  const addRelation109 = (map, fromId, fromValue, toId, toValue) => {
    if (!fromId || !toId || !String(fromValue || "").trim() || !String(toValue || "").trim()) return;
    const key = relationKey109(fromId, fromValue, toId);
    if (!map.has(key)) map.set(key, new Set());
    map.get(key).add(norm(toValue));
  };

  const configuredRelations109 = cfg => {
    const map = new Map();
    (Array.isArray(cfg?.relationships) ? cfg.relationships : []).forEach(edge => {
      if (!edge || edge.enabled === false) return;
      addRelation109(map, edge.fromId, edge.fromValue, edge.toId, edge.toValue);
    });
    return map;
  };

  const deriveKohaRelations109 = (cfg, rows) => {
    const map = new Map();
    const levels = activeLevels109(cfg);
    const treeCtx = buildActiveTreeContext(rows || []);

    for (let i = 1; i < levels.length; i++) {
      const parentCfg = levels[i - 1];
      const childCfg = levels[i];
      const parentCode = String(parentCfg.firebaseCode || "");
      const childCode = String(childCfg.firebaseCode || "");
      if (!parentCode || !childCode) continue;

      treeCtx.rows.forEach(row => {
        if (parseLevel(getTreeNodeName(row)) !== childCode) return;
        const parent = findAncestorByLevel(row, parentCode, treeCtx);
        if (!parent) return;
        const parentValue = cleanLabel(getTreeNodeName(parent));
        const childValue = cleanLabel(getTreeNodeName(row));
        addRelation109(map, parentCfg.id, parentValue, childCfg.id, childValue);
      });
    }

    return map;
  };

  const mergeRelationMaps109 = (...maps) => {
    const out = new Map();
    maps.forEach(map => {
      if (!map) return;
      map.forEach((values, key) => {
        if (!out.has(key)) out.set(key, new Set());
        values.forEach(value => out.get(key).add(value));
      });
    });
    return out;
  };

  const diagnoseGenericModel109 = (cfg, levels, extras, itemsById, relations) => {
    const fields = new Map([...levels, ...extras].map(field => [String(field.id), field]));
    const issues = [];
    const enabledEdges = (Array.isArray(cfg?.relationships) ? cfg.relationships : [])
      .filter(edge => edge && edge.enabled !== false);

    [...fields.values()].forEach(field => {
      if (!(itemsById.get(field.id) || []).length) {
        issues.push({ type: "empty-source", fieldId: field.id,
          message: `${genericLabel109(field)} (${field.tag}$${field.subfield}) : aucune valeur disponible` });
      }
    });

    enabledEdges.forEach((edge, index) => {
      const from = fields.get(String(edge.fromId));
      const to = fields.get(String(edge.toId));
      if (!from || !to || from === to) {
        issues.push({ type: "invalid-relation", edgeIndex: index,
          message: `Relation ${index + 1} : niveau parent ou enfant absent/incohérent` });
        return;
      }
      const fromItems = itemsById.get(from.id) || [];
      const toItems = itemsById.get(to.id) || [];
      if (!fromItems.some(item => itemMatchesValue109(item, edge.fromValue))) {
        issues.push({ type: "unknown-parent", edgeIndex: index,
          message: `Relation ${index + 1} : valeur parente « ${edge.fromValue || "—"} » absente de ${genericLabel109(from)}` });
      }
      if (!toItems.some(item => itemMatchesValue109(item, edge.toValue))) {
        issues.push({ type: "unknown-child", edgeIndex: index,
          message: `Relation ${index + 1} : valeur enfant « ${edge.toValue || "—"} » absente de ${genericLabel109(to)}` });
      }
    });

    if (cfg?.hierarchy?.relationshipMode === "configured" && relations.size) {
      levels.slice(1).forEach(level => {
        const targeted = new Set();
        enabledEdges.filter(edge => String(edge.toId) === String(level.id))
          .forEach(edge => targeted.add(norm(edge.toValue)));
        (itemsById.get(level.id) || []).forEach(item => {
          const value = item.value || item.label;
          if (value && !targeted.has(norm(value))) {
            issues.push({ type: "orphan-value", fieldId: level.id, value,
              message: `${genericLabel109(level)} : « ${item.label || value} » n’est relié à aucun parent` });
          }
        });
      });
    }

    return {
      issues,
      counts: issues.reduce((out, issue) => {
        out[issue.type] = (out[issue.type] || 0) + 1;
        return out;
      }, {})
    };
  };

  const buildGenericModel109 = async (cfg, legacyRows) => {
    const levels = activeLevels109(cfg);
    const extras = activeExtras109(cfg);
    const itemsById = new Map();

    for (const fieldCfg of [...levels, ...extras]) {
      itemsById.set(fieldCfg.id, await loadItemsForField109(fieldCfg, legacyRows));
    }

    const configured = configuredRelations109(cfg);
    const derived =
      cfg?.hierarchy?.relationshipMode === "firebase_legacy"
        ? deriveKohaRelations109(cfg, legacyRows)
        : new Map();

    const relations =
      cfg?.hierarchy?.relationshipMode === "configured"
        ? configured
        : mergeRelationMaps109(derived, configured);

    const diagnostics = diagnoseGenericModel109(cfg, levels, extras, itemsById, relations);
    return { levels, extras, itemsById, relations, legacyRows, diagnostics };
  };

  const itemMatchesValue109 = (item, raw) => {
    const target = norm(raw || "");
    if (!target) return false;
    return [item?.value, item?.label, item?.description]
      .filter(Boolean)
      .some(candidate => norm(candidate) === target);
  };

  const findItem109 = (items, raw) =>
    (items || []).find(item => itemMatchesValue109(item, raw)) || null;

  const allowedItemsForLevel109 = (model, levelIndex, state) => {
    const level = model.levels[levelIndex];
    const all = model.itemsById.get(level.id) || [];
    if (levelIndex === 0) return all;

    const parent = model.levels[levelIndex - 1];
    const parentState = state[parent.id];
    if (!parentState) return [];

    const parentItem = findItem109(model.itemsById.get(parent.id) || [], parentState);
    if (!parentItem) return [];

    const key = relationKey109(parent.id, parentItem.value || parentItem.label, level.id);
    const allowedKeys = model.relations.get(key);

    if (!allowedKeys || !allowedKeys.size) {
      return model.relations.size === 0 && model.levels.every(x => x.sourceType !== "firebase_legacy")
        ? all
        : [];
    }

    return all.filter(item =>
      allowedKeys.has(norm(item.value || item.label)) ||
      allowedKeys.has(norm(item.label || item.value))
    );
  };

  const extraAllowedByKohaContext109 = (extraCfg, items, model, state) => {
    if (!extraCfg.filterByHierarchy || extraCfg.sourceType !== "firebase_legacy") return items;

    const selectedLabels = model.levels
      .map(level => {
        const item = findItem109(model.itemsById.get(level.id) || [], state[level.id]);
        return item?.label || item?.value || "";
      })
      .filter(Boolean);

    if (!selectedLabels.length) return items;

    return items.filter(item => {
      if (!Array.isArray(item.ancestorKeys)) return true;
      return selectedLabels.every(label => item.ancestorKeys.includes(norm(label)));
    });
  };

  // ------------------------------------------------------------
  // Filtrage natif Koha générique (fonction du 122 absorbée)
  // ------------------------------------------------------------

  const ensureGenericFilterStyle109 = () => {
    if (document.getElementById("pmk-tree-native-filter-style")) return;
    const style = document.createElement("style");
    style.id = "pmk-tree-native-filter-style";
    style.textContent = `
      .pmk-tree-invalid-value,
      .pmk-tree-invalid-value + .select2-container .select2-selection {
        background:#fff3cd !important;
        border-color:#e0a800 !important;
      }
      .pmk-tree-invalid-value + .select2-container .select2-selection__rendered {
        color:#7a4b00 !important;
        font-weight:600;
      }
      .pmk-tree-filtered-disabled + .select2-container { opacity:.64; }
    `;
    document.head.appendChild(style);
  };

  const markNativeField109 = (field, invalid, disabled) => {
    if (!field) return;
    field.classList.toggle("pmk-tree-invalid-value", !!invalid);
    field.classList.toggle("pmk-tree-filtered-disabled", !!disabled);
    if (invalid) {
      field.setAttribute(
        "title",
        tr109(
          "La valeur actuelle n'est pas autorisée par l'arborescence. Elle est conservée tant que l'agent ne la remplace pas.",
          "The current value is not allowed by the hierarchy. It is preserved until staff replaces it."
        )
      );
    } else {
      field.removeAttribute("title");
    }
  };

  const filterNativeSelect109 = (field, allowedItems, disabled, preserveInvalid) => {
    if (!field || field.tagName !== "SELECT") return;

    const current = readFieldValue109(field);
    const allowed = new Set();
    (allowedItems || []).forEach(item => {
      allowed.add(norm(item.value || ""));
      allowed.add(norm(item.label || ""));
    });

    [...field.options].forEach(option => {
      const isEmpty = !String(option.value || option.textContent || "").trim();
      const isAllowed =
        isEmpty ||
        allowed.has(norm(option.value || "")) ||
        allowed.has(norm(option.textContent || option.label || ""));
      const isCurrent =
        String(option.value) === String(field.value) ||
        norm(option.textContent || "") === norm(current.label);

      option.hidden = !isAllowed && !(preserveInvalid && isCurrent);
      option.disabled = !isAllowed && !(preserveInvalid && isCurrent);
    });

    const currentIsAllowed =
      !current.value && !current.label
        ? true
        : (allowed.has(norm(current.value)) || allowed.has(norm(current.label)));

    field.disabled = !!disabled;
    markNativeField109(field, !currentIsAllowed && !!(current.value || current.label), disabled);

    try {
      if (window.jQuery && window.jQuery(field).data("select2")) {
        window.jQuery(field).trigger("change.select2");
      }
    } catch (_) {}
  };

  const applyNativeFiltersToScope109 = (model, cfg, scope, scopeIndex) => {
    const primaryTag = model.levels[0]?.tag || "";
    const state = {};

    model.levels.forEach(level => {
      const field = resolveGenericField109(level, primaryTag, scope, scopeIndex);
      const current = readFieldValue109(field);
      state[level.id] = current.value || current.label || "";
    });

    model.levels.forEach((level, index) => {
      if (index === 0) return;
      const field = resolveGenericField109(level, primaryTag, scope, scopeIndex);
      if (!field || field.tagName !== "SELECT") return;
      const allowed = allowedItemsForLevel109(model, index, state);
      const parent = model.levels[index - 1];
      const parentValue = state[parent.id];
      filterNativeSelect109(
        field,
        allowed,
        !parentValue,
        cfg?.features?.preserveInvalidExistingValues !== false
      );
    });
  };

  const startNativeFiltering109 = (model, cfg) => {
    if (!(cfg?.features?.nativeFiltering || (cfg?.features?.legacyFiltering!==false && cfg?.hierarchy?.relationshipMode==="firebase_legacy" && cfg?.levels?.every(l=>l.sourceType==="firebase_legacy"))) || !model.levels.length) return () => {};
    ensureGenericFilterStyle109();

    const primaryTag = model.levels[0].tag;
    let timer = null;

    const applyAll = () => {
      const scopes = findTagScopes109(primaryTag);
      if (scopes.length) {
        scopes.forEach((scope, index) => applyNativeFiltersToScope109(model, cfg, scope, index));
      } else {
        applyNativeFiltersToScope109(model, cfg, null, 0);
      }
    };

    const onChange = event => {
      const target = event.target;
      if (!target) return;
      const watched = model.levels.some(level => {
        const ref = normalizeMarcRef109(level);
        if (!ref) return false;
        return fieldSelectors109(ref.tag, ref.subfield).some(selector => {
          try { return target.matches(selector); } catch (_) { return false; }
        });
      });
      if (!watched) return;
      clearTimeout(timer);
      timer = setTimeout(applyAll, 30);
    };

    document.addEventListener("change", onChange, true);
    document.addEventListener("select2:select", onChange, true);
    document.addEventListener("select2:clear", onChange, true);

    const observer = new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(applyAll, 120);
    });

    observer.observe(
      document.querySelector("#cat_addbiblio") || document.querySelector('form[name="f"]') || document.body,
      { childList: true, subtree: true }
    );

    applyAll();

    return () => {
      document.removeEventListener("change", onChange, true);
      document.removeEventListener("select2:select", onChange, true);
      document.removeEventListener("select2:clear", onChange, true);
      observer.disconnect();
    };
  };

  // ------------------------------------------------------------
  // Mémorisations génériques
  // ------------------------------------------------------------

  const genericKohaIdentity109 = () => {
    const marker = document.querySelector(
      '.loggedinusername, #logged-in-info-full .loggedinusername, #logged-in-menu .loggedinusername'
    );
    let borrowernumber = marker?.getAttribute("data-borrowernumber") || marker?.dataset?.borrowernumber || "";
    const name = (marker?.textContent || "").trim();

    if (!borrowernumber && marker) {
      try {
        const url = new URL(marker.getAttribute("href") || "", location.origin);
        borrowernumber = url.searchParams.get("borrowernumber") || "";
      } catch (_) {}
    }

    const slug = norm(name).replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "") || "unknown";
    return {
      id: borrowernumber ? `koha_${borrowernumber}` : `koha_name_${slug}`,
      name: name || (borrowernumber ? `Koha #${borrowernumber}` : "Compte Koha")
    };
  };

  const genericPresetDocId109 = cfg =>
    cfg?.lists?.mode === "koha_user"
      ? genericKohaIdentity109().id
      : "common";

  const loadGenericPresets109 = async cfg => {
    if (cfg?.lists?.enabled === false) return [];
    await ensureKoha109();
    const ref = doc(firebaseDb, GENERIC_PRESETS_COLLECTION, genericPresetDocId109(cfg));
    const snap = await getDoc(ref);
    return snap.exists() && Array.isArray(snap.data()?.presets) ? snap.data().presets : [];
  };

  const saveGenericPresets109 = async (cfg, presets) => {
    await ensureKoha109();
    const identity = genericKohaIdentity109();
    const ref = doc(firebaseDb, GENERIC_PRESETS_COLLECTION, genericPresetDocId109(cfg));
    await setDoc(ref, {
      mode: cfg?.lists?.mode === "koha_user" ? "koha_user" : "common",
      kohaUserName: cfg?.lists?.mode === "koha_user" ? identity.name : null,
      presets: presets,
      updatedAt: serverTimestamp()
    }, { merge: true });
  };

  // ------------------------------------------------------------
  // Panneau générique
  // ------------------------------------------------------------

  const genericLabel109 = field =>
    tr109(field?.labelFr || field?.id || "Champ", field?.labelEn || field?.labelFr || field?.id || "Field");

  const createGenericPanel109 = async (model, cfg) => {
    if (!cfg?.features?.assistant || !model.levels.length) return;
    if (document.getElementById(PANEL_ID)) return;

    ensureStyle();

    const root = document.createElement("div");
    root.id = PANEL_ID;
    root.classList.add("pmk-tree-generic");
    root.style.width = `${Math.max(280, Number(cfg?.appearance?.widthPx) || 360)}px`;

    const savedPanelState = getJSON(GENERIC_PANEL_STATE_KEY, { collapsed: false });
    if (cfg?.features?.rememberPanelState !== false && savedPanelState.collapsed) {
      root.classList.add("collapsed");
    }

    const primaryTag = model.levels[0].tag;
    const allFields = [...model.levels, ...model.extras];

    root.innerHTML = `
      <div class="head">
        <span>
          <span class="title">${escapeHTML(tr109("Assistant catalogage", "Cataloguing assistant"))}</span>
          <span class="subtitle" data-generic-list-label></span>
        </span>
        <div class="head-btns">
          <button type="button" data-act="collapse" title="${escapeAttr(tr109("Réduire", "Collapse"))}">–</button>
        </div>
      </div>
      <div class="body">
        <div class="status" data-generic-diagnostics style="display:none;margin-bottom:8px" role="status"></div>
        <div class="row" data-row="generic-scope" style="display:none">
          <label>${escapeHTML(tr109(`Zone ${primaryTag} cible`, `Target ${primaryTag} field`))}</label>
          <select class="combo-input" data-generic-scope style="width:100%"></select>
        </div>
        <div data-generic-fields></div>
        ${cfg?.features?.showBreadcrumb === false ? "" : `
          <div class="status" data-generic-breadcrumb style="margin-bottom:8px"></div>
        `}
        <div class="actions">
          <button type="button" class="btn-primary" data-act="generic-apply">${escapeHTML(tr109("Appliquer", "Apply"))}</button>
          ${cfg?.lists?.enabled === false ? "" : `<button type="button" class="btn-secondary" data-act="generic-save">${escapeHTML(tr109("Mémoriser", "Save"))}</button>`}
          <button type="button" class="btn-ghost" data-act="generic-clear">${escapeHTML(tr109("Vider", "Clear"))}</button>
        </div>
        <div class="status" data-generic-status></div>
        ${cfg?.lists?.enabled === false ? "" : `
          <hr class="divider">
          <div class="presets-title">
            <span>${escapeHTML(tr109("Mémorisations", "Saved selections"))}</span>
            <span class="presets-count" data-generic-presets-count></span>
          </div>
          <div class="preset-list" data-generic-presets></div>
        `}
      </div>
    `;

    document.body.appendChild(root);

    const fieldsHost = root.querySelector("[data-generic-fields]");
    const status = root.querySelector("[data-generic-status]");
    const diagnosticsHost = root.querySelector("[data-generic-diagnostics]");
    const breadcrumb = root.querySelector("[data-generic-breadcrumb]");
    const scopeRow = root.querySelector('[data-row="generic-scope"]');
    const scopeSelect = root.querySelector("[data-generic-scope]");
    const listLabel = root.querySelector("[data-generic-list-label]");
    const combos = new Map();
    const state = {};

    if (diagnosticsHost && model.diagnostics?.issues?.length) {
      const shown = model.diagnostics.issues.slice(0, 5);
      diagnosticsHost.style.display = "block";
      diagnosticsHost.textContent = `${tr109("Configuration à contrôler", "Configuration needs review")} (${model.diagnostics.issues.length}) : ` +
        shown.map(issue => issue.message).join(" · ") +
        (model.diagnostics.issues.length > shown.length ? ` · +${model.diagnostics.issues.length - shown.length}` : "");
    }

    if (listLabel) {
      listLabel.textContent =
        cfg?.lists?.mode === "koha_user"
          ? `${tr109("Compte Koha", "Koha account")}: ${genericKohaIdentity109().name}`
          : tr109("Listes communes", "Shared lists");
    }

    allFields.forEach(fieldCfg => {
      const row = document.createElement("div");
      row.className = "row";
      row.dataset.genericFieldId = fieldCfg.id;
      row.innerHTML = `<label>${escapeHTML(genericLabel109(fieldCfg))} (${escapeHTML(fieldCfg.tag + "$" + fieldCfg.subfield)})</label>`;
      fieldsHost.appendChild(row);
      const combo = makeCombo(row, tr109(`Rechercher : ${genericLabel109(fieldCfg)}…`, `Search: ${genericLabel109(fieldCfg)}…`));
      combos.set(fieldCfg.id, combo);
      state[fieldCfg.id] = "";
    });

    let scopes = [];
    const refreshScopes = () => {
      scopes = findTagScopes109(primaryTag);
      const before = scopeSelect.value;
      scopeSelect.innerHTML = scopes.map((scope, index) =>
        `<option value="${index}">${escapeHTML(`${primaryTag} #${index + 1} (${scope.id || "—"})`)}</option>`
      ).join("");
      scopeRow.style.display = scopes.length > 1 ? "" : "none";
      if (before !== "" && scopes[Number(before)]) scopeSelect.value = before;
      return scopes;
    };
    refreshScopes();

    const getSelectedScope = () => scopes[Number(scopeSelect.value)] || scopes[0] || null;
    const getScopeIndex = () => Math.max(0, Number(scopeSelect.value) || 0);

    const itemForState = fieldCfg =>
      findItem109(model.itemsById.get(fieldCfg.id) || [], state[fieldCfg.id]);

    const allowedItemsForExtra = extraCfg => {
      let items = model.itemsById.get(extraCfg.id) || [];
      items = extraAllowedByKohaContext109(extraCfg, items, model, state);

      const incomingParents = model.levels.filter(parent => {
        const parentItem = itemForState(parent);
        if (!parentItem) return false;
        return model.relations.has(relationKey109(parent.id, parentItem.value || parentItem.label, extraCfg.id));
      });

      if (!incomingParents.length) return items;

      return items.filter(item => incomingParents.every(parent => {
        const parentItem = itemForState(parent);
        const allowed = model.relations.get(relationKey109(parent.id, parentItem.value || parentItem.label, extraCfg.id));
        return allowed && (
          allowed.has(norm(item.value || item.label)) ||
          allowed.has(norm(item.label || item.value))
        );
      }));
    };

    const updateBreadcrumb = () => {
      if (!breadcrumb) return;
      const labels = model.levels.map(level => itemForState(level)?.label || "").filter(Boolean);
      breadcrumb.textContent = labels.length
        ? `${tr109("Chemin", "Path")}: ${labels.join(" › ")}`
        : tr109("Aucun chemin sélectionné.", "No path selected.");
    };

    const rebuild = () => {
      const filteringReasons = [];
      model.levels.forEach((level, index) => {
        const allowed = allowedItemsForLevel109(model, index, state);
        const combo = combos.get(level.id);
        combo.setItems(allowed);
        combo.setDisabled(index > 0 && !state[model.levels[index - 1].id]);
        if (index > 0 && state[model.levels[index - 1].id] && !allowed.length) {
          const parent = model.levels[index - 1];
          const parentItem = itemForState(parent);
          filteringReasons.push(tr109(
            `Aucune valeur proposée pour ${genericLabel109(level)} : aucune relation active depuis « ${parentItem?.label || state[parent.id]} ».`,
            `No value is offered for ${genericLabel109(level)}: no active relation from “${parentItem?.label || state[parent.id]}”.`
          ));
        }
      });

      model.extras.forEach(extra => {
        const combo = combos.get(extra.id);
        combo.setItems(allowedItemsForExtra(extra));
        combo.setDisabled(false);
      });

      if (cfg?.features?.rememberSelection !== false) {
        setJSON(GENERIC_CACHE_KEY, state);
      }

      updateBreadcrumb();
      if (filteringReasons.length) status.textContent = filteringReasons.join(" ");
      else if (/Aucune valeur proposée|No value is offered/.test(status.textContent || "")) status.textContent = "";
    };

    const clearAfter = levelIndex => {
      model.levels.slice(levelIndex + 1).forEach(level => {
        state[level.id] = "";
        combos.get(level.id)?.setValue("", true);
      });
    };

    model.levels.forEach((level, index) => {
      combos.get(level.id).onChange(value => {
        state[level.id] = value;
        clearAfter(index);
        rebuild();
      });
    });

    model.extras.forEach(extra => {
      combos.get(extra.id).onChange(value => {
        state[extra.id] = value;
        rebuild();
      });
    });

    const initializeFromPage = () => {
      const scope = getSelectedScope();
      const scopeIndex = getScopeIndex();
      allFields.forEach(fieldCfg => {
        const field = resolveGenericField109(fieldCfg, primaryTag, scope, scopeIndex);
        const current = readFieldValue109(field);
        const items = model.itemsById.get(fieldCfg.id) || [];
        const match = findItem109(items, current.value) || findItem109(items, current.label);
        state[fieldCfg.id] = match ? (match.value || match.label) : (current.value || current.label || "");
        combos.get(fieldCfg.id)?.setValue(state[fieldCfg.id], true);
      });
      rebuild();
    };

    initializeFromPage();

    scopeSelect.addEventListener("change", () => {
      refreshScopes();
      initializeFromPage();
    });

    root.querySelector('[data-act="generic-apply"]')?.addEventListener("click", () => {
      const scope = getSelectedScope();
      const scopeIndex = getScopeIndex();
      const results = [];

      allFields.forEach(fieldCfg => {
        const raw = state[fieldCfg.id];
        if (!raw) {
          results.push(`${fieldCfg.tag}$${fieldCfg.subfield} : ${tr109("inchangé", "unchanged")}`);
          return;
        }

        const items =
          model.levels.includes(fieldCfg)
            ? allowedItemsForLevel109(model, model.levels.indexOf(fieldCfg), state)
            : allowedItemsForExtra(fieldCfg);

        const item = findItem109(items, raw);
        if (!item) {
          results.push(`${fieldCfg.tag}$${fieldCfg.subfield} : ✘ ${tr109("valeur non autorisée", "value not allowed")}`);
          return;
        }

        const field = resolveGenericField109(fieldCfg, primaryTag, scope, scopeIndex);
        const result = setGenericField109(field, item);
        results.push(`${fieldCfg.tag}$${fieldCfg.subfield} : ${result.ok ? "✔ " + result.matched : "✘ " + result.reason}`);
      });

      status.textContent = results.join("\n");
    });

    root.querySelector('[data-act="generic-clear"]')?.addEventListener("click", () => {
      allFields.forEach(fieldCfg => {
        state[fieldCfg.id] = "";
        combos.get(fieldCfg.id)?.setValue("", true);
      });
      rebuild();
      status.textContent = tr109("Sélection du panneau vidée.", "Assistant selection cleared.");
    });

    root.querySelector('[data-act="collapse"]')?.addEventListener("click", () => {
      root.classList.toggle("collapsed");
      if (cfg?.features?.rememberPanelState !== false) {
        setJSON(GENERIC_PANEL_STATE_KEY, { collapsed: root.classList.contains("collapsed") });
      }
    });

    // Déplacement : même principe que le 109 historique.
    (() => {
      const head = root.querySelector(".head");
      let dragging = false;
      let offX = 0;
      let offY = 0;
      head.addEventListener("mousedown", event => {
        if (event.target.closest(".head-btns")) return;
        dragging = true;
        const rect = root.getBoundingClientRect();
        offX = event.clientX - rect.left;
        offY = event.clientY - rect.top;
        root.style.right = "auto";
      });
      document.addEventListener("mousemove", event => {
        if (!dragging) return;
        root.style.left = `${Math.max(0, event.clientX - offX)}px`;
        root.style.top = `${Math.max(0, event.clientY - offY)}px`;
      });
      document.addEventListener("mouseup", () => { dragging = false; });
    })();

    // Mémorisations génériques.
    const presetsHost = root.querySelector("[data-generic-presets]");
    const presetsCount = root.querySelector("[data-generic-presets-count]");
    let presets = [];

    const renderPresets = () => {
      if (!presetsHost) return;
      const max = Math.max(1, Number(cfg?.lists?.maxPresets) || 20);
      if (presetsCount) presetsCount.textContent = `${presets.length}/${max}`;
      if (!presets.length) {
        presetsHost.innerHTML = `<div class="preset-empty">${escapeHTML(tr109("Aucune mémorisation pour l'instant.", "No saved selection yet."))}</div>`;
        return;
      }
      presetsHost.innerHTML = presets.map((preset, index) => {
        const labels = allFields.map(fieldCfg => {
          const raw = preset.values?.[fieldCfg.id];
          return findItem109(model.itemsById.get(fieldCfg.id) || [], raw)?.label || raw || "";
        }).filter(Boolean);
        return `
          <div class="preset-item" data-generic-preset="${index}">
            <span class="preset-text">
              ${preset.name ? `<span class="preset-name">${escapeHTML(preset.name)}</span>` : ""}
              <span class="preset-chain">${escapeHTML(labels.join(" › "))}</span>
            </span>
            <button type="button" class="preset-del" data-generic-delete="${index}" title="${escapeAttr(tr109("Supprimer", "Delete"))}" aria-label="${escapeAttr(tr109("Supprimer", "Delete"))}">×</button>
          </div>`;
      }).join("");
    };

    if (presetsHost) {
      try {
        presets = await loadGenericPresets109(cfg);
      } catch (_) {
        presets = getJSON("pmk_cataloguing_tree_presets_fallback", []);
      }
      renderPresets();

      presetsHost.addEventListener("click", async event => {
        const deleteButton = event.target.closest("[data-generic-delete]");
        if (deleteButton) {
          const index = Number(deleteButton.dataset.genericDelete);
          presets.splice(index, 1);
          try { await saveGenericPresets109(cfg, presets); }
          catch (_) { setJSON("pmk_cataloguing_tree_presets_fallback", presets); }
          renderPresets();
          return;
        }

        const item = event.target.closest("[data-generic-preset]");
        if (!item) return;
        const preset = presets[Number(item.dataset.genericPreset)];
        if (!preset) return;
        allFields.forEach(fieldCfg => {
          state[fieldCfg.id] = String(preset.values?.[fieldCfg.id] || "");
          combos.get(fieldCfg.id)?.setValue(state[fieldCfg.id], true);
        });
        rebuild();
        status.textContent = tr109('Mémorisation chargée. Cliquez sur "Appliquer" pour l’utiliser.', 'Saved selection loaded. Click “Apply” to use it.');
      });
    }

    root.querySelector('[data-act="generic-save"]')?.addEventListener("click", async () => {
      const values = {};
      allFields.forEach(fieldCfg => { values[fieldCfg.id] = state[fieldCfg.id] || ""; });
      if (!Object.values(values).some(Boolean)) {
        status.textContent = tr109("Rien à mémoriser.", "Nothing to save.");
        return;
      }

      const suggested = model.levels.map(level => itemForState(level)?.label || "").filter(Boolean).join(" › ");
      const name = window.prompt(tr109("Nom de la mémorisation (facultatif)", "Saved selection name (optional)"), suggested) || "";
      const max = Math.max(1, Number(cfg?.lists?.maxPresets) || 20);
      presets.unshift({ name: name.trim().slice(0, 80), values, updatedAt: Date.now() });
      presets = presets.slice(0, max);
      try {
        await saveGenericPresets109(cfg, presets);
      } catch (_) {
        setJSON("pmk_cataloguing_tree_presets_fallback", presets);
      }
      renderPresets();
      status.textContent = tr109("Mémorisation enregistrée.", "Saved selection stored.");
    });

    // Responsive sans modifier le rendu desktop historique.
    const media = window.matchMedia(`(max-width:${Math.max(320, Number(cfg?.appearance?.mobileBreakpointPx) || 576)}px)`);
    const applyResponsive = () => {
      if (media.matches) {
        root.style.width = "calc(100vw - 16px)";
        root.style.maxWidth = "calc(100vw - 16px)";
        root.style.left = "8px";
        root.style.right = "8px";
        root.style.top = "58px";
      } else {
        root.style.width = `${Math.max(280, Number(cfg?.appearance?.widthPx) || 360)}px`;
        root.style.maxWidth = "";
        if (!root.style.left) root.style.right = "20px";
      }
    };
    applyResponsive();
    try { media.addEventListener("change", applyResponsive); } catch (_) { media.addListener(applyResponsive); }
  };

  const bootGeneric109 = async cfg => {
    let legacyRows = [];
    const needsKoha = [...activeLevels109(cfg), ...activeExtras109(cfg)]
      .some(field => field.sourceType === "firebase_legacy") ||
      cfg?.hierarchy?.relationshipMode === "firebase_legacy" ||
      cfg?.lists?.enabled !== false;

    if (needsKoha) {
      try { legacyRows = await loadLegacyTreeRows109(); }
      catch (_) {
        // Le moteur reste utilisable avec VA / manuel même si Koha est indisponible.
        legacyRows = [];
      }
    }

    const model = await buildGenericModel109(cfg, legacyRows);
    startNativeFiltering109(model, cfg);
    await createGenericPanel109(model, cfg);

    window.PMKCataloguingTreeAssistant = {
      version: "4.1.0",
      moduleId: MODULE_ID,
      config: deepClone109(cfg),
      model: model,
      diagnostics: deepClone109(model.diagnostics),
      reload: () => location.reload(),
      fetchAuthorisedValues: fetchKohaAuthorisedValues109
    };
  };

  const boot = async () => {
    await waitForBody();
    ensureStyle();

    runtimeConfig = await loadRuntimeConfig109();

    if (!runtimeConfig || runtimeConfig.enabled === false || runtimeConfig?.page?.enabled === false ||
        location.pathname !== (runtimeConfig.page?.path || "/cgi-bin/koha/cataloguing/addbiblio.pl")) {
      return;
    }

    try {
      // Preserve the existing panel and its saved presets for the unchanged historical profile.
      // Customized fields and sources automatically use the configurable assistant.
      const baseline = runtimeDefaults109();
      const customized = ["levels", "extraFields", "relationships", "hierarchy", "features", "lists", "appearance", "language"]
        .some(key => JSON.stringify(runtimeConfig[key]) !== JSON.stringify(baseline[key]));
      if (runtimeConfig.runtimeMode === "generic" || customized) await bootGeneric109(runtimeConfig);
      else await bootLegacy109(runtimeConfig);
    } catch (error) {
      // Fail-safe : le module ne doit jamais empêcher le catalogage Koha.
      try { console.error("[PMK 109]", error); } catch (_) {}
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();

;window.PMKNonPlugin.loaded.push("109-helper-domaine.js");
} catch (error) { window.PMKNonPlugin.errors.push("109-helper-domaine.js: "+error.message); console.error("[PMK] 109-helper-domaine.js",error); };
try {
/*
 Nom du fichier : 110-exemplaire-helper.js
 Version : 3.1.2-preplugin
 Date : 2026-09-20

 PimpMyKoha — Assistant de saisie des exemplaires

 Principes :
 - conserve le rendu et le profil initial historique par défaut ;
 - reste totalement autonome du 102 "Boutons modèles exemplaires" ;
 - ne soumet JAMAIS le formulaire Koha et n'enregistre jamais un exemplaire automatiquement ;
 - fonctionne sur additem.pl et batchMod.pl ;
 - accepte un nombre libre de champs exemplaire configurés par kohafield / sélecteur ;
 - conserve "Copier au + nombreux" avec le calcul historique : majorité stricte, au moins 2 occurrences, pas d'égalité ;
 - respecte le mécanisme natif Koha disable_input sur batchMod.pl pour les vidages ;
 - source les choix par formulaire Koha, valeurs autorisées, API Koha ou liste manuelle avec repli sûr ;
 - valide toujours les valeurs finales contre les contrôles réellement présents dans Koha ;
 - synchronise input/change et Select2 ;
 - conserve les mémorisations Koha historiques et ajoute des modes commun / compte Koha sans les imposer ;
 - français / anglais ; responsive ; fail-safe.
*/
(function () {
    "use strict";

    if (window.__PMK110_ITEM_ENTRY_ASSISTANT__) return;
    window.__PMK110_ITEM_ENTRY_ASSISTANT__ = true;

    const MODULE_ID = "item-entry-assistant";
    const MODULE_VERSION = "3.1.2-preplugin";
    const PANEL_ID = "koha_items_assistant_panel";
    const CACHE_KEY = "koha_items_assistant_last";
    const PRESETS_KEY = "koha_items_assistant_presets";
    const PANEL_STATE_KEY = "koha_items_assistant_panel_state";
    const PANEL_POSITION_KEY = "koha_items_assistant_panel_position";
    const SELECTED_OWNER_KEY = "koha_items_assistant_selected_owner";
    const PRESET_CONTROLS_KEY = "koha_items_assistant_preset_controls_open";

    const PAGE_DEFINITIONS = [
        { id: "cataloguing.additem", path: "/cgi-bin/koha/cataloguing/additem.pl", labelFr: "Création / modification d’exemplaire", labelEn: "Item creation / editing", enabled: true },
        { id: "tools.batchmod", path: "/cgi-bin/koha/tools/batchMod.pl", labelFr: "Modification d’exemplaires par lot", labelEn: "Batch item modification", enabled: true }
    ];

    const DEFAULT_FIREBASE_CONFIG = {}; // Anciennes options conservées uniquement dans les sauvegardes.

    const DEFAULT_FIELDS = [
        { id:"b", legacyCode:"b", enabled:true, kohafield:"items.homebranch", marcTag:"995", marcSubfield:"b", labelFr:"Site Prop.", labelEn:"Home library", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"c", legacyCode:"c", enabled:true, kohafield:"items.holdingbranch", marcTag:"995", marcSubfield:"c", labelFr:"Site actuel", labelEn:"Current library", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"s", legacyCode:"s", enabled:true, kohafield:"items.enumchron", marcTag:"995", marcSubfield:"s", labelFr:"Etage", labelEn:"Level", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"e", legacyCode:"e", enabled:true, kohafield:"items.location", marcTag:"995", marcSubfield:"e", labelFr:"Localisation", labelEn:"Location", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"j", legacyCode:"j", enabled:true, kohafield:"items.copynumber", marcTag:"995", marcSubfield:"j", labelFr:"Sous local.", labelEn:"Sub-location", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"k", legacyCode:"k", enabled:true, kohafield:"items.itemcallnumber", marcTag:"995", marcSubfield:"k", labelFr:"Cote", labelEn:"Call number", type:"input", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"f", legacyCode:"f", enabled:true, kohafield:"items.barcode", marcTag:"995", marcSubfield:"f", labelFr:"Code barre", labelEn:"Barcode", type:"input", allowClear:true, copyEligible:false, normalize:"none", selector:"" },
        { id:"r", legacyCode:"r", enabled:true, kohafield:"items.itype", marcTag:"995", marcSubfield:"r", labelFr:"Type doc.", labelEn:"Item type", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"3", legacyCode:"3", enabled:true, kohafield:"items.ccode", marcTag:"995", marcSubfield:"3", labelFr:"Collection", labelEn:"Collection", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"q", legacyCode:"q", enabled:true, kohafield:"items.more_subfields_xml_q", marcTag:"995", marcSubfield:"q", labelFr:"Public", labelEn:"Audience", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"o", legacyCode:"o", enabled:true, kohafield:"items.notforloan", marcTag:"995", marcSubfield:"o", labelFr:"Statut", labelEn:"Status", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"2", legacyCode:"2", enabled:true, kohafield:"items.itemlost", marcTag:"995", marcSubfield:"2", labelFr:"Motif exclu", labelEn:"Lost status", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"t", legacyCode:"t", enabled:true, kohafield:"items.more_subfields_xml_t", marcTag:"995", marcSubfield:"t", labelFr:"Achat/don", labelEn:"Purchase / gift", type:"select", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"A", legacyCode:"A", enabled:true, kohafield:"items.more_subfields_xml_A", marcTag:"995", marcSubfield:"A", labelFr:"Fournisseur", labelEn:"Vendor", type:"input", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"p", legacyCode:"p", enabled:true, kohafield:"items.replacementprice", marcTag:"995", marcSubfield:"p", labelFr:"Prix", labelEn:"Replacement price", type:"input", allowClear:true, copyEligible:true, normalize:"price", selector:"" },
        { id:"u", legacyCode:"u", enabled:true, kohafield:"items.itemnotes_nonpublic", marcTag:"995", marcSubfield:"u", labelFr:"Note interne", labelEn:"Internal note", type:"input", allowClear:true, copyEligible:true, normalize:"none", selector:"" },
        { id:"x", legacyCode:"x", enabled:true, kohafield:"items.itemnotes", marcTag:"995", marcSubfield:"x", labelFr:"Note OPAC", labelEn:"OPAC note", type:"input", allowClear:true, copyEligible:true, normalize:"none", selector:"" }
    ];

    /* Les sources restent neutres par défaut : Auto sans source externe = comportement historique du formulaire Koha. */
    DEFAULT_FIELDS.forEach(function (field) {
        field.sourceMode = "auto";
        field.source = {
            authorisedValueCategory:"",
            authorisedValueCategoryCustom:"",
            apiEndpoint:"",
            apiArrayPath:"",
            apiValuePath:"value",
            apiLabelPath:"description",
            fallbackToForm:true,
            manualValues:[]
        };
    });

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: PAGE_DEFINITIONS.map(function (p) { return { id:p.id, path:p.path, enabled:p.enabled }; }),
        panel: {
            widthPx: 420,
            collapsedByDefault: true,
            rememberStateAndPosition: true,
            refreshOptionsMs: 5000
        },
        fields: DEFAULT_FIELDS,
        copyMajority: {
            enabled: true,
            minOccurrences: 2,
            thresholdPercent: 50,
            strictGreaterThanThreshold: true,
            rejectTies: true,
            requireExistingItems: true
        },
        presets: {
            enabled: true,
            maxPresets: 20,
            mode: "legacyNamed",
            collection: "koha_items_assistant_presets",
            rememberSelectedList: true
        },
        firebase: {
            enabled: true,
            sdkVersion: "11.5.0",
            config: DEFAULT_FIREBASE_CONFIG
        }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let configRegistered = false;
    let unsubscribeConfig = null;
    let renderTimer = null;
    let refreshTimer = null;
    let firebaseDb = null;
    let firebaseApi = null;
    let firebaseBootPromise = null;

    const sourceValueCache = new Map();
    let authorisedValueCategoryCache = [];
    let authorisedValueCategoryPromise = null;

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function deepMerge(base, incoming) {
        if (Array.isArray(base)) return Array.isArray(incoming) ? clone(incoming) : clone(base);
        if (!base || typeof base !== "object") return incoming === undefined ? base : incoming;
        const out = clone(base);
        if (!incoming || typeof incoming !== "object") return out;
        Object.keys(incoming).forEach(function (key) {
            const value = incoming[key];
            if (Array.isArray(value)) out[key] = clone(value);
            else if (value && typeof value === "object" && out[key] && typeof out[key] === "object" && !Array.isArray(out[key])) out[key] = deepMerge(out[key], value);
            else if (value !== undefined) out[key] = value;
        });
        return out;
    }

    function norm(s) {
        return String(s || "")
            .replace(/\u00a0/g, " ")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (char) {
            return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char];
        });
    }

    function getJSON(key, fallback) {
        try {
            const value = JSON.parse(localStorage.getItem(key) || "null");
            return value === null ? fallback : value;
        } catch (_) {
            return fallback;
        }
    }

    function setJSON(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const value = String(document.documentElement.lang || navigator.language || "fr").toLowerCase();
        return value.startsWith("en") ? "en" : "fr";
    }

    function tr(fr, en) {
        return language() === "en" ? (en || fr || "") : (fr || en || "");
    }

    function fieldLabel(field) {
        return tr(field && field.labelFr, field && field.labelEn) || String(field && (field.kohafield || field.id) || "");
    }

    function supportedPage() {
        return (currentConfig.pages || PAGE_DEFINITIONS).some(function (p) { return p.path === location.pathname; });
    }

    function pageEnabled() {
        if (currentConfig.enabled === false) return false;
        const page = (Array.isArray(currentConfig.pages) ? currentConfig.pages : []).find(function (p) { return p && p.path === location.pathname; });
        return !page || page.enabled !== false;
    }

    function activeFields() {
        const fields = Array.isArray(currentConfig.fields) ? currentConfig.fields : DEFAULT_FIELDS;
        return fields.filter(function (f) { return f && f.enabled !== false && (f.kohafield || f.selector); });
    }

    function dependencyValues(field) {
        return String(field && field.dependsOnValues || "").split(/[\n,;]/).map(function (value) { return norm(value); }).filter(Boolean);
    }

    function dependencySatisfied(field, values) {
        const mode = String(field && field.dependencyMode || "none");
        if (mode === "none") return true;
        const parentId = String(field && field.dependsOnFieldId || "").trim();
        if (!parentId) return false;
        const parentValue = norm(values && values[parentId]);
        if (mode === "nonempty") return !!parentValue;
        const allowed = dependencyValues(field);
        return !!parentValue && allowed.includes(parentValue);
    }

    function normalizeFieldId(value, fallbackIndex) {
        const raw = String(value || "").trim();
        if (raw) return raw;
        return "field_" + (fallbackIndex + 1);
    }

    function normalizeConfig(config) {
        const merged = deepMerge(DEFAULT_CONFIG, config || {});
        const seen = new Set();
        merged.fields = (Array.isArray(merged.fields) ? merged.fields : clone(DEFAULT_FIELDS)).map(function (f, index) {
            const base = deepMerge({
                id:"", legacyCode:"", enabled:true, kohafield:"", marcTag:"", marcSubfield:"",
                labelFr:"", labelEn:"", type:"auto", allowClear:true, copyEligible:true, normalize:"none", selector:"",
                dependencyMode:"none", dependsOnFieldId:"", dependsOnValues:"",
                sourceMode:"auto",
                source:{
                    authorisedValueCategory:"",
                    authorisedValueCategoryCustom:"",
                    apiEndpoint:"",
                    apiArrayPath:"",
                    apiValuePath:"value",
                    apiLabelPath:"description",
                    fallbackToForm:true,
                    manualValues:[]
                }
            }, f || {});
            let id = normalizeFieldId(base.id || base.legacyCode, index);
            if (seen.has(id)) {
                let n = 2;
                while (seen.has(id + "_" + n)) n++;
                id = id + "_" + n;
            }
            seen.add(id);
            base.id = id;
            if (!base.legacyCode) base.legacyCode = id;
            if (!["none","nonempty","equals"].includes(base.dependencyMode)) base.dependencyMode = "none";
            if (!["auto","form","authorised_values","koha_api","manual"].includes(base.sourceMode)) base.sourceMode = "auto";
            base.source = deepMerge({
                authorisedValueCategory:"",
                authorisedValueCategoryCustom:"",
                apiEndpoint:"",
                apiArrayPath:"",
                apiValuePath:"value",
                apiLabelPath:"description",
                fallbackToForm:true,
                manualValues:[]
            }, base.source || {});
            if (!Array.isArray(base.source.manualValues)) base.source.manualValues = [];
            return base;
        });
        merged.panel.widthPx = Math.max(300, Math.min(760, Number(merged.panel.widthPx) || 420));
        merged.panel.refreshOptionsMs = Math.max(1000, Math.min(60000, Number(merged.panel.refreshOptionsMs) || 5000));
        merged.copyMajority.minOccurrences = Math.max(1, Math.min(999, Number(merged.copyMajority.minOccurrences) || 2));
        merged.copyMajority.thresholdPercent = Math.max(0, Math.min(100, Number(merged.copyMajority.thresholdPercent) || 50));
        merged.presets.maxPresets = Math.max(1, Math.min(500, Number(merged.presets.maxPresets) || 20));
        if (!["legacyNamed","common","kohaUser"].includes(merged.presets.mode)) merged.presets.mode = "legacyNamed";
        return merged;
    }

    function currentPageId() {
        const def = (currentConfig.pages || PAGE_DEFINITIONS).find(function (p) { return p.path === location.pathname; });
        return def ? def.id : "";
    }

    function waitForBody() {
        return new Promise(function (resolve) {
            if (document.body) return resolve();
            const timer = setInterval(function () {
                if (document.body) {
                    clearInterval(timer);
                    resolve();
                }
            }, 100);
        });
    }

    const ensureStyle = () => {
        if (document.getElementById("koha_items_assistant_style"))
            return;
        const s = document.createElement("style");
        s.id = "koha_items_assistant_style";
        s.textContent = `
        #${PANEL_ID}{
            position:fixed;z-index:999999;
            background:#ffffff;border:1px solid #dfe6df;border-radius:14px;
            box-shadow:0 14px 42px rgba(24,39,27,.16),0 3px 10px rgba(20,20,40,.07);
            width:420px;font:12.5px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
            color:#1f2430;overflow:hidden;user-select:none;
        }
        #${PANEL_ID} *{box-sizing:border-box;user-select:text}
        #${PANEL_ID}.collapsed .body{display:none}
        #${PANEL_ID} .head{
            display:flex;justify-content:space-between;align-items:center;gap:8px;
            padding:11px 12px;cursor:move;font-weight:700;font-size:13px;
            background:linear-gradient(135deg,#3f8340 0%,#438d43 100%);color:#fff;
            letter-spacing:.2px;border-bottom:1px solid rgba(0,0,0,.08);
        }
        #${PANEL_ID} .head .title{display:flex;align-items:center;gap:8px;font-size:13.5px}
        #${PANEL_ID} .head .subtitle{
            display:inline-block;font-size:10.5px;font-weight:500;color:rgba(255,255,255,.94);
            margin-left:22px;margin-top:3px;letter-spacing:0;
            background:rgba(255,255,255,.12);padding:1px 6px;border-radius:999px;
        }
        #${PANEL_ID} .head .subtitle:empty{display:none}
        #${PANEL_ID} .head-btns{display:flex;gap:4px}
        #${PANEL_ID} .head-btns button{
            background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.08);color:#fff;width:24px;height:24px;
            border-radius:7px;cursor:pointer;font-size:13px;line-height:1;
            display:flex;align-items:center;justify-content:center;transition:background .15s,border-color .15s;
        }
        #${PANEL_ID} .head-btns button:hover{background:rgba(255,255,255,.30);border-color:rgba(255,255,255,.18)}
        #${PANEL_ID} .body{
            padding:10px 12px 12px;max-height:78vh;overflow-y:auto;overflow-x:hidden;
            background:linear-gradient(180deg,#ffffff 0%,#fbfcfb 100%);
            scrollbar-width:thin;scrollbar-color:#cfd8d0 transparent;
        }
        #${PANEL_ID} .body > *,#${PANEL_ID} .actions,#${PANEL_ID} .preset-list,#${PANEL_ID} .preset-controls{max-width:100%;min-width:0}
        #${PANEL_ID} .row{
            margin:0 0 5px;
            display:flex;
            align-items:center;
            gap:8px;
            flex-wrap:nowrap;
        }
        #${PANEL_ID} .row label{
            font-weight:700;color:#566258;font-size:10.5px;
            text-transform:uppercase;letter-spacing:.42px;
            white-space:nowrap;
            flex:0 0 110px;
            min-width:80px;
        }
        #${PANEL_ID} .row .combo-wrap{
            position:relative;
            flex:1 1 auto;
            min-width:0;
        }
        #${PANEL_ID} .clear-checkbox{
            display:flex;
            align-items:center;
            gap:5px;
            font-size:10px;
            color:#7b837c;
            cursor:pointer;
            padding:0 3px;
            white-space:nowrap;
            flex:0 0 64px;
            justify-content:flex-end;
            box-sizing:border-box;
        }
        #${PANEL_ID} .row .clear-checkbox input[type="checkbox"]{
            margin:0;
            cursor:pointer;
            width:13px;
            height:13px;
            flex-shrink:0;
            accent-color:#408540;
        }
        #${PANEL_ID} .combo-wrap{position:relative;flex:1 1 auto;min-width:0}
        #${PANEL_ID} .combo-input{
            width:100%;padding:5.5px 34px 5.5px 8px;border:1.3px solid #d7dfd8;border-radius:8px;
            font:inherit;background:#fff;transition:border-color .15s,background .15s,box-shadow .15s;
            font-size:12px;color:#1f2430;box-shadow:0 1px 1px rgba(20,35,22,.02);
        }
        #${PANEL_ID} .combo-input::placeholder{
            color:#87908a;
            opacity:1;
        }
        #${PANEL_ID} .combo-input:hover:not(:disabled){border-color:#c4cec5}
        #${PANEL_ID} .combo-input:focus{
            outline:none;border-color:#4b924c;background:#fff;
            box-shadow:0 0 0 2px rgba(64,133,64,.12);
        }
        #${PANEL_ID} .combo-input:disabled{background:#f0f2f0;color:#9aa1a0;cursor:not-allowed}
        #${PANEL_ID} select.combo-input:has(option:checked:not([value=""])),
        #${PANEL_ID} input.combo-input:not(:placeholder-shown){
            background:#fbfefb;border-color:#c8d8c9;
        }
        #${PANEL_ID} .combo-clear{
            position:absolute;right:7px;top:50%;transform:translateY(-50%);
            border:none;background:transparent;color:#8f9891;cursor:pointer;font-size:14px;
            width:23px;height:23px;border-radius:999px;display:flex;align-items:center;justify-content:center;
            opacity:.38;transition:opacity .15s,background .15s,color .15s;
        }
        #${PANEL_ID} .combo-wrap:hover .combo-clear,#${PANEL_ID} .combo-clear:focus{opacity:.85}
        #${PANEL_ID} .combo-clear:hover{background:#eef1ee;color:#4d5850;opacity:1}
        #${PANEL_ID} .combo-menu{
            position:absolute;left:0;right:0;top:calc(100% + 4px);background:#fff;
            border:1px solid #dbe0e8;border-radius:9px;box-shadow:0 8px 24px rgba(20,20,40,.16);
            max-height:180px;overflow-y:auto;z-index:10;display:none;
        }
        #${PANEL_ID} .combo-item{padding:5px 10px;cursor:pointer;font-size:12px;display:flex;flex-direction:column;gap:2px}
        #${PANEL_ID} .combo-item:hover,#${PANEL_ID} .combo-item.active{background:#e9f5ea;color:#408540}
        #${PANEL_ID} .combo-item-label{font-size:12px;color:#1f2430}
        #${PANEL_ID} .combo-empty{padding:6px 10px;color:#9aa1b3;font-style:italic}
        #${PANEL_ID} .actions{
            display:flex;gap:6px;margin-top:9px;padding-top:9px;flex-wrap:wrap;
            border-top:1px solid #e8ece8;
        }
        #${PANEL_ID} .actions button{
            flex:1 1 0;padding:6.5px 7px;cursor:pointer;font:inherit;font-weight:700;border-radius:8px;
            border:1px solid transparent;transition:filter .15s,background .15s,border-color .15s,box-shadow .15s,transform .08s;
            font-size:11.5px;min-width:0;max-width:100%;white-space:normal;line-height:1.15;text-align:center;
            min-height:38px;display:flex;align-items:center;justify-content:center;
        }
        #${PANEL_ID} .actions button:active{transform:translateY(1px)}
        #${PANEL_ID} .btn-primary{
            background:#408540;color:#fff;border-color:#397a39;
            box-shadow:0 2px 5px rgba(64,133,64,.20);
        }
        #${PANEL_ID} .btn-primary:hover{filter:brightness(1.06);box-shadow:0 3px 7px rgba(64,133,64,.24)}
        #${PANEL_ID} .btn-secondary{background:#eef7ef;color:#347336;border-color:#d8ead9}
        #${PANEL_ID} .btn-secondary:hover{background:#e4f2e5;border-color:#c8e1ca}
        #${PANEL_ID} .btn-ghost{background:#f5f6f5;color:#646d66;border-color:#e8ebe8}
        #${PANEL_ID} .btn-ghost:hover{background:#ecefec;border-color:#dce1dc}
        #${PANEL_ID} .btn-copy{background:#edf5fa;color:#246f9b;border-color:#d9e9f3}
        #${PANEL_ID} .btn-copy:hover{background:#dfedf6;border-color:#c8deeb}
        #${PANEL_ID} .status{
            font-size:10.5px;color:#536056;margin-top:7px;white-space:pre-wrap;line-height:1.45;
            background:#f7f9f7;border-radius:8px;padding:7px 9px;border:1px solid #e5eae5;
            border-left:3px solid #a9baa9;max-height:100px;overflow-y:auto;
        }
        #${PANEL_ID} .status:empty{display:none}
        #${PANEL_ID} .divider{border:none;border-top:1px solid #e3e8e3;margin:10px 0 8px}
        #${PANEL_ID} .presets-title{
            font-weight:800;font-size:10.5px;text-transform:uppercase;letter-spacing:.55px;
            color:#566258;margin-bottom:5px;display:flex;justify-content:space-between;align-items:center;
        }
        #${PANEL_ID} .presets-count{
            color:#7d887f;font-weight:700;text-transform:none;letter-spacing:0;
            background:#eef2ee;border:1px solid #e2e7e2;border-radius:999px;padding:1px 6px;
        }
        #${PANEL_ID} .presets-actions{display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:6px}
        #${PANEL_ID} .presets-actions .note-presets{font-size:10px;color:#7a837c;flex:1;}
        #${PANEL_ID} .btn-small{padding:4px 8px;font-size:10.5px;border-radius:7px;}
        #${PANEL_ID} .preset-controls{
            padding:7px 7px 1px;margin-bottom:6px;display:none;
            background:#f7f9f7;border:1px solid #e8ece8;border-radius:8px;
        }
        #${PANEL_ID} .preset-controls.open{display:block}
        #${PANEL_ID} .preset-controls .row{margin:0 0 7px;min-width:0}
        #${PANEL_ID} .preset-controls .row > div{flex:1 1 auto;min-width:0;max-width:100%}
        #${PANEL_ID} .preset-list{display:flex;flex-direction:column;gap:5px;max-height:132px;overflow-y:auto;padding-right:2px}
        #${PANEL_ID} .preset-item{
            display:flex;align-items:center;gap:6px;background:#fff;border:1px solid #e3e8e3;
            border-radius:8px;padding:6px 7px;cursor:pointer;transition:background .15s,border-color .15s,box-shadow .15s;
        }
        #${PANEL_ID} .preset-item:hover{
            background:#f7fcf7;border-color:#bed8c0;box-shadow:0 1px 3px rgba(64,133,64,.07);
        }
        #${PANEL_ID} .preset-text{flex:1;min-width:0;font-size:11px;color:#1f2430;line-height:1.25}
        #${PANEL_ID} .preset-text b{
            display:block;color:#397c3b;font-size:11.5px;font-weight:800;margin-bottom:2px;
            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
        }
        #${PANEL_ID} .preset-fields{
            display:block;color:#737d75;font-size:10px;line-height:1.3;
            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
        }
        #${PANEL_ID} .preset-del{
            border:none;background:transparent;color:#b0b8b1;cursor:pointer;font-size:13px;
            width:20px;height:20px;border-radius:6px;flex-shrink:0;display:flex;align-items:center;justify-content:center;
        }
        #${PANEL_ID} .preset-del:hover{background:#ffe8e8;color:#d9473f}
        #${PANEL_ID} .preset-empty{color:#919991;font-style:italic;font-size:10.5px;padding:5px 2px}
        #${PANEL_ID} .field-modified {
            border-color:#2a7a2a !important;
            background:#eaf6ea !important;
            box-shadow:0 0 0 2px rgba(42,122,42,.20) !important;
            transition:all .3s;
        }
        #${PANEL_ID} .field-modified-highlight {
            animation:flash-green 1.5s ease 3;
        }
        @keyframes flash-green {
            0%,100%{background:#eaf6ea;border-color:#2a7a2a}
            50%{background:#d2edd3;border-color:#1b5e1b}
        }
        #${PANEL_ID} .row .combo-input.text-input{
            background:#fff;border-color:#d7dfd8;
        }
        #${PANEL_ID} .row .combo-input.text-input:focus{
            background:#fff;border-color:#4b924c;
        }
        /* Styles uniques pour les modaux de l'assistant - complètement isolés de Koha */
        #${PANEL_ID}_modal_backdrop {
            position:fixed;
            inset:0;
            background:rgba(2,6,23,.72);
            z-index:2147483646;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:24px;
            box-sizing:border-box;
            font-family:Arial,Helvetica,sans-serif;
            pointer-events:auto;
        }
        #${PANEL_ID}_modal_content {
            background:white;
            padding:22px;
            border-radius:15px;
            box-shadow:0 24px 70px rgba(0,0,0,.35);
            z-index:2147483647;
            max-width:min(92vw,560px);
            max-height:min(84vh,760px);
            overflow-y:auto;
            width:100%;
            box-sizing:border-box;
            border:1px solid #dfe6df;
            isolation:isolate;
            transform:translateZ(0);
        }
        #${PANEL_ID}_modal_content h3 {
            margin:0 0 10px;
            color:#26332a;
            font-size:16px;
        }
        #${PANEL_ID}_modal_content ul {
            list-style:none;
            padding:0;
            margin:12px 0;
            border:1px solid #edf0ed;border-radius:9px;overflow:hidden;
        }
        #${PANEL_ID}_modal_content ul li {
            padding:7px 9px;
            border-bottom:1px solid #f0f2f0;
            font-size:12.5px;
            background:#fff;
        }
        #${PANEL_ID}_modal_content ul li:last-child{border-bottom:none}
        #${PANEL_ID}_modal_content ul li strong {
            color:#408540;
        }
        #${PANEL_ID}_modal_content .modal-actions {
            display:flex;
            gap:8px;
            margin-top:15px;
            justify-content:flex-end;
        }
        #${PANEL_ID}_modal_content .modal-actions button {
            padding:8px 18px;
            border-radius:8px;
            border:1px solid #dbe0e8;
            cursor:pointer;
            font-weight:700;
            font-size:12.5px;
        }
        #${PANEL_ID}_modal_content .modal-actions .btn-confirm {
            background:#408540;
            color:white;
            border-color:#397a39;
            box-shadow:0 2px 5px rgba(64,133,64,.16);
        }
        #${PANEL_ID}_modal_content .modal-actions .btn-confirm:hover {
            filter:brightness(1.06);
        }
        #${PANEL_ID}_modal_content .modal-actions .btn-cancel {
            background:#f4f6f4;
            color:#5a665d;
            border-color:#e3e7e3;
        }
        #${PANEL_ID}_modal_content .modal-actions .btn-cancel:hover {
            background:#ebefeb;
        }
        #${PANEL_ID}_modal_content .modal-note {
            font-size:11px;
            color:#69736b;
            margin-top:10px;
            padding:8px 9px;
            background:#f7f9f7;
            border:1px solid #e7ebe7;
            border-radius:7px;
        }
        #${PANEL_ID}_modal_content .preset-name-input {
            width:100%;
            padding:8px 11px;
            border:1.3px solid #d7dfd8;
            border-radius:8px;
            font-size:13px;
            margin:8px 0;
        }
        #${PANEL_ID}_modal_content .preset-name-input:focus {
            outline:none;
            border-color:#4b924c;
            box-shadow:0 0 0 2px rgba(64,133,64,.12);
        }
`;
        document.head.appendChild(s);
    };

    function ensureResponsiveStyle() {
        if (document.getElementById("koha_items_assistant_responsive_style")) return;
        const style = document.createElement("style");
        style.id = "koha_items_assistant_responsive_style";
        style.textContent = `
            #${PANEL_ID}{max-width:calc(100vw - 24px)}
            #${PANEL_ID} .pmk110-config-anchor{display:inline-flex;align-items:center;justify-content:center;min-width:0}
            @media (max-width: 576px){
                #${PANEL_ID}{left:8px !important;right:8px !important;top:58px !important;width:auto !important;max-width:none}
                #${PANEL_ID} .body{max-height:calc(100vh - 115px)}
                #${PANEL_ID} .row{flex-wrap:wrap}
                #${PANEL_ID} .row label{flex:1 0 100%;min-width:0}
                #${PANEL_ID} .clear-checkbox{flex:0 0 auto}
            }
        `;
        document.head.appendChild(style);
    }

    function cssEscapeValue(value) {
        const raw = String(value == null ? "" : value);
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(raw);
        return raw.replace(/([\"'\\.#[\]:(),>+~*= ])/g, "\\$1");
    }

    function selectorCandidates(field) {
        const list = [];
        const custom = String(field && field.selector || "").trim();
        if (custom) list.push(custom);
        const kohafield = String(field && field.kohafield || "").trim();
        if (kohafield) {
            const escaped = cssEscapeValue(kohafield);
            list.push(`[name="${escaped}"]`);
            if (kohafield.startsWith("items.")) {
                const bare = kohafield.slice(6);
                const escapedBare = cssEscapeValue(bare);
                list.push(`[name="${escapedBare}"]`, `[name="items[${escapedBare}]"]`);
            }
        }
        return Array.from(new Set(list));
    }

    function getFieldElement(field) {
        if (!field) return null;
        const candidates = selectorCandidates(field);
        for (const selector of candidates) {
            let matches = [];
            try {
                matches = Array.from(document.querySelectorAll(selector)).filter(function (el) {
                    return el && el.type !== "hidden" && !el.closest("#" + PANEL_ID);
                });
            } catch (_) {}
            if (matches.length === 1) return matches[0];
            if (matches.length > 1) {
                const visible = matches.filter(function (el) { return el.offsetParent !== null || el.getClientRects().length > 0; });
                if (visible.length === 1) return visible[0];
                const enabled = visible.find(function (el) { return !el.disabled; });
                if (enabled) return enabled;
            }
        }
        return null;
    }

    async function findFieldElementWithRetry(field, attempt) {
        attempt = attempt || 0;
        const el = getFieldElement(field);
        if (el || attempt >= 8) return el;
        await new Promise(function (resolve) { setTimeout(resolve, 180); });
        return findFieldElementWithRetry(field, attempt + 1);
    }

    function fieldType(field, el) {
        if (el) {
            if (el.tagName === "SELECT") return "select";
            if (el.tagName === "TEXTAREA") return "input";
            if (el.tagName === "INPUT") return "input";
        }
        return field && field.type === "select" ? "select" : "input";
    }

    function getFieldValue(el) {
        return el && "value" in el ? String(el.value || "") : "";
    }

    function getSelectOptions(el) {
        if (!el || el.tagName !== "SELECT") return [];
        return Array.from(el.options || []).map(function (opt) {
            return { value:String(opt.value || ""), label:String(opt.textContent || "").trim() };
        });
    }

    function getPathValue(object, path) {
        const cleanPath = String(path || "").trim();
        if (!cleanPath) return object;
        return cleanPath.split(".").reduce(function (value, key) {
            if (value == null) return undefined;
            return value[key];
        }, object);
    }

    function uniqueOptions(options) {
        const result = [];
        const seen = new Set();
        (Array.isArray(options) ? options : []).forEach(function (option) {
            if (!option) return;
            const value = String(option.value == null ? "" : option.value);
            const label = String(option.label == null ? value : option.label).trim();
            const key = value + "\u0000" + label;
            if (seen.has(key)) return;
            seen.add(key);
            result.push({ value:value, label:label });
        });
        return result;
    }

    async function kohaApiFetch(endpoint) {
        const raw = String(endpoint || "").trim();
        if (!raw) throw new Error("missing_endpoint");
        const url = new URL(raw, window.location.origin);
        if (url.origin !== window.location.origin || !url.pathname.startsWith("/api/v1/")) {
            throw new Error("invalid_koha_api_endpoint");
        }
        const response = await fetch(url.href, {
            method: "GET",
            credentials: "same-origin",
            headers: { "Accept":"application/json" }
        });
        if (!response.ok) throw new Error("koha_api_" + response.status);
        return response.json();
    }

    function effectiveAuthorisedValueCategory(field) {
        const source = field && field.source || {};
        const selected = String(source.authorisedValueCategory || "").trim();
        if (selected === "__custom__") return String(source.authorisedValueCategoryCustom || "").trim();
        return selected;
    }

    function manualOptions(field) {
        const values = field && field.source && Array.isArray(field.source.manualValues)
            ? field.source.manualValues
            : [];
        return uniqueOptions(values.filter(function (item) {
            return item && item.enabled !== false && String(item.value || "").trim() !== "";
        }).map(function (item) {
            const value = String(item.value || "").trim();
            return {
                value:value,
                label:tr(String(item.labelFr || value), String(item.labelEn || item.labelFr || value))
            };
        }));
    }

    async function loadAuthorisedValueCategories(force) {
        if (!force && authorisedValueCategoryCache.length) return authorisedValueCategoryCache.slice();
        if (!force && authorisedValueCategoryPromise) return authorisedValueCategoryPromise;
        authorisedValueCategoryPromise = (async function () {
            try {
                const data = await kohaApiFetch("/api/v1/authorised_value_categories?_per_page=1000&_order_by=%2Bcategory_name");
                const categories = (Array.isArray(data) ? data : []).map(function (item) {
                    return String(item && (item.category_name || item.name) || "").trim();
                }).filter(Boolean);
                authorisedValueCategoryCache = Array.from(new Set(categories)).sort(function (a,b) {
                    return a.localeCompare(b, language());
                });
            } catch (_) {
                authorisedValueCategoryCache = [];
            } finally {
                authorisedValueCategoryPromise = null;
            }
            return authorisedValueCategoryCache.slice();
        })();
        return authorisedValueCategoryPromise;
    }

    function fieldFromConfigPath(rootObject, fieldPath) {
        if (!rootObject || !Array.isArray(fieldPath)) return null;
        const idx = fieldPath.indexOf("fields");
        if (idx < 0) return null;
        const index = Number(fieldPath[idx + 1]);
        if (!Number.isInteger(index)) return null;
        return Array.isArray(rootObject.fields) ? rootObject.fields[index] || null : null;
    }

    function authorisedValueCategoryOptions(rootObject, fieldPath) {
        const currentField = fieldFromConfigPath(rootObject, fieldPath);
        const current = currentField ? String(currentField.source && currentField.source.authorisedValueCategory || "") : "";
        const options = [{ value:"", label:{ fr:"— Aucune catégorie —", en:"— No category —" } }];
        const names = authorisedValueCategoryCache.slice();
        if (current && current !== "__custom__" && !names.includes(current)) names.push(current);
        names.sort(function (a,b) { return a.localeCompare(b, language()); });
        names.forEach(function (name) {
            options.push({ value:name, label:{ fr:name, en:name } });
        });
        options.push({ value:"__custom__", label:{ fr:"Autre catégorie / saisie manuelle…", en:"Other category / manual entry…" } });
        return options;
    }

    async function loadAuthorisedValueOptions(field) {
        const category = effectiveAuthorisedValueCategory(field);
        if (!category) throw new Error("missing_authorised_value_category");
        const key = "av:" + category;
        if (sourceValueCache.has(key)) return clone(sourceValueCache.get(key));
        const endpoint = "/api/v1/authorised_value_categories/" +
            encodeURIComponent(category) + "/authorised_values?_per_page=1000&_order_by=%2Bdescription";
        const data = await kohaApiFetch(endpoint);
        const options = uniqueOptions((Array.isArray(data) ? data : []).map(function (item) {
            const value = String(item && item.value != null ? item.value : "").trim();
            const description = String(item && (item.description || item.opac_description || item.value) || "").trim();
            return value ? { value:value, label:description || value } : null;
        }).filter(Boolean));
        sourceValueCache.set(key, clone(options));
        return options;
    }

    async function loadGenericApiOptions(field) {
        const source = field && field.source || {};
        const endpoint = String(source.apiEndpoint || "").trim();
        if (!endpoint) throw new Error("missing_api_endpoint");
        const key = "api:" + endpoint + "|" + String(source.apiArrayPath || "") + "|" +
            String(source.apiValuePath || "") + "|" + String(source.apiLabelPath || "");
        if (sourceValueCache.has(key)) return clone(sourceValueCache.get(key));
        const payload = await kohaApiFetch(endpoint);
        const list = source.apiArrayPath ? getPathValue(payload, source.apiArrayPath) : payload;
        if (!Array.isArray(list)) throw new Error("api_result_is_not_array");
        const valuePath = String(source.apiValuePath || "value").trim();
        const labelPath = String(source.apiLabelPath || source.apiValuePath || "description").trim();
        const options = uniqueOptions(list.map(function (item) {
            const rawValue = getPathValue(item, valuePath);
            const rawLabel = getPathValue(item, labelPath);
            if (rawValue == null || String(rawValue).trim() === "") return null;
            return {
                value:String(rawValue).trim(),
                label:String(rawLabel == null || rawLabel === "" ? rawValue : rawLabel).trim()
            };
        }).filter(Boolean));
        sourceValueCache.set(key, clone(options));
        return options;
    }

    function fieldHasConfiguredListSource(field) {
        if (!field) return false;
        const mode = String(field.sourceMode || "auto");
        const source = field.source || {};
        if (mode === "manual" || mode === "authorised_values" || mode === "koha_api") return true;
        if (mode !== "auto") return false;
        return !!(
            effectiveAuthorisedValueCategory(field) ||
            String(source.apiEndpoint || "").trim() ||
            (Array.isArray(source.manualValues) && source.manualValues.some(function (item) {
                return item && item.enabled !== false && String(item.value || "").trim() !== "";
            }))
        );
    }

    async function loadFieldOptions(field, formElement) {
        const mode = String(field && field.sourceMode || "auto");
        const source = field && field.source || {};
        const formOptions = getSelectOptions(formElement);
        const fallback = source.fallbackToForm !== false;

        if (mode === "form") return formOptions;
        if (mode === "manual") {
            const list = manualOptions(field);
            return list.length || !fallback ? list : formOptions;
        }
        if (mode === "authorised_values") {
            try {
                const list = await loadAuthorisedValueOptions(field);
                return list.length || !fallback ? list : formOptions;
            } catch (_) {
                return fallback ? formOptions : [];
            }
        }
        if (mode === "koha_api") {
            try {
                const list = await loadGenericApiOptions(field);
                return list.length || !fallback ? list : formOptions;
            } catch (_) {
                return fallback ? formOptions : [];
            }
        }

        /* Auto : VA explicite > API explicite > valeurs manuelles > formulaire Koha. */
        if (effectiveAuthorisedValueCategory(field)) {
            try {
                const list = await loadAuthorisedValueOptions(field);
                if (list.length) return list;
            } catch (_) {}
        }
        if (String(source.apiEndpoint || "").trim()) {
            try {
                const list = await loadGenericApiOptions(field);
                if (list.length) return list;
            } catch (_) {}
        }
        const manual = manualOptions(field);
        if (manual.length) return manual;
        return formOptions;
    }

    function triggerNativeAndJQuery(element) {
        if (!element) return;
        const dispatch = function () {
            try { element.dispatchEvent(new Event("input", { bubbles:true })); } catch (_) {}
            try { element.dispatchEvent(new Event("change", { bubbles:true })); } catch (_) {}
            if (window.jQuery) {
                try {
                    const $el = window.jQuery(element);
                    $el.trigger("input");
                    $el.trigger("change");
                    if ($el.data("select2")) $el.trigger("change.select2");
                } catch (_) {}
            }
        };
        dispatch();
        setTimeout(dispatch, 40);
    }

    function normalizeFieldValue(field, value) {
        let result = String(value == null ? "" : value).trim();
        if (field && field.normalize === "price") result = result.replace(/,/g, ".");
        return result;
    }

    function resolveSelectOptionValue(selectEl, targetValue) {
        if (!selectEl || selectEl.tagName !== "SELECT") return null;
        const wanted = norm(targetValue);
        const match = Array.from(selectEl.options || []).find(function (opt) {
            return norm(opt.value) === wanted || norm(opt.textContent) === wanted;
        });
        return match ? String(match.value) : null;
    }

    function setFieldValue(field, el, value) {
        if (!el) return false;
        const clean = normalizeFieldValue(field, value);
        if (el.tagName === "SELECT") {
            const resolved = resolveSelectOptionValue(el, clean);
            if (resolved === null) return false;
            Array.from(el.options || []).forEach(function (opt) { opt.selected = String(opt.value) === resolved; });
            el.value = resolved;
        } else {
            el.value = clean;
        }
        triggerNativeAndJQuery(el);
        return true;
    }

    function subfieldRow(el) {
        return el && el.closest ? el.closest(".subfield_line") : null;
    }

    function isFieldMandatory(el) {
        const row = subfieldRow(el);
        if (!row) return false;
        const mandatory = row.querySelector('input[name="mandatory"]');
        return !!mandatory && String(mandatory.value) === "1";
    }

    function isBatchModPage() {
        return currentPageId() === "tools.batchmod" || /\/cgi-bin\/koha\/tools\/batchMod\.pl/i.test(location.pathname);
    }

    function isAddItemPage() {
        return currentPageId() === "cataloguing.additem" || /\/cgi-bin\/koha\/cataloguing\/additem\.pl/i.test(location.pathname);
    }

    function findNativeBatchClearCheckbox(el) {
        if (!el || !isBatchModPage()) return null;
        const fieldName = String(el.getAttribute("name") || el.name || "");
        if (!fieldName) return null;
        const form = el.closest("form") || document.querySelector("form");
        if (!form) return null;
        const boxes = Array.from(form.querySelectorAll('input[type="checkbox"][name="disable_input"]'));
        return boxes.find(function (cb) {
            const v = String(cb.value || "");
            return v === fieldName || norm(v) === norm(fieldName);
        }) || null;
    }

    function canClearField(field, el) {
        if (!field || field.allowClear === false || !el) return false;
        if (isBatchModPage()) return !!findNativeBatchClearCheckbox(el);
        if (isFieldMandatory(el)) return false;
        if (el.tagName === "SELECT") return Array.from(el.options || []).some(function (o) { return String(o.value) === ""; });
        return !el.readOnly && !el.disabled;
    }

    function setBatchModClearFlag(el, shouldClear) {
        const checkbox = findNativeBatchClearCheckbox(el);
        if (!checkbox) return false;
        if (checkbox.checked !== !!shouldClear) {
            try { checkbox.click(); } catch (_) {
                checkbox.checked = !!shouldClear;
                try { checkbox.dispatchEvent(new Event("change", { bubbles:true })); } catch (_) {}
            }
        }
        /* Le 031 peut demander une confirmation asynchrone : le clic natif a bien été transmis à Koha. */
        return true;
    }

    function clearFieldThroughKoha(field, el) {
        if (!field || !el || field.allowClear === false) return false;
        if (isBatchModPage()) return setBatchModClearFlag(el, true);
        if (!canClearField(field, el)) return false;
        if (el.tagName === "SELECT") {
            const blank = Array.from(el.options || []).find(function (o) { return String(o.value) === ""; });
            if (!blank) return false;
            el.value = "";
        } else {
            el.value = "";
        }
        triggerNativeAndJQuery(el);
        return true;
    }

    function cancelKohaClear(field, el) {
        if (!field || !el) return;
        if (isBatchModPage()) {
            const checkbox = findNativeBatchClearCheckbox(el);
            if (checkbox && checkbox.checked) {
                try { checkbox.click(); } catch (_) { checkbox.checked = false; }
            }
        }
    }

    function tableFieldMatch(source, field, allowText) {
        if (!source || !field) return false;
        const col = String(source.dataset && source.dataset.colname || source.getAttribute && source.getAttribute("data-colname") || "");
        const text = String(source.textContent || "").trim();
        const kohafield = String(field.kohafield || "");
        const bare = kohafield.startsWith("items.") ? kohafield.slice(6) : kohafield;
        const candidates = [field.id, field.legacyCode, kohafield, bare, field.marcSubfield].filter(Boolean).map(norm);
        if (col && candidates.includes(norm(col))) return true;
        if (allowText) {
            const labels = [field.labelFr, field.labelEn, bare, kohafield].filter(Boolean).map(norm);
            if (text && labels.includes(norm(text))) return true;
        }
        return false;
    }

    function fieldForSource(source, allowText) {
        return activeFields().find(function (field) { return field.copyEligible !== false && tableFieldMatch(source, field, allowText); }) || null;
    }

    function getItemValuesFromTableRow(row) {
        const values = {};
        const headers = Array.from(document.querySelectorAll("#itemst thead th"));
        Array.from(row.querySelectorAll("td")).forEach(function (cell, index) {
            const text = String(cell.textContent || "").trim();
            if (!text || cell.querySelector('input[type="checkbox"]') || cell.querySelector(".btn-group")) return;
            const field = fieldForSource(headers[index], true) || fieldForSource(cell, false);
            if (field) values[field.id] = text;
        });
        return values;
    }

    function getExistingItems() {
        const table = document.querySelector("#itemst");
        if (!table) return [];
        return Array.from(table.querySelectorAll("tbody tr")).map(getItemValuesFromTableRow).filter(function (v) { return Object.keys(v).length > 0; });
    }

    function computeMostCommonValues(items) {
        const result = {};
        const countsByField = {};
        activeFields().forEach(function (field) {
            if (field.copyEligible !== false) countsByField[field.id] = {};
        });
        items.forEach(function (item) {
            Object.entries(item).forEach(function (entry) {
                const id = entry[0], value = String(entry[1] || "").trim();
                if (!value || !countsByField[id]) return;
                countsByField[id][value] = (countsByField[id][value] || 0) + 1;
            });
        });
        const cfg = currentConfig.copyMajority || {};
        const minOccurrences = Math.max(1, Number(cfg.minOccurrences) || 2);
        const threshold = Math.max(0, Math.min(100, Number(cfg.thresholdPercent) || 50));
        Object.entries(countsByField).forEach(function (entry) {
            const id = entry[0], counts = entry[1];
            let max = 0, best = "", tied = false;
            Object.entries(counts).forEach(function (pair) {
                const value = pair[0], count = pair[1];
                if (count > max) { max = count; best = value; tied = false; }
                else if (count === max && count > 0) tied = true;
            });
            if (!best || max < minOccurrences) return;
            if (cfg.rejectTies !== false && tied) return;
            const percent = items.length ? (max * 100 / items.length) : 0;
            const thresholdOk = cfg.strictGreaterThanThreshold !== false ? percent > threshold : percent >= threshold;
            if (thresholdOk) result[id] = best;
        });
        return result;
    }

    function makeCombo(row, field, options, isInput, showClearCheckbox) {
        const placeholder = isInput ? fieldLabel(field) : tr("Rechercher ", "Search ") + fieldLabel(field) + "…";
        const normalOptions = Array.isArray(options) ? options.map(function (o) { return Object.assign({}, o); }) : [];
        const hasEmpty = normalOptions.some(function (o) { return String(o.value) === ""; });
        row.innerHTML = `
            <div class="combo-wrap">
                ${isInput
                    ? `<input type="text" class="combo-input text-input" placeholder="${escapeHTML(placeholder)}" autocomplete="off">`
                    : `<select class="combo-input">${!hasEmpty ? `<option value="">${escapeHTML(placeholder)}</option>` : ""}${normalOptions.map(function (o) { return `<option value="${escapeHTML(o.value)}">${escapeHTML(o.label || o.value)}</option>`; }).join("")}</select>`}
                <button type="button" class="combo-clear" tabindex="-1" title="${escapeHTML(tr("Vider le champ du panneau", "Clear the panel field"))}">×</button>
            </div>
            ${showClearCheckbox ? `<label class="clear-checkbox" title="${escapeHTML(tr("Cocher pour demander à Koha d’effacer ce champ lors de l’application", "Check to ask Koha to clear this field when applying"))}"><input type="checkbox" class="clear-checkbox-input"><span>${escapeHTML(tr("Vider", "Clear"))}</span></label>` : ""}
        `;
        const input = row.querySelector(".combo-input");
        const clearBtn = row.querySelector(".combo-clear");
        const clearCheckbox = row.querySelector(".clear-checkbox-input");
        let value = "";
        let onChangeCb = function () {};

        function updateSelectValue(newValue, silent) {
            const wanted = norm(newValue);
            const options = Array.from(input.options || []);
            const match = options.find(function (opt) { return norm(opt.value) === wanted || norm(opt.textContent) === wanted; });
            if (match) {
                input.value = match.value;
                value = String(match.value || "");
            } else if (!wanted) {
                const blank = options.find(function (opt) { return String(opt.value) === ""; });
                if (blank) { input.value = ""; value = ""; }
            }
            if (!silent) onChangeCb(value);
        }

        if (isInput) {
            input.addEventListener("input", function () { value = input.value; onChangeCb(value); });
        } else {
            input.addEventListener("change", function () { value = input.value || ""; onChangeCb(value); });
        }
        clearBtn.addEventListener("click", function () {
            if (input.disabled) return;
            value = "";
            input.value = "";
            onChangeCb(value);
            input.focus();
        });

        return {
            setItems: function (items) {
                if (!input || input.tagName !== "SELECT") return;
                const existing = input.value;
                const list = Array.isArray(items) ? items : [];
                const empty = list.some(function (o) { return String(o.value) === ""; });
                input.innerHTML = (!empty ? `<option value="">${escapeHTML(placeholder)}</option>` : "") + list.map(function (o) { return `<option value="${escapeHTML(o.value)}">${escapeHTML(o.label || o.value)}</option>`; }).join("");
                if (existing && Array.from(input.options).some(function (o) { return String(o.value) === String(existing); })) input.value = existing;
            },
            setValue: function (newValue, silent) {
                value = String(newValue == null ? "" : newValue);
                if (input.tagName === "SELECT") updateSelectValue(value, silent);
                else { input.value = value; if (!silent) onChangeCb(value); }
            },
            getValue: function () { return value; },
            setDisabled: function (disabled, reason) {
                input.disabled = !!disabled;
                clearBtn.disabled = !!disabled;
                row.classList.toggle("pmk110-dependency-disabled", !!disabled);
                row.title = disabled ? String(reason || tr("Dépendance non satisfaite", "Dependency not satisfied")) : "";
            },
            onChange: function (fn) { onChangeCb = typeof fn === "function" ? fn : function () {}; },
            getClearFlag: function () { return !!(clearCheckbox && clearCheckbox.checked); },
            setClearFlag: function (checked) { if (clearCheckbox) clearCheckbox.checked = !!checked; }
        };
    }

    function canConfigure() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === "function") {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }
        const el = document.querySelector('#logged-in-info-full .loggedinusername[data-loggedinusername], .loggedinusername[data-loggedinusername]');
        if (!el) return false;
        return el.dataset.isSuperlibrarian === "is_superlibrarian" || el.classList.contains("is_superlibrarian");
    }

    function mountContextButton(root) {
        if (!root || !canConfigure() || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = root.querySelector(".pmk110-config-anchor");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "item-entry-assistant",
                context: { pageId: currentPageId(), sectionId: "fields" }
            });
        } catch (_) {}
    }

    function readLoggedInUsername() {
        const el = document.querySelector('#logged-in-info-full .loggedinusername[data-loggedinusername], .loggedinusername[data-loggedinusername]');
        if (el) {
            const data = String(el.getAttribute("data-loggedinusername") || "").trim();
            if (data) return data;
            const text = String(el.textContent || "").trim();
            if (text) return text;
        }
        return "";
    }

    function safeOwnerId(value) {
        return norm(value).replace(/\s+/g, "_").replace(/[^a-z0-9_.-]/g, "").slice(0, 120);
    }

    async function ensureKoha() {
        if (!window.PMKNativeData) return false;
        firebaseApi=window.PMKNativeData;
        firebaseDb=firebaseApi.createDatabase('taxonomy');
        return true;
    }

    function presetCollectionName() {
        return String(currentConfig.presets && currentConfig.presets.collection || "koha_items_assistant_presets");
    }

    function maxPresets() {
        return Math.max(1, Number(currentConfig.presets && currentConfig.presets.maxPresets) || 20);
    }

    async function listKohaOwners() {
        if (!(await ensureKoha())) return [];
        const snap = await firebaseApi.getDocs(firebaseApi.collection(firebaseDb, presetCollectionName()));
        return snap.docs
            .filter(function (d) { return !String(d.id).startsWith("__pmk110_"); })
            .map(function (d) { const data = d.data() || {}; return { id:d.id, ownerName:data.ownerName || d.id }; })
            .sort(function (a,b) { return String(a.ownerName).localeCompare(String(b.ownerName), language()); });
    }

    async function readKohaPresetDoc(ownerId) {
        if (!(await ensureKoha()) || !ownerId) return { ownerName:"", presets:[] };
        const ref = firebaseApi.doc(firebaseDb, presetCollectionName(), ownerId);
        const snap = await firebaseApi.getDoc(ref);
        if (!snap.exists()) return { ownerName:"", presets:[] };
        const data = snap.data() || {};
        return { ownerName:data.ownerName || ownerId, presets:Array.isArray(data.presets) ? data.presets : [] };
    }

    async function writeKohaPresetDoc(ownerId, ownerName, presets) {
        if (!(await ensureKoha()) || !ownerId) return false;
        const ref = firebaseApi.doc(firebaseDb, presetCollectionName(), ownerId);
        await firebaseApi.setDoc(ref, { ownerName:ownerName, presets:presets, updatedAt:firebaseApi.serverTimestamp() }, { merge:true });
        return true;
    }

    async function deleteKohaPresetDoc(ownerId) {
        if (!(await ensureKoha()) || !ownerId) return false;
        await firebaseApi.deleteDoc(firebaseApi.doc(firebaseDb, presetCollectionName(), ownerId));
        return true;
    }

    function presetIdentityForAutomaticMode() {
        const mode = String(currentConfig.presets && currentConfig.presets.mode || "legacyNamed");
        if (mode === "common") return { id:"__pmk110_common__", name:tr("Listes communes", "Shared presets") };
        if (mode === "kohaUser") {
            const username = readLoggedInUsername();
            if (!username) return null;
            return { id:"__pmk110_user_" + safeOwnerId(username), name:username };
        }
        return null;
    }

    function createPanel() {
        const old = document.getElementById(PANEL_ID);
        if (old) old.remove();
        if (refreshTimer) { clearInterval(refreshTimer); refreshTimer = null; }
        if (!supportedPage() || !pageEnabled()) return;

        ensureStyle();
        ensureResponsiveStyle();

        const remember = currentConfig.panel.rememberStateAndPosition !== false;
        const savedPanelState = remember ? getJSON(PANEL_STATE_KEY, { collapsed: currentConfig.panel.collapsedByDefault !== false }) : { collapsed: currentConfig.panel.collapsedByDefault !== false };
        const savedPosition = remember ? getJSON(PANEL_POSITION_KEY, { left:null, top:70, right:20 }) : { left:null, top:70, right:20 };
        const fields = activeFields();
        const root = document.createElement("div");
        root.id = PANEL_ID;
        root.style.width = Math.max(300, Number(currentConfig.panel.widthPx) || 420) + "px";
        if (savedPanelState.collapsed) root.classList.add("collapsed");
        if (savedPosition.left !== null && window.innerWidth > 576) {
            root.style.left = savedPosition.left + "px";
            root.style.top = savedPosition.top + "px";
            root.style.right = "auto";
        } else {
            root.style.top = (savedPosition.top == null ? 70 : savedPosition.top) + "px";
            root.style.right = (savedPosition.right == null ? 20 : savedPosition.right) + "px";
        }

        const rowsHtml = fields.map(function (field) {
            return `<div class="row" data-row="${escapeHTML(field.id)}"><label>${escapeHTML(fieldLabel(field))}</label></div>`;
        }).join("");
        const legacyMode = String(currentConfig.presets.mode || "legacyNamed") === "legacyNamed";
        root.innerHTML = `
            <div class="head">
                <span><span class="title">${escapeHTML(tr("Assistance exemplaires", "Item assistance"))}</span><span class="subtitle" id="koha_items_current_list"></span></span>
                <div class="head-btns"><span class="pmk110-config-anchor"></span><button type="button" data-pmk110-act="collapse" title="${escapeHTML(tr("Réduire", "Collapse"))}">–</button></div>
            </div>
            <div class="body">
                ${rowsHtml}
                <div class="actions">
                    <button type="button" class="btn-primary" data-act="apply">${escapeHTML(tr("Appliquer", "Apply"))}</button>
                    <button type="button" class="btn-ghost" data-act="clearAll" title="${escapeHTML(tr("Vide uniquement les valeurs préparées dans le panneau", "Clears only values prepared in the panel"))}">${escapeHTML(tr("Vider", "Clear"))}</button>
                    <button type="button" class="btn-copy" data-act="copyFromOthers">${escapeHTML(tr("Copier au + nombreux", "Copy majority"))}</button>
                    <button type="button" class="btn-secondary" data-act="save">${escapeHTML(tr("Mémoriser", "Save preset"))}</button>
                </div>
                <div class="status" id="koha_items_status"></div>
                <hr class="divider">
                <div class="presets-title"><span>${escapeHTML(tr("Mémorisations", "Presets"))}</span><span class="presets-count" id="koha_items_presets_count"></span></div>
                <div class="presets-actions"><span class="note-presets">${escapeHTML(legacyMode ? tr("Sélectionnez une liste ou créez-en une.", "Select or create a list.") : tr("La liste est déterminée automatiquement par le mode configuré.", "The list is selected automatically by the configured mode."))}</span><div style="display:flex;gap:6px;align-items:center"><button type="button" class="btn-secondary btn-small" data-act="togglePresetControls">${escapeHTML(tr("Options", "Options"))}</button></div></div>
                <div class="preset-controls" id="koha_items_preset_controls">
                    ${legacyMode ? `<div class="row" data-row="ownerSelect"><label>${escapeHTML(tr("Liste nominative", "Named list"))}</label><select class="combo-input" data-owner-select style="width:100%"></select></div><div class="row" data-row="owner"><label>${escapeHTML(tr("Créer une liste", "Create list"))}</label><div style="display:flex;gap:8px;align-items:center"><input type="text" class="combo-input" data-owner-input placeholder="${escapeHTML(tr("Nom Prénom (requis)", "Full name (required)"))}"><button type="button" class="btn-secondary btn-small" data-act="createList">${escapeHTML(tr("Créer liste", "Create list"))}</button></div></div>` : `<div class="modal-note">${escapeHTML(currentConfig.presets.mode === "kohaUser" ? tr("Mémorisations liées automatiquement au compte Koha connecté.", "Presets automatically linked to the signed-in Koha account.") : tr("Mémorisations communes à tous les utilisateurs.", "Presets shared by all users."))}</div>`}
                </div>
                <div class="preset-list" id="koha_items_presets"></div>
            </div>
        `;
        document.body.appendChild(root);

        // Isoler les interactions du volet 110 des gestionnaires délégués
        // d'autres scripts Koha/PMK (plusieurs modules utilisent des data-act
        // génériques comme "collapse"). Les gestionnaires internes des
        // contrôles s'exécutent normalement, puis le clic ne remonte pas au
        // document.
        root.addEventListener("click", function (event) {
            event.stopPropagation();
        });

        mountContextButton(root);

        const status = root.querySelector("#koha_items_status");
        const presetsList = root.querySelector("#koha_items_presets");
        const presetsCount = root.querySelector("#koha_items_presets_count");
        const currentListLabel = root.querySelector("#koha_items_current_list");
        const ownerInput = root.querySelector("[data-owner-input]");
        const ownerSelect = root.querySelector("[data-owner-select]");
        const createListBtn = root.querySelector('[data-act="createList"]');
        const combos = {};
        const state = {};

        function refreshDependencies() {
            fields.forEach(function (field) {
                const combo = combos[field.id];
                if (!combo) return;
                const satisfied = dependencySatisfied(field, state);
                const parent = fields.find(function (candidate) { return candidate.id === field.dependsOnFieldId; });
                combo.setDisabled(!satisfied, tr("Disponible lorsque ", "Available when ") + (parent ? fieldLabel(parent) : (field.dependsOnFieldId || tr("le champ parent", "the parent field"))) + tr(" satisfait la règle configurée.", " matches the configured rule."));
            });
        }

        function savePosition() {
            if (!remember) return;
            const rect = root.getBoundingClientRect();
            setJSON(PANEL_POSITION_KEY, { left:Math.round(rect.left), top:Math.round(rect.top), right:null });
        }

        (function installDrag() {
            const head = root.querySelector(".head");
            let dragging = false, offX = 0, offY = 0;
            head.addEventListener("mousedown", function (event) {
                if (window.innerWidth <= 576 || event.target.closest(".head-btns")) return;
                dragging = true;
                const rect = root.getBoundingClientRect();
                offX = event.clientX - rect.left;
                offY = event.clientY - rect.top;
                root.style.right = "auto";
            });
            document.addEventListener("mousemove", function (event) {
                if (!dragging) return;
                root.style.left = Math.max(0, Math.min(window.innerWidth - root.offsetWidth, event.clientX - offX)) + "px";
                root.style.top = Math.max(0, event.clientY - offY) + "px";
            });
            document.addEventListener("mouseup", function () { if (dragging) { dragging = false; savePosition(); } });
        })();

        fields.forEach(function (field) {
            const row = root.querySelector(`[data-row="${cssEscapeValue(field.id)}"]`);
            if (!row) return;
            const el = getFieldElement(field);
            const targetType = fieldType(field, el);
            const useList = targetType === "select" || fieldHasConfiguredListSource(field);
            const immediateOptions = useList
                ? (String(field.sourceMode || "auto") === "manual" ? manualOptions(field) : getSelectOptions(el))
                : [];
            const combo = makeCombo(row, field, immediateOptions, !useList, !!el && canClearField(field, el));
            combos[field.id] = combo;
            const value = el ? normalizeFieldValue(field, getFieldValue(el)) : "";
            state[field.id] = value;
            combo.setValue(value, true);
            combo.onChange(function (value) { state[field.id] = value; refreshDependencies(); });

            if (useList) {
                loadFieldOptions(field, el).then(function (options) {
                    if (!document.body.contains(root) || !combos[field.id]) return;
                    combos[field.id].setItems(options);
                    combos[field.id].setValue(state[field.id], true);
                }).catch(function () {});
            }
        });
        refreshDependencies();

        function clearPanel() {
            fields.forEach(function (field) {
                state[field.id] = "";
                if (combos[field.id]) {
                    combos[field.id].setValue("", true);
                    combos[field.id].setClearFlag(false);
                }
            });
            status.textContent = tr("✅ Tous les champs du panneau ont été vidés.", "✅ All panel fields were cleared.");
        }

        async function applyValues() {
            const changes = [], skipped = [], modifiedEls = [];
            for (const field of fields) {
                const combo = combos[field.id];
                if (!combo) continue;
                if (!dependencySatisfied(field, state)) {
                    if (String(state[field.id] || "")) skipped.push(fieldLabel(field) + " (" + tr("dépendance non satisfaite", "dependency not satisfied") + ")");
                    continue;
                }
                const rawValue = String(state[field.id] || "");
                const value = normalizeFieldValue(field, rawValue);
                const clearRequested = combo.getClearFlag() && !value;
                const el = await findFieldElementWithRetry(field, 0);
                if (!el) {
                    if (value || clearRequested) skipped.push(fieldLabel(field) + " (" + tr("champ introuvable", "field not found") + ")");
                    continue;
                }
                const current = getFieldValue(el);
                if (clearRequested) {
                    const ok = clearFieldThroughKoha(field, el);
                    if (ok) {
                        changes.push(`${fieldLabel(field)}: "${current}" → (${tr("vidage demandé à Koha", "clear requested through Koha")})`);
                        modifiedEls.push(el);
                    } else skipped.push(fieldLabel(field) + " (" + tr("vidage impossible avec les contrôles natifs Koha", "cannot be cleared with native Koha controls") + ")");
                    continue;
                }
                if (value) {
                    cancelKohaClear(field, el);
                    if (norm(current) !== norm(value)) {
                        const ok = setFieldValue(field, el, value);
                        if (ok) { changes.push(`${fieldLabel(field)}: "${current}" → "${value}"`); modifiedEls.push(el); }
                        else skipped.push(fieldLabel(field) + " (" + tr("valeur absente ou non applicable", "value missing or not applicable") + ")");
                    }
                }
                await new Promise(function (resolve) { setTimeout(resolve, 20); });
            }
            modifiedEls.forEach(function (el) {
                el.classList.add("field-modified", "field-modified-highlight");
                setTimeout(function () { el.classList.remove("field-modified-highlight"); }, 4500);
            });
            if (changes.length) status.textContent = `✅ ${changes.length} ${tr("champ(s) préparé(s)", "field(s) prepared")}:\n${changes.join("\n")}` + (skipped.length ? `\n⚠️ ${skipped.join(", ")}` : "");
            else if (skipped.length) status.textContent = `⚠️ ${tr("Aucun champ modifié", "No field changed")}. ${skipped.join(", ")}`;
            else status.textContent = tr("Aucun champ modifié (valeurs déjà présentes ou identiques).", "No field changed (values already present or identical).");
        }

        function copyFromOthers() {
            if (currentConfig.copyMajority && currentConfig.copyMajority.enabled === false) {
                status.textContent = tr("La fonction « Copier au + nombreux » est désactivée.", "Copy majority is disabled.");
                return;
            }
            const items = getExistingItems();
            if (!items.length) { status.textContent = tr("❌ Aucun exemplaire existant trouvé dans le tableau.", "❌ No existing item found in the table."); return; }
            const values = computeMostCommonValues(items);
            const ids = Object.keys(values);
            if (!ids.length) { status.textContent = tr("❌ Aucune donnée commune significative trouvée parmi les exemplaires.", "❌ No significant common value found among existing items."); return; }
            const modal = document.createElement("div");
            modal.className = PANEL_ID + "_modal_backdrop";
            modal.id = PANEL_ID + "_modal_backdrop";
            modal.style.cssText = "position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(2,6,23,.72);z-index:2147483646;padding:24px;box-sizing:border-box";
            const box = document.createElement("div");
            box.className = PANEL_ID + "_modal_content";
            box.id = PANEL_ID + "_modal_content";
            box.style.cssText = "width:100%;max-width:560px;max-height:84vh;box-sizing:border-box;position:relative;isolation:isolate;transform:translateZ(0)";
            box.innerHTML = `<h3>${escapeHTML(tr("📋 Confirmer la copie depuis les exemplaires existants", "📋 Confirm copy from existing items"))}</h3><p style="color:#475069;font-size:13px">${escapeHTML(tr("Les valeurs suivantes seront préparées dans le panneau. Vous pourrez ensuite les transférer dans Koha avec le bouton Appliquer du panneau :", "The following values will be prepared in the panel. You can then transfer them to Koha with Apply:"))}</p><ul>${ids.map(function (id) { const field = fields.find(function (f) { return f.id === id; }); return `<li><strong>${escapeHTML(fieldLabel(field))}</strong> → <span style="color:#408540;font-weight:600">"${escapeHTML(values[id])}"</span></li>`; }).join("")}</ul><div class="modal-note">${escapeHTML(tr("Règle par défaut : majorité stricte, au moins 2 occurrences, aucune égalité.", "Default rule: strict majority, at least 2 occurrences, no tie."))}</div><div class="modal-actions"><button class="btn-cancel" data-act="modalCancel">${escapeHTML(tr("Annuler", "Cancel"))}</button><button class="btn-confirm" data-act="modalConfirm">${escapeHTML(tr("Préparer", "Prepare"))}</button></div>`;
            modal.appendChild(box); document.body.appendChild(modal);
            box.querySelector('[data-act="modalCancel"]').addEventListener("click", function () { modal.remove(); status.textContent = tr("Copie annulée.", "Copy cancelled."); });
            box.querySelector('[data-act="modalConfirm"]').addEventListener("click", function () {
                fields.forEach(function (field) { if (combos[field.id]) combos[field.id].setClearFlag(false); });
                Object.entries(values).forEach(function (entry) {
                    const field = fields.find(function (f) { return f.id === entry[0]; });
                    if (!field || !combos[field.id]) return;
                    const clean = normalizeFieldValue(field, entry[1]);
                    state[field.id] = clean;
                    combos[field.id].setValue(clean, true);
                });
                modal.remove();
                status.textContent = tr("✅ Valeurs préparées. Utilisez le bouton Appliquer du panneau pour les transférer dans Koha.", "✅ Values prepared. Use Apply to transfer them to Koha.");
            });
        }

        let currentOwnerId = "";
        let currentOwnerName = "";
        let firebasePresets = [];

        function renderPresets() {
            const presets = currentOwnerId ? firebasePresets : getJSON(PRESETS_KEY, []);
            presetsCount.textContent = `${presets.length}/${maxPresets()}`;
            if (!presets.length) { presetsList.innerHTML = `<div class="preset-empty">${escapeHTML(tr("Aucune mémorisation pour l'instant.", "No preset yet."))}</div>`; return; }
            presetsList.innerHTML = presets.map(function (preset, index) {
                const name = preset.presetName || tr("Mémorisation ", "Preset ") + (index + 1);
                const summary = fields.filter(function (field) { return preset[field.id] !== undefined; }).map(function (field) { return fieldLabel(field) + ": " + normalizeFieldValue(field, preset[field.id]); }).join(" | ");
                return `<div class="preset-item" data-idx="${index}"><span class="preset-text"><b>${escapeHTML(name)}</b><span class="preset-fields">${escapeHTML(summary)}</span></span><button type="button" class="preset-del" data-del="${index}" title="${escapeHTML(tr("Supprimer", "Delete"))}">×</button></div>`;
            }).join("");
        }

        async function loadLegacyOwners() {
            if (!ownerSelect) return;
            ownerSelect.innerHTML = `<option value="">${escapeHTML(tr("Sélectionnez votre nom...", "Select your name..."))}</option>`;
            const ok = await ensureKoha();
            if (!ok) { status.textContent = tr("Koha indisponible : l’assistant reste fonctionnel, mais les listes partagées ne peuvent pas être chargées.", "Koha unavailable: the assistant still works, but shared lists cannot be loaded."); return; }
            try {
                const owners = await listKohaOwners();
                ownerSelect.innerHTML += owners.map(function (o) { return `<option value="${escapeHTML(o.id)}">${escapeHTML(o.ownerName)}</option>`; }).join("");
                const saved = currentConfig.presets.rememberSelectedList !== false ? getJSON(SELECTED_OWNER_KEY, "") : "";
                if (saved && owners.some(function (o) { return o.id === saved; })) { ownerSelect.value = saved; await loadPresetOwner(saved); }
                else status.textContent = tr(`Listes nominatives chargées (${owners.length}).`, `Named lists loaded (${owners.length}).`);
            } catch (_) { status.textContent = tr("Erreur lors du chargement des listes Koha.", "Error loading Koha lists."); }
        }

        async function loadPresetOwner(ownerId, ownerNameOverride) {
            currentOwnerId = ownerId || "";
            if (!currentOwnerId) {
                currentOwnerName = ""; firebasePresets = []; renderPresets(); currentListLabel.textContent = ""; return;
            }
            try {
                const data = await readKohaPresetDoc(currentOwnerId);
                currentOwnerName = data.ownerName || ownerNameOverride || currentOwnerId;
                firebasePresets = data.presets || [];
                if (ownerInput) ownerInput.value = currentOwnerName;
                currentListLabel.textContent = tr("Liste de : ", "List: ") + currentOwnerName;
                if (currentConfig.presets.rememberSelectedList !== false) setJSON(SELECTED_OWNER_KEY, currentOwnerId);
                renderPresets();
                status.textContent = tr(`Mémorisations pour ${currentOwnerName} chargées (${firebasePresets.length}).`, `Presets for ${currentOwnerName} loaded (${firebasePresets.length}).`);
            } catch (_) { status.textContent = tr("Erreur lors de la lecture des mémorisations Koha.", "Error reading Koha presets."); }
        }

        async function initializePresetMode() {
            if (currentConfig.presets.enabled === false) {
                root.querySelector(".presets-title").style.display = "none";
                root.querySelector(".presets-actions").style.display = "none";
                root.querySelector("#koha_items_preset_controls").style.display = "none";
                presetsList.style.display = "none";
                root.querySelector('[data-act="save"]').style.display = "none";
                return;
            }
            if (legacyMode) return loadLegacyOwners();
            const identity = presetIdentityForAutomaticMode();
            if (!identity) { status.textContent = tr("Impossible d’identifier le compte Koha connecté : les mémorisations utilisateur sont indisponibles.", "Unable to identify the signed-in Koha account: user presets are unavailable."); return; }
            if (!(await ensureKoha())) { status.textContent = tr("Koha indisponible : l’assistant reste fonctionnel, mais les mémorisations ne peuvent pas être chargées.", "Koha unavailable: the assistant still works, but presets cannot be loaded."); return; }
            await loadPresetOwner(identity.id, identity.name);
            if (!currentOwnerName) { currentOwnerName = identity.name; currentListLabel.textContent = identity.name; }
        }

        function presetDataFromState(name) {
            const data = { presetName:name, createdAt:new Date().toISOString() };
            let hasData = false;
            fields.forEach(function (field) {
                const value = normalizeFieldValue(field, state[field.id]);
                if (value) { data[field.id] = value; hasData = true; }
            });
            return hasData ? data : null;
        }

        async function savePreset() {
            if (currentConfig.presets.enabled === false) return;
            if (!(await ensureKoha())) { status.textContent = tr("Koha non disponible.", "Koha unavailable."); return; }
            let identity;
            if (legacyMode) {
                const name = String(ownerInput && ownerInput.value || currentOwnerName || "").trim();
                if (!name) { status.textContent = tr("Entrez votre nom et prénom avant de mémoriser.", "Enter your full name before saving a preset."); if (ownerInput) ownerInput.focus(); return; }
                identity = { id:safeOwnerId(name), name:name };
            } else {
                identity = presetIdentityForAutomaticMode();
                if (!identity) { status.textContent = tr("Compte Koha introuvable.", "Koha account not found."); return; }
            }
            const probe = presetDataFromState("");
            if (!probe) { status.textContent = tr("Rien à mémoriser : au moins un champ doit être rempli.", "Nothing to save: at least one field must be filled."); return; }
            const modal = document.createElement("div");
            modal.className = PANEL_ID + "_modal_backdrop";
            modal.style.cssText = "position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(2,6,23,.72);z-index:2147483646;padding:24px;box-sizing:border-box";
            const box = document.createElement("div"); box.className = PANEL_ID + "_modal_content"; box.id = PANEL_ID + "_modal_content";
            box.innerHTML = `<h3>${escapeHTML(tr("💾 Nommer la mémorisation", "💾 Name preset"))}</h3><p style="color:#475069;font-size:13px">${escapeHTML(tr("Donnez un nom à cette mémorisation pour la retrouver facilement :", "Give this preset a name:"))}</p><input type="text" class="preset-name-input" id="presetNameInput" placeholder="${escapeHTML(tr("Ex: Livre jeunesse, BD, DVD...", "E.g. Children book, comics, DVD..."))}" value="${escapeHTML(tr("Mémorisation ", "Preset ") + (firebasePresets.length + 1))}"><div class="modal-actions"><button class="btn-cancel" data-act="modalCancel">${escapeHTML(tr("Annuler", "Cancel"))}</button><button class="btn-confirm" data-act="modalConfirm">${escapeHTML(tr("Enregistrer", "Save"))}</button></div>`;
            modal.appendChild(box); document.body.appendChild(modal);
            const nameInput = box.querySelector("#presetNameInput"); nameInput.focus(); nameInput.select();
            box.querySelector('[data-act="modalCancel"]').addEventListener("click", function () { modal.remove(); status.textContent = tr("Mémorisation annulée.", "Preset cancelled."); });
            box.querySelector('[data-act="modalConfirm"]').addEventListener("click", async function () {
                const presetName = String(nameInput.value || "").trim() || tr("Mémorisation ", "Preset ") + (firebasePresets.length + 1);
                modal.remove();
                try {
                    const existingData = await readKohaPresetDoc(identity.id);
                    const existing = Array.isArray(existingData.presets) ? existingData.presets.slice() : [];
                    const duplicate = existing.findIndex(function (p) { return String(p.presetName || "") === presetName; });
                    if (duplicate !== -1 && !window.confirm(tr(`Une mémorisation nommée "${presetName}" existe déjà. Voulez-vous la remplacer ?`, `A preset named "${presetName}" already exists. Replace it?`))) { status.textContent = tr("Mémorisation annulée.", "Preset cancelled."); return; }
                    if (duplicate !== -1) existing.splice(duplicate, 1);
                    existing.unshift(presetDataFromState(presetName));
                    while (existing.length > maxPresets()) existing.pop();
                    await writeKohaPresetDoc(identity.id, identity.name, existing);
                    currentOwnerId = identity.id; currentOwnerName = identity.name; firebasePresets = existing;
                    if (currentConfig.presets.rememberSelectedList !== false) setJSON(SELECTED_OWNER_KEY, currentOwnerId);
                    currentListLabel.textContent = tr("Liste de : ", "List: ") + currentOwnerName;
                    renderPresets();
                    if (legacyMode) {
                        await loadLegacyOwners();
                        if (ownerSelect) ownerSelect.value = currentOwnerId;
                    }
                    status.textContent = tr(`✅ Mémorisation "${presetName}" enregistrée pour ${identity.name}.`, `✅ Preset "${presetName}" saved for ${identity.name}.`);
                } catch (e) { status.textContent = tr("Erreur lors de l'enregistrement Koha : ", "Koha save error: ") + (e && e.message || e); }
            });
        }

        async function deletePreset(index) {
            if (!currentOwnerId || !firebasePresets[index]) return;
            const name = firebasePresets[index].presetName || tr("Mémorisation", "Preset");
            if (!window.confirm(tr(`Supprimer "${name}" ?`, `Delete "${name}"?`))) return;
            const next = firebasePresets.slice(); next.splice(index, 1);
            try {
                if (!next.length && legacyMode) {
                    const removeList = window.confirm(tr("La liste nominative est désormais vide. Voulez-vous supprimer la liste elle-même ?", "The named list is now empty. Delete the list itself?"));
                    if (removeList) {
                        await deleteKohaPresetDoc(currentOwnerId);
                        currentOwnerId = ""; currentOwnerName = ""; firebasePresets = [];
                        if (ownerSelect) ownerSelect.value = ""; if (ownerInput) ownerInput.value = "";
                        setJSON(SELECTED_OWNER_KEY, ""); await loadLegacyOwners(); renderPresets(); currentListLabel.textContent = "";
                        status.textContent = tr("Liste vide supprimée.", "Empty list deleted."); return;
                    }
                }
                await writeKohaPresetDoc(currentOwnerId, currentOwnerName, next);
                firebasePresets = next; renderPresets();
                status.textContent = tr(`✅ Mémorisation "${name}" supprimée.`, `✅ Preset "${name}" deleted.`);
            } catch (_) { status.textContent = tr("Erreur lors de la suppression Koha.", "Koha deletion error."); }
        }

        if (ownerSelect) ownerSelect.addEventListener("change", function () { loadPresetOwner(ownerSelect.value); });
        if (createListBtn) createListBtn.addEventListener("click", async function () {
            const name = String(ownerInput && ownerInput.value || "").trim();
            if (!name) { status.textContent = tr("Entrez un nom complet pour créer la liste.", "Enter a full name to create the list."); ownerInput.focus(); return; }
            if (!(await ensureKoha())) { status.textContent = tr("Koha non disponible.", "Koha unavailable."); return; }
            const id = safeOwnerId(name);
            const existing = await readKohaPresetDoc(id);
            await writeKohaPresetDoc(id, name, existing.presets || []);
            await loadLegacyOwners();
            if (ownerSelect) ownerSelect.value = id;
            await loadPresetOwner(id, name);
            status.textContent = tr(`✅ Liste "${name}" créée et sélectionnée.`, `✅ List "${name}" created and selected.`);
        });

        presetsList.addEventListener("click", function (event) {
            const del = event.target.closest("[data-del]");
            if (del) { deletePreset(Number(del.dataset.del)); return; }
            const item = event.target.closest(".preset-item");
            if (!item) return;
            const presets = currentOwnerId ? firebasePresets : getJSON(PRESETS_KEY, []);
            const preset = presets[Number(item.dataset.idx)];
            if (!preset) return;
            fields.forEach(function (field) { state[field.id] = ""; if (combos[field.id]) { combos[field.id].setValue("", true); combos[field.id].setClearFlag(false); } });
            fields.forEach(function (field) {
                let value = preset[field.id];
                if (value === undefined && field.legacyCode && preset[field.legacyCode] !== undefined) value = preset[field.legacyCode];
                if (value === undefined) return;
                const clean = normalizeFieldValue(field, value);
                state[field.id] = clean;
                if (combos[field.id]) combos[field.id].setValue(clean, true);
            });
            status.textContent = tr(`✅ Mémorisation "${preset.presetName || ""}" chargée. Cliquez sur "Appliquer" pour l'utiliser.`, `✅ Preset "${preset.presetName || ""}" loaded. Click Apply to use it.`);
        });

        const presetControls = root.querySelector("#koha_items_preset_controls");
        const togglePresetControlsBtn = root.querySelector('[data-act="togglePresetControls"]');
        function updatePresetControlsLabel() { togglePresetControlsBtn.textContent = presetControls.classList.contains("open") ? tr("Masquer", "Hide") : tr("Options", "Options"); }
        togglePresetControlsBtn.addEventListener("click", function () { presetControls.classList.toggle("open"); updatePresetControlsLabel(); setJSON(PRESET_CONTROLS_KEY, presetControls.classList.contains("open")); });
        if (getJSON(PRESET_CONTROLS_KEY, false)) presetControls.classList.add("open");
        updatePresetControlsLabel();

        root.querySelector('[data-act="apply"]').addEventListener("click", applyValues);
        root.querySelector('[data-act="clearAll"]').addEventListener("click", clearPanel);
        root.querySelector('[data-act="copyFromOthers"]').addEventListener("click", copyFromOthers);
        root.querySelector('[data-act="save"]').addEventListener("click", savePreset);
        const collapseBtn = root.querySelector('[data-pmk110-act="collapse"]');
        collapseBtn.textContent = savedPanelState.collapsed ? "+" : "–";
        collapseBtn.addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();
            root.classList.toggle("collapsed");
            const collapsed = root.classList.contains("collapsed");
            collapseBtn.textContent = collapsed ? "+" : "–";
            if (remember) setJSON(PANEL_STATE_KEY, { collapsed:collapsed });
            savePosition();
        });
        window.addEventListener("beforeunload", savePosition, { once:true });

        renderPresets();
        initializePresetMode();

        refreshTimer = setInterval(function () {
            fields.forEach(function (field) {
                const el = getFieldElement(field), combo = combos[field.id];
                if (!combo) return;
                const hasExternal = fieldHasConfiguredListSource(field);
                if (!hasExternal && el && el.tagName === "SELECT") {
                    combo.setItems(getSelectOptions(el));
                    combo.setValue(state[field.id], true);
                    return;
                }
                if (String(field.sourceMode || "auto") === "manual") {
                    combo.setItems(manualOptions(field));
                    combo.setValue(state[field.id], true);
                }
            });
        }, currentConfig.panel.refreshOptionsMs);
    }

    function newField() {
        const id = "field_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2,6);
        return {
            id:id, legacyCode:id, enabled:true, kohafield:"items.", marcTag:"995", marcSubfield:"",
            labelFr:"Nouveau champ", labelEn:"New field", type:"auto", allowClear:true, copyEligible:true,
            normalize:"none", selector:"", dependencyMode:"none", dependsOnFieldId:"", dependsOnValues:"", sourceMode:"auto",
            source:{
                authorisedValueCategory:"", authorisedValueCategoryCustom:"", apiEndpoint:"", apiArrayPath:"",
                apiValuePath:"value", apiLabelPath:"description", fallbackToForm:true, manualValues:[]
            }
        };
    }

    function diagnoseConfiguredFields(config, root) {
        const cfg = normalizeConfig(config || currentConfig);
        const scope = root && typeof root.querySelectorAll === "function" ? root : document;
        const enabled = cfg.fields.filter(function (field) { return field && field.enabled !== false; });
        const ids = new Set(enabled.map(function (field) { return field.id; }));
        const targetCounts = new Map();
        enabled.forEach(function (field) {
            const target = String(field.kohafield || field.selector || "").trim();
            if (target) targetCounts.set(target, (targetCounts.get(target) || 0) + 1);
        });
        return enabled.map(function (field) {
            let element = null;
            for (const selector of selectorCandidates(field)) {
                try {
                    const matches = Array.from(scope.querySelectorAll(selector)).filter(function (node) { return node.type !== "hidden" && !node.closest("#" + PANEL_ID); });
                    if (matches.length) { element = matches[0]; break; }
                } catch (_) {}
            }
            const issues = [];
            if (!element) issues.push("target-missing");
            if (field.marcTag && !/^\d{3}$/.test(String(field.marcTag))) issues.push("marc-invalid");
            if (field.sourceMode === "authorised_values" && !effectiveAuthorisedValueCategory(field)) issues.push("authorised-value-category-missing");
            if (field.dependencyMode !== "none" && (!field.dependsOnFieldId || !ids.has(field.dependsOnFieldId) || field.dependsOnFieldId === field.id)) issues.push("dependency-invalid");
            if (field.dependencyMode === "equals" && !dependencyValues(field).length) issues.push("dependency-values-missing");
            const target = String(field.kohafield || field.selector || "").trim();
            if (target && targetCounts.get(target) > 1) issues.push("target-duplicate");
            return {
                id:field.id,label:fieldLabel(field),target:target,
                marc:(field.marcTag || "—") + "$" + (field.marcSubfield || "—"),
                source:field.sourceMode || "auto",authorisedValueCategory:effectiveAuthorisedValueCategory(field),
                dependency:field.dependencyMode === "none" ? "none" : field.dependsOnFieldId,
                found:!!element,tagName:element ? element.tagName : null,issues:issues
            };
        });
    }

    function renderFieldDiagnostics(context) {
        const rows = diagnoseConfiguredFields(context && context.rootObject);
        const wrap = document.createElement("div");
        wrap.className = "pmk110-field-diagnostics";
        const problems = rows.filter(function (row) { return row.issues.length; }).length;
        const intro = document.createElement("p");
        intro.textContent = tr(rows.length + " champ(s) contrôlé(s), " + problems + " à vérifier. Le test lit la page sans modifier le formulaire.", rows.length + " field(s) checked, " + problems + " need review. The check does not modify the form.");
        wrap.appendChild(intro);
        const list = document.createElement("ul");
        rows.forEach(function (row) {
            const li = document.createElement("li");
            li.textContent = `${row.label} — ${row.target || "cible absente"} — MARC ${row.marc} — source ${row.source}` + (row.authorisedValueCategory ? ` (${row.authorisedValueCategory})` : "") + (row.dependency !== "none" ? ` — dépend de ${row.dependency}` : "") + (row.issues.length ? ` — ⚠ ${row.issues.join(", ")}` : " — ✓");
            list.appendChild(li);
        });
        wrap.appendChild(list);
        return wrap;
    }

    function validateConfig(config) {
        return normalizeConfig(config);
    }

    function registerWithPMK() {
        if (!window.PMKConfig || configRegistered) return false;
        configRegistered = true;
        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 4,
            name: { fr:"Assistant de saisie des exemplaires", en:"Item entry assistant" },
            description: {
                fr:"Assistant repliable sur additem.pl et batchMod.pl : préparation contrôlée de champs exemplaire, mémorisations et reprise des valeurs majoritaires des exemplaires existants.",
                en:"Collapsible assistant on additem.pl and batchMod.pl for controlled item-field preparation, presets, and majority values from existing items."
            },
            category: { fr:"Catalogue / exemplaires", en:"Catalog / items" },
            supportedPages: ["cataloguing.additem","tools.batchmod"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                { type:"section", id:"activation", label:{fr:"Activation",en:"Activation"}, description:{fr:"Le 110 reste autonome du 102. Il ne soumet jamais le formulaire Koha.",en:"110 remains separate from 102. It never submits the Koha form."}, fields:[
                    { key:"enabled", type:"boolean", label:{fr:"Activer l’assistant exemplaires",en:"Enable item assistant"} },
                    { key:"pages", type:"repeater", label:{fr:"Pages Koha",en:"Koha pages"}, reorder:false, removable:false, canAdd:function(){return false;}, itemTitle:function(item,index,lang){ const d=PAGE_DEFINITIONS[index]; return d ? (lang==="en"?d.labelEn:d.labelFr) : String(item&&item.path||"Page"); }, fields:[
                        {key:"enabled",type:"boolean",label:{fr:"Activer sur cette page",en:"Enable on this page"}},
                        {key:"id",type:"text",readOnly:true,advanced:true,label:{fr:"Identifiant page",en:"Page identifier"}},
                        {key:"path",type:"text",label:{fr:"Chemin Koha",en:"Koha path"}}
                    ]}
                ]},
                { type:"section", id:"panel", label:{fr:"Panneau",en:"Panel"}, description:{fr:"420 px et panneau replié restent les valeurs historiques par défaut. Sur petit écran la largeur s’adapte automatiquement.",en:"420 px and collapsed state remain the historical defaults. Width adapts automatically on small screens."}, fields:[
                    {key:"panel.widthPx",type:"number",min:300,max:760,label:{fr:"Largeur du panneau (px)",en:"Panel width (px)"}},
                    {key:"panel.collapsedByDefault",type:"boolean",label:{fr:"Panneau replié par défaut",en:"Collapsed by default"}},
                    {key:"panel.rememberStateAndPosition",type:"boolean",label:{fr:"Mémoriser état et position sur ce navigateur",en:"Remember state and position in this browser"}},
                    {key:"panel.refreshOptionsMs",type:"number",min:1000,max:60000,advanced:true,label:{fr:"Rafraîchissement des listes Koha (ms)",en:"Koha list refresh interval (ms)"}}
                ]},
                { type:"section", id:"fields", label:{fr:"Champs de l’assistant",en:"Assistant fields"}, description:{fr:"Les 17 champs préconfigurés restent dans le même ordre. Pour chaque champ, la source des choix peut venir du formulaire Koha, d’une catégorie de valeurs autorisées, d’un endpoint REST Koha ou d’une liste manuelle. Le mode Auto garde le formulaire comme repli sûr.",en:"The 17 original fields remain in the same order. Each field can source choices from the Koha form, an authorised-value category, a Koha REST endpoint or a manual list. Auto mode keeps the form as a safe fallback."}, fields:[
                    {type:"custom",label:{fr:"Contrôler les cibles, mappings et dépendances",en:"Check targets, mappings and dependencies"},render:renderFieldDiagnostics},
                    {key:"fields",type:"repeater",label:{fr:"Champs",en:"Fields"},addLabel:{fr:"Ajouter un champ exemplaire",en:"Add item field"},reorder:true,newItem:newField,liveTitleKey:"labelFr",itemTitle:function(item,index,lang){return lang==="en"?String(item&&item.labelEn||item&&item.labelFr||("Field "+(index+1))):String(item&&item.labelFr||item&&item.labelEn||("Champ "+(index+1)));},fields:[
                        {key:"enabled",type:"boolean",label:{fr:"Champ actif",en:"Field enabled"}},
                        {key:"id",type:"text",readOnly:true,advanced:true,label:{fr:"Identifiant stable",en:"Stable identifier"}},
                        {key:"labelFr",type:"text",label:{fr:"Libellé français",en:"French label"}},
                        {key:"labelEn",type:"text",label:{fr:"Libellé anglais",en:"English label"}},
                        {key:"kohafield",type:"text",label:{fr:"Kohafield exemplaire",en:"Item kohafield"},help:{fr:"Ex. items.homebranch, items.location, items.more_subfields_xml_q. C’est la cible réellement modifiée par l’assistant.",en:"E.g. items.homebranch, items.location, items.more_subfields_xml_q. This is the field actually changed by the assistant."}},
                        {key:"marcTag",type:"text",advanced:true,label:{fr:"Zone UNIMARC (information)",en:"UNIMARC tag (information)"}},
                        {key:"marcSubfield",type:"text",advanced:true,label:{fr:"Sous-zone UNIMARC (information)",en:"UNIMARC subfield (information)"}},
                        {key:"selector",type:"text",advanced:true,label:{fr:"Sélecteur CSS de secours",en:"Fallback CSS selector"},help:{fr:"À laisser vide normalement. Utiliser uniquement lorsqu’un champ local n’est pas accessible par son kohafield.",en:"Normally leave blank. Use only when a local field cannot be reached by its kohafield."}},
                        {key:"type",type:"select",advanced:true,label:{fr:"Type du champ cible",en:"Target field type"},options:[{value:"auto",label:{fr:"Détection automatique",en:"Automatic detection"}},{value:"select",label:{fr:"Liste",en:"Select"}},{value:"input",label:{fr:"Champ texte",en:"Text field"}}]},
                        {key:"dependencyMode",type:"select",label:{fr:"Dépendance avec un autre champ",en:"Dependency on another field"},options:[{value:"none",label:{fr:"Aucune",en:"None"}},{value:"nonempty",label:{fr:"Actif lorsque le champ parent est renseigné",en:"Enabled when parent field is filled"}},{value:"equals",label:{fr:"Actif pour certaines valeurs du champ parent",en:"Enabled for selected parent values"}}]},
                        {key:"dependsOnFieldId",type:"text",label:{fr:"Identifiant du champ parent",en:"Parent field identifier"},help:{fr:"Utilisez l’identifiant stable d’un autre champ de cette liste, par exemple b ou r.",en:"Use another field’s stable identifier, for example b or r."}},
                        {key:"dependsOnValues",type:"textarea",rows:3,label:{fr:"Valeurs du parent autorisant ce champ",en:"Parent values enabling this field"},help:{fr:"Une valeur par ligne. Utilisé uniquement pour la dépendance « certaines valeurs ».",en:"One value per line. Used only by selected-value dependencies."}},
                        {key:"sourceMode",type:"select",label:{fr:"Source des choix dans l’assistant",en:"Source for assistant choices"},help:{fr:"Auto est recommandé : VA/API configurée si disponible, sinon liste manuelle, sinon options du formulaire Koha.",en:"Auto is recommended: configured AV/API when available, then manual values, then Koha form options."},options:[
                            {value:"auto",label:{fr:"Automatique — recommandé",en:"Automatic — recommended"}},
                            {value:"form",label:{fr:"Formulaire Koha",en:"Koha form"}},
                            {value:"authorised_values",label:{fr:"Valeurs autorisées Koha",en:"Koha authorised values"}},
                            {value:"koha_api",label:{fr:"API REST Koha",en:"Koha REST API"}},
                            {value:"manual",label:{fr:"Liste manuelle",en:"Manual list"}}
                        ]},
                        {key:"source.authorisedValueCategory",type:"select",label:{fr:"Catégorie de valeurs autorisées",en:"Authorised-value category"},options:authorisedValueCategoryOptions,help:{fr:"La liste est chargée automatiquement via l’API Koha quand le compte connecté possède le droit catalogue. Si l’API est indisponible, choisissez « Autre catégorie ».",en:"The list is loaded automatically through the Koha API when the signed-in account has catalogue permission. If unavailable, choose “Other category”."}},
                        {key:"source.authorisedValueCategoryCustom",type:"text",advanced:true,label:{fr:"Catégorie VA saisie manuellement",en:"Manually entered AV category"},help:{fr:"Utilisée uniquement si « Autre catégorie / saisie manuelle… » est sélectionné ci-dessus.",en:"Used only when “Other category / manual entry…” is selected above."}},
                        {key:"source.apiEndpoint",type:"text",advanced:true,label:{fr:"Endpoint API Koha",en:"Koha API endpoint"},help:{fr:"Endpoint REST du même Koha, commençant par /api/v1/. Les endpoints externes sont refusés.",en:"REST endpoint on the same Koha, starting with /api/v1/. External endpoints are rejected."}},
                        {key:"source.apiArrayPath",type:"text",advanced:true,label:{fr:"Chemin du tableau JSON (facultatif)",en:"JSON array path (optional)"},help:{fr:"Laisser vide si la réponse API est directement un tableau. Exemple : data.items pour une réponse imbriquée.",en:"Leave blank if the API response is directly an array. Example: data.items for a nested response."}},
                        {key:"source.apiValuePath",type:"text",advanced:true,label:{fr:"Propriété JSON contenant la valeur",en:"JSON property containing value"},help:{fr:"Ex. library_id, item_type_id, value.",en:"E.g. library_id, item_type_id, value."}},
                        {key:"source.apiLabelPath",type:"text",advanced:true,label:{fr:"Propriété JSON contenant le libellé",en:"JSON property containing label"},help:{fr:"Ex. name, description. Si vide, la valeur est utilisée comme libellé.",en:"E.g. name, description. If blank, the value is also used as label."}},
                        {key:"source.fallbackToForm",type:"boolean",label:{fr:"Revenir aux options du formulaire si la source échoue",en:"Fall back to form options if the source fails"}},
                        {key:"source.manualValues",type:"repeater",label:{fr:"Valeurs manuelles",en:"Manual values"},addLabel:{fr:"Ajouter une valeur",en:"Add value"},reorder:true,newItem:function(){return {enabled:true,value:"",labelFr:"",labelEn:""};},itemTitle:function(item,index,lang){if(!item)return "#"+(index+1);return String((lang==="en"?item.labelEn:item.labelFr)||item.labelFr||item.labelEn||item.value||("#"+(index+1)));},fields:[
                            {key:"enabled",type:"boolean",label:{fr:"Valeur active",en:"Value enabled"}},
                            {key:"value",type:"text",label:{fr:"Valeur stockée",en:"Stored value"}},
                            {key:"labelFr",type:"text",label:{fr:"Libellé français",en:"French label"}},
                            {key:"labelEn",type:"text",label:{fr:"Libellé anglais",en:"English label"}}
                        ]},
                        {key:"allowClear",type:"boolean",label:{fr:"Autoriser le vidage si Koha le permet",en:"Allow clearing when Koha allows it"}},
                        {key:"copyEligible",type:"boolean",label:{fr:"Inclure dans « Copier au + nombreux »",en:"Include in Copy majority"}},
                        {key:"normalize",type:"select",advanced:true,label:{fr:"Normalisation",en:"Normalization"},options:[{value:"none",label:{fr:"Aucune",en:"None"}},{value:"price",label:{fr:"Prix : virgule vers point",en:"Price: comma to dot"}}]}
                    ]}
                ]},
                { type:"section", id:"majority", label:{fr:"Copier au + nombreux",en:"Copy majority"}, description:{fr:"Les valeurs historiques sont conservées : au moins 2 occurrences, plus de 50 % des exemplaires et aucune égalité.",en:"Historical defaults are preserved: at least 2 occurrences, more than 50% of items and no tie."}, fields:[
                    {key:"copyMajority.enabled",type:"boolean",label:{fr:"Activer la fonction",en:"Enable feature"}},
                    {key:"copyMajority.minOccurrences",type:"number",min:1,max:999,advanced:true,label:{fr:"Nombre minimal d’occurrences",en:"Minimum occurrences"}},
                    {key:"copyMajority.thresholdPercent",type:"number",min:0,max:100,advanced:true,label:{fr:"Seuil de majorité (%)",en:"Majority threshold (%)"}},
                    {key:"copyMajority.strictGreaterThanThreshold",type:"boolean",advanced:true,label:{fr:"Exiger strictement plus que le seuil",en:"Require strictly more than threshold"}},
                    {key:"copyMajority.rejectTies",type:"boolean",advanced:true,label:{fr:"Ne rien reprendre en cas d’égalité",en:"Copy nothing on ties"}}
                ]},
                { type:"section", id:"presets", label:{fr:"Mémorisations",en:"Presets"}, description:{fr:"Le mode « listes nominatives historiques » reste le défaut afin de conserver tes listes Koha actuelles. Les modes commun et compte Koha sont disponibles pour la migration, sans modifier l’usage actuel tant qu’ils ne sont pas sélectionnés.",en:"Historical named lists remain the default to preserve existing Koha data. Shared and Koha-account modes are available for migration without changing current use until selected."}, fields:[
                    {key:"presets.enabled",type:"boolean",label:{fr:"Activer les mémorisations",en:"Enable presets"}},
                    {key:"presets.mode",type:"select",label:{fr:"Mode des listes",en:"Preset list mode"},options:[
                        {value:"legacyNamed",label:{fr:"Listes nominatives historiques (compatibilité production)",en:"Historical named lists (production compatibility)"}},
                        {value:"common",label:{fr:"Une liste commune à tous",en:"One shared list for everyone"}},
                        {value:"kohaUser",label:{fr:"Liste selon le compte Koha connecté",en:"List for signed-in Koha account"}}
                    ]},
                    {key:"presets.maxPresets",type:"number",min:1,max:500,label:{fr:"Nombre maximum de mémorisations",en:"Maximum presets"}},
                    {key:"presets.rememberSelectedList",type:"boolean",advanced:true,label:{fr:"Mémoriser la liste nominative sélectionnée",en:"Remember selected named list"}},
                    {key:"presets.collection",type:"text",advanced:true,label:{fr:"Collection Koha des mémorisations",en:"Koha preset collection"}}
                ]},
                { type:"section", id:"legacy-storage", label:{fr:"Stockage Koha provisoire",en:"Temporary Koha storage"}, description:{fr:"Compatibilité transitoire avec la production actuelle. Lors du passage au plugin natif, les mémorisations devront être stockées côté Koha.",en:"Temporary compatibility with current production. In the native plugin, presets should be stored in Koha."}, fields:[
                ]}
            ]
        });

        window.PMKConfig.getConfig(MODULE_ID).then(function (cfg) {
            currentConfig = normalizeConfig(cfg || {});
            scheduleRender(0);
        }).catch(function () {
            currentConfig = normalizeConfig(DEFAULT_CONFIG);
            scheduleRender(0);
        });
        if (typeof window.PMKConfig.subscribe === "function") {
            unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                currentConfig = normalizeConfig(cfg || {});
                scheduleRender(0);
            });
        }
        return true;
    }

    function scheduleRender(delay) {
        if (!supportedPage()) return;
        if (renderTimer) clearTimeout(renderTimer);
        renderTimer = setTimeout(function () { waitForBody().then(createPanel); }, delay == null ? 100 : delay);
    }

    function bootstrap() {
        currentConfig = normalizeConfig(DEFAULT_CONFIG);
        if (supportedPage()) loadAuthorisedValueCategories(false).catch(function () {});
        if (registerWithPMK()) {
            if (supportedPage()) scheduleRender(0);
            return;
        }
        window.addEventListener("pmk:config-ready", function () { registerWithPMK(); }, { once:true });
        /* Non-régression : si PMK n'est pas encore disponible, l'assistant historique reste utilisable avec ses défauts. */
        if (supportedPage()) scheduleRender(500);
    }

    window.PMK110ItemEntryAssistant = Object.freeze({
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        getConfig: function () { return clone(currentConfig); },
        refresh: function () { scheduleRender(0); },
        refreshAuthorisedValueCategories: function () { return loadAuthorisedValueCategories(true); },
        getAuthorisedValueCategories: function () { return authorisedValueCategoryCache.slice(); },
        loadFieldOptions: function (fieldId) {
            const field = activeFields().find(function (candidate) { return candidate.id === fieldId; });
            if (!field) return Promise.resolve([]);
            return loadFieldOptions(field, getFieldElement(field));
        },
        detectFields: function () {
            return activeFields().map(function (field) {
                const el = getFieldElement(field);
                return { id:field.id, kohafield:field.kohafield, found:!!el, tagName:el ? el.tagName : null, type:el ? fieldType(field,el) : null };
            });
        },
        diagnoseFields: function (config, root) { return diagnoseConfiguredFields(config || currentConfig, root); },
        dependencySatisfied: function (field, values) { return dependencySatisfied(field, values || {}); }
    });

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bootstrap, { once:true });
    else bootstrap();
})();

;window.PMKNonPlugin.loaded.push("110-exemplaire-helper.js");
} catch (error) { window.PMKNonPlugin.errors.push("110-exemplaire-helper.js: "+error.message); console.error("[PMK] 110-exemplaire-helper.js",error); };
try {
/* ============================================================================
 * 111-internal-share.js
 * PimpMyKoha — Partage interne
 * Version : 4.0.0-preplugin
 * Date    : 2026-09-20
 *
 * Objectifs :
 * - conserver le comportement métier historique du 111 ;
 * - rendre les paramètres utiles administrables dans PMK ;
 * - adopter un design plus intégré à Koha ;
 * - stocker les partages dans l'API/BDD native du plugin Koha ;
 * - conserver les anciens noms de configuration seulement pour relire les sauvegardes historiques.
 *
 * IMPORTANT : ce module ne modifie jamais une donnée métier Koha.
 * Il partage uniquement un lien interne Koha + du contexte + un statut.
 * ========================================================================== */
(function () {
    'use strict';

    if (window.__PMK111_INTERNAL_SHARE__) return;
    window.__PMK111_INTERNAL_SHARE__ = true;

    const MODULE_ID = 'internal-share';
    const VERSION = '4.0.0-preplugin';
    const STYLE_ID = 'pmk111-styles';
    const ROOT_ID = 'pmk111-root';
    const MODAL_ID = 'pmk111-share-modal';
    const STATUS_MODAL_ID = 'pmk111-status-modal';
    const DIAG_ID = 'pmk111-diagnostics';
    const SESSION_USER_KEY = 'pmk111-session-user-id';
    const COLLAPSE_PREFIX = 'pmk111-collapsed-';
    const DIAG_KEY = 'pmk111-connection-log';

    const PAGE_DEFINITIONS = [
        {
            id: 'catalogue.detail', path: '/cgi-bin/koha/catalogue/detail.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar', position: 'append',
            labelFr: 'Notice détaillée', labelEn: 'Bibliographic detail',
            titleTemplateFr: '{title}', titleTemplateEn: '{title}'
        },
        {
            id: 'catalogue.search', path: '/cgi-bin/koha/catalogue/search.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#selection_ops', position: 'append',
            labelFr: 'Résultats catalogue', labelEn: 'Catalog results',
            titleTemplateFr: 'Recherche : {query}', titleTemplateEn: 'Search: {query}'
        },
        {
            id: 'members.moremember', path: '/cgi-bin/koha/members/moremember.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar.btn-toolbar, #toolbar', position: 'append',
            labelFr: 'Fiche lecteur', labelEn: 'Patron details',
            titleTemplateFr: 'Fiche : {name}', titleTemplateEn: 'Patron: {name}'
        },
        {
            id: 'circ.circulation', path: '/cgi-bin/koha/circ/circulation.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar.btn-toolbar, #toolbar', position: 'append',
            labelFr: 'Prêt', labelEn: 'Circulation',
            titleTemplateFr: 'Prêt : {name}', titleTemplateEn: 'Circulation: {name}'
        },
        {
            id: 'members.readingrec', path: '/cgi-bin/koha/members/readingrec.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar.btn-toolbar, #toolbar', position: 'append',
            labelFr: 'Historique de lecture', labelEn: 'Reading history',
            titleTemplateFr: 'Hist. lecture : {name}', titleTemplateEn: 'Reading history: {name}'
        },
        {
            id: 'members.holdshistory', path: '/cgi-bin/koha/members/holdshistory.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar.btn-toolbar, #toolbar', position: 'append',
            labelFr: 'Historique des réservations', labelEn: 'Hold history',
            titleTemplateFr: 'Hist. réserv. : {name}', titleTemplateEn: 'Hold history: {name}'
        },
        {
            id: 'members.notices', path: '/cgi-bin/koha/members/notices.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar.btn-toolbar, #toolbar', position: 'append',
            labelFr: 'Notifications lecteur', labelEn: 'Patron notices',
            titleTemplateFr: 'Notifications : {name}', titleTemplateEn: 'Notices: {name}'
        },
        {
            id: 'cataloguing.additem', path: '/cgi-bin/koha/cataloguing/additem.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: 'h1', position: 'append',
            labelFr: 'Exemplaires', labelEn: 'Items',
            titleTemplateFr: '{title}', titleTemplateEn: '{title}'
        },
        {
            id: 'cataloguing.addbiblio', path: '/cgi-bin/koha/cataloguing/addbiblio.pl', enabled: true,
            shareMode: 'page', placementMode: 'auto', selector: '#toolbar, .main-toolbar, #breadcrumbs', position: 'append',
            labelFr: 'Catalogage notice', labelEn: 'Cataloging',
            titleTemplateFr: '{catalogingTitle}', titleTemplateEn: '{catalogingTitle}'
        },
        {
            id: 'reserve.request', path: '/cgi-bin/koha/reserve/request.pl', enabled: true,
            shareMode: 'reservationRows', placementMode: 'auto', selector: '', position: 'append',
            labelFr: 'Réservations', labelEn: 'Holds',
            titleTemplateFr: 'Réservation : {patron}', titleTemplateEn: 'Hold: {patron}',
            noteTemplateFr: 'Lecteur : {patron}\nPriorité/Statut : {priority}',
            noteTemplateEn: 'Patron: {patron}\nPriority/status: {priority}'
        }
    ];

    const DEFAULT_STATUSES = [
        {
            id: 'trouve', enabled: true, variant: 'success', icon: 'fa-check', terminal: false,
            commentPolicy: 'optional',
            labelFr: 'Résolu', labelEn: 'Resolved',
            reservationLabelFr: 'Trouvé', reservationLabelEn: 'Found',
            textFr: 'Résolu', textEn: 'Resolved',
            reservationTextFr: 'Document trouvé', reservationTextEn: 'Document found'
        },
        {
            id: 'non_trouve', enabled: true, variant: 'danger', icon: 'fa-times', terminal: false,
            commentPolicy: 'optional',
            labelFr: 'Non résolu', labelEn: 'Unresolved',
            reservationLabelFr: 'Introuvable', reservationLabelEn: 'Not found',
            textFr: 'Non résolu', textEn: 'Unresolved',
            reservationTextFr: 'Introuvable', reservationTextEn: 'Not found'
        },
        {
            id: 'transmis', enabled: true, variant: 'info', icon: 'fa-arrow-right', terminal: false,
            commentPolicy: 'optional',
            labelFr: 'Transmis', labelEn: 'Forwarded',
            reservationLabelFr: 'Transmis', reservationLabelEn: 'Handed over',
            textFr: 'Transmis', textEn: 'Forwarded',
            reservationTextFr: 'Transmis au lecteur', reservationTextEn: 'Handed to patron'
        },
        {
            id: 'autre', enabled: true, variant: 'warning', icon: 'fa-tag', terminal: false,
            commentPolicy: 'required',
            labelFr: 'Autre…', labelEn: 'Other…',
            reservationLabelFr: 'Autre…', reservationLabelEn: 'Other…',
            textFr: 'Autre statut', textEn: 'Other status',
            reservationTextFr: 'Autre statut', reservationTextEn: 'Other status'
        }
    ];

    const DEFAULT_FIREBASE_CONFIG = {}; // Anciennes options conservées uniquement dans les sauvegardes.

    const DEFAULT_CONFIG = {
        enabled: true,
        sites: [
            {
                id: 'draguignan', enabled: true,
                labelFr: 'Draguignan', labelEn: 'Draguignan',
                matchName: 'DRAGUIGNAN', matchCode: 'DRA',
                canSend: true, canReceive: true, channel: 'draguignan'
            }
        ],
        pages: PAGE_DEFINITIONS.map(clone),
        routing: {
            mode: 'broadcastSite',
            acceptLegacyUntargeted: true,
            allowFreeRecipient: true,
            recipientRequired: false,
            targets: []
        },
        lifetime: {
            ttlMinutes: 5,
            showCountdown: true,
            warningBeforeSeconds: 60,
            cleanupExpired: true,
            deleteOnTerminal: false,
            deleteAfterTerminalSeconds: 0
        },
        workflow: {
            initialStatus: 'en_attente',
            initialTextFr: 'En attente',
            initialTextEn: 'Pending',
            statuses: DEFAULT_STATUSES.map(clone)
        },
        permissions: {
            statusUpdatePolicy: 'anyViewer',
            deletePolicy: 'creator',
            allowSuperlibrarianDelete: true
        },
        appearance: {
            mode: 'koha',
            position: 'bottom-right',
            widthPx: 390,
            maxVisible: 0,
            newestFirst: false,
            rememberCollapsed: true,
            collapsedByDefault: false,
            compactOnMobile: true,
            mobileBreakpointPx: 576,
            showCreator: true,
            showSenderSite: false,
            showUsageCount: true,
            showConnectionStatus: true,
            showDiagnostics: true,
            buttonLabelFr: 'Partage interne',
            buttonLabelEn: 'Internal share',
            modalTitleFr: 'Partager cette page',
            modalTitleEn: 'Share this page',
            recipientLabelFr: 'Destinataire (optionnel)',
            recipientLabelEn: 'Recipient (optional)',
            recipientPlaceholderFr: 'Ex. Bureau, Accueil, prénom…',
            recipientPlaceholderEn: 'e.g. Desk, Front desk, name…',
            noteLabelFr: 'Informations supplémentaires (optionnel)',
            noteLabelEn: 'Additional information (optional)',
            notePlaceholderFr: 'Ex. À rechercher pour le comptoir…',
            notePlaceholderEn: 'e.g. Please locate for the desk…'
        },
        identity: {
            preferKohaUsername: true,
            fallbackToSessionId: true,
            usernameSelector: '#logged-in-info-full .loggedinusername[data-loggedinusername], .loggedinusername[data-loggedinusername]'
        },
        storage: {
            mode: 'koha',
            firebaseLegacy: {
                enabled: true,
                sdkVersion: '10.7.1',
                appName: 'pmk111-internal-share',
                sharesPath: 'shares',
                usagePath: 'stats/usage_count',
                config: clone(DEFAULT_FIREBASE_CONFIG)
            },
            pluginApi: {
                basePath: '/api/v1/contrib/pimpmykoha/internal-share',
                pollingMs: 4000,
                stopWhenHidden: true,
                credentials: 'same-origin'
            }
        },
        diagnostics: {
            enabled: true,
            maxEntries: 50,
            logToConsole: false
        }
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let currentSite = null;
    let currentIdentity = null;
    let currentStore = null;
    let currentPage = null;
    let configRegistered = false;
    let unsubscribeConfig = null;
    let injectionObserver = null;
    let injectionTimer = null;
    let runtimeGeneration = 0;
    let usageCount = 0;
    let shareMap = new Map();
    let timerMap = new Map();
    let processingShare = false;
    let processingStatus = false;
    let pendingShareContext = null;
    let pendingStatus = null;

    function clone(value) {
        if (value === undefined) return undefined;
        return JSON.parse(JSON.stringify(value));
    }

    function deepMerge(base, incoming) {
        if (Array.isArray(base)) return Array.isArray(incoming) ? clone(incoming) : clone(base);
        if (!base || typeof base !== 'object') return incoming === undefined ? base : incoming;
        const out = clone(base);
        if (!incoming || typeof incoming !== 'object') return out;
        Object.keys(incoming).forEach(function (key) {
            const value = incoming[key];
            if (Array.isArray(value)) out[key] = clone(value);
            else if (value && typeof value === 'object' && out[key] && typeof out[key] === 'object' && !Array.isArray(out[key])) out[key] = deepMerge(out[key], value);
            else if (value !== undefined) out[key] = value;
        });
        return out;
    }

    function normalizeConfig(config) {
        const merged = deepMerge(DEFAULT_CONFIG, config || {});
        merged.storage.mode = "koha";
        merged.pages = Array.isArray(config && config.pages) ? config.pages.map(function (page, i) {
            return deepMerge(PAGE_DEFINITIONS[i] || {}, page || {});
        }) : PAGE_DEFINITIONS.map(clone);
        if (!merged.pages.length) merged.pages = PAGE_DEFINITIONS.map(clone);
        merged.workflow.statuses = Array.isArray(merged.workflow.statuses) && merged.workflow.statuses.length
            ? merged.workflow.statuses.map(function (status, i) { return deepMerge(DEFAULT_STATUSES[i] || {}, status || {}); })
            : DEFAULT_STATUSES.map(clone);
        merged.sites = Array.isArray(merged.sites) ? merged.sites : clone(DEFAULT_CONFIG.sites);
        merged.routing.targets = Array.isArray(merged.routing.targets) ? merged.routing.targets : [];
        merged.lifetime.ttlMinutes = clampNumber(merged.lifetime.ttlMinutes, 1, 1440, 5);
        merged.lifetime.warningBeforeSeconds = clampNumber(merged.lifetime.warningBeforeSeconds, 0, 86400, 60);
        merged.appearance.widthPx = clampNumber(merged.appearance.widthPx, 280, 760, 390);
        merged.appearance.maxVisible = clampNumber(merged.appearance.maxVisible, 0, 100, 0);
        merged.appearance.mobileBreakpointPx = clampNumber(merged.appearance.mobileBreakpointPx, 320, 1200, 576);
        merged.storage.pluginApi.pollingMs = clampNumber(merged.storage.pluginApi.pollingMs, 1000, 60000, 4000);
        merged.diagnostics.maxEntries = clampNumber(merged.diagnostics.maxEntries, 10, 500, 50);
        return merged;
    }

    function clampNumber(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function lang() {
        const raw = String(document.documentElement.lang || '').toLowerCase();
        return raw.indexOf('en') === 0 ? 'en' : 'fr';
    }

    function tr(fr, en) {
        return lang() === 'en' ? (en || fr || '') : (fr || en || '');
    }

    function clean(value) {
        return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    }

    function norm(value) {
        return clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }


    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(String(value));
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (ch) { return '\\' + ch; });
    }

    function safeId(value) {
        return norm(value).replace(/\s+/g, '-').replace(/[^a-z0-9_.-]/g, '').slice(0, 120);
    }

    function esc(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
            return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch];
        });
    }

    function safeInternalUrl(value) {
        try {
            const url = new URL(String(value || ''), window.location.origin);
            if (!/^https?:$/.test(url.protocol) || url.origin !== window.location.origin) return null;
            return url.href;
        } catch (_) {
            return null;
        }
    }

    function currentPath() {
        return window.location.pathname;
    }

    function pageConfigForPath(pathname) {
        const pages = currentConfig.pages || [];
        return pages.find(function (p) { return p && p.enabled !== false && p.path === pathname; }) || null;
    }

    function branchInfo() {
        let name = '';
        let code = '';
        const nameEl = document.querySelector('.logged-in-branch-name, #logged-in-info-full .logged-in-branch-name');
        if (nameEl) name = clean(nameEl.textContent);
        const codeEl = document.querySelector('.logged-in-branch-code, [data-branchcode], [data-branch-code]');
        if (codeEl) code = clean(codeEl.getAttribute('data-branchcode') || codeEl.getAttribute('data-branch-code') || codeEl.textContent);
        return { name:name, code:code };
    }

    function resolveSite(info) {
        if (!info) return null;
        const nName = norm(info.name);
        const nCode = norm(info.code);
        return (currentConfig.sites || []).find(function (site) {
            if (!site || site.enabled === false) return false;
            const names = [site.matchName, site.labelFr, site.labelEn].filter(Boolean).map(norm);
            const codes = [site.matchCode, site.id].filter(Boolean).map(norm);
            return (!!nName && names.indexOf(nName) !== -1) || (!!nCode && codes.indexOf(nCode) !== -1);
        }) || null;
    }

    function readKohaUsername() {
        const selector = clean(currentConfig.identity && currentConfig.identity.usernameSelector) || DEFAULT_CONFIG.identity.usernameSelector;
        let el = null;
        try { el = document.querySelector(selector); } catch (_) {}
        if (!el) return '';
        return clean(el.getAttribute('data-loggedinusername') || el.textContent);
    }

    function sessionIdentity() {
        let value = '';
        try { value = sessionStorage.getItem(SESSION_USER_KEY) || ''; } catch (_) {}
        if (!value) {
            const randomPart = window.crypto && typeof window.crypto.randomUUID === 'function'
                ? window.crypto.randomUUID()
                : Math.random().toString(36).slice(2) + Date.now().toString(36);
            value = 'session:' + randomPart;
            try { sessionStorage.setItem(SESSION_USER_KEY, value); } catch (_) {}
        }
        return value;
    }

    function resolveIdentity() {
        const username = currentConfig.identity.preferKohaUsername !== false ? readKohaUsername() : '';
        if (username) return { id:'koha:' + safeId(username), username:username, label:username, source:'koha' };
        if (currentConfig.identity.fallbackToSessionId !== false) {
            const id = sessionIdentity();
            return { id:id, username:'', label:tr('Cette session', 'This session'), source:'session' };
        }
        return { id:'anonymous', username:'', label:tr('Utilisateur', 'User'), source:'anonymous' };
    }

    function isSuperlibrarian() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === 'function') {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }
        const el = document.querySelector('#logged-in-info-full .loggedinusername[data-loggedinusername], .loggedinusername[data-loggedinusername]');
        if (!el) return false;
        return el.dataset.isSuperlibrarian === 'is_superlibrarian' || el.classList.contains('is_superlibrarian');
    }

    function addDiagnostic(status, message, details) {
        if (!(currentConfig.diagnostics && currentConfig.diagnostics.enabled)) return;
        const entry = {
            timestamp: new Date().toISOString(),
            time: new Date().toLocaleTimeString(),
            status: status || 'info',
            message: clean(message),
            details: clean(details),
            page: currentPath()
        };
        let list = [];
        try { list = JSON.parse(localStorage.getItem(DIAG_KEY) || '[]') || []; } catch (_) {}
        list.unshift(entry);
        list.length = Math.min(list.length, currentConfig.diagnostics.maxEntries || 50);
        try { localStorage.setItem(DIAG_KEY, JSON.stringify(list)); } catch (_) {}
        if (currentConfig.diagnostics.logToConsole && window.console) {
            try { console.info('[PMK111]', status, message, details || ''); } catch (_) {}
        }
        renderDiagnostics();
    }

    function readDiagnostics() {
        try { return JSON.parse(localStorage.getItem(DIAG_KEY) || '[]') || []; } catch (_) { return []; }
    }

    function clearDiagnostics() {
        try { localStorage.removeItem(DIAG_KEY); } catch (_) {}
        renderDiagnostics();
    }

    function statusById(id) {
        return (currentConfig.workflow.statuses || []).find(function (s) { return s && s.enabled !== false && s.id === id; }) || null;
    }

    function isReservationShare(data) {
        return String(data && data.kind || '') === 'reservation' || /^Réservation\s*:/i.test(String(data && data.title || ''));
    }

    function statusDisplay(data) {
        const status = String(data && data.status || currentConfig.workflow.initialStatus || 'en_attente');
        if (status === currentConfig.workflow.initialStatus || status === 'en_attente') {
            return {
                id: status,
                variant: 'default',
                icon: 'fa-clock-o',
                text: tr(currentConfig.workflow.initialTextFr, currentConfig.workflow.initialTextEn),
                label: tr(currentConfig.workflow.initialTextFr, currentConfig.workflow.initialTextEn)
            };
        }
        const cfg = statusById(status);
        if (!cfg) return { id:status, variant:'default', icon:'fa-info-circle', text:status, label:status };
        const reservation = isReservationShare(data);
        return {
            id: cfg.id,
            variant: cfg.variant || 'default',
            icon: cfg.icon || 'fa-circle',
            text: reservation
                ? tr(cfg.reservationTextFr || cfg.textFr, cfg.reservationTextEn || cfg.textEn)
                : tr(cfg.textFr, cfg.textEn),
            label: reservation
                ? tr(cfg.reservationLabelFr || cfg.labelFr, cfg.reservationLabelEn || cfg.labelEn)
                : tr(cfg.labelFr, cfg.labelEn)
        };
    }

    function shareExpiry(data) {
        const explicit = Number(data && data.expiresAt);
        if (Number.isFinite(explicit) && explicit > 0) return explicit;
        const ts = Number(data && data.timestamp);
        if (!Number.isFinite(ts)) return 0;
        return ts + currentConfig.lifetime.ttlMinutes * 60000;
    }

    function isExpired(data) {
        const expiry = shareExpiry(data);
        return !expiry || Date.now() >= expiry;
    }

    function targetVisible(data) {
        const target = data && data.target;
        if (!target || !target.type) {
            if (!currentConfig.routing.acceptLegacyUntargeted) return false;
            if (!data.sender && !data.senderSiteId) return true;
            const sender = norm(data.senderSiteId || data.sender || '');
            return [currentSite.id, currentSite.matchCode, currentSite.matchName, currentSite.labelFr, currentSite.labelEn].filter(Boolean).map(norm).indexOf(sender) !== -1;
        }
        const type = String(target.type);
        const value = norm(target.value || '');
        if (type === 'all') return true;
        if (type === 'site') {
            return [currentSite.id, currentSite.matchCode, currentSite.matchName, currentSite.labelFr, currentSite.labelEn].filter(Boolean).map(norm).indexOf(value) !== -1;
        }
        if (type === 'channel') return norm(currentSite.channel || currentSite.id) === value;
        if (type === 'user') return currentIdentity && [currentIdentity.id, currentIdentity.username].filter(Boolean).map(norm).indexOf(value) !== -1;
        return false;
    }

    function canUpdateStatus(data) {
        const policy = currentConfig.permissions.statusUpdatePolicy;
        if (policy === 'creator') return data && data.createdBy === currentIdentity.id;
        if (policy === 'superlibrarian') return isSuperlibrarian();
        return true;
    }

    function canDelete(data) {
        const creator = data && data.createdBy === currentIdentity.id;
        if (currentConfig.permissions.allowSuperlibrarianDelete && isSuperlibrarian()) return true;
        const policy = currentConfig.permissions.deletePolicy;
        if (policy === 'anyViewer') return true;
        if (policy === 'superlibrarian') return isSuperlibrarian();
        return creator;
    }

    function currentTargetForNewShare(selectedTargetId) {
        const mode = currentConfig.routing.mode;
        if (mode === 'broadcastAll') return { type:'all', value:'all', label:tr('Tous', 'All') };
        if (mode === 'broadcastChannel') return { type:'channel', value:currentSite.channel || currentSite.id, label:currentSite.labelFr || currentSite.id };
        if (mode === 'targeted') {
            const target = (currentConfig.routing.targets || []).find(function (t) { return t && t.enabled !== false && t.id === selectedTargetId; });
            if (!target) return null;
            return { type:target.type || 'site', value:target.value || target.id, label:tr(target.labelFr, target.labelEn) };
        }
        return { type:'site', value:currentSite.id, label:tr(currentSite.labelFr, currentSite.labelEn) };
    }

    function positionClass() {
        const p = String(currentConfig.appearance.position || 'bottom-right');
        return ['bottom-right','bottom-left','top-right','top-left'].indexOf(p) !== -1 ? p : 'bottom-right';
    }

    function ensureStyles() {
        let style = document.getElementById(STYLE_ID);
        if (style) style.remove();
        style = document.createElement('style');
        style.id = STYLE_ID;
        const width = currentConfig.appearance.widthPx;
        const mobile = currentConfig.appearance.mobileBreakpointPx;
        style.textContent = `
#${ROOT_ID}{position:fixed;z-index:1040;width:min(${width}px,calc(100vw - 24px));display:flex;flex-direction:column;gap:8px;pointer-events:none;}
#${ROOT_ID}.bottom-right{right:16px;bottom:16px;align-items:flex-end;}#${ROOT_ID}.bottom-left{left:16px;bottom:16px;align-items:flex-start;}#${ROOT_ID}.top-right{right:16px;top:72px;align-items:flex-end;}#${ROOT_ID}.top-left{left:16px;top:72px;align-items:flex-start;}
.pmk111-card{pointer-events:auto;width:100%;background:#fff;color:#212529;border:1px solid #d8dee4;border-left:4px solid #6c757d;border-radius:.35rem;box-shadow:0 2px 8px rgba(0,0,0,.14);overflow:hidden;}
.pmk111-card[data-variant="success"]{border-left-color:#398439}.pmk111-card[data-variant="danger"]{border-left-color:#ac2925}.pmk111-card[data-variant="info"]{border-left-color:#269abc}.pmk111-card[data-variant="warning"]{border-left-color:#d58512}
.pmk111-card-head{display:flex;align-items:flex-start;gap:.5rem;padding:.6rem .7rem .35rem;background:#f8f9fa;border-bottom:1px solid #e5e7e9}.pmk111-card-title{flex:1;min-width:0;font-weight:600;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pmk111-card-head .btn{padding:1px 6px;line-height:1.25}.pmk111-body{padding:.55rem .7rem}.pmk111-meta{font-size:.86em;color:#6c757d;margin-bottom:.25rem}.pmk111-recipient{font-weight:600;margin-bottom:.25rem}.pmk111-delivery-state{font-size:.82em;color:#526273;margin:.2rem 0}.pmk111-note,.pmk111-comment{padding:.4rem .5rem;background:#f8f9fa;border-left:3px solid #ced4da;border-radius:.2rem;white-space:pre-wrap;overflow-wrap:anywhere;margin:.35rem 0}.pmk111-statusline{display:flex;align-items:center;gap:.35rem;font-weight:600;margin:.3rem 0}.pmk111-actions{display:flex;align-items:center;flex-wrap:wrap;gap:.35rem;margin-top:.45rem}.pmk111-actions .btn{font-size:12px;padding:3px 7px}.pmk111-footer{display:flex;justify-content:space-between;gap:.5rem;align-items:center;margin-top:.45rem;font-size:.82em;color:#6c757d}.pmk111-footer a{font-weight:600}.pmk111-timer.is-ending{color:#8a6d3b;font-weight:600}.pmk111-collapsed .pmk111-body{display:none}.pmk111-collapse-handle{pointer-events:auto;border-radius:50%;width:32px;height:32px;padding:0;display:none}.pmk111-collapsed .pmk111-collapse-handle{display:inline-flex;align-items:center;justify-content:center}.pmk111-collapsed .pmk111-card{display:none}.pmk111-item{width:100%;display:flex;flex-direction:column;align-items:inherit;gap:4px}.pmk111-row-share{margin-left:6px;padding:1px 5px;font-size:11px;vertical-align:middle}.pmk111-config-anchor{display:inline-flex;align-items:center;margin-left:.35rem}
.pmk111-overlay{position:fixed;inset:0;z-index:1060;background:rgba(0,0,0,.42);display:none;align-items:center;justify-content:center;padding:1rem}.pmk111-overlay.is-open{display:flex}.pmk111-dialog{width:min(520px,100%);max-height:calc(100vh - 2rem);overflow:auto;background:#fff;border:1px solid rgba(0,0,0,.2);border-radius:.35rem;box-shadow:0 5px 15px rgba(0,0,0,.35)}.pmk111-dialog-head{display:flex;align-items:center;justify-content:space-between;gap:.75rem;padding:12px 15px;border-bottom:1px solid #e5e5e5}.pmk111-dialog-head h3{font-size:18px;margin:0}.pmk111-dialog-body{padding:15px}.pmk111-dialog-foot{display:flex;justify-content:flex-end;gap:.5rem;padding:10px 15px;border-top:1px solid #e5e5e5;background:#f8f9fa}.pmk111-dialog label{font-weight:600}.pmk111-dialog .form-control{width:100%}.pmk111-statusbox{display:flex;align-items:center;gap:.45rem;font-size:12px;color:#6c757d}.pmk111-dot{width:8px;height:8px;border-radius:50%;display:inline-block;background:#999}.pmk111-dot.connected{background:#398439}.pmk111-dot.connecting{background:#d58512}.pmk111-dot.error{background:#ac2925}.pmk111-diagnostics{position:fixed;z-index:1065;right:18px;bottom:18px;width:min(620px,calc(100vw - 36px));max-height:55vh;overflow:auto;background:#fff;border:1px solid #ccc;border-radius:.35rem;box-shadow:0 4px 16px rgba(0,0,0,.2);display:none}.pmk111-diagnostics.is-open{display:block}.pmk111-diag-head{display:flex;justify-content:space-between;align-items:center;padding:.55rem .7rem;border-bottom:1px solid #ddd;background:#f8f9fa}.pmk111-diag-list{font-family:monospace;font-size:11px}.pmk111-diag-row{display:grid;grid-template-columns:72px 82px minmax(120px,1fr) minmax(100px,1fr);gap:.4rem;padding:.35rem .55rem;border-bottom:1px solid #eee}.pmk111-empty{padding:1rem;color:#6c757d;text-align:center}
.pmk111-legacy .pmk111-card{background:#2c3e50;color:#fff;border-color:#2c3e50}.pmk111-legacy .pmk111-card-head{background:#34495e;border-bottom-color:rgba(255,255,255,.12)}.pmk111-legacy .pmk111-meta,.pmk111-legacy .pmk111-footer{color:#bdc3c7}.pmk111-legacy .pmk111-note,.pmk111-legacy .pmk111-comment{background:rgba(0,0,0,.2);border-left-color:#95a5a6}.pmk111-legacy .pmk111-footer a{color:#7fd37f}
@media(max-width:${mobile}px){#${ROOT_ID}{left:8px!important;right:8px!important;top:auto!important;bottom:8px!important;width:auto}.pmk111-dialog{max-height:calc(100vh - 1rem)}.pmk111-dialog-body{padding:12px}.pmk111-actions .btn{flex:1 1 auto}.pmk111-diag-row{grid-template-columns:64px 72px 1fr}.pmk111-diag-row span:last-child{grid-column:1/-1}.pmk111-row-share{min-width:30px}.pmk111-compact-mobile .pmk111-note,.pmk111-compact-mobile .pmk111-comment{max-height:5.2em;overflow:auto}}
        `;
        document.head.appendChild(style);
    }

    function ensureRoot() {
        let root = document.getElementById(ROOT_ID);
        if (!root) {
            root = document.createElement('div');
            root.id = ROOT_ID;
            document.body.appendChild(root);
        }
        root.className = positionClass();
        if (currentConfig.appearance.mode === 'legacyDark') root.classList.add('pmk111-legacy');
        if (currentConfig.appearance.compactOnMobile) root.classList.add('pmk111-compact-mobile');
        return root;
    }

    function mountConfigButton(anchor, sectionId) {
        if (!anchor || !isSuperlibrarian() || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== 'function') return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: 'append',
                contextKey: 'internal-share',
                context: { pageId: currentPage && currentPage.id || '', sectionId: sectionId || 'activation' }
            });
        } catch (_) {}
    }

    function ensureModals() {
        let overlay = document.getElementById(MODAL_ID);
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = MODAL_ID;
            overlay.className = 'pmk111-overlay';
            overlay.innerHTML = `
<div class="pmk111-dialog" role="dialog" aria-modal="true" aria-labelledby="pmk111-share-title">
 <div class="pmk111-dialog-head"><h3 id="pmk111-share-title"><i class="fa fa-share-alt" aria-hidden="true"></i> <span data-role="title"></span><span class="pmk111-config-anchor"></span></h3><button type="button" class="close" data-act="close" aria-label="Fermer"><span aria-hidden="true">×</span></button></div>
 <div class="pmk111-dialog-body">
  <div class="pmk111-statusbox" data-role="connection"><span class="pmk111-dot"></span><span data-role="connection-text"></span><button type="button" class="btn btn-link btn-xs" data-act="diagnostics" style="display:none"></button></div>
  <div class="form-group" data-role="target-wrap" style="display:none"><label data-role="target-label"></label><select class="form-control" data-role="target"></select></div>
  <div class="form-group" data-role="recipient-wrap"><label data-role="recipient-label"></label><input type="text" class="form-control" data-role="recipient"></div>
  <div class="form-group"><label data-role="note-label"></label><textarea class="form-control" rows="3" data-role="note"></textarea></div>
  <div class="text-muted" style="font-size:12px" data-role="usage"></div>
 </div>
 <div class="pmk111-dialog-foot"><button type="button" class="btn btn-default" data-act="cancel"></button><button type="button" class="btn btn-primary" data-act="confirm"><i class="fa fa-share-alt" aria-hidden="true"></i> <span></span></button></div>
</div>`;
            document.body.appendChild(overlay);
            overlay.addEventListener('click', function (e) { if (e.target === overlay && !processingShare) closeShareModal(); });
            overlay.querySelector('[data-act="close"]').addEventListener('click', closeShareModal);
            overlay.querySelector('[data-act="cancel"]').addEventListener('click', closeShareModal);
            overlay.querySelector('[data-act="confirm"]').addEventListener('click', executeShareFromModal);
            overlay.querySelector('[data-act="diagnostics"]').addEventListener('click', toggleDiagnostics);
        }

        let statusModal = document.getElementById(STATUS_MODAL_ID);
        if (!statusModal) {
            statusModal = document.createElement('div');
            statusModal.id = STATUS_MODAL_ID;
            statusModal.className = 'pmk111-overlay';
            statusModal.innerHTML = `
<div class="pmk111-dialog" role="dialog" aria-modal="true" aria-labelledby="pmk111-status-title">
 <div class="pmk111-dialog-head"><h3 id="pmk111-status-title"><i class="fa fa-info-circle" aria-hidden="true"></i> <span data-role="title"></span></h3><button type="button" class="close" data-act="close"><span aria-hidden="true">×</span></button></div>
 <div class="pmk111-dialog-body"><div class="form-group"><label data-role="comment-label"></label><textarea class="form-control" rows="3" data-role="comment"></textarea><p class="help-block" data-role="help"></p></div></div>
 <div class="pmk111-dialog-foot"><button type="button" class="btn btn-default" data-act="cancel"></button><button type="button" class="btn btn-primary" data-act="confirm"></button></div>
</div>`;
            document.body.appendChild(statusModal);
            statusModal.addEventListener('click', function (e) { if (e.target === statusModal && !processingStatus) closeStatusModal(); });
            statusModal.querySelector('[data-act="close"]').addEventListener('click', closeStatusModal);
            statusModal.querySelector('[data-act="cancel"]').addEventListener('click', closeStatusModal);
            statusModal.querySelector('[data-act="confirm"]').addEventListener('click', executeStatusFromModal);
        }

        document.addEventListener('keydown', onEscape, { passive:false });
        configureModalLabels();
        mountConfigButton(overlay.querySelector('.pmk111-config-anchor'), 'appearance');
    }

    function configureModalLabels() {
        const overlay = document.getElementById(MODAL_ID);
        if (!overlay) return;
        overlay.querySelector('[data-role="title"]').textContent = tr(currentConfig.appearance.modalTitleFr, currentConfig.appearance.modalTitleEn);
        overlay.querySelector('[data-role="recipient-label"]').textContent = tr(currentConfig.appearance.recipientLabelFr, currentConfig.appearance.recipientLabelEn);
        overlay.querySelector('[data-role="recipient"]').placeholder = tr(currentConfig.appearance.recipientPlaceholderFr, currentConfig.appearance.recipientPlaceholderEn);
        overlay.querySelector('[data-role="note-label"]').textContent = tr(currentConfig.appearance.noteLabelFr, currentConfig.appearance.noteLabelEn);
        overlay.querySelector('[data-role="note"]').placeholder = tr(currentConfig.appearance.notePlaceholderFr, currentConfig.appearance.notePlaceholderEn);
        overlay.querySelector('[data-act="cancel"]').textContent = tr('Annuler', 'Cancel');
        overlay.querySelector('[data-act="confirm"] span').textContent = tr('Partager', 'Share');
        overlay.querySelector('[data-role="target-label"]').textContent = tr('Diffuser à', 'Send to');
        overlay.querySelector('[data-act="diagnostics"]').textContent = tr('Diagnostic', 'Diagnostics');
    }

    function onEscape(e) {
        if (e.key !== 'Escape') return;
        if (document.getElementById(STATUS_MODAL_ID) && document.getElementById(STATUS_MODAL_ID).classList.contains('is-open') && !processingStatus) closeStatusModal();
        else if (document.getElementById(MODAL_ID) && document.getElementById(MODAL_ID).classList.contains('is-open') && !processingShare) closeShareModal();
        else if (document.getElementById(DIAG_ID) && document.getElementById(DIAG_ID).classList.contains('is-open')) toggleDiagnostics();
    }

    function connectionUI(status, message) {
        const overlay = document.getElementById(MODAL_ID);
        if (!overlay) return;
        const box = overlay.querySelector('[data-role="connection"]');
        if (!currentConfig.appearance.showConnectionStatus) { box.style.display = 'none'; return; }
        box.style.display = 'flex';
        const dot = box.querySelector('.pmk111-dot');
        dot.className = 'pmk111-dot ' + (status || '');
        box.querySelector('[data-role="connection-text"]').textContent = message || '';
        const diag = box.querySelector('[data-act="diagnostics"]');
        diag.style.display = currentConfig.appearance.showDiagnostics && currentConfig.diagnostics.enabled ? '' : 'none';
    }

    function openShareModal(context) {
        pendingShareContext = context || { kind:'page', title:generatePageTitle(currentPage), note:'' };
        const overlay = document.getElementById(MODAL_ID);
        if (!overlay) return;
        configureModalLabels();
        const recipient = overlay.querySelector('[data-role="recipient"]');
        const note = overlay.querySelector('[data-role="note"]');
        recipient.value = pendingShareContext.recipient || '';
        note.value = pendingShareContext.note || '';
        const recipientWrap = overlay.querySelector('[data-role="recipient-wrap"]');
        recipientWrap.style.display = currentConfig.routing.allowFreeRecipient ? '' : 'none';

        const targetWrap = overlay.querySelector('[data-role="target-wrap"]');
        const targetSelect = overlay.querySelector('[data-role="target"]');
        if (currentConfig.routing.mode === 'targeted') {
            targetWrap.style.display = '';
            targetSelect.innerHTML = '<option value="">' + esc(tr('Choisir…', 'Choose…')) + '</option>' +
                (currentConfig.routing.targets || []).filter(function (t) { return t && t.enabled !== false; }).map(function (t) {
                    return '<option value="' + esc(t.id) + '">' + esc(tr(t.labelFr, t.labelEn) || t.id) + '</option>';
                }).join('');
        } else {
            targetWrap.style.display = 'none';
            targetSelect.innerHTML = '';
        }
        overlay.querySelector('[data-role="usage"]').textContent = currentConfig.appearance.showUsageCount
            ? tr('Utilisations : ', 'Uses: ') + String(usageCount || 0) : '';
        connectionUI(currentStore && currentStore.isConnected && currentStore.isConnected() ? 'connected' : 'connecting',
            currentStore && currentStore.isConnected && currentStore.isConnected() ? tr('Connecté', 'Connected') : tr('Connexion…', 'Connecting…'));
        overlay.classList.add('is-open');
        window.setTimeout(function () { (currentConfig.routing.allowFreeRecipient ? recipient : note).focus(); }, 0);
    }

    function closeShareModal() {
        const overlay = document.getElementById(MODAL_ID);
        if (overlay) overlay.classList.remove('is-open');
        pendingShareContext = null;
        processingShare = false;
        setShareModalBusy(false);
    }

    function setShareModalBusy(busy) {
        const overlay = document.getElementById(MODAL_ID);
        if (!overlay) return;
        const btn = overlay.querySelector('[data-act="confirm"]');
        btn.disabled = !!busy;
        const span = btn.querySelector('span');
        span.textContent = busy ? tr('Envoi…', 'Sending…') : tr('Partager', 'Share');
        const icon = btn.querySelector('i');
        icon.className = busy ? 'fa fa-spinner fa-spin' : 'fa fa-share-alt';
    }

    async function executeShareFromModal() {
        if (processingShare || !pendingShareContext || !currentStore) return;
        const overlay = document.getElementById(MODAL_ID);
        const recipient = clean(overlay.querySelector('[data-role="recipient"]').value);
        const note = cleanMultiline(overlay.querySelector('[data-role="note"]').value);
        const targetId = overlay.querySelector('[data-role="target"]').value;
        if (currentConfig.routing.recipientRequired && !recipient) {
            alert(tr('Veuillez saisir un destinataire.', 'Please enter a recipient.'));
            return;
        }
        const target = currentTargetForNewShare(targetId);
        if (currentConfig.routing.mode === 'targeted' && !target) {
            alert(tr('Veuillez choisir une destination.', 'Please choose a destination.'));
            return;
        }
        processingShare = true;
        setShareModalBusy(true);
        const now = Date.now();
        const share = {
            url: window.location.href,
            title: pendingShareContext.title || tr('Page Koha', 'Koha page'),
            kind: pendingShareContext.kind || 'page',
            recipient: recipient || null,
            note: note || null,
            status: currentConfig.workflow.initialStatus || 'en_attente',
            statusComment: null,
            sender: branchInfo().name || tr('Inconnu', 'Unknown'),
            senderSiteId: currentSite.id,
            senderSiteCode: currentSite.matchCode || branchInfo().code || '',
            target: target,
            createdBy: currentIdentity.id,
            createdByLabel: currentIdentity.label,
            timestamp: now,
            expiresAt: now + currentConfig.lifetime.ttlMinutes * 60000,
            deliveryStatus: 'sent',
            sentAt: now,
            viewedAt: null,
            viewedBy: null,
            moduleVersion: VERSION
        };
        try {
            await currentStore.create(share);
            try { usageCount = await currentStore.incrementUsage(); } catch (_) {}
            addDiagnostic('connected', tr('Partage créé', 'Share created'), share.title);
            const source = pendingShareContext.sourceButton;
            closeShareModal();
            if (source) {
                const original = source.innerHTML;
                source.innerHTML = '<i class="fa fa-check" aria-hidden="true"></i>' + (source.classList.contains('pmk111-row-share') ? '' : ' ' + tr('Partagé', 'Shared'));
                window.setTimeout(function () { if (source.isConnected) source.innerHTML = original; }, 1800);
            }
        } catch (error) {
            processingShare = false;
            setShareModalBusy(false);
            connectionUI('error', tr('Erreur de connexion', 'Connection error'));
            addDiagnostic('error', tr('Erreur de partage', 'Share error'), error && error.message);
            alert(tr('Erreur de partage : ', 'Share error: ') + (error && error.message ? error.message : tr('erreur inconnue', 'unknown error')));
        }
    }

    function cleanMultiline(value) {
        return String(value == null ? '' : value).replace(/\r\n/g, '\n').trim();
    }

    function openStatusModal(key, statusId) {
        const data = shareMap.get(key);
        const cfg = statusById(statusId);
        if (!data || !cfg || !canUpdateStatus(data)) return;
        pendingStatus = { key:key, statusId:statusId, cfg:cfg };
        const modal = document.getElementById(STATUS_MODAL_ID);
        modal.querySelector('[data-role="title"]').textContent = tr('Changer le statut : ', 'Change status: ') + (isReservationShare(data) ? tr(cfg.reservationLabelFr, cfg.reservationLabelEn) : tr(cfg.labelFr, cfg.labelEn));
        modal.querySelector('[data-role="comment-label"]').textContent = cfg.commentPolicy === 'required' ? tr('Commentaire obligatoire', 'Comment required') : tr('Commentaire', 'Comment');
        modal.querySelector('[data-role="help"]').textContent = cfg.commentPolicy === 'required' ? tr('Décrivez ce statut avant de valider.', 'Describe this status before saving.') : tr('Le commentaire est facultatif.', 'Comment is optional.');
        modal.querySelector('[data-role="comment"]').value = '';
        modal.querySelector('[data-act="cancel"]').textContent = tr('Annuler', 'Cancel');
        modal.querySelector('[data-act="confirm"]').textContent = tr('Valider', 'Save');
        modal.classList.add('is-open');
        modal.querySelector('[data-role="comment"]').focus();
    }

    function closeStatusModal() {
        const modal = document.getElementById(STATUS_MODAL_ID);
        if (modal) modal.classList.remove('is-open');
        pendingStatus = null;
        processingStatus = false;
        if (modal) modal.querySelector('[data-act="confirm"]').disabled = false;
    }

    async function executeStatusFromModal() {
        if (!pendingStatus || processingStatus || !currentStore) return;
        const modal = document.getElementById(STATUS_MODAL_ID);
        const comment = cleanMultiline(modal.querySelector('[data-role="comment"]').value);
        if (pendingStatus.cfg.commentPolicy === 'required' && !comment) {
            alert(tr('Veuillez saisir un commentaire.', 'Please enter a comment.'));
            return;
        }
        processingStatus = true;
        modal.querySelector('[data-act="confirm"]').disabled = true;
        try {
            await currentStore.update(pendingStatus.key, { status:pendingStatus.statusId, statusComment:comment || null, updatedAt:Date.now(), updatedBy:currentIdentity.id });
            const terminal = !!pendingStatus.cfg.terminal;
            const key = pendingStatus.key;
            closeStatusModal();
            if (terminal && currentConfig.lifetime.deleteOnTerminal) {
                const delay = Math.max(0, Number(currentConfig.lifetime.deleteAfterTerminalSeconds) || 0) * 1000;
                window.setTimeout(function () { if (currentStore) currentStore.remove(key).catch(function () {}); }, delay);
            }
        } catch (error) {
            processingStatus = false;
            modal.querySelector('[data-act="confirm"]').disabled = false;
            addDiagnostic('error', tr('Erreur de statut', 'Status error'), error && error.message);
            alert(tr('Erreur de mise à jour : ', 'Update error: ') + (error && error.message ? error.message : tr('erreur inconnue', 'unknown error')));
        }
    }

    function renderShare(key, data) {
        if (!data || isExpired(data) || !targetVisible(data)) {
            removeRenderedShare(key);
            if (data && isExpired(data) && currentConfig.lifetime.cleanupExpired && currentStore) currentStore.remove(key).catch(function () {});
            return;
        }
        shareMap.set(key, data);
        const root = ensureRoot();
        let item = document.getElementById('pmk111-item-' + cssSafe(key));
        if (!item) {
            item = document.createElement('div');
            item.className = 'pmk111-item';
            item.id = 'pmk111-item-' + cssSafe(key);
            item.dataset.key = key;
            if (currentConfig.appearance.newestFirst && root.firstChild) root.insertBefore(item, root.firstChild); else root.appendChild(item);
        }
        const status = statusDisplay(data);
        const safeUrl = safeInternalUrl(data.url);
        const creator = data.createdBy === currentIdentity.id ? tr('Vous', 'You') : (data.createdByLabel || tr('Autre', 'Other'));
        const mine = data.createdBy === currentIdentity.id;
        const deliveryText = data.viewedAt
            ? tr('Consulté le ', 'Viewed on ') + new Date(Number(data.viewedAt)).toLocaleString()
            : (mine ? tr('Envoyé — disponible jusqu’à expiration', 'Sent — available until expiry') : tr('Disponible — pas encore consulté', 'Available — not viewed yet'));
        const collapsed = currentConfig.appearance.rememberCollapsed ? localCollapseState(key) : currentConfig.appearance.collapsedByDefault;
        item.classList.toggle('pmk111-collapsed', !!collapsed);
        const statusButtons = canUpdateStatus(data) ? (currentConfig.workflow.statuses || []).filter(function (s) { return s && s.enabled !== false; }).map(function (s) {
            const label = isReservationShare(data) ? tr(s.reservationLabelFr || s.labelFr, s.reservationLabelEn || s.labelEn) : tr(s.labelFr, s.labelEn);
            const active = data.status === s.id;
            return '<button type="button" class="btn btn-' + variantToButton(s.variant) + ' btn-xs" data-act="status" data-status="' + esc(s.id) + '"' + (active ? ' disabled aria-pressed="true"' : '') + '><i class="fa ' + esc(s.icon || 'fa-circle') + '" aria-hidden="true"></i> ' + esc(label) + '</button>';
        }).join('') : '';
        item.innerHTML = `
<div class="pmk111-card" data-variant="${esc(status.variant)}">
 <div class="pmk111-card-head"><div class="pmk111-card-title"><i class="fa fa-share-alt" aria-hidden="true"></i> ${esc(data.title || tr('Partage interne','Internal share'))}</div><button type="button" class="btn btn-default btn-xs" data-act="collapse" title="${esc(tr('Réduire','Collapse'))}"><i class="fa fa-chevron-down"></i></button>${canDelete(data) ? '<button type="button" class="btn btn-default btn-xs" data-act="delete" title="' + esc(tr('Supprimer','Delete')) + '"><i class="fa fa-times text-danger"></i></button>' : ''}</div>
 <div class="pmk111-body">
  ${data.recipient ? '<div class="pmk111-recipient"><i class="fa fa-user"></i> ' + esc(tr('Pour : ','For: ')) + '<strong>' + esc(data.recipient) + '</strong></div>' : ''}
  <div class="pmk111-delivery-state" data-role="delivery"><i class="fa fa-eye" aria-hidden="true"></i> ${esc(deliveryText)}</div>
  <div class="pmk111-statusline"><i class="fa ${esc(status.icon)}" aria-hidden="true"></i><span>${esc(status.text)}</span></div>
  ${data.statusComment ? '<div class="pmk111-comment"><i class="fa fa-info-circle"></i> ' + esc(data.statusComment) + '</div>' : ''}
  ${data.note ? '<div class="pmk111-note"><i class="fa fa-comment"></i> ' + esc(data.note).replace(/\n/g,'<br>') + '</div>' : ''}
  ${(currentConfig.appearance.showCreator || currentConfig.appearance.showSenderSite) ? '<div class="pmk111-meta">' + (currentConfig.appearance.showCreator ? esc(tr('Créé par : ','Created by: ') + creator) : '') + (currentConfig.appearance.showCreator && currentConfig.appearance.showSenderSite ? ' · ' : '') + (currentConfig.appearance.showSenderSite ? esc(data.sender || '') : '') + '</div>' : ''}
  ${statusButtons ? '<div class="pmk111-actions">' + statusButtons + '</div>' : ''}
  <div class="pmk111-footer"><span class="pmk111-timer" data-role="timer"></span>${safeUrl ? '<a href="' + esc(safeUrl) + '" target="_blank" rel="noopener noreferrer">' + esc(tr('Ouvrir','Open')) + ' <i class="fa fa-arrow-right"></i></a>' : '<span class="text-danger">' + esc(tr('Lien invalide','Invalid link')) + '</span>'}</div>
  ${currentConfig.appearance.showUsageCount ? '<div class="text-muted" style="font-size:11px;text-align:right;margin-top:.25rem">' + esc(tr('Utilisations : ','Uses: ')) + '<span data-role="usage">' + esc(String(usageCount || 0)) + '</span></div>' : ''}
 </div>
</div>
<button type="button" class="btn btn-default pmk111-collapse-handle" data-act="expand" title="${esc(tr('Développer','Expand'))}"><i class="fa fa-chevron-up"></i></button>`;
        item.querySelector('[data-act="collapse"]').addEventListener('click', function () { setCollapsed(key, true); renderShare(key, data); });
        item.querySelector('[data-act="expand"]').addEventListener('click', function () { setCollapsed(key, false); renderShare(key, data); });
        const del = item.querySelector('[data-act="delete"]');
        if (del) del.addEventListener('click', function () { deleteShare(key, data); });
        Array.from(item.querySelectorAll('[data-act="status"]')).forEach(function (btn) {
            btn.addEventListener('click', function () { openStatusModal(key, btn.dataset.status); });
        });
        const openLink = item.querySelector('.pmk111-footer a');
        if (openLink) openLink.addEventListener('click', function () {
            if (mine || data.viewedAt || !currentStore) return;
            const viewedAt = Date.now();
            data.viewedAt = viewedAt;
            data.viewedBy = currentIdentity.id;
            data.deliveryStatus = 'viewed';
            const delivery = item.querySelector('[data-role="delivery"]');
            if (delivery) delivery.textContent = tr('Consulté le ', 'Viewed on ') + new Date(viewedAt).toLocaleString();
            currentStore.update(key, {viewedAt:viewedAt,viewedBy:currentIdentity.id,deliveryStatus:'viewed'}).catch(function (error) {
                addDiagnostic('error', tr('Accusé de consultation non enregistré','View receipt not saved'), error.message);
            });
        });
        startTimer(key, data, item);
        enforceVisibleLimit();
    }

    function cssSafe(value) {
        return String(value || '').replace(/[^a-zA-Z0-9_-]/g, '_');
    }

    function variantToButton(variant) {
        if (variant === 'success') return 'success';
        if (variant === 'danger') return 'danger';
        if (variant === 'warning') return 'warning';
        if (variant === 'info') return 'info';
        if (variant === 'primary') return 'primary';
        return 'default';
    }

    function localCollapseState(key) {
        try {
            const stored = localStorage.getItem(COLLAPSE_PREFIX + key);
            if (stored === '1') return true;
            if (stored === '0') return false;
        } catch (_) {}
        return !!currentConfig.appearance.collapsedByDefault;
    }

    function setCollapsed(key, value) {
        if (!currentConfig.appearance.rememberCollapsed) return;
        try { localStorage.setItem(COLLAPSE_PREFIX + key, value ? '1' : '0'); } catch (_) {}
    }

    function startTimer(key, data, item) {
        if (timerMap.has(key)) window.clearInterval(timerMap.get(key));
        const tick = function () {
            if (!item.isConnected) { window.clearInterval(timerMap.get(key)); timerMap.delete(key); return; }
            const remaining = shareExpiry(data) - Date.now();
            if (remaining <= 0) {
                removeRenderedShare(key);
                if (currentConfig.lifetime.cleanupExpired && currentStore) currentStore.remove(key).catch(function () {});
                return;
            }
            const el = item.querySelector('[data-role="timer"]');
            if (!el) return;
            if (!currentConfig.lifetime.showCountdown) { el.textContent = ''; return; }
            const minutes = Math.floor(remaining / 60000);
            const seconds = Math.floor((remaining % 60000) / 1000);
            el.textContent = tr('Expire dans ', 'Expires in ') + minutes + 'm ' + String(seconds).padStart(2,'0') + 's';
            el.classList.toggle('is-ending', remaining <= currentConfig.lifetime.warningBeforeSeconds * 1000);
        };
        tick();
        timerMap.set(key, window.setInterval(tick, 1000));
    }

    function enforceVisibleLimit() {
        const limit = Number(currentConfig.appearance.maxVisible) || 0;
        if (!limit) return;
        const root = document.getElementById(ROOT_ID);
        if (!root) return;
        const items = Array.from(root.querySelectorAll('.pmk111-item'));
        items.forEach(function (item, index) { item.style.display = index < limit ? '' : 'none'; });
    }

    function removeRenderedShare(key) {
        shareMap.delete(key);
        if (timerMap.has(key)) { window.clearInterval(timerMap.get(key)); timerMap.delete(key); }
        const item = document.getElementById('pmk111-item-' + cssSafe(key));
        if (item) item.remove();
        try { localStorage.removeItem(COLLAPSE_PREFIX + key); } catch (_) {}
    }

    async function deleteShare(key, data) {
        if (!canDelete(data) || !currentStore) return;
        if (!window.confirm(tr('Supprimer cette demande pour tous les utilisateurs ?', 'Delete this request for all users?'))) return;
        try { await currentStore.remove(key); } catch (error) { alert(tr('Erreur de suppression : ', 'Delete error: ') + (error.message || error)); }
    }

    function updateUsageUI() {
        document.querySelectorAll('#' + ROOT_ID + ' [data-role="usage"]').forEach(function (el) { el.textContent = String(usageCount || 0); });
        const modal = document.getElementById(MODAL_ID);
        if (modal) modal.querySelector('[data-role="usage"]').textContent = currentConfig.appearance.showUsageCount ? tr('Utilisations : ', 'Uses: ') + String(usageCount || 0) : '';
    }

    function generatePageTokens(page) {
        const params = new URLSearchParams(window.location.search);
        const nameHeader = document.querySelector('#main_moremember h1, #main_moremember h3, .main h1, .main h3, #patron-template h1');
        const titleEl = document.querySelector('.title, h1, h2');
        const rawTitle = clean(titleEl ? titleEl.textContent.replace(tr(currentConfig.appearance.buttonLabelFr,currentConfig.appearance.buttonLabelEn),'') : '');
        const biblionumber = params.get('biblionumber') || '';
        const query = params.get('q') || tr('Catalogue', 'Catalog');
        const catalogingTitle = page && page.id === 'cataloguing.addbiblio'
            ? (biblionumber ? tr('Modif. Notice #', 'Edit record #') + biblionumber : tr('Nouvelle Notice', 'New record'))
            : rawTitle;
        return {
            name: clean(nameHeader ? nameHeader.textContent.replace(tr(currentConfig.appearance.buttonLabelFr,currentConfig.appearance.buttonLabelEn),'') : tr('Lecteur','Patron')).slice(0,60),
            title: rawTitle ? rawTitle.slice(0,80) : tr('Page Koha', 'Koha page'),
            biblionumber: biblionumber,
            query: query,
            catalogingTitle: catalogingTitle
        };
    }

    function applyTemplate(template, tokens) {
        return String(template || '').replace(/\{([a-zA-Z0-9_]+)\}/g, function (_, key) { return tokens[key] == null ? '' : String(tokens[key]); }).replace(/\s{2,}/g,' ').trim();
    }

    function generatePageTitle(page) {
        const tokens = generatePageTokens(page);
        const template = tr(page && page.titleTemplateFr, page && page.titleTemplateEn) || '{title}';
        return applyTemplate(template, tokens) || tr('Page Koha', 'Koha page');
    }

    function insertButtonAt(target, button, position) {
        if (!target || !button) return;
        if (position === 'prepend') target.insertBefore(button, target.firstChild);
        else if (position === 'before') target.parentNode && target.parentNode.insertBefore(button, target);
        else if (position === 'after') target.parentNode && target.parentNode.insertBefore(button, target.nextSibling);
        else target.appendChild(button);
    }

    function injectMainButton(page) {
        if (!page || page.shareMode !== 'page' || !currentSite || !currentSite.canSend) return;
        if (document.getElementById('pmk111-share-button')) return;
        let target = null;
        try { target = document.querySelector(page.selector || ''); } catch (_) {}
        if (!target) return;
        const btn = document.createElement(page.id === 'cataloguing.additem' ? 'button' : 'a');
        btn.id = 'pmk111-share-button';
        if (btn.tagName === 'A') btn.href = '#'; else btn.type = 'button';
        btn.className = 'btn btn-default';
        btn.innerHTML = '<i class="fa fa-share-alt" aria-hidden="true"></i> ' + esc(tr(currentConfig.appearance.buttonLabelFr, currentConfig.appearance.buttonLabelEn));
        if (page.id === 'cataloguing.additem') btn.style.marginLeft = '.6rem';
        insertButtonAt(target, btn, page.position || 'append');
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            openShareModal({ kind:'page', title:generatePageTitle(page), note:'', sourceButton:btn });
        });
    }

    function injectReservationRowButtons(page) {
        if (!page || page.shareMode !== 'reservationRows' || !currentSite || !currentSite.canSend) return;
        const rows = document.querySelectorAll('table tbody tr');
        rows.forEach(function (row) {
            if (row.querySelector('.pmk111-row-share')) return;
            const patronLink = row.querySelector('a[href*="moremember.pl"]');
            const firstTd = row.cells && row.cells[0];
            if (!patronLink || !firstTd) return;
            const patron = clean(patronLink.textContent);
            const priorityEl = row.querySelector('.current_priority');
            const priority = clean(priorityEl ? priorityEl.textContent : '1');
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-default btn-xs pmk111-row-share';
            btn.innerHTML = '<i class="fa fa-share-alt" aria-hidden="true"></i>';
            btn.title = tr('Partage interne : ', 'Internal share: ') + patron;
            firstTd.appendChild(btn);
            btn.addEventListener('click', function (e) {
                e.preventDefault(); e.stopPropagation();
                const tokens = { patron:patron, priority:priority };
                openShareModal({
                    kind:'reservation',
                    title:applyTemplate(tr(page.titleTemplateFr,page.titleTemplateEn), tokens),
                    note:applyTemplate(tr(page.noteTemplateFr,page.noteTemplateEn), tokens).replace(/\\n/g,'\n'),
                    sourceButton:btn
                });
            });
        });
    }

    function runInjection() {
        currentPage = pageConfigForPath(currentPath());
        if (!currentPage || !currentSite || !currentSite.canSend) return;
        if (currentPage.shareMode === 'reservationRows') injectReservationRowButtons(currentPage); else injectMainButton(currentPage);
    }

    function startInjectionObserver() {
        stopInjectionObserver();
        runInjection();
        if (!currentPage || currentPage.shareMode !== 'reservationRows' || typeof MutationObserver !== 'function') return;
        const table = document.querySelector('table');
        const root = table || document.body;
        injectionObserver = new MutationObserver(function () {
            if (injectionTimer) window.clearTimeout(injectionTimer);
            injectionTimer = window.setTimeout(runInjection, 150);
        });
        injectionObserver.observe(root, { childList:true, subtree:true });
    }

    function stopInjectionObserver() {
        if (injectionObserver) { injectionObserver.disconnect(); injectionObserver = null; }
        if (injectionTimer) { window.clearTimeout(injectionTimer); injectionTimer = null; }
    }

    function ensureDiagnostics() {
        let panel = document.getElementById(DIAG_ID);
        if (panel) return panel;
        panel = document.createElement('div');
        panel.id = DIAG_ID;
        panel.className = 'pmk111-diagnostics';
        panel.innerHTML = '<div class="pmk111-diag-head"><strong>' + esc(tr('Diagnostic — Partage interne','Diagnostics — Internal share')) + '</strong><div><button type="button" class="btn btn-default btn-xs" data-act="clear">' + esc(tr('Effacer','Clear')) + '</button> <button type="button" class="btn btn-default btn-xs" data-act="close">×</button></div></div><div class="pmk111-diag-list"></div>';
        document.body.appendChild(panel);
        panel.querySelector('[data-act="clear"]').addEventListener('click', clearDiagnostics);
        panel.querySelector('[data-act="close"]').addEventListener('click', toggleDiagnostics);
        return panel;
    }

    function renderDiagnostics() {
        const panel = document.getElementById(DIAG_ID);
        if (!panel) return;
        const list = panel.querySelector('.pmk111-diag-list');
        const rows = readDiagnostics();
        list.innerHTML = rows.length ? rows.map(function (r) {
            return '<div class="pmk111-diag-row"><span>' + esc(r.time || '') + '</span><span>' + esc(r.status || '') + '</span><span>' + esc(r.message || '') + '</span><span>' + esc(r.details || r.page || '') + '</span></div>';
        }).join('') : '<div class="pmk111-empty">' + esc(tr('Aucun événement enregistré.','No event recorded.')) + '</div>';
    }

    function toggleDiagnostics() {
        if (!(currentConfig.diagnostics && currentConfig.diagnostics.enabled)) return;
        const panel = ensureDiagnostics();
        panel.classList.toggle('is-open');
        renderDiagnostics();
    }

    // ---------------------------------------------------------------------
    // STORAGE ADAPTER REGISTRY
    // ---------------------------------------------------------------------
    const adapterFactories = Object.create(null);

    function registerStorageAdapter(name, factory) {
        if (!name || typeof factory !== 'function') throw new Error('Invalid PMK111 storage adapter');
        adapterFactories[name] = factory;
    }

    function createStore() {
        const mode = 'koha'; // Existing legacy options are retained but never select a remote engine.
        const factory = adapterFactories[mode];
        if (!factory) throw new Error('Unknown PMK111 storage adapter: ' + mode);
        return factory({ config:currentConfig, site:currentSite, identity:currentIdentity, onConnection:connectionUI, diagnostic:addDiagnostic });
    }

    registerStorageAdapter('koha', function(ctx) {
        const api=window.PMKNativeData,db=api.createDatabase('internal-share');
        // Legacy paths remain usable as local collection names; no external connection.
        const legacy=ctx.config.storage.firebaseLegacy||{};
        const shares=api.collection(db,legacy.sharesPath||'shares');
        const usage=api.doc(db,'stats','usage_count');
        let connected=false,stop=null;
        return {
            mode:'koha',isConnected:()=>connected,
            async start(events){
                await api.getSession();
                let known=new Map();
                stop=api.onSnapshot(api.query(shares,api.where('timestamp','>=',Date.now()-ctx.config.lifetime.ttlMinutes*60000-60000)),snap=>{
                    const next=new Map();for(const d of snap.docs){const data=d.data();next.set(d.id,data);if(JSON.stringify(known.get(d.id))!==JSON.stringify(data))events.upsert(d.id,data);}
                    for(const id of known.keys())if(!next.has(id))events.remove(id);known=next;
                    connected=true;ctx.onConnection('connected',tr('Connecté à Koha','Connected to Koha'));
                },error=>{connected=false;ctx.onConnection('disconnected',error.message);});
            },
            async stop(){stop?.();stop=null;connected=false;},
            async create(data){const r=await api.addDoc(shares,Object.assign({},data,{timestamp:Date.now()}));return r.id;},
            async update(id,patch){return api.updateDoc(api.doc(shares,id),patch);},
            async remove(id){return api.deleteDoc(api.doc(shares,id));},
            async getUsage(){const s=await api.getDoc(usage);return Number(s.data()?.count)||0;},
            async incrementUsage(){return api.runTransaction(db,async tx=>{const s=await tx.get(usage),count=(Number(s.data()?.count)||0)+1;tx.set(usage,{count});return count;});}
        };
    });

    function sameOriginApiBase(path) {
        const url = new URL(String(path || ''), window.location.origin);
        if (url.origin !== window.location.origin) throw new Error('PMK111 plugin API must be same-origin');
        if (url.pathname.indexOf('/api/') !== 0) throw new Error('PMK111 plugin API path must start with /api/');
        return url.pathname.replace(/\/$/, '');
    }

    async function stopRuntime() {
        runtimeGeneration++;
        stopInjectionObserver();
        if (currentStore && typeof currentStore.stop === 'function') {
            try { await currentStore.stop(); } catch (_) {}
        }
        currentStore = null;
        shareMap.clear();
        timerMap.forEach(function (timer) { window.clearInterval(timer); });
        timerMap.clear();
        const root = document.getElementById(ROOT_ID); if (root) root.innerHTML = '';
        const mainBtn = document.getElementById('pmk111-share-button'); if (mainBtn) mainBtn.remove();
        document.querySelectorAll('.pmk111-row-share').forEach(function (b) { b.remove(); });
    }

    async function startRuntime() {
        const myGeneration = ++runtimeGeneration;
        ensureStyles(); ensureRoot(); ensureModals();
        currentIdentity = resolveIdentity();
        currentPage = pageConfigForPath(currentPath());
        const info = await waitForBranch(10000);
        if (myGeneration !== runtimeGeneration) return;
        currentSite = resolveSite(info);
        if (!currentConfig.enabled || !currentSite) {
            addDiagnostic('disconnected', tr('Module inactif sur ce site','Module inactive on this site'), info.name || info.code || '');
            return;
        }
        startInjectionObserver();
        if (!currentSite.canReceive) return;
        try {
            currentStore = createStore();
            usageCount = currentConfig.appearance.showUsageCount ? await currentStore.getUsage().catch(function(){return 0;}) : 0;
            updateUsageUI();
            await currentStore.start({ upsert:renderShare, remove:removeRenderedShare });
        } catch (error) {
            addDiagnostic('error', tr('Stockage indisponible','Storage unavailable'), error.message);
            connectionUI('error', tr('Stockage indisponible','Storage unavailable'));
        }
    }

    function waitForBranch(timeoutMs) {
        return new Promise(function (resolve) {
            const start = Date.now();
            const run = function () {
                const info = branchInfo();
                if (info.name || info.code || Date.now() - start >= timeoutMs) resolve(info);
                else window.setTimeout(run, 250);
            };
            run();
        });
    }

    function newSite() {
        const id = 'site-' + Date.now().toString(36);
        return { id:id, enabled:true, labelFr:'Nouveau site', labelEn:'New site', matchName:'', matchCode:'', canSend:true, canReceive:true, channel:id };
    }

    function newTarget() {
        const id = 'target-' + Date.now().toString(36);
        return { id:id, enabled:true, labelFr:'Nouvelle destination', labelEn:'New destination', type:'site', value:'' };
    }

    function newStatus() {
        const id = 'status-' + Date.now().toString(36);
        return { id:id, enabled:true, variant:'default', icon:'fa-tag', terminal:false, commentPolicy:'optional', labelFr:'Nouveau statut', labelEn:'New status', reservationLabelFr:'', reservationLabelEn:'', textFr:'Nouveau statut', textEn:'New status', reservationTextFr:'', reservationTextEn:'' };
    }

    function pageFromPickerContext(ctx) {
        const path = Array.isArray(ctx && ctx.fieldPath) ? ctx.fieldPath : [];
        const idx = path.find(function (v) { return Number.isInteger(v); });
        return Number.isInteger(idx) ? (ctx.rootObject && ctx.rootObject.pages && ctx.rootObject.pages[idx]) : null;
    }

    function pickPlacement(context) {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.pickForConfig !== 'function') return Promise.reject(new Error('pmk_common_picker_unavailable'));
        registerPickerAdapter();
        const page = pageFromPickerContext(context) || {};
        return service.pickForConfig({ moduleId:MODULE_ID, targetUrl:page.path || currentPath(), rootObject:context.rootObject || {}, fieldPath:context.fieldPath || [], adminContext:{ sectionId:'pages' }, options:{ bannerText:tr('Clique sur la zone où placer le bouton — Échap annule','Click where to place the button — Esc cancels') } });
    }

    function onPickedPlacement(rootObject, fieldPath, picked) {
        if (!rootObject || !Array.isArray(rootObject.pages) || !picked) return;
        const idx = (fieldPath || []).find(function (v) { return Number.isInteger(v); });
        if (!Number.isInteger(idx) || !rootObject.pages[idx]) return;
        rootObject.pages[idx].selector = picked.selector || picked.value || rootObject.pages[idx].selector;
        rootObject.pages[idx].placementMode = 'custom';
    }

    function registerPickerAdapter() {
        const service = window.PMKConfig && window.PMKConfig.elementPicker;
        if (!service || typeof service.register !== 'function') return;
        service.register(MODULE_ID, {
            buildResult:function (element, base) {
                const selector = base && base.selector ? base.selector : simpleSelector(element);
                return Object.assign({}, base || {}, { value:selector, selector:selector, targetName:clean(element.getAttribute('aria-label') || element.getAttribute('title') || element.textContent).slice(0,100) });
            },
            applyPending:function (draft, pending, picked) { onPickedPlacement(draft, pending && pending.fieldPath || [], picked || {}); return draft; }
        });
    }

    function simpleSelector(el) {
        if (!el || !(el instanceof Element)) return '';
        if (el.id) return '#' + cssEscape(el.id);
        const cls = Array.from(el.classList || []).filter(function (c) { return !/^active$|^open$|^show$/.test(c); }).slice(0,2);
        if (cls.length) return el.tagName.toLowerCase() + '.' + cls.map(function(c){return cssEscape(c);}).join('.');
        return el.tagName.toLowerCase();
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        if (!Array.isArray(cfg.sites) || !cfg.sites.length) return { ok:false, message:tr('Au moins un site doit être configuré.','At least one site must be configured.') };
        const ids = new Set();
        for (const site of cfg.sites) {
            if (!site || site.enabled === false) continue;
            if (!clean(site.id) || ids.has(site.id)) return { ok:false, message:tr('Chaque site actif doit avoir un identifiant unique.','Each enabled site needs a unique identifier.') };
            ids.add(site.id);
            if (!clean(site.matchName) && !clean(site.matchCode)) return { ok:false, message:tr('Chaque site actif doit indiquer un nom ou un code Koha à reconnaître.','Each enabled site must provide a Koha name or code to match.') };
        }
        if (cfg.routing.mode === 'targeted' && !(cfg.routing.targets || []).some(function(t){return t && t.enabled !== false;})) return { ok:false, message:tr('Le mode ciblé nécessite au moins une destination active.','Targeted mode requires at least one enabled destination.') };
        for (const page of cfg.pages || []) {
            if (!page || page.enabled === false || page.shareMode === 'reservationRows') continue;
            if (!clean(page.selector)) return { ok:false, message:tr('Une page active n’a pas de zone d’insertion.','An enabled page has no insertion target.') };
            try { document.createDocumentFragment().querySelector(page.selector); } catch (_) { return { ok:false, message:tr('Sélecteur CSS invalide : ','Invalid CSS selector: ') + page.selector }; }
        }
        const statusIds = new Set();
        for (const status of cfg.workflow.statuses || []) {
            if (!status || status.enabled === false) continue;
            if (!clean(status.id) || statusIds.has(status.id)) return { ok:false, message:tr('Chaque statut actif doit avoir un identifiant unique.','Each enabled status needs a unique identifier.') };
            statusIds.add(status.id);
        }
        return { ok:true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 4,
            name: { fr:'Partage interne', en:'Internal share' },
            description: {
                fr:'Partage en temps réel de pages Koha et de demandes liées aux réservations. Les destinataires, la durée de disponibilité et les états envoyé, disponible et consulté sont visibles. Le stockage utilise exclusivement l’API native du plugin Koha.',
                en:'Real-time sharing of Koha pages and hold-related requests. Recipients, availability duration, and sent, available and viewed states are visible. Storage exclusively uses the native Koha plugin API.'
            },
            category: { fr:'Travail collaboratif', en:'Collaboration' },
            supportedPages: PAGE_DEFINITIONS.map(function(p){return p.id;}).concat(['all-staff-pages']),
            prerequisites: [], dependencies: [], defaults: clone(DEFAULT_CONFIG), validate: validateConfig,
            schema: [
                { type:'section', id:'activation', label:{fr:'Activation et sites',en:'Activation and sites'}, fields:[
                    { key:'enabled', type:'boolean', label:{fr:'Activer le partage interne',en:'Enable internal sharing'} },
                    { key:'sites', type:'repeater', label:{fr:'Sites Koha concernés',en:'Koha sites'}, addLabel:{fr:'Ajouter un site',en:'Add site'}, reorder:true, newItem:newSite, itemTitle:function(item){return clean(item && (item.labelFr || item.matchName || item.id)) || 'Site';}, fields:[
                        {key:'enabled',type:'boolean',label:{fr:'Actif',en:'Enabled'}},{key:'id',type:'text',label:{fr:'Identifiant interne',en:'Internal ID'}},{key:'labelFr',type:'text',label:{fr:'Nom FR',en:'FR name'}},{key:'labelEn',type:'text',label:{fr:'Nom EN',en:'EN name'}},{key:'matchName',type:'text',label:{fr:'Nom du site tel qu’affiché par Koha',en:'Branch name as shown by Koha'}},{key:'matchCode',type:'text',label:{fr:'Code site Koha',en:'Koha branch code'}},{key:'canSend',type:'boolean',label:{fr:'Peut envoyer',en:'Can send'}},{key:'canReceive',type:'boolean',label:{fr:'Reçoit les demandes',en:'Receives requests'}},{key:'channel',type:'text',advanced:true,label:{fr:'Canal de diffusion',en:'Broadcast channel'}}
                    ]}
                ]},
                { type:'section', id:'pages', label:{fr:'Pages et boutons',en:'Pages and buttons'}, description:{fr:'Les pages historiques restent actives par défaut. request.pl conserve son bouton par ligne de réservation.',en:'Historical pages remain enabled by default. request.pl keeps its per-hold-row button.'}, fields:[
                    { key:'pages', type:'repeater', reorder:false, removable:false, canAdd:function(){return false;}, itemTitle:function(item,index){const d=PAGE_DEFINITIONS[index];return d ? tr(d.labelFr,d.labelEn) : clean(item && item.path);}, fields:[
                        {key:'enabled',type:'boolean',label:{fr:'Activer sur cette page',en:'Enable on this page'}},{key:'path',type:'text',readOnly:true,label:{fr:'Chemin Koha',en:'Koha path'}},{key:'shareMode',type:'select',advanced:true,label:{fr:'Mode de partage',en:'Share mode'},options:[{value:'page',label:{fr:'Bouton de page',en:'Page button'}},{value:'reservationRows',label:{fr:'Boutons par ligne de réservation',en:'Per-hold-row buttons'}}]},{key:'selector',type:'elementPicker',advanced:true,label:{fr:'Zone d’insertion du bouton',en:'Button insertion target'},pickLabel:{fr:'Choisir sur la page',en:'Choose on page'},allowManual:true,pick:pickPlacement,onPick:onPickedPlacement},{key:'position',type:'select',advanced:true,label:{fr:'Position',en:'Position'},options:[{value:'append',label:{fr:'À la fin',en:'Append'}},{value:'prepend',label:{fr:'Au début',en:'Prepend'}},{value:'before',label:{fr:'Avant la zone',en:'Before target'}},{value:'after',label:{fr:'Après la zone',en:'After target'}}]},{key:'titleTemplateFr',type:'text',advanced:true,label:{fr:'Modèle de titre FR',en:'FR title template'}},{key:'titleTemplateEn',type:'text',advanced:true,label:{fr:'Modèle de titre EN',en:'EN title template'}},{key:'noteTemplateFr',type:'textarea',advanced:true,label:{fr:'Note automatique FR',en:'FR automatic note'}},{key:'noteTemplateEn',type:'textarea',advanced:true,label:{fr:'Note automatique EN',en:'EN automatic note'}}
                    ]}
                ]},
                { type:'section', id:'routing', label:{fr:'Diffusion et destinataires',en:'Routing and recipients'}, fields:[
                    {key:'routing.mode',type:'select',label:{fr:'Mode de diffusion',en:'Routing mode'},options:[{value:'broadcastSite',label:{fr:'Tout le site — comportement historique',en:'Whole site — historical behavior'}},{value:'broadcastChannel',label:{fr:'Canal partagé',en:'Shared channel'}},{value:'broadcastAll',label:{fr:'Tous les sites configurés',en:'All configured sites'}},{value:'targeted',label:{fr:'Destination choisie à l’envoi',en:'Destination chosen when sending'}}]},
                    {key:'routing.acceptLegacyUntargeted',type:'boolean',label:{fr:'Afficher les anciens partages sans cible',en:'Show legacy untargeted shares'}},{key:'routing.allowFreeRecipient',type:'boolean',label:{fr:'Afficher le champ destinataire libre',en:'Show free-text recipient field'}},{key:'routing.recipientRequired',type:'boolean',label:{fr:'Destinataire libre obligatoire',en:'Require free-text recipient'}},
                    {key:'routing.targets',type:'repeater',label:{fr:'Destinations proposées en mode ciblé',en:'Targets offered in targeted mode'},addLabel:{fr:'Ajouter une destination',en:'Add target'},newItem:newTarget,itemTitle:function(item){return clean(item && (item.labelFr || item.id)) || 'Destination';},fields:[{key:'enabled',type:'boolean',label:{fr:'Active',en:'Enabled'}},{key:'id',type:'text',label:{fr:'Identifiant',en:'ID'}},{key:'labelFr',type:'text',label:{fr:'Libellé FR',en:'FR label'}},{key:'labelEn',type:'text',label:{fr:'Libellé EN',en:'EN label'}},{key:'type',type:'select',label:{fr:'Type',en:'Type'},options:[{value:'site',label:{fr:'Site',en:'Site'}},{value:'channel',label:{fr:'Canal',en:'Channel'}},{value:'user',label:{fr:'Utilisateur Koha',en:'Koha user'}},{value:'all',label:{fr:'Tous',en:'All'}}]},{key:'value',type:'text',label:{fr:'Valeur cible',en:'Target value'}}]}
                ]},
                { type:'section', id:'workflow', label:{fr:'Statuts et workflow',en:'Statuses and workflow'}, fields:[
                    {key:'workflow.initialTextFr',type:'text',label:{fr:'Libellé initial FR',en:'Initial FR label'}},{key:'workflow.initialTextEn',type:'text',label:{fr:'Libellé initial EN',en:'Initial EN label'}},
                    {key:'workflow.statuses',type:'repeater',label:{fr:'Statuts disponibles',en:'Available statuses'},addLabel:{fr:'Ajouter un statut',en:'Add status'},reorder:true,newItem:newStatus,itemTitle:function(item){return clean(item && (item.labelFr || item.id)) || 'Statut';},fields:[{key:'enabled',type:'boolean',label:{fr:'Actif',en:'Enabled'}},{key:'id',type:'text',label:{fr:'Identifiant',en:'ID'}},{key:'labelFr',type:'text',label:{fr:'Bouton générique FR',en:'Generic FR button'}},{key:'labelEn',type:'text',label:{fr:'Bouton générique EN',en:'Generic EN button'}},{key:'reservationLabelFr',type:'text',label:{fr:'Bouton réservation FR',en:'Hold FR button'}},{key:'reservationLabelEn',type:'text',label:{fr:'Bouton réservation EN',en:'Hold EN button'}},{key:'textFr',type:'text',label:{fr:'Texte statut FR',en:'FR status text'}},{key:'textEn',type:'text',label:{fr:'Texte statut EN',en:'EN status text'}},{key:'reservationTextFr',type:'text',label:{fr:'Texte réservation FR',en:'Hold FR status text'}},{key:'reservationTextEn',type:'text',label:{fr:'Texte réservation EN',en:'Hold EN status text'}},{key:'variant',type:'select',label:{fr:'Style Koha',en:'Koha style'},options:[{value:'default',label:'Default'},{value:'primary',label:'Primary'},{value:'success',label:'Success'},{value:'info',label:'Info'},{value:'warning',label:'Warning'},{value:'danger',label:'Danger'}]},{key:'icon',type:'text',advanced:true,label:{fr:'Classe Font Awesome',en:'Font Awesome class'}},{key:'commentPolicy',type:'select',label:{fr:'Commentaire',en:'Comment'},options:[{value:'optional',label:{fr:'Facultatif',en:'Optional'}},{value:'required',label:{fr:'Obligatoire',en:'Required'}}]},{key:'terminal',type:'boolean',label:{fr:'Statut terminal',en:'Terminal status'}}]}
                ]},
                { type:'section', id:'lifetime', label:{fr:'Durée de vie',en:'Lifetime'}, fields:[
                    {key:'lifetime.ttlMinutes',type:'number',min:1,max:1440,label:{fr:'Durée d’affichage (minutes)',en:'Display lifetime (minutes)'}},{key:'lifetime.showCountdown',type:'boolean',label:{fr:'Afficher le compte à rebours',en:'Show countdown'}},{key:'lifetime.warningBeforeSeconds',type:'number',min:0,max:86400,label:{fr:'Alerte avant expiration (secondes)',en:'Expiry warning (seconds)'}},{key:'lifetime.cleanupExpired',type:'boolean',label:{fr:'Supprimer automatiquement les demandes expirées',en:'Automatically delete expired requests'}},{key:'lifetime.deleteOnTerminal',type:'boolean',label:{fr:'Supprimer après un statut terminal',en:'Delete after terminal status'}},{key:'lifetime.deleteAfterTerminalSeconds',type:'number',min:0,max:3600,advanced:true,label:{fr:'Délai après statut terminal (secondes)',en:'Delay after terminal status (seconds)'}}
                ]},
                { type:'section', id:'permissions', label:{fr:'Droits',en:'Permissions'}, fields:[
                    {key:'permissions.statusUpdatePolicy',type:'select',label:{fr:'Qui peut changer un statut ?',en:'Who can change status?'},options:[{value:'anyViewer',label:{fr:'Tout agent qui voit la demande — historique',en:'Any viewer — historical'}},{value:'creator',label:{fr:'Créateur uniquement',en:'Creator only'}},{value:'superlibrarian',label:{fr:'Superlibrarian uniquement',en:'Superlibrarian only'}}]},{key:'permissions.deletePolicy',type:'select',label:{fr:'Qui peut supprimer ?',en:'Who can delete?'},options:[{value:'creator',label:{fr:'Créateur — historique',en:'Creator — historical'}},{value:'anyViewer',label:{fr:'Tout agent',en:'Any viewer'}},{value:'superlibrarian',label:{fr:'Superlibrarian uniquement',en:'Superlibrarian only'}}]},{key:'permissions.allowSuperlibrarianDelete',type:'boolean',label:{fr:'Le superlibrarian peut toujours supprimer',en:'Superlibrarian can always delete'}}
                ]},
                { type:'section', id:'appearance', label:{fr:'Apparence',en:'Appearance'}, fields:[
                    {key:'appearance.mode',type:'select',label:{fr:'Style',en:'Style'},options:[{value:'koha',label:{fr:'Intégré à Koha — recommandé',en:'Koha integrated — recommended'}},{value:'legacyDark',label:{fr:'Historique sombre',en:'Legacy dark'}}]},{key:'appearance.position',type:'select',label:{fr:'Position des demandes',en:'Request position'},options:[{value:'bottom-right',label:{fr:'Bas droite',en:'Bottom right'}},{value:'bottom-left',label:{fr:'Bas gauche',en:'Bottom left'}},{value:'top-right',label:{fr:'Haut droite',en:'Top right'}},{value:'top-left',label:{fr:'Haut gauche',en:'Top left'}}]},{key:'appearance.widthPx',type:'number',min:280,max:760,label:{fr:'Largeur maximale (px)',en:'Maximum width (px)'}},{key:'appearance.maxVisible',type:'number',min:0,max:100,label:{fr:'Nombre maximal visible (0 = illimité)',en:'Maximum visible (0 = unlimited)'}},{key:'appearance.newestFirst',type:'boolean',label:{fr:'Nouveaux partages en premier',en:'Newest shares first'}},{key:'appearance.rememberCollapsed',type:'boolean',label:{fr:'Mémoriser les demandes repliées',en:'Remember collapsed requests'}},{key:'appearance.collapsedByDefault',type:'boolean',label:{fr:'Demandes repliées par défaut',en:'Collapsed by default'}},{key:'appearance.compactOnMobile',type:'boolean',label:{fr:'Mode compact sur petit écran',en:'Compact on small screens'}},{key:'appearance.showCreator',type:'boolean',label:{fr:'Afficher le créateur',en:'Show creator'}},{key:'appearance.showSenderSite',type:'boolean',label:{fr:'Afficher le site émetteur',en:'Show sender site'}},{key:'appearance.showUsageCount',type:'boolean',label:{fr:'Afficher le compteur d’utilisation',en:'Show usage counter'}},{key:'appearance.showConnectionStatus',type:'boolean',label:{fr:'Afficher l’état de connexion',en:'Show connection status'}},{key:'appearance.showDiagnostics',type:'boolean',advanced:true,label:{fr:'Afficher l’accès au diagnostic',en:'Show diagnostics access'}},{key:'appearance.buttonLabelFr',type:'text',label:{fr:'Libellé du bouton FR',en:'FR button label'}},{key:'appearance.buttonLabelEn',type:'text',label:{fr:'Libellé du bouton EN',en:'EN button label'}}
                ]},
                { type:'section', id:'storage', label:{fr:'Stockage',en:'Storage'}, description:{fr:'Les partages et leur compteur sont conservés dans la base Koha. L’accès utilise votre session professionnelle.',en:'Shares and usage counts are stored in Koha using the staff session.'}, fields:[
                    {key:'storage.mode',type:'select',label:{fr:'Moteur de stockage',en:'Storage engine'},options:[{value:'koha',label:{fr:'Base de données Koha',en:'Koha database'}}]},
                ]},
                { type:'section', id:'advanced', label:{fr:'Avancé / diagnostic',en:'Advanced / diagnostics'}, fields:[
                    {key:'identity.preferKohaUsername',type:'boolean',advanced:true,label:{fr:'Identifier le créateur avec le compte Koha',en:'Identify creator using Koha account'}},{key:'identity.fallbackToSessionId',type:'boolean',advanced:true,label:{fr:'Repli sur un identifiant de session',en:'Fallback to session ID'}},{key:'identity.usernameSelector',type:'text',advanced:true,label:{fr:'Sélecteur du compte Koha',en:'Koha account selector'}},{key:'diagnostics.enabled',type:'boolean',advanced:true,label:{fr:'Activer le journal de diagnostic local',en:'Enable local diagnostics log'}},{key:'diagnostics.maxEntries',type:'number',min:10,max:500,advanced:true,label:{fr:'Nombre maximal d’événements',en:'Maximum log entries'}},{key:'diagnostics.logToConsole',type:'boolean',advanced:true,label:{fr:'Dupliquer les événements dans la console',en:'Also log events to console'}}
                ]}
            ],
            focusContext:function(main, context) {
                if (!main || !context) return;
                const section = main.querySelector('[data-pmk-section-id="' + (context.sectionId || 'activation') + '"]');
                if (section) window.setTimeout(function(){section.scrollIntoView({behavior:'smooth',block:'start'});},0);
            }
        };
    }

    function registerWithPMK() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function' || configRegistered) return false;
        configRegistered = true;
        window.PMKConfig.registerModule(moduleDefinition());
        registerPickerAdapter();
        if (typeof window.PMKConfig.getConfig === 'function') {
            window.PMKConfig.getConfig(MODULE_ID).then(function (cfg) {
                currentConfig = normalizeConfig(cfg || {});
                restartRuntime();
            }).catch(function () { currentConfig = normalizeConfig(DEFAULT_CONFIG); restartRuntime(); });
        }
        if (typeof window.PMKConfig.subscribe === 'function') {
            unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                currentConfig = normalizeConfig(cfg || {});
                restartRuntime();
            });
        }
        return true;
    }

    let restartTimer = null;
    function restartRuntime() {
        if (restartTimer) window.clearTimeout(restartTimer);
        restartTimer = window.setTimeout(async function () {
            restartTimer = null;
            await stopRuntime();
            startRuntime();
        }, 50);
    }

    function boot() {
        currentConfig = normalizeConfig(DEFAULT_CONFIG);
        registerWithPMK();
        if (!configRegistered) {
            window.addEventListener('pmk:config-ready', function () { registerWithPMK(); }, { once:true });
            window.setTimeout(registerWithPMK, 1500);
        }
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { if (!configRegistered) startRuntime(); }, { once:true });
        else if (!configRegistered) startRuntime();
    }

    window.PMK111StorageAdapters = {
        register: registerStorageAdapter,
        list: function () { return Object.keys(adapterFactories); }
    };

    window.PMK111InternalShare = {
        moduleId: MODULE_ID,
        version: VERSION,
        defaults: clone(DEFAULT_CONFIG),
        moduleDefinition: moduleDefinition,
        getConfig: function () { return clone(currentConfig); },
        getSite: function () { return clone(currentSite); },
        getIdentity: function () { return clone(currentIdentity); },
        refresh: restartRuntime,
        stop: stopRuntime,
        openShare: function (title, note) { openShareModal({ kind:'page', title:title || generatePageTitle(currentPage), note:note || '' }); },
        diagnostics: readDiagnostics,
        storageAdapters: window.PMK111StorageAdapters
    };

    window.addEventListener('pagehide', function () { stopRuntime(); });
    boot();
})();

;window.PMKNonPlugin.loaded.push("111-internal-share.js");
} catch (error) { window.PMKNonPlugin.errors.push("111-internal-share.js: "+error.message); console.error("[PMK] 111-internal-share.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.scanner;
if(pmkLegacy.enabled===false || options.enabled===false)return;
(function () {
    // === DÉTECTION MOBILE / PETIT ÉCRAN ===
    function isMobileOrSmallScreen() {
        const isMobileUA = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|tablet|Silk/i.test(navigator.userAgent);
        const isSmallScreen = window.innerWidth <= 1024;
        const isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
        const criteriaMet = [isMobileUA, isSmallScreen, isTouch].filter(Boolean).length;
        (function(){})(`[Quagga] Détection: Mobile=${isMobileUA}, SmallScreen=${isSmallScreen}, Touch=${isTouch} → Actif=${criteriaMet >= 2}`);
        return criteriaMet >= 2;
    }

    if (!isMobileOrSmallScreen()) {
        (function(){})('[Quagga] Désactivé: non mobile ou écran trop grand');
        return;
    }

    const STYLE_ID = 'koha-quagga-styles';
    const OVERLAY_ID = 'koha-quagga-overlay';
    const VIDEO_ID = 'koha-quagga-video';
    const MSG_ID = 'koha-quagga-msg';

    // === LISTE DES CHAMPS À ÉQUIPER ===
    const TARGET_INPUTS = options.targets.split(/\n/).map(s=>s.trim()).filter(Boolean);

    // === CONFIGURATION DE LA VÉRIFICATION MULTIPLE ===
    const VERIFICATION_CONFIG = {
        REQUIRED_READS: 3,        // Nombre de lectures identiques requises
        TIMEOUT_MS: 800,          // Délai max entre deux lectures (ms)
        RESET_ON_DIFFERENT: true  // Réinitialise si un code différent est lu
    };

    // === STYLES ===
    if (!document.getElementById(STYLE_ID)) {
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.innerHTML = `
            /* === Wrapper et bouton sobre === */
            .quagga-wrapper {
                position: relative;
                display: inline-block;
                width: 100%;
                max-width: 100%;
            }

            .quagga-wrapper .quagga-btn {
                position: absolute;
                right: 8px;
                top: 50%;
                transform: translateY(-50%);
                z-index: 10;
                border: 0;
                background: transparent;
                color: #6c757d;
                width: 32px;
                height: 32px;
                border-radius: 4px;
                font-size: 18px;
                line-height: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: color 0.2s, background 0.2s;
                padding: 0;
            }

            .quagga-wrapper .quagga-btn:hover {
                color: #212529;
                background: rgba(0, 0, 0, 0.05);
            }

            .quagga-wrapper .quagga-btn:focus {
                outline: none;
            }

            .quagga-wrapper input {
                padding-right: 46px !important;
            }

            /* === Overlay === */
            #${OVERLAY_ID} {
                position: fixed;
                inset: 0;
                z-index: 999999;
                background: rgba(0, 0, 0, 0.92);
                display: none;
                flex-direction: column;
            }

            /* === Top bar épurée === */
            #koha-quagga-topbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 16px;
                color: #e9ecef;
                gap: 12px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: rgba(0, 0, 0, 0.6);
                z-index: 10;
                flex-wrap: wrap;
                border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            }

            #koha-quagga-topbar-left {
                display: flex;
                align-items: center;
                gap: 10px;
                flex-wrap: wrap;
            }

            #koha-quagga-topbar-left strong {
                font-weight: 500;
                font-size: 15px;
                letter-spacing: 0.3px;
                color: #dee2e6;
            }

            #koha-quagga-restart-btn {
                padding: 4px 12px;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 4px;
                background: transparent;
                color: #ced4da;
                font-size: 12px;
                cursor: pointer;
                transition: background 0.2s, color 0.2s;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }

            #koha-quagga-restart-btn:hover {
                background: rgba(255, 255, 255, 0.08);
                color: #fff;
            }

            #koha-quagga-close {
                border: 0;
                border-radius: 4px;
                padding: 4px 14px;
                cursor: pointer;
                background: transparent;
                color: #adb5bd;
                font-size: 13px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                transition: background 0.2s, color 0.2s;
            }

            #koha-quagga-close:hover {
                background: rgba(220, 53, 69, 0.15);
                color: #f8d7da;
            }

            /* === Statut === */
            #koha-quagga-status {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 12px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                color: #adb5bd;
            }

            #koha-quagga-status-dot {
                width: 8px;
                height: 8px;
                border-radius: 50%;
                background: #6c757d;
                display: inline-block;
                transition: background 0.3s;
            }

            #koha-quagga-status-dot.scanning {
                background: #ffc107;
                animation: pulse-dot 0.8s ease-in-out infinite;
            }

            #koha-quagga-status-dot.detected {
                background: #28a745;
            }

            #koha-quagga-status-dot.error {
                background: #dc3545;
            }

            #koha-quagga-status-dot.verifying {
                background: #17a2b8;
                animation: pulse-dot 0.4s ease-in-out infinite;
            }

            @keyframes pulse-dot {
                0%, 100% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.4; transform: scale(0.8); }
            }

            /* === Résolution affichée === */
            #koha-quagga-resolution {
                font-size: 11px;
                color: #6c757d;
                font-family: monospace;
                margin-left: 4px;
            }

            /* === Vidéo === */
            #${VIDEO_ID} {
                flex: 1;
                min-height: 0;
                width: 100%;
                object-fit: cover;
                background: #000;
            }

            /* === Message === */
            #${MSG_ID} {
                padding: 10px 16px 16px;
                color: #adb5bd;
                text-align: center;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 13px;
                background: rgba(0, 0, 0, 0.6);
                border-top: 1px solid rgba(255, 255, 255, 0.04);
                letter-spacing: 0.2px;
            }

            #${MSG_ID} strong {
                color: #e9ecef;
                font-weight: 500;
            }

            #${MSG_ID} .highlight {
                color: #ffc107;
            }

            #${MSG_ID} .progress {
                color: #17a2b8;
            }

            /* === Cache le canvas de Quagga === */
            #${OVERLAY_ID} canvas.drawingBuffer {
                display: none !important;
            }

            /* === Responsive pour petits écrans === */
            @media (max-width: 480px) {
                #koha-quagga-topbar-left strong {
                    font-size: 13px;
                }
                #koha-quagga-restart-btn {
                    font-size: 11px;
                    padding: 3px 8px;
                }
                #koha-quagga-close {
                    font-size: 12px;
                    padding: 3px 10px;
                }
                #koha-quagga-status {
                    font-size: 11px;
                }
                #koha-quagga-resolution {
                    font-size: 10px;
                }
            }
        `;
        document.head.appendChild(style);
    }

    // === État ===
    let active = false;
    let isScanning = false;
    let quaggaStream = null;
    let currentInput = null;

    // === État pour la vérification multiple ===
    let verificationState = {
        code: null,
        count: 0,
        timer: null,
        lastRead: null,
        isVerifying: false
    };

    // === Icône sobre (caméra stylisée) ===
    function createIcon() {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('width', '20');
        svg.setAttribute('height', '20');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        svg.setAttribute('stroke-width', '1.8');
        svg.setAttribute('stroke-linecap', 'round');
        svg.setAttribute('stroke-linejoin', 'round');
        svg.innerHTML = `
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
            <circle cx="12" cy="13" r="4" />
        `;
        return svg;
    }

    // === Équiper un champ avec le bouton ===
    function equipInput(input) {
        if (!input) return;
        if (input.dataset.quaggaReady === '1') return;

        const wrapper = document.createElement('span');
        wrapper.className = 'quagga-wrapper';
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'quagga-btn';
        btn.setAttribute('aria-label', 'Scanner un code-barres');
        btn.title = 'Scanner un code-barres';
        btn.appendChild(createIcon());
        wrapper.appendChild(btn);

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            openScanner(input);
        });

        input.dataset.quaggaReady = '1';
        (function(){})(`[Quagga] Champ équipé: #${input.id || input.name}`);
    }

    // === Trouver tous les champs cibles ===
    function findAndEquipInputs() {
        if(options.extraSelector)document.querySelectorAll(options.extraSelector).forEach(equipInput);
        TARGET_INPUTS.forEach(selector => {
            const inputs = document.querySelectorAll(`#${selector}`);
            if (inputs.length === 0) {
                const byName = document.querySelectorAll(`input[name="${selector}"]`);
                byName.forEach(input => equipInput(input));
                return;
            }
            inputs.forEach(input => equipInput(input));
        });

        // Champs DataTables
        document.querySelectorAll('.dt-search input[type="search"]').forEach(input => {
            if (!input.dataset.quaggaReady) {
                equipInput(input);
            }
        });

        document.querySelectorAll('[data-quagga-target]').forEach(input => {
            equipInput(input);
        });
    }

    // === Overlay ===
    function ensureOverlay() {
        let overlay = document.getElementById(OVERLAY_ID);
        if (overlay) return overlay;

        overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;

        overlay.innerHTML = `
            <div id="koha-quagga-topbar">
                <div id="koha-quagga-topbar-left">
                    <strong>📷 Scanner</strong>
                    <button type="button" id="koha-quagga-restart-btn">Relancer</button>
                </div>
                <div id="koha-quagga-status">
                    <span id="koha-quagga-status-dot"></span>
                    <span id="koha-quagga-status-text">Prêt</span>
                    <span id="koha-quagga-resolution"></span>
                </div>
                <button type="button" id="koha-quagga-close">Fermer</button>
            </div>
            <video id="${VIDEO_ID}" autoplay playsinline muted></video>
            <div id="${MSG_ID}">Alignez le code-barres dans le cadre</div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('#koha-quagga-close').addEventListener('click', closeScanner);
        overlay.querySelector('#koha-quagga-restart-btn').addEventListener('click', function () {
            restartScan();
        });
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) closeScanner();
        });

        return overlay;
    }

    function loadQuagga() {
        return new Promise(function (resolve, reject) {
            if (window.Quagga) {
                resolve();
                return;
            }

            const s = document.createElement('script');
            s.src = 'https://cdn.jsdelivr.net/npm/@ericblade/quagga2@1.8.2/dist/quagga.min.js';
            s.onload = function () {
                (function(){})('[Quagga] Chargé');
                resolve();
            };
            s.onerror = function () {
                reject(new Error('Impossible de charger Quagga2'));
            };
            document.head.appendChild(s);
        });
    }

    function setStatus(text, state, resolution) {
        const dot = document.getElementById('koha-quagga-status-dot');
        const label = document.getElementById('koha-quagga-status-text');
        const msg = document.getElementById(MSG_ID);
        const resEl = document.getElementById('koha-quagga-resolution');

        if (label) label.textContent = text;
        if (resEl && resolution) {
            resEl.textContent = `📐 ${resolution}`;
        } else if (resEl) {
            resEl.textContent = '';
        }
        if (dot) {
            dot.className = '';
            if (state === 'scanning') dot.classList.add('scanning');
            else if (state === 'detected') dot.classList.add('detected');
            else if (state === 'error') dot.classList.add('error');
            else if (state === 'verifying') dot.classList.add('verifying');
        }
        if (msg && state !== 'error') {
            msg.textContent = text;
        }
    }

    function cleanBarcode(code, format) {
        if (!code) return code;

        let cleaned = code;

        if (format === 'codabar_reader' || format === 'codabar') {
            cleaned = cleaned.replace(/^[A-Da-d]+/, '').replace(/[A-Da-d]+$/, '');
            if (cleaned !== code) (function(){})(`[Quagga] Codabar nettoyé: "${code}" → "${cleaned}"`);
        }

        if (format === 'code_39_reader' || format === 'code_39') {
            cleaned = cleaned.replace(/^\*+/, '').replace(/\*+$/, '');
            if (cleaned !== code) (function(){})(`[Quagga] Code39 nettoyé: "${code}" → "${cleaned}"`);
        }

        if (format === 'code_128_reader' || format === 'code_128') {
            cleaned = cleaned.replace(/^[^\x20-\x7E]+/, '').replace(/[^\x20-\x7E]+$/, '');
            if (cleaned !== code) (function(){})(`[Quagga] Code128 nettoyé: "${code}" → "${cleaned}"`);
        }

        return cleaned;
    }

    // === FONCTION DE VÉRIFICATION MULTIPLE ===
    function handleBarcodeRead(code, format) {
        if (!currentInput) return;
        
        const cleanedCode = cleanBarcode(code, format);
        if (!cleanedCode) return;

        (function(){})(`[Quagga] Lecture ${format}: "${cleanedCode}"`);

        // Réinitialise si un code différent est lu (si configuré)
        if (VERIFICATION_CONFIG.RESET_ON_DIFFERENT && 
            verificationState.code !== null && 
            verificationState.code !== cleanedCode) {
            (function(){})(`[Quagga] Code différent détecté, réinitialisation`);
            resetVerificationState();
        }

        // Si c'est le premier code ou le même code
        if (verificationState.code === null) {
            verificationState.code = cleanedCode;
            verificationState.count = 1;
            verificationState.lastRead = Date.now();
            verificationState.isVerifying = true;
            
            setStatus(`🔍 Vérification... (1/${VERIFICATION_CONFIG.REQUIRED_READS})`, 'verifying');
            updateMessage(`🔍 Vérification en cours... (${1}/${VERIFICATION_CONFIG.REQUIRED_READS})`);
            
            // Démarre le timer
            startVerificationTimer();
        } 
        else if (verificationState.code === cleanedCode) {
            // Incrémente le compteur
            verificationState.count++;
            verificationState.lastRead = Date.now();
            
            const progress = verificationState.count;
            const required = VERIFICATION_CONFIG.REQUIRED_READS;
            
            if (progress < required) {
                setStatus(`🔍 Vérification... (${progress}/${required})`, 'verifying');
                updateMessage(`🔍 Vérification en cours... (${progress}/${required})`);
                
                // Réinitialise le timer
                resetVerificationTimer();
                startVerificationTimer();
            } else {
                // ✅ Lecture confirmée !
                (function(){})(`[Quagga] ✅ Code confirmé après ${progress} lectures: "${cleanedCode}"`);
                confirmBarcode(cleanedCode);
            }
        }
    }

    function resetVerificationState() {
        if (verificationState.timer) {
            clearTimeout(verificationState.timer);
            verificationState.timer = null;
        }
        verificationState.code = null;
        verificationState.count = 0;
        verificationState.lastRead = null;
        verificationState.isVerifying = false;
    }

    function startVerificationTimer() {
        if (verificationState.timer) {
            clearTimeout(verificationState.timer);
        }
        
        verificationState.timer = setTimeout(() => {
            (function(){})(`[Quagga] ⏱️ Délai d'attente dépassé, réinitialisation`);
            resetVerificationState();
            setStatus('🔍 Scan en cours...', 'scanning');
            updateMessage('Alignez le code-barres dans le cadre');
        }, VERIFICATION_CONFIG.TIMEOUT_MS);
    }

    function resetVerificationTimer() {
        if (verificationState.timer) {
            clearTimeout(verificationState.timer);
            verificationState.timer = null;
        }
    }

    function confirmBarcode(cleanedCode) {
        resetVerificationState();
        
        // ✅ Insère le code dans le champ
        if (currentInput) {
            currentInput.value = cleanedCode;
            currentInput.dispatchEvent(new Event('input', { bubbles: true }));
            currentInput.dispatchEvent(new Event('change', { bubbles: true }));
            currentInput.dispatchEvent(new Event('blur', { bubbles: true }));
        }

        setStatus(`✅ ${cleanedCode}`, 'detected');
        updateMessage(`✅ Code-barres validé : <strong>${cleanedCode}</strong>`);

        // Ferme après un court délai
        setTimeout(closeScanner, 600);
    }

    function updateMessage(text) {
        const msg = document.getElementById(MSG_ID);
        if (msg) msg.innerHTML = text;
    }

    function stopCurrentScan() {
        try {
            if (window.Quagga) {
                window.Quagga.stop();
                window.Quagga.offDetected();
            }
        } catch (e) {}

        const video = document.getElementById(VIDEO_ID);
        if (video && video.srcObject) {
            video.srcObject.getTracks().forEach(track => track.stop());
            video.srcObject = null;
        }
        quaggaStream = null;
        resetVerificationState();
        setStatus('Prêt', '');
    }

    // === RÉSOLUTION AMÉLIORÉE ===
    async function getBestCameraResolution() {
        const resolutions = [
            { width: 3840, height: 2160 },
            { width: 2560, height: 1440 },
            { width: 1920, height: 1080 },
            { width: 1600, height: 1200 },
            { width: 1280, height: 720 },
            { width: 1024, height: 768 }
        ];

        try {
            for (const res of resolutions) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({
                        video: {
                            width: { ideal: res.width },
                            height: { ideal: res.height },
                            facingMode: 'environment'
                        }
                    });
                    const track = stream.getVideoTracks()[0];
                    const settings = track.getSettings();
                    stream.getTracks().forEach(t => t.stop());
                    
                    (function(){})(`[Quagga] Résolution testée: ${res.width}x${res.height} → OK (obtenue: ${settings.width}x${settings.height})`);
                    return {
                        width: settings.width || res.width,
                        height: settings.height || res.height
                    };
                } catch (e) {
                    (function(){})(`[Quagga] Résolution ${res.width}x${res.height} non supportée`);
                }
            }
        } catch (e) {
            (function(){})('[Quagga] Impossible de tester les résolutions, fallback HD');
        }

        return { width: 1280, height: 720 };
    }

    async function startQuaggaScan() {
        const video = document.getElementById(VIDEO_ID);
        if (!video) {
            setStatus('Erreur: vidéo non trouvée', 'error');
            return;
        }

        if (!currentInput) {
            setStatus('Erreur: aucun champ cible', 'error');
            return;
        }

        try {
            const bestResolution = await getBestCameraResolution();
            (function(){})(`[Quagga] Résolution sélectionnée: ${bestResolution.width}x${bestResolution.height}`);

            const stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: bestResolution.width },
                    height: { ideal: bestResolution.height },
                    facingMode: 'environment',
                    focusMode: 'continuous',
                    zoom: { ideal: 1.0 }
                },
                audio: false
            });

            video.srcObject = stream;
            await video.play();
            quaggaStream = stream;

            const track = stream.getVideoTracks()[0];
            const settings = track.getSettings();
            const resolutionStr = `${settings.width || bestResolution.width}×${settings.height || bestResolution.height}`;
            (function(){})(`[Quagga] Caméra: ${track.label || 'unknown'}, Résolution: ${resolutionStr}`);

            setStatus('🔍 Scan en cours...', 'scanning', resolutionStr);
            updateMessage('Alignez le code-barres dans le cadre');

            const config = {
                inputStream: {
                    name: 'Live',
                    type: 'LiveStream',
                    target: video,
                    constraints: {
                        facingMode: 'environment',
                        width: { ideal: bestResolution.width },
                        height: { ideal: bestResolution.height }
                    }
                },
                decoder: {
                    readers: [
                        'code_128_reader',
                        'code_39_reader',
                        'code_93_reader',
                        'codabar_reader',
                        'ean_reader',
                        'ean_8_reader',
                        'upc_reader',
                        'upc_e_reader',
                        'i2of5_reader'
                    ],
                    multiple: false
                },
                locator: {
                    patchSize: 'medium',
                    halfSample: true
                },
                frequency: 20,
                locate: true
            };

            if (window.Quagga) {
                try {
                    window.Quagga.stop();
                    window.Quagga.offDetected();
                } catch (e) {}
            }

            window.Quagga.init(config, function(err) {
                if (err) {
                    (function(){})('[Quagga] Erreur init:', err);
                    setStatus('Erreur: ' + err.message, 'error');
                    isScanning = false;
                    return;
                }

                window.Quagga.start();
                (function(){})('[Quagga] Démarré en mode Auto');

                window.Quagga.onDetected(function(result) {
                    if (result && result.codeResult) {
                        // Utilise la nouvelle fonction avec vérification multiple
                        handleBarcodeRead(result.codeResult.code, result.codeResult.format);
                    }
                });
            });

        } catch (err) {
            (function(){})('[Quagga] Erreur:', err);
            setStatus('Erreur: ' + (err.message || 'inconnue'), 'error');
            isScanning = false;
        }
    }

    async function startScan() {
        if (isScanning) return;

        stopCurrentScan();
        isScanning = true;

        const video = document.getElementById(VIDEO_ID);
        if (video) video.style.display = 'block';

        try {
            await loadQuagga();
            await startQuaggaScan();
        } catch (err) {
            (function(){})('[Quagga] Erreur:', err);
            isScanning = false;
            setStatus('Erreur: ' + (err.message || 'inconnue'), 'error');
        }
    }

    async function restartScan() {
        stopCurrentScan();
        isScanning = false;
        resetVerificationState();
        await startScan();
    }

    async function openScanner(input) {
        if (active) return;
        active = true;
        isScanning = false;
        currentInput = input;
        resetVerificationState();

        const overlay = ensureOverlay();
        overlay.style.display = 'flex';

        setStatus('🔍 Détection de la meilleure résolution...', '');

        try {
            await loadQuagga();
            await startScan();
        } catch (e) {
            (function(){})('[Quagga] Erreur:', e);
            setStatus('Erreur: ' + (e.message || 'inconnue'), 'error');
            active = false;
        }
    }

    function closeScanner() {
        active = false;
        isScanning = false;

        stopCurrentScan();
        resetVerificationState();

        try {
            if (window.Quagga) {
                window.Quagga.stop();
                window.Quagga.offDetected();
            }
        } catch (e) {}

        const overlay = document.getElementById(OVERLAY_ID);
        if (overlay) overlay.style.display = 'none';
        currentInput = null;
        updateMessage('Alignez le code-barres dans le cadre');
    }

    // === Initialisation ===
    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                findAndEquipInputs();
            });
        } else {
            findAndEquipInputs();
        }

        const observer = new MutationObserver(function() {
            findAndEquipInputs();
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        (function(){})('[Quagga Scanner] Chargé (mobile uniquement)');
        (function(){})(`[Quagga Scanner] Champs cibles: ${TARGET_INPUTS.join(', ')}`);
        (function(){})('[Quagga Scanner] Mode: Auto (tous les formats)');
        (function(){})('[Quagga Scanner] Résolution: Auto (meilleure disponible)');
        (function(){})(`[Quagga Scanner] Vérification: ${VERIFICATION_CONFIG.REQUIRED_READS} lectures requises, délai ${VERIFICATION_CONFIG.TIMEOUT_MS}ms`);
    }

    init();
})();








// === GESTION DES RÉSULTATS (UNIQUEMENT SUR SEARCH.PL) ===
(function() {
    // Vérifier qu'on est bien sur la page search.pl
    if (!window.location.pathname.includes('/catalogue/search.pl')) {
        return;
    }

    (function (callback) {
        if (document.readyState !== 'loading') callback.call(document);
        else document.addEventListener('DOMContentLoaded', callback, { once: true });
    })(function() {
        // ====== 1. BOUTON "AFFICHER PLUS" ======
        function initResultRow(row) {
            if (row.dataset.initialized === 'true') return;
            row.dataset.initialized = 'true';

            var thirdCell = row.querySelector('td:nth-child(3)');
            if (!thirdCell) return;

            var titleElement = thirdCell.querySelector('.firstresult');
            if (!titleElement) return;

            // Créer le conteneur pour les détails
            var detailsContainer = document.createElement('div');
            detailsContainer.className = 'notice-details';
            detailsContainer.id = 'details-' + Math.random().toString(36).substr(2, 9);

            // Collecter les éléments à déplacer
            var elementsToMove = [];
            var currentElement = titleElement.nextElementSibling;
            
            while (currentElement) {
                var nextElement = currentElement.nextElementSibling;
                
                if (currentElement.classList && 
                    (currentElement.classList.contains('bouton') || 
                     currentElement.querySelector('.bouton'))) {
                    elementsToMove.push(currentElement);
                } else if (currentElement.tagName !== 'BR' && 
                           !currentElement.classList.contains('btn-show-more') &&
                           !currentElement.classList.contains('notice-details')) {
                    elementsToMove.push(currentElement);
                }
                
                currentElement = nextElement;
            }

            elementsToMove.forEach(function(el) {
                detailsContainer.appendChild(el);
            });

            titleElement.after(detailsContainer);

            // Créer le bouton
            var showBtn = document.createElement('button');
            showBtn.className = 'btn-show-more';
            showBtn.innerHTML = 'Afficher plus <span class="arrow">▼</span>';
            showBtn.setAttribute('aria-expanded', 'false');
            
            showBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                var isVisible = detailsContainer.classList.toggle('visible');
                this.innerHTML = isVisible ? 
                    'Afficher moins <span class="arrow open">▲</span>' : 
                    'Afficher plus <span class="arrow">▼</span>';
                this.setAttribute('aria-expanded', isVisible);
                
                var rowId = row.id || 'row-' + Math.random().toString(36).substr(2, 9);
                if (!row.id) row.id = rowId;
                
                var expandedState = JSON.parse(localStorage.getItem('expandedRows') || '{}');
                expandedState[rowId] = isVisible;
                localStorage.setItem('expandedRows', JSON.stringify(expandedState));
            });

            titleElement.after(showBtn);

            // Restaurer l'état
            var rowId = row.id || 'row-' + Math.random().toString(36).substr(2, 9);
            if (!row.id) row.id = rowId;
            
            var expandedState = JSON.parse(localStorage.getItem('expandedRows') || '{}');
            if (expandedState[rowId]) {
                detailsContainer.classList.add('visible');
                showBtn.innerHTML = 'Afficher moins <span class="arrow open">▲</span>';
                showBtn.setAttribute('aria-expanded', 'true');
            }

            // Transformer en icônes UNIQUEMENT SI ON EST SUR MOBILE
            if (window.innerWidth <= 768) {
                transformLinksToIcons(row);
            }

            // Gérer les boutons "Afficher/Masquer" existants
            var toggleButtons = detailsContainer.querySelectorAll('.bouton');
            toggleButtons.forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var target = this.nextElementSibling;
                    while (target && !target.classList.contains('sectionz')) {
                        target = target.nextElementSibling;
                    }
                    if (target) {
                        if (target.style.display === 'none' || !target.style.display) {
                            target.style.display = 'block';
                            this.textContent = 'Masquer le résumé';
                        } else {
                            target.style.display = 'none';
                            this.textContent = 'Afficher/Masquer le résumé';
                        }
                    }
                });
            });

            // Gérer les boutons des exemplaires
            var exemplaireBtns = row.querySelectorAll('.btn-toggle-exemplaire');
            exemplaireBtns.forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var detailsDiv = this.closest('.bloc-exemplaire').querySelector('.details-exemplaire');
                    if (detailsDiv) {
                        if (detailsDiv.style.display === 'none' || !detailsDiv.style.display) {
                            detailsDiv.style.display = 'block';
                            this.textContent = 'Masquer détails';
                        } else {
                            detailsDiv.style.display = 'none';
                            this.textContent = 'Afficher détails';
                        }
                    }
                });
            });
        }

        // ====== 2. TRANSFORMER LES LIENS EN ICÔNES ======
        function transformLinksToIcons(row) {
            var holdElement = row.querySelector('.hold');
            if (!holdElement) return;

            var actionContainer = document.createElement('div');
            actionContainer.className = 'action-icons';

            var links = holdElement.querySelectorAll('a');
            var cartLink = holdElement.querySelector('.addtocart');
            var cartRemove = holdElement.querySelector('.cartRemove');

            links.forEach(function(link) {
                if (link.classList.contains('addtocart') || link.classList.contains('cartRemove')) {
                    return;
                }
                
                var newLink = document.createElement('a');
                newLink.href = link.href;
                newLink.title = link.textContent.trim().replace(/[\(\)]/g, '').trim();
                newLink.target = link.target || '';
                newLink.rel = link.rel || '';
                newLink.textContent = link.textContent;
                
                Array.from(link.attributes).forEach(function(attr) {
                    if (attr.name.startsWith('data-')) {
                        newLink.setAttribute(attr.name, attr.value);
                    }
                });
                
                if (link.onclick) {
                    newLink.onclick = link.onclick;
                }
                
                actionContainer.appendChild(newLink);
            });

            if (cartLink) {
                var cartClone = cartLink.cloneNode(true);
                cartClone.className = 'addtocart';
                cartClone.textContent = 'Ajouter au panier';
                cartClone.title = 'Ajouter au panier';
                if (cartLink.onclick) {
                    cartClone.onclick = cartLink.onclick;
                }
                actionContainer.appendChild(cartClone);
            }

            if (cartRemove) {
                var removeClone = cartRemove.cloneNode(true);
                removeClone.className = 'cartRemove';
                removeClone.textContent = '(Supprimer)';
                removeClone.title = 'Retirer du panier';
                if (cartRemove.onclick) {
                    removeClone.onclick = cartRemove.onclick;
                }
                actionContainer.appendChild(removeClone);
            }

            holdElement.parentNode.replaceChild(actionContainer, holdElement);
        }

        // ====== 3. INITIALISER TOUTES LES LIGNES ======
        function initAllRows() {
            var rows = document.querySelectorAll('#searchresults tbody tr');
            rows.forEach(function(row) {
                initResultRow(row);
            });
        }

        // ====== 4. OBSERVER LES CHANGEMENTS ======
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1 && node.tagName === 'TR') {
                        initResultRow(node);
                    }
                    if (node.querySelectorAll) {
                        node.querySelectorAll('#searchresults tbody tr').forEach(function(row) {
                            if (!row.dataset.initialized) {
                                initResultRow(row);
                            }
                        });
                    }
                });
            });
        });

        var targetNode = document.getElementById('searchresults');
        if (targetNode) {
            observer.observe(targetNode, {
                childList: true,
                subtree: true,
                attributes: false
            });
        }

        // ====== 5. INITIALISATION ======
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            initAllRows();
        } else {
            document.addEventListener('DOMContentLoaded', initAllRows);
        }

        // Réinitialiser après un changement de page
        document.addEventListener('searchresults-updated', initAllRows);

        // === EXPOSER LA FONCTION ===
        window.initSearchResults = function() {
            var rows = document.querySelectorAll('#searchresults tbody tr');
            rows.forEach(function(row) {
                row.dataset.initialized = 'false';
                initResultRow(row);
            });
        };
    });
})();



})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("112-responsive.js");
} catch (error) { window.PMKNonPlugin.errors.push("112-responsive.js: "+error.message); console.error("[PMK] 112-responsive.js",error); };
try {
/*
 Nom du fichier : 113-autocomplete-elestic.js
 Module PMK : search-autocomplete-performance
 Version : 3.1.0-preplugin
 Date : 2026-09-21
 Description :
   Autocomplétion catalogue Koha enrichie issue du script historique 113.
   Conserve le scoring, les 20 résultats, les 8 enrichissements automatiques,
   la disponibilité locale/ailleurs, la cote, les couvertures Electre et
   le bouton de recherche classique.

   Évolutions 3.0 :
   - recherche code-barres exemplaire via /api/v1/items?external_id=... ;
   - fusion des résultats exemplaire + notice par biblio_id ;
   - priorité maximale au CB exact ;
   - réutilisation facultative du moteur de reconnaissance du module 036 ;
   - cache recherche / disponibilité / code-barres / couverture ;
   - disponibilité groupée via /api/v1/items, avec repli par notice ;
   - concurrence bornée pour les enrichissements ;
   - configuration PMK complète, FR/EN, responsive et rendu Koha intégré ;
   - annulation stricte des recherches devenues obsolètes.
   - constructeur accessible de formats de codes-barres (sans regex obligatoire) ;
   - preset d’origine DR + 9 chiffres et test visuel des exemples ;
   - la regex reste disponible uniquement pour les formats experts.

 IMPORTANT :
   - aucune écriture dans Koha ;
   - aucune recherche externe Google Books ;
   - la recherche classique Koha reste la référence exhaustive.
*/
(function (window, document, $) {
    "use strict";

    const MODULE_ID = "search-autocomplete-performance";
    const MODULE_VERSION = "3.1.0-preplugin";
    const OWNED_DATA_KEY = "pmk113Owned";
    const STYLE_ID = "pmk113-autocomplete-styles";
    const PREVIEW_ID = "pmk113-cover-preview";
    const CONTEXT_KEY = "pmk113-search-autocomplete";

    if (!window || !document || !$) return;
    if (window.__PMK113AutocompleteV3) return;
    window.__PMK113AutocompleteV3 = true;

    const HISTORICAL_INDEX_MAPPINGS = [
        { enabled:true, indexCode:"au", fields:"author" },
        { enabled:true, indexCode:"pn", fields:"author" },
        { enabled:true, indexCode:"ti", fields:"title,unititle" },
        { enabled:true, indexCode:"se", fields:"title" },
        { enabled:true, indexCode:"nb", fields:"isbn" },
        { enabled:true, indexCode:"ns", fields:"issn" },
        { enabled:true, indexCode:"pb", fields:"publisher" },
        { enabled:true, indexCode:"pl", fields:"publication_place" },
        { enabled:true, indexCode:"nt", fields:"notes" },
        { enabled:true, indexCode:"callnum", fields:"cn_sort" },
        { enabled:true, indexCode:"yr", fields:"publication_year" }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        scope: {
            inputSelector: "#search-form",
            indexSelector: "#idx_0",
            pageMode: "where-input-exists",
            pages: [
                { enabled:true, path:"/cgi-bin/koha/mainpage.pl", labelFr:"Accueil Koha", labelEn:"Koha home" },
                { enabled:true, path:"/cgi-bin/koha/catalogue/search.pl", labelFr:"Recherche catalogue", labelEn:"Catalogue search" }
            ]
        },
        search: {
            minLength: 3,
            delayMs: 180,
            resultsCount: 20,
            keywordFields: "title,author,unititle",
            indexMappings: HISTORICAL_INDEX_MAPPINGS,
            replaceExistingAutocomplete: true,
            classicSearchEnabled: true,
            warningEnabled: true,
            warningFr: "Attention, toutes les zones des notices ne sont pas interrogées par ce système. N’hésitez pas à lancer quand même une recherche classique.",
            warningEn: "Not all record fields are searched by these suggestions. Use the full Koha search when needed.",
            zonesFr: "Zones interrogées : titre, sous-titre, auteur, éditeur, année, ISBN, ISSN, notes, cote, lieu de publication et code-barres d’exemplaire.",
            zonesEn: "Searched fields: title, subtitle, author, publisher, year, ISBN, ISSN, notes, call number, publication place and item barcode.",
            classicButtonFr: "Lancer une recherche classique",
            classicButtonEn: "Run full Koha search"
        },
        barcode: {
            enabled: true,
            use036Recognizer: true,
            accepted036ProfileIds: "koha-barcode-index,isbn13,isbn10,issn,ean13,upca,ean8,dr-prefix,numeric-10,generic-numeric,generic-alphanumeric,aim-code128,aim-code39,aim-ean-upc",
            forcedIndexCodes: "bc,barcode",
            exactEnabled: true,
            prefixEnabled: true,
            prefixMinLength: 8,
            maxMatches: 10,
            displayBarcode: true,
            exactScoreBonus: 5000,
            prefixScoreBonus: 1800,
            fallbackProfiles: [
                {
                    id: "dr-9-digits",
                    enabled: true,
                    labelFr: "Configuration initiale — DR + 9 chiffres",
                    labelEn: "Initial configuration — DR + 9 digits",
                    mode: "prefix-digits",
                    prefix: "DR",
                    minLength: 9,
                    maxLength: 9,
                    example: "DR100007790",
                    regex: ""
                },
                {
                    id: "numeric-library-barcode",
                    enabled: true,
                    labelFr: "Code-barres numérique",
                    labelEn: "Numeric barcode",
                    mode: "digits",
                    prefix: "",
                    minLength: 8,
                    maxLength: 40,
                    example: "00000000000001",
                    regex: ""
                },
                {
                    id: "alphanumeric-library-barcode",
                    enabled: true,
                    labelFr: "Code-barres alphanumérique générique",
                    labelEn: "Generic alphanumeric barcode",
                    mode: "alphanumeric",
                    prefix: "",
                    minLength: 8,
                    maxLength: 40,
                    example: "A12345678",
                    regex: ""
                }
            ]
        },
        scoring: {
            titleTerm: 120,
            authorTerm: 90,
            unititleTerm: 70,
            publisherTerm: 35,
            yearTerm: 15,
            itemTypeTerm: 10,
            isbnTerm: 25,
            eanTerm: 25,
            titleExact: 900,
            titlePrefix: 500,
            titleContains: 220,
            authorExact: 650,
            authorPrefix: 350,
            unititleExact: 400,
            allTermsInTitle: 350,
            isbnExact: 1200,
            eanExact: 1200
        },
        availability: {
            enabled: true,
            autoEnrichCount: 8,
            strategy: "bulk-then-queue",
            concurrency: 3,
            bulkMaxItems: 500,
            showHereElsewhere: true,
            showCallnumber: true,
            cacheTtlMs: 60000
        },
        covers: {
            enabled: true,
            autoLoad: true,
            autoEnrichCount: 8,
            provider: "electre",
            endpoint: "/api/v1/contrib/electre/image",
            useFallbackUrl: true,
            concurrency: 1,
            cacheTtlMs: 3600000,
            previewEnabled: true,
            previewWidthPx: 220,
            previewHeightPx: 320,
            thumbWidthPx: 40,
            thumbHeightPx: 55
        },
        performance: {
            searchCacheTtlMs: 30000,
            barcodeCacheTtlMs: 60000,
            maxSearchCacheEntries: 80,
            abortObsoleteRequests: true
        },
        display: {
            kohaIntegrated: true,
            maxHeightPx: 500,
            menuWidthMode: "input",
            fixedWidthPx: 520,
            showAuthor: true,
            showPublisher: true,
            showYear: true,
            showItemType: true,
            responsiveBreakpointPx: 576
        }
    };

    let currentConfig = deepClone(DEFAULT_CONFIG);
    let configRegistered = false;
    let unsubscribeConfig = null;
    let $input = $();
    let searchGeneration = 0;
    let activeSearchXhrs = [];
    let currentItemMap = new Map();
    let searchCache = new Map();
    let barcodeCache = new Map();
    let availabilityCache = new Map();
    let coverCache = new Map();
    let availabilityQueue = [];
    let availabilityRunning = 0;
    let availabilityQueuedKeys = new Set();
    let coverQueue = [];
    let coverRunning = 0;
    let coverQueuedKeys = new Set();
    let previewBound = false;
    let lazyBound = false;
    let moduleStarted = false;

    function deepClone(value) {
        return value == null ? value : JSON.parse(JSON.stringify(value));
    }

    function isObject(value) {
        return !!value && typeof value === "object" && !Array.isArray(value);
    }

    function mergeDeep(base, patch) {
        if (Array.isArray(base)) {
            return Array.isArray(patch) ? deepClone(patch) : deepClone(base);
        }
        if (!isObject(base)) return patch === undefined ? base : deepClone(patch);
        const out = {};
        Object.keys(base).forEach(function (key) {
            out[key] = deepClone(base[key]);
        });
        if (isObject(patch)) {
            Object.keys(patch).forEach(function (key) {
                if (isObject(base[key]) && isObject(patch[key])) out[key] = mergeDeep(base[key], patch[key]);
                else out[key] = deepClone(patch[key]);
            });
        }
        return out;
    }

    function clampNumber(value, fallback, min, max) {
        let n = Number(value);
        if (!Number.isFinite(n)) n = Number(fallback);
        if (Number.isFinite(min)) n = Math.max(min, n);
        if (Number.isFinite(max)) n = Math.min(max, n);
        return n;
    }

    function splitCsv(value) {
        return String(value || "")
            .split(/[,\n;]+/)
            .map(function (s) { return s.trim(); })
            .filter(Boolean);
    }

    function escapeRegexLiteral(value) {
        return String(value == null ? "" : value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function normalizeBarcodeProfile(profile, index) {
        profile = profile && typeof profile === "object" ? profile : {};
        let mode = String(profile.mode || "").trim();
        if (["digits", "alphanumeric", "prefix-digits", "prefix-alphanumeric", "expert"].indexOf(mode) === -1) {
            mode = profile.regex ? "expert" : "alphanumeric";
        }
        let minLength = clampNumber(profile.minLength, mode === "expert" ? 1 : 8, 0, 128);
        let maxLength = clampNumber(profile.maxLength, mode === "expert" ? Math.max(minLength, 128) : Math.max(minLength, 40), 0, 128);
        if (maxLength < minLength) maxLength = minLength;
        return {
            id: String(profile.id || ("barcode-" + String(index + 1))).trim(),
            enabled: profile.enabled !== false,
            labelFr: String(profile.labelFr || profile.label || "Format de code-barres").trim(),
            labelEn: String(profile.labelEn || profile.label || "Barcode format").trim(),
            mode: mode,
            prefix: String(profile.prefix || ""),
            minLength: minLength,
            maxLength: maxLength,
            example: String(profile.example || "").trim(),
            regex: String(profile.regex || "").trim()
        };
    }

    function barcodeProfileRegexSource(profile) {
        const p = normalizeBarcodeProfile(profile, 0);
        if (p.mode === "expert") return p.regex;

        const min = Math.max(0, Number(p.minLength) || 0);
        const max = Math.max(min, Number(p.maxLength) || min);
        const quantifier = min === max ? "{" + min + "}" : "{" + min + "," + max + "}";
        const prefix = escapeRegexLiteral(p.prefix || "");

        if (p.mode === "digits") return "^[0-9]" + quantifier + "$";
        if (p.mode === "prefix-digits") return "^" + prefix + "[0-9]" + quantifier + "$";
        if (p.mode === "prefix-alphanumeric") return "^" + prefix + "(?=[A-Za-z0-9*._-]" + quantifier + "$)(?=.*[0-9])[A-Za-z0-9*._-]+$";
        return "^(?=[A-Za-z0-9*._-]" + quantifier + "$)(?=.*[0-9])[A-Za-z0-9*._-]+$";
    }

    function barcodeProfileRegex(profile) {
        return safeRegex(barcodeProfileRegexSource(profile));
    }

    function getBarcodeProfileFromPath(root, path) {
        if (!root || !Array.isArray(path) || !root.barcode || !Array.isArray(root.barcode.fallbackProfiles)) return null;
        const pos = path.indexOf("fallbackProfiles");
        if (pos === -1) return null;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? root.barcode.fallbackProfiles[index] : null;
    }

    function barcodeProfileUsesPrefix(root, path) {
        const p = getBarcodeProfileFromPath(root, path);
        return Boolean(p && (p.mode === "prefix-digits" || p.mode === "prefix-alphanumeric"));
    }

    function barcodeProfileUsesBuilder(root, path) {
        const p = getBarcodeProfileFromPath(root, path);
        return Boolean(p && p.mode !== "expert");
    }

    function barcodeProfileIsExpert(root, path) {
        const p = getBarcodeProfileFromPath(root, path);
        return Boolean(p && p.mode === "expert");
    }

    function renderBarcodeProfilePreview(context) {
        const root = context && context.rootObject;
        const path = context && Array.isArray(context.fieldPath) ? context.fieldPath : [];
        const p = getBarcodeProfileFromPath(root, path);
        const node = document.createElement("div");
        node.style.cssText = "padding:8px 10px;border:1px solid #d8dee4;border-radius:6px;background:#f8f9fa;font-size:13px";
        if (!p) {
            node.textContent = tr("Format indisponible.", "Format unavailable.");
            return node;
        }
        const source = barcodeProfileRegexSource(p);
        const rx = safeRegex(source);
        const example = String(p.example || "").trim();
        const ok = Boolean(example && rx && rx.test(example));

        const summary = document.createElement("div");
        summary.style.fontWeight = "600";
        if (p.mode === "prefix-digits") {
            summary.textContent = tr("Format : préfixe « " + p.prefix + " » + " + p.minLength + (p.minLength === p.maxLength ? " chiffres" : " à " + p.maxLength + " chiffres"),
                "Format: prefix “" + p.prefix + "” + " + p.minLength + (p.minLength === p.maxLength ? " digits" : " to " + p.maxLength + " digits"));
        } else if (p.mode === "prefix-alphanumeric") {
            summary.textContent = tr("Format : préfixe « " + p.prefix + " » + caractères alphanumériques", "Format: prefix “" + p.prefix + "” + alphanumeric characters");
        } else if (p.mode === "digits") {
            summary.textContent = tr("Format : chiffres uniquement", "Format: digits only");
        } else if (p.mode === "alphanumeric") {
            summary.textContent = tr("Format : lettres, chiffres et séparateurs usuels", "Format: letters, digits and common separators");
        } else {
            summary.textContent = tr("Format expert", "Expert format");
        }
        node.appendChild(summary);

        const test = document.createElement("div");
        test.style.marginTop = "5px";
        if (!example) {
            test.textContent = tr("Ajoutez un exemple pour vérifier le format.", "Add an example to test the format.");
        } else {
            test.textContent = (ok ? "✓ " : "✗ ") + example + " — " + (ok ? tr("reconnu", "recognized") : tr("non reconnu", "not recognized"));
            test.style.fontWeight = "600";
        }
        node.appendChild(test);

        const technical = document.createElement("code");
        technical.textContent = source || "—";
        technical.style.cssText = "display:block;margin-top:6px;white-space:normal;word-break:break-all;color:#586069";
        node.appendChild(technical);
        return node;
    }

    function normalizeConfig(config) {
        const cfg = mergeDeep(DEFAULT_CONFIG, config || {});
        cfg.enabled = cfg.enabled !== false;
        cfg.search.minLength = clampNumber(cfg.search.minLength, 3, 1, 20);
        cfg.search.delayMs = clampNumber(cfg.search.delayMs, 180, 0, 3000);
        cfg.search.resultsCount = clampNumber(cfg.search.resultsCount, 20, 1, 100);
        cfg.barcode.prefixMinLength = clampNumber(cfg.barcode.prefixMinLength, 8, 1, 128);
        cfg.barcode.maxMatches = clampNumber(cfg.barcode.maxMatches, 10, 1, 100);
        cfg.barcode.exactScoreBonus = clampNumber(cfg.barcode.exactScoreBonus, 5000, 0, 100000);
        cfg.barcode.prefixScoreBonus = clampNumber(cfg.barcode.prefixScoreBonus, 1800, 0, 100000);
        cfg.availability.autoEnrichCount = clampNumber(cfg.availability.autoEnrichCount, 8, 0, 100);
        cfg.availability.concurrency = clampNumber(cfg.availability.concurrency, 3, 1, 8);
        cfg.availability.bulkMaxItems = clampNumber(cfg.availability.bulkMaxItems, 500, 20, 2000);
        cfg.availability.cacheTtlMs = clampNumber(cfg.availability.cacheTtlMs, 60000, 0, 3600000);
        cfg.covers.autoEnrichCount = clampNumber(cfg.covers.autoEnrichCount, 8, 0, 100);
        cfg.covers.concurrency = clampNumber(cfg.covers.concurrency, 1, 1, 4);
        cfg.covers.cacheTtlMs = clampNumber(cfg.covers.cacheTtlMs, 3600000, 0, 86400000);
        cfg.covers.previewWidthPx = clampNumber(cfg.covers.previewWidthPx, 220, 80, 600);
        cfg.covers.previewHeightPx = clampNumber(cfg.covers.previewHeightPx, 320, 100, 900);
        cfg.covers.thumbWidthPx = clampNumber(cfg.covers.thumbWidthPx, 40, 20, 120);
        cfg.covers.thumbHeightPx = clampNumber(cfg.covers.thumbHeightPx, 55, 20, 180);
        cfg.performance.searchCacheTtlMs = clampNumber(cfg.performance.searchCacheTtlMs, 30000, 0, 3600000);
        cfg.performance.barcodeCacheTtlMs = clampNumber(cfg.performance.barcodeCacheTtlMs, 60000, 0, 3600000);
        cfg.performance.maxSearchCacheEntries = clampNumber(cfg.performance.maxSearchCacheEntries, 80, 5, 500);
        cfg.display.maxHeightPx = clampNumber(cfg.display.maxHeightPx, 500, 150, 1000);
        cfg.display.fixedWidthPx = clampNumber(cfg.display.fixedWidthPx, 520, 280, 1200);
        cfg.display.responsiveBreakpointPx = clampNumber(cfg.display.responsiveBreakpointPx, 576, 320, 1200);

        if (!Array.isArray(cfg.search.indexMappings) || !cfg.search.indexMappings.length) {
            cfg.search.indexMappings = deepClone(HISTORICAL_INDEX_MAPPINGS);
        }
        if (!Array.isArray(cfg.barcode.fallbackProfiles)) {
            cfg.barcode.fallbackProfiles = deepClone(DEFAULT_CONFIG.barcode.fallbackProfiles);
        }
        cfg.barcode.fallbackProfiles = cfg.barcode.fallbackProfiles.map(normalizeBarcodeProfile);
        if (!Array.isArray(cfg.scope.pages)) {
            cfg.scope.pages = deepClone(DEFAULT_CONFIG.scope.pages);
        }
        return cfg;
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const html = String(document.documentElement.getAttribute("lang") || "").toLowerCase();
        return html.indexOf("en") === 0 ? "en" : "fr";
    }

    function tr(fr, en) {
        return language() === "en" ? en : fr;
    }

    function normalizeText(value) {
        return (value == null ? "" : String(value))
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .trim();
    }

    function digitsOnly(value) {
        return (value == null ? "" : String(value)).replace(/[^0-9Xx]/g, "").toUpperCase();
    }

    function safeRegex(pattern) {
        if (!pattern) return null;
        try { return new RegExp(String(pattern)); } catch (_) { return null; }
    }

    function pathAllowed() {
        if (!currentConfig.enabled) return false;
        const mode = String(currentConfig.scope.pageMode || "where-input-exists");
        if (mode === "where-input-exists") return true;
        if (mode === "configured-pages") {
            const path = window.location.pathname;
            return currentConfig.scope.pages.some(function (page) {
                return page && page.enabled !== false && String(page.path || "") === path;
            });
        }
        return true;
    }

    function getInput() {
        let selector = String(currentConfig.scope.inputSelector || "#search-form");
        try { return $(selector).first(); } catch (_) { return $("#search-form").first(); }
    }

    function getIndexValue() {
        let selector = String(currentConfig.scope.indexSelector || "#idx_0");
        try {
            const $idx = $(selector).first();
            return $idx.length ? String($idx.val() || "kw") : "kw";
        } catch (_) {
            return "kw";
        }
    }

    function currentBranch() {
        return String(
            $(".logged-in-branch-code").attr("data-logged-in-branch-code") ||
            $(".logged-in-branch-code").data("logged-in-branch-code") ||
            ""
        );
    }

    function cacheGet(cache, key, ttlMs) {
        const entry = cache.get(key);
        if (!entry) return null;
        if (ttlMs > 0 && Date.now() - entry.at > ttlMs) {
            cache.delete(key);
            return null;
        }
        return deepClone(entry.value);
    }

    function cacheSet(cache, key, value, maxEntries) {
        cache.set(key, { at: Date.now(), value: deepClone(value) });
        if (maxEntries && cache.size > maxEntries) {
            const first = cache.keys().next();
            if (!first.done) cache.delete(first.value);
        }
    }

    function abortSearchRequests() {
        if (currentConfig.performance.abortObsoleteRequests === false) {
            activeSearchXhrs = [];
            return;
        }
        activeSearchXhrs.forEach(function (xhr) {
            try { if (xhr && typeof xhr.abort === "function") xhr.abort(); } catch (_) {}
        });
        activeSearchXhrs = [];
    }

    function jqRequest(options) {
        const xhr = $.ajax(options);
        activeSearchXhrs.push(xhr);
        return new Promise(function (resolve, reject) {
            xhr.done(function (data, textStatus, jqXHR) {
                activeSearchXhrs = activeSearchXhrs.filter(function (x) { return x !== xhr; });
                resolve({ data:data, xhr:jqXHR || xhr });
            });
            xhr.fail(function (jqXHR, status, error) {
                activeSearchXhrs = activeSearchXhrs.filter(function (x) { return x !== xhr; });
                if (status === "abort") {
                    const e = new Error("abort");
                    e.aborted = true;
                    reject(e);
                    return;
                }
                const e = new Error(error || status || ("HTTP " + (jqXHR && jqXHR.status)));
                e.status = jqXHR && jqXHR.status;
                e.responseText = jqXHR && jqXHR.responseText;
                reject(e);
            });
        });
    }

    function isbn13to10(isbn13) {
        const clean = digitsOnly(isbn13).replace(/X/g, "");
        if (!/^978\d{10}$/.test(clean)) return null;
        const core = clean.substring(3, 12);
        let sum = 0;
        for (let i = 0; i < 9; i += 1) sum += (10 - i) * parseInt(core[i], 10);
        const check = (11 - (sum % 11)) % 11;
        return core + (check === 10 ? "X" : String(check));
    }

    function fieldsForIndex(idxValue) {
        const baseIdx = String(idxValue || "kw").split(",")[0];
        const mapping = currentConfig.search.indexMappings.find(function (row) {
            return row && row.enabled !== false && String(row.indexCode || "").trim() === baseIdx;
        });
        if (mapping) return splitCsv(mapping.fields);
        return splitCsv(currentConfig.search.keywordFields || "title,author,unititle");
    }

    function buildQueryConditions(terms, idxValue) {
        const fields = fieldsForIndex(idxValue);
        return terms.map(function (word) {
            return {
                "-or": fields.map(function (field) {
                    const cond = {};
                    cond["me." + field] = { "-like": "%" + word + "%" };
                    return cond;
                })
            };
        });
    }

    function scoreResult(item, terms, rawQuery) {
        const s = currentConfig.scoring;
        let score = 0;
        const normalizedQuery = normalizeText(rawQuery);
        const title = normalizeText(item.title);
        const author = normalizeText(item.author);
        const unititle = normalizeText(item.unititle);
        const isbn = digitsOnly(item.isbn);
        const ean = digitsOnly(item.ean);
        const queryDigits = digitsOnly(rawQuery);

        const haystacks = [
            { value:item.title || "", weight:s.titleTerm },
            { value:item.author || "", weight:s.authorTerm },
            { value:item.unititle || "", weight:s.unititleTerm },
            { value:item.publisher || "", weight:s.publisherTerm },
            { value:item.publication_year || "", weight:s.yearTerm },
            { value:item.item_type || "", weight:s.itemTypeTerm },
            { value:item.isbn || "", weight:s.isbnTerm },
            { value:item.ean || "", weight:s.eanTerm }
        ];

        terms.forEach(function (term) {
            const normalizedTerm = normalizeText(term);
            haystacks.forEach(function (entry) {
                const value = normalizeText(entry.value);
                if (value && normalizedTerm && value.indexOf(normalizedTerm) !== -1) score += Number(entry.weight) || 0;
            });
        });

        if (normalizedQuery) {
            if (title === normalizedQuery) score += Number(s.titleExact) || 0;
            else if (title.indexOf(normalizedQuery) === 0) score += Number(s.titlePrefix) || 0;
            else if (title.indexOf(normalizedQuery) !== -1) score += Number(s.titleContains) || 0;

            if (author === normalizedQuery) score += Number(s.authorExact) || 0;
            else if (author.indexOf(normalizedQuery) === 0) score += Number(s.authorPrefix) || 0;

            if (unititle === normalizedQuery) score += Number(s.unititleExact) || 0;

            const allTermsInTitle = terms.length > 1 && terms.every(function (term) {
                return title.indexOf(normalizeText(term)) !== -1;
            });
            if (allTermsInTitle) score += Number(s.allTermsInTitle) || 0;
        }

        if (queryDigits.length >= 8) {
            if (isbn && queryDigits === isbn) score += Number(s.isbnExact) || 0;
            if (ean && queryDigits === ean) score += Number(s.eanExact) || 0;
        }

        if (item.barcodeMatch === "exact") score += Number(currentConfig.barcode.exactScoreBonus) || 0;
        else if (item.barcodeMatch === "prefix") score += Number(currentConfig.barcode.prefixScoreBonus) || 0;

        return score;
    }

    function sortResults(items, terms, rawQuery) {
        return items.slice().sort(function (a, b) {
            const scoreA = scoreResult(a, terms, rawQuery);
            const scoreB = scoreResult(b, terms, rawQuery);
            if (scoreA !== scoreB) return scoreB - scoreA;
            return String(a.title || "").localeCompare(String(b.title || ""), "fr", { sensitivity:"base" });
        });
    }

    function normalizeBiblio(item) {
        item = item || {};
        return {
            label: item.title || "",
            value: item.title || "",
            title: item.title || "",
            author: item.author || "",
            unititle: item.unititle || "",
            year: item.publication_year || "",
            publisher: item.publisher || "",
            item_type: item.item_type || "",
            isbn: item.isbn || "",
            ean: item.ean || "",
            fallback_url: item.url || "",
            biblio_id: item.biblio_id,
            matchedBarcodes: [],
            suggestionSources: ['catalogue'],
            barcodeMatch: ""
        };
    }

    function biblioFromEmbeddedItem(item) {
        const b = item && (item.biblio || (item._embedded && item._embedded.biblio));
        if (b) {
            const out = normalizeBiblio(b);
            if (out.biblio_id == null && item && item.biblio_id != null) out.biblio_id = item.biblio_id;
            return out;
        }
        return normalizeBiblio({
            biblio_id: item && item.biblio_id,
            title: tr("Notice #", "Record #") + String(item && item.biblio_id || "")
        });
    }

    function forcedBarcodeIndex(idxValue) {
        const base = String(idxValue || "").split(",")[0];
        return splitCsv(currentConfig.barcode.forcedIndexCodes).indexOf(base) !== -1;
    }

    function recognizeWith036(raw, idxValue) {
        if (currentConfig.barcode.use036Recognizer === false) return null;
        const api = window.PMK036CatalogueSearch;
        if (!api || typeof api.evaluateValue !== "function") return null;
        try {
            const result = api.evaluateValue(raw, idxValue || "");
            if (!result || !result.matched) return { matched:false, source:"036" };
            const id = String(result.profile && result.profile.id || "");
            const accepted = splitCsv(currentConfig.barcode.accepted036ProfileIds);
            return {
                matched: accepted.indexOf(id) !== -1 || forcedBarcodeIndex(idxValue),
                normalizedValue: String(result.normalizedValue || raw || ""),
                source: "036",
                profileId: id
            };
        } catch (_) {
            return null;
        }
    }

    function recognizeBarcode(raw, idxValue) {
        if (currentConfig.barcode.enabled === false) return { matched:false, value:String(raw || "") };
        const value = String(raw || "").trim();
        if (!value) return { matched:false, value:value };

        if (forcedBarcodeIndex(idxValue)) {
            return { matched:true, value:value, normalizedValue:value, source:"forced-index" };
        }

        const from036 = recognizeWith036(value, idxValue);
        if (from036 && from036.matched) {
            return Object.assign({ value:value }, from036);
        }

        const profiles = currentConfig.barcode.fallbackProfiles || [];
        for (let i = 0; i < profiles.length; i += 1) {
            const p = profiles[i];
            if (!p || p.enabled === false) continue;
            const rx = barcodeProfileRegex(p);
            if (rx && rx.test(value)) {
                return {
                    matched:true,
                    value:value,
                    normalizedValue:value,
                    source:"113",
                    profileId:String(p.id || "")
                };
            }
        }
        return { matched:false, value:value };
    }

    function searchBiblios(rawQuery, terms, idxValue) {
        const key = "biblio|" + idxValue + "|" + normalizeText(rawQuery);
        const cached = cacheGet(searchCache, key, currentConfig.performance.searchCacheTtlMs);
        if (cached) return Promise.resolve(cached);

        const andConditions = buildQueryConditions(terms, idxValue);
        if (!andConditions.length) return Promise.resolve([]);

        return jqRequest({
            url: "/api/v1/biblios",
            method: "GET",
            dataType: "json",
            headers: { "Accept":"application/json" },
            data: {
                q: JSON.stringify({ "-and":andConditions }),
                _per_page: currentConfig.search.resultsCount
            }
        }).then(function (result) {
            const items = $.map(Array.isArray(result.data) ? result.data : [], normalizeBiblio);
            cacheSet(searchCache, key, items, currentConfig.performance.maxSearchCacheEntries);
            return items;
        });
    }

    function barcodeRequest(value, matchMode) {
        const key = "barcode|" + matchMode + "|" + value;
        const cached = cacheGet(barcodeCache, key, currentConfig.performance.barcodeCacheTtlMs);
        if (cached) return Promise.resolve(cached);

        return jqRequest({
            url: "/api/v1/items",
            method: "GET",
            dataType: "json",
            headers: {
                "Accept":"application/json",
                "x-koha-embed":"biblio"
            },
            data: {
                external_id: value,
                _match: matchMode,
                _per_page: currentConfig.barcode.maxMatches
            }
        }).then(function (result) {
            const rows = Array.isArray(result.data) ? result.data : [];
            cacheSet(barcodeCache, key, rows, currentConfig.performance.maxSearchCacheEntries);
            return rows;
        });
    }

    async function searchBarcodes(rawQuery, idxValue, recognition) {
        if (!recognition || !recognition.matched) return [];
        const value = String(recognition.normalizedValue || rawQuery || "").trim();
        if (!value) return [];

        let rows = [];
        if (currentConfig.barcode.exactEnabled !== false) {
            rows = await barcodeRequest(value, "exact");
            if (rows.length) {
                rows.forEach(function (row) { row.__pmk113BarcodeMatch = "exact"; });
                return rows;
            }
        }

        if (currentConfig.barcode.prefixEnabled !== false && value.length >= currentConfig.barcode.prefixMinLength) {
            rows = await barcodeRequest(value, "starts_with");
            rows.forEach(function (row) {
                row.__pmk113BarcodeMatch = String(row.external_id || "") === value ? "exact" : "prefix";
            });
            return rows;
        }
        return [];
    }

    function mergeSearchResults(biblios, barcodeItems) {
        const map = new Map();

        (biblios || []).forEach(function (item) {
            if (!item || item.biblio_id == null) return;
            map.set(String(item.biblio_id), item);
        });

        (barcodeItems || []).forEach(function (row) {
            if (!row || row.biblio_id == null) return;
            const key = String(row.biblio_id);
            let item = map.get(key);
            if (!item) {
                item = biblioFromEmbeddedItem(row);
                item.suggestionSources = [];
                map.set(key, item);
            }
            if (!Array.isArray(item.suggestionSources)) item.suggestionSources = [];
            if (!item.suggestionSources.includes('barcode')) item.suggestionSources.push('barcode');
            if (!Array.isArray(item.matchedBarcodes)) item.matchedBarcodes = [];
            const bc = String(row.external_id || "");
            if (bc && item.matchedBarcodes.indexOf(bc) === -1) item.matchedBarcodes.push(bc);
            const match = row.__pmk113BarcodeMatch || "";
            if (match === "exact") item.barcodeMatch = "exact";
            else if (!item.barcodeMatch && match) item.barcodeMatch = match;
            if (!item.barcodeMatchedItem || match === "exact") item.barcodeMatchedItem = row;
        });

        return Array.from(map.values());
    }

    function isItemAvailable(item) {
        return item &&
            Number(item.not_for_loan_status) === 0 &&
            !item.checked_out_date &&
            Number(item.lost_status) === 0 &&
            Number(item.withdrawn) === 0;
    }

    function getItemCallnumber(item) {
        return item && (item.itemcallnumber || item.callnumber || item.call_num || item.cn_sort || item.cote || "") || "";
    }

    function summarizeAvailability(items) {
        items = Array.isArray(items) ? items : [];
        const branch = currentBranch();
        const availableHere = items.some(function (it) {
            return isItemAvailable(it) && String(it.holding_library_id || "") === branch;
        });
        const availableElsewhere = items.some(function (it) {
            return isItemAvailable(it) && String(it.holding_library_id || "") !== branch;
        });

        let callnumber = "";
        const priorities = [
            function (it) { return isItemAvailable(it) && String(it.holding_library_id || "") === branch; },
            function (it) { return isItemAvailable(it); },
            function () { return true; }
        ];
        for (let p = 0; p < priorities.length && !callnumber; p += 1) {
            for (let i = 0; i < items.length; i += 1) {
                if (!priorities[p](items[i])) continue;
                const c = getItemCallnumber(items[i]);
                if (c) { callnumber = c; break; }
            }
        }

        return {
            availableHere:availableHere,
            availableElsewhere:availableElsewhere,
            available:availableHere || availableElsewhere,
            callnumber:callnumber,
            itemsCount:items.length
        };
    }

    function getMenu() {
        try {
            return $input.autocomplete("widget").addClass("kx-catalog-autocomplete pmk113-menu");
        } catch (_) {
            return $();
        }
    }

    function findRow(biblioId) {
        return getMenu().find('li[data-kx-biblio-id="' + String(biblioId) + '"]');
    }

    function availabilityLabel(summary) {
        if (!summary) return tr("Indisponible", "Unavailable");
        if (summary.available) {
            if (currentConfig.availability.showHereElsewhere === false) return tr("Disponible", "Available");
            if (summary.availableHere) return tr("Disponible ici", "Available here");
            if (summary.availableElsewhere) return tr("Disponible ailleurs", "Available elsewhere");
        }
        return tr("Indisponible", "Unavailable");
    }

    function applyAvailabilityToRow(item, summary) {
        if (!item || item.biblio_id == null) return;
        const $row = findRow(item.biblio_id);
        if (!$row.length) return;

        const $dot = $row.find(".ac-avail-dot");
        const $label = $row.find(".ac-avail-label");
        const $call = $row.find(".ac-callnumber");

        $dot.removeClass("loading available unavailable here elsewhere");
        $label.removeClass("loading available unavailable deferred here elsewhere");

        if (summary && summary.availableHere) {
            $dot.addClass("available here");
            $label.addClass("available here").text(availabilityLabel(summary));
        } else if (summary && summary.availableElsewhere) {
            $dot.addClass("available elsewhere");
            $label.addClass("available elsewhere").text(availabilityLabel(summary));
        } else {
            $dot.addClass("unavailable");
            $label.addClass("unavailable").text(availabilityLabel(summary));
        }

        if (currentConfig.availability.showCallnumber !== false && summary && summary.callnumber) {
            $call.text(tr("Cote : ", "Call number: ") + summary.callnumber).show();
        } else {
            $call.hide();
        }

        $row.attr("data-kx-availability-loaded", "1");
        updateRowEnrichedState($row);
    }

    function updateRowEnrichedState($row) {
        if (!$row || !$row.length) return;
        const availabilityDone = currentConfig.availability.enabled === false || $row.attr("data-kx-availability-loaded") === "1";
        const coverDone = currentConfig.covers.enabled === false || $row.attr("data-kx-cover-loaded") === "1";
        if (availabilityDone && coverDone) $row.attr("data-kx-enriched", "1");
    }

    function resetEnrichment() {
        availabilityQueue = [];
        availabilityRunning = 0;
        availabilityQueuedKeys.clear();
        coverQueue = [];
        coverRunning = 0;
        coverQueuedKeys.clear();
    }

    function availabilityQueueKey(item, generation) {
        return generation + ":" + String(item.biblio_id);
    }

    function enqueueAvailability(item, generation, priority) {
        if (currentConfig.availability.enabled === false || !item || item.biblio_id == null || generation !== searchGeneration) return;

        const cached = cacheGet(availabilityCache, String(item.biblio_id), currentConfig.availability.cacheTtlMs);
        if (cached) {
            applyAvailabilityToRow(item, cached);
            if (priority || currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, !!priority);
            return;
        }

        const $row = findRow(item.biblio_id);
        if (!$row.length || $row.attr("data-kx-availability-loaded") === "1") {
            if (priority || currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, !!priority);
            return;
        }

        const key = availabilityQueueKey(item, generation);
        if (availabilityQueuedKeys.has(key)) return;
        availabilityQueuedKeys.add(key);

        const job = { item:item, generation:generation, key:key, priority:!!priority };
        if (priority) availabilityQueue.unshift(job);
        else availabilityQueue.push(job);
        pumpAvailabilityQueue();
    }

    function pumpAvailabilityQueue() {
        const max = currentConfig.availability.concurrency;
        while (availabilityRunning < max && availabilityQueue.length) {
            const job = availabilityQueue.shift();
            if (!job || job.generation !== searchGeneration) continue;
            availabilityRunning += 1;
            loadAvailabilitySingle(job.item, job.generation, job.priority)
                .catch(function () {})
                .finally(function () {
                    availabilityQueuedKeys.delete(job.key);
                    availabilityRunning = Math.max(0, availabilityRunning - 1);
                    pumpAvailabilityQueue();
                });
        }
    }

    function loadAvailabilitySingle(item, generation, priority) {
        const cached = cacheGet(availabilityCache, String(item.biblio_id), currentConfig.availability.cacheTtlMs);
        if (cached) {
            if (generation === searchGeneration) applyAvailabilityToRow(item, cached);
            if (priority || currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, !!priority);
            return Promise.resolve(cached);
        }

        return jqRequest({
            url: "/api/v1/biblios/" + encodeURIComponent(item.biblio_id) + "/items",
            method: "GET",
            dataType: "json",
            headers: { "Accept":"application/json" },
            data: { _per_page:currentConfig.availability.bulkMaxItems }
        }).then(function (result) {
            const summary = summarizeAvailability(Array.isArray(result.data) ? result.data : []);
            cacheSet(availabilityCache, String(item.biblio_id), summary);
            if (generation === searchGeneration) applyAvailabilityToRow(item, summary);
            if (priority || currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, !!priority);
            return summary;
        }).catch(function (error) {
            if (error && error.aborted) return null;
            const summary = summarizeAvailability([]);
            cacheSet(availabilityCache, String(item.biblio_id), summary);
            if (generation === searchGeneration) applyAvailabilityToRow(item, summary);
            if (priority || currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, !!priority);
            return summary;
        });
    }

    async function bulkEnrichAvailability(items, generation) {
        if (currentConfig.availability.enabled === false || generation !== searchGeneration) return false;
        if (currentConfig.availability.strategy !== "bulk-then-queue") return false;

        const missing = (items || []).filter(function (item) {
            if (!item || item.biblio_id == null) return false;
            const cached = cacheGet(availabilityCache, String(item.biblio_id), currentConfig.availability.cacheTtlMs);
            if (cached) {
                applyAvailabilityToRow(item, cached);
                if (currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, false);
                return false;
            }
            return true;
        });
        if (!missing.length) return true;

        const ors = missing.map(function (item) {
            return { "me.biblio_id":Number(item.biblio_id) };
        });
        try {
            const result = await jqRequest({
                url: "/api/v1/items",
                method: "GET",
                dataType: "json",
                headers: { "Accept":"application/json" },
                data: {
                    q: JSON.stringify({ "-or":ors }),
                    _per_page:currentConfig.availability.bulkMaxItems
                }
            });
            if (generation !== searchGeneration) return true;
            const rows = Array.isArray(result.data) ? result.data : [];
            const grouped = new Map();
            rows.forEach(function (row) {
                const key = String(row.biblio_id);
                if (!grouped.has(key)) grouped.set(key, []);
                grouped.get(key).push(row);
            });
            missing.forEach(function (item) {
                const summary = summarizeAvailability(grouped.get(String(item.biblio_id)) || []);
                cacheSet(availabilityCache, String(item.biblio_id), summary);
                applyAvailabilityToRow(item, summary);
                if (currentConfig.covers.autoLoad !== false) enqueueCover(item, generation, false);
            });
            return true;
        } catch (error) {
            if (error && error.aborted) return true;
            return false;
        }
    }

    function renderCoverImage($zone, url) {
        $zone.empty();
        const $img = $("<img>", { src:url, alt:tr("Couverture", "Cover") });
        $img.on("error", function () {
            $zone.text(tr("Pas de couverture", "No cover"));
        });
        $zone.append($img);
    }

    function useFallbackCover($zone, item) {
        if (currentConfig.covers.useFallbackUrl !== false && item.fallback_url) renderCoverImage($zone, item.fallback_url);
        else $zone.text(tr("Pas de couverture", "No cover"));
    }

    function coverQueueKey(item, generation) {
        return generation + ":" + String(item.biblio_id);
    }

    function enqueueCover(item, generation, priority) {
        if (currentConfig.covers.enabled === false || !item || item.biblio_id == null || generation !== searchGeneration) return;
        const $row = findRow(item.biblio_id);
        if (!$row.length || $row.attr("data-kx-cover-loaded") === "1") return;

        const cached = cacheGet(coverCache, String(item.biblio_id), currentConfig.covers.cacheTtlMs);
        if (cached) {
            const $zone = $row.find(".ac-cover-zone");
            if (cached.url) renderCoverImage($zone, cached.url);
            else useFallbackCover($zone, item);
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return;
        }

        const key = coverQueueKey(item, generation);
        if (coverQueuedKeys.has(key)) return;
        coverQueuedKeys.add(key);
        const job = { item:item, generation:generation, key:key };
        if (priority) coverQueue.unshift(job);
        else coverQueue.push(job);
        pumpCoverQueue();
    }

    function pumpCoverQueue() {
        const max = currentConfig.covers.concurrency;
        while (coverRunning < max && coverQueue.length) {
            const job = coverQueue.shift();
            if (!job || job.generation !== searchGeneration) continue;
            coverRunning += 1;
            loadCover(job.item, job.generation)
                .catch(function () {})
                .finally(function () {
                    coverQueuedKeys.delete(job.key);
                    coverRunning = Math.max(0, coverRunning - 1);
                    pumpCoverQueue();
                });
        }
    }

    function loadCover(item, generation) {
        const $row = findRow(item.biblio_id);
        if (!$row.length) return Promise.resolve(null);
        const $zone = $row.find(".ac-cover-zone");

        const cached = cacheGet(coverCache, String(item.biblio_id), currentConfig.covers.cacheTtlMs);
        if (cached) {
            if (cached.url) renderCoverImage($zone, cached.url);
            else useFallbackCover($zone, item);
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return Promise.resolve(cached);
        }

        if (currentConfig.covers.provider !== "electre") {
            useFallbackCover($zone, item);
            cacheSet(coverCache, String(item.biblio_id), { url:"" });
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return Promise.resolve(null);
        }

        const rawIsbn = String(item.isbn || "").split(/[\s,;]+/)[0] || "";
        const isbn10 = isbn13to10(rawIsbn) || digitsOnly(rawIsbn);
        if (!isbn10) {
            useFallbackCover($zone, item);
            cacheSet(coverCache, String(item.biblio_id), { url:"" });
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return Promise.resolve(null);
        }

        return jqRequest({
            url: String(currentConfig.covers.endpoint || "/api/v1/contrib/electre/image"),
            method: "GET",
            dataType: "text",
            data: { isbn10:isbn10, side:"staff", result_page:true }
        }).then(function (result) {
            if (generation !== searchGeneration) return null;
            let coverUrl = result.data;
            if (typeof coverUrl === "string") coverUrl = coverUrl.trim().replace(/^"|"$/g, "");
            if (coverUrl) renderCoverImage($zone, coverUrl);
            else useFallbackCover($zone, item);
            cacheSet(coverCache, String(item.biblio_id), { url:coverUrl || "" });
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return coverUrl;
        }).catch(function (error) {
            if (error && error.aborted) return null;
            useFallbackCover($zone, item);
            cacheSet(coverCache, String(item.biblio_id), { url:"" });
            $row.attr("data-kx-cover-loaded", "1");
            updateRowEnrichedState($row);
            return null;
        });
    }

    function injectSearchActions($menu) {
        $menu.find(".ac-menu-actions").remove();
        const queryValue = String($input.val() || "");
        const idxValue = getIndexValue();
        const $actions = $("<div>", { class:"ac-menu-actions" });

        if (currentConfig.search.warningEnabled !== false) {
            $("<div>", { class:"ac-info-banner" })
                .text(tr(currentConfig.search.warningFr, currentConfig.search.warningEn))
                .appendTo($actions);
            $("<ul>", { class:"ac-zones-list" })
                .append($("<li>").text(tr(currentConfig.search.zonesFr, currentConfig.search.zonesEn)))
                .appendTo($actions);
        }

        if (currentConfig.search.classicSearchEnabled !== false) {
            const $form = $("<form>", {
                action:"/cgi-bin/koha/catalogue/search.pl",
                method:"get",
                class:"ac-search-form"
            });
            if (queryValue) $("<input>", { type:"hidden", name:"q", value:queryValue }).appendTo($form);
            $("<input>", { type:"hidden", name:"idx", value:idxValue }).appendTo($form);
            $("<button>", { type:"submit", class:"btn btn-default btn-sm ac-search-cta" })
                .text(tr(currentConfig.search.classicButtonFr, currentConfig.search.classicButtonEn))
                .appendTo($form);
            $form.appendTo($actions);
        }

        if ($actions.children().length) $menu.prepend($actions);
    }

    function addStyles() {
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            (document.head || document.documentElement).appendChild(style);
        }
        const d = currentConfig.display;
        const c = currentConfig.covers;
        style.textContent = `
            .pmk113-menu.kx-catalog-autocomplete{
                max-height:${d.maxHeightPx}px;
                overflow-y:auto;
                overflow-x:hidden;
                z-index:10000;
                padding:0;
                background:var(--bs-body-bg,#fff);
                color:var(--bs-body-color,#212529);
                border:1px solid #d4d9dd;
                border-radius:4px;
                box-shadow:0 4px 14px rgba(0,0,0,.14);
            }
            .pmk113-menu .ui-menu-item{margin:0;padding:0;}
            .pmk113-menu .autocomplete-item{
                display:flex;align-items:flex-start;gap:10px;padding:7px 10px;
                border-bottom:1px solid #e8ebed;color:inherit;text-decoration:none;
                background:#fff;
            }
            .pmk113-menu .ui-state-active .autocomplete-item,
            .pmk113-menu .autocomplete-item:hover{background:#f0f5f8;color:inherit;}
            .pmk113-menu .ac-cover-zone{
                width:${c.thumbWidthPx}px;height:${c.thumbHeightPx}px;flex:0 0 ${c.thumbWidthPx}px;
                background:#f1f3f4;border:1px solid #d7dcdf;border-radius:3px;
                display:flex;align-items:center;justify-content:center;
                font-size:.68em;color:#6c757d;text-align:center;overflow:hidden;
            }
            .pmk113-menu .ac-cover-zone img{width:100%;height:100%;object-fit:cover;cursor:${c.previewEnabled !== false ? "zoom-in" : "default"};}
            .pmk113-menu .ac-text{display:flex;flex-direction:column;min-width:0;flex:1;}
            .pmk113-menu .ac-title-row{display:flex;align-items:center;gap:6px;min-width:0;}
            .pmk113-menu .ac-title{font-weight:700;color:#2b3a42;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
            .pmk113-menu .ac-author{font-size:.9em;color:#495057;}
            .pmk113-menu .ac-meta,.pmk113-menu .ac-callnumber,.pmk113-menu .ac-barcode,.pmk113-menu .ac-source{font-size:.78em;color:#6c757d;margin-top:2px;}
            .pmk113-menu .ac-barcode{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:#475569;}
            .pmk113-menu .ac-menu-actions{position:sticky;top:0;z-index:2;background:#fff;padding:7px 0 1px;border-bottom:1px solid #e6e9eb;}
            .pmk113-menu .ac-info-banner{margin:0 10px 7px;padding:6px 8px;border-left:3px solid #e0a800;background:#fff8df;color:#6d5817;font-size:.8em;line-height:1.35;border-radius:3px;}
            .pmk113-menu .ac-zones-list{margin:0 10px 7px;padding-left:18px;font-size:.78em;color:#6c757d;}
            .pmk113-menu .ac-search-form{margin:0 10px 8px;}
            .pmk113-menu .ac-search-cta{display:block;width:100%;}
            .pmk113-menu .ac-empty-state{display:none!important;}
            .pmk113-menu .ac-avail-dot{display:inline-block;width:9px;height:9px;border-radius:50%;flex:0 0 9px;background:#adb5bd;}
            .pmk113-menu .ac-avail-dot.available.here{background:#198754;}
            .pmk113-menu .ac-avail-dot.available.elsewhere{background:#0d6efd;}
            .pmk113-menu .ac-avail-dot.unavailable{background:#dc3545;}
            .pmk113-menu .ac-avail-label{font-size:.78em;margin-top:2px;}
            .pmk113-menu .ac-avail-label.available.here{color:#146c43;}
            .pmk113-menu .ac-avail-label.available.elsewhere{color:#0a58ca;}
            .pmk113-menu .ac-avail-label.unavailable{color:#b02a37;}
            .pmk113-menu .ac-avail-label.deferred,.pmk113-menu .ac-avail-label.loading{color:#6c757d;}
            #${PREVIEW_ID}{position:fixed;display:none;z-index:20000;border:3px solid #fff;box-shadow:0 4px 20px rgba(0,0,0,.35);border-radius:4px;pointer-events:none;max-width:${c.previewWidthPx}px;max-height:${c.previewHeightPx}px;background:#fff;}
            #${PREVIEW_ID} img{display:block;max-width:${c.previewWidthPx}px;max-height:${c.previewHeightPx}px;border-radius:2px;}
            @media(max-width:${d.responsiveBreakpointPx}px){
                .pmk113-menu.kx-catalog-autocomplete{position:fixed!important;left:8px!important;right:8px!important;width:auto!important;max-height:min(${d.maxHeightPx}px,65vh)!important;}
                .pmk113-menu .autocomplete-item{padding:8px;}
                .pmk113-menu .ac-cover-zone{width:${Math.max(32, Math.min(c.thumbWidthPx, 44))}px;height:${Math.max(44, Math.min(c.thumbHeightPx, 62))}px;flex-basis:${Math.max(32, Math.min(c.thumbWidthPx, 44))}px;}
                #${PREVIEW_ID}{display:none!important;}
            }
        `;
    }

    function ensurePreview() {
        if (currentConfig.covers.previewEnabled === false) {
            $("#" + PREVIEW_ID).remove();
            return;
        }
        let $preview = $("#" + PREVIEW_ID);
        if (!$preview.length) {
            $preview = $("<div>", { id:PREVIEW_ID }).append($("<img>", { alt:"" })).appendTo("body");
        }
        if (previewBound) return;
        previewBound = true;

        $(document)
            .off(".pmk113CoverPreview")
            .on("mouseenter.pmk113CoverPreview", ".pmk113-menu .ac-cover-zone img", function () {
                if (currentConfig.covers.previewEnabled === false) return;
                const src = $(this).attr("src");
                if (!src) return;
                const $p = $("#" + PREVIEW_ID);
                $p.find("img").attr("src", src);
                $p.show();
                positionPreview($(this), $p);
            })
            .on("mouseleave.pmk113CoverPreview", ".pmk113-menu .ac-cover-zone img", function () {
                $("#" + PREVIEW_ID).hide();
            });
    }

    function positionPreview($thumb, $preview) {
        if (!$thumb.length || !$preview.length) return;
        const rect = $thumb[0].getBoundingClientRect();
        const width = currentConfig.covers.previewWidthPx;
        const height = currentConfig.covers.previewHeightPx;
        const offset = 10;
        let left = rect.right + offset;
        let top = rect.top;
        if (left + width > window.innerWidth - 10) left = rect.left - width - offset;
        if (top + height > window.innerHeight - 10) top = window.innerHeight - height - 10;
        top = Math.max(10, top);
        left = Math.max(10, left);
        $preview.css({ left:left + "px", top:top + "px" });
    }

    function setupLazyHandler() {
        if (lazyBound) return;
        lazyBound = true;
        $(document)
            .off(".pmk113LazyEnrichment")
            .on("mouseenter.pmk113LazyEnrichment focusin.pmk113LazyEnrichment", ".pmk113-menu li[data-kx-biblio-id]", function () {
                const $row = $(this);
                const id = String($row.attr("data-kx-biblio-id") || "");
                if (!id) return;
                const item = currentItemMap.get(id);
                if (!item) return;
                if ($row.attr("data-kx-availability-loaded") !== "1") enqueueAvailability(item, searchGeneration, true);
                if (currentConfig.covers.enabled !== false && $row.attr("data-kx-cover-loaded") !== "1") enqueueCover(item, searchGeneration, true);
            });
    }

    async function runSearch(rawQuery, idxValue, generation) {
        const terms = rawQuery.split(/\s+/).filter(Boolean);
        const recognition = recognizeBarcode(rawQuery, idxValue);
        const barcodeOnly = forcedBarcodeIndex(idxValue);

        const biblioPromise = barcodeOnly ? Promise.resolve([]) : searchBiblios(rawQuery, terms, idxValue);
        const barcodePromise = recognition.matched ? searchBarcodes(rawQuery, idxValue, recognition).catch(function () { return []; }) : Promise.resolve([]);

        const results = await Promise.all([biblioPromise.catch(function () { return []; }), barcodePromise]);
        if (generation !== searchGeneration) return [];

        const merged = mergeSearchResults(results[0], results[1]);
        const ranked = sortResults(merged, terms, rawQuery).slice(0, currentConfig.search.resultsCount);
        ranked.forEach(function (item, index) {
            item.rank = index;
            item.searchGeneration = generation;
            currentItemMap.set(String(item.biblio_id), item);
        });
        return ranked;
    }

    function configureAutocomplete() {
        if (!$input.length || typeof $input.autocomplete !== "function") return false;

        const existing = $input.autocomplete("instance");
        if (existing) {
            if ($input.data(OWNED_DATA_KEY)) {
                try { $input.autocomplete("destroy"); } catch (_) {}
            } else if (currentConfig.search.replaceExistingAutocomplete !== false) {
                try { $input.autocomplete("destroy"); } catch (_) {}
            } else {
                return false;
            }
        }

        $input.data(OWNED_DATA_KEY, true);
        $input.autocomplete({
            minLength: currentConfig.search.minLength,
            delay: currentConfig.search.delayMs,

            create: function () {
                getMenu();
            },

            open: function () {
                const $menu = getMenu();
                if (currentConfig.display.menuWidthMode === "fixed") {
                    $menu.width(currentConfig.display.fixedWidthPx);
                } else if (currentConfig.display.menuWidthMode === "viewport") {
                    $menu.css({ width:"min(760px, calc(100vw - 16px))" });
                } else {
                    $menu.width($input.outerWidth());
                }
            },

            close: function () {
                $("#" + PREVIEW_ID).hide();
            },

            focus: function (event, ui) {
                // Arrow keys focus a jQuery UI menu item without moving DOM focus
                // from the input. Explicitly request the same enrichment as hover.
                event.preventDefault();
                if (ui.item && ui.item.biblio_id != null) {
                    enqueueAvailability(ui.item, searchGeneration, true);
                    enqueueCover(ui.item, searchGeneration, true);
                }
                return false;
            },

            select: function (event, ui) {
                event.preventDefault();
                if (ui.item && ui.item.biblio_id) {
                    window.location.href = "/cgi-bin/koha/catalogue/detail.pl?biblionumber=" + encodeURIComponent(ui.item.biblio_id);
                }
                return false;
            },

            source: function (request, response) {
                const rawQuery = String(request.term || "").trim();
                const idxValue = getIndexValue();
                const generation = ++searchGeneration;
                const requestInput = $input;
                const isCurrent = function () {
                    return generation === searchGeneration && currentConfig.enabled &&
                        requestInput[0] === $input[0] && String(requestInput.val() || '').trim() === rawQuery && getIndexValue() === idxValue;
                };
                currentItemMap.clear();
                resetEnrichment();
                abortSearchRequests();

                runSearch(rawQuery, idxValue, generation)
                    .then(function (rankedItems) {
                        // Always settle the widget callback, including obsolete
                        // requests, so jQuery UI can decrement its loading counter.
                        if (!isCurrent()) { response([]); return; }
                        const responseItems = rankedItems.length
                            ? rankedItems
                            : [{ label:"", value:"", isEmptyState:true, searchGeneration:generation }];
                        response(responseItems);

                        window.setTimeout(async function () {
                            if (!isCurrent()) return;
                            const $menu = getMenu();
                            injectSearchActions($menu);

                            const autoAvailability = rankedItems.slice(0, currentConfig.availability.autoEnrichCount);
                            let bulkDone = false;
                            if (currentConfig.availability.enabled !== false && autoAvailability.length) {
                                bulkDone = await bulkEnrichAvailability(autoAvailability, generation);
                            }
                            if (!bulkDone && generation === searchGeneration) {
                                autoAvailability.forEach(function (item) { enqueueAvailability(item, generation, false); });
                            }

                            if (currentConfig.covers.enabled !== false && currentConfig.covers.autoLoad !== false) {
                                rankedItems.slice(0, currentConfig.covers.autoEnrichCount).forEach(function (item) {
                                    if (currentConfig.availability.enabled === false) enqueueCover(item, generation, false);
                                });
                            }
                        }, 0);
                    })
                    .catch(function (error) {
                        if ((error && error.aborted) || !isCurrent()) { response([]); return; }
                        response([{ label:"", value:"", isEmptyState:true, searchGeneration:generation }]);
                    });
            }
        });

        const instance = $input.autocomplete("instance");
        if (!instance) return false;

        instance._renderItem = function (ul, item) {
            if (item.isEmptyState) return $("<li>").addClass("ac-empty-state").appendTo(ul);

            const detailUrl = "/cgi-bin/koha/catalogue/detail.pl?biblionumber=" + encodeURIComponent(item.biblio_id);
            const $li = $("<li>").attr({
                "data-kx-biblio-id":item.biblio_id,
                "data-kx-enriched":"0",
                "data-kx-availability-loaded": currentConfig.availability.enabled === false ? "1" : "0",
                "data-kx-cover-loaded": currentConfig.covers.enabled === false ? "1" : "0"
            });

            const $link = $("<a>", { href:detailUrl, class:"autocomplete-item" }).appendTo($li);
            const $cover = $("<div>", { class:"ac-cover-zone" }).appendTo($link);
            const $text = $("<div>", { class:"ac-text" }).appendTo($link);
            const $titleRow = $("<div>", { class:"ac-title-row" }).appendTo($text);

            if (currentConfig.availability.enabled !== false) $("<span>", { class:"ac-avail-dot loading", "aria-hidden":"true" }).appendTo($titleRow);
            $("<span>", { class:"ac-title" }).text(item.label || tr("Notice sans titre", "Untitled record")).appendTo($titleRow);

            if (currentConfig.display.showAuthor !== false && item.author) $("<span>", { class:"ac-author" }).text(item.author).appendTo($text);

            const sources = [];
            if ((item.suggestionSources || []).includes('catalogue')) sources.push(tr('Catalogue Koha', 'Koha catalogue'));
            if (item.barcodeMatch) sources.push(item.barcodeMatch === 'exact' ? tr('Code-barres exact', 'Exact barcode') : tr('Début du code-barres', 'Barcode prefix'));
            if (sources.length) $('<span>', {class:'ac-source'}).text(sources.join(' · ')).appendTo($text);

            const meta = [];
            if (currentConfig.display.showPublisher !== false && item.publisher) meta.push(item.publisher);
            if (currentConfig.display.showYear !== false && item.year) meta.push(item.year);
            if (currentConfig.display.showItemType !== false && item.item_type) meta.push(item.item_type);
            if (meta.length) $("<span>", { class:"ac-meta" }).text(meta.join(" · ")).appendTo($text);

            if (currentConfig.barcode.displayBarcode !== false && item.matchedBarcodes && item.matchedBarcodes.length) {
                const text = tr("CB : ", "Barcode: ") + item.matchedBarcodes[0] + (item.matchedBarcodes.length > 1 ? " +" + (item.matchedBarcodes.length - 1) : "");
                $("<span>", { class:"ac-barcode" }).text(text).appendTo($text);
            }

            $("<span>", { class:"ac-callnumber" }).hide().appendTo($text);

            if (currentConfig.availability.enabled !== false) {
                if (item.rank < currentConfig.availability.autoEnrichCount) {
                    $("<span>", { class:"ac-avail-label loading" }).text(tr("Vérification…", "Checking…")).appendTo($text);
                } else {
                    $("<span>", { class:"ac-avail-label deferred" })
                        .text(tr("Survolez pour vérifier disponibilité et cote", "Hover to check availability and call number"))
                        .appendTo($text);
                }
            }

            if (currentConfig.covers.enabled !== false) {
                if (currentConfig.covers.autoLoad !== false && item.rank < currentConfig.covers.autoEnrichCount) $cover.text(tr("Chargement…", "Loading…"));
                else $cover.text(tr("Survol", "Hover"));
            } else {
                $cover.hide();
            }

            return $li.appendTo(ul);
        };

        return true;
    }

    function canConfigure() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === "function") {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }
        const el = document.querySelector("#logged-in-info-full .loggedinusername[data-loggedinusername], .loggedinusername[data-loggedinusername]");
        return !!(el && (el.dataset.isSuperlibrarian === "is_superlibrarian" || el.classList.contains("is_superlibrarian")));
    }

    function mountContextAccess() {
        if (!canConfigure() || !window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function" || !$input.length) return;
        const anchor = $input.closest(".form-content, #cat-search-block, form").first()[0] || $input.parent()[0];
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId:MODULE_ID,
                anchor:anchor,
                position:"after",
                contextKey:CONTEXT_KEY,
                context:{ sectionId:"search" }
            });
        } catch (_) {}
    }

    function newIndexMapping() {
        return { enabled:true, indexCode:"", fields:"title" };
    }

    function newBarcodeProfile() {
        return {
            id:"barcode-" + Date.now().toString(36),
            enabled:true,
            labelFr:"Nouveau format CB",
            labelEn:"New barcode format",
            mode:"digits",
            prefix:"",
            minLength:8,
            maxLength:14,
            example:"",
            regex:""
        };
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        if (!cfg.scope.inputSelector) return { ok:false, message:tr("Le sélecteur de la barre de recherche est obligatoire.", "Search input selector is required.") };
        try { document.createDocumentFragment().querySelector(cfg.scope.inputSelector); } catch (_) {
            return { ok:false, message:tr("Le sélecteur de la barre de recherche n’est pas valide.", "Search input selector is invalid.") };
        }
        const ids = new Set();
        for (const p of cfg.barcode.fallbackProfiles) {
            if (!p || p.enabled === false) continue;
            const id = String(p.id || "").trim();
            if (!id || ids.has(id)) return { ok:false, message:tr("Chaque format de code-barres actif doit avoir un identifiant unique.", "Each enabled barcode format must have a unique id.") };
            ids.add(id);
            const source = barcodeProfileRegexSource(p);
            if (!safeRegex(source)) return { ok:false, message:tr("Format de code-barres invalide : ", "Invalid barcode format: ") + String(p.labelFr || p.id || "") };
            if (p.mode !== "expert" && Number(p.maxLength) < Number(p.minLength)) {
                return { ok:false, message:tr("La longueur maximale d’un format CB doit être supérieure ou égale à la longueur minimale.", "A barcode format maximum length must be greater than or equal to its minimum length.") };
            }
        }
        return { ok:true };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function" || configRegistered) return false;
        configRegistered = true;
        window.PMKConfig.registerModule({
            id:MODULE_ID,
            schemaVersion:4,
            name:{ fr:"Autocomplétion Recherche catalogue", en:"Catalogue search autocomplete" },
            description:{
                fr:"Suggestions rapides issues du catalogue Koha avec classement local, disponibilité, cote, couverture et recherche par code-barres exemplaire. La recherche classique Koha reste la référence exhaustive.",
                en:"Fast suggestions from the Koha catalogue with local ranking, availability, call number, cover and item-barcode lookup. Full Koha search remains authoritative."
            },
            category:{ fr:"Catalogue / recherche", en:"Catalogue / search" },
            supportedPages:["staff.searchbar","catalogue.search","mainpage"],
            prerequisites:[],
            dependencies:[],
            defaults:deepClone(DEFAULT_CONFIG),
            validate:validateConfig,
            schema:[
                {
                    type:"section", id:"activation", label:{fr:"Activation et portée",en:"Activation and scope"},
                    fields:[
                        {key:"enabled",type:"boolean",label:{fr:"Activer l’autocomplétion catalogue",en:"Enable catalogue autocomplete"}},
                        {key:"scope.pageMode",type:"select",label:{fr:"Pages actives",en:"Active pages"},options:[
                            {value:"where-input-exists",label:{fr:"Toutes les pages où la barre Koha existe — comportement historique",en:"Every page where the Koha search bar exists — historical behavior"}},
                            {value:"configured-pages",label:{fr:"Uniquement les pages configurées",en:"Only configured pages"}}
                        ]},
                        {key:"scope.pages",type:"repeater",label:{fr:"Pages configurées",en:"Configured pages"},addLabel:{fr:"Ajouter une page",en:"Add page"},reorder:true,newItem:function(){return {enabled:true,path:window.location.pathname,labelFr:"Nouvelle page",labelEn:"New page"};},itemTitle:function(item,index,lang){return String(lang==="en"?(item&&item.labelEn||item&&item.path):(item&&item.labelFr||item&&item.path)||("Page "+(index+1)));},fields:[
                            {key:"enabled",type:"boolean",label:{fr:"Active",en:"Enabled"}},
                            {key:"labelFr",type:"text",label:{fr:"Nom français",en:"French name"}},
                            {key:"labelEn",type:"text",label:{fr:"Nom anglais",en:"English name"}},
                            {key:"path",type:"text",label:{fr:"Chemin Koha",en:"Koha path"}}
                        ]},
                        {key:"scope.inputSelector",type:"text",advanced:true,label:{fr:"Sélecteur du champ de recherche",en:"Search input selector"}},
                        {key:"scope.indexSelector",type:"text",advanced:true,label:{fr:"Sélecteur de l’index Koha",en:"Koha index selector"}}
                    ]
                },
                {
                    type:"section", id:"search", label:{fr:"Recherche catalogue",en:"Catalogue search"},
                    description:{fr:"Les valeurs historiques restent 3 caractères minimum, 20 propositions et classement local pondéré.",en:"Historical defaults remain 3 minimum characters, 20 suggestions and weighted local ranking."},
                    fields:[
                        {key:"search.minLength",type:"number",min:1,max:20,label:{fr:"Nombre minimum de caractères",en:"Minimum characters"}},
                        {key:"search.delayMs",type:"number",min:0,max:3000,label:{fr:"Délai avant recherche (ms)",en:"Search delay (ms)"}},
                        {key:"search.resultsCount",type:"number",min:1,max:100,label:{fr:"Nombre maximum de propositions",en:"Maximum suggestions"}},
                        {key:"search.keywordFields",type:"text",advanced:true,label:{fr:"Champs utilisés en mode mots-clés",en:"Fields used in keyword mode"},help:{fr:"Liste séparée par des virgules. Défaut historique : title,author,unititle.",en:"Comma-separated list. Historical default: title,author,unititle."}},
                        {key:"search.indexMappings",type:"repeater",advanced:true,label:{fr:"Correspondance index Koha → champs API",en:"Koha index → API fields mapping"},addLabel:{fr:"Ajouter une correspondance",en:"Add mapping"},reorder:true,newItem:newIndexMapping,itemTitle:function(item){return String(item&&item.indexCode||"Index");},fields:[
                            {key:"enabled",type:"boolean",label:{fr:"Active",en:"Enabled"}},
                            {key:"indexCode",type:"text",label:{fr:"Code index Koha",en:"Koha index code"}},
                            {key:"fields",type:"text",label:{fr:"Champs API séparés par virgules",en:"Comma-separated API fields"}}
                        ]},
                        {key:"search.replaceExistingAutocomplete",type:"boolean",advanced:true,label:{fr:"Remplacer un autocomplete déjà présent sur cette barre",en:"Replace an existing autocomplete on this search bar"}},
                        {key:"search.warningEnabled",type:"boolean",label:{fr:"Afficher l’avertissement sur la recherche rapide",en:"Show fast-search warning"}},
                        {key:"search.classicSearchEnabled",type:"boolean",label:{fr:"Afficher le bouton Recherche classique",en:"Show full Koha search button"}},
                        {key:"search.warningFr",type:"text",label:{fr:"Avertissement français",en:"French warning"}},
                        {key:"search.warningEn",type:"text",label:{fr:"Avertissement anglais",en:"English warning"}},
                        {key:"search.zonesFr",type:"text",label:{fr:"Description des zones — français",en:"Searched fields — French"}},
                        {key:"search.zonesEn",type:"text",label:{fr:"Description des zones — anglais",en:"Searched fields — English"}},
                        {key:"search.classicButtonFr",type:"text",label:{fr:"Bouton classique — français",en:"Full search button — French"}},
                        {key:"search.classicButtonEn",type:"text",label:{fr:"Bouton classique — anglais",en:"Full search button — English"}}
                    ]
                },
                {
                    type:"section", id:"barcode", label:{fr:"Recherche par code-barres exemplaire",en:"Item barcode search"},
                    description:{fr:"Le CB est recherché via /api/v1/items puis fusionné avec les résultats notice. Les formats courants se configurent sans regex : préfixe, type de caractères, longueur et exemple de test.",en:"Barcodes are searched through /api/v1/items and merged with record results. Common formats are configured without regex: prefix, character type, length and a test example."},
                    fields:[
                        {key:"barcode.enabled",type:"boolean",label:{fr:"Intégrer les codes-barres aux recherches",en:"Include item barcodes in searches"}},
                        {key:"barcode.use036Recognizer",type:"boolean",label:{fr:"Réutiliser la reconnaissance du module 036 si disponible",en:"Reuse module 036 recognition when available"}},
                        {key:"barcode.accepted036ProfileIds",type:"text",advanced:true,label:{fr:"Profils 036 considérés comme codes-barres",en:"036 profiles treated as barcodes"}},
                        {key:"barcode.forcedIndexCodes",type:"text",label:{fr:"Index Koha qui forcent une recherche CB",en:"Koha indexes that force barcode lookup"},help:{fr:"Ex. bc,barcode. Sur ces index, la branche notice classique n’est pas lancée.",en:"E.g. bc,barcode. On these indexes the regular record branch is skipped."}},
                        {key:"barcode.exactEnabled",type:"boolean",label:{fr:"Chercher d’abord le CB exact",en:"Search exact barcode first"}},
                        {key:"barcode.prefixEnabled",type:"boolean",label:{fr:"Si aucun exact : chercher les CB commençant par la saisie",en:"If no exact match: search barcodes starting with input"}},
                        {key:"barcode.prefixMinLength",type:"number",min:1,max:128,label:{fr:"Longueur minimale pour la recherche par début de CB",en:"Minimum length for barcode prefix search"}},
                        {key:"barcode.maxMatches",type:"number",min:1,max:100,label:{fr:"Nombre maximum d’exemplaires retournés par recherche CB",en:"Maximum items returned by barcode lookup"}},
                        {key:"barcode.displayBarcode",type:"boolean",label:{fr:"Afficher le CB correspondant dans la proposition",en:"Show matching barcode in suggestion"}},
                        {key:"barcode.exactScoreBonus",type:"number",advanced:true,label:{fr:"Bonus de score CB exact",en:"Exact barcode score bonus"}},
                        {key:"barcode.prefixScoreBonus",type:"number",advanced:true,label:{fr:"Bonus de score CB partiel",en:"Prefix barcode score bonus"}},
                        {key:"barcode.fallbackProfiles",type:"repeater",label:{fr:"Formats de codes-barres reconnus",en:"Recognized barcode formats"},addLabel:{fr:"Ajouter un format de code-barres",en:"Add barcode format"},reorder:true,newItem:newBarcodeProfile,itemTitle:function(item,index,lang){return String(lang==="en"?(item&&item.labelEn||item&&item.id):(item&&item.labelFr||item&&item.id)||("CB "+(index+1)));},help:{fr:"Aucune expression régulière n’est nécessaire pour les formats courants. Exemple d’origine préconfiguré : préfixe DR + 9 chiffres.",en:"No regular expression is required for common formats. Original preset example: DR prefix + 9 digits."},fields:[
                            {key:"enabled",type:"boolean",label:{fr:"Format actif",en:"Format enabled"}},
                            {key:"labelFr",type:"text",label:{fr:"Nom du format",en:"Format name (French)"}},
                            {key:"labelEn",type:"text",advanced:true,label:{fr:"Nom anglais",en:"English name"}},
                            {key:"mode",type:"select",refreshOnChange:true,label:{fr:"Structure du code-barres",en:"Barcode structure"},options:[
                                {value:"digits",label:{fr:"Chiffres uniquement",en:"Digits only"}},
                                {value:"alphanumeric",label:{fr:"Lettres + chiffres (et séparateurs usuels)",en:"Letters + digits (and common separators)"}},
                                {value:"prefix-digits",label:{fr:"Préfixe fixe + chiffres",en:"Fixed prefix + digits"}},
                                {value:"prefix-alphanumeric",label:{fr:"Préfixe fixe + lettres/chiffres",en:"Fixed prefix + letters/digits"}},
                                {value:"expert",label:{fr:"Format expert (expression régulière)",en:"Expert format (regular expression)"}}
                            ]},
                            {key:"prefix",type:"text",refreshOnChange:true,label:{fr:"Préfixe fixe",en:"Fixed prefix"},placeholder:{fr:"DR",en:"DR"},when:barcodeProfileUsesPrefix},
                            {key:"minLength",type:"number",min:0,max:128,refreshOnChange:true,label:{fr:"Nombre minimum de caractères après le préfixe",en:"Minimum characters after prefix"},when:barcodeProfileUsesBuilder},
                            {key:"maxLength",type:"number",min:0,max:128,refreshOnChange:true,label:{fr:"Nombre maximum de caractères après le préfixe",en:"Maximum characters after prefix"},when:barcodeProfileUsesBuilder},
                            {key:"example",type:"text",refreshOnChange:true,label:{fr:"Exemple de code-barres à tester",en:"Example barcode to test"},placeholder:{fr:"DR100007790",en:"DR100007790"}},
                            {type:"custom",label:{fr:"Vérification du format",en:"Format check"},render:renderBarcodeProfilePreview},
                            {key:"regex",type:"text",label:{fr:"Expression régulière",en:"Regular expression"},when:barcodeProfileIsExpert,help:{fr:"Réservé aux formats complexes. Les autres modes construisent automatiquement cette règle.",en:"For complex formats only. Other modes build this rule automatically."}},
                            {key:"id",type:"text",advanced:true,label:{fr:"Identifiant technique",en:"Technical identifier"}}
                        ]}
                    ]
                },
                {
                    type:"section", id:"availability", label:{fr:"Disponibilité et cote",en:"Availability and call number"},
                    description:{fr:"Le mode par défaut tente une requête groupée, puis retombe sur 3 requêtes simultanées maximum si nécessaire. Il remplace le séquentiel historique sans revenir aux dizaines d’appels simultanés.",en:"Default mode tries one bulk request, then falls back to at most 3 concurrent requests when needed. It replaces the historical serial queue without returning to dozens of simultaneous calls."},
                    fields:[
                        {key:"availability.enabled",type:"boolean",label:{fr:"Afficher la disponibilité",en:"Show availability"}},
                        {key:"availability.autoEnrichCount",type:"number",min:0,max:100,label:{fr:"Nombre de premières propositions enrichies automatiquement",en:"Number of first suggestions enriched automatically"}},
                        {key:"availability.strategy",type:"select",label:{fr:"Stratégie de chargement",en:"Loading strategy"},options:[
                            {value:"bulk-then-queue",label:{fr:"Groupée puis file parallèle — recommandé",en:"Bulk then bounded queue — recommended"}},
                            {value:"queue",label:{fr:"File parallèle uniquement",en:"Bounded queue only"}}
                        ]},
                        {key:"availability.concurrency",type:"number",min:1,max:8,label:{fr:"Requêtes disponibilité simultanées maximum",en:"Maximum concurrent availability requests"}},
                        {key:"availability.bulkMaxItems",type:"number",min:20,max:2000,advanced:true,label:{fr:"Maximum d’exemplaires dans la requête groupée",en:"Maximum items in bulk request"}},
                        {key:"availability.showHereElsewhere",type:"boolean",label:{fr:"Distinguer Disponible ici / ailleurs",en:"Distinguish Available here / elsewhere"}},
                        {key:"availability.showCallnumber",type:"boolean",label:{fr:"Afficher la cote",en:"Show call number"}},
                        {key:"availability.cacheTtlMs",type:"number",advanced:true,label:{fr:"Durée du cache disponibilité (ms)",en:"Availability cache duration (ms)"}}
                    ]
                },
                {
                    type:"section", id:"covers", label:{fr:"Couvertures",en:"Covers"},
                    fields:[
                        {key:"covers.enabled",type:"boolean",label:{fr:"Afficher les couvertures",en:"Show covers"}},
                        {key:"covers.autoLoad",type:"boolean",label:{fr:"Charger automatiquement les premières couvertures",en:"Automatically load first covers"}},
                        {key:"covers.autoEnrichCount",type:"number",min:0,max:100,label:{fr:"Nombre de couvertures chargées automatiquement",en:"Number of covers loaded automatically"}},
                        {key:"covers.provider",type:"select",label:{fr:"Source principale",en:"Primary source"},options:[
                            {value:"electre",label:{fr:"Electre via endpoint Koha historique",en:"Electre through historical Koha endpoint"}},
                            {value:"fallback",label:{fr:"Uniquement l’URL déjà fournie par la notice",en:"Only URL already supplied by the record"}}
                        ]},
                        {key:"covers.endpoint",type:"text",advanced:true,label:{fr:"Endpoint couverture Electre",en:"Electre cover endpoint"}},
                        {key:"covers.useFallbackUrl",type:"boolean",label:{fr:"Utiliser l’URL de repli de la notice",en:"Use record fallback URL"}},
                        {key:"covers.previewEnabled",type:"boolean",label:{fr:"Agrandir la couverture au survol",en:"Enlarge cover on hover"}},
                        {key:"covers.thumbWidthPx",type:"number",min:20,max:120,label:{fr:"Largeur vignette (px)",en:"Thumbnail width (px)"}},
                        {key:"covers.thumbHeightPx",type:"number",min:20,max:180,label:{fr:"Hauteur vignette (px)",en:"Thumbnail height (px)"}},
                        {key:"covers.previewWidthPx",type:"number",min:80,max:600,advanced:true,label:{fr:"Largeur aperçu (px)",en:"Preview width (px)"}},
                        {key:"covers.previewHeightPx",type:"number",min:100,max:900,advanced:true,label:{fr:"Hauteur aperçu (px)",en:"Preview height (px)"}},
                        {key:"covers.concurrency",type:"number",min:1,max:4,advanced:true,label:{fr:"Couvertures simultanées maximum",en:"Maximum concurrent cover requests"}},
                        {key:"covers.cacheTtlMs",type:"number",advanced:true,label:{fr:"Durée du cache couverture (ms)",en:"Cover cache duration (ms)"}}
                    ]
                },
                {
                    type:"section", id:"display", label:{fr:"Affichage",en:"Display"},
                    fields:[
                        {key:"display.showAuthor",type:"boolean",label:{fr:"Afficher l’auteur",en:"Show author"}},
                        {key:"display.showPublisher",type:"boolean",label:{fr:"Afficher l’éditeur",en:"Show publisher"}},
                        {key:"display.showYear",type:"boolean",label:{fr:"Afficher l’année",en:"Show year"}},
                        {key:"display.showItemType",type:"boolean",label:{fr:"Afficher le type de document",en:"Show item type"}},
                        {key:"display.maxHeightPx",type:"number",min:150,max:1000,label:{fr:"Hauteur maximale du menu (px)",en:"Maximum menu height (px)"}},
                        {key:"display.menuWidthMode",type:"select",label:{fr:"Largeur du menu",en:"Menu width"},options:[
                            {value:"input",label:{fr:"Même largeur que la barre — historique",en:"Same width as search input — historical"}},
                            {value:"fixed",label:{fr:"Largeur fixe",en:"Fixed width"}},
                            {value:"viewport",label:{fr:"Largeur adaptée à l’écran",en:"Viewport-adaptive width"}}
                        ]},
                        {key:"display.fixedWidthPx",type:"number",min:280,max:1200,label:{fr:"Largeur fixe (px)",en:"Fixed width (px)"}},
                        {key:"display.responsiveBreakpointPx",type:"number",min:320,max:1200,advanced:true,label:{fr:"Seuil responsive (px)",en:"Responsive breakpoint (px)"}}
                    ]
                },
                {
                    type:"section", id:"performance",
                    fields:[
                        {key:"performance.searchCacheTtlMs",type:"number",advanced:true,label:{fr:"Cache recherches notices (ms)",en:"Record search cache (ms)"}},
                        {key:"performance.barcodeCacheTtlMs",type:"number",advanced:true,label:{fr:"Cache recherches CB (ms)",en:"Barcode search cache (ms)"}},
                        {key:"performance.maxSearchCacheEntries",type:"number",min:5,max:500,advanced:true,label:{fr:"Nombre maximal d’entrées de cache",en:"Maximum cache entries"}},
                        {key:"performance.abortObsoleteRequests",type:"boolean",advanced:true,label:{fr:"Annuler les requêtes devenues obsolètes",en:"Abort obsolete requests"}}
                    ]
                },
                {
                    type:"section", id:"scoring",
                    fields:[
                        {key:"scoring.titleTerm",type:"number",advanced:true,label:{fr:"Titre contient un terme",en:"Title contains a term"}},
                        {key:"scoring.authorTerm",type:"number",advanced:true,label:{fr:"Auteur contient un terme",en:"Author contains a term"}},
                        {key:"scoring.unititleTerm",type:"number",advanced:true,label:{fr:"Titre uniforme contient un terme",en:"Uniform title contains a term"}},
                        {key:"scoring.publisherTerm",type:"number",advanced:true,label:{fr:"Éditeur contient un terme",en:"Publisher contains a term"}},
                        {key:"scoring.titleExact",type:"number",advanced:true,label:{fr:"Titre exact",en:"Exact title"}},
                        {key:"scoring.titlePrefix",type:"number",advanced:true,label:{fr:"Titre commence par",en:"Title starts with"}},
                        {key:"scoring.authorExact",type:"number",advanced:true,label:{fr:"Auteur exact",en:"Exact author"}},
                        {key:"scoring.authorPrefix",type:"number",advanced:true,label:{fr:"Auteur commence par",en:"Author starts with"}},
                        {key:"scoring.isbnExact",type:"number",advanced:true,label:{fr:"ISBN exact",en:"Exact ISBN"}},
                        {key:"scoring.eanExact",type:"number",advanced:true,label:{fr:"EAN exact",en:"Exact EAN"}}
                    ]
                }
            ],
            focusContext:function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "search";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]');
                if (section) window.setTimeout(function () { section.scrollIntoView({ block:"start", behavior:"smooth" }); }, 0);
            }
        });

        if (typeof window.PMKConfig.subscribe === "function") {
            try {
                unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (cfg) {
                    applyConfig(cfg);
                });
            } catch (_) {}
        }
        return true;
    }

    function loadConfig() {
        registerModule();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULT_CONFIG));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(function (cfg) { return normalizeConfig(cfg); })
            .catch(function () { return deepClone(DEFAULT_CONFIG); });
    }

    function destroyRuntime() {
        searchGeneration += 1;
        abortSearchRequests();
        resetEnrichment();
        currentItemMap.clear();
        $("#" + PREVIEW_ID).hide();

        if ($input && $input.length && $input.data(OWNED_DATA_KEY)) {
            try { $input.autocomplete("destroy"); } catch (_) {}
            $input.removeData(OWNED_DATA_KEY);
        }
        $input = $();
    }

    function applyConfig(config) {
        currentConfig = normalizeConfig(config);
        destroyRuntime();
        addStyles();
        ensurePreview();
        setupLazyHandler();
        if (!currentConfig.enabled || !pathAllowed()) return false;
        $input = getInput();
        if (!$input.length || typeof $input.autocomplete !== "function") return false;
        const ok = configureAutocomplete();
        if (ok) mountContextAccess();
        moduleStarted = ok;
        return ok;
    }

    function activateFromPMKOrDefaults() {
        registerModule();
        loadConfig().then(applyConfig);
    }

    function start() {
        if (registerModule()) {
            loadConfig().then(applyConfig);
            return;
        }

        // Le 113 doit rester utilisable même si le socle PMK arrive après lui.
        applyConfig(DEFAULT_CONFIG);

        const onReady = function () {
            window.removeEventListener("pmk:config-ready", onReady);
            activateFromPMKOrDefaults();
        };
        window.addEventListener("pmk:config-ready", onReady, { once:true });
        window.setTimeout(function () {
            if (!configRegistered && window.PMKConfig) activateFromPMKOrDefaults();
        }, 6000);
    }

    window.PMK113SearchAutocomplete = {
        moduleId:MODULE_ID,
        version:MODULE_VERSION,
        defaults:deepClone(DEFAULT_CONFIG),
        getConfig:function () { return deepClone(currentConfig); },
        refresh:function () { return loadConfig().then(applyConfig); },
        recognizeBarcode:function (value, index) { return recognizeBarcode(value, index || getIndexValue()); },
        scoreResult:function (item, terms, query) { return scoreResult(item || {}, terms || [], query || ""); },
        clearCaches:function () {
            searchCache.clear();
            barcodeCache.clear();
            availabilityCache.clear();
            coverCache.clear();
        },
        destroy:destroyRuntime
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once:true });
    } else {
        start();
    }
})(window, document, window.jQuery);

;window.PMKNonPlugin.loaded.push("113-autocomplete-elestic.js");
} catch (error) { window.PMKNonPlugin.errors.push("113-autocomplete-elestic.js: "+error.message); console.error("[PMK] 113-autocomplete-elestic.js",error); };
