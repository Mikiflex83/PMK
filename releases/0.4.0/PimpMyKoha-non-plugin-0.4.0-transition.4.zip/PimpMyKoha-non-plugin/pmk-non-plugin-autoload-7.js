/* Generated PMK non-plugin autoload chunk; sources stay individually available. */
try {
/*
 Nom du fichier : 114-renew-modif.js
 Module PMK : renewal-enhancements
 Version : 3.2.0-preplugin
 Date : 2026-09-21

 Fusion canonique des scripts historiques :
   - 114-renew-modif.js
   - 089-renewal-column-enhancements.js (absorbé ; à décharger après recette)

 Principes :
   - conserve physiquement les contrôles natifs Koha ; aucune checkbox de renouvellement n'est recréée ;
   - réintègre par défaut la checkbox native Koha dans la carte PMK, en déplaçant le nœud existant sans le cloner ;
   - restaure sa position DOM d'origine si le module est désactivé ou reconfiguré ;
   - ne déclenche AUCUN renouvellement via API ; l'action reste intégralement native Koha ;
   - enrichit facultativement l'affichage via GET /api/v1/checkouts/{checkout_id}/allows_renewal ;
   - fonctionne immédiatement à partir du DOM, même si l'API est absente/interdite ;
   - reprend la présentation historique R / N / « renouvelé » du 089 ;
   - supprime définitivement le faux bouton historique « Renouveler la sélection » du 089 ;
   - limite l'exécution aux pages de circulation/historique configurées ;
   - observer ciblé sur les tableaux / la zone principale, jamais un traitement aveugle de tout le body.
   - v3.2 : le DOM Koha explicite et le quota priment sur la checkbox et sur l’API ; la checkbox n’est affichée que si le renouvellement est réellement permis.
   - v3.2 : renew_<itemnumber> n’est plus utilisé comme checkout_id REST ; sans vrai identifiant de prêt, aucun appel API erroné n’est lancé.
*/
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK114RenewalEnhancementsV3) return;
    window.__PMK114RenewalEnhancementsV3 = true;

    const MODULE_ID = "renewal-enhancements";
    const MODULE_VERSION = "3.2.0-preplugin";
    const STYLE_ID = "pmk114-renewal-styles";
    const CONTEXT_KEY = "pmk114-renewal";

    const DEFAULT_REASON_LABELS = [
        { enabled:true, code:"too_many", fr:"Nombre maximal de renouvellements atteint", en:"Maximum number of renewals reached" },
        { enabled:true, code:"on_reserve", fr:"Une réservation empêche le renouvellement", en:"A hold prevents renewal" },
        { enabled:true, code:"norenew_overdue", fr:"Renouvellement interdit en raison du retard", en:"Renewal blocked because the item is overdue" },
        { enabled:true, code:"too_unseen", fr:"Le document doit être présenté à la bibliothèque", en:"The item must be seen by the library" },
        { enabled:true, code:"too_soon", fr:"Renouvellement encore trop tôt", en:"Too soon to renew" },
        { enabled:true, code:"auto_too_late", fr:"Le document n'est plus renouvelable", en:"The item is no longer renewable" },
        { enabled:true, code:"auto_too_much_owing", fr:"Des frais impayés empêchent le renouvellement automatique", en:"Outstanding charges prevent automatic renewal" },
        { enabled:true, code:"auto_account_expired", fr:"Le compte lecteur est expiré", en:"The patron account is expired" },
        { enabled:true, code:"item_denied_renewal", fr:"Les règles de l'exemplaire interdisent le renouvellement", en:"Item rules deny renewal" },
        { enabled:true, code:"restriction", fr:"Une restriction empêche le renouvellement", en:"A restriction prevents renewal" }
    ];

    const DEFAULT_CONFIG = {
        enabled: true,
        pages: [
            {
                id: "circ.circulation",
                enabled: true,
                path: "/cgi-bin/koha/circ/circulation.pl",
                mode: "active",
                labelFr: "Circulation — prêts actifs",
                labelEn: "Circulation — active checkouts"
            },
            {
                id: "members.moremember",
                enabled: true,
                path: "/cgi-bin/koha/members/moremember.pl",
                mode: "active",
                labelFr: "Fiche lecteur — prêts actifs",
                labelEn: "Patron details — active checkouts"
            },
            {
                id: "members.memberhistory",
                enabled: true,
                path: "/cgi-bin/koha/members/memberhistory.pl",
                mode: "history",
                labelFr: "Historique lecteur",
                labelEn: "Patron history"
            },
            {
                id: "circ.returns",
                enabled: true,
                path: "/cgi-bin/koha/circ/returns.pl",
                mode: "history",
                labelFr: "Retours",
                labelEn: "Check in"
            }
        ],
        active: {
            enabled: true,
            showStatus: true,
            showCounts: true,
            showReason: true,
            showUnseenRenewals: true,
            integrateCheckboxInCard: true,
            showCheckboxLabel: true,
            hideKnownNativeText: true,
            countFormat: "remaining-total",
            statusSource: "api-preferred"
        },
        api: {
            enabled: true,
            endpointTemplate: "/api/v1/checkouts/{id}/allows_renewal",
            concurrency: 3,
            timeoutMs: 4000,
            cacheMs: 60000,
            stopAfterForbidden: true,
            trustCheckboxValueWhenNamedIssue: true,
            trustCheckboxValueWhenNamedRenew: false
        },
        history: {
            enabled: true,
            useLegacyLabelClasses: true,
            renewedPatterns: "^R$;renouvelé;renouvele;renewed",
            notRenewedPatterns: "^N$;non renouvelé;non renouvele;not renewed",
            renewedTooltipFr: "Renouvellement détecté",
            renewedTooltipEn: "Renewal detected",
            notRenewedTooltipFr: "Non renouvelé",
            notRenewedTooltipEn: "Not renewed"
        },
        labels: {
            renewableFr: "Renouvellement possible",
            renewableEn: "Renewal available",
            impossibleFr: "Renouvellement impossible",
            impossibleEn: "Renewal unavailable",
            blockedFr: "Renouvellement impossible",
            blockedEn: "Renewal blocked",
            unknownFr: "État de renouvellement",
            unknownEn: "Renewal status",
            renewFr: "Renouveler",
            renewEn: "Renew",
            renewedUnavailableFr: "Nouveau renouvellement indisponible",
            renewedUnavailableEn: "No further renewal available",
            renewedQuotaFr: "Quota de renouvellements atteint",
            renewedQuotaEn: "Renewal limit reached",
            remainingFr: "{remaining}/{total} renouvellements restants",
            remainingEn: "{remaining}/{total} renewals remaining",
            usedFr: "{current}/{total} renouvellements utilisés",
            usedEn: "{current}/{total} renewals used",
            unseenFr: "{count} renouvellement(s) non vu(s)",
            unseenEn: "{count} unseen renewal(s)"
        },
        icons: {
            renewable: "✅",
            impossible: "⛔",
            blocked: "🔒",
            unknown: "ℹ️"
        },
        appearance: {
            compact: false,
            animation: true,
            minWidthPx: 180,
            mobileMinWidthPx: 140,
            successText: "#155724",
            successBg: "#d4edda",
            successBorder: "#b7d7c2",
            dangerText: "#721c24",
            dangerBg: "#f8d7da",
            dangerBorder: "#f5c6cb",
            neutralText: "#495057",
            neutralBg: "#f8f9fa",
            neutralBorder: "#dee2e6"
        },
        advanced: {
            renewalHeaderWords: "renouvel;renew",
            activeCellSelectors: ".renewcol, td.renew, td[class*=\"renew\"]",
            historyCellSelectors: ".renewcol, td.renew, td[class*=\"renew\"]",
            mainRootSelectors: "main, #main, #patron_detail, #patronissues, .main",
            initialScanDelayMs: 150,
            mutationDebounceMs: 100,
            tableDiscoveryMs: 10000,
            diagnostics: false
        },
        reasonLabels: DEFAULT_REASON_LABELS
    };

    let currentConfig = deepClone(DEFAULT_CONFIG);
    let unsubscribeConfig = null;
    let rootObserver = null;
    let discoveryTimer = 0;
    let mutationTimer = 0;
    let apiForbidden = false;
    let activeApi = 0;
    const apiQueue = [];
    const apiCache = new Map();
    const apiFailureCache = new Map();
    const apiPending = new Map();
    const tableObservers = new Map();
    const enhancedCells = new Set();
    const movedNativeControls = new Set();

    function deepClone(value) {
        if (value == null) return value;
        return JSON.parse(JSON.stringify(value));
    }

    function isPlainObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function merge(base, incoming) {
        if (Array.isArray(base)) return Array.isArray(incoming) ? deepClone(incoming) : deepClone(base);
        if (!isPlainObject(base)) return incoming === undefined ? base : incoming;
        const out = {};
        Object.keys(base).forEach(function (key) {
            out[key] = isPlainObject(base[key])
                ? merge(base[key], incoming && isPlainObject(incoming[key]) ? incoming[key] : undefined)
                : Array.isArray(base[key])
                    ? (incoming && Array.isArray(incoming[key]) ? deepClone(incoming[key]) : deepClone(base[key]))
                    : (incoming && incoming[key] !== undefined ? incoming[key] : base[key]);
        });
        if (incoming && isPlainObject(incoming)) {
            Object.keys(incoming).forEach(function (key) {
                if (!(key in out)) out[key] = deepClone(incoming[key]);
            });
        }
        return out;
    }

    function normalizeConfig(config) {
        const out = merge(DEFAULT_CONFIG, config || {});
        out.api.concurrency = clampNumber(out.api.concurrency, 1, 8, 3);
        out.api.timeoutMs = clampNumber(out.api.timeoutMs, 1000, 20000, 4000);
        out.api.cacheMs = clampNumber(out.api.cacheMs, 0, 3600000, 60000);
        out.advanced.initialScanDelayMs = clampNumber(out.advanced.initialScanDelayMs, 0, 5000, 150);
        out.advanced.mutationDebounceMs = clampNumber(out.advanced.mutationDebounceMs, 20, 2000, 100);
        out.advanced.tableDiscoveryMs = clampNumber(out.advanced.tableDiscoveryMs, 1000, 60000, 10000);
        return out;
    }

    function clampNumber(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.max(min, Math.min(max, n));
    }

    function lang() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            try { return window.PMKConfig.getLanguage() === "en" ? "en" : "fr"; } catch (_) {}
        }
        const htmlLang = String(document.documentElement.getAttribute("lang") || "").toLowerCase();
        if (htmlLang.indexOf("en") === 0) return "en";
        return "fr";
    }

    function local(fr, en) {
        return lang() === "en" ? en : fr;
    }

    function debug() {
        if (!currentConfig.advanced.diagnostics || !window.console || typeof console.debug !== "function") return;
        const args = Array.prototype.slice.call(arguments);
        args.unshift("[PMK114]");
        console.debug.apply(console, args);
    }

    function splitRules(value) {
        return String(value || "")
            .split(/[;\n]+/)
            .map(function (item) { return item.trim(); })
            .filter(Boolean);
    }

    function currentPage() {
        const path = window.location && window.location.pathname ? window.location.pathname : "";
        const pages = Array.isArray(currentConfig.pages) ? currentConfig.pages : [];
        return pages.find(function (page) {
            return page && page.enabled !== false && String(page.path || "") === path;
        }) || null;
    }

    function safeQuery(root, selector) {
        try { return root.querySelector(selector); } catch (_) { return null; }
    }

    function safeQueryAll(root, selector) {
        try { return Array.from(root.querySelectorAll(selector)); } catch (_) { return []; }
    }

    function cleanText(value) {
        return String(value || "").replace(/\s+/g, " ").trim();
    }

    function elementVisible(element) {
        if (!element || !element.isConnected) return false;
        if (element.hidden) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(element) : null;
        if (style && (style.display === "none" || style.visibility === "hidden")) return false;
        return true;
    }

    function pageModeIs(page, wanted) {
        if (!page) return false;
        return page.mode === "both" || page.mode === wanted;
    }

    function findMainRoot() {
        const selectors = splitRules(String(currentConfig.advanced.mainRootSelectors || "").replace(/,/g, ";"));
        for (let i = 0; i < selectors.length; i += 1) {
            const el = safeQuery(document, selectors[i]);
            if (el) return el;
        }
        return document.body;
    }

    function headerWords() {
        return splitRules(currentConfig.advanced.renewalHeaderWords).map(function (x) { return x.toLowerCase(); });
    }

    function headerMatches(text) {
        const normalized = cleanText(text).toLowerCase();
        return headerWords().some(function (word) { return word && normalized.indexOf(word) !== -1; });
    }

    function findColumnIndex(table) {
        const rows = safeQueryAll(table, "thead tr, tr");
        for (let r = 0; r < Math.min(rows.length, 5); r += 1) {
            const cells = Array.from(rows[r].children || []).filter(function (el) { return /^(TH|TD)$/.test(el.tagName); });
            for (let i = 0; i < cells.length; i += 1) {
                if (headerMatches(cells[i].textContent)) return i;
            }
        }
        return -1;
    }

    function tableHasRenewalCells(table, mode) {
        const selector = mode === "history" ? currentConfig.advanced.historyCellSelectors : currentConfig.advanced.activeCellSelectors;
        return Boolean(safeQuery(table, selector));
    }

    function findTables(page) {
        if (!page) return [];
        const root = findMainRoot();
        return safeQueryAll(root, "table").filter(function (table) {
            if (!table || !table.isConnected) return false;
            if (table.getAttribute("data-pmk114-ignore") === "1") return false;
            const mode = page.mode === "both" ? "active" : page.mode;
            return findColumnIndex(table) >= 0 || tableHasRenewalCells(table, mode);
        });
    }

    function getCell(row, columnIndex, mode) {
        const selector = mode === "history" ? currentConfig.advanced.historyCellSelectors : currentConfig.advanced.activeCellSelectors;
        const direct = safeQuery(row, selector);
        if (direct && direct.tagName === "TD") return direct;
        const cells = Array.from(row.children || []).filter(function (el) { return el.tagName === "TD"; });
        return columnIndex >= 0 && cells[columnIndex] ? cells[columnIndex] : null;
    }

    function nativeText(cell) {
        if (!cell) return "";
        const clone = cell.cloneNode(true);
        safeQueryAll(clone, ".pmk114-card, .pmk114-checkbox-label").forEach(function (el) { el.remove(); });
        return cleanText(clone.textContent);
    }

    function findNativeCheckbox(cell) {
        const selectors = [
            'input[type="checkbox"].renew',
            'input[type="checkbox"][name="renew"]',
            'input[type="checkbox"][name="renew[]"]',
            'input[type="checkbox"][name="renew_checked"]',
            'input[type="checkbox"][name="renew_checked[]"]',
            'input[type="checkbox"][name="issue"]',
            'input[type="checkbox"][name="issue[]"]',
            'input[type="checkbox"][id^="renew_"]',
            'input[type="checkbox"]'
        ];
        for (let i = 0; i < selectors.length; i += 1) {
            const input = safeQuery(cell, selectors[i]);
            if (input) return input;
        }
        return null;
    }

    function parseCounts(text) {
        const source = cleanText(text);
        let m = source.match(/il\s+reste\s+(\d+)\s+renouvellements?\s+sur\s+(\d+)/i);
        if (m) return { remaining:Number(m[1]), total:Number(m[2]), current:Math.max(0, Number(m[2]) - Number(m[1])), source:"dom" };

        m = source.match(/(\d+)\s*(?:\/|sur)\s*(\d+)\s+renouvellements?\s+restants?/i);
        if (m) return { remaining:Number(m[1]), total:Number(m[2]), current:Math.max(0, Number(m[2]) - Number(m[1])), source:"dom" };

        m = source.match(/(\d+)\s+of\s+(\d+)\s+renewals?\s+remaining/i);
        if (m) return { remaining:Number(m[1]), total:Number(m[2]), current:Math.max(0, Number(m[2]) - Number(m[1])), source:"dom" };

        return null;
    }

    function parseUnseen(text) {
        const source = cleanText(text);
        let m = source.match(/(\d+)\s+(?:renouvellements?\s+)?(?:non\s+vus?|avant\s+que\s+le\s+document\s+doive\s+être\s+vu)/i);
        if (m) return Number(m[1]);
        m = source.match(/(\d+)\s+of\s+\d+\s+renewals?\s+left\s+before\s+the\s+item\s+must\s+be\s+seen/i);
        if (m) return Number(m[1]);
        return null;
    }

    function domReasons(text, cell) {
        /*
         * Les classes Koha spécifiques sont plus fiables qu'un texte générique
         * « Non renouvelable ». On les teste donc en premier afin de conserver
         * un motif précis (réservation, retard, etc.) lorsqu'il existe.
         */
        const knownClassChecks = [
            [".no-renew-hold", "on_reserve"],
            [".no-renew-too-many", "too_many"],
            [".no-renew-unseen", "too_unseen"],
            [".no-renew-overdue", "norenew_overdue"],
            [".no-renew-too-late", "auto_too_late"],
            [".no-renewal-before", "too_soon"],
            [".auto-renew-fines", "auto_too_much_owing"],
            [".auto-renew-expired", "auto_account_expired"]
        ];
        const reasons = [];
        for (let i = 0; i < knownClassChecks.length; i += 1) {
            if (firstActiveMarker(cell, [knownClassChecks[i][0]])) reasons.push(knownClassChecks[i][1]);
        }

        const source = cleanText(text).toLowerCase();
        if (/réserv|reserv|on hold|hold/.test(source)) reasons.push("on_reserve");
        if (/retard|overdue/.test(source)) reasons.push("norenew_overdue");
        if (/trop tôt|trop tot|too soon|no renewal before/.test(source)) reasons.push("too_soon");
        if (/doit.*(?:vu|présent|present)|must be.*seen/.test(source)) reasons.push("too_unseen");
        if (/plus.*renouvel|no renewals left|maximum|maximal/.test(source)) reasons.push("too_many");
        if (/expir/.test(source)) reasons.push("auto_account_expired");
        if (/amende|frais|fine|owing|charge/.test(source)) reasons.push("auto_too_much_owing");
        if (!reasons.length && /not allowed|non renouvelable|renouvellement impossible|renewal not allowed/.test(source)) reasons.push("restriction");
        return Array.from(new Set(reasons));
    }

    function domReason(text, cell) {
        return domReasons(text, cell)[0] || "";
    }

    function reasonLabel(code) {
        if (!code) return "";
        const list = Array.isArray(currentConfig.reasonLabels) ? currentConfig.reasonLabels : [];
        const found = list.find(function (item) { return item && item.enabled !== false && String(item.code || "") === String(code); });
        if (found) return lang() === "en" ? (found.en || found.fr || code) : (found.fr || found.en || code);
        return String(code).replace(/_/g, " ");
    }

    function nativeMarkerActive(element) {
        if (!element) return false;
        if (element.hidden || element.getAttribute("aria-hidden") === "true") return false;
        if (element.style && String(element.style.display || "").toLowerCase() === "none") return false;

        /*
         * Après le premier rendu, PMK masque les marqueurs Koha avec sa propre
         * classe .pmk114-hide-native. Cette classe ne doit pas faire disparaître
         * l'information métier lors des scans suivants. En revanche, une classe
         * Koha/CSS qui masquait déjà le marqueur avant PMK doit être respectée.
         */
        if (!element.classList.contains("pmk114-hide-native")) {
            try {
                if (window.getComputedStyle(element).display === "none") return false;
            } catch (_) {}
        }
        return true;
    }

    function firstActiveMarker(cell, selectors) {
        for (let i = 0; i < selectors.length; i += 1) {
            const nodes = safeQueryAll(cell, selectors[i]);
            for (let j = 0; j < nodes.length; j += 1) {
                if (nativeMarkerActive(nodes[j])) return nodes[j];
            }
        }
        return null;
    }

    function domState(cell) {
        const text = nativeText(cell);
        const checkbox = findNativeCheckbox(cell);
        const counts = parseCounts(text);
        const reasons = domReasons(text, cell);
        const reason = reasons[0] || "";

        const preciseBlockedSelectors = [
            ".no-renew-hold",
            ".no-renew-too-many",
            ".no-renew-unseen",
            ".no-renew-overdue",
            ".no-renew-too-late",
            ".no-renewal-before",
            ".auto-renew-fines",
            ".auto-renew-expired"
        ];
        const preciseBlockedElement = firstActiveMarker(cell, preciseBlockedSelectors);
        const genericBlockedElement = firstActiveMarker(cell, [".renewals-disabled"]);
        const allowedElement = firstActiveMarker(cell, [".renewals-allowed"]);

        const negativeText = /non\s+renouvelable|renouvellement\s+impossible|not\s+renewable|not\s+allowed|no\s+renewals?\s+left/i.test(text);
        const quotaExhausted = Boolean(
            counts &&
            Number.isFinite(Number(counts.total)) && Number(counts.total) > 0 &&
            Number.isFinite(Number(counts.remaining)) && Number(counts.remaining) <= 0
        );
        const quotaAvailable = Boolean(
            counts &&
            Number.isFinite(Number(counts.remaining)) && Number(counts.remaining) > 0
        );
        const checkboxUsable = Boolean(checkbox && !checkbox.disabled && elementVisible(checkbox));
        const checkboxBlocked = Boolean(checkbox && checkbox.disabled);

        /*
         * Priorité de décision v3.2 :
         * 1. blocage explicite Koha / quota à zéro ;
         * 2. autorisation explicite Koha / quota positif ;
         * 3. checkbox seulement en dernier recours.
         *
         * La simple présence d'une checkbox ne peut donc plus transformer
         * « Non renouvelable » + « 0/1 restant » en « Renouvellement possible ».
         */
        let allowsRenewal = null;
        let authority = "none";

        if (preciseBlockedElement || genericBlockedElement || quotaExhausted || checkboxBlocked) {
            allowsRenewal = false;
            authority = quotaExhausted ? "dom-quota" : "dom-blocked";
        } else if (allowedElement || quotaAvailable) {
            allowsRenewal = true;
            authority = quotaAvailable ? "dom-quota" : "dom-allowed";
        } else if (negativeText) {
            allowsRenewal = false;
            authority = "dom-text";
        } else if (checkboxUsable) {
            allowsRenewal = true;
            authority = "dom-checkbox-fallback";
        }

        return {
            source:"dom",
            allowsRenewal:allowsRenewal,
            authoritative:authority !== "none" && authority !== "dom-checkbox-fallback",
            authority:authority,
            checkbox:checkbox,
            counts:counts,
            unseen:parseUnseen(text),
            reason:reason,
            reasons:reasons,
            quotaExhausted:quotaExhausted,
            rawText:text
        };
    }

    function numeric(value) {
        return /^\d+$/.test(String(value || "").trim()) ? String(value).trim() : "";
    }

    function dataCandidate(element, names) {
        if (!element) return "";
        for (let i = 0; i < names.length; i += 1) {
            const attr = element.getAttribute(names[i]);
            const n = numeric(attr);
            if (n) return n;
        }
        return "";
    }

    function extractCheckoutId(row, cell, checkbox) {
        const attrs = ["data-checkout-id", "data-checkoutid", "data-issue-id", "data-issueid", "data-issue"];
        const direct = dataCandidate(checkbox, attrs) || dataCandidate(cell, attrs) || dataCandidate(row, attrs);
        if (direct) return direct;

        const withData = safeQuery(row, "[data-checkout-id],[data-checkoutid],[data-issue-id],[data-issueid],[data-issue]");
        const nested = dataCandidate(withData, attrs);
        if (nested) return nested;

        const hidden = safeQuery(row, 'input[type="hidden"][name="checkout_id"],input[type="hidden"][name="issue_id"],input[type="hidden"][name="issue"]');
        const hiddenValue = hidden ? numeric(hidden.value) : "";
        if (hiddenValue) return hiddenValue;

        const links = safeQueryAll(row, "a[href], a[data-issue], a[data-issueid], a[data-checkout-id]");
        for (let i = 0; i < links.length; i += 1) {
            const fromData = dataCandidate(links[i], attrs);
            if (fromData) return fromData;
            try {
                const url = new URL(links[i].getAttribute("href"), window.location.origin);
                const fromUrl = numeric(url.searchParams.get("checkout_id")) || numeric(url.searchParams.get("issue_id")) || numeric(url.searchParams.get("issue"));
                if (fromUrl) return fromUrl;
            } catch (_) {}
        }

        if (checkbox) {
            /*
             * IMPORTANT : dans Koha, id="renew_12345" / value="12345" désigne
             * généralement l'ITEMNUMBER, pas le checkout_id de l'API REST.
             * On ne transforme donc jamais l'id renew_* en identifiant de prêt.
             */
            const name = String(checkbox.name || "").toLowerCase();
            const value = numeric(checkbox.value);
            if (value && currentConfig.api.trustCheckboxValueWhenNamedIssue !== false && /^issue(?:\[\])?$/.test(name)) return value;
            if (value && currentConfig.api.trustCheckboxValueWhenNamedRenew === true && /^renew(?:\[\])?$/.test(name)) return value;
        }
        return "";
    }

    function cacheGet(id) {
        const hit = apiCache.get(String(id));
        if (!hit) return null;
        if (Date.now() - hit.at > currentConfig.api.cacheMs) {
            apiCache.delete(String(id));
            return null;
        }
        return deepClone(hit.value);
    }

    function cacheSet(id, value) {
        apiCache.set(String(id), { at:Date.now(), value:deepClone(value) });
        apiFailureCache.delete(String(id));
    }

    function failureCacheActive(id) {
        const key = String(id);
        const at = apiFailureCache.get(key);
        if (!at) return false;
        if (Date.now() - at > currentConfig.api.cacheMs) {
            apiFailureCache.delete(key);
            return false;
        }
        return true;
    }

    function markApiFailure(id) {
        apiFailureCache.set(String(id), Date.now());
    }

    function apiFetch(checkoutId) {
        const cached = cacheGet(checkoutId);
        if (cached) return Promise.resolve(cached);
        if (failureCacheActive(checkoutId)) return Promise.resolve(null);
        if (!currentConfig.api.enabled || apiForbidden) return Promise.resolve(null);
        const key = String(checkoutId);
        if (apiPending.has(key)) return apiPending.get(key);

        const pending = new Promise(function (resolve) {
            apiQueue.push({ id:key, resolve:resolve });
            pumpApiQueue();
        }).finally(function () {
            apiPending.delete(key);
        });
        apiPending.set(key, pending);
        return pending;
    }

    function pumpApiQueue() {
        const max = currentConfig.api.concurrency;
        while (activeApi < max && apiQueue.length) {
            const job = apiQueue.shift();
            activeApi += 1;
            doApiFetch(job.id)
                .then(job.resolve)
                .catch(function () { job.resolve(null); })
                .finally(function () {
                    activeApi -= 1;
                    pumpApiQueue();
                });
        }
    }

    function doApiFetch(checkoutId) {
        const endpoint = String(currentConfig.api.endpointTemplate || DEFAULT_CONFIG.api.endpointTemplate).replace("{id}", encodeURIComponent(checkoutId));
        const controller = typeof AbortController === "function" ? new AbortController() : null;
        let timer = 0;
        if (controller) timer = window.setTimeout(function () { try { controller.abort(); } catch (_) {} }, currentConfig.api.timeoutMs);

        return window.fetch(endpoint, {
            method:"GET",
            credentials:"same-origin",
            cache:"no-store",
            headers:{ Accept:"application/json" },
            signal:controller ? controller.signal : undefined
        }).then(function (response) {
            if (timer) window.clearTimeout(timer);
            if (response.status === 401 || response.status === 403) {
                if (currentConfig.api.stopAfterForbidden !== false) apiForbidden = true;
                markApiFailure(checkoutId);
                debug("API renewal forbidden; DOM fallback retained", response.status);
                return null;
            }
            if (!response.ok) {
                markApiFailure(checkoutId);
                return null;
            }
            return response.json();
        }).then(function (data) {
            if (!data || typeof data !== "object") {
                markApiFailure(checkoutId);
                return null;
            }
            const normalized = {
                source:"api",
                allowsRenewal:typeof data.allows_renewal === "boolean" ? data.allows_renewal : null,
                maxRenewals:Number.isFinite(Number(data.max_renewals)) ? Number(data.max_renewals) : null,
                currentRenewals:Number.isFinite(Number(data.current_renewals)) ? Number(data.current_renewals) : null,
                unseenRenewals:Number.isFinite(Number(data.unseen_renewals)) ? Number(data.unseen_renewals) : null,
                error:data.error == null ? "" : String(data.error)
            };
            if (normalized.maxRenewals != null && normalized.currentRenewals != null) {
                normalized.remainingRenewals = Math.max(0, normalized.maxRenewals - normalized.currentRenewals);
            } else {
                normalized.remainingRenewals = null;
            }
            cacheSet(checkoutId, normalized);
            return normalized;
        }).catch(function (error) {
            if (timer) window.clearTimeout(timer);
            markApiFailure(checkoutId);
            if (error && error.name !== "AbortError") debug("allows_renewal failed", checkoutId, error);
            return null;
        });
    }

    function formatTemplate(template, vars) {
        return String(template || "").replace(/\{([a-zA-Z0-9_]+)\}/g, function (_, key) {
            return vars[key] == null ? "" : String(vars[key]);
        });
    }

    function resolvedState(dom, api) {
        const preferApi = currentConfig.active.statusSource !== "dom-only";

        /*
         * Le DOM Koha est prioritaire lorsqu'il contient une décision explicite
         * (blocage, autorisation ou quota). L'API ne peut pas renverser cet état ;
         * elle sert uniquement à compléter un DOM indéterminé ou à enrichir les
         * informations absentes.
         */
        let allows = dom && typeof dom.allowsRenewal === "boolean" ? dom.allowsRenewal : null;
        let source = dom && dom.authority ? dom.authority : "dom";

        if (!(dom && dom.authoritative) && preferApi && api && typeof api.allowsRenewal === "boolean") {
            allows = api.allowsRenewal;
            source = "api";
        }

        let counts = dom && dom.counts ? dom.counts : null;
        if (!counts && api && api.maxRenewals != null && api.currentRenewals != null) {
            counts = {
                remaining:api.remainingRenewals,
                total:api.maxRenewals,
                current:api.currentRenewals,
                source:"api"
            };
        }

        const unseen = dom && dom.unseen != null
            ? dom.unseen
            : (api && api.unseenRenewals != null ? api.unseenRenewals : null);

        let reasons = dom && Array.isArray(dom.reasons) ? dom.reasons.slice() : (dom && dom.reason ? [dom.reason] : []);
        if (api && api.error && !reasons.includes(api.error)) reasons.push(api.error);
        reasons = reasons.filter(Boolean);
        let reason = reasons[0] || "";
        if (allows === false && isGenericRestrictionReason(reason)) reason = "";

        const remainingRenewals = counts && Number.isFinite(Number(counts.remaining)) ? Number(counts.remaining) : null;
        const totalRenewals = counts && Number.isFinite(Number(counts.total)) ? Number(counts.total) : null;
        const currentRenewals = counts && Number.isFinite(Number(counts.current)) ? Number(counts.current) : 0;
        const quotaReached = Boolean(
            totalRenewals != null && totalRenewals > 0 &&
            remainingRenewals != null && remainingRenewals <= 0
        );

        // Le quota DOM à zéro reste impératif même si une API répondrait true.
        if (quotaReached && dom && dom.counts) {
            allows = false;
            source = "dom-quota";
        }

        return {
            allowsRenewal:allows,
            counts:counts,
            unseen:unseen,
            reason:reason,
            reasons:reasons,
            hasRenewed:currentRenewals > 0,
            quotaReached:quotaReached,
            source:source
        };
    }

    function applyAppearanceVars(card) {
        const a = currentConfig.appearance;
        card.style.setProperty("--pmk114-success-text", String(a.successText || DEFAULT_CONFIG.appearance.successText));
        card.style.setProperty("--pmk114-success-bg", String(a.successBg || DEFAULT_CONFIG.appearance.successBg));
        card.style.setProperty("--pmk114-success-border", String(a.successBorder || DEFAULT_CONFIG.appearance.successBorder));
        card.style.setProperty("--pmk114-danger-text", String(a.dangerText || DEFAULT_CONFIG.appearance.dangerText));
        card.style.setProperty("--pmk114-danger-bg", String(a.dangerBg || DEFAULT_CONFIG.appearance.dangerBg));
        card.style.setProperty("--pmk114-danger-border", String(a.dangerBorder || DEFAULT_CONFIG.appearance.dangerBorder));
        card.style.setProperty("--pmk114-neutral-text", String(a.neutralText || DEFAULT_CONFIG.appearance.neutralText));
        card.style.setProperty("--pmk114-neutral-bg", String(a.neutralBg || DEFAULT_CONFIG.appearance.neutralBg));
        card.style.setProperty("--pmk114-neutral-border", String(a.neutralBorder || DEFAULT_CONFIG.appearance.neutralBorder));
        card.style.setProperty("--pmk114-min-width", String(clampNumber(a.minWidthPx, 100, 600, 180)) + "px");
        card.style.setProperty("--pmk114-mobile-min-width", String(clampNumber(a.mobileMinWidthPx, 80, 400, 140)) + "px");
        card.classList.toggle("is-compact", Boolean(a.compact));
        card.classList.toggle("no-animation", a.animation === false);
    }

    function ensureCard(cell) {
        let card = safeQuery(cell, ":scope > .pmk114-card");
        if (!card) {
            card = document.createElement("div");
            card.className = "pmk114-card";
            card.setAttribute("data-pmk114-owned", "1");

            const status = document.createElement("div");
            status.className = "pmk114-status";
            const icon = document.createElement("span");
            icon.className = "pmk114-icon";
            icon.setAttribute("aria-hidden", "true");
            const text = document.createElement("span");
            text.className = "pmk114-status-text";
            status.appendChild(icon);
            status.appendChild(text);
            card.appendChild(status);

            const renewChoice = document.createElement("div");
            renewChoice.className = "pmk114-renew-choice";
            renewChoice.hidden = true;
            card.appendChild(renewChoice);

            const count = document.createElement("span");
            count.className = "pmk114-count";
            card.appendChild(count);

            const unseen = document.createElement("span");
            unseen.className = "pmk114-unseen";
            card.appendChild(unseen);

            const reason = document.createElement("span");
            reason.className = "pmk114-reason";
            card.appendChild(reason);

            cell.insertBefore(card, cell.firstChild);
        }
        applyAppearanceVars(card);
        enhancedCells.add(cell);
        cell.classList.add("pmk114-enhanced");
        return card;
    }

    function labelState(card, state, loading) {
        const icon = safeQuery(card, ".pmk114-icon");
        const text = safeQuery(card, ".pmk114-status-text");
        card.classList.remove("is-ok", "is-blocked", "is-unknown");

        if (state.allowsRenewal === true) {
            card.classList.add("is-ok");
            if (icon) icon.textContent = currentConfig.icons.renewable || "✅";
            if (text) text.textContent = local(currentConfig.labels.renewableFr, currentConfig.labels.renewableEn);
        } else if (state.allowsRenewal === false) {
            card.classList.add("is-blocked");
            if (icon) icon.textContent = currentConfig.icons.impossible || "⛔";
            if (text) text.textContent = state.quotaReached
                ? local(
                    currentConfig.labels.renewedQuotaFr || "Quota de renouvellements atteint",
                    currentConfig.labels.renewedQuotaEn || "Renewal limit reached"
                )
                : local(currentConfig.labels.impossibleFr, currentConfig.labels.impossibleEn);
        } else {
            card.classList.add("is-unknown");
            if (icon) icon.textContent = currentConfig.icons.unknown || "ℹ️";
            if (text) text.textContent = local(currentConfig.labels.unknownFr, currentConfig.labels.unknownEn);
        }

        card.classList.toggle("is-loading", Boolean(loading));
        card.setAttribute("data-source", state.source || "dom");
    }

    function renderCount(card, state) {
        const el = safeQuery(card, ".pmk114-count");
        if (!el) return;
        if (!currentConfig.active.showCounts || !state.counts || !Number.isFinite(Number(state.counts.total))) {
            el.hidden = true;
            el.textContent = "";
            return;
        }
        const vars = {
            remaining:Number(state.counts.remaining) || 0,
            current:Number(state.counts.current) || 0,
            total:Number(state.counts.total) || 0
        };
        const useUsed = currentConfig.active.countFormat === "used-total";
        const template = useUsed
            ? local(currentConfig.labels.usedFr, currentConfig.labels.usedEn)
            : local(currentConfig.labels.remainingFr, currentConfig.labels.remainingEn);
        el.textContent = formatTemplate(template, vars);
        el.hidden = false;
    }

    function renderUnseen(card, state) {
        const el = safeQuery(card, ".pmk114-unseen");
        if (!el) return;
        if (!currentConfig.active.showUnseenRenewals || state.unseen == null || Number(state.unseen) <= 0) {
            el.hidden = true;
            el.textContent = "";
            return;
        }
        el.textContent = formatTemplate(local(currentConfig.labels.unseenFr, currentConfig.labels.unseenEn), { count:Number(state.unseen) });
        el.hidden = false;
    }


    function isGenericRestrictionReason(reason) {
        const value = cleanText(reason).toLowerCase();
        if (!value) return false;
        return (
            value === "restriction" ||
            value === "not_allowed" ||
            value === "not allowed" ||
            /renewal\s+not\s+allowed/.test(value) ||
            /renouvellement\s+impossible/.test(value) ||
            /non\s+renouvelable/.test(value) ||
            /restriction.*renouvel/.test(value)
        );
    }

    function renderReason(card, state) {
        const el = safeQuery(card, ".pmk114-reason");
        if (!el) return;

        /*
         * Un motif générique "restriction" n'apporte rien au statut rouge
         * "Renouvellement impossible" et peut faire croire qu'un renouvellement
         * qui vient de réussir a échoué. On ne l'affiche jamais.
         * Les motifs réellement explicatifs (réservation, retard, quota, etc.)
         * restent disponibles.
         */
        if (
            !currentConfig.active.showReason ||
            !(state.reasons && state.reasons.length) && !state.reason
        ) {
            el.hidden = true;
            el.textContent = "";
            return;
        }

        const codes = Array.from(new Set((state.reasons && state.reasons.length ? state.reasons : [state.reason]).filter(function(code){return code && !isGenericRestrictionReason(code);} )));
        const labels = codes.map(reasonLabel).filter(function(label){return label && !isGenericRestrictionReason(label);});
        if (!labels.length) {
            el.hidden = true;
            el.textContent = "";
            return;
        }

        el.textContent = labels.join(" · ");
        el.title = local("Motifs fournis par Koha : ", "Reasons supplied by Koha: ") + codes.join(", ");
        el.hidden = false;
    }

    function restoreNativeControl(checkbox) {
        if (!checkbox) return;
        const state = checkbox.__pmk114MoveState;
        if (!state) {
            checkbox.classList.remove("pmk114-native-checkbox");
            return;
        }

        const carrier = state.carrier;
        if (carrier) {
            safeQueryAll(carrier, ".pmk114-checkbox-label[data-pmk114-owned=\"1\"]").forEach(function (el) { el.remove(); });
        }

        const parent = state.originalParent;
        const next = state.originalNextSibling;
        if (parent && parent.isConnected) {
            try {
                if (state.generatedWrapper) {
                    if (next && next.parentNode === parent) parent.insertBefore(checkbox, next);
                    else parent.appendChild(checkbox);
                } else if (carrier) {
                    if (next && next.parentNode === parent) parent.insertBefore(carrier, next);
                    else parent.appendChild(carrier);
                }
            } catch (_) {}
        }

        if (carrier && !state.generatedWrapper) {
            carrier.classList.remove("pmk114-native-control");
            carrier.removeAttribute("data-pmk114-native-moved");
        }
        checkbox.classList.remove("pmk114-native-checkbox");
        checkbox.removeAttribute("data-pmk114-native-moved");
        try { delete checkbox.__pmk114MoveState; } catch (_) { checkbox.__pmk114MoveState = null; }
        movedNativeControls.delete(checkbox);
    }

    function checkboxLabelRoot(checkbox) {
        if (!checkbox) return null;
        const state = checkbox.__pmk114MoveState;
        if (state && state.carrier) return state.carrier;
        return checkbox.closest("label") || checkbox.parentElement;
    }

    function syncCheckboxLabel(checkbox) {
        if (!checkbox) return;
        const root = checkboxLabelRoot(checkbox);
        if (!root) return;

        let existingGenerated = safeQuery(root, ".pmk114-checkbox-label[data-pmk114-owned=\"1\"]");
        if (!currentConfig.active.showCheckboxLabel) {
            if (existingGenerated) existingGenerated.remove();
            return;
        }

        const clone = root.cloneNode(true);
        safeQueryAll(clone, ".pmk114-checkbox-label").forEach(function (el) { el.remove(); });
        const alreadyLabeled = /renouvel|renew/i.test(cleanText(clone.textContent));
        if (alreadyLabeled || existingGenerated) return;

        const label = document.createElement("span");
        label.className = "pmk114-checkbox-label";
        label.setAttribute("data-pmk114-owned", "1");
        label.textContent = local(currentConfig.labels.renewFr, currentConfig.labels.renewEn);
        root.appendChild(label);
    }

    function moveNativeControlIntoCard(cell, card, checkbox) {
        if (!cell || !card || !checkbox) return;
        const zone = safeQuery(card, ".pmk114-renew-choice");
        if (!zone) return;

        let state = checkbox.__pmk114MoveState;
        if (!state) {
            const nativeLabel = checkbox.closest("label");
            const movableNativeLabel = nativeLabel && cell.contains(nativeLabel) && !nativeLabel.closest(".pmk114-card");
            if (movableNativeLabel) {
                state = {
                    carrier:nativeLabel,
                    originalParent:nativeLabel.parentNode,
                    originalNextSibling:nativeLabel.nextSibling,
                    generatedWrapper:false
                };
                nativeLabel.classList.add("pmk114-native-control");
                nativeLabel.setAttribute("data-pmk114-native-moved", "1");
                zone.appendChild(nativeLabel);
            } else {
                const originalParent = checkbox.parentNode;
                const originalNextSibling = checkbox.nextSibling;
                const wrapper = document.createElement("label");
                wrapper.className = "pmk114-native-control pmk114-native-control-generated";
                wrapper.setAttribute("data-pmk114-owned", "1");
                wrapper.setAttribute("data-pmk114-native-moved", "1");
                state = {
                    carrier:wrapper,
                    originalParent:originalParent,
                    originalNextSibling:originalNextSibling,
                    generatedWrapper:true
                };
                wrapper.appendChild(checkbox);
                zone.appendChild(wrapper);
            }
            checkbox.__pmk114MoveState = state;
            checkbox.setAttribute("data-pmk114-native-moved", "1");
            movedNativeControls.add(checkbox);
        } else if (state.carrier && state.carrier.parentNode !== zone) {
            zone.appendChild(state.carrier);
        }

        zone.hidden = false;
        zone.classList.toggle("is-disabled", Boolean(checkbox.disabled));
        zone.setAttribute("aria-disabled", checkbox.disabled ? "true" : "false");
        syncCheckboxLabel(checkbox);
    }

    function styleNativeControl(cell, card, checkbox) {
        const zone = card ? safeQuery(card, ".pmk114-renew-choice") : null;
        if (!checkbox) {
            if (zone) zone.hidden = true;
            return;
        }

        checkbox.classList.add("pmk114-native-checkbox");

        if (currentConfig.active.integrateCheckboxInCard !== false && card) {
            moveNativeControlIntoCard(cell, card, checkbox);
            return;
        }

        if (checkbox.__pmk114MoveState) restoreNativeControl(checkbox);
        checkbox.classList.add("pmk114-native-checkbox");
        const parent = checkbox.closest("label") || checkbox.parentElement;
        if (parent && parent !== cell) parent.classList.add("pmk114-native-control");
        if (zone) zone.hidden = true;
        syncCheckboxLabel(checkbox);
    }

    function syncNativeControlAvailability(card, checkbox, state) {
        const zone = card ? safeQuery(card, ".pmk114-renew-choice") : null;
        if (!zone) return;

        const canRenew = Boolean(state && state.allowsRenewal === true && checkbox && !checkbox.disabled);
        zone.hidden = !canRenew;
        zone.classList.toggle("is-disabled", !canRenew);
        zone.setAttribute("aria-disabled", canRenew ? "false" : "true");

        /*
         * On ne désactive pas artificiellement la checkbox native Koha : elle
         * reste intacte pour préserver le fonctionnement du formulaire. On la
         * retire simplement de l'interface PMK quand Koha dit non renouvelable.
         */
    }

    function hideKnownNativeElements(cell) {
        safeQueryAll(cell, ".pmk114-hide-native").forEach(function (el) { el.classList.remove("pmk114-hide-native"); });
        if (!currentConfig.active.hideKnownNativeText) return;

        const selectors = [
            ".renewals-info",
            ".renewals-disabled",
            ".renewals",
            ".no-renew-hold",
            ".no-renew-too-many",
            ".no-renew-unseen",
            ".no-renew-overdue",
            ".no-renew-too-late",
            ".no-renewal-before",
            ".auto-renew-fines",
            ".auto-renew-expired"
        ];
        selectors.forEach(function (selector) {
            safeQueryAll(cell, selector).forEach(function (el) {
                if (el.closest(".pmk114-card")) return;
                if (safeQuery(el, 'input[type="checkbox"]')) return;
                el.classList.add("pmk114-hide-native");
            });
        });

        /*
         * Koha peut laisser un compteur numérique brut dans un <span> imbriqué
         * (ex. "0") à côté du texte .renewals-info. Une fois ce dernier repris
         * dans la carte PMK, ce nombre isolé devient un reliquat visuel.
         * On ne masque que les spans numériques/vides hors carte et sans contrôle.
         */
        safeQueryAll(cell, "span").forEach(function (el) {
            if (el.closest(".pmk114-card")) return;
            if (safeQuery(el, 'input,button,select,textarea,a[href]')) return;

            const text = cleanText(el.textContent);
            const hasMeaningfulChild = Array.from(el.children || []).some(function (child) {
                if (child.classList && child.classList.contains("pmk114-hide-native")) return false;
                const childText = cleanText(child.textContent);
                return childText && !/^\d+$/.test(childText);
            });

            if (!hasMeaningfulChild && (/^\d+$/.test(text) || text === "")) {
                el.classList.add("pmk114-hide-native");
            }
        });
    }

    function renderActiveCell(row, cell) {
        if (!cell || !cell.isConnected) return;
        const dom = domState(cell);
        if (!dom.checkbox && dom.allowsRenewal == null && !dom.rawText) return;

        const card = ensureCard(cell);
        card.hidden = false;
        const statusLine = safeQuery(card, ".pmk114-status");
        if (statusLine) statusLine.hidden = !currentConfig.active.showStatus;
        hideKnownNativeElements(cell);
        styleNativeControl(cell, card, dom.checkbox);

        const initial = resolvedState(dom, null);
        syncNativeControlAvailability(card, dom.checkbox, initial);
        labelState(card, initial, false);
        renderCount(card, initial);
        renderUnseen(card, initial);
        renderReason(card, initial);

        if (!currentConfig.api.enabled || apiForbidden) return;
        const checkoutId = extractCheckoutId(row, cell, dom.checkbox);
        if (!checkoutId) {
            card.setAttribute("data-api", "no-checkout-id");
            return;
        }

        const cached = cacheGet(checkoutId);
        if (cached) {
            const state = resolvedState(dom, cached);
            syncNativeControlAvailability(card, dom.checkbox, state);
            labelState(card, state, false);
            renderCount(card, state);
            renderUnseen(card, state);
            renderReason(card, state);
            card.setAttribute("data-api", "cache");
            return;
        }

        if (failureCacheActive(checkoutId)) {
            labelState(card, initial, false);
            card.setAttribute("data-api", "fallback-dom-cached");
            return;
        }

        // Si Koha donne déjà un état exploitable dans le DOM, l'API enrichit
        // silencieusement en arrière-plan : aucun spinner ne doit clignoter.
        // Le spinner n'est affiché que lorsque le DOM ne permet vraiment pas
        // de déterminer l'état du renouvellement.
        const needsVisibleLoading = initial.allowsRenewal == null;
        labelState(card, initial, needsVisibleLoading);
        card.setAttribute("data-api", needsVisibleLoading ? "loading" : "loading-silent");
        apiFetch(checkoutId).then(function (api) {
            if (!cell.isConnected || !card.isConnected) return;
            const freshDom = domState(cell);
            const state = resolvedState(freshDom, api);
            syncNativeControlAvailability(card, freshDom.checkbox, state);
            labelState(card, state, false);
            renderCount(card, state);
            renderUnseen(card, state);
            renderReason(card, state);
            card.setAttribute("data-api", api ? "ok" : "fallback-dom");
        });
    }

    function compilePatterns(raw) {
        return splitRules(raw).map(function (pattern) {
            try { return new RegExp(pattern, "i"); } catch (_) { return null; }
        }).filter(Boolean);
    }

    function historyMatch(text, patterns) {
        const value = cleanText(text);
        return patterns.some(function (rx) { return rx.test(value); });
    }

    function clearHistoryClasses(cell) {
        cell.classList.remove("pmk114-history-renewed", "pmk114-history-not-renewed");
        if (cell.getAttribute("data-pmk114-label-owned") === "1") {
            cell.classList.remove("label", "label-success", "label-default");
            cell.removeAttribute("data-pmk114-label-owned");
        }
        if (cell.getAttribute("data-pmk114-title-owned") === "1") {
            const original = cell.__pmk114OriginalTitle;
            if (original == null) cell.removeAttribute("title");
            else cell.setAttribute("title", original);
            cell.removeAttribute("data-pmk114-title-owned");
            try { delete cell.__pmk114OriginalTitle; } catch (_) { cell.__pmk114OriginalTitle = undefined; }
        }
    }

    function renderHistoryCell(cell) {
        if (!cell || !currentConfig.history.enabled) return;
        const text = nativeText(cell);
        if (!text) return;

        clearHistoryClasses(cell);
        const renewed = historyMatch(text, compilePatterns(currentConfig.history.renewedPatterns));
        const notRenewed = !renewed && historyMatch(text, compilePatterns(currentConfig.history.notRenewedPatterns));

        if (renewed) {
            cell.classList.add("pmk114-history-renewed");
            if (currentConfig.history.useLegacyLabelClasses) {
                cell.classList.add("label", "label-success");
                cell.setAttribute("data-pmk114-label-owned", "1");
            }
            cell.__pmk114OriginalTitle = cell.getAttribute("title");
            cell.title = local(currentConfig.history.renewedTooltipFr, currentConfig.history.renewedTooltipEn);
            cell.setAttribute("data-pmk114-title-owned", "1");
        } else if (notRenewed) {
            cell.classList.add("pmk114-history-not-renewed");
            if (currentConfig.history.useLegacyLabelClasses) {
                cell.classList.add("label", "label-default");
                cell.setAttribute("data-pmk114-label-owned", "1");
            }
            cell.__pmk114OriginalTitle = cell.getAttribute("title");
            cell.title = local(currentConfig.history.notRenewedTooltipFr, currentConfig.history.notRenewedTooltipEn);
            cell.setAttribute("data-pmk114-title-owned", "1");
        }
        enhancedCells.add(cell);
    }

    function processTable(table, page) {
        if (!table || !table.isConnected || !page) return;
        const columnIndex = findColumnIndex(table);
        const mode = page.mode || "active";
        const rows = safeQueryAll(table, "tbody tr");

        rows.forEach(function (row) {
            const lookupMode = mode === "history" ? "history" : "active";
            const cell = getCell(row, columnIndex, lookupMode);
            if (!cell) return;
            if (mode === "active" && currentConfig.active.enabled) renderActiveCell(row, cell);
            else if (mode === "history" && currentConfig.history.enabled) renderHistoryCell(cell);
            else if (mode === "both") {
                const state = domState(cell);
                if ((state.checkbox || state.allowsRenewal != null) && currentConfig.active.enabled) renderActiveCell(row, cell);
                else if (currentConfig.history.enabled) renderHistoryCell(cell);
            }
        });

        mountContextAccess(table, page);
        observeTable(table, page);
    }

    function observeTable(table, page) {
        if (tableObservers.has(table) || typeof MutationObserver !== "function") return;
        const target = safeQuery(table, "tbody") || table;
        const observer = new MutationObserver(function (mutations) {
            const meaningful = mutations.some(function (mutation) {
                if (mutation.type !== "childList") return false;
                return mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0;
            });
            if (!meaningful) return;
            window.clearTimeout(mutationTimer);
            mutationTimer = window.setTimeout(function () { processTable(table, page); }, currentConfig.advanced.mutationDebounceMs);
        });
        observer.observe(target, { childList:true, subtree:true });
        tableObservers.set(table, observer);
    }


    function removeLegacy089SimulationButton() {
        // Le 089 historique ajoutait un bouton qui ne renouvelait rien : il simulait seulement le rendu.
        // Suppression défensive pendant la période de migration si 089 est encore chargé par erreur.
        safeQueryAll(document, "#selection_ops button, #selection_ops input[type=button], #selection_ops input[type=submit]").forEach(function (button) {
            const text = cleanText(button.textContent || button.value);
            if (text === "Renouveler la sélection" || text === "Renew selection") {
                button.remove();
            }
        });
    }

    function scan() {
        const page = currentPage();
        if (!currentConfig.enabled || !page) return 0;
        removeLegacy089SimulationButton();
        const tables = findTables(page);
        tables.forEach(function (table) { processTable(table, page); });
        return tables.length;
    }

    function startRootDiscovery() {
        stopRootDiscovery();
        if (typeof MutationObserver !== "function") return;
        const root = findMainRoot();
        if (!root) return;

        rootObserver = new MutationObserver(function (mutations) {
            const foundTableChange = mutations.some(function (mutation) {
                return Array.from(mutation.addedNodes || []).some(function (node) {
                    return node && node.nodeType === 1 && (node.tagName === "TABLE" || safeQuery(node, "table"));
                });
            });
            if (!foundTableChange) return;
            window.clearTimeout(mutationTimer);
            mutationTimer = window.setTimeout(scan, currentConfig.advanced.mutationDebounceMs);
        });
        rootObserver.observe(root, { childList:true, subtree:true });
        discoveryTimer = window.setTimeout(stopRootDiscovery, currentConfig.advanced.tableDiscoveryMs);
    }

    function stopRootDiscovery() {
        if (rootObserver) rootObserver.disconnect();
        rootObserver = null;
        if (discoveryTimer) window.clearTimeout(discoveryTimer);
        discoveryTimer = 0;
    }

    function mountContextAccess(table, page) {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = safeQuery(table, "thead th") || table;
        if (!anchor || anchor.getAttribute("data-pmk114-config-anchor") === "1") return;
        anchor.setAttribute("data-pmk114-config-anchor", "1");
        try {
            window.PMKConfig.mountContextButton({
                moduleId:MODULE_ID,
                anchor:anchor,
                position:"append",
                contextKey:CONTEXT_KEY + "-" + (page ? page.id : "page"),
                context:{ sectionId:"activation", pageId:page ? page.id : "" }
            });
        } catch (_) {}
    }

    function addStyles() {
        let style = document.getElementById(STYLE_ID);
        if (style) return;
        style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
            .pmk114-enhanced { padding: 6px 8px !important; }
            .pmk114-card {
                --pmk114-success-text:#155724;
                --pmk114-success-bg:#d4edda;
                --pmk114-success-border:#b7d7c2;
                --pmk114-danger-text:#721c24;
                --pmk114-danger-bg:#f8d7da;
                --pmk114-danger-border:#f5c6cb;
                --pmk114-neutral-text:#495057;
                --pmk114-neutral-bg:#f8f9fa;
                --pmk114-neutral-border:#dee2e6;
                --pmk114-min-width:180px;
                --pmk114-mobile-min-width:140px;
                box-sizing:border-box;
                display:flex;
                flex-direction:column;
                align-items:flex-start;
                gap:4px;
                min-width:var(--pmk114-min-width);
                padding:4px 8px;
                margin:0 0 4px 0;
                border:1px solid var(--pmk114-neutral-border);
                border-radius:6px;
                background:var(--pmk114-neutral-bg);
                color:var(--pmk114-neutral-text);
                font:inherit;
            }
            .pmk114-card:not(.no-animation) { animation:pmk114Fade .22s ease-out; }
            @keyframes pmk114Fade { from{opacity:0;transform:translateY(-3px)} to{opacity:1;transform:none} }
            .pmk114-card.is-ok { border-color:var(--pmk114-neutral-border); background:var(--pmk114-neutral-bg); color:var(--pmk114-success-text); }
            .pmk114-card.is-blocked { border-color:var(--pmk114-neutral-border); background:var(--pmk114-neutral-bg); color:var(--pmk114-danger-text); }
            .pmk114-card.is-unknown { border-color:var(--pmk114-neutral-border); background:var(--pmk114-neutral-bg); color:var(--pmk114-neutral-text); }
            .pmk114-status { display:flex; align-items:center; gap:5px; font-weight:600; line-height:1.25; }
            .pmk114-icon { flex:0 0 auto; }
            .pmk114-count {
                display:inline-block;
                padding:2px 9px;
                border:1px solid currentColor;
                border-radius:999px;
                font-size:.85em;
                font-weight:500;
                opacity:.96;
            }
            .pmk114-card.is-ok .pmk114-count { background:var(--pmk114-success-bg); border-color:var(--pmk114-success-border); color:var(--pmk114-success-text); }
            .pmk114-card.is-blocked .pmk114-count { background:var(--pmk114-danger-bg); border-color:var(--pmk114-danger-border); color:var(--pmk114-danger-text); }
            .pmk114-unseen,.pmk114-reason { font-size:.84em; line-height:1.3; }
            .pmk114-reason { font-weight:500; }
            .pmk114-card.is-loading::after { content:""; width:10px; height:10px; border:2px solid currentColor; border-right-color:transparent; border-radius:50%; animation:pmk114Spin .7s linear infinite; position:absolute; margin-left:calc(var(--pmk114-min-width) - 30px); margin-top:2px; opacity:.55; }
            @keyframes pmk114Spin { to{transform:rotate(360deg)} }
            .pmk114-card { position:relative; }
            .pmk114-renew-choice {
                display:flex;
                align-items:center;
                width:100%;
                box-sizing:border-box;
                margin:1px 0 2px 0;
                padding:4px 7px;
                border:1px solid var(--pmk114-neutral-border);
                border-radius:6px;
                background:rgba(255,255,255,.58);
            }
            .pmk114-renew-choice[hidden] { display:none !important; }
            .pmk114-card.is-ok .pmk114-renew-choice { border-color:var(--pmk114-success-border); background:var(--pmk114-success-bg); }
            .pmk114-card.is-blocked .pmk114-renew-choice { border-color:var(--pmk114-danger-border); background:var(--pmk114-danger-bg); }
            .pmk114-renew-choice.is-disabled { opacity:.68; }
            .pmk114-native-control {
                display:inline-flex !important;
                align-items:center;
                gap:7px;
                width:100%;
                margin:0 !important;
                padding:0 !important;
                border:0 !important;
                border-radius:0 !important;
                background:transparent !important;
                cursor:pointer;
                font-weight:600;
                line-height:1.3;
            }
            .pmk114-renew-choice.is-disabled .pmk114-native-control { cursor:not-allowed; }
            .pmk114-native-checkbox {
                flex:0 0 auto;
                width:1.05rem;
                height:1.05rem;
                margin:0 !important;
                accent-color:var(--pmk114-success-text);
                cursor:pointer;
            }
            .pmk114-native-checkbox:disabled { cursor:not-allowed; }
            .pmk114-checkbox-label { margin:0; font-size:.9em; font-weight:600; }
            .pmk114-hide-native { display:none !important; }
            .pmk114-history-renewed { font-weight:600; }
            .pmk114-history-not-renewed { font-weight:500; }
            .pmk114-card.is-compact { gap:2px; padding:3px 6px; font-size:.9em; }
            @media (max-width:768px) {
                .pmk114-card { min-width:var(--pmk114-mobile-min-width); font-size:.86em; padding:3px 6px; }
                .pmk114-count { padding:1px 7px; font-size:.8em; }
            }
            @media (prefers-reduced-motion:reduce) {
                .pmk114-card, .pmk114-card::after { animation:none !important; }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function restoreRuntime() {
        stopRootDiscovery();
        window.clearTimeout(mutationTimer);
        mutationTimer = 0;
        tableObservers.forEach(function (observer) { try { observer.disconnect(); } catch (_) {} });
        tableObservers.clear();
        apiFailureCache.clear();

        Array.from(movedNativeControls).forEach(function (checkbox) {
            try { restoreNativeControl(checkbox); } catch (_) {}
        });
        movedNativeControls.clear();

        enhancedCells.forEach(function (cell) {
            if (!cell || !cell.isConnected) return;
            safeQueryAll(cell, ".pmk114-card, .pmk114-checkbox-label").forEach(function (el) {
                if (el.getAttribute("data-pmk114-owned") === "1") el.remove();
            });
            safeQueryAll(cell, ".pmk114-hide-native").forEach(function (el) { el.classList.remove("pmk114-hide-native"); });
            safeQueryAll(cell, ".pmk114-native-checkbox").forEach(function (el) { el.classList.remove("pmk114-native-checkbox"); });
            safeQueryAll(cell, ".pmk114-native-control").forEach(function (el) { el.classList.remove("pmk114-native-control"); });
            clearHistoryClasses(cell);
            cell.classList.remove("pmk114-enhanced");
        });
        enhancedCells.clear();
        safeQueryAll(document, "[data-pmk114-config-anchor=\"1\"]").forEach(function (el) { el.removeAttribute("data-pmk114-config-anchor"); });
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        if (!Array.isArray(cfg.pages) || !cfg.pages.length) return { ok:false, message:local("Le module doit conserver au moins une page configurée.", "The module must keep at least one configured page.") };
        if (cfg.api.concurrency < 1 || cfg.api.concurrency > 8) return { ok:false, message:local("La concurrence API doit être comprise entre 1 et 8.", "API concurrency must be between 1 and 8.") };
        return { ok:true };
    }

    function buildModuleDefinition() {
        return {
            id:MODULE_ID,
            schemaVersion:3,
            name:{ fr:"Disponibilité et motifs de renouvellement", en:"Renewal enhancements" },
            description:{
                fr:"Module maître issu des 114 et 089 : améliore l'affichage des renouvellements sans remplacer les contrôles Koha, enrichit les états via l'API et présente l'historique R/N.",
                en:"Master module from legacy 114 and 089: improves renewal display without replacing Koha controls, enriches states through the API and presents R/N history."
            },
            category:{ fr:"Circulation & historique", en:"Circulation & history" },
            supportedPages:["circ.circulation","members.moremember","members.memberhistory","circ.returns"],
            prerequisites:[],
            dependencies:[],
            defaults:deepClone(DEFAULT_CONFIG),
            validate:validateConfig,
            schema:[
                {
                    type:"section", id:"activation", label:{fr:"Activation et pages",en:"Activation and pages"},
                    fields:[
                        {key:"enabled",type:"boolean",label:{fr:"Activer les améliorations de renouvellement",en:"Enable renewal enhancements"}},
                        {
                            key:"pages", type:"repeater", reorder:false, removable:false,
                            label:{fr:"Pages Koha",en:"Koha pages"},
                            itemTitle:function (item, index, language) { return language === "en" ? (item.labelEn || item.path) : (item.labelFr || item.path); },
                            fields:[
                                {key:"enabled",type:"boolean",label:{fr:"Activer sur cette page",en:"Enable on this page"}},
                                {key:"path",type:"text",readOnly:true,label:{fr:"Chemin",en:"Path"}},
                                {key:"mode",type:"select",label:{fr:"Fonction de la page",en:"Page role"},options:[
                                    {value:"active",label:{fr:"Prêts actifs",en:"Active checkouts"}},
                                    {value:"history",label:{fr:"Historique / état R-N",en:"History / R-N state"}},
                                    {value:"both",label:{fr:"Les deux",en:"Both"}}
                                ]}
                            ]
                        }
                    ]
                },
                {
                    type:"section", id:"active", label:{fr:"Prêts actifs",en:"Active checkouts"},
                    description:{fr:"Les contrôles natifs Koha sont toujours conservés. Le module ajoute uniquement une présentation autour d'eux.",en:"Native Koha controls are always preserved. The module only adds presentation around them."},
                    fields:[
                        {key:"active.enabled",type:"boolean",label:{fr:"Améliorer les cellules de renouvellement",en:"Enhance renewal cells"}},
                        {key:"active.showStatus",type:"boolean",label:{fr:"Afficher l'état possible / impossible",en:"Show available / unavailable status"}},
                        {key:"active.showCounts",type:"boolean",label:{fr:"Afficher les compteurs de renouvellement",en:"Show renewal counters"}},
                        {key:"active.countFormat",type:"select",label:{fr:"Présentation du compteur",en:"Counter format"},options:[
                            {value:"remaining-total",label:{fr:"Restants / maximum — historique",en:"Remaining / maximum — historical"}},
                            {value:"used-total",label:{fr:"Utilisés / maximum",en:"Used / maximum"}}
                        ]},
                        {key:"active.showReason",type:"boolean",label:{fr:"Afficher le motif de blocage",en:"Show blocking reason"}},
                        {key:"active.showUnseenRenewals",type:"boolean",label:{fr:"Afficher les renouvellements non vus",en:"Show unseen renewals"}},
                        {key:"active.integrateCheckboxInCard",type:"boolean",label:{fr:"Intégrer la case Koha dans la carte de renouvellement",en:"Integrate the Koha checkbox into the renewal card"},help:{fr:"Déplace uniquement le contrôle natif existant : aucune case n'est recréée et l'action Koha reste inchangée.",en:"Moves only the existing native control: no checkbox is recreated and Koha's action remains unchanged."}},
                        {key:"active.showCheckboxLabel",type:"boolean",label:{fr:"Ajouter « Renouveler » si la case Koha n'a pas de libellé visible",en:"Add “Renew” when Koha checkbox has no visible label"}},
                        {key:"active.hideKnownNativeText",type:"boolean",label:{fr:"Masquer les textes Koha redondants déjà repris dans la carte",en:"Hide redundant Koha text already represented in the card"}},
                        {key:"active.statusSource",type:"select",advanced:true,label:{fr:"Source de l'état",en:"Status source"},options:[
                            {value:"api-preferred",label:{fr:"API Koha si disponible, sinon DOM — recommandé",en:"Koha API when available, otherwise DOM — recommended"}},
                            {value:"dom-only",label:{fr:"DOM Koha uniquement",en:"Koha DOM only"}}
                        ]}
                    ]
                },
                {
                    type:"section", id:"api", label:{fr:"API Koha — enrichissement",en:"Koha API — enrichment"},
                    description:{fr:"Lecture uniquement de allows_renewal. Aucun POST de renouvellement n'est effectué par ce module.",en:"Read-only use of allows_renewal. This module never sends renewal POST requests."},
                    fields:[
                        {key:"api.enabled",type:"boolean",label:{fr:"Enrichir avec l'API Koha",en:"Enrich with Koha API"}},
                        {key:"api.concurrency",type:"number",min:1,max:8,label:{fr:"Appels simultanés maximum",en:"Maximum concurrent calls"}},
                        {key:"api.timeoutMs",type:"number",min:1000,max:20000,advanced:true,label:{fr:"Délai maximal d'un appel (ms)",en:"Request timeout (ms)"}},
                        {key:"api.cacheMs",type:"number",min:0,max:3600000,advanced:true,label:{fr:"Durée du cache (ms)",en:"Cache duration (ms)"}},
                        {key:"api.endpointTemplate",type:"text",advanced:true,label:{fr:"Endpoint allows_renewal",en:"allows_renewal endpoint"}},
                        {key:"api.stopAfterForbidden",type:"boolean",advanced:true,label:{fr:"Après un 401/403, rester en mode DOM jusqu'au prochain chargement",en:"After 401/403, stay in DOM mode until next page load"}},
                        {key:"api.trustCheckboxValueWhenNamedIssue",type:"boolean",advanced:true,label:{fr:"Accepter la valeur d'une case Koha nommée issue comme checkout_id",en:"Accept a Koha checkbox named issue as checkout_id"}},
                        {key:"api.trustCheckboxValueWhenNamedRenew",type:"boolean",advanced:true,label:{fr:"Accepter la valeur d'une case nommée renew comme checkout_id",en:"Accept a checkbox named renew as checkout_id"}}
                    ]
                },
                {
                    type:"section", id:"history", label:{fr:"Historique — héritage du 089",en:"History — legacy 089"},
                    description:{fr:"Reprend sans action simulée la mise en évidence R / N / « renouvelé » du script 089.",en:"Preserves the R / N / “renewed” presentation from script 089 without its simulated action."},
                    fields:[
                        {key:"history.enabled",type:"boolean",label:{fr:"Mettre en évidence l'état de renouvellement dans l'historique",en:"Highlight renewal state in history"}},
                        {key:"history.useLegacyLabelClasses",type:"boolean",label:{fr:"Conserver les classes visuelles historiques label-success / label-default",en:"Keep historical label-success / label-default classes"}},
                        {key:"history.renewedPatterns",type:"textarea",advanced:true,label:{fr:"Motifs considérés comme renouvelé (séparés par ;)",en:"Patterns considered renewed (separated by ;)"}},
                        {key:"history.notRenewedPatterns",type:"textarea",advanced:true,label:{fr:"Motifs considérés comme non renouvelé",en:"Patterns considered not renewed"}},
                        {key:"history.renewedTooltipFr",type:"text",label:{fr:"Infobulle renouvelé — FR",en:"Renewed tooltip — FR"}},
                        {key:"history.renewedTooltipEn",type:"text",label:{fr:"Infobulle renouvelé — EN",en:"Renewed tooltip — EN"}},
                        {key:"history.notRenewedTooltipFr",type:"text",label:{fr:"Infobulle non renouvelé — FR",en:"Not renewed tooltip — FR"}},
                        {key:"history.notRenewedTooltipEn",type:"text",label:{fr:"Infobulle non renouvelé — EN",en:"Not renewed tooltip — EN"}}
                    ]
                },
                {
                    type:"section", id:"labels", label:{fr:"Textes et icônes",en:"Labels and icons"},
                    fields:[
                        {key:"icons.renewable",type:"text",label:{fr:"Icône renouvellement possible",en:"Renewable icon"}},
                        {key:"icons.impossible",type:"text",label:{fr:"Icône renouvellement impossible",en:"Unavailable icon"}},
                        {key:"icons.blocked",type:"text",label:{fr:"Icône renouvellement bloqué",en:"Blocked icon"}},
                        {key:"labels.renewableFr",type:"text",label:{fr:"Texte possible — FR",en:"Available text — FR"}},
                        {key:"labels.renewableEn",type:"text",label:{fr:"Texte possible — EN",en:"Available text — EN"}},
                        {key:"labels.impossibleFr",type:"text",label:{fr:"Texte impossible — FR",en:"Unavailable text — FR"}},
                        {key:"labels.impossibleEn",type:"text",label:{fr:"Texte impossible — EN",en:"Unavailable text — EN"}},
                        {key:"labels.blockedFr",type:"text",label:{fr:"Texte bloqué — FR",en:"Blocked text — FR"}},
                        {key:"labels.blockedEn",type:"text",label:{fr:"Texte bloqué — EN",en:"Blocked text — EN"}},
                        {key:"labels.renewedUnavailableFr",type:"text",label:{fr:"Texte après renouvellement — FR",en:"Post-renewal text — FR"},help:{fr:"Affiché lorsqu'au moins un renouvellement a réussi mais qu'un nouveau renouvellement n'est pas disponible.",en:"Shown when at least one renewal has succeeded but another renewal is not available."}},
                        {key:"labels.renewedUnavailableEn",type:"text",label:{fr:"Texte après renouvellement — EN",en:"Post-renewal text — EN"}},
                        {key:"labels.renewedQuotaFr",type:"text",label:{fr:"Texte quota atteint — FR",en:"Renewal limit text — FR"}},
                        {key:"labels.renewedQuotaEn",type:"text",label:{fr:"Texte quota atteint — EN",en:"Renewal limit text — EN"}},
                        {key:"labels.remainingFr",type:"text",advanced:true,label:{fr:"Format compteur restants — FR",en:"Remaining counter format — FR"}},
                        {key:"labels.remainingEn",type:"text",advanced:true,label:{fr:"Format compteur restants — EN",en:"Remaining counter format — EN"}}
                    ]
                },
                {
                    type:"section", id:"reasons", label:{fr:"Motifs de blocage reçus de Koha",en:"Blocking reasons received from Koha"},
                    description:{fr:"Chaque code technique renvoyé par Koha possède un libellé compréhensible. Si plusieurs restrictions s’appliquent, elles sont toutes affichées.",en:"Each technical code returned by Koha has a readable label. When several restrictions apply, all are displayed."},
                    fields:[
                        {
                            key:"reasonLabels",type:"repeater",label:{fr:"Libellés des motifs API/DOM",en:"API/DOM reason labels"},
                            fields:[
                                {key:"enabled",type:"boolean",label:{fr:"Actif",en:"Enabled"}},
                                {key:"code",type:"text",label:{fr:"Code",en:"Code"}},
                                {key:"fr",type:"text",label:{fr:"Libellé FR",en:"FR label"}},
                                {key:"en",type:"text",label:{fr:"Libellé EN",en:"EN label"}}
                            ]
                        }
                    ]
                },
                {
                    type:"section", id:"appearance", label:{fr:"Apparence",en:"Appearance"},
                    fields:[
                        {key:"appearance.compact",type:"boolean",label:{fr:"Mode compact",en:"Compact mode"}},
                        {key:"appearance.animation",type:"boolean",label:{fr:"Animation légère à l'apparition",en:"Light entrance animation"}},
                        {key:"appearance.minWidthPx",type:"number",min:100,max:600,label:{fr:"Largeur minimale carte (px)",en:"Card minimum width (px)"}},
                        {key:"appearance.mobileMinWidthPx",type:"number",min:80,max:400,label:{fr:"Largeur minimale mobile (px)",en:"Mobile minimum width (px)"}},
                        {key:"appearance.successText",type:"color",label:{fr:"Texte possible",en:"Available text"}},
                        {key:"appearance.successBg",type:"color",label:{fr:"Fond possible",en:"Available background"}},
                        {key:"appearance.dangerText",type:"color",label:{fr:"Texte impossible",en:"Unavailable text"}},
                        {key:"appearance.dangerBg",type:"color",label:{fr:"Fond impossible",en:"Unavailable background"}}
                    ]
                },
                {
                    type:"section", id:"advanced", label:{fr:"Ciblage et diagnostic",en:"Targeting and diagnostics"}, advanced:true,
                    fields:[
                        {key:"advanced.renewalHeaderWords",type:"text",advanced:true,label:{fr:"Mots reconnus dans l'en-tête de colonne",en:"Words recognized in renewal header"}},
                        {key:"advanced.activeCellSelectors",type:"text",advanced:true,label:{fr:"Sélecteurs cellules prêts actifs",en:"Active checkout cell selectors"}},
                        {key:"advanced.historyCellSelectors",type:"text",advanced:true,label:{fr:"Sélecteurs cellules historique",en:"History cell selectors"}},
                        {key:"advanced.mainRootSelectors",type:"text",advanced:true,label:{fr:"Zones dans lesquelles rechercher les tableaux",en:"Roots in which tables are searched"}},
                        {key:"advanced.mutationDebounceMs",type:"number",min:20,max:2000,advanced:true,label:{fr:"Délai après redessin tableau (ms)",en:"Delay after table redraw (ms)"}},
                        {key:"advanced.tableDiscoveryMs",type:"number",min:1000,max:60000,advanced:true,label:{fr:"Durée de surveillance d'apparition des tableaux (ms)",en:"Table discovery watch duration (ms)"}},
                        {key:"advanced.diagnostics",type:"boolean",advanced:true,label:{fr:"Diagnostic console",en:"Console diagnostics"}}
                    ]
                }
            ],
            focusContext:function (main, context) {
                if (!main) return;
                const wanted = context && context.sectionId ? context.sectionId : "activation";
                const section = main.querySelector('[data-pmk-section-id="' + wanted + '"]') || main.querySelector('[data-pmk-section-id="activation"]');
                if (section) window.setTimeout(function () { section.scrollIntoView({ block:"start", behavior:"smooth" }); }, 0);
            }
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(buildModuleDefinition()); } catch (error) { debug("registerModule failed", error); return false; }
        if (typeof window.PMKConfig.subscribe === "function" && !unsubscribeConfig) {
            try {
                unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (cfg) { applyConfig(cfg); });
            } catch (_) {}
        }
        return true;
    }

    function loadConfig() {
        registerModule();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return Promise.resolve(deepClone(DEFAULT_CONFIG));
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(normalizeConfig)
            .catch(function () { return deepClone(DEFAULT_CONFIG); });
    }

    function applyConfig(config) {
        restoreRuntime();
        currentConfig = normalizeConfig(config);
        addStyles();
        apiForbidden = false;
        apiQueue.splice(0, apiQueue.length);
        if (!currentConfig.enabled || !currentPage()) return false;
        window.setTimeout(function () {
            scan();
            startRootDiscovery();
        }, currentConfig.advanced.initialScanDelayMs);
        return true;
    }

    function start() {
        if (registerModule()) {
            loadConfig().then(applyConfig);
            return;
        }

        applyConfig(DEFAULT_CONFIG);
        const ready = function () {
            window.removeEventListener("pmk:config-ready", ready);
            loadConfig().then(applyConfig);
        };
        window.addEventListener("pmk:config-ready", ready, { once:true });
        window.setTimeout(function () {
            if (window.PMKConfig) loadConfig().then(applyConfig);
        }, 6000);
    }

    window.PMK114RenewalEnhancements = {
        moduleId:MODULE_ID,
        version:MODULE_VERSION,
        defaults:deepClone(DEFAULT_CONFIG),
        refresh:function () { return loadConfig().then(applyConfig); },
        scan:scan,
        parseCounts:parseCounts,
        domReasons:domReasons,
        extractCheckoutId:extractCheckoutId,
        clearApiCache:function () { apiCache.clear(); apiForbidden = false; },
        destroy:restoreRuntime
    };

    // Compatibilité historique : l'ancien 114 exposait cette fonction.
    window.refreshRenewalDisplay = scan;

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once:true });
    } else {
        start();
    }
})(window, document);

;window.PMKNonPlugin.loaded.push("114-renew-modif.js");
} catch (error) { window.PMKNonPlugin.errors.push("114-renew-modif.js: "+error.message); console.error("[PMK] 114-renew-modif.js",error); };
try {
/*
 * 116-chrono-messages.js
 * PimpMyKoha — Chronologie des messages lecteur
 * Version : 2.0.0-preplugin
 * Date : 2026-09-20
 *
 * Fonction historique conservée :
 * - circulation.pl et moremember.pl uniquement ;
 * - cible historique : #messages.circmessage ul ;
 * - affichage initial par défaut : plus ancien -> plus récent.
 *
 * Configuration PMK volontairement minimale :
 * - activer / désactiver ;
 * - ordre : plus ancien -> plus récent / plus récent -> plus ancien.
 *
 * Le module ne modifie jamais le contenu des messages. Il déplace uniquement
 * les noeuds <li> existants et sait restaurer l'ordre Koha capturé au chargement.
 */
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK116PatronMessageChronologyV2) return;
    window.__PMK116PatronMessageChronologyV2 = true;

    const MODULE_ID = "patron-message-chronology";
    const MODULE_VERSION = "2.0.0-preplugin";

    const SUPPORTED_PATHS = new Set([
        "/cgi-bin/koha/circ/circulation.pl",
        "/cgi-bin/koha/members/moremember.pl"
    ]);

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        order: "oldest-first"
    });

    const originalOrders = new Map();
    const contextAnchors = new Set();
    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribeConfig = null;
    let observer = null, refreshTimer = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function normalizeConfig(raw) {
        const source = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: source.enabled !== false,
            order: source.order === "newest-first" ? "newest-first" : "oldest-first"
        };
    }

    function isSupportedPage() {
        return SUPPORTED_PATHS.has(window.location.pathname);
    }

    function findMessageLists() {
        if (!isSupportedPage()) return [];

        /*
         * Le premier sélecteur est exactement celui du 116 historique.
         * Le second couvre le conteneur Koha utilisé sur certaines variantes
         * de fiche lecteur, sans élargir la recherche à toutes les listes
         * .circmessage (qui peuvent aussi contenir des alertes sans rapport).
         */
        const selectors = [
            "#messages.circmessage ul",
            "#patron_messages ul"
        ];

        const lists = [];
        const seen = new Set();
        selectors.forEach(function (selector) {
            document.querySelectorAll(selector).forEach(function (list) {
                if (!seen.has(list)) {
                    seen.add(list);
                    lists.push(list);
                }
            });
        });
        return lists;
    }

    function directMessages(list) {
        if (!list) return [];
        return Array.from(list.children).filter(function (node) {
            return node && node.tagName === "LI";
        });
    }

    function rememberNativeOrder(list) {
        if (!list || originalOrders.has(list)) return;
        originalOrders.set(list, directMessages(list));
    }

    function currentNativeSequence(list) {
        rememberNativeOrder(list);

        const native = (originalOrders.get(list) || []).filter(function (node) {
            return node && node.isConnected && node.parentElement === list;
        });

        /*
         * Si Koha ou un autre module ajoute un message après la capture initiale,
         * on le conserve aussi, dans son ordre DOM actuel, sans jamais le perdre.
         */
        const known = new Set(native);
        directMessages(list).forEach(function (node) {
            if (!known.has(node)) {
                native.push(node);
                known.add(node);
            }
        });

        originalOrders.set(list, native.slice());
        return native;
    }

    function placeInOrder(list, nodes) {
        if (!list || !nodes.length) return;
        const current=directMessages(list);
        if(current.length===nodes.length && current.every((node,index)=>node===nodes[index]))return;
        const fragment = document.createDocumentFragment();
        nodes.forEach(function (node) {
            if (node && node.parentElement === list) fragment.appendChild(node);
        });
        list.appendChild(fragment);
    }

    function restoreList(list) {
        if (!list || !originalOrders.has(list)) return;
        placeInOrder(list, currentNativeSequence(list));
        list.removeAttribute("data-pmk116-order");
    }

    function restoreAll() {
        originalOrders.forEach(function (_nodes, list) {
            if (list && list.isConnected) restoreList(list);
        });
    }

    function applyOrderToList(list, order) {
        if (!list) return;
        const native = currentNativeSequence(list);
        const wanted = order === "oldest-first" ? native.slice().reverse() : native.slice();
        // Seules les dates identifiées par Koha servent au tri. Une date écrite
        // dans le corps d'un message peut être une instruction à l'agent.
        const dated=wanted.map((node,index)=>{
            const source=node.querySelector('time[datetime], [data-order], .date');
            const raw=source && (source.getAttribute('datetime') || source.getAttribute('data-order') || source.textContent);
            const date=raw && window.PMKDates?.parse(raw);
            return {node,index,date};
        }).filter(row=>row.date);
        const sorted=dated.slice().sort((a,b)=>(a.date-b.date)*(order==='oldest-first'?1:-1)||a.index-b.index);
        dated.forEach((row,index)=>{wanted[row.index]=sorted[index].node;});
        placeInOrder(list, wanted);
        list.setAttribute("data-pmk116-order", order);
        mountContextAccess(list);
    }

    function mountContextAccess(list) {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = list.closest("#messages.circmessage, #patron_messages, .circmessage") || list.parentElement;
        if (!anchor || contextAnchors.has(anchor)) return;
        contextAnchors.add(anchor);
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "append",
                contextKey: "pmk116-messages",
                context: { sectionId: "settings" }
            });
        } catch (_) {}
    }

    function validateConfig(config) {
        const cfg = normalizeConfig(config);
        if (!["oldest-first", "newest-first"].includes(cfg.order)) {
            return {
                ok: false,
                message: "L'ordre des messages est invalide."
            };
        }
        return { ok: true };
    }

    function buildModuleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: {
                fr: "Chronologie des messages lecteur",
                en: "Patron message chronology"
            },
            description: {
                fr: "Classe les messages lecteur et suit les ajouts de Koha. Les dates identifiées servent au tri ; sans date exploitable, l’ordre Koha historique est conservé ou inversé selon votre choix. À date identique, l’ordre reste stable.",
                en: "Orders patron messages and follows Koha additions. Structured dates are used when available; otherwise historical Koha order is kept or reversed. Equal dates retain a stable order."
            },
            category: {
                fr: "Lecteurs / communication",
                en: "Patrons / communication"
            },
            supportedPages: ["circ.circulation", "members.moremember"],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "settings",
                    label: { fr: "Réglages", en: "Settings" },
                    fields: [
                        {
                            key: "enabled",
                            type: "boolean",
                            label: {
                                fr: "Activer le classement des messages lecteur",
                                en: "Enable patron message ordering"
                            }
                        },
                        {
                            key: "order",
                            type: "select",
                            label: {
                                fr: "Ordre d'affichage",
                                en: "Display order"
                            },
                            options: [
                                {
                                    value: "oldest-first",
                                    label: {
                                        fr: "Plus ancien → plus récent — ordre initial",
                                        en: "Oldest → newest — original default"
                                    }
                                },
                                {
                                    value: "newest-first",
                                    label: {
                                        fr: "Plus récent → plus ancien — ordre Koha historique",
                                        en: "Newest → oldest — historical Koha order"
                                    }
                                }
                            ]
                        }
                    ]
                }
            ],
            focusContext: function (main) {
                if (!main) return;
                const section = main.querySelector('[data-pmk-section-id="settings"]');
                if (section) {
                    window.setTimeout(function () {
                        section.scrollIntoView({ block: "start", behavior: "smooth" });
                    }, 0);
                }
            }
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try {
            window.PMKConfig.registerModule(buildModuleDefinition());
        } catch (_) {
            return false;
        }

        if (typeof window.PMKConfig.subscribe === "function" && !unsubscribeConfig) {
            try {
                unsubscribeConfig = window.PMKConfig.subscribe(MODULE_ID, function (config) {
                    applyConfig(config);
                });
            } catch (_) {}
        }
        return true;
    }

    function loadConfig() {
        registerModule();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") {
            return Promise.resolve(clone(DEFAULT_CONFIG));
        }
        return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
            .then(normalizeConfig)
            .catch(function () {
                return clone(DEFAULT_CONFIG);
            });
    }

    function applyConfig(config) {
        observer?.disconnect();
        currentConfig = normalizeConfig(config);
        restoreAll();

        if (!isSupportedPage() || currentConfig.enabled === false) return false;

        const lists = findMessageLists();
        lists.forEach(function (list) {
            rememberNativeOrder(list);
            applyOrderToList(list, currentConfig.order);
        });
        if(!observer)observer=new MutationObserver(records=>{
            if(!records.some(record=>(record.target.nodeType===1?record.target:record.target.parentElement)?.closest?.('#messages.circmessage, #patron_messages') || [...record.addedNodes].some(node=>node.nodeType===1&&(node.matches?.('#messages.circmessage, #patron_messages')||node.querySelector?.('#messages.circmessage, #patron_messages')))))return;
            clearTimeout(refreshTimer);refreshTimer=setTimeout(()=>applyConfig(currentConfig),80);
        });
        for(const list of originalOrders.keys())if(!list.isConnected)originalOrders.delete(list);
        observer.observe(document.body,{childList:true,subtree:true,characterData:true});
        return lists.length > 0;
    }

    function start() {
        if (registerModule()) {
            loadConfig().then(applyConfig);
            return;
        }

        /* Sans PMK, on conserve exactement le comportement historique. */
        applyConfig(DEFAULT_CONFIG);

        const onReady = function () {
            window.removeEventListener("pmk:config-ready", onReady);
            loadConfig().then(applyConfig);
        };
        window.addEventListener("pmk:config-ready", onReady, { once: true });

        window.setTimeout(function () {
            if (window.PMKConfig) loadConfig().then(applyConfig);
        }, 6000);
    }

    window.PMK116PatronMessageChronology = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        refresh: function () {
            return loadConfig().then(applyConfig);
        },
        restore: function () { observer?.disconnect();clearTimeout(refreshTimer);restoreAll(); }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    } else {
        start();
    }
})(window, document);

;window.PMKNonPlugin.loaded.push("116-chrono-messages.js");
} catch (error) { window.PMKNonPlugin.errors.push("116-chrono-messages.js: "+error.message); console.error("[PMK] 116-chrono-messages.js",error); };
try {
/*
 Nom du fichier : 117-icons-menus.js
 Module PMK : menu-icons
 Version : 3.2.0-preplugin
 Date : 2026-09-21

 Evolution PMK du script historique 117-icons-menus.js.

 OBJECTIFS :
 - conserver strictement le rendu historique par défaut sur .sidebar_menu ;
 - rendre éditables les correspondances historiques libellé -> icône ;
 - permettre des règles personnalisées illimitées sur n'importe quel menu ou sous-menu Koha ;
 - permettre de cibler un élément par picker, sélecteur CSS ou texte ;
 - permettre de remplacer, ajouter ou masquer une icône ;
 - supporter Font Awesome et une image personnalisée ;
 - bibliothèque visuelle Font Awesome avec recherche et aperçu ;
 - conserver activation/désactivation à chaud et restauration propre du DOM ;
 - aucune dépendance CDN ajoutée.
*/
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK117MenuIconsV3) return;
    window.__PMK117MenuIconsV3 = true;

    const MODULE_ID = "menu-icons";
    const MODULE_VERSION = "3.2.0-preplugin";
    const PICKER_STYLE_ID = "pmk117-picker-style";
    const PENDING_PICK_KEY = "PimpMyKoha.117.pendingPick.v1";
    const CUSTOM_ICON_ATTR = "data-pmk117-owned";
    const HOST_ATTR = "data-pmk117-host";

    const LEGACY_ICON_MAP = Object.freeze({
                // --- Accueil et Liens Généraux ---
                "Accueil Outils": "fas fa-home",
                "Page d'accueil Acquisitions": "fas fa-shopping-cart",
    
                // --- Menu Adhérents & Fiche Utilisateur ---
                "Prêter": "fas fa-book",
                "Prêt par lot": "fas fa-layer-group",
                "Détails": "fas fa-info-circle",
                "Comptabilité": "fas fa-dollar-sign",
                "Historique de prêts": "fas fa-history",
                "Historique des réservations": "fas fa-clock",
                "Log des modifications": "fas fa-edit",
                "Notifications": "fas fa-bell",
                "Statistiques": "fas fa-chart-bar",
                "Fichiers": "fas fa-folder",
                "Suggestions d'achat": "fas fa-lightbulb",
                "Suggestions": "fas fa-lightbulb",
                "Listes d'adhérents": "fas fa-users-cog",
                "Clubs d'adhérents": "fas fa-puzzle-piece",
                "Commentaires": "fas fa-comments",
                "Importer des adhérents": "fas fa-user-plus",
                "Notifications et tickets": "fas fa-envelope-open-text",
                "Paramétrage des relances": "fas fa-exclamation-circle",
                "Créateur de cartes d'adhérent": "fas fa-id-badge",
                "Suppression et anonymisation des adhérents par lot": "fas fa-user-slash",
                "Modification d'adhérents par lot": "fas fa-user-edit",
                "Catégories d'adhérents": "fas fa-address-card",
                "Types d'attributs d'adhérent": "fas fa-id-card",
                "Types de suspension d'adhérent": "fas fa-ban",
    
                // --- Circulation & Libre service ---
                "Circulation en libre accès (SIP2)": "fas fa-exchange-alt",
                "Rendre": "fas fa-arrow-left",
                "Renouveler": "fas fa-redo",
                "Choisir un site": "fas fa-map-marker-alt",
                "Catalogage rapide": "fas fa-bolt",
                "Modification des dates de retour par lot": "fas fa-calendar-minus",
                "Modifier en lot des réservations": "fas fa-calendar-alt",
                "Collections tournantes": "fas fa-sync",
                "Règles de circulation et de pénalités": "fas fa-gavel",
                "Limites de transfert réseau": "fas fa-exchange-alt",
                "Matrice des coûts de transport": "fas fa-money-bill-alt",
                "Alertes de circulation": "fas fa-bell",
                "Collecte sur rendez-vous": "fas fa-calendar-check",
    
                // --- Réservations ---
                "File de réservations": "fas fa-list-ol",
                "Réservations à traiter": "fas fa-bookmark",
                "Réservations mises de coté": "fas fa-archive",
                "Ratios de réservation": "fas fa-percentage",
    
                // --- Transferts ---
                "Transférer": "fas fa-random",
                "Transferts à envoyer": "fas fa-paper-plane",
                "Transferts à recevoir": "fas fa-download",
    
                // --- Retards ---
                "Retards avec amendes": "fas fa-exclamation-triangle",
                "Retards": "fas fa-clock",
    
                // --- Périodiques ---
                "Réclamations": "fas fa-exclamation-circle",
                "Vérifier l'expiration": "fas fa-calendar-times",
                "Gestion des périodicités": "fas fa-hourglass-half",
                "Gestion des modèles de numérotation": "fas fa-list-ol",
                "Rechercher dans Mana-KB": "fas fa-search-plus",
                "Gestion des champs des abonnements": "fas fa-sliders-h",
                "Assistant statistiques sur les périodiques": "fas fa-chart-line",
    
                // --- Acquisitions ---
                "Commandes en retard": "fas fa-hourglass-start",
                "Factures": "fas fa-file-invoice-dollar",
                "Messages EDIFACT": "fas fa-exchange-alt",
                "Assistant statistiques Acquisitions": "fas fa-chart-bar",
                "Commandes par poste budgétaire": "fas fa-chart-pie",
                "Monnaies": "fas fa-coins",
                "Gérer les champs des factures": "fas fa-file-invoice",
                "Gérer les champs des paniers de commandes": "fas fa-shopping-basket",
                "Gérer les champs des lignes de commandes": "fas fa-list-ul",
    
                // --- Rapports Guidés ---
                "Rapports sauvegardés": "fas fa-save",
                "Voir dictionnaire": "fas fa-book",
                "Bibliothèque de rapports Koha": "fas fa-code-branch",
                "Schéma de la base de données Koha": "fas fa-database",
    
                // --- Administration : Catalogue & Grilles MARC ---
                "Grille des notices bibliographiques MARC": "fas fa-th-list",
                "Test de grille de catalogage bibliagement MARC": "fas fa-vial",
                "Grilles des notices d'autorité": "fas fa-user-shield",
                "Liens Koha => MARC": "fas fa-link",
                "Configuration de la classification": "fas fa-folder-tree",
                "Règles de concordance": "fas fa-compress-arrows-alt",
                "Sources de notices": "fas fa-search-plus",
                "Règles de fusion de notices": "fas fa-clone",
                "Configuration des Sets OAI": "fas fa-cubes",
                "Champs de recherche des exemplaires": "fas fa-search",
                "Configuration du moteur de recherche (Elasticsearch)": "fas fa-search",
                "Normal": "fas fa-book",
                "MARC": "fas fa-database",
                "Marc avec étiquettes": "fas fa-tags",
                "Exemplaires": "fas fa-copy",
                "Rotation des stocks": "fas fa-sync-alt",
                "Rotation": "fas fa-sync-alt",
                "Modifications d'exemplaires par ancienneté": "fas fa-history",
                
                // Imports / Exports catalogue
                "Import des notices dans le réservoir": "fas fa-upload",
                "Gérer les notices importées dans le réservoir": "fas fa-tasks",
                "Télécharger des notices dans le réservoir": "fas fa-upload",
                "Gestion des notices téléchargées": "fas fa-tasks",
                "Exporter les données du catalogue": "fas fa-download",
                
                // Modifications par lot catalogue
                "Modification d'exemplaires par lots": "fas fa-edit",
                "Suppression d'exemplaires par lots": "fas fa-trash",
                "Modification de notices par lot": "fas fa-edit",
                "Suppression de notices en lot": "fas fa-trash",
                "Suppression de notices par lot": "fas fa-trash",
                "Modèles de transformation MARC": "fas fa-sliders-h",
                "Mots-clés": "fas fa-tags",
    
                // Rapports globaux
                "Inventaire/Récolement": "fas fa-clipboard-list",
                "Inventaire": "fas fa-clipboard-list",
                "Récolement": "fas fa-clipboard-list",
                "Problèmes de catalogage": "fas fa-exclamation-circle",
    
                // --- Administration : Paramètres de Base & Comptabilité ---
                "Préférences système": "fas fa-cog",
                "Préférences": "fas fa-cog",
                "Bibliothèques": "fas fa-building",
                "Groupes de bibliothèques": "fas fa-warehouse",
                "Types de document": "fas fa-file-alt",
                "Valeurs autorisées": "fas fa-check-square",
                "Types de débit": "fas fa-money-check-alt",
                "Types de crédit": "fas fa-credit-card",
                "Villes et communes": "fas fa-map-marker-alt",
    
                // --- Administration : Paramètres Acquisitions ---
                "Devises et taux de change": "fas fa-money-bill-wave",
                "Budgets": "fas fa-wallet",
                "Postes budgétaires": "fas fa-chart-pie",
                "Comptes EDI": "fas fa-laptop-code",
                "EAN des bibliothèques": "fas fa-barcode",
    
                // --- Administration : Paramètres divers ---
                "Fournisseurs d'identité": "fas fa-id-card-alt",
                "Serveurs Z39.50/SRU": "fas fa-server",
                "Entrepôts OAI": "fas fa-archive",
                "Serveurs SMTP": "fas fa-server",
                "Transferts de fichiers": "fas fa-file-export",
                "Voulez-vous dire ?": "fas fa-question-circle",
                "Configurer les colonnes": "fas fa-columns",
                "Alertes sonores": "fas fa-volume-up",
                "Partager vos statistiques d'utilisation": "fas fa-chart-line",
                "Partager du contenu avec Mana KB": "fas fa-cloud-upload-alt",
                "Champs supplémentaires": "fas fa-plus-square",
                "Raccourcis clavier": "fas fa-keyboard",
    
                // --- Outils & Plugins & Tâches ---
                "Créateur d'étiquettes rapide": "fas fa-tags",
                "Créateur d'étiquettes": "fas fa-tag",
                "Générateur d'images de codes à barres": "fas fa-barcode",
                "Téléverser une image de couverture locale": "fas fa-image",
                "Calendrier": "fas fa-calendar-alt",
                "profils CSV": "fas fa-file-csv",
                "Visualiseur des logs": "fas fa-history",
                "Annonces": "fas fa-bullhorn",
                "Personnalisations HTML": "fas fa-code",
                "Pages": "fas fa-file-code",
                "Éditeur de citations": "fas fa-quote-left",
                "Outil de Plugins": "fas fa-plug",
                "Plugins": "fas fa-plug",
                "Téléchargements": "fas fa-download",
                "Accès aux fichiers": "fas fa-folder-open",
                "Tâches": "fas fa-tasks",
                "Acquisitions": "fas fa-shopping-cart",
                "Administration": "fas fa-cog",
                "Configuration": "fas fa-cogs",
                "Contrôle des autorités": "fas fa-user-shield",
                "Autorités": "fa fa-fw fa-link",
                "Catalogage": "fas fa-book-open",
                "Circulation": "fas fa-exchange-alt",
                "Contenu enrichi": "fas fa-star",
                "Gestion des ressources électroniques": "fas fa-file-alt",
                "Internationalisation": "fas fa-globe",
                "Prêt entre bibliothèques": "fas fa-external-link-alt",
                "Usage local": "fas fa-home",
                "Logs": "fas fa-file-archive",
                "Catalogue Public en Ligne (OPAC)": "fas fa-book-reader",
                "Adhérents": "fas fa-users",
                "Conservation": "fas fa-shield-alt",
                "Recherche": "fas fa-search",
                "Périodiques": "fas fa-newspaper",
                "Interface professionnelle": "fas fa-desktop",
                "Outils": "fas fa-tools",
                "Services web": "fas fa-plug",
    
                // --- Icône par défaut ---
                "default": "fas fa-thumbtack"
            });


    function deepClone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function buildLegacyRules(iconMap) {
        return Object.keys(iconMap || {})
            .filter(function (key) { return key !== "default"; })
            .map(function (text, index) {
                return {
                    id: "legacy-" + String(index + 1),
                    enabled: true,
                    text: text,
                    iconClass: String(iconMap[text] || "")
                };
            });
    }

    const DEFAULT_CONFIG = {
        enabled: true,
        observeDom: true,
        observeDelayMs: 100,
        legacy: {
            enabled: true,
            overrideExistingIcons: false,
            defaultIconClass: String(LEGACY_ICON_MAP.default || "fas fa-thumbtack"),
            rules: buildLegacyRules(LEGACY_ICON_MAP)
        },
        customRules: []
    };

    let currentConfig = deepClone(DEFAULT_CONFIG);
    let registered = false;
    let unsubscribe = null;
    let observer = null;
    let observerTimer = 0;
    let runtimeRecords = [];

    function cleanText(value) {
        return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    }

    function iconLabelFromClass(iconClass) {
        const token = String(iconClass || "").split(/\s+/).filter(function (part) { return /^fa-/.test(part); }).pop() || "fa-circle";
        return token.replace(/^fa-/, "").replace(/-/g, " ");
    }

    function buildFontAwesomeLibrary() {
        const seen = new Set();
        const items = [];
        Object.keys(LEGACY_ICON_MAP || {}).forEach(function (key) {
            const cls = cleanText(LEGACY_ICON_MAP[key]);
            if (!cls || seen.has(cls)) return;
            seen.add(cls);
            items.push({
                className: cls,
                label: key === "default" ? "Punaise / défaut" : key,
                search: (key + " " + iconLabelFromClass(cls) + " " + cls).toLowerCase()
            });
        });
        items.sort(function (a, b) {
            return a.label.localeCompare(b.label, "fr", { sensitivity: "base" });
        });
        return items;
    }

    const FONT_AWESOME_LIBRARY = buildFontAwesomeLibrary();

    function openFontAwesomeLibrary(options) {
        options = options || {};
        const lang = options.language === "en" ? "en" : "fr";
        const current = cleanText(options.current || "");
        return new Promise(function (resolve, reject) {
            const previous = document.getElementById("pmk117-icon-library");
            if (previous) previous.remove();

            const overlay = document.createElement("div");
            overlay.id = "pmk117-icon-library";
            overlay.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.38);display:flex;align-items:center;justify-content:center;padding:16px";

            const panel = document.createElement("div");
            panel.style.cssText = "width:min(880px,96vw);max-height:88vh;background:#fff;border-radius:8px;box-shadow:0 12px 40px rgba(0,0,0,.28);display:flex;flex-direction:column;overflow:hidden";
            overlay.appendChild(panel);

            const header = document.createElement("div");
            header.style.cssText = "display:flex;gap:10px;align-items:center;padding:12px 14px;border-bottom:1px solid #ddd";
            const title = document.createElement("strong");
            title.textContent = lang === "en" ? "Choose a Font Awesome icon" : "Choisir une icône Font Awesome";
            title.style.flex = "1";
            const close = document.createElement("button");
            close.type = "button";
            close.className = "btn btn-sm btn-outline-secondary";
            close.textContent = "×";
            header.append(title, close);
            panel.appendChild(header);

            const search = document.createElement("input");
            search.type = "search";
            search.className = "form-control form-control-sm";
            search.placeholder = lang === "en" ? "Search: book, user, calendar…" : "Rechercher : livre, utilisateur, calendrier…";
            search.style.cssText = "margin:12px 14px;width:calc(100% - 28px)";
            panel.appendChild(search);

            const count = document.createElement("div");
            count.style.cssText = "padding:0 14px 8px;color:#6c757d;font-size:12px";
            panel.appendChild(count);

            const grid = document.createElement("div");
            grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(125px,1fr));gap:8px;padding:0 14px 14px;overflow:auto";
            panel.appendChild(grid);

            function cleanup() {
                document.removeEventListener("keydown", onKey, true);
                if (overlay.isConnected) overlay.remove();
            }
            function cancel() {
                cleanup();
                reject(new Error("picker_cancelled"));
            }
            function choose(item) {
                cleanup();
                resolve(item.className);
            }
            function onKey(event) {
                if (event.key === "Escape") {
                    event.preventDefault();
                    cancel();
                }
            }
            function render() {
                const q = cleanText(search.value).toLowerCase();
                const filtered = FONT_AWESOME_LIBRARY.filter(function (item) {
                    return !q || item.search.indexOf(q) !== -1;
                });
                count.textContent = String(filtered.length) + (lang === "en" ? " icons" : " icônes");
                grid.innerHTML = "";
                filtered.forEach(function (item) {
                    const button = document.createElement("button");
                    button.type = "button";
                    button.className = "btn btn-light";
                    button.style.cssText = "min-height:74px;border:1px solid #ddd;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:7px;padding:8px;white-space:normal";
                    if (item.className === current) {
                        button.style.outline = "2px solid #0d6efd";
                        button.style.outlineOffset = "1px";
                    }
                    const icon = document.createElement("i");
                    icon.className = item.className;
                    icon.style.fontSize = "22px";
                    icon.setAttribute("aria-hidden", "true");
                    const label = document.createElement("span");
                    label.textContent = item.label;
                    label.style.cssText = "font-size:11px;line-height:1.15;text-align:center";
                    button.append(icon, label);
                    button.title = item.className;
                    button.addEventListener("click", function () { choose(item); });
                    grid.appendChild(button);
                });
            }

            close.addEventListener("click", cancel);
            overlay.addEventListener("click", function (event) { if (event.target === overlay) cancel(); });
            search.addEventListener("input", render);
            document.addEventListener("keydown", onKey, true);
            document.body.appendChild(overlay);
            render();
            window.setTimeout(function () { search.focus(); }, 0);
        });
    }

    function getLegacyRuleFromPath(root, path) {
        if (!root || !root.legacy || !Array.isArray(root.legacy.rules) || !Array.isArray(path)) return null;
        const pos = path.indexOf("rules");
        if (pos === -1) return null;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? root.legacy.rules[index] : null;
    }

    function renderFaPreview(iconClass, label) {
        const wrap = document.createElement("div");
        wrap.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 10px;border:1px solid #ddd;border-radius:6px;background:#f8f9fa";
        const icon = document.createElement("i");
        icon.className = cleanText(iconClass) || "fas fa-circle";
        icon.style.fontSize = "22px";
        icon.setAttribute("aria-hidden", "true");
        const text = document.createElement("span");
        text.textContent = label || cleanText(iconClass) || "—";
        wrap.append(icon, text);
        return wrap;
    }

    function renderLegacyDefaultPreview(context) {
        const root = context && context.rootObject;
        return renderFaPreview(root && root.legacy && root.legacy.defaultIconClass, cleanText(root && root.legacy && root.legacy.defaultIconClass));
    }

    function renderLegacyRulePreview(context) {
        const rule = getLegacyRuleFromPath(context && context.rootObject, context && context.fieldPath || []);
        return renderFaPreview(rule && rule.iconClass, rule && rule.text);
    }

    function renderCustomRulePreview(context) {
        const rule = getCustomRuleFromPath(context && context.rootObject, context && context.fieldPath || []);
        if (!rule) return renderFaPreview("fas fa-circle", "—");
        if (rule.iconType === "image") {
            const wrap = document.createElement("div");
            wrap.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 10px;border:1px solid #ddd;border-radius:6px;background:#f8f9fa";
            if (rule.imageUrl) {
                const img = document.createElement("img");
                img.src = rule.imageUrl;
                img.alt = "";
                img.style.cssText = "width:" + clampNumber(rule.sizePx,16,8,96) + "px;height:" + clampNumber(rule.sizePx,16,8,96) + "px;object-fit:contain";
                wrap.appendChild(img);
            }
            const text = document.createElement("span");
            text.textContent = rule.imageUrl || (context.language === "en" ? "No image URL" : "Aucune URL d’image");
            wrap.appendChild(text);
            return wrap;
        }
        if (rule.iconType === "none") {
            const node = document.createElement("div");
            node.textContent = context.language === "en" ? "No icon" : "Aucune icône";
            node.style.cssText = "padding:8px 10px;border:1px solid #ddd;border-radius:6px;background:#f8f9fa";
            return node;
        }
        const preview = renderFaPreview(rule.iconClass, rule.iconClass);
        const icon = preview.querySelector("i");
        if (icon) {
            icon.style.fontSize = clampNumber(rule.sizePx,16,8,96) + "px";
            if (rule.color) icon.style.color = rule.color;
        }
        return preview;
    }

    async function chooseLegacyDefaultIcon(context) {
        const root = context && context.rootObject;
        if (!root || !root.legacy) return { changed:false };
        const selected = await openFontAwesomeLibrary({ current:root.legacy.defaultIconClass, language:context.language });
        root.legacy.defaultIconClass = selected;
        return { changed:true, refresh:true };
    }

    async function chooseLegacyRuleIcon(context) {
        const rule = getLegacyRuleFromPath(context && context.rootObject, context && context.fieldPath || []);
        if (!rule) return { changed:false };
        const selected = await openFontAwesomeLibrary({ current:rule.iconClass, language:context.language });
        rule.iconClass = selected;
        return { changed:true, refresh:true };
    }

    async function chooseCustomRuleIcon(context) {
        const rule = getCustomRuleFromPath(context && context.rootObject, context && context.fieldPath || []);
        if (!rule) return { changed:false };
        const selected = await openFontAwesomeLibrary({ current:rule.iconClass, language:context.language });
        rule.iconType = "fa";
        rule.iconClass = selected;
        return { changed:true, refresh:true };
    }

    function clampNumber(value, fallback, min, max) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.max(min, Math.min(max, n));
    }

    function splitPages(value) {
        if (Array.isArray(value)) return value.map(cleanText).filter(Boolean);
        return String(value || "")
            .split(/[\n,;]+/)
            .map(cleanText)
            .filter(Boolean);
    }

    function normalizePath(value) {
        const raw = cleanText(value);
        if (!raw || raw === "*" || raw.toLowerCase() === "all") return raw;
        try {
            const url = new URL(raw, window.location.origin);
            return url.pathname;
        } catch (_) {
            return raw.charAt(0) === "/" ? raw : "/" + raw;
        }
    }

    function normalizeLegacyRules(rawRules, rawIconMap) {
        const base = buildLegacyRules(LEGACY_ICON_MAP);
        const mapByText = new Map(base.map(function (rule) { return [rule.text, rule]; }));

        if (rawIconMap && typeof rawIconMap === "object") {
            Object.keys(rawIconMap).forEach(function (key) {
                if (key === "default") return;
                if (mapByText.has(key)) {
                    mapByText.get(key).iconClass = cleanText(rawIconMap[key]) || mapByText.get(key).iconClass;
                }
            });
        }

        if (!Array.isArray(rawRules) || !rawRules.length) return base;

        const out = [];
        rawRules.forEach(function (rule, index) {
            if (!rule || typeof rule !== "object") return;
            const text = cleanText(rule.text || rule.label);
            if (!text) return;
            out.push(Object.assign({}, rule, {
                id: cleanText(rule.id) || ("legacy-custom-" + String(index + 1)),
                enabled: rule.enabled !== false,
                text: text,
                iconClass: cleanText(rule.iconClass || rule.className || (mapByText.get(text) && mapByText.get(text).iconClass))
            }));
        });

        return out.length ? out : base;
    }

    function normalizeCustomRule(rule, index) {
        rule = rule && typeof rule === "object" ? rule : {};
        const iconType = ["fa", "image", "none"].indexOf(rule.iconType) !== -1 ? rule.iconType : "fa";
        const targetMode = ["selector", "text"].indexOf(rule.targetMode) !== -1 ? rule.targetMode : "selector";
        const textMode = ["exact", "contains"].indexOf(rule.textMode) !== -1 ? rule.textMode : "exact";
        const position = rule.position === "append" ? "append" : "prepend";
        return Object.assign({}, rule, {
            id: cleanText(rule.id) || ("rule-" + String(index + 1)),
            enabled: rule.enabled !== false,
            name: cleanText(rule.name || rule.label),
            pages: cleanText(rule.pages || "*") || "*",
            targetMode: targetMode,
            selector: cleanText(rule.selector || rule.targetSelector),
            targetName: cleanText(rule.targetName),
            text: cleanText(rule.text || rule.matchText),
            textMode: textMode,
            menuSelector: cleanText(rule.menuSelector) ||
                'nav a, .sidebar_menu a, .navbar a, .dropdown-menu a, [role="menu"] a, [role="menuitem"]',
            iconType: iconType,
            iconClass: cleanText(rule.iconClass || "fas fa-circle"),
            imageUrl: cleanText(rule.imageUrl),
            sizePx: clampNumber(rule.sizePx, 16, 8, 96),
            color: cleanText(rule.color),
            position: position,
            replaceExisting: rule.replaceExisting !== false,
            priority: clampNumber(rule.priority, 100, 0, 1000)
        });
    }

    function normalizeConfig(raw) {
        raw = raw && typeof raw === "object" ? raw : {};
        const legacyRaw = raw.legacy && typeof raw.legacy === "object" ? raw.legacy : {};
        const legacyRules = normalizeLegacyRules(
            legacyRaw.rules || raw.legacyRules,
            raw.iconMap
        );
        const customRulesRaw = Array.isArray(raw.customRules)
            ? raw.customRules
            : (Array.isArray(raw.rules) ? raw.rules : []);

        return Object.assign({}, raw, {
            enabled: raw.enabled !== false,
            observeDom: raw.observeDom !== false,
            observeDelayMs: clampNumber(raw.observeDelayMs, 100, 30, 2000),
            legacy: Object.assign({}, legacyRaw, {
                enabled: legacyRaw.enabled !== false,
                overrideExistingIcons: legacyRaw.overrideExistingIcons === true,
                defaultIconClass: cleanText(
                    legacyRaw.defaultIconClass ||
                    (raw.iconMap && raw.iconMap.default) ||
                    LEGACY_ICON_MAP.default ||
                    "fas fa-thumbtack"
                ),
                rules: legacyRules
            }),
            customRules: customRulesRaw.map(normalizeCustomRule)
        });
    }

    function pageMatches(rule) {
        const pages = splitPages(rule && rule.pages);
        if (!pages.length) return true;
        const current = window.location.pathname;
        return pages.some(function (page) {
            const normalized = normalizePath(page);
            return normalized === "*" || normalized === "all" || normalized === current;
        });
    }

    function recordInserted(node) {
        runtimeRecords.push({ type: "inserted", node: node });
    }

    function recordMutation(node) {
        if (!node) return;
        runtimeRecords.push({
            type: "mutation",
            node: node,
            className: node.className && typeof node.className === "string" ? node.className : null,
            style: node.getAttribute ? node.getAttribute("style") : null,
            hidden: "hidden" in node ? Boolean(node.hidden) : null,
            ariaHidden: node.getAttribute ? node.getAttribute("aria-hidden") : null,
            owned: node.getAttribute ? node.getAttribute(CUSTOM_ICON_ATTR) : null,
            host: node.getAttribute ? node.getAttribute(HOST_ATTR) : null
        });
    }

    function restoreMutation(record) {
        const node = record && record.node;
        if (!node || !node.isConnected) return;
        if (record.className !== null) node.className = record.className;
        if (record.style === null) node.removeAttribute("style");
        else node.setAttribute("style", record.style);
        if (record.hidden !== null) node.hidden = record.hidden;
        if (record.ariaHidden === null) node.removeAttribute("aria-hidden");
        else node.setAttribute("aria-hidden", record.ariaHidden);
        if (record.owned === null) node.removeAttribute(CUSTOM_ICON_ATTR);
        else node.setAttribute(CUSTOM_ICON_ATTR, record.owned);
        if (record.host === null) node.removeAttribute(HOST_ATTR);
        else node.setAttribute(HOST_ATTR, record.host);
    }

    function restoreRuntime() {
        for (let i = runtimeRecords.length - 1; i >= 0; i -= 1) {
            const record = runtimeRecords[i];
            if (!record) continue;
            if (record.type === "inserted") {
                if (record.node && record.node.parentNode) record.node.parentNode.removeChild(record.node);
            } else if (record.type === "mutation") {
                restoreMutation(record);
            }
        }
        runtimeRecords = [];
    }

    function findLegacyMatch(linkText) {
        const rules = currentConfig.legacy.rules || [];
        for (let i = 0; i < rules.length; i += 1) {
            const rule = rules[i];
            if (!rule || rule.enabled === false) continue;
            const text = cleanText(rule.text);
            if (text && linkText.indexOf(text) !== -1) {
                return { found: true, iconClass: cleanText(rule.iconClass) };
            }
        }
        return {
            found: false,
            iconClass: cleanText(currentConfig.legacy.defaultIconClass) || "fas fa-thumbtack"
        };
    }

    function applyHistoricalBehavior() {
        if (!currentConfig.legacy.enabled) return 0;
        const sidebarMenus = document.querySelectorAll(".sidebar_menu");
        if (!sidebarMenus.length) return 0;

        let touched = 0;
        sidebarMenus.forEach(function (menu) {
            menu.querySelectorAll("ul li a").forEach(function (link) {
                const linkText = cleanText(link.textContent);
                let existingIcon = link.querySelector("i");
                const match = findLegacyMatch(linkText);
                const targetClass = match.found
                    ? (match.iconClass || currentConfig.legacy.defaultIconClass)
                    : currentConfig.legacy.defaultIconClass;

                if (existingIcon) {
                    const isHistoricalPin = existingIcon.classList.contains("fa-thumbtack");
                    if (!currentConfig.legacy.overrideExistingIcons && !isHistoricalPin) return;
                    if (!match.found && isHistoricalPin) return;
                    if (!targetClass || existingIcon.className === targetClass) return;
                    recordMutation(existingIcon);
                    existingIcon.className = targetClass;
                    existingIcon.setAttribute(CUSTOM_ICON_ATTR, "legacy");
                    touched += 1;
                    return;
                }

                if (!targetClass) return;
                const icon = document.createElement("i");
                icon.className = targetClass;
                icon.style.marginRight = "8px";
                icon.setAttribute(CUSTOM_ICON_ATTR, "legacy");
                link.prepend(icon);
                recordInserted(icon);
                touched += 1;
            });
        });
        return touched;
    }

    function cssEscape(value) {
        if (window.CSS && typeof window.CSS.escape === "function") return window.CSS.escape(value);
        return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return "\\" + c; });
    }

    function stableSelector(element) {
        if (!element || element.nodeType !== 1) return "";

        if (element.id) {
            try {
                const byId = "#" + cssEscape(element.id);
                if (document.querySelectorAll(byId).length === 1) return byId;
            } catch (_) {}
        }

        if (element.tagName === "A") {
            const href = element.getAttribute("href");
            if (href) {
                const escapedHref = String(href).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
                const exact = 'a[href="' + escapedHref + '"]';
                try {
                    if (document.querySelectorAll(exact).length === 1) return exact;
                } catch (_) {}
            }
        }

        const parts = [];
        let node = element;
        while (node && node !== document.body && parts.length < 7) {
            let part = node.tagName.toLowerCase();
            if (node.id) {
                part += "#" + cssEscape(node.id);
                parts.unshift(part);
                break;
            }
            const classes = Array.from(node.classList || []).filter(function (name) {
                return !/^pmk|^active$|^selected$|^hover$|^focus$|^show$|^open$/.test(name);
            });
            if (classes.length) part += "." + cssEscape(classes[0]);
            const parent = node.parentElement;
            if (parent && !classes.length) {
                const peers = Array.from(parent.children).filter(function (x) { return x.tagName === node.tagName; });
                if (peers.length > 1) part += ":nth-of-type(" + (peers.indexOf(node) + 1) + ")";
            }
            parts.unshift(part);
            node = parent;
        }
        return parts.join(" > ");
    }

    function resolveRuleTargets(rule) {
        if (!rule || rule.enabled === false || !pageMatches(rule)) return [];

        if (rule.targetMode === "text") {
            let candidates = [];
            try { candidates = Array.from(document.querySelectorAll(rule.menuSelector)); }
            catch (_) { return []; }
            const wanted = cleanText(rule.text);
            if (!wanted) return [];
            return candidates.filter(function (element) {
                const actual = cleanText(element.textContent);
                return rule.textMode === "contains" ? actual.indexOf(wanted) !== -1 : actual === wanted;
            });
        }

        if (!rule.selector) return [];
        try {
            return Array.from(document.querySelectorAll(rule.selector));
        } catch (_) {
            return [];
        }
    }

    function findExistingIcon(host) {
        if (!host || !host.querySelector) return null;
        return host.querySelector(
            'i[class*="fa-"], i.fa, i.fas, i.far, i.fab, span[class*="fa-"], svg.svg-inline--fa, [' + CUSTOM_ICON_ATTR + ']'
        );
    }

    function applyVisualStyles(node, rule) {
        if (!node || !node.style) return;
        const size = clampNumber(rule.sizePx, 16, 8, 96);
        if (rule.iconType === "image") {
            node.style.width = size + "px";
            node.style.height = size + "px";
            node.style.objectFit = "contain";
            node.style.verticalAlign = "middle";
        } else {
            node.style.fontSize = size + "px";
            if (rule.color) node.style.color = rule.color;
        }
        node.style.marginRight = rule.position === "prepend" ? "8px" : "0";
        node.style.marginLeft = rule.position === "append" ? "8px" : "0";
    }

    function insertIcon(host, rule) {
        let node = null;
        if (rule.iconType === "image") {
            if (!rule.imageUrl) return null;
            node = document.createElement("img");
            node.src = rule.imageUrl;
            node.alt = "";
            node.setAttribute("aria-hidden", "true");
        } else if (rule.iconType === "fa") {
            if (!rule.iconClass) return null;
            node = document.createElement("i");
            node.className = rule.iconClass;
            node.setAttribute("aria-hidden", "true");
        }
        if (!node) return null;

        node.setAttribute(CUSTOM_ICON_ATTR, "custom");
        applyVisualStyles(node, rule);

        if (rule.position === "append") host.appendChild(node);
        else host.insertBefore(node, host.firstChild);

        recordInserted(node);
        return node;
    }

    function hideExistingIcon(icon) {
        if (!icon) return;
        recordMutation(icon);
        icon.style.setProperty("display", "none", "important");
        icon.setAttribute("aria-hidden", "true");
    }

    function applyCustomRuleToHost(host, rule) {
        if (!host || host.nodeType !== 1) return 0;
        const existing = findExistingIcon(host);

        if (rule.iconType === "none") {
            if (existing) {
                hideExistingIcon(existing);
                return 1;
            }
            return 0;
        }

        if (existing && !rule.replaceExisting) return 0;

        if (rule.iconType === "fa" && existing && existing.tagName === "I") {
            recordMutation(existing);
            existing.className = rule.iconClass;
            existing.setAttribute(CUSTOM_ICON_ATTR, "custom");
            applyVisualStyles(existing, rule);
            return 1;
        }

        if (existing && rule.replaceExisting) hideExistingIcon(existing);
        return insertIcon(host, rule) ? 1 : 0;
    }

    function applyCustomRules() {
        let touched = 0;
        (currentConfig.customRules || []).map(function (rule, index) { return { rule:rule, index:index }; }).sort(function (a, b) {
            return a.rule.priority - b.rule.priority || a.index - b.index;
        }).forEach(function (entry) {
            const rule = entry.rule;
            resolveRuleTargets(rule).forEach(function (host) {
                touched += applyCustomRuleToHost(host, rule);
            });
        });
        return touched;
    }

    function renderConflictOverview(context) {
        const config = normalizeConfig(context && context.rootObject || DEFAULT_CONFIG);
        const host = document.createElement("div");
        const active = config.customRules.filter(function (rule) { return rule.enabled !== false && pageMatches(rule); });
        const groups = new Map();
        active.forEach(function (rule) {
            const key = rule.targetMode === "text" ? "texte:" + rule.menuSelector + ":" + rule.textMode + ":" + rule.text : "sélecteur:" + rule.selector;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(rule);
        });
        const conflicts = Array.from(groups.entries()).filter(function (entry) { return entry[1].length > 1; });
        const summary = document.createElement("p");
        summary.textContent = active.length + " règle(s) active(s) sur cette page · " + conflicts.length + " conflit(s) de cible.";
        host.appendChild(summary);
        if (!conflicts.length) {
            const ok = document.createElement("p"); ok.textContent = "Chaque cible ne reçoit qu’une personnalisation."; host.appendChild(ok); return host;
        }
        const list = document.createElement("ul");
        conflicts.forEach(function (entry) {
            const ordered = entry[1].map(function (rule, index) { return { rule:rule, index:index }; }).sort(function (a,b) { return a.rule.priority-b.rule.priority || a.index-b.index; });
            const winner = ordered[ordered.length - 1].rule;
            const li = document.createElement("li");
            li.textContent = entry[0] + " — priorité finale : « " + (winner.name || winner.id) + " » (" + winner.priority + ").";
            list.appendChild(li);
        });
        host.appendChild(list);
        return host;
    }

    function applyAll() {
        let touched = 0;
        touched += applyHistoricalBehavior();
        touched += applyCustomRules();
        return touched;
    }

    function stopObserver() {
        clearTimeout(observerTimer);
        observerTimer = 0;
        if (observer) observer.disconnect();
        observer = null;
    }

    function mutationIsOnlyOurs(mutation) {
        if (!mutation) return false;
        const added = Array.from(mutation.addedNodes || []);
        if (!added.length) return false;
        return added.every(function (node) {
            return node.nodeType === 1 && (
                node.hasAttribute && node.hasAttribute(CUSTOM_ICON_ATTR) ||
                node.querySelector && node.querySelector("[" + CUSTOM_ICON_ATTR + "]")
            );
        });
    }

    function startObserver() {
        if (observer || !document.body || !currentConfig.observeDom) return;
        observer = new MutationObserver(function (mutations) {
            if (mutations.length && mutations.every(mutationIsOnlyOurs)) return;
            clearTimeout(observerTimer);
            observerTimer = window.setTimeout(function () {
                stopObserver();
                restoreRuntime();
                applyAll();
                startObserver();
            }, currentConfig.observeDelayMs);
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function applyConfig(rawConfig) {
        stopObserver();
        restoreRuntime();
        currentConfig = normalizeConfig(rawConfig);
        if (!currentConfig.enabled) return 0;
        const touched = applyAll();
        startObserver();
        return touched;
    }

    function validateConfig(config) {
        if (!config || typeof config !== "object") {
            return { ok: false, message: "Configuration invalide." };
        }

        const normalized = normalizeConfig(config);
        for (let i = 0; i < normalized.customRules.length; i += 1) {
            const rule = normalized.customRules[i];
            if (!rule.enabled) continue;
            if (rule.targetMode === "selector" && !rule.selector) {
                return { ok: false, message: "Une règle active doit avoir un élément ciblé ou un sélecteur CSS." };
            }
            if (rule.targetMode === "text" && !rule.text) {
                return { ok: false, message: "Une règle active en mode texte doit préciser le libellé à rechercher." };
            }
            if (rule.iconType === "fa" && !rule.iconClass) {
                return { ok: false, message: "Une règle Font Awesome active doit préciser une classe d’icône." };
            }
            if (rule.iconType === "image" && !rule.imageUrl) {
                return { ok: false, message: "Une règle image active doit préciser l’adresse de l’image." };
            }
        }

        return { ok: true };
    }

    function getCustomRuleFromPath(root, path) {
        if (!root || !Array.isArray(path)) return null;
        const pos = path.indexOf("customRules");
        if (pos === -1) return null;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) && Array.isArray(root.customRules) ? root.customRules[index] : null;
    }

    function resolveCustomRuleIndexFromFieldPath(path) {
        if (!Array.isArray(path)) return -1;
        const pos = path.indexOf("customRules");
        if (pos === -1) return -1;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? index : -1;
    }

    function firstConcretePage(rule) {
        const pages = splitPages(rule && rule.pages);
        for (let i = 0; i < pages.length; i += 1) {
            const path = normalizePath(pages[i]);
            if (path && path !== "*" && path !== "all") return path;
        }
        return "";
    }

    function pickElementOnCurrentPage() {
        return new Promise(function (resolve, reject) {
            const overlay = document.getElementById("pmk-config-overlay");
            const previousDisplay = overlay ? overlay.style.display : "";
            if (overlay) overlay.style.display = "none";

            let style = document.getElementById(PICKER_STYLE_ID);
            if (!style) {
                style = document.createElement("style");
                style.id = PICKER_STYLE_ID;
                style.textContent = [
                    ".pmk117-picker-hover{outline:3px solid #2f7d32!important;outline-offset:2px!important;cursor:crosshair!important;}",
                    ".pmk117-picker-banner{position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#fff;border:1px solid #bbb;border-radius:4px;padding:8px 12px;box-shadow:0 2px 8px rgba(0,0,0,.25);font-size:14px;max-width:calc(100vw - 20px)}"
                ].join("");
                document.head.appendChild(style);
            }

            const banner = document.createElement("div");
            banner.className = "pmk117-picker-banner";
            banner.textContent = (document.documentElement.lang || "").toLowerCase().startsWith("en")
                ? "Click the menu or submenu to customize — Escape to cancel"
                : "Cliquez sur le menu ou sous-menu à personnaliser — Échap pour annuler";
            document.body.appendChild(banner);

            let hovered = null;

            function normalizeTarget(target) {
                if (!target || !target.closest) return target;
                return target.closest("a, button, [role='menuitem']") || target;
            }

            function cleanup() {
                if (hovered) hovered.classList.remove("pmk117-picker-hover");
                document.removeEventListener("mouseover", over, true);
                document.removeEventListener("mouseout", out, true);
                document.removeEventListener("click", click, true);
                document.removeEventListener("keydown", key, true);
                if (banner.isConnected) banner.remove();
                if (overlay) overlay.style.display = previousDisplay;
            }

            function over(event) {
                if (hovered) hovered.classList.remove("pmk117-picker-hover");
                const target = normalizeTarget(event.target);
                hovered = target && target.nodeType === 1 ? target : null;
                if (hovered && !hovered.closest(".pmk117-picker-banner")) hovered.classList.add("pmk117-picker-hover");
            }

            function out(event) {
                const target = normalizeTarget(event.target);
                if (target && target.classList) target.classList.remove("pmk117-picker-hover");
            }

            function click(event) {
                if (event.target && event.target.closest && event.target.closest(".pmk117-picker-banner")) return;
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();

                const element = normalizeTarget(event.target);
                const selector = stableSelector(element);
                const targetName = cleanText(element && element.textContent).slice(0, 160) ||
                    (element && element.tagName ? element.tagName.toLowerCase() : "menu");

                cleanup();
                if (!selector) return reject(new Error("selector_unavailable"));

                resolve({
                    value: selector,
                    selector: selector,
                    targetName: targetName,
                    tag: element && element.tagName ? element.tagName.toLowerCase() : "",
                    href: element && element.getAttribute ? (element.getAttribute("href") || "") : ""
                });
            }

            function key(event) {
                if (event.key !== "Escape") return;
                event.preventDefault();
                cleanup();
                reject(new Error("picker_cancelled"));
            }

            document.addEventListener("mouseover", over, true);
            document.addEventListener("mouseout", out, true);
            document.addEventListener("click", click, true);
            document.addEventListener("keydown", key, true);
        });
    }

    function pickForConfig(context) {
        const rule = getCustomRuleFromPath(context.rootObject, context.fieldPath);
        return window.PMKConfig.elementPicker.pickForConfig({moduleId:MODULE_ID,rootObject:context.rootObject,
            fieldPath:context.fieldPath,targetUrl:firstConcretePage(rule) || location.pathname,persistAfterPick:false});
    }

    function resumePendingPick() {
        try {
            const pending=JSON.parse(sessionStorage.getItem(PENDING_PICK_KEY) || 'null');
            if (!pending || pending.moduleId !== MODULE_ID) return;
            sessionStorage.setItem('pmk-common-element-picker-v1',JSON.stringify({moduleId:MODULE_ID,targetUrl:pending.page,
                fieldPath:['customRules',Number(pending.ruleIndex),'selector'],draft:normalizeConfig(pending.draft),persistAfterPick:false,startedAt:pending.startedAt}));
            sessionStorage.removeItem(PENDING_PICK_KEY);
            window.PMKConfig.elementPicker.resume(MODULE_ID);
        } catch (_) {}
    }

    function moduleDefinition() {
        const legacyCount = buildLegacyRules(LEGACY_ICON_MAP).length;
        return {
            id: MODULE_ID,
            schemaVersion: 5,
            compactActivation:true,
            hidePageCount:true,
            name: {
                fr: "Icônes des menus",
                en: "Menu icons"
            },
            description: {
                fr: "Choisissez l’icône ou le logo d’un menu Koha. Les icônes préconfigurées des menus latéraux sont conservées ; vos personnalisations s’appliquent ensuite aux éléments choisis.",
                en: "Customizes Koha menu and submenu icons using a visual Font Awesome library or a custom logo. The original rendering remains the default preset."
            },
            category: {
                fr: "Navigation et interface",
                en: "Navigation and interface"
            },
            prerequisites: [],
            dependencies: [],
            defaults: deepClone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    description: {
                        fr: "Le module restaure proprement les icônes natives lorsqu’il est désactivé.",
                        en: "The module cleanly restores native icons when disabled."
                    },
                    fields: [
                        {
                            type: "custom",
                            label: { fr: "Priorités et conflits", en: "Priorities and conflicts" },
                            render: renderConflictOverview
                        },
                        {
                            key: "enabled",
                            type: "boolean",
                            label: { fr: "Activer les icônes des menus", en: "Enable menu icons" }
                        },
                        {
                            key: "observeDom",
                            type: "boolean",
                            label: { fr: "Suivre les menus chargés dynamiquement", en: "Track dynamically loaded menus" }
                        }
                    ]
                },
                {
                    type: "section",
                    id: "historical",
                    label: { fr: "Icônes préconfigurées des menus latéraux", en: "Preconfigured sidebar icons" },
                    description: {
                        fr: "Les menus latéraux disposent de " + legacyCount + " correspondances de texte préconfigurées. Pour modifier un seul menu, utilisez les personnalisations ci-dessous. La bibliothèque complète reste accessible dans les réglages avancés.",
                        en: "The " + legacyCount + " historical mappings are preserved and can now be edited. By default, behavior remains identical to the historical script 117."
                    },
                    fields: [
                        {
                            key: "legacy.enabled",
                            type: "boolean",
                            label: { fr: "Utiliser les icônes préconfigurées", en: "Use preconfigured icons" }
                        },
                        {
                            key: "legacy.overrideExistingIcons",
                            type: "boolean",
                            label: { fr: "Remplacer aussi les icônes natives déjà présentes", en: "Also replace existing native icons" },
                            help: {
                                fr: "Désactivé par défaut pour reproduire le legacy. Les règles personnalisées peuvent toujours remplacer une icône précise.",
                                en: "Disabled by default to preserve legacy behavior. Custom rules can still replace a specific icon."
                            }
                        },
                        {
                            type: "custom",
                            label: { fr: "Icône par défaut", en: "Default icon" },
                            render: renderLegacyDefaultPreview
                        },
                        {
                            type: "action",
                            buttonLabel: { fr: "Choisir dans la bibliothèque d’icônes", en: "Choose from icon library" },
                            iconClass: "fas fa-search",
                            action: chooseLegacyDefaultIcon
                        },
                        {
                            key: "legacy.defaultIconClass",
                            type: "text",
                            advanced: true,
                            label: { fr: "Classe Font Awesome — saisie manuelle", en: "Font Awesome class — manual entry" },
                            help: {
                                fr: "Mode avancé. Défaut historique : fas fa-thumbtack.",
                                en: "Advanced mode. Historical default: fas fa-thumbtack."
                            }
                        },
                        {
                            key: "legacy.rules",
                            type: "repeater",
                            advanced:true,
                            label:{fr:"Bibliothèque des correspondances préconfigurées",en:"Preconfigured mappings"},
                            reorder: true,
                            removable: false,
                            canAdd: function () { return false; },
                            itemTitle: function (item, index) {
                                return cleanText(item && item.text) || ("Menu " + String(index + 1));
                            },
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: { fr: "Correspondance active", en: "Mapping enabled" }
                                },
                                {
                                    key: "text",
                                    type: "text",
                                    label: { fr: "Texte du menu", en: "Menu text" },
                                    help: {
                                        fr: "Le premier texte correspondant dans cette liste est utilisé. Les personnalisations ci-dessous sont appliquées ensuite.",
                                        en: "The first partial match wins, as in the historical script."
                                    }
                                },
                                {
                                    type: "custom",
                                    label: { fr: "Icône actuelle", en: "Current icon" },
                                    render: renderLegacyRulePreview
                                },
                                {
                                    type: "action",
                                    buttonLabel: { fr: "Choisir une icône", en: "Choose an icon" },
                                    iconClass: "fas fa-search",
                                    action: chooseLegacyRuleIcon
                                },
                                {
                                    key: "iconClass",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Classe Font Awesome — saisie manuelle", en: "Font Awesome class — manual entry" },
                                    placeholder: { fr: "fas fa-book", en: "fas fa-book" }
                                }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "custom",
                    label: { fr: "Menus et sous-menus personnalisés", en: "Custom menus and submenus" },
                    description: {
                        fr: "Ajoutez une règle, choisissez le menu sur la page puis son icône. Une personnalisation peut remplacer une icône préconfigurée. Si plusieurs règles ciblent le même élément, la priorité la plus élevée gagne ; à égalité, la dernière règle conserve le comportement historique.",
                        en: "Add rules and pick any Koha menu or submenu. If several rules target the same element, the highest priority wins; at equal priority the last rule preserves historical behaviour."
                    },
                    fields: [
                        {
                            key: "customRules",
                            type: "repeater",
                            addLabel: { fr: "Ajouter une personnalisation d’icône", en: "Add icon customization" },
                            itemLabel: { fr: "Icône", en: "Icon" },
                            itemTitle: function (item, index) {
                                return cleanText(item && (item.name || item.targetName || item.text)) ||
                                    ("Icône " + String(index + 1));
                            },
                            newItem: function () {
                                return {
                                    id: "rule-" + Date.now().toString(36),
                                    enabled: true,
                                    name: "",
                                    pages: window.location.pathname || "*",
                                    targetMode: "selector",
                                    selector: "",
                                    targetName: "",
                                    text: "",
                                    textMode: "exact",
                                    menuSelector: 'nav a, .sidebar_menu a, .navbar a, .dropdown-menu a, [role="menu"] a, [role="menuitem"]',
                                    iconType: "fa",
                                    iconClass: "fas fa-circle",
                                    imageUrl: "",
                                    sizePx: 16,
                                    color: "",
                                    position: "prepend",
                                    replaceExisting: true,
                                    priority: 100
                                };
                            },
                            fields: [
                                {
                                    key: "enabled",
                                    type: "boolean",
                                    label: { fr: "Règle active", en: "Rule enabled" }
                                },
                                {
                                    key: "name",
                                    type: "text",
                                    label: { fr: "Nom de la règle", en: "Rule name" }
                                },
                                {
                                    key: "priority",
                                    type: "number",
                                    min: 0,
                                    max: 1000,
                                    label: { fr: "Priorité", en: "Priority" },
                                    help: { fr: "En cas de même cible, la valeur la plus élevée gagne. À priorité égale, la dernière règle conserve le comportement historique.", en: "For the same target, the highest value wins. At equal priority, the last rule preserves historical behaviour." }
                                },
                                {
                                    key: "pages",
                                    type: "text",
                                    label: { fr: "Pages Koha", en: "Koha pages" },
                                    help: {
                                        fr: "Chemins séparés par des virgules. Utilisez * pour toutes les pages.",
                                        en: "Comma-separated paths. Use * for all pages."
                                    }
                                },
                                {
                                    key: "targetMode",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Méthode de ciblage", en: "Targeting method" },
                                    options: [
                                        { value: "selector", label: { fr: "Picker / sélecteur CSS", en: "Picker / CSS selector" } },
                                        { value: "text", label: { fr: "Libellé du menu", en: "Menu label" } }
                                    ]
                                },
                                {
                                    key: "selector",
                                    type: "elementPicker",
                                    manualAlways:true,
                                    label: { fr: "Menu ou sous-menu ciblé", en: "Target menu or submenu" },
                                    pickLabel: { fr: "Choisir sur la page", en: "Pick on page" },
                                    clearLabel: { fr: "Effacer", en: "Clear" },
                                    allowManual: true,
                                    pick: pickForConfig,
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.targetMode !== "text");
                                    },
                                    help: {
                                        fr: "Le picker cible de préférence le lien ou bouton de menu, et mémorise un sélecteur stable.",
                                        en: "The picker prefers the menu link or button and stores a stable selector."
                                    }
                                },
                                {
                                    key: "targetName",
                                    type: "text",
                                    readOnly: true,
                                    advanced: true,
                                    label: { fr: "Élément détecté", en: "Detected element" }
                                },
                                {
                                    key: "text",
                                    type: "text",
                                    label: { fr: "Libellé à rechercher", en: "Label to match" },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.targetMode === "text");
                                    }
                                },
                                {
                                    key: "textMode",
                                    type: "select",
                                    label: { fr: "Correspondance du libellé", en: "Label matching" },
                                    options: [
                                        { value: "exact", label: { fr: "Exacte", en: "Exact" } },
                                        { value: "contains", label: { fr: "Contient", en: "Contains" } }
                                    ],
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.targetMode === "text");
                                    }
                                },
                                {
                                    key: "menuSelector",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Zones de menus à parcourir", en: "Menu areas to scan" },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.targetMode === "text");
                                    }
                                },
                                {
                                    key: "iconType",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Type d’icône", en: "Icon type" },
                                    options: [
                                        { value: "fa", label: { fr: "Font Awesome — bibliothèque visuelle", en: "Font Awesome — visual library" } },
                                        { value: "image", label: { fr: "Logo / image personnalisé", en: "Custom logo / image" } },
                                        { value: "none", label: { fr: "Aucune icône", en: "No icon" } }
                                    ]
                                },
                                {
                                    type: "custom",
                                    label: { fr: "Aperçu", en: "Preview" },
                                    render: renderCustomRulePreview
                                },
                                {
                                    type: "action",
                                    buttonLabel: { fr: "Choisir dans la bibliothèque Font Awesome", en: "Choose from Font Awesome library" },
                                    iconClass: "fas fa-search",
                                    action: chooseCustomRuleIcon,
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType === "fa");
                                    }
                                },
                                {
                                    key: "iconClass",
                                    type: "text",
                                    advanced: true,
                                    label: { fr: "Classe Font Awesome — saisie manuelle", en: "Font Awesome class — manual entry" },
                                    placeholder: { fr: "fas fa-book", en: "fas fa-book" },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType === "fa");
                                    }
                                },
                                {
                                    key: "imageUrl",
                                    type: "text",
                                    label: { fr: "URL du logo / de l’image", en: "Logo / image URL" },
                                    help: { fr: "Utilisez une ressource HTTPS ou une image servie par votre installation. Aucun CDN n’est ajouté par le 117.", en: "Use an HTTPS resource or an image served by your installation. Module 117 adds no CDN." },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType === "image");
                                    }
                                },
                                {
                                    key: "sizePx",
                                    type: "number",
                                    min: 8,
                                    max: 96,
                                    label: { fr: "Taille (px)", en: "Size (px)" },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType !== "none");
                                    }
                                },
                                {
                                    key: "color",
                                    type: "color",
                                    label: { fr: "Couleur", en: "Color" },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType === "fa");
                                    }
                                },
                                {
                                    key: "position",
                                    type: "select",
                                    label: { fr: "Position", en: "Position" },
                                    options: [
                                        { value: "prepend", label: { fr: "Avant le libellé", en: "Before label" } },
                                        { value: "append", label: { fr: "Après le libellé", en: "After label" } }
                                    ],
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType !== "none");
                                    }
                                },
                                {
                                    key: "replaceExisting",
                                    type: "boolean",
                                    label: { fr: "Remplacer l’icône existante", en: "Replace existing icon" },
                                    help: {
                                        fr: "Si désactivé, la règle n’ajoute rien lorsqu’une icône existe déjà.",
                                        en: "If disabled, the rule adds nothing when an icon already exists."
                                    },
                                    when: function (root, path) {
                                        const rule = getCustomRuleFromPath(root, path);
                                        return Boolean(rule && rule.iconType !== "none");
                                    }
                                }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function registerWithPMK() {
        if (registered || !window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") {
            return false;
        }

        try {
            window.PMKConfig.elementPicker?.register(MODULE_ID,{
                resolveTarget:element=>element.closest('a,button,[role="menuitem"]') || element,
                applyPending:(draft,pending,picked)=>{const rule=getCustomRuleFromPath(draft,pending.fieldPath);if(rule){rule.targetMode='selector';rule.targetName=picked.label || picked.selector;}return draft;}
            });
            window.PMKConfig.registerModule(moduleDefinition());
            registered = true;
        } catch (_) {
            return false;
        }

        if (typeof window.PMKConfig.subscribe === "function") {
            try {
                unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
            } catch (_) {}
        }

        if (typeof window.PMKConfig.getConfig === "function") {
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(applyConfig)
                .catch(function () { applyConfig(DEFAULT_CONFIG); });
        } else {
            applyConfig(DEFAULT_CONFIG);
        }

        return true;
    }

    function mountContextAccess() {
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor = document.querySelector(".sidebar_menu h5, .sidebar_menu h4, .sidebar_menu h3, .sidebar_menu");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor: anchor,
                position: "after",
                contextKey: "menu-icons",
                context: { pagePath: window.location.pathname }
            });
        } catch (_) {}
    }

    function start() {
        const run = function () {
            if (!registerWithPMK()) {
                applyConfig(DEFAULT_CONFIG);
                window.addEventListener("pmk:config-ready", function () {
                    registerWithPMK();
                    mountContextAccess();
                    resumePendingPick();
                }, { once: true });
            } else {
                mountContextAccess();
                resumePendingPick();
            }
        };

        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", run, { once: true });
        } else {
            run();
        }
    }

    window.PMK117MenuIcons = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: deepClone(DEFAULT_CONFIG),
        refresh: function () {
            if (window.PMKConfig && typeof window.PMKConfig.getConfig === "function") {
                return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).then(applyConfig);
            }
            return Promise.resolve(applyConfig(DEFAULT_CONFIG));
        },
        apply: applyConfig,
        restore: restoreRuntime,
        iconMap: deepClone(LEGACY_ICON_MAP),
        pickElement: pickElementOnCurrentPage,
        stableSelector: stableSelector
    };

    window.addEventListener("beforeunload", function () {
        stopObserver();
        if (typeof unsubscribe === "function") {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });

    start();
})(window, document);

;window.PMKNonPlugin.loaded.push("117-icons-menus.js");
} catch (error) { window.PMKNonPlugin.errors.push("117-icons-menus.js: "+error.message); console.error("[PMK] 117-icons-menus.js",error); };
try {
/*
 Nom du fichier : 118-mail-tel-obligatoire.js
 Module PMK      : patron-required-contact
 Version         : 3.1.0-preplugin
 Date            : 2026-09-20
 Auteur          : équipe PimpMyKoha / refactorisation PimpMyKoha

 Objectif :
 - conserver le comportement historique du script 118 sur memberentry.pl ;
 - rendre la règle portable et configurable sans toucher au JavaScript ;
 - permettre, champ par champ, trois états : ignoré, obligatoire seul, ou membre d'un groupe ;
 - permettre à chaque groupe d'exiger au moins N champs renseignés ;
 - conserver exactement le préréglage initial :
      #phone, #mobile, #email, #emailpro dans le groupe "contact",
      minimum 1, aucun champ individuellement obligatoire ;
 - conserver le rendu historique par défaut : messages sous champs, bordures rouges,
   bloc contact surligné, scroll/focus et secousse du bouton de sauvegarde ;
 - reprendre la mécanique historique de blocage Koha : submit + check_form_borrowers + clic sauvegarde ;
 - chaîner check_form_borrowers de façon réversible pour conserver la validation native Koha ;
 - utiliser stopImmediatePropagation uniquement quand notre validation échoue, comme le legacy.

 Dépendance : 000-pmk-config-firestore.js optionnelle au runtime.
 Sans PMK, les valeurs d’origine intégrées ci-dessous sont appliquées.
*/
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK118RequiredContactV3) return;
    window.__PMK118RequiredContactV3 = true;

    const MODULE_ID = "patron-required-contact";
    const MODULE_VERSION = "3.1.0-preplugin";
    const MEMBERENTRY_FRAGMENT = "/cgi-bin/koha/members/memberentry.pl";

    const STANDARD_FIELDS = Object.freeze({
        phone:            { selector: "#phone",            fr: "Téléphone principal",       en: "Primary phone" },
        mobile:           { selector: "#mobile",           fr: "Mobile",                    en: "Mobile phone" },
        phonepro:         { selector: "#phonepro",         fr: "Téléphone professionnel",   en: "Work phone" },
        email:            { selector: "#email",            fr: "Courriel",                  en: "Email" },
        emailpro:         { selector: "#emailpro",         fr: "Courriel professionnel",    en: "Work email" },
        fax:              { selector: "#fax",              fr: "Fax",                       en: "Fax" },
        B_phone:          { selector: "#B_phone",          fr: "Téléphone adresse alternative", en: "Alternate address phone" },
        B_email:          { selector: "#B_email",          fr: "Courriel adresse alternative",  en: "Alternate address email" },
        altcontactphone:  { selector: "#altcontactphone",  fr: "Téléphone contact alternatif",  en: "Alternate contact phone" },
        smsalertnumber:   { selector: "#SMSnumber, #smsalertnumber", fr: "Numéro SMS",       en: "SMS number" }
    });

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        scope: "both",
        contactContainerSelector: "#memberentry_contact",
        saveButtonSelector: "#saverecord",
        fields: [
            {
                id: "legacy-phone",
                enabled: true,
                source: "phone",
                customSelector: "",
                labelFr: "Téléphone principal",
                labelEn: "Primary phone",
                rule: "group",
                groupId: "contact"
            },
            {
                id: "legacy-mobile",
                enabled: true,
                source: "mobile",
                customSelector: "",
                labelFr: "Mobile",
                labelEn: "Mobile phone",
                rule: "group",
                groupId: "contact"
            },
            {
                id: "legacy-email",
                enabled: true,
                source: "email",
                customSelector: "",
                labelFr: "Courriel",
                labelEn: "Email",
                rule: "group",
                groupId: "contact"
            },
            {
                id: "legacy-emailpro",
                enabled: true,
                source: "emailpro",
                customSelector: "",
                labelFr: "Courriel professionnel",
                labelEn: "Work email",
                rule: "group",
                groupId: "contact"
            }
        ],
        groups: [
            {
                id: "contact",
                enabled: true,
                labelFr: "Contact",
                labelEn: "Contact",
                minRequired: 1,
                messageFr: "Au moins un champ de contact est obligatoire",
                messageEn: "At least one contact field is required"
            }
        ],
        requiredMessageFr: "Ce champ de contact est obligatoire",
        requiredMessageEn: "This contact field is required",
        appearance: {
            fieldErrorColor: "#cc0000",
            fieldErrorBackground: "#fff5f5",
            containerBorder: "2px solid #cc0000",
            containerBackground: "#fffafa",
            containerPadding: "10px",
            containerBorderRadius: "5px"
        }
    });

    let currentConfig = null;
    let registered = false;
    let unsubscribe = null;
    let boundForm = null;
    let boundSaveButton = null;
    let hasVisibleErrors = false;

    // Le script historique protégeait la sauvegarde à trois niveaux :
    // submit du formulaire, check_form_borrowers et clic sur Enregistrer.
    // On conserve cette mécanique, mais le patch de la fonction Koha est réversible.
    let originalCheckFormBorrowers = null;
    let patchedCheckFormBorrowers = null;
    let checkFormPatchTimer = null;
    let checkFormPatchAttempts = 0;

    const fieldOriginalStyles = new WeakMap();
    const containerOriginalStyles = new WeakMap();

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function clean(value) {
        return String(value == null ? "" : value).trim();
    }

    function lang() {
        const value = String(document.documentElement.lang || "fr").toLowerCase();
        return value.indexOf("en") === 0 ? "en" : "fr";
    }

    function text(fr, en) {
        return lang() === "en" ? (en || fr || "") : (fr || en || "");
    }

    function mergeObject(base, raw) {
        const out = clone(base);
        if (!raw || typeof raw !== "object") return out;
        Object.keys(raw).forEach(function (key) {
            if (Array.isArray(raw[key])) out[key] = clone(raw[key]);
            else if (raw[key] && typeof raw[key] === "object" && !Array.isArray(raw[key])) {
                out[key] = Object.assign({}, out[key] || {}, raw[key]);
            } else out[key] = raw[key];
        });
        return out;
    }

    function normalizeField(field, index) {
        const raw = field || {};
        let source = clean(raw.source) || "phone";
        if (source !== "custom" && !STANDARD_FIELDS[source]) source = "custom";

        let rule = clean(raw.rule) || "ignored";
        if (["ignored", "required", "group"].indexOf(rule) === -1) rule = "ignored";

        const std = STANDARD_FIELDS[source] || {};
        return {
            id: clean(raw.id) || ("field-" + (index + 1)),
            enabled: raw.enabled !== false,
            source: source,
            customSelector: clean(raw.customSelector),
            labelFr: clean(raw.labelFr) || std.fr || ("Champ " + (index + 1)),
            labelEn: clean(raw.labelEn) || std.en || ("Field " + (index + 1)),
            rule: rule,
            groupId: clean(raw.groupId)
        };
    }

    function normalizeGroup(group, index) {
        const raw = group || {};
        let min = parseInt(raw.minRequired, 10);
        if (!Number.isFinite(min) || min < 1) min = 1;
        return {
            id: clean(raw.id) || ("group-" + (index + 1)),
            enabled: raw.enabled !== false,
            labelFr: clean(raw.labelFr) || ("Groupe " + (index + 1)),
            labelEn: clean(raw.labelEn) || ("Group " + (index + 1)),
            minRequired: min,
            messageFr: clean(raw.messageFr) || "Au moins un champ de ce groupe est obligatoire",
            messageEn: clean(raw.messageEn) || "At least one field in this group is required"
        };
    }

    function normalizeConfig(raw) {
        const cfg = mergeObject(DEFAULT_CONFIG, raw || {});
        cfg.enabled = cfg.enabled !== false;
        if (["create", "edit", "both"].indexOf(cfg.scope) === -1) cfg.scope = "both";
        cfg.contactContainerSelector = clean(cfg.contactContainerSelector) || "#memberentry_contact";
        cfg.saveButtonSelector = clean(cfg.saveButtonSelector) || "#saverecord";
        cfg.fields = (Array.isArray(cfg.fields) ? cfg.fields : DEFAULT_CONFIG.fields).map(normalizeField);
        cfg.groups = (Array.isArray(cfg.groups) ? cfg.groups : DEFAULT_CONFIG.groups).map(normalizeGroup);
        cfg.requiredMessageFr = clean(cfg.requiredMessageFr) || DEFAULT_CONFIG.requiredMessageFr;
        cfg.requiredMessageEn = clean(cfg.requiredMessageEn) || DEFAULT_CONFIG.requiredMessageEn;
        cfg.appearance = Object.assign({}, DEFAULT_CONFIG.appearance, cfg.appearance || {});
        return cfg;
    }

    function isMemberEntry() {
        return window.location.pathname.indexOf("memberentry.pl") !== -1;
    }

    function detectFormMode(form) {
        if (!form) return "create";
        const explicit = form.querySelector('input[name="borrowernumber"], #borrowernumber');
        if (explicit && clean(explicit.value)) return "edit";
        const params = new URLSearchParams(window.location.search || "");
        if (clean(params.get("borrowernumber"))) return "edit";
        return "create";
    }

    function scopeAllows(cfg, form) {
        if (!cfg || cfg.scope === "both") return true;
        return cfg.scope === detectFormMode(form);
    }

    function selectorForRule(rule) {
        if (!rule) return "";
        if (rule.source === "custom") return clean(rule.customSelector);
        const std = STANDARD_FIELDS[rule.source];
        return std ? std.selector : "";
    }

    function safeQuery(selector, root) {
        if (!selector) return null;
        try {
            return (root || document).querySelector(selector);
        } catch (_) {
            return null;
        }
    }

    function resolveRuntimeFields(cfg, form) {
        const rows = [];
        (cfg.fields || []).forEach(function (rule, index) {
            if (!rule || rule.enabled === false || rule.rule === "ignored") return;
            const selector = selectorForRule(rule);
            const element = safeQuery(selector, form) || safeQuery(selector, document);
            if (!element) return; // champ masqué/absent sur cette installation : ignoré, fail-open
            rows.push({
                index: index,
                rule: rule,
                selector: selector,
                element: element,
                label: text(rule.labelFr, rule.labelEn)
            });
        });
        return rows;
    }

    function valuePresent(element) {
        if (!element) return false;
        if (element.type === "checkbox" || element.type === "radio") return !!element.checked;
        return clean(element.value) !== "";
    }

    function rememberFieldStyle(field) {
        if (!field || fieldOriginalStyles.has(field)) return;
        fieldOriginalStyles.set(field, {
            borderColor: field.style.borderColor,
            backgroundColor: field.style.backgroundColor
        });
    }

    function restoreFieldStyle(field) {
        if (!field) return;
        const saved = fieldOriginalStyles.get(field);
        field.style.borderColor = saved ? saved.borderColor : "";
        field.style.backgroundColor = saved ? saved.backgroundColor : "";
        fieldOriginalStyles.delete(field);
    }

    function errorIdFor(field) {
        const raw = clean(field && field.id) || clean(field && field.name) || "field";
        return "pmk118-error-" + raw.replace(/[^A-Za-z0-9_-]/g, "-");
    }

    function removeFieldError(field) {
        if (!field) return;
        const id = errorIdFor(field);
        const node = document.getElementById(id);
        if (node && node.getAttribute("data-pmk118-owned") === "1") node.remove();
        restoreFieldStyle(field);
        field.removeAttribute("aria-invalid");
        const described = clean(field.getAttribute("aria-describedby"));
        if (described) {
            const kept = described.split(/\s+/).filter(function (token) { return token !== id; });
            if (kept.length) field.setAttribute("aria-describedby", kept.join(" "));
            else field.removeAttribute("aria-describedby");
        }
    }

    function addFieldError(field, message, cfg) {
        if (!field) return;
        removeFieldError(field);
        rememberFieldStyle(field);

        const host = field.closest("li") || field.parentElement;
        if (!host) return;

        const error = document.createElement("span");
        error.id = errorIdFor(field);
        error.className = "field-error-message pmk118-field-error-message";
        error.setAttribute("data-pmk118-owned", "1");
        error.style.cssText = "color: " + cfg.appearance.fieldErrorColor + "; font-size: 12px; display: block; margin-top: 5px; font-weight: normal;";
        error.textContent = "⚠️ " + message;
        host.appendChild(error);

        field.style.borderColor = cfg.appearance.fieldErrorColor;
        field.style.backgroundColor = cfg.appearance.fieldErrorBackground;
        field.setAttribute("aria-invalid", "true");
        const described = clean(field.getAttribute("aria-describedby"));
        field.setAttribute("aria-describedby", clean(described + " " + error.id));
    }

    function resolveContainer(cfg, runtimeFields) {
        let container = safeQuery(cfg.contactContainerSelector, document);
        if (container) return container;
        if (runtimeFields && runtimeFields.length) {
            container = runtimeFields[0].element.closest("fieldset");
        }
        return container || null;
    }

    function rememberContainerStyle(container) {
        if (!container || containerOriginalStyles.has(container)) return;
        containerOriginalStyles.set(container, {
            border: container.style.border,
            padding: container.style.padding,
            borderRadius: container.style.borderRadius,
            backgroundColor: container.style.backgroundColor
        });
    }

    function highlightContainer(container, cfg) {
        if (!container) return;
        rememberContainerStyle(container);
        container.style.border = cfg.appearance.containerBorder;
        container.style.padding = cfg.appearance.containerPadding;
        container.style.borderRadius = cfg.appearance.containerBorderRadius;
        container.style.backgroundColor = cfg.appearance.containerBackground;
    }

    function restoreContainer(container) {
        if (!container) return;
        const saved = containerOriginalStyles.get(container);
        container.style.border = saved ? saved.border : "";
        container.style.padding = saved ? saved.padding : "";
        container.style.borderRadius = saved ? saved.borderRadius : "";
        container.style.backgroundColor = saved ? saved.backgroundColor : "";
        containerOriginalStyles.delete(container);
    }

    function clearAllErrors() {
        document.querySelectorAll('[data-pmk118-owned="1"].pmk118-field-error-message').forEach(function (node) {
            node.remove();
        });
        fieldOriginalStyles.forEach ? fieldOriginalStyles.forEach(function () {}) : null;
        if (boundForm && currentConfig) {
            resolveRuntimeFields(currentConfig, boundForm).forEach(function (row) {
                removeFieldError(row.element);
            });
            restoreContainer(resolveContainer(currentConfig, resolveRuntimeFields(currentConfig, boundForm)));
        }
        hasVisibleErrors = false;
    }

    function buildValidation(cfg, form) {
        const runtimeFields = resolveRuntimeFields(cfg, form);
        const invalid = [];

        runtimeFields.forEach(function (row) {
            if (row.rule.rule === "required" && !valuePresent(row.element)) {
                invalid.push({
                    row: row,
                    message: text(cfg.requiredMessageFr, cfg.requiredMessageEn),
                    type: "required"
                });
            }
        });

        const groupsById = {};
        (cfg.groups || []).forEach(function (group) {
            if (!group || group.enabled === false) return;
            groupsById[group.id] = group;
        });

        Object.keys(groupsById).forEach(function (groupId) {
            const group = groupsById[groupId];
            const members = runtimeFields.filter(function (row) {
                return row.rule.rule === "group" && row.rule.groupId === groupId;
            });
            if (!members.length) return;

            const filled = members.filter(function (row) { return valuePresent(row.element); }).length;
            // Si certains champs du groupe sont masqués par la configuration Koha,
            // la règle reste réalisable avec les champs réellement présents.
            const effectiveMin = Math.min(Math.max(1, group.minRequired), members.length);
            if (filled >= effectiveMin) return;

            const message = text(group.messageFr, group.messageEn);
            members.forEach(function (row) {
                if (!valuePresent(row.element)) {
                    invalid.push({ row: row, message: message, type: "group", groupId: groupId });
                }
            });
        });

        return {
            ok: invalid.length === 0,
            invalid: invalid,
            runtimeFields: runtimeFields,
            container: resolveContainer(cfg, runtimeFields)
        };
    }

    function renderValidation(result, cfg) {
        result.runtimeFields.forEach(function (row) { removeFieldError(row.element); });
        restoreContainer(result.container);

        if (result.ok) {
            hasVisibleErrors = false;
            return;
        }

        result.invalid.forEach(function (entry) {
            addFieldError(entry.row.element, entry.message, cfg);
        });
        highlightContainer(result.container, cfg);
        hasVisibleErrors = true;
    }

    function shakeSaveButton() {
        const button = boundSaveButton;
        if (!button) return;
        const originalTransform = button.style.transform;
        const steps = [
            [-5, 0],
            [5, 100],
            [-3, 200],
            [3, 300],
            [0, 400]
        ];
        steps.forEach(function (step) {
            window.setTimeout(function () {
                button.style.transform = step[0] === 0 ? originalTransform : ("translateX(" + step[0] + "px)");
            }, step[1]);
        });
    }

    function rejectSubmission(result, cfg) {
        renderValidation(result, cfg);
        shakeSaveButton();
        const first = result.invalid.length ? result.invalid[0].row.element : null;
        if (first) {
            try { first.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (_) {}
            try { first.focus({ preventScroll: true }); } catch (_) { try { first.focus(); } catch (__) {} }
        }
    }

    function validateNow(showErrors) {
        if (!boundForm || !currentConfig || currentConfig.enabled === false || !scopeAllows(currentConfig, boundForm)) {
            return { ok: true, invalid: [], runtimeFields: [], container: null };
        }
        const result = buildValidation(currentConfig, boundForm);
        if (showErrors) renderValidation(result, currentConfig);
        return result;
    }

    function onFormInput(event) {
        if (!hasVisibleErrors || !currentConfig || !boundForm) return;
        const rows = resolveRuntimeFields(currentConfig, boundForm);
        const belongs = rows.some(function (row) { return row.element === event.target; });
        if (!belongs) return;
        renderValidation(buildValidation(currentConfig, boundForm), currentConfig);
    }

    function onFormBlur(event) {
        if (!hasVisibleErrors || !currentConfig || !boundForm) return;
        const rows = resolveRuntimeFields(currentConfig, boundForm);
        const belongs = rows.some(function (row) { return row.element === event.target; });
        if (!belongs) return;
        renderValidation(buildValidation(currentConfig, boundForm), currentConfig);
    }

    // Validation commune aux trois méthodes historiques de sauvegarde.
    // Retourne true si Koha peut poursuivre, false si PMK doit bloquer.
    function validateBeforeKohaSubmit() {
        if (!currentConfig || currentConfig.enabled === false || !boundForm || !scopeAllows(currentConfig, boundForm)) {
            return true;
        }
        const result = buildValidation(currentConfig, boundForm);
        if (result.ok) {
            renderValidation(result, currentConfig);
            return true;
        }
        rejectSubmission(result, currentConfig);
        return false;
    }

    // Méthode historique 1 : interception du submit réel du formulaire.
    function onSubmit(event) {
        if (validateBeforeKohaSubmit()) return;
        event.preventDefault();
        event.stopPropagation();
    }

    // Méthode historique 3 : interception du clic avant les handlers Koha.
    // Le stopImmediatePropagation n'est utilisé QUE quand la règle PMK échoue.
    // Quand tout est valide, on ne touche à rien et Koha poursuit son cycle normal.
    function onSaveClick(event) {
        if (validateBeforeKohaSubmit()) return;
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    }

    // Méthode historique 2 : chaînage de check_form_borrowers.
    // C'est indispensable sur Koha car certains chemins de sauvegarde passent par cette
    // fonction et peuvent contourner un simple preventDefault sur le bouton.
    function installCheckFormPatch() {
        if (!boundForm || !currentConfig || currentConfig.enabled === false) return false;

        if (patchedCheckFormBorrowers && window.check_form_borrowers === patchedCheckFormBorrowers) {
            return true;
        }

        const kohaCheck = window.check_form_borrowers;
        if (typeof kohaCheck !== "function") return false;

        originalCheckFormBorrowers = kohaCheck;
        patchedCheckFormBorrowers = function () {
            if (!validateBeforeKohaSubmit()) return false;
            return kohaCheck.apply(this, arguments);
        };
        patchedCheckFormBorrowers.__pmk118 = true;
        patchedCheckFormBorrowers.__pmk118Original = originalCheckFormBorrowers;
        window.check_form_borrowers = patchedCheckFormBorrowers;
        return true;
    }

    function scheduleCheckFormPatch() {
        if (installCheckFormPatch()) return;
        checkFormPatchAttempts = 0;

        const retry = function () {
            checkFormPatchTimer = null;
            if (!boundForm || !currentConfig || currentConfig.enabled === false) return;
            if (installCheckFormPatch()) return;
            checkFormPatchAttempts += 1;
            if (checkFormPatchAttempts < 30) {
                checkFormPatchTimer = window.setTimeout(retry, 100);
            }
        };

        checkFormPatchTimer = window.setTimeout(retry, 100);
    }

    function restoreCheckFormPatch() {
        if (checkFormPatchTimer !== null) {
            window.clearTimeout(checkFormPatchTimer);
            checkFormPatchTimer = null;
        }
        checkFormPatchAttempts = 0;

        // Ne restaure la fonction que si notre wrapper est encore celui installé.
        // Si un autre script a remplacé check_form_borrowers après nous, on ne l'écrase pas.
        if (patchedCheckFormBorrowers && window.check_form_borrowers === patchedCheckFormBorrowers) {
            window.check_form_borrowers = originalCheckFormBorrowers;
        }
        originalCheckFormBorrowers = null;
        patchedCheckFormBorrowers = null;
    }

    function unbindRuntime() {
        restoreCheckFormPatch();
        if (boundForm) {
            boundForm.removeEventListener("submit", onSubmit, true);
            boundForm.removeEventListener("input", onFormInput, true);
            boundForm.removeEventListener("blur", onFormBlur, true);
        }
        if (boundSaveButton) boundSaveButton.removeEventListener("click", onSaveClick, true);
        clearAllErrors();
        boundForm = null;
        boundSaveButton = null;
    }

    function bindRuntime(cfg) {
        if (!isMemberEntry()) return;
        const form = document.getElementById("entryform");
        if (!form) return;
        if (!scopeAllows(cfg, form)) return;

        boundForm = form;
        boundSaveButton = safeQuery(cfg.saveButtonSelector, document);

        // Même ordre de protection que le script historique.
        boundForm.addEventListener("submit", onSubmit, true);
        boundForm.addEventListener("input", onFormInput, true);
        boundForm.addEventListener("blur", onFormBlur, true);
        if (boundSaveButton) boundSaveButton.addEventListener("click", onSaveClick, true);
        scheduleCheckFormPatch();

        // Comme le legacy : si le formulaire chargé possède déjà un contact valide,
        // aucun état d'erreur ne reste affiché.
        const initial = buildValidation(cfg, form);
        if (initial.ok) renderValidation(initial, cfg);
    }

    function applyConfig(raw) {
        unbindRuntime();
        currentConfig = normalizeConfig(raw || DEFAULT_CONFIG);
        if (!currentConfig.enabled) return;
        bindRuntime(currentConfig);
    }


    function pathIndex(path, key) {
        const list = Array.isArray(path) ? path : [];
        for (let i = 0; i < list.length - 1; i += 1) {
            if (list[i] === key && Number.isInteger(list[i + 1])) return list[i + 1];
        }
        return -1;
    }

    function itemFromPath(root, path, key) {
        const index = pathIndex(path, key);
        return root && Array.isArray(root[key]) && index >= 0 ? root[key][index] : null;
    }

    function isCustomField(root, path) {
        const item = itemFromPath(root, path, "fields");
        return Boolean(item && item.source === "custom");
    }

    function isGroupedField(root, path) {
        const item = itemFromPath(root, path, "fields");
        return Boolean(item && item.rule === "group");
    }

    function sourceOptions() {
        const options = Object.keys(STANDARD_FIELDS).map(function (key) {
            const f = STANDARD_FIELDS[key];
            return { value: key, label: { fr: f.fr, en: f.en } };
        });
        options.push({ value: "custom", label: { fr: "Champ personnalisé (sélecteur CSS)", en: "Custom field (CSS selector)" } });
        return options;
    }

    function ruleOptions() {
        return [
            { value: "ignored", label: { fr: "Ignoré", en: "Ignored" } },
            { value: "required", label: { fr: "Obligatoire individuellement", en: "Individually required" } },
            { value: "group", label: { fr: "Membre d’un groupe alternatif", en: "Member of an alternative group" } }
        ];
    }

    function scopeOptions() {
        return [
            { value: "both", label: { fr: "Création et modification", en: "Create and edit" } },
            { value: "create", label: { fr: "Création uniquement", en: "Create only" } },
            { value: "edit", label: { fr: "Modification uniquement", en: "Edit only" } }
        ];
    }

    function newField() {
        return {
            id: "field-" + Date.now().toString(36),
            enabled: true,
            source: "phone",
            customSelector: "",
            labelFr: "Nouveau champ",
            labelEn: "New field",
            rule: "ignored",
            groupId: "contact"
        };
    }

    function newGroup() {
        const suffix = Date.now().toString(36);
        return {
            id: "group-" + suffix,
            enabled: true,
            labelFr: "Nouveau groupe",
            labelEn: "New group",
            minRequired: 1,
            messageFr: "Au moins un champ de ce groupe est obligatoire",
            messageEn: "At least one field in this group is required"
        };
    }

    function validateConfig(raw) {
        const cfg = normalizeConfig(raw || {});
        const ids = new Set();
        for (let i = 0; i < cfg.groups.length; i += 1) {
            const g = cfg.groups[i];
            if (!g.id) return { ok: false, message: "Chaque groupe doit avoir un identifiant." };
            if (ids.has(g.id)) return { ok: false, message: "Chaque groupe doit avoir un identifiant unique." };
            ids.add(g.id);
            if (g.minRequired < 1) return { ok: false, message: "Le minimum requis d’un groupe doit être supérieur ou égal à 1." };
        }

        for (let j = 0; j < cfg.fields.length; j += 1) {
            const f = cfg.fields[j];
            if (f.source === "custom" && f.enabled && f.rule !== "ignored") {
                if (!f.customSelector) return { ok: false, message: "Un champ personnalisé actif doit avoir un sélecteur CSS." };
                try { document.querySelector(f.customSelector); } catch (_) {
                    return { ok: false, message: "Sélecteur CSS invalide pour le champ « " + (f.labelFr || f.id) + " »." };
                }
            }
            if (f.rule === "group" && f.enabled && !f.groupId) {
                return { ok: false, message: "Un champ de groupe doit indiquer l’identifiant du groupe." };
            }
        }
        return { ok: true };
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 3,
            name: { fr: "Coordonnées obligatoires", en: "Required contact details" },
            description: {
                fr: "Contrôle les coordonnées sur memberentry.pl. Chaque champ peut être ignoré, obligatoire individuellement ou intégré à un groupe exigeant au moins N valeurs renseignées. Le préréglage initial est fourni par défaut.",
                en: "Validates contact details on memberentry.pl. Each field can be ignored, individually required, or placed in a group requiring at least N filled values. The original preset is the default."
            },
            category: { fr: "Adhérents", en: "Patrons" },
            supportedPages: [MEMBERENTRY_FRAGMENT],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            validate: validateConfig,
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le contrôle des coordonnées", en: "Enable contact validation" } },
                        { key: "scope", type: "select", label: { fr: "Appliquer lors de", en: "Apply when" }, options: scopeOptions() }
                    ]
                },
                {
                    type: "section",
                    id: "fields",
                    label: { fr: "Champs contrôlés", en: "Controlled fields" },
                    description: {
                        fr: "Pour chaque champ : Ignoré = aucune contrainte ; Obligatoire individuellement = ce champ doit être rempli ; Groupe = il participe à une règle « au moins N parmi ». Les champs absents du formulaire Koha courant sont ignorés.",
                        en: "For each field: Ignored = no constraint; Individually required = this field must be filled; Group = it participates in an 'at least N among' rule. Fields absent from the current Koha form are ignored."
                    },
                    fields: [
                        {
                            key: "fields",
                            type: "repeater",
                            label: { fr: "Champs", en: "Fields" },
                            addLabel: { fr: "Ajouter un champ", en: "Add field" },
                            reorder: true,
                            newItem: newField,
                            itemTitle: function (item, index, currentLang) {
                                const l = currentLang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
                                return l || (currentLang === "en" ? "Field " : "Champ ") + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Actif", en: "Enabled" } },
                                { key: "labelFr", type: "text", label: { fr: "Libellé français", en: "French label" } },
                                { key: "labelEn", type: "text", label: { fr: "Libellé anglais", en: "English label" } },
                                { key: "source", type: "select", refreshOnChange: true, label: { fr: "Champ Koha", en: "Koha field" }, options: sourceOptions() },
                                {
                                    key: "customSelector",
                                    type: "text",
                                    label: { fr: "Sélecteur CSS personnalisé", en: "Custom CSS selector" },
                                    when: isCustomField
                                },
                                { key: "rule", type: "select", refreshOnChange: true, label: { fr: "Règle", en: "Rule" }, options: ruleOptions() },
                                {
                                    key: "groupId",
                                    type: "text",
                                    label: { fr: "Identifiant du groupe", en: "Group ID" },
                                    help: { fr: "Doit correspondre à un groupe défini ci-dessous.", en: "Must match a group defined below." },
                                    when: isGroupedField
                                },
                                { key: "id", type: "text", readOnly: true, advanced: true, label: { fr: "Identifiant technique", en: "Technical ID" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "groups",
                    label: { fr: "Groupes alternatifs", en: "Alternative groups" },
                    description: {
                        fr: "Exemple : phone + mobile dans le groupe « téléphone », minimum 1 = au moins l’un des deux doit être renseigné.",
                        en: "Example: phone + mobile in the 'phone' group, minimum 1 = at least one of them must be filled."
                    },
                    fields: [
                        {
                            key: "groups",
                            type: "repeater",
                            label: { fr: "Groupes", en: "Groups" },
                            addLabel: { fr: "Ajouter un groupe", en: "Add group" },
                            reorder: true,
                            newItem: newGroup,
                            itemTitle: function (item, index, currentLang) {
                                const l = currentLang === "en" ? clean(item && item.labelEn) : clean(item && item.labelFr);
                                return l || (currentLang === "en" ? "Group " : "Groupe ") + (index + 1);
                            },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Actif", en: "Enabled" } },
                                { key: "id", type: "text", label: { fr: "Identifiant du groupe", en: "Group ID" } },
                                { key: "labelFr", type: "text", label: { fr: "Nom français", en: "French name" } },
                                { key: "labelEn", type: "text", label: { fr: "Nom anglais", en: "English name" } },
                                { key: "minRequired", type: "number", min: 1, step: 1, label: { fr: "Nombre minimum de champs renseignés", en: "Minimum number of filled fields" } },
                                { key: "messageFr", type: "text", label: { fr: "Message d’erreur français", en: "French error message" } },
                                { key: "messageEn", type: "text", label: { fr: "Message d’erreur anglais", en: "English error message" } }
                            ]
                        }
                    ]
                },
                {
                    type: "section",
                    id: "messages",
                    label: { fr: "Champs obligatoires seuls", en: "Individually required fields" },
                    fields: [
                        { key: "requiredMessageFr", type: "text", label: { fr: "Message français", en: "French message" } },
                        { key: "requiredMessageEn", type: "text", label: { fr: "Message anglais", en: "English message" } }
                    ]
                },
                {
                    type: "section",
                    id: "advanced",
                    advanced: true,
                    label: { fr: "Avancé", en: "Advanced" },
                    fields: [
                        { key: "contactContainerSelector", type: "text", label: { fr: "Conteneur contact", en: "Contact container" } },
                        { key: "saveButtonSelector", type: "text", label: { fr: "Bouton de sauvegarde", en: "Save button" } }
                    ]
                }
            ]
        };
    }

    function registerWithPMK() {
        if (registered || !window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try {
            window.PMKConfig.registerModule(moduleDefinition());
            registered = true;
        } catch (_) {
            return false;
        }

        if (typeof window.PMKConfig.subscribe === "function") {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }

        if (typeof window.PMKConfig.getConfig === "function") {
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(function (cfg) { applyConfig(cfg || DEFAULT_CONFIG); })
                .catch(function () { applyConfig(DEFAULT_CONFIG); });
        } else {
            applyConfig(DEFAULT_CONFIG);
        }
        return true;
    }

    function start() {
        const run = function () {
            if (!registerWithPMK()) {
                applyConfig(DEFAULT_CONFIG);
                window.addEventListener("pmk:config-ready", function () { registerWithPMK(); }, { once: true });
            }
        };
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run, { once: true });
        else run();
    }

    window.PMK118RequiredContact = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: clone(DEFAULT_CONFIG),
        standardFields: clone(STANDARD_FIELDS),
        apply: applyConfig,
        validateNow: function (showErrors) { return validateNow(showErrors !== false); },
        refresh: function () {
            if (window.PMKConfig && typeof window.PMKConfig.getConfig === "function") {
                return Promise.resolve(window.PMKConfig.getConfig(MODULE_ID)).then(function (cfg) {
                    applyConfig(cfg || DEFAULT_CONFIG);
                    return currentConfig;
                });
            }
            applyConfig(DEFAULT_CONFIG);
            return Promise.resolve(currentConfig);
        }
    };

    window.addEventListener("beforeunload", function () {
        unbindRuntime();
        if (typeof unsubscribe === "function") {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });

    start();
})(window, document);

;window.PMKNonPlugin.loaded.push("118-mail-tel-obligatoire.js");
} catch (error) { window.PMKNonPlugin.errors.push("118-mail-tel-obligatoire.js: "+error.message); console.error("[PMK] 118-mail-tel-obligatoire.js",error); };
try {
//--------------------------------------
//Transfert par lot
/* =====================================================================
   Transfert d'exemplaires en lot - Koha 25.11
   circ/branchtransfers.pl

   A COLLER TEL QUEL dans la preference systeme :
   Administration > Preferences systeme > Look and feel
   (onglet "Interface professionnelle") > IntranetUserJS
   (ne pas entourer de balises <script>, Koha s'en charge).

   Fonctionnement :
   - S'active uniquement sur circ/branchtransfers.pl.
   - Panneau flottant pour coller une liste de codes-barres et transferer.
   - Verifie l'etat de chaque exemplaire avant transfert, sans recharger
     la page a chaque code-barres.
   - Boutons pour copier les ignores / erreurs (presse-papier + notification).
   - Possibilite d'annuler un transfert venant d'etre fait.

   Préparation PimpMyKoha : 2026-09-20
   Module PMK : multi-transfer — Transfert en lot
   Version    : 4.0.0-preplugin

   Le comportement historique et l'interface sont conservés.
   Corrections internes :
   - états checkout/transfer/first_hold chargés via l'endpoint Koha qui
     supporte officiellement ces embeds ;
   - les limites de transfert restent sous l'autorité du POST natif Koha ;
   - « Annuler les réussis » ne cible que les transferts créés par le lot.

   Voir README.md pour l'installation et le detail des cas ignores.
   ===================================================================== */

(function () {
    "use strict";

    var isTransferPage = /\/circ\/branchtransfers\.pl/.test(window.location.pathname);

    var MODULE_ID = "multi-transfer";
    var MODULE_VERSION = "4.0.3-preplugin";
    var STORAGE_KEY = "kohaBatchTransferJob_v3";
    var LAST_REPORT_KEY = "kohaBatchTransferLastReport_v3";
    var PANEL_ID = "batch-transfer-panel";
    var STYLE_ID = "batch-transfer-styles";
    var ITEM_URL = "/cgi-bin/koha/catalogue/moredetail.pl?itemnumber=";

    var DEFAULT_CONFIG = {
        enabled: true,
        defaultSkipOnLoan: true,
        defaultSkipInTransfer: true,
        defaultSkipNotForLoan: true
    };
    var currentConfig = Object.assign({}, DEFAULT_CONFIG);
    var registeredWithPMK = false;
    var unsubscribePMK = null;
    var runtimeInitialized = false;

    function normalizeConfig(raw) {
        raw = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: raw.enabled !== false,
            defaultSkipOnLoan: raw.defaultSkipOnLoan !== false,
            defaultSkipInTransfer: raw.defaultSkipInTransfer !== false,
            defaultSkipNotForLoan: raw.defaultSkipNotForLoan !== false
        };
    }

    /* ------------------------------------------------------------------ */
    /* Storage                                                            */
    /* ------------------------------------------------------------------ */

    function getJob() {
        try {
            var raw = sessionStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            return null;
        }
    }

    function setJob(job) {
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(job));
    }

    function clearJob() {
        sessionStorage.removeItem(STORAGE_KEY);
    }

    function saveLastReport(job) {
        if (!job) return;
        try {
            var report = {
                log: job.log || [],
                total: job.total || 0,
                tobranchcd: job.tobranchcd || "",
                savedAt: Date.now()
            };
            sessionStorage.setItem(LAST_REPORT_KEY, JSON.stringify(report));
            window.__btpLastJob = report;
        } catch (e) {
            window.__btpLastJob = job;
        }
    }

    function getLastReport() {
        if (window.__btpLastJob && window.__btpLastJob.log) return window.__btpLastJob;
        try {
            var raw = sessionStorage.getItem(LAST_REPORT_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            return null;
        }
    }

    /* ------------------------------------------------------------------ */
    /* Utils                                                              */
    /* ------------------------------------------------------------------ */

    function parseBarcodes(text) {
        // Un code-barres est une chaîne opaque : ne jamais le découper sur un espace.
        // Accepte une valeur par ligne ou des listes CSV séparées par ; ou ,.
        // Les espaces *internes* sont conservés, sans conversion numérique.
        var seen = Object.create(null);
        return String(text || "")
            .split(/[\r\n;,]+/)
            .map(function (s) { return s.trim(); })
            .filter(function (s) {
                if (!s || Object.prototype.hasOwnProperty.call(seen, s)) return false;
                seen[s] = true;
                return true;
            });
    }

    function hasExactBarcode(item, barcode) {
        // Koha REST : external_id = items.barcode. Contrôle strict (y compris zéros initiaux).
        return !!item && typeof item.external_id === "string" && item.external_id === barcode;
    }

    function escapeHtml(str) {
        return String(str == null ? "" : str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function itemLinkHtml(barcode, itemId) {
        var safeBarcode = escapeHtml(barcode);
        if (!itemId) return "<strong>" + safeBarcode + "</strong>";
        return (
            '<a class="btp-itemlink" href="' +
            ITEM_URL +
            encodeURIComponent(itemId) +
            '" target="_blank" rel="noopener" title="Fiche exemplaire">' +
            safeBarcode +
            "</a>"
        );
    }

    function getLoggedInBranch() {
        var el =
            document.getElementById("logged-in-branch-code") ||
            document.querySelector("[data-branchcode]") ||
            document.querySelector("#branchselect option[selected]");
        if (el) {
            return (el.getAttribute("data-branchcode") || el.textContent || el.value || "").trim();
        }
        if (typeof logged_in_library_id !== "undefined" && logged_in_library_id) {
            return String(logged_in_library_id);
        }
        return "";
    }

    function getLoggedInBranchLabel() {
        var code = getLoggedInBranch();
        var nameEl =
            document.getElementById("logged-in-branch-name") ||
            document.querySelector("#logged-in-branch-code") ||
            document.querySelector(".logged-in-branch-name");
        var name = nameEl ? (nameEl.textContent || "").replace(/\s+/g, " ").trim() : "";
        if (name && code && name.indexOf(code) === -1) return name + " (" + code + ")";
        if (name) return name;
        if (code) return code;
        return "votre bibliothèque de connexion";
    }

    function cancelLocationWarning() {
        return (
            "Attention : après annulation, Koha considère l'exemplaire comme étant " +
            "sur le site où vous êtes connecté (" +
            getLoggedInBranchLabel() +
            "), et non sur son site d'origine."
        );
    }

    function getCsrfToken() {
        var input = document.querySelector('input[name="csrf_token"]');
        if (input && input.value) return input.value;
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta) return meta.getAttribute("content") || "";
        return "";
    }

    function updateCsrfFromDoc(doc) {
        if (!doc) return;
        var tokenInput = doc.querySelector('input[name="csrf_token"]');
        if (!tokenInput || !tokenInput.value) return;
        document.querySelectorAll('input[name="csrf_token"]').forEach(function (el) {
            el.value = tokenInput.value;
        });
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta) meta.setAttribute("content", tokenInput.value);
    }

    function statusClass(status) {
        if (status === "ok") return "ok";
        if (status === "ignore") return "skip";
        if (status === "annule") return "cancelled";
        return "err";
    }

    function statusLabel(status) {
        if (status === "ok") return "OK";
        if (status === "ignore") return "Ignoré";
        if (status === "annule") return "Annulé";
        return "Erreur";
    }

    function getActiveJob() {
        return getJob() || getLastReport() || null;
    }

    function canCancelEntry(entry) {
        if (!entry || !entry.itemId || entry.cancelled) return false;
        if (entry.status === "ok") return true;
        if (entry.status === "ignore" && entry.code === "in_transfer") return true;
        return false;
    }

    function canBulkCancelEntry(entry) {
        // Sécurité PMK : le bouton global ne doit jamais annuler un transfert
        // qui existait avant le lancement du lot. Les anciens rapports sans
        // ce marqueur restent annulables individuellement, mais pas en masse.
        return canCancelEntry(entry) && entry.createdByCurrentJob === true;
    }

    /* ------------------------------------------------------------------ */
    /* Styles                                                             */
    /* ------------------------------------------------------------------ */

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        var style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent =
            "#" +
            PANEL_ID +
            "{" +
            "--btp-ink:#1c2838;--btp-muted:#5b6b7c;--btp-line:#d5dde6;" +
            "--btp-bg:#f7f9fb;--btp-panel:#ffffff;--btp-accent:#0f6e6a;" +
            "--btp-accent-2:#0b4f4c;--btp-ok:#1f7a3f;--btp-err:#b42318;" +
            "--btp-skip:#9a6700;--btp-shadow:0 14px 40px rgba(28,40,56,.18);" +
            "position:fixed;bottom:18px;right:18px;width:min(420px,calc(100vw - 24px));" +
            "max-height:min(88vh,760px);display:flex;flex-direction:column;" +
            "background:var(--btp-panel);color:var(--btp-ink);border:1px solid var(--btp-line);" +
            "border-radius:14px;box-shadow:var(--btp-shadow);z-index:99999;" +
            "font:14px/1.45 'Segoe UI','Candara','Gill Sans',sans-serif;" +
            "overflow:hidden;}" +
            "#" +
            PANEL_ID +
            " *{box-sizing:border-box;}" +
            "#" +
            PANEL_ID +
            " .btp-header{background:linear-gradient(135deg,var(--btp-accent),var(--btp-accent-2));" +
            "color:#fff;padding:12px 14px;display:flex;justify-content:space-between;" +
            "align-items:center;gap:8px;}" +
            "#" +
            PANEL_ID +
            " .btp-title{font-weight:700;letter-spacing:.01em;}" +
            "#" +
            PANEL_ID +
            " .btp-subtitle{font-size:11px;opacity:.85;margin-top:2px;}" +
            "#" +
            PANEL_ID +
            " .btp-toggle,#" +
            PANEL_ID +
            " .btp-iconbtn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);" +
            "color:#fff;border-radius:8px;width:32px;height:32px;cursor:pointer;font-weight:700;}" +
            "#" +
            PANEL_ID +
            " .btp-body{padding:12px 14px 14px;overflow:auto;display:flex;flex-direction:column;gap:8px;" +
            "background:linear-gradient(180deg,#fff 0%,var(--btp-bg) 100%);min-height:0;}" +
            "#" +
            PANEL_ID +
            " label{display:block;font-size:12px;font-weight:600;color:var(--btp-muted);margin-bottom:4px;}" +
            "#" +
            PANEL_ID +
            " textarea,#" +
            PANEL_ID +
            " select{width:100%;border:1px solid var(--btp-line);border-radius:10px;" +
            "padding:8px 10px;background:#fff;color:var(--btp-ink);}" +
            "#" +
            PANEL_ID +
            " textarea{height:108px;resize:vertical;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;}" +
            "#" +
            PANEL_ID +
            " .btp-checks{display:flex;flex-direction:column;gap:6px;margin:4px 0;}" +
            "#" +
            PANEL_ID +
            " .btp-checkbox{display:flex;align-items:flex-start;gap:8px;font-size:12px;color:var(--btp-ink);}" +
            "#" +
            PANEL_ID +
            " .btp-checkbox input{margin-top:3px;}" +
            "#" +
            PANEL_ID +
            " .btp-checkbox label{margin:0;font-weight:500;color:var(--btp-ink);}" +
            "#" +
            PANEL_ID +
            " .btp-actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px;}" +
            "#" +
            PANEL_ID +
            " .btp-actions button{cursor:pointer;border:none;border-radius:9px;padding:7px 12px;" +
            "font-weight:600;font-size:13px;}" +
            "#" +
            PANEL_ID +
            " #btp-start{background:var(--btp-accent);color:#fff;}" +
            "#" +
            PANEL_ID +
            " #btp-start:hover{background:var(--btp-accent-2);}" +
            "#" +
            PANEL_ID +
            " #btp-stop{background:#f3d6d4;color:var(--btp-err);}" +
            "#" +
            PANEL_ID +
            " .btp-secondary{background:#e8eef3;color:var(--btp-ink);}" +
            "#" +
            PANEL_ID +
            " .btp-secondary:disabled,#" +
            PANEL_ID +
            " button:disabled{opacity:.55;cursor:not-allowed;}" +
            "#" +
            PANEL_ID +
            " .btp-progress{font-size:12px;font-weight:700;color:var(--btp-accent-2);}" +
            "#" +
            PANEL_ID +
            " .btp-summary{display:flex;gap:8px;flex-wrap:wrap;font-size:11px;}" +
            "#" +
            PANEL_ID +
            " .btp-pill{background:#fff;border:1px solid var(--btp-line);border-radius:999px;" +
            "padding:2px 8px;color:var(--btp-muted);}" +
            "#" +
            PANEL_ID +
            " .btp-pill strong{color:var(--btp-ink);}" +
            "#" +
            PANEL_ID +
            " .btp-logwrap{display:flex;flex-direction:column;min-height:0;flex:1;}" +
            "#" +
            PANEL_ID +
            " .btp-loghead{display:flex;justify-content:space-between;align-items:center;" +
            "margin:4px 0 2px;font-size:12px;font-weight:700;}" +
            "#" +
            PANEL_ID +
            " .btp-log{max-height:240px;min-height:120px;overflow:auto;border:1px solid var(--btp-line);" +
            "border-radius:10px;background:#fff;padding:4px;}" +
            "#" +
            PANEL_ID +
            " .btp-row{display:grid;grid-template-columns:64px 1fr auto;gap:6px;padding:7px 8px;" +
            "border-bottom:1px solid #eef2f6;font-size:12px;align-items:start;}" +
            "#" +
            PANEL_ID +
            " .btp-row:last-child{border-bottom:none;}" +
            "#" +
            PANEL_ID +
            " .btp-badge{display:inline-block;border-radius:999px;padding:1px 7px;font-size:10px;" +
            "font-weight:700;text-transform:uppercase;letter-spacing:.04em;align-self:start;}" +
            "#" +
            PANEL_ID +
            " .btp-badge.ok{background:#e8f7ee;color:var(--btp-ok);}" +
            "#" +
            PANEL_ID +
            " .btp-badge.skip{background:#fff4d6;color:var(--btp-skip);}" +
            "#" +
            PANEL_ID +
            " .btp-badge.err{background:#fdecea;color:var(--btp-err);}" +
            "#" +
            PANEL_ID +
            " .btp-badge.cancelled{background:#e8eef3;color:#445566;}" +
            "#" +
            PANEL_ID +
            " .btp-msg{color:var(--btp-ink);word-break:break-word;}" +
            "#" +
            PANEL_ID +
            " .btp-itemlink{color:var(--btp-accent);font-weight:700;text-decoration:none;}" +
            "#" +
            PANEL_ID +
            " .btp-itemlink:hover{text-decoration:underline;}" +
            "#" +
            PANEL_ID +
            " .btp-row-actions{display:flex;flex-direction:column;gap:4px;}" +
            "#" +
            PANEL_ID +
            " .btp-cancel-one{border:1px solid #f0c2be;background:#fdecea;color:var(--btp-err);" +
            "border-radius:7px;padding:3px 7px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;}" +
            "#" +
            PANEL_ID +
            " .btp-cancel-one:disabled{opacity:.5;cursor:not-allowed;}" +
            "#" +
            PANEL_ID +
            " .btp-help{font-size:11px;color:var(--btp-muted);line-height:1.35;}" +
            "#" +
            PANEL_ID +
            " #btp-cancel-help{margin:2px 0 0;padding:8px 10px;background:#fff8e8;border:1px solid #f0e0b2;" +
            "border-radius:10px;color:#6a4b00;}" +
            "#" +
            PANEL_ID +
            " #btp-cancel-help strong{color:#5a3f00;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-layer{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;" +
            "padding:18px;background:rgba(28,40,56,.28);z-index:20;opacity:0;pointer-events:none;" +
            "transition:opacity .2s ease;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-layer.btp-notice-show{opacity:1;pointer-events:auto;}" +
            "#" +
            PANEL_ID +
            " .btp-notice{min-width:220px;width:min(320px,92%);background:#fff;border-radius:14px;" +
            "box-shadow:0 16px 40px rgba(16,24,32,.28);border:1px solid var(--btp-line);padding:16px 18px;" +
            "text-align:center;transform:translateY(8px) scale(.97);transition:transform .2s ease;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-layer.btp-notice-show .btp-notice{transform:translateY(0) scale(1);}" +
            "#" +
            PANEL_ID +
            " .btp-notice-icon{width:36px;height:36px;border-radius:50%;display:inline-flex;align-items:center;" +
            "justify-content:center;font-weight:700;font-size:18px;margin-bottom:8px;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-ok .btp-notice-icon{background:#e8f7ee;color:var(--btp-ok);}" +
            "#" +
            PANEL_ID +
            " .btp-notice-err .btp-notice-icon{background:#fdecea;color:var(--btp-err);}" +
            "#" +
            PANEL_ID +
            " .btp-notice-title{font-weight:700;font-size:14px;margin-bottom:4px;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-text{font-size:12px;color:var(--btp-muted);line-height:1.4;margin-bottom:8px;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-codes{display:none;width:100%;min-height:72px;max-height:140px;margin:0 0 10px;" +
            "padding:8px;border:1px solid var(--btp-line);border-radius:8px;resize:vertical;" +
            "font:12px/1.35 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;box-sizing:border-box;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-codes.btp-notice-codes-show{display:block;}" +
            "#" +
            PANEL_ID +
            " .btp-notice-close{border:none;border-radius:8px;padding:6px 12px;font-weight:600;" +
            "cursor:pointer;background:#e8eef3;color:var(--btp-ink);font-size:12px;}" +
            "#" +
            PANEL_ID +
            " #btp-clipboard-helper{position:absolute;left:-9999px;top:0;width:1px;height:1px;opacity:0;}";
        document.head.appendChild(style);
    }

    /* ------------------------------------------------------------------ */
    /* Panel UI                                                           */
    /* ------------------------------------------------------------------ */

    function buildPanel() {
        var existing = document.getElementById(PANEL_ID);
        if (existing) return existing;

        injectStyles();

        var panel = document.createElement("div");
        panel.id = PANEL_ID;
        panel.innerHTML =
            '<div class="btp-header">' +
            "<div>" +
            '<div class="btp-title">Transfert en lot</div>' +
            '<div class="btp-subtitle">Collez ou scannez une liste, choisissez la destination, lancez</div>' +
            "</div>" +
            '<button type="button" class="btp-toggle" title="Réduire / agrandir" aria-label="Réduire">_</button>' +
            "</div>" +
            '<div class="btp-body">' +
            "<div>" +
            '<label for="btp-tobranch">Bibliothèque de destination</label>' +
            '<select id="btp-tobranch"></select>' +
            "</div>" +
            "<div>" +
            '<label for="btp-barcodes">Codes-barres (un par ligne)</label>' +
            '<textarea id="btp-barcodes" placeholder="B00001&#10;B00002&#10;B00003"></textarea>' +
            "</div>" +
            '<div class="btp-checks">' +
            '<div class="btp-checkbox">' +
            '<input type="checkbox" id="btp-skiploan" />' +
            '<label for="btp-skiploan">Ne pas transférer les exemplaires actuellement empruntés ' +
            "(recommandé : sinon ils seront rendus automatiquement)</label>" +
            "</div>" +
            '<div class="btp-checkbox">' +
            '<input type="checkbox" id="btp-skiptransfer" />' +
            '<label for="btp-skiptransfer">Ignorer les exemplaires déjà en transfert ' +
            "(décochez pour forcer un nouveau transfert)</label>" +
            "</div>" +
            '<div class="btp-checkbox">' +
            '<input type="checkbox" id="btp-skipnfl" />' +
            '<label for="btp-skipnfl">Ne pas transférer les exemplaires exclus du prêt</label>' +
            "</div>" +
            "</div>" +
            '<p class="btp-help">Aussi ignorés automatiquement : introuvable, déjà sur place, ' +
            "réservé, retiré, perdu, ou transfert non autorisé entre bibliothèques.</p>" +
            '<div class="btp-actions">' +
            '<button type="button" id="btp-start">Démarrer</button>' +
            '<button type="button" id="btp-stop" disabled>Arrêter</button>' +
            '<button type="button" id="btp-copy-ignored" class="btp-secondary" disabled>Copier les ignorés</button>' +
            '<button type="button" id="btp-copy-errors" class="btp-secondary" disabled>Copier les erreurs</button>' +
            '<button type="button" id="btp-retry-errors" class="btp-secondary" disabled>Préparer la reprise des erreurs</button>' +
            '<button type="button" id="btp-cancel-oks" class="btp-secondary" disabled title="Annuler les transferts réussis de cette liste">Annuler les réussis</button>' +
            "</div>" +
            '<p class="btp-help" id="btp-cancel-help">' +
            "Si vous annulez un transfert : l'exemplaire sera considéré comme étant sur " +
            "<strong>votre site actuel</strong> (la bibliothèque où vous êtes connecté), " +
            "pas sur son site d'origine.</p>" +
            '<div class="btp-progress" id="btp-progress">Prêt.</div>' +
            '<div class="btp-summary" id="btp-summary"></div>' +
            '<div class="btp-logwrap">' +
            '<div class="btp-loghead"><span>Résultats</span><span id="btp-logcount">0</span></div>' +
            '<div class="btp-log" id="btp-log" aria-live="polite"></div>' +
            "</div>" +
            "</div>" +
            '<div class="btp-notice-layer" id="btp-notice-layer" aria-hidden="true">' +
            '<div class="btp-notice btp-notice-ok" role="dialog" aria-modal="true">' +
            '<div class="btp-notice-icon">✓</div>' +
            '<div class="btp-notice-title" id="btp-notice-title">Copie</div>' +
            '<div class="btp-notice-text" id="btp-notice-text"></div>' +
            '<textarea id="btp-notice-codes" class="btp-notice-codes" spellcheck="false"></textarea>' +
            '<button type="button" class="btp-notice-close" id="btp-notice-close">Fermer</button>' +
            "</div>" +
            "</div>" +
            '<textarea id="btp-clipboard-helper" tabindex="-1" aria-hidden="true"></textarea>';

        document.body.appendChild(panel);

        var defaultSkipLoan = document.getElementById("btp-skiploan");
        var defaultSkipTransfer = document.getElementById("btp-skiptransfer");
        var defaultSkipNfl = document.getElementById("btp-skipnfl");
        if (defaultSkipLoan) defaultSkipLoan.checked = currentConfig.defaultSkipOnLoan !== false;
        if (defaultSkipTransfer) defaultSkipTransfer.checked = currentConfig.defaultSkipInTransfer !== false;
        if (defaultSkipNfl) defaultSkipNfl.checked = currentConfig.defaultSkipNotForLoan !== false;

        var realSelect = document.getElementById("tobranchcd");
        var ourSelect = document.getElementById("btp-tobranch");
        if (realSelect) {
            ourSelect.innerHTML = realSelect.innerHTML;
        } else {
            ourSelect.innerHTML = '<option value="">Chargement…</option>';
            loadLibrariesInto(ourSelect);
        }

        panel.querySelector(".btp-toggle").addEventListener("click", function () {
            var body = panel.querySelector(".btp-body");
            var hidden = body.style.display === "none";
            body.style.display = hidden ? "" : "none";
            this.textContent = hidden ? "_" : "+";
        });

        panel.querySelector("#btp-start").addEventListener("click", startJob);
        panel.querySelector("#btp-stop").addEventListener("click", stopJob);
        panel.querySelector("#btp-copy-ignored").addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            copyBarcodes("ignore", "ignorés");
        });
        panel.querySelector("#btp-copy-errors").addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            copyBarcodes("erreur", "en erreur");
        });
        panel.querySelector("#btp-retry-errors").addEventListener("click", function () {
            if(getJob())return;
            var report=getLastReport();if(!report)return;
            var codes=Array.from(new Set(report.log.filter(function(e){return e.status==='erreur';}).map(function(e){return e.barcode;}).filter(Boolean)));
            document.getElementById('btp-barcodes').value=codes.join('\n');
            if(report.tobranchcd)document.getElementById('btp-tobranch').value=report.tobranchcd;
            setProgress(codes.length+' code(s) en erreur préparé(s). Vérifiez la destination puis cliquez sur Démarrer. Les réussites ne seront pas rejouées.');
        });
        panel.querySelector("#btp-cancel-oks").addEventListener("click", cancelAllOkTransfers);
        panel.querySelector("#btp-notice-layer").addEventListener("click", function (e) {
            if (e.target === e.currentTarget) hideNotice();
        });
        panel.querySelector("#btp-notice-close").addEventListener("click", function (e) {
            e.preventDefault();
            hideNotice();
        });
        panel.querySelector(".btp-notice").addEventListener("click", function (e) {
            e.stopPropagation();
        });

        return panel;
    }

    function loadLibrariesInto(select) {
        fetch("/api/v1/libraries?_per_page=-1", { headers: { Accept: "application/json" }, credentials: "same-origin" })
            .then(function (r) {
                if (!r.ok) throw new Error("HTTP " + r.status);
                return r.json();
            })
            .then(function (libs) {
                select.innerHTML = '<option value="">— Choisir —</option>';
                (libs || []).forEach(function (lib) {
                    var opt = document.createElement("option");
                    opt.value = lib.library_id;
                    opt.textContent = lib.name || lib.library_id;
                    select.appendChild(opt);
                });
            })
            .catch(function () {
                select.innerHTML = '<option value="">Impossible de charger les bibliothèques</option>';
            });
    }

    function setProgress(text) {
        var p = document.getElementById("btp-progress");
        if (p) p.textContent = text;
    }

    function updateSummary(job) {
        var box = document.getElementById("btp-summary");
        if (!box || !job) return;
        var ok = 0;
        var ignore = 0;
        var err = 0;
        var cancelled = 0;
        var cancellable = 0;
        job.log.forEach(function (e) {
            if (e.status === "ok") ok++;
            else if (e.status === "ignore") ignore++;
            else if (e.status === "annule") cancelled++;
            else err++;
            if (canBulkCancelEntry(e)) cancellable++;
        });
        box.innerHTML =
            '<span class="btp-pill">OK <strong>' +
            ok +
            "</strong></span>" +
            '<span class="btp-pill">Ignorés <strong>' +
            ignore +
            "</strong></span>" +
            '<span class="btp-pill">Erreurs <strong>' +
            err +
            "</strong></span>" +
            (cancelled
                ? '<span class="btp-pill">Annulés <strong>' + cancelled + "</strong></span>"
                : "");

        var copyIgnored = document.getElementById("btp-copy-ignored");
        var copyErrors = document.getElementById("btp-copy-errors");
        var cancelOks = document.getElementById("btp-cancel-oks");
        if (copyIgnored) copyIgnored.disabled = ignore === 0;
        if (copyErrors) copyErrors.disabled = err === 0;
        var retry=document.getElementById('btp-retry-errors');if(retry)retry.disabled=err===0||!!getJob();
        if (cancelOks) cancelOks.disabled = cancellable === 0;
    }

    function appendResultRow(entry, entryIndex) {
        var log = document.getElementById("btp-log");
        var count = document.getElementById("btp-logcount");
        if (!log) return;

        var row = document.createElement("div");
        row.className = "btp-row";
        row.setAttribute("data-entry-index", String(entryIndex));

        var actions = "";
        if (canCancelEntry(entry)) {
            actions =
                '<div class="btp-row-actions">' +
                '<button type="button" class="btp-cancel-one" data-entry-index="' +
                entryIndex +
                '">Annuler</button>' +
                "</div>";
        } else {
            actions = "<div></div>";
        }

        row.innerHTML =
            '<div><span class="btp-badge ' +
            statusClass(entry.status) +
            '">' +
            statusLabel(entry.status) +
            "</span></div>" +
            '<div class="btp-msg">' +
            itemLinkHtml(entry.barcode, entry.itemId) +
            " — " +
            escapeHtml(entry.message) +
            "</div>" +
            actions;

        var cancelBtn = row.querySelector(".btp-cancel-one");
        if (cancelBtn) {
            cancelBtn.addEventListener("click", function () {
                cancelTransferAtIndex(Number(cancelBtn.getAttribute("data-entry-index")));
            });
        }

        log.appendChild(row);
        log.scrollTop = log.scrollHeight;
        if (count) count.textContent = String(log.children.length);
    }

    function refreshResultRow(entryIndex) {
        var job = getActiveJob();
        if (!job || !job.log || !job.log[entryIndex]) return;
        var log = document.getElementById("btp-log");
        if (!log) return;
        var row = log.querySelector('.btp-row[data-entry-index="' + entryIndex + '"]');
        if (!row) return;

        var entry = job.log[entryIndex];
        var actions = "";
        if (canCancelEntry(entry)) {
            actions =
                '<div class="btp-row-actions">' +
                '<button type="button" class="btp-cancel-one" data-entry-index="' +
                entryIndex +
                '">Annuler</button>' +
                "</div>";
        } else {
            actions = "<div></div>";
        }
        row.innerHTML =
            '<div><span class="btp-badge ' +
            statusClass(entry.status) +
            '">' +
            statusLabel(entry.status) +
            "</span></div>" +
            '<div class="btp-msg">' +
            itemLinkHtml(entry.barcode, entry.itemId) +
            " — " +
            escapeHtml(entry.message) +
            "</div>" +
            actions;
        var cancelBtn = row.querySelector(".btp-cancel-one");
        if (cancelBtn) {
            cancelBtn.addEventListener("click", function () {
                cancelTransferAtIndex(entryIndex);
            });
        }
        updateSummary(job);
    }

    function renderLog(job) {
        var log = document.getElementById("btp-log");
        if (!log) return;
        log.innerHTML = "";
        (job.log || []).forEach(function (entry, idx) {
            appendResultRow(entry, idx);
        });
        updateSummary(job);
    }

    function renderIdle() {
        var startBtn = document.getElementById("btp-start");
        var stopBtn = document.getElementById("btp-stop");
        var textarea = document.getElementById("btp-barcodes");
        var select = document.getElementById("btp-tobranch");
        ["btp-skiploan", "btp-skiptransfer", "btp-skipnfl"].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.disabled = false;
        });
        if (startBtn) startBtn.disabled = false;
        if (stopBtn) stopBtn.disabled = true;
        if (textarea) textarea.disabled = false;
        if (select) select.disabled = false;
    }

    function renderRunning() {
        var startBtn = document.getElementById("btp-start");
        var stopBtn = document.getElementById("btp-stop");
        var textarea = document.getElementById("btp-barcodes");
        var select = document.getElementById("btp-tobranch");
        ["btp-skiploan", "btp-skiptransfer", "btp-skipnfl"].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.disabled = true;
        });
        if (startBtn) startBtn.disabled = true;
        if (stopBtn) stopBtn.disabled = false;
        if (textarea) textarea.disabled = true;
        if (select) select.disabled = true;
    }

    /* ------------------------------------------------------------------ */
    /* Notice flottante + presse-papier                                   */
    /* ------------------------------------------------------------------ */

    var noticeTimer = null;

    function hideNotice() {
        var layer = document.getElementById("btp-notice-layer");
        var codes = document.getElementById("btp-notice-codes");
        if (!layer) return;
        layer.classList.remove("btp-notice-show");
        layer.setAttribute("aria-hidden", "true");
        if (codes) {
            codes.classList.remove("btp-notice-codes-show");
            codes.value = "";
        }
        if (noticeTimer) {
            clearTimeout(noticeTimer);
            noticeTimer = null;
        }
    }

    function showNotice(title, text, kind, options) {
        options = options || {};
        var layer = document.getElementById("btp-notice-layer");
        var card = layer && layer.querySelector(".btp-notice");
        var titleEl = document.getElementById("btp-notice-title");
        var textEl = document.getElementById("btp-notice-text");
        var iconEl = layer && layer.querySelector(".btp-notice-icon");
        var codes = document.getElementById("btp-notice-codes");
        if (!layer || !card || !titleEl || !textEl) return;

        card.className = "btp-notice " + (kind === "err" ? "btp-notice-err" : "btp-notice-ok");
        if (iconEl) iconEl.textContent = kind === "err" ? "!" : "✓";
        titleEl.textContent = title;
        textEl.textContent = text || "";

        if (codes) {
            if (options.codesText) {
                codes.value = options.codesText;
                codes.classList.add("btp-notice-codes-show");
            } else {
                codes.value = "";
                codes.classList.remove("btp-notice-codes-show");
            }
        }

        layer.setAttribute("aria-hidden", "false");
        layer.classList.remove("btp-notice-show");
        void layer.offsetWidth;
        layer.classList.add("btp-notice-show");

        if (noticeTimer) clearTimeout(noticeTimer);
        // Si des codes sont affiches, on laisse plus longtemps pour Ctrl+C
        var delay = options.codesText ? 8000 : 2400;
        if (options.persist) delay = 0;
        if (delay) {
            noticeTimer = setTimeout(hideNotice, delay);
        }
    }

    // Alias utilise par le reste du script
    function showToast(message, kind) {
        if (kind === "err") showNotice("Attention", message, "err");
        else showNotice("OK", message, "ok");
    }

    function selectAllIn(el) {
        if (!el) return;
        el.focus();
        el.select();
        try {
            el.setSelectionRange(0, el.value.length);
        } catch (e) {
            /* ignore */
        }
        try {
            var range = document.createRange();
            range.selectNodeContents(el);
            var sel = window.getSelection();
            if (sel) {
                sel.removeAllRanges();
                sel.addRange(range);
            }
        } catch (e2) {
            /* ignore */
        }
    }

    // Copie synchrone dans le geste utilisateur (obligatoire pour beaucoup de navigateurs)
    function copyTextNow(text) {
        var helper = document.getElementById("btp-clipboard-helper");
        if (!helper) {
            helper = document.createElement("textarea");
            helper.id = "btp-clipboard-helper";
            helper.setAttribute("aria-hidden", "true");
            helper.tabIndex = -1;
            var panel = document.getElementById(PANEL_ID);
            if (panel) panel.appendChild(helper);
            else document.body.appendChild(helper);
        }

        var previousActive = document.activeElement;
        helper.value = String(text);
        helper.removeAttribute("readonly");
        helper.removeAttribute("disabled");
        // Doit etre "editable" pour execCommand('copy') dans certains navigateurs
        helper.style.cssText =
            "position:fixed;top:0;left:0;width:1px;height:1px;padding:0;margin:0;border:0;outline:none;opacity:0.01;z-index:-1;";

        selectAllIn(helper);

        var ok = false;
        try {
            ok = document.execCommand("copy");
        } catch (e) {
            ok = false;
        }

        // Remettre le helper hors ecran
        helper.style.cssText = "position:absolute;left:-9999px;top:0;width:1px;height:1px;opacity:0;";
        if (previousActive && previousActive.focus) {
            try {
                previousActive.focus();
            } catch (e2) {
                /* ignore */
            }
        }

        return !!ok;
    }

    function barcodesFromDom(status) {
        var badgeClass = status === "ignore" ? "skip" : status === "erreur" ? "err" : status === "ok" ? "ok" : "";
        if (!badgeClass) return [];
        var rows = document.querySelectorAll("#btp-log .btp-row");
        var seen = {};
        var list = [];
        Array.prototype.forEach.call(rows, function (row) {
            var badge = row.querySelector(".btp-badge");
            if (!badge || !badge.classList.contains(badgeClass)) return;
            var link = row.querySelector(".btp-itemlink");
            var strong = row.querySelector(".btp-msg strong");
            var bc = ((link && link.textContent) || (strong && strong.textContent) || "").trim();
            if (!bc || seen[bc]) return;
            seen[bc] = true;
            list.push(bc);
        });
        return list;
    }

    function barcodesForStatus(status) {
        var job = getActiveJob();
        var seen = {};
        var list = [];

        function push(bc) {
            bc = String(bc || "").trim();
            if (!bc || seen[bc]) return;
            seen[bc] = true;
            list.push(bc);
        }

        if (job && job.log && job.log.length) {
            job.log.forEach(function (entry) {
                if (entry.status === status) push(entry.barcode);
            });
        }

        // Secours : lire aussi les lignes affichees a l'ecran
        if (!list.length) {
            barcodesFromDom(status).forEach(push);
        }

        return list;
    }

    function copyBarcodes(status, label) {
        var barcodes = barcodesForStatus(status);
        if (!barcodes.length) {
            showNotice(
                "Rien à copier",
                "Aucun code-barres " + label + " dans les résultats pour le moment.",
                "err"
            );
            return;
        }

        var payload = barcodes.join("\n");
        var copied = copyTextNow(payload);

        function showCopyResult(success) {
            showNotice(
                success ? "Copié dans le presse-papier" : "Prêt à copier",
                success
                    ? barcodes.length +
                          " code" +
                          (barcodes.length > 1 ? "s" : "") +
                          "-barres " +
                          label +
                          ". Vous pouvez les coller (Ctrl+V)."
                    : barcodes.length +
                          " code" +
                          (barcodes.length > 1 ? "s" : "") +
                          "-barres " +
                          label +
                          ". Ils sont sélectionnés ci-dessous : faites Ctrl+C, puis Fermer.",
                success ? "ok" : "err",
                { codesText: payload, persist: !success }
            );

            var codes = document.getElementById("btp-notice-codes");
            if (codes) {
                setTimeout(function () {
                    selectAllIn(codes);
                    if (!success) {
                        try {
                            document.execCommand("copy");
                        } catch (e) {
                            /* ignore */
                        }
                    }
                }, 30);
            }
        }

        showCopyResult(copied);

        // Secours asynchrone (HTTPS uniquement) si la copie synchrone a echoue
        if (
            !copied &&
            navigator.clipboard &&
            window.isSecureContext &&
            typeof navigator.clipboard.writeText === "function"
        ) {
            navigator.clipboard.writeText(payload).then(
                function () {
                    showCopyResult(true);
                },
                function () {
                    /* deja affiche en mode Ctrl+C */
                }
            );
        }
    }

    /* ------------------------------------------------------------------ */
    /* Cancel transfer (via circ/returns.pl — pas d'API REST)             */
    /* ------------------------------------------------------------------ */

    function ensureCsrfToken() {
        var existing = getCsrfToken();
        if (existing) return Promise.resolve(existing);
        return fetch("/cgi-bin/koha/circ/returns.pl", {
            credentials: "same-origin",
            headers: { Accept: "text/html" }
        })
            .then(function (r) {
                return r.text();
            })
            .then(function (html) {
                var doc = new DOMParser().parseFromString(html, "text/html");
                updateCsrfFromDoc(doc);
                return getCsrfToken();
            });
    }


    function fetchTransferStateForItem(itemId) {
        return apiGet("/api/v1/items/" + encodeURIComponent(itemId)).then(function (item) {
            var biblioId = item && item.biblio_id;
            if (!biblioId) throw new Error("biblio_id absent");
            var filter = encodeURIComponent(JSON.stringify({ item_id: itemId }));
            var url =
                "/api/v1/biblios/" +
                encodeURIComponent(biblioId) +
                "/items?q=" +
                filter +
                "&_per_page=1";
            return fetch(url, {
                headers: { Accept: "application/json", "x-koha-embed": "transfer" },
                credentials: "same-origin"
            }).then(function (resp) {
                if (!resp.ok) throw new Error("HTTP " + resp.status);
                return resp.json();
            }).then(function (items) {
                return items && items.length ? items[0].transfer || null : null;
            });
        });
    }

    // Relecture stricte APRES écriture. Une réponse HTML ne suffit pas à
    // déclarer un transfert réalisé. On vérifie l'identité exacte + la destination.
    function fetchVerifiedTransferState(itemId, expectedBarcode) {
        return apiGet("/api/v1/items/" + encodeURIComponent(itemId)).then(function (seed) {
            if (!seed || String(seed.item_id) !== String(itemId) || !hasExactBarcode(seed, expectedBarcode)) {
                throw new Error("L'identité de l'exemplaire a changé ou ne correspond pas au code-barres saisi.");
            }
            if (!seed.biblio_id) throw new Error("Notice bibliographique non identifiée.");
            var query = encodeURIComponent(JSON.stringify({item_id: itemId}));
            return fetch("/api/v1/biblios/" + encodeURIComponent(seed.biblio_id) +
                "/items?q=" + query + "&_per_page=1", {
                credentials: "same-origin",
                headers: {Accept: "application/json", "x-koha-embed": "transfer"}
            }).then(function (response) {
                if (!response.ok) throw new Error("Lecture du transfert impossible (HTTP " + response.status + ").");
                return response.json();
            }).then(function (items) {
                if (!Array.isArray(items) || items.length !== 1 ||
                    String(items[0].item_id) !== String(itemId) ||
                    !hasExactBarcode(items[0], expectedBarcode)) {
                    throw new Error("La réponse Koha ne confirme pas l'identité exacte de l'exemplaire.");
                }
                return items[0].transfer || null;
            });
        });
    }

    function transferFingerprint(transfer) {
        if (!transfer) return "";
        return JSON.stringify([
            transfer.transfer_id == null ? "" : String(transfer.transfer_id),
            transfer.from_library_id || transfer.frombranch || "",
            transfer.to_library_id || transfer.tobranch || "",
            transfer.date_sent || transfer.datesent || "",
            transfer.date_arrived || transfer.datearrived || ""
        ]);
    }

    function verifyTransferAfterPost(itemId, barcode, destination, previousTransfer, htmlResult) {
        return fetchVerifiedTransferState(itemId, barcode).then(function (current) {
            if (!current) {
                return {success: false, status: "erreur", code: "transfer_not_confirmed",
                    message: "Transfert non confirmé : aucun transfert actif retrouvé dans Koha après l'envoi. Vérifiez la fiche."};
            }
            var actualDestination = String(current.to_library_id || current.tobranch || "");
            if (actualDestination !== String(destination)) {
                return {success: false, status: "erreur", code: "transfer_wrong_destination",
                    message: "Transfert non conforme : Koha indique la destination " +
                        (actualDestination || "inconnue") + " au lieu de " + destination + ". Vérification manuelle nécessaire."};
            }
            if (previousTransfer && transferFingerprint(previousTransfer) === transferFingerprint(current)) {
                return {success: false, status: "erreur", code: "transfer_not_new",
                    message: "Transfert vers " + destination + " visible dans Koha, mais déjà présent avant cette opération : aucune nouvelle action prouvée."};
            }
            var msg = "Transfert confirmé dans Koha vers " + actualDestination +
                " (exemplaire n° " + itemId + ", code-barres exact : " + barcode + ").";
            if (!htmlResult.success) {
                msg += " Attention : la réponse HTML ne confirmait pas le résultat ; état Koha relu après envoi.";
            }
            return {success: true, status: "ok", code: "verified_transfer", message: msg};
        }).catch(function (error) {
            return {success: false, status: "erreur", code: "transfer_verification_unavailable",
                message: "Résultat non vérifiable après envoi : " +
                    (error && error.message ? error.message : "lecture Koha impossible") +
                    ". Le transfert peut avoir été effectué : vérifiez dans Koha avant de relancer."};
        });
    }

    function postCancelTransfer(itemId) {
        return ensureCsrfToken().then(function (csrf) {
            if (!csrf) {
                return { ok: false, message: "Session invalide — rechargez la page." };
            }
            var body = new URLSearchParams();
            body.set("itemnumber", String(itemId));
            body.set("canceltransfer", "1");
            body.set("csrf_token", csrf);

            return fetch("/cgi-bin/koha/circ/returns.pl", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                    Accept: "text/html"
                },
                body: body.toString()
            }).then(function (resp) {
                return resp.text().then(function (html) {
                    var doc = new DOMParser().parseFromString(html, "text/html");
                    updateCsrfFromDoc(doc);
                    if (resp.status >= 400) {
                        return { ok: false, message: "L'annulation a échoué. Réessayez ou faites-le à la main." };
                    }
                    // Vérification via l'endpoint qui supporte officiellement l'embed transfer.
                    return fetchTransferStateForItem(itemId)
                        .then(function (transfer) {
                            if (transfer) {
                                return {
                                    ok: false,
                                    message: "Le transfert est encore actif — vérifiez à la main."
                                };
                            }
                            return { ok: true };
                        })
                        .catch(function () {
                            if (/transfercancelled|transfert annul|Transfer cancelled/i.test(html)) {
                                return { ok: true };
                            }
                            return { ok: false, message: "Impossible de confirmer l'annulation." };
                        });
                });
            });
        });
    }

    function cancelTransferAtIndex(entryIndex, options) {
        options = options || {};
        var job = getActiveJob();
        if (!job || !job.log || !job.log[entryIndex]) return Promise.resolve(false);
        var entry = job.log[entryIndex];
        if (!canCancelEntry(entry)) return Promise.resolve(false);

        if (!options.silentConfirm) {
            var okConfirm = window.confirm(
                "Annuler le transfert de " +
                    entry.barcode +
                    " ?\n\n" +
                    cancelLocationWarning()
            );
            if (!okConfirm) return Promise.resolve(false);
        }

        var rowBtn = document.querySelector(
            '.btp-row[data-entry-index="' + entryIndex + '"] .btp-cancel-one'
        );
        if (rowBtn) {
            rowBtn.disabled = true;
            rowBtn.textContent = "…";
        }

        return postCancelTransfer(entry.itemId)
            .then(function (result) {
                var j = getActiveJob();
                if (!j || !j.log[entryIndex]) return false;
                if (result.ok) {
                    var siteLabel = getLoggedInBranchLabel();
                    j.log[entryIndex].status = "annule";
                    j.log[entryIndex].cancelled = true;
                    j.log[entryIndex].code = "cancelled";
                    j.log[entryIndex].message =
                        "Transfert annulé — site actuel = " +
                        siteLabel +
                        " (pas le site d'origine).";
                    if (getJob()) setJob(j);
                    saveLastReport(j);
                    refreshResultRow(entryIndex);
                    if (!options.silentToast) {
                        showNotice(
                            "Transfert annulé",
                            entry.barcode +
                                " — l'exemplaire est maintenant considéré sur " +
                                siteLabel +
                                ", pas sur son site d'origine.",
                            "ok"
                        );
                    }
                    return true;
                }
                if (rowBtn) {
                    rowBtn.disabled = false;
                    rowBtn.textContent = "Annuler";
                }
                if (!options.silentToast) {
                    showNotice("Annulation impossible", result.message || "Réessayez plus tard.", "err");
                }
                return false;
            })
            .catch(function () {
                if (rowBtn) {
                    rowBtn.disabled = false;
                    rowBtn.textContent = "Annuler";
                }
                if (!options.silentToast) {
                    showNotice("Annulation impossible", "Une erreur est survenue.", "err");
                }
                return false;
            });
    }

    function cancelAllOkTransfers() {
        var job = getActiveJob();
        if (!job || !job.log) {
            showNotice("Rien à annuler", "Aucun transfert dans les résultats.", "err");
            return;
        }
        var indexes = [];
        job.log.forEach(function (e, idx) {
            if (canBulkCancelEntry(e)) indexes.push(idx);
        });
        if (!indexes.length) {
            showNotice("Rien à annuler", "Aucun transfert réussi à annuler.", "err");
            return;
        }
        var okConfirm = window.confirm(
            "Annuler " +
                indexes.length +
                " transfert(s) de cette liste ?\n\n" +
                cancelLocationWarning() +
                "\n\nCela vaut pour chaque exemplaire annulé."
        );
        if (!okConfirm) return;

        var btn = document.getElementById("btp-cancel-oks");
        if (btn) btn.disabled = true;

        var chain = Promise.resolve();
        var done = 0;
        var fail = 0;
        indexes.forEach(function (idx) {
            chain = chain.then(function () {
                return cancelTransferAtIndex(idx, { silentConfirm: true, silentToast: true }).then(function (ok) {
                    if (ok) done++;
                    else fail++;
                });
            });
        });
        chain.then(function () {
            if (btn) btn.disabled = false;
            updateSummary(getActiveJob());
            var siteLabel = getLoggedInBranchLabel();
            if (fail === 0) {
                showNotice(
                    "Annulations terminées",
                    done +
                        " transfert(s) annulé(s). Site actuel pour ces exemplaires : " +
                        siteLabel +
                        " (pas le site d'origine).",
                    "ok"
                );
            } else {
                showNotice(
                    "Annulations partielles",
                    done +
                        " annulé(s), " +
                        fail +
                        " échec(s). Pour les annulés : site actuel = " +
                        siteLabel +
                        ".",
                    "err"
                );
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* API pre-checks                                                     */
    /* ------------------------------------------------------------------ */

    function apiGet(url) {
        return fetch(url, {
            headers: { Accept: "application/json" },
            credentials: "same-origin"
        }).then(function (resp) {
            if (!resp.ok) {
                var err = new Error("HTTP " + resp.status);
                err.status = resp.status;
                throw err;
            }
            return resp.json();
        });
    }

    function fetchItemBundle(barcode) {
        var q = "/api/v1/items?external_id=" + encodeURIComponent(barcode) + "&_match=exact&_per_page=2";
        return apiGet(q).then(function (items) {
            if (!items || !items.length) {
                return { errorCode: "not_found", message: "Code-barres inconnu : aucun exemplaire trouvé." };
            }

            // Même avec _match=exact, ne jamais faire confiance à l'ordre des résultats.
            // Un code-barres doit correspondre à un seul exemplaire, strictement.
            var exactItems = items.filter(function (item) { return hasExactBarcode(item, barcode); });
            if (exactItems.length !== 1 || items.length !== 1) {
                return {
                    errorCode: "barcode_mismatch",
                    message: "Recherche API non univoque pour ce code-barres (" +
                        exactItems.length + " correspondance(s) exacte(s), " + items.length +
                        " résultat(s)). Aucun transfert effectué."
                };
            }
            var seed = exactItems[0];
            var itemId = seed.item_id;
            var biblioId = seed.biblio_id;

            if (!itemId) {
                return { errorCode: "not_found", message: "Code-barres inconnu : aucun exemplaire exploitable trouvé." };
            }

            // Koha 24.11/25.11 documente checkout, transfer, first_hold et
            // _status sur GET /biblios/{biblio_id}/items, pas sur GET /items/{id}.
            // On cible l'item précis via q={item_id:...}.
            if (biblioId) {
                var itemFilter = encodeURIComponent(JSON.stringify({ item_id: itemId }));
                var biblioItemsUrl =
                    "/api/v1/biblios/" +
                    encodeURIComponent(biblioId) +
                    "/items?q=" +
                    itemFilter +
                    "&_per_page=1";

                return fetch(biblioItemsUrl, {
                    headers: {
                        Accept: "application/json",
                        "x-koha-embed": "checkout,transfer,first_hold,_status"
                    },
                    credentials: "same-origin"
                })
                    .then(function (resp) {
                        if (!resp.ok) throw new Error("HTTP " + resp.status);
                        return resp.json();
                    })
                    .then(function (enrichedItems) {
                        var item = enrichedItems && enrichedItems.length ? enrichedItems[0] : null;
                        if (!item || String(item.item_id) !== String(itemId) || !hasExactBarcode(item, barcode)) {
                            throw new Error("Identité de l'exemplaire non vérifiée");
                        }
                        return { item: item, itemId: itemId, biblioId: biblioId };
                    })
                    .catch(function () {
                        return fetchItemBundleFallback(seed, itemId, biblioId, barcode);
                    });
            }

            return fetchItemBundleFallback(seed, itemId, biblioId, barcode);
        });
    }

    function fetchItemBundleFallback(seed, itemId, biblioId, barcode) {
        return apiGet("/api/v1/items/" + encodeURIComponent(itemId))
            .catch(function () { return seed || {}; })
            .then(function (item) {
                if (String(item.item_id) !== String(itemId) || !hasExactBarcode(item, barcode)) {
                    return { errorCode: "barcode_mismatch", message: "Incohérence entre le code-barres demandé et la fiche exemplaire. Transfert bloqué." };
                }
                var filter = encodeURIComponent(JSON.stringify({ item_id: itemId }));
                return apiGet("/api/v1/checkouts?q=" + filter)
                    .then(function (checkouts) {
                        item.checkout = checkouts && checkouts.length ? checkouts[0] : null;
                        return {
                            item: item,
                            itemId: itemId,
                            biblioId: biblioId || item.biblio_id || null,
                            unverifiedTransferHold: true
                        };
                    })
                    .catch(function () {
                        return {
                            item: item,
                            itemId: itemId,
                            biblioId: biblioId || item.biblio_id || null,
                            unverifiedCheckout: true,
                            unverifiedTransferHold: true
                        };
                    });
            });
    }

    function evaluateSkip(itemBundle, job) {
        if (itemBundle.errorCode) {
            return {
                skip: true,
                status: "erreur",
                code: itemBundle.errorCode,
                message: itemBundle.message,
                itemId: null
            };
        }

        var item = itemBundle.item;
        var itemId = itemBundle.itemId;
        var holding = item.holding_library_id || "";
        var to = job.tobranchcd;
        var loginBranch = job.loginBranch || "";

        if (loginBranch && to === loginBranch) {
            return {
                skip: true,
                status: "ignore",
                code: "dest_is_login",
                message: "La destination est votre bibliothèque actuelle : transfert impossible.",
                itemId: itemId
            };
        }

        if (holding && holding === to) {
            return {
                skip: true,
                status: "ignore",
                code: "already_at_dest",
                message: "Déjà sur place à la bibliothèque de destination.",
                itemId: itemId
            };
        }

        if (item.withdrawn && Number(item.withdrawn) > 0) {
            return {
                skip: true,
                status: "ignore",
                code: "withdrawn",
                message: "Exemplaire retiré du fonds — à traiter à la main.",
                itemId: itemId
            };
        }

        if (item.lost_status && Number(item.lost_status) > 0) {
            return {
                skip: true,
                status: "ignore",
                code: "lost",
                message: "Exemplaire marqué perdu — à traiter à la main.",
                itemId: itemId
            };
        }

        var nfl = item.effective_not_for_loan_status != null ? item.effective_not_for_loan_status : item.not_for_loan_status;
        if (job.skipNotForLoan && nfl != null && Number(nfl) !== 0) {
            return {
                skip: true,
                status: "ignore",
                code: "not_for_loan",
                message: "Exemplaire exclu du prêt — ignoré.",
                itemId: itemId
            };
        }

        if (item.transfer) {
            var tr = item.transfer;
            var from = tr.from_library_id || tr.frombranch || "?";
            var dest = tr.to_library_id || tr.tobranch || "?";
            var datesent = tr.datesent || tr.date_sent;
            var state = datesent ? "déjà en route" : "transfert déjà demandé";
            if (job.skipInTransfer !== false) {
                return {
                    skip: true,
                    status: "ignore",
                    code: "in_transfer",
                    message: state + " (" + from + " → " + dest + ") — ignoré.",
                    itemId: itemId
                };
            }
            // Forcer : on continue, Koha remplacera en principe le transfert existant
            return {
                skip: false,
                warning: "Attention : un transfert existait déjà (" + state + " : " + from + " → " + dest + ") — forcé.",
                itemId: itemId,
                holding: holding
            };
        }

        var hold = item.first_hold;
        if (hold) {
            var holdStatus = hold.status || hold.found || "";
            var holdBranch = hold.pickup_library_id || hold.branchcode || "?";
            var holdLabel = "Une réservation existe";
            if (/^W$/i.test(holdStatus) || /waiting/i.test(String(holdStatus))) {
                holdLabel = "Réservation en attente";
            } else if (/^T$/i.test(holdStatus) || /transit/i.test(String(holdStatus))) {
                holdLabel = "Réservation en transit";
            }
            return {
                skip: true,
                status: "ignore",
                code: "hold",
                message: holdLabel + " (retrait : " + holdBranch + ") — décision manuelle nécessaire.",
                itemId: itemId
            };
        }

        var onLoan = !!(item.checkout || item.checked_out_date);
        if (job.skipOnLoan && onLoan) {
            return {
                skip: true,
                status: "ignore",
                code: "on_loan",
                message: "Actuellement emprunté — ignoré.",
                itemId: itemId
            };
        }

        if (!job.skipOnLoan && onLoan) {
            return {
                skip: false,
                warning: "Attention : il était emprunté et a été rendu automatiquement.",
                itemId: itemId,
                onLoan: true
            };
        }

        if (itemBundle.unverifiedCheckout && job.skipOnLoan) {
            return {
                skip: true,
                status: "ignore",
                code: "checkout_unverified",
                message: "Impossible de vérifier s'il est emprunté — ignoré par précaution.",
                itemId: itemId
            };
        }

        return { skip: false, itemId: itemId, holding: holding };
    }

    function checkTransferLimit(fromBranch, toBranch, item) {
        // PMK 4.0 : ne bloque plus avant le POST. Les préférences système
        // UseBranchTransferLimits / BranchTransferLimitsType et la logique
        // serveur Koha restent l'autorité. La fonction est conservée comme
        // point d'extension compatible, mais retourne toujours null.
        return Promise.resolve(null);
    }

    /* ------------------------------------------------------------------ */
    /* Transfer via AJAX form POST (no full page reload)                  */
    /* ------------------------------------------------------------------ */

    function postTransfer(barcode, tobranchcd) {
        var csrf = getCsrfToken();
        if (!csrf) {
            return Promise.resolve({
                success: false,
                status: "erreur",
                message: "Session invalide — rechargez la page puis réessayez."
            });
        }

        var body = new URLSearchParams();
        body.set("op", "cud-transfer");
        body.set("barcode", barcode);
        body.set("tobranchcd", tobranchcd);
        body.set("csrf_token", csrf);

        var action =
            (document.querySelector("#branchtransfers") && document.querySelector("#branchtransfers").getAttribute("action")) ||
            window.location.pathname;

        return fetch(action, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
                Accept: "text/html"
            },
            body: body.toString()
        }).then(function (resp) {
            return resp.text().then(function (html) {
                var parser = new DOMParser();
                var doc = parser.parseFromString(html, "text/html");
                updateCsrfFromDoc(doc);
                return interpretTransferHtml(doc, barcode, tobranchcd, resp.status);
            });
        });
    }

    function textOf(nodes) {
        return Array.prototype.map
            .call(nodes, function (n) {
                return (n.textContent || "").replace(/\s+/g, " ").trim();
            })
            .filter(Boolean);
    }

    function interpretTransferHtml(doc, barcode, tobranchcd, httpStatus) {
        if (httpStatus >= 400) {
            return {
                success: false,
                status: "erreur",
                message: "Le transfert a échoué (erreur serveur)."
            };
        }

        // Modal réservation / hold found
        var confirm = doc.getElementById("transfer_confirm");
        if (confirm) {
            return {
                success: false,
                status: "ignore",
                code: "hold_modal",
                message: "Une réservation bloque ce transfert — à traiter à la main."
            };
        }

        // Erreurs connues
        var alerts = textOf(doc.querySelectorAll(".alert, .dialog.alert, .alert-info, .alert-warning, .alert-error"));
        var joined = alerts.join(" / ");

        if (/No item with barcode|Aucun exemplaire avec le code/i.test(joined)) {
            return { success: false, status: "erreur", code: "bad_barcode", message: joined || "Code-barres inconnu." };
        }
        if (/already at destination|déjà à la bibliothèque de destination|deja a la bibliotheque de destination|already at destination library/i.test(joined)) {
            return {
                success: false,
                status: "ignore",
                code: "already_at_dest",
                message: "Déjà à la bibliothèque de destination."
            };
        }
        if (/Transfer is not allowed|transfert n'est pas autorisé|transfert n'est pas autorise|n'est pas autorisé|n'est pas autorise/i.test(joined)) {
            return {
                success: false,
                status: "ignore",
                code: "transfer_limit",
                message: "Transfert non autorisé entre ces bibliothèques."
            };
        }

        // Succès : barcode présent dans la table / champs cachés bc-
        var inputs = doc.querySelectorAll('#branchtransfers input[type="hidden"][name^="bc-"], input[name^="bc-"]');
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].value === barcode) {
                var idx = (inputs[i].name.match(/^bc-(\d+)$/) || [])[1];
                var confirmed = tobranchcd;
                if (idx != null) {
                    var tb = doc.querySelector('input[name="tb-' + idx + '"]');
                    if (tb && tb.value) confirmed = tb.value;
                }
                var msg = "Transféré vers " + confirmed;
                if (/has been returned|a été rendu|a ete rendu|was on loan|était en prêt|etait en pret/i.test(joined)) {
                    msg += " (il était emprunté et a été rendu automatiquement).";
                }
                return { success: true, status: "ok", message: msg };
            }
        }

        // Ne jamais valider un transfert sur une correspondance partielle
        // (ex. 12345 présent dans 123456). Seuls les champs bc-* exacts font foi.

        if (joined) {
            return { success: false, status: "erreur", message: joined };
        }

        return {
            success: false,
            status: "erreur",
            message: "Échec : raison non reconnue. Vérifiez l'exemplaire à la main."
        };
    }

    /* ------------------------------------------------------------------ */
    /* Job orchestration                                                  */
    /* ------------------------------------------------------------------ */

    function logResult(job, barcode, status, message, itemId, code, createdByCurrentJob) {
        var entry = {
            barcode: barcode,
            status: status,
            message: message,
            itemId: itemId || null,
            code: code || null,
            cancelled: false,
            createdByCurrentJob: createdByCurrentJob === true
        };
        job.log.push(entry);
        setJob(job);
        saveLastReport(job);
        setProgress(job.log.length + " / " + job.total + " traité(s)…");
        appendResultRow(entry, job.log.length - 1);
        updateSummary(job);
    }

    function stopJob() {
        var job = getJob();
        if (job) {
            job.stopped = true;
            setJob(job);
            window.__btpLastJob = job;
        }
        setProgress("Arrêt demandé… fin du code-barres en cours.");
    }

    function finishJob(job) {
        saveLastReport(job);
        clearJob();
        renderIdle();
        setProgress("Terminé : " + job.log.length + " / " + job.total + ".");
        updateSummary(job);
        // Remettre les CB restants (si arret) dans le textarea
        var textarea = document.getElementById("btp-barcodes");
        if (textarea && job.queue && job.queue.length) {
            textarea.value = job.queue.join("\n");
        } else if (textarea) {
            textarea.value = "";
        }
    }

    function startJob() {
        var textarea = document.getElementById("btp-barcodes");
        var select = document.getElementById("btp-tobranch");
        var skipLoan = document.getElementById("btp-skiploan");
        var skipTransfer = document.getElementById("btp-skiptransfer");
        var skipNfl = document.getElementById("btp-skipnfl");
        var barcodes = parseBarcodes(textarea.value);

        if (!barcodes.length) {
            showNotice("Liste vide", "Ajoutez au moins un code-barres.", "err");
            return;
        }
        if (!select.value) {
            showNotice("Destination manquante", "Choisissez une bibliothèque de destination.", "err");
            return;
        }
        if (!document.querySelector("#branchtransfers") && !document.querySelector('form[name="branchtransfers"]')) {
            // le formulaire peut s'appeler #branchtransfers
            if (!document.querySelector("form")) {
                alert("Formulaire de transfert introuvable sur la page.");
                return;
            }
        }

        var job = {
            queue: barcodes,
            total: barcodes.length,
            tobranchcd: select.value,
            skipOnLoan: !!(skipLoan && skipLoan.checked),
            skipInTransfer: !!(skipTransfer && skipTransfer.checked),
            skipNotForLoan: !!(skipNfl && skipNfl.checked),
            loginBranch: getLoggedInBranch(),
            stopped: false,
            log: []
        };
        setJob(job);
        window.__btpLastJob = job;
        renderRunning();
        document.getElementById("btp-log").innerHTML = "";
        document.getElementById("btp-logcount").textContent = "0";
        updateSummary(job);
        setProgress("Démarrage — 0 / " + job.total + "…");
        processNext();
    }

    function processNext() {
        var job = getJob();
        if (!job) return;

        if (job.stopped) {
            finishJob(job);
            setProgress("Arrêté : " + job.log.length + " / " + job.total + " traité(s). CB restants conservés.");
            return;
        }

        if (!job.queue.length) {
            finishJob(job);
            return;
        }

        var next = job.queue.shift();
        setJob(job);

        fetchItemBundle(next)
            .then(function (bundle) {
                var current = getJob();
                if (!current) return;

                var decision = evaluateSkip(bundle, current);
                if (decision.skip) {
                    logResult(current, next, decision.status, decision.message, decision.itemId, decision.code);
                    processNext();
                    return;
                }

                var fromBranch = decision.holding || current.loginBranch;
                var limitPromise = bundle.item
                    ? checkTransferLimit(fromBranch, current.tobranchcd, bundle.item)
                    : Promise.resolve(null);

                return limitPromise.then(function (limitSkip) {
                    var j = getJob();
                    if (!j) return;
                    if (limitSkip) {
                        logResult(j, next, limitSkip.status, limitSkip.message, limitSkip.itemId, limitSkip.code);
                        processNext();
                        return;
                    }

                    if (!bundle.item || !hasExactBarcode(bundle.item, next) ||
                        String(bundle.item.item_id) !== String(decision.itemId)) {
                        logResult(j, next, "erreur", "Identité exemplaire/code-barres non confirmée : aucun transfert effectué.", decision.itemId || null, "barcode_mismatch");
                        processNext();
                        return;
                    }
                    // Conserver l'état AVANT écriture pour ne jamais présenter un
                    // ancien transfert comme un succès du lot courant.
                    return fetchVerifiedTransferState(decision.itemId, next).then(function (before) {
                        return postTransfer(next, j.tobranchcd).then(function (htmlResult) {
                            // Quoi que dise le HTML, l'état réellement enregistré
                            // dans Koha est l'unique source du badge OK.
                            return verifyTransferAfterPost(decision.itemId, next, j.tobranchcd, before, htmlResult);
                        });
                    }).catch(function (error) {
                        return {success: false, status: "erreur", code: "precheck_unavailable",
                            message: "Opération interrompue ou non vérifiable : lecture Koha ou envoi échoué (" +
                                (error && error.message ? error.message : error) + "). Vérifiez Koha avant de relancer."};
                    }).then(function (result) {
                        var j2 = getJob();
                        if (!j2) return;
                        var message = result.message;
                        if (result.success && decision.warning) {
                            message += " — " + decision.warning;
                        }
                        logResult(
                            j2,
                            next,
                            result.status || (result.success ? "ok" : "erreur"),
                            message,
                            decision.itemId || (bundle.item && bundle.item.item_id) || null,
                            result.code || null,
                            result.success === true
                        );
                        processNext();
                    });
                });
            })
            .catch(function (e) {
                var j = getJob();
                if (!j) return;
                logResult(
                    j,
                    next,
                    "erreur",
                    "Erreur inattendue : " + (e && e.message ? e.message : e),
                    null,
                    "exception"
                );
                processNext();
            });
    }

    /* ------------------------------------------------------------------ */
    /* Init                                                               */
    /* ------------------------------------------------------------------ */

    function applyDefaultCheckboxes() {
        // Ne jamais modifier les choix d'un job actif/repris.
        var active = getJob();
        if (active && active.queue && active.queue.length && !active.stopped) return;
        var skipLoan = document.getElementById("btp-skiploan");
        var skipTransfer = document.getElementById("btp-skiptransfer");
        var skipNfl = document.getElementById("btp-skipnfl");
        if (skipLoan) skipLoan.checked = currentConfig.defaultSkipOnLoan !== false;
        if (skipTransfer) skipTransfer.checked = currentConfig.defaultSkipInTransfer !== false;
        if (skipNfl) skipNfl.checked = currentConfig.defaultSkipNotForLoan !== false;
    }

    function removeRuntimeUi() {
        var panel = document.getElementById(PANEL_ID);
        if (panel) panel.remove();
        var style = document.getElementById(STYLE_ID);
        if (style) style.remove();
        runtimeInitialized = false;
    }

    function initRuntime() {
        if (!currentConfig.enabled) return;
        if (runtimeInitialized && document.getElementById(PANEL_ID)) {
            applyDefaultCheckboxes();
            return;
        }
        runtimeInitialized = true;
        buildPanel();
        var job = getJob();
        if (job && job.stopped && job.queue && job.queue.length) {
            saveLastReport(job);
            clearJob();
            renderIdle();
            renderLog(job);
            var stoppedTextarea = document.getElementById("btp-barcodes");
            var stoppedSelect = document.getElementById("btp-tobranch");
            if (stoppedTextarea) stoppedTextarea.value = job.queue.join("\n");
            if (stoppedSelect) stoppedSelect.value = job.tobranchcd;
            setProgress("Lot interrompu : " + job.log.length + " / " + job.total + " traité(s). Les " + job.queue.length + " code(s)-barres restant(s) sont prêts à reprendre.");
            updateSummary(job);
            applyDefaultCheckboxes();
        } else if (job && job.queue && job.queue.length && !job.stopped) {
            renderRunning();
            var textarea = document.getElementById("btp-barcodes");
            var select = document.getElementById("btp-tobranch");
            if (textarea) textarea.value = job.queue.join("\n");
            if (select) select.value = job.tobranchcd;
            var skipLoan = document.getElementById("btp-skiploan");
            var skipTransfer = document.getElementById("btp-skiptransfer");
            var skipNfl = document.getElementById("btp-skipnfl");
            if (skipLoan) skipLoan.checked = !!job.skipOnLoan;
            if (skipTransfer) skipTransfer.checked = job.skipInTransfer !== false;
            if (skipNfl) skipNfl.checked = job.skipNotForLoan !== false;
            renderLog(job);
            setProgress("Reprise — " + job.log.length + " / " + job.total + "…");
            processNext();
        } else if (job && job.log && job.log.length && (!job.queue || !job.queue.length)) {
            saveLastReport(job);
            clearJob();
            renderIdle();
            renderLog(job);
            setProgress("Dernier rapport restauré (" + job.log.length + " ligne(s)).");
            applyDefaultCheckboxes();
        } else {
            renderIdle();
            applyDefaultCheckboxes();
            var last = getLastReport();
            if (last && last.log && last.log.length) {
                renderLog(last);
                setProgress("Dernier rapport disponible (" + last.log.length + " ligne(s)).");
            }
        }
    }

    function applyConfig(raw) {
        currentConfig = normalizeConfig(raw);
        if (!isTransferPage) return;
        if (!currentConfig.enabled) {
            // Si un traitement est en cours, on demande un arrêt propre après le CB courant.
            var running = getJob();
            if (running && running.queue && running.queue.length && !running.stopped) {
                running.stopped = true;
                setJob(running);
            }
            removeRuntimeUi();
            return;
        }
        initRuntime();
        applyDefaultCheckboxes();
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Transfert en lot", en: "Batch transfer" },
            description: {
                fr: "Conserve le panneau historique du script 119 sur branchtransfers.pl pour transférer séquentiellement une liste de codes-barres. Les réglages PMK définissent uniquement l'activation et l'état initial des trois sécurités du panneau.",
                en: "Keeps the historical script 119 panel on branchtransfers.pl to sequentially transfer a barcode list. PMK settings only control activation and the initial state of the panel's three safety options."
            },
            category: { fr: "Réservations et transferts", en: "Holds and transfers" },
            supportedPages: ["/cgi-bin/koha/circ/branchtransfers.pl"],
            prerequisites: [],
            dependencies: [],
            defaults: Object.assign({}, DEFAULT_CONFIG),
            schema: [
                {
                    type: "section",
                    id: "activation",
                    label: { fr: "Activation", en: "Activation" },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer Transfert en lot", en: "Enable Batch transfer" } }
                    ]
                },
                {
                    type: "section",
                    id: "defaults",
                    label: { fr: "Valeurs par défaut du panneau", en: "Panel defaults" },
                    description: {
                        fr: "Ces réglages déterminent uniquement l'état initial des trois cases. L'agent peut toujours les modifier avant de démarrer un lot.",
                        en: "These settings only define the initial state of the three checkboxes. Staff can still change them before starting a batch."
                    },
                    fields: [
                        {
                            key: "defaultSkipOnLoan",
                            type: "boolean",
                            label: {
                                fr: "Ne pas transférer les exemplaires actuellement empruntés",
                                en: "Do not transfer currently checked-out items"
                            }
                        },
                        {
                            key: "defaultSkipInTransfer",
                            type: "boolean",
                            label: {
                                fr: "Ignorer les exemplaires déjà en transfert",
                                en: "Skip items already in transfer"
                            }
                        },
                        {
                            key: "defaultSkipNotForLoan",
                            type: "boolean",
                            label: {
                                fr: "Ne pas transférer les exemplaires exclus du prêt",
                                en: "Do not transfer not-for-loan items"
                            }
                        }
                    ]
                }
            ]
        };
    }

    function registerWithPMK() {
        if (registeredWithPMK || !window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") {
            return false;
        }
        try {
            window.PMKConfig.registerModule(moduleDefinition());
            registeredWithPMK = true;
        } catch (e) {
            return false;
        }

        if (typeof window.PMKConfig.subscribe === "function") {
            try {
                unsubscribePMK = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
            } catch (e) {}
        }

        if (typeof window.PMKConfig.getConfig === "function") {
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(function (cfg) { applyConfig(cfg || DEFAULT_CONFIG); })
                .catch(function () { applyConfig(DEFAULT_CONFIG); });
        } else {
            applyConfig(DEFAULT_CONFIG);
        }
        return true;
    }

    function bootstrap() {
        // Fail-safe : le script garde son comportement historique même sans PMK.
        if (!registerWithPMK()) {
            applyConfig(DEFAULT_CONFIG);
            window.addEventListener("pmk:config-ready", function () {
                registerWithPMK();
            }, { once: true });
        }
    }

    window.PMK119MultiTransfer = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        defaults: Object.assign({}, DEFAULT_CONFIG),
        apply: applyConfig,
        getActiveJob: getActiveJob,
        canCancelEntry: canCancelEntry,
        canBulkCancelEntry: canBulkCancelEntry
    };

    window.addEventListener("beforeunload", function () {
        if (typeof unsubscribePMK === "function") {
            try { unsubscribePMK(); } catch (e) {}
        }
    }, { once: true });

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bootstrap, { once: true });
    } else {
        bootstrap();
    }

})();

;window.PMKNonPlugin.loaded.push("119-multi-transfert.js");
} catch (error) { window.PMKNonPlugin.errors.push("119-multi-transfert.js: "+error.message); console.error("[PMK] 119-multi-transfert.js",error); };
try {
/* ============================================================
   120-date-retrait-reservations.js
   PimpMyKoha — Date limite de retrait des réservations
   Version : 2.3.1-preplugin
   Date : 2026-10-29

   - Priorité à expiration_date renvoyée par Koha.
   - Identifie le site de retrait (pickup_library_id).
   - Lit le calendrier via un rapport SQL JSON compatible Koha 25.11.
   - Signale une échéance officielle sur un jour fermé et suggère
     le prochain jour d'ouverture, sans modifier Koha.
   - Si aucune date officielle n'existe, calcule une estimation
     en tenant compte du calendrier accessible.
   - Repli prudent en cas d'API indisponible.
   - Auto-enregistrement PMK, options FR/EN.
   ============================================================ */
(function (window, document) {
    "use strict";
    if (!window || !document) return;
    if (window.__PMK120HoldPickupExpiration) return;
    window.__PMK120HoldPickupExpiration = true;

    const MODULE_ID = "hold-pickup-expiration";
    const MODULE_VERSION = "2.3.1-preplugin";
    const PAGE_PATH = "/cgi-bin/koha/circ/returns.pl";
    const PAGE_ID = "circ.returns";
    const INFO_CLASS = "pmk120-hold-expiration-info";
    const MAX_SEARCH_DAYS = 90;
    const CALENDAR_REPORT_SQL = `SELECT
  'weekly' AS rule_type, branchcode, weekday,
  NULL AS day, NULL AS month, NULL AS year, 0 AS isexception
FROM repeatable_holidays
WHERE weekday IS NOT NULL
UNION ALL
SELECT
  'yearly' AS rule_type, branchcode, NULL AS weekday,
  day, month, NULL AS year, 0 AS isexception
FROM repeatable_holidays
WHERE weekday IS NULL
UNION ALL
SELECT
  'special' AS rule_type, branchcode, NULL AS weekday,
  day, month, year, isexception
FROM special_holidays
ORDER BY branchcode, rule_type, year, month, day, weekday`;

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        checkKohaCalendar: true,
        calendarReportId: 0,
        calendarSqlTemplate: CALENDAR_REPORT_SQL,
        suggestNextOpenDay: true,
        fallbackDays: 11,
        fallbackCountOpenDays: true,
        excludeSundays: true,
        fallbackFrenchHolidays: true,
        markFallbackAsEstimate: true,
        labelFr: "Mise de côté jusqu’au :",
        labelEn: "Hold available until:"
    });

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let observer = null;
    const holdCache = new Map();
    const closureCache = new Map();
    let processedForms = new WeakMap();

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
            return window.PMKConfig.getLanguage();
        }
        return String(document.documentElement.lang || navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }
    function tr(fr, en) { return language() === "en" ? en : fr; }
    function normalizeConfig(raw) {
        const s = raw && typeof raw === "object" ? raw : {};
        const n = Number(s.fallbackDays);
        return {
            enabled: s.enabled !== false,
            checkKohaCalendar: s.checkKohaCalendar !== false,
            calendarReportId: Math.max(0, Math.floor(Number(s.calendarReportId) || 0)),
            calendarSqlTemplate: CALENDAR_REPORT_SQL,
            suggestNextOpenDay: s.suggestNextOpenDay !== false,
            fallbackDays: Number.isFinite(n) ? Math.max(0, Math.min(60, Math.floor(n))) : 11,
            fallbackCountOpenDays: true, // Même politique de fermeture dans tous les modes
            excludeSundays: s.excludeSundays !== false,
            fallbackFrenchHolidays: s.fallbackFrenchHolidays !== false,
            markFallbackAsEstimate: s.markFallbackAsEstimate !== false,
            labelFr: String(s.labelFr || DEFAULT_CONFIG.labelFr),
            labelEn: String(s.labelEn || DEFAULT_CONFIG.labelEn)
        };
    }
    function parseKohaDate(value) {
        const raw = String(value || "").trim();
        if (!raw) return null;
        const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (m) {
            const y = Number(m[1]), month = Number(m[2]) - 1, day = Number(m[3]);
            const d = new Date(y, month, day, 12, 0, 0, 0);
            return d.getFullYear() === y && d.getMonth() === month && d.getDate() === day ? d : null;
        }
        const d = new Date(raw);
        if (Number.isNaN(d.getTime())) return null;
        d.setHours(12, 0, 0, 0);
        return d;
    }
    function dateISO(d) {
        return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
    }
    function formatDate(d) {
        return new Intl.DateTimeFormat(language() === "en" ? "en-GB" : "fr-FR", {
            day: "2-digit", month: "2-digit", year: "numeric"
        }).format(d);
    }
    function addDays(date, n) {
        const d = new Date(date.getTime());
        d.setHours(12, 0, 0, 0);
        d.setDate(d.getDate() + n);
        return d;
    }
    function escapeHtml(value) {
        return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
            return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[c];
        });
    }
    async function getJson(url) {
        const response = await fetch(url.toString(), {
            method: "GET", credentials: "same-origin", headers: { Accept: "application/json" }
        });
        if (!response.ok) throw new Error("Koha HTTP " + response.status);
        return response.json();
    }
    async function fetchHold(holdId) {
        const id = String(holdId || "").trim();
        if (!/^\d+$/.test(id)) throw new Error("hold_id invalide");
        if (holdCache.has(id)) return holdCache.get(id);
        const promise = (async function () {
            const url = new URL("/api/v1/holds", window.location.origin);
            url.searchParams.set("hold_id", id);
            url.searchParams.set("_per_page", "1");
            const data = await getJson(url);
            if (!Array.isArray(data)) throw new Error("Réponse de réservation inattendue");
            const match = data.find(h => String(h.hold_id) === id);
            if (!match) throw new Error("Réservation introuvable : " + id);
            return match;
        })().catch(function (error) { holdCache.delete(id); throw error; });
        holdCache.set(id, promise);
        return promise;
    }
    // Source : /cgi-bin/koha/svc/report?id=...&annotated=1 (rapport non public).
    // Préserve weekly, yearly, single, et exceptions de réouverture.
    let calendarReportCache = null;
    async function fetchCalendarRules() {
        const id = currentConfig.calendarReportId;
        if (!id) throw new Error("ID rapport calendrier non configuré dans PMK");
        if (calendarReportCache && calendarReportCache.id === id) return calendarReportCache.promise;
        const promise = (async () => {
            const url = new URL("/cgi-bin/koha/svc/report", window.location.origin);
            url.searchParams.set("id", String(id));
            url.searchParams.set("annotated", "1");
            const data = await getJson(url);
            if (!Array.isArray(data)) throw new Error("Rapport : réponse non tabulaire");
            // Le service JSON annoté renvoie un tableau d'objets.
            if (data.some(row => !row || typeof row !== "object" || Array.isArray(row))) {
                throw new Error("Rapport : format non annoté (attendu : objets)");
            }
            const rules = data.map(r => ({
                type: String(r.rule_type || "").toLowerCase(),
                branch: String(r.branchcode || "").trim().toUpperCase(),
                weekday: r.weekday == null ? null : Number(r.weekday),
                day: r.day == null ? null : Number(r.day),
                month: r.month == null ? null : Number(r.month),
                year: r.year == null ? null : Number(r.year),
                exception: Number(r.isexception || 0) === 1
            }));
            if (rules.some(r => !["weekly", "yearly", "special"].includes(r.type) || !r.branch)) {
                throw new Error("Le rapport ne correspond pas au modèle PMK 120");
            }
            return rules;
        })().catch(e => { calendarReportCache = null; throw e; });
        calendarReportCache = {id, promise};
        return promise;
    }
    async function fetchClosures(libraryId) {
        const branch = String(libraryId || "").trim().toUpperCase();
        if (!branch) throw new Error("Site de retrait inconnu");
        const key = branch + "|" + currentConfig.calendarReportId;
        if (closureCache.has(key)) return closureCache.get(key);
        const promise = fetchCalendarRules().then(all => ({
            branch,
            rules: all.filter(r => r.branch === branch)
        })).catch(e => { closureCache.delete(key); throw e; });
        closureCache.set(key, promise);
        return promise;
    }
    // Algorithme grégorien de Meeus/Jones/Butcher : dimanche de Pâques.
    function easterSunday(year) {
        const a = year % 19, b = Math.floor(year / 100), c = year % 100;
        const d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25);
        const g = Math.floor((b - f + 1) / 3);
        const h = (19 * a + b - d - g + 15) % 30;
        const i = Math.floor(c / 4), k = c % 4;
        const l = (32 + 2 * e + 2 * i - h - k) % 7;
        const m = Math.floor((a + 11 * h + 22 * l) / 451);
        const n = h + l - 7 * m + 114;
        return new Date(year, Math.floor(n / 31) - 1, n % 31 + 1, 12);
    }
    const holidayCache = new Map();
    function nationalFrenchHolidays(year) {
        if (holidayCache.has(year)) return holidayCache.get(year);
        const fixed = ['01-01','05-01','05-08','07-14','08-15','11-01','11-11','12-25'];
        const holidays = new Set(fixed.map(day => year + '-' + day));
        const easter = easterSunday(year);
        [1, 39, 50].forEach(offset => holidays.add(dateISO(addDays(easter, offset))));
        holidayCache.set(year, holidays);
        return holidays;
    }
    function isClosed(date, closures) {
        const iso = dateISO(date);
        if (closures) {
            const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate(), w = date.getDay();
            const matching = closures.rules.filter(r =>
                r.type === "special" && r.year === y && r.month === m && r.day === d
            );
            // Une exception annule un jour fermé récurrent. Une fermeture ponctuelle prime.
            if (matching.some(r => !r.exception)) return true;
            if (matching.some(r => r.exception)) return false;
            return closures.rules.some(r =>
                (r.type === "weekly" && r.weekday === w) ||
                (r.type === "yearly" && r.month === m && r.day === d)
            );
        }
        // Repli explicite uniquement lorsque la source Koha est inaccessible.
        if (currentConfig.fallbackFrenchHolidays && nationalFrenchHolidays(date.getFullYear()).has(iso)) return true;
        return currentConfig.excludeSundays && date.getDay() === 0;
    }
    function nextOpenDate(date, closures) {
        for (let i = 1; i <= MAX_SEARCH_DAYS; i++) {
            const candidate = addDays(date, i);
            if (!isClosed(candidate, closures)) return candidate;
        }
        return null;
    }
    // Politique unique : les jours fermés ne sont jamais comptés dans les 11 jours
    // de retrait. Sans calendrier accessible, le repli local exclut les dimanches.
    // Cette date reste indicative : seule Koha peut définir l'échéance officielle.
    function estimatedDeadline(baseDate, days, closures) {
        let date = addDays(baseDate, 0);
        let remaining = Math.max(0, Number(days) || 0);
        for (let i = 0; i < 180 && remaining > 0; i++) {
            date = addDays(date, 1);
            if (isClosed(date, closures)) continue;
            remaining--;
        }
        if (remaining > 0) return null;
        // Un délai de zéro jour peut tomber sur un jour fermé.
        if (isClosed(date, closures)) return nextOpenDate(date, closures);
        return date;
    }

    async function resolveExpiration(hold) {
        const official = parseKohaDate(hold.expiration_date || hold.waiting_expires_on || hold.expirationdate);
        const waiting = parseKohaDate(hold.waiting_date);
        const base = waiting || new Date();
        const library = String(hold.pickup_library_id || hold.branchcode || "").trim();
        let closures = null;
        if (currentConfig.checkKohaCalendar && library) {
            try { closures = await fetchClosures(library); }
            catch (error) { console.warn("[PMK120] Rapport calendrier Koha indisponible", error); }
        }
        const date = official || estimatedDeadline(base, currentConfig.fallbackDays, closures);
        if (!date) return null;
        // Un contrôle commun s'applique sans distinction au mode officiel/estimation.
        // Sans calendrier, on ne déclare jamais une date officiellement fermée.
        const closed = isClosed(date, closures);
        const suggested = closed && currentConfig.suggestNextOpenDay ? nextOpenDate(date, closures) : null;
        return {
            date, official: Boolean(official), estimated: !official,
            source: official ? "koha-expiration" : (waiting ? "waiting-date-fallback" : "today-fallback"),
            closed, suggested, calendarChecked: Boolean(closures)
        };
    }

    function modalBodyFor(form) {
        if (!form) return null;
        return form.querySelector(".modal-body, #hold-found-modal-body") ||
            (form.closest(".modal-content") && form.closest(".modal-content").querySelector(".modal-body")) ||
            form.closest(".modal-body") || form;
    }
    function removeExisting(body) {
        if (body) body.querySelectorAll("." + INFO_CLASS).forEach(function (node) { node.remove(); });
    }
    function injectLine(form, holdId, result) {
        const body = modalBodyFor(form);
        if (!body || !result || !result.date) return;
        // Évite d'insérer le résultat d'une ancienne requête dans une nouvelle modale.
        if (reserveIdFor(form) !== String(holdId)) return;
        removeExisting(body);
        const box = document.createElement("div");
        box.className = "alert " + (result.closed ? "alert-warning " : "alert-info ") + INFO_CLASS;
        box.dataset.holdId = String(holdId);
        box.dataset.source = result.source;
        box.style.margin = "10px 0";
        box.style.padding = "8px 12px";
        const label = language() === "en" ? currentConfig.labelEn : currentConfig.labelFr;
        const estimate = result.estimated && currentConfig.markFallbackAsEstimate ? tr(" (estimation)", " (estimate)") : "";
        let html = '<div><strong><i class="fa-regular fa-calendar" aria-hidden="true"></i> ' +
            escapeHtml(label) + '</strong> ' + escapeHtml(formatDate(result.date) + estimate) + '</div>';
        if (result.closed) {
            html += '<div style="margin-top:5px"><strong>' +
                escapeHtml(tr(result.calendarChecked ? "⚠ Jour de fermeture identifié (calendrier Koha ou jour férié)." : "⚠ Date tombant sur un jour de fermeture identifié (secours).", result.calendarChecked ? "⚠ Identified closure day (Koha calendar or national holiday)." : "⚠ Date falls on an identified closure day (fallback).")) + '</strong></div>';
            if (result.suggested) {
                html += '<div>' + escapeHtml(tr("Prochain jour ouvert possible : ", "Next possible open day: ") + formatDate(result.suggested)) + '</div>';
            }
            if (result.official) {
                html += '<div class="small">' + escapeHtml(tr(
                    "La date officielle reste celle enregistrée dans Koha ; proposition indicative, aucune modification de réservation.",
                    "The official date remains the one recorded in Koha; suggestion only, no hold modification."
                )) + '</div>';
            }
        }
        if (result.estimated && !result.calendarChecked) {
            html += '<div class="small">' + escapeHtml(tr(
                "Calendrier Koha non confirmé : estimation partielle (dimanches et jours fériés nationaux).",
                "Koha calendar not confirmed: partial estimate (Sundays and national holidays)."
            )) + '</div>';
        }
        if (result.estimated) {
            html += '<div class="small">' + escapeHtml(tr(
                "Date indicative calculée selon les jours d’ouverture disponibles ; à confirmer dans Koha.",
                "Indicative date based on available opening days; confirm in Koha."
            )) + '</div>';
        }
        box.innerHTML = html;
        const title = body.querySelector("h1, h2, h3, h4, .modal-title");
        if (title && title.parentNode) title.insertAdjacentElement("afterend", box);
        else body.prepend(box);
        if (window.PMKConfig && typeof window.PMKConfig.mountContextButton === "function") {
            try {
                window.PMKConfig.mountContextButton({
                    moduleId: MODULE_ID, anchor: box, position: "append", contextKey: "pmk120-hold-expiration"
                });
            } catch (_) {}
        }
    }
    function reserveIdFor(form) {
        const input = form && form.querySelector('input[name="reserve_id"], input[name="hold_id"], #reserve_id');
        return input ? String(input.value || "").trim() : "";
    }
    async function processForm(form) {
        if (!form || !currentConfig.enabled) return;
        const id = reserveIdFor(form);
        if (!id) return;
        if (processedForms.get(form) === id) return;
        processedForms.set(form, id);
        try {
            const hold = await fetchHold(id);
            const result = await resolveExpiration(hold);
            if (result && currentConfig.enabled && processedForms.get(form) === id) injectLine(form, id, result);
        } catch (error) {
            processedForms.delete(form);
            console.warn("[PMK120] Date de retrait indisponible", error);
        }
    }
    function candidateForms(root) {
        const scope = root && root.querySelectorAll ? root : document;
        const forms = Array.from(scope.querySelectorAll("#hold-found-modal-form, form.confirm, .modal form"));
        if (root && root.matches && root.matches("form")) forms.unshift(root);
        return Array.from(new Set(forms));
    }
    function scan(root) {
        if (window.location.pathname !== PAGE_PATH || !currentConfig.enabled) return;
        candidateForms(root).forEach(processForm);
    }
    function installObserver() {
        if (observer || typeof MutationObserver !== "function") return;
        observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node && node.nodeType === 1 && !node.classList.contains(INFO_CLASS)) scan(node);
                });
            });
        });
        observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    }
    function validate(config) {
        const n = Number(config && config.fallbackDays);
        if (config && config.fallbackDays !== undefined && (!Number.isFinite(n) || n < 0 || n > 60)) {
            return { ok: false, message: "Le nombre de jours de repli doit être compris entre 0 et 60." };
        }
        return { ok: true };
    }
    function definition() {
        return {
            id: MODULE_ID, schemaVersion: 1,
            name: { fr: "Date limite de retrait des réservations", en: "Hold pickup expiration date" },
            description: {
                fr: "Contrôle uniforme du calendrier pour les dates officielles et estimées. Calcule les estimations en jours ouverts, sans modifier les réservations Koha.",
                en: "Shows Koha's official expiration and checks pickup library closures. Suggests the next open day without altering Koha."
            },
            category: { fr: "Circulation / réservations", en: "Circulation / holds" },
            supportedPages: [PAGE_ID], prerequisites: [], dependencies: [],
            defaults: clone(DEFAULT_CONFIG), normalize: normalizeConfig, validate: validate,
            schema: [{
                type: "section", id: "settings", label: { fr: "Réglages", en: "Settings" },
                fields: [
                    { key: "enabled", type: "boolean", label: { fr: "Activer l’affichage", en: "Enable display" } },
                    { key: "checkKohaCalendar", type: "boolean", label: { fr: "Vérifier le calendrier Koha du site de retrait", en: "Check Koha pickup library calendar" } },
                    { key: "calendarReportId", type: "number", label: { fr: "ID du rapport SQL calendrier", en: "Calendar SQL report ID" }, help: { fr: "Rapport NON PUBLIC contenant les fermetures Koha ; recopier l’ID après création.", en: "NON-PUBLIC Koha closure report; paste the ID after creating it." } },
                    { key: "calendarSqlTemplate", type: "textarea", rows: 24, readOnly: true, label: { fr: "SQL du calendrier à copier dans Koha", en: "Calendar SQL to copy into Koha" }, help: { fr: "Créer un rapport guidé privé avec ce SQL, puis renseigner son identifiant ci-dessus.", en: "Create a private guided report with this SQL, then enter its ID above." } },
                    { key: "suggestNextOpenDay", type: "boolean", label: { fr: "Suggérer le prochain jour ouvert", en: "Suggest next open day" } },
                    { key: "fallbackDays", type: "number", label: { fr: "Délai de secours (jours)", en: "Fallback delay (days)" },
                      help: { fr: "Uniquement en l’absence de date officielle Koha. Décompte des jours ouverts selon le calendrier Koha, par défaut : 11.", en: "Only without an official Koha date. Counts open days using the Koha calendar; default: 11." } },
                    { key: "excludeSundays", type: "boolean", label: { fr: "Secours sans calendrier : exclure les dimanches", en: "Without calendar: exclude Sundays" } },
                    { key: "fallbackFrenchHolidays", type: "boolean", label: { fr: "Exclure les jours fériés nationaux français (y compris si API indisponible)", en: "Exclude French national holidays (including API fallback)" } },
                    { key: "markFallbackAsEstimate", type: "boolean", label: { fr: "Identifier les estimations", en: "Mark estimates" } },
                    { key: "labelFr", type: "text", label: { fr: "Libellé — français", en: "Label — French" } },
                    { key: "labelEn", type: "text", label: { fr: "Libellé — anglais", en: "Label — English" } }
                ]
            }]
        };
    }
    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) { return false; }
        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            try {
                unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (config) {
                    currentConfig = normalizeConfig(config);
                    closureCache.clear(); calendarReportCache = null;
                    processedFormsClear();
                    if (currentConfig.enabled) scan(document);
                    else document.querySelectorAll("." + INFO_CLASS).forEach(function (node) { node.remove(); });
                });
            } catch (_) {}
        }
        return true;
    }
    // WeakMap n'est pas itérable : on le remplace en changeant sa référence.
    function processedFormsClear() {
        processedForms = new WeakMap();
        document.querySelectorAll("." + INFO_CLASS).forEach(node => node.remove());
    }
    async function loadConfig() {
        registerModule();
        if (!window.PMKConfig || typeof window.PMKConfig.getConfig !== "function") return clone(DEFAULT_CONFIG);
        try { return normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID)); }
        catch (_) { return clone(DEFAULT_CONFIG); }
    }
    async function start() {
        currentConfig = await loadConfig();
        if (window.location.pathname !== PAGE_PATH) return;
        installObserver();
        scan(document);
    }
    window.PMK120HoldPickupExpiration = {
        moduleId: MODULE_ID, version: MODULE_VERSION,
        refresh: function () {
            return loadConfig().then(function (cfg) {
                currentConfig = cfg;
                closureCache.clear(); calendarReportCache = null;
                processedFormsClear();
                scan(document);
            });
        },
        clearCache: function () { holdCache.clear(); closureCache.clear(); calendarReportCache = null; processedFormsClear(); scan(document); }
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
    if (!window.PMKConfig) window.addEventListener("pmk:config-ready", function () { registerModule(); }, { once: true });
})(window, document);

;window.PMKNonPlugin.loaded.push("120-date-retrait-reservations.js");
} catch (error) { window.PMKNonPlugin.errors.push("120-date-retrait-reservations.js: "+error.message); console.error("[PMK] 120-date-retrait-reservations.js",error); };
try {
(async function () {
  const cfg=await window.PMKConfig.getConfig('cataloguing-tree-assistant');
  const defaults=window.PMKConfig.getDefinition('cataloguing-tree-assistant').defaults;
  if(cfg.features?.legacyFiltering===false || !cfg.enabled || cfg.page?.enabled===false || cfg.runtimeMode==='generic')return;
  if(['levels','extraFields','relationships','hierarchy','features','lists','appearance','language'].some(k=>JSON.stringify(cfg[k])!==JSON.stringify(defaults[k])))return;
  // --- Restriction : ne s'exécute que sur la page addbiblio.pl ---
  if (!/\/cgi-bin\/koha\/cataloguing\/addbiblio\.pl/i.test(location.pathname)) {
    return;
  }

  const firebaseConfig = {}; // Anciennes options conservées uniquement dans les sauvegardes.

  // --- Activer les logs ---
  const DEBUG = true;

  function log(...args) {
    if (DEBUG) {
      (function(){})('[Koha099-Highlight]', ...args);
    }
  }

  // --- Utilitaires ---
  const norm = s => (s || "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  const parseLevel = name => {
    const s = norm(name);
    if (/domaine\s*0?99\$?a/.test(s)) return "a";
    if (/sous[- ]domaine\s*0?99\$?b/.test(s)) return "b";
    if (/th[eè]me\s*0?99\$?e/.test(s)) return "e";
    if (/sujet\s*0?99\$?f/.test(s)) return "f";
    return "";
  };

  const cleanLabel = s => {
    const txt = (s || "").trim();
    if (!txt) return "";
    const m = txt.match(/^(.*?)\s*\((?:Sous[- ]?domaine|Domaine|Th[eè]me(?:s)?|Sujet|Forme\s*\/\s*Genre|Genre(?:\s+litt[eè]raire)?)[^)]*\)/i);
    if (m) return m[1].trim();
    return txt.replace(/\s*\(\d+\)\s*$/, "").trim();
  };

  const extractPathKey = node => {
    const p = (node.parentPath || node.path || node.parent || "").trim();
    return norm(p);
  };

  const findTagScopes = () => [...document.querySelectorAll('li.tag.clearfix[id^="tag_099_"]')];

  const findFieldInScope = (scope, code) =>
    scope.querySelector(`select[name^="tag_099_subfield_${code}_"]`) ||
    scope.querySelector(`input[name^="tag_099_subfield_${code}_"]`);

  const findFFieldInScope = scope => {
    const all = [...scope.querySelectorAll('select[name^="tag_099_subfield_f_"]')];
    if (!all.length) return null;
    return all.find(s => !s.value) || all[0];
  };

  // --- Indexation des données ---

  // Reproduit la logique d'attachement de buildTree() :
  // un noeud supprimé, ou un noeud dont la chaîne de parents n'est plus
  // rattachée à la racine, ne doit pas être utilisé par les listes 099.
  const getTreeParentPath = node => {
    if (!node) return "";
    if (typeof node.parentPath === "string") return node.parentPath.trim();
    if (typeof node.parent === "string") return node.parent.trim();
    return "";
  };

  const getTreeNodeName = node => (node?.name || node?.label || "").toString().trim();

  const getTreeFullPath = node => {
    const name = getTreeNodeName(node);
    const parentPath = getTreeParentPath(node);
    return parentPath ? `${parentPath}/${name}` : name;
  };

  const buildActiveTreeContext = rows => {
    // 1. Exclure les documents explicitement supprimés.
    const activeRows = (rows || []).filter(row => !row.deleted);

    // 2. Reconstituer le même index de chemins que buildTree().
    const byPath = new Map();
    activeRows.forEach(row => {
      const fullPath = getTreeFullPath(row);
      if (fullPath) byPath.set(fullPath, row);
    });

    // 3. Ne conserver que les noeuds réellement atteignables depuis la racine.
    //    Cela élimine aussi les descendants/orphelins d'un ancien noeud supprimé.
    const reachablePaths = new Set();
    activeRows.forEach(row => {
      if (getTreeParentPath(row) === "") {
        const fullPath = getTreeFullPath(row);
        if (fullPath) reachablePaths.add(fullPath);
      }
    });

    let changed = true;
    let guard = 0;
    while (changed && guard++ < activeRows.length + 2) {
      changed = false;
      activeRows.forEach(row => {
        const fullPath = getTreeFullPath(row);
        if (!fullPath || reachablePaths.has(fullPath)) return;
        const parentPath = getTreeParentPath(row);
        if (parentPath && reachablePaths.has(parentPath) && byPath.has(parentPath)) {
          reachablePaths.add(fullPath);
          changed = true;
        }
      });
    }

    const reachableRows = activeRows.filter(row => reachablePaths.has(getTreeFullPath(row)));

    return {
      allRows: rows || [],
      rows: reachableRows,
      byPath,
      reachablePaths,
      excludedDeleted: (rows || []).length - activeRows.length,
      excludedOrphans: activeRows.length - reachableRows.length
    };
  };

  const findAncestorByLevel = (node, wantedLevel, treeCtx) => {
    let parentPath = getTreeParentPath(node);
    let guard = 0;

    while (parentPath && guard++ < 100) {
      if (!treeCtx.reachablePaths.has(parentPath)) return null;
      const parent = treeCtx.byPath.get(parentPath);
      if (!parent) return null;

      if (parseLevel(getTreeNodeName(parent)) === wantedLevel) return parent;
      parentPath = getTreeParentPath(parent);
    }
    return null;
  };

  const getAncestorLabelKeys = (node, treeCtx) => {
    const keys = [];
    let parentPath = getTreeParentPath(node);
    let guard = 0;

    while (parentPath && guard++ < 100) {
      if (!treeCtx.reachablePaths.has(parentPath)) break;
      const parent = treeCtx.byPath.get(parentPath);
      if (!parent) break;
      const label = cleanLabel(getTreeNodeName(parent));
      if (label) keys.push(norm(label));
      parentPath = getTreeParentPath(parent);
    }
    return keys;
  };

  const buildIndex = rows => {
    const treeCtx = buildActiveTreeContext(rows);
    rows = treeCtx.rows;

    log('Construction de l\'index à partir de', rows.length, 'noeuds atteignables',
      `(${treeCtx.excludedDeleted} supprimés, ${treeCtx.excludedOrphans} orphelins exclus)`);

    const idx = { a: [], bByA: new Map(), eByAB: new Map(), fByABE: new Map() };

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "a") continue;
      const label = cleanLabel(getTreeNodeName(r));
      if (!label) continue;
      idx.a.push({ label, raw: r, key: norm(label) });
    }
    idx.a = [...new Map(idx.a.map(x => [x.key, x])).values()]
      .sort((x, y) => x.label.localeCompare(y.label, "fr"));

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "b") continue;
      const label = cleanLabel(getTreeNodeName(r));
      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);
      if (!aRow) continue;
      const aKey = norm(cleanLabel(getTreeNodeName(aRow)));
      const a = idx.a.find(x => x.key === aKey);
      if (!a) continue;

      if (!idx.bByA.has(a.key)) idx.bByA.set(a.key, []);
      idx.bByA.get(a.key).push({ label, raw: r, key: norm(label), aKey: a.key });
    }
    for (const [k, arr] of idx.bByA) {
      idx.bByA.set(k, [...new Map(arr.map(x => [x.key, x])).values()]
        .sort((x, y) => x.label.localeCompare(y.label, "fr")));
    }

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "e") continue;
      const label = cleanLabel(getTreeNodeName(r));
      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);
      const bRow = findAncestorByLevel(r, "b", treeCtx);
      if (!aRow || !bRow) continue;

      const aKey = norm(cleanLabel(getTreeNodeName(aRow)));
      const bKey = norm(cleanLabel(getTreeNodeName(bRow)));
      const a = idx.a.find(x => x.key === aKey);
      if (!a) continue;
      const b = (idx.bByA.get(a.key) || []).find(x => x.key === bKey);
      if (!b) continue;

      const abKey = `${a.key}|||${b.key}`;
      if (!idx.eByAB.has(abKey)) idx.eByAB.set(abKey, []);
      idx.eByAB.get(abKey).push({ label, raw: r, key: norm(label), aKey: a.key, bKey: b.key });
    }
    for (const [k, arr] of idx.eByAB) {
      idx.eByAB.set(k, [...new Map(arr.map(x => [x.key, x])).values()]
        .sort((x, y) => x.label.localeCompare(y.label, "fr")));
    }

    for (const r of rows) {
      if (parseLevel(getTreeNodeName(r)) !== "f") continue;
      const label = cleanLabel(getTreeNodeName(r));
      if (!label) continue;

      const aRow = findAncestorByLevel(r, "a", treeCtx);
      const bRow = findAncestorByLevel(r, "b", treeCtx);
      const eRow = findAncestorByLevel(r, "e", treeCtx);
      if (!aRow || !bRow || !eRow) continue;

      const aKey = norm(cleanLabel(getTreeNodeName(aRow)));
      const bKey = norm(cleanLabel(getTreeNodeName(bRow)));
      const eKey = norm(cleanLabel(getTreeNodeName(eRow)));
      const a = idx.a.find(x => x.key === aKey);
      if (!a) continue;
      const b = (idx.bByA.get(a.key) || []).find(x => x.key === bKey);
      if (!b) continue;
      const e = (idx.eByAB.get(`${a.key}|||${b.key}`) || []).find(x => x.key === eKey);
      if (!e) continue;

      const abeKey = `${a.key}|||${b.key}|||${e.key}`;
      if (!idx.fByABE.has(abeKey)) idx.fByABE.set(abeKey, []);
      idx.fByABE.get(abeKey).push({ label, raw: r, key: norm(label) });
    }
    for (const [k, arr] of idx.fByABE) {
      idx.fByABE.set(k, [...new Map(arr.map(x => [x.key, x])).values()]
        .sort((x, y) => x.label.localeCompare(y.label, "fr")));
    }

    log('Index construit:');
    log('  - Domaines (a):', idx.a.length);
    log('  - Sous-domaines (b):', idx.bByA.size, 'groupes');
    log('  - Thèmes (e):', idx.eByAB.size, 'groupes');
    log('  - Sujets (f):', idx.fByABE.size, 'groupes');

    // Diagnostic accessible via l'objet global : window.Koha099TreeDebug
    window.Koha099TreeDebug = {
      totalRows: (treeCtx.excludedDeleted + treeCtx.excludedOrphans + rows.length),
      activeReachableRows: rows.length,
      excludedDeleted: treeCtx.excludedDeleted,
      excludedOrphans: treeCtx.excludedOrphans,
      find(text) {
        const needle = norm(text || "");
        return treeCtx.allRows.filter(r => {
          const hay = `${getTreeNodeName(r)} ${getTreeParentPath(r)}`;
          return norm(hay).includes(needle);
        }).map(r => ({
          id: r.id,
          name: getTreeNodeName(r),
          parentPath: getTreeParentPath(r),
          deleted: r.deleted,
          reachable: treeCtx.reachablePaths.has(getTreeFullPath(r)),
          level: parseLevel(getTreeNodeName(r))
        }));
      }
    };

    return idx;
  };

  // --- Récupérer les valeurs sélectionnées ---
  const getCurrentValues = (scope) => {
    const aField = findFieldInScope(scope, "a");
    const bField = findFieldInScope(scope, "b");
    const eField = findFieldInScope(scope, "e");
    const fField = findFFieldInScope(scope);

    const getValue = field => {
      if (!field) return "";
      if (field.tagName === "SELECT") {
        const selected = field.options[field.selectedIndex];
        return selected ? (selected.textContent || selected.value || "") : (field.value || "");
      }
      return field.value || "";
    };

    const values = {
      a: getValue(aField),
      b: getValue(bField),
      e: getValue(eField),
      f: getValue(fField)
    };
    
    log('Valeurs actuelles:', values);
    return values;
  };

  // --- Vérifier si une valeur est autorisée ---
  const isValueAllowed = (value, allowedLabels, fieldName) => {
    if (!value) {
      log(`  ${fieldName}: valeur vide, considérée comme autorisée`);
      return true;
    }
    if (allowedLabels.length === 0) {
      log(`  ${fieldName}: aucune option autorisée, valeur non autorisée`);
      return false;
    }
    const valueNorm = norm(value);
    const isAllowed = allowedLabels.some(label => norm(label) === valueNorm);
    log(`  ${fieldName}: "${value}" ${isAllowed ? 'autorisée ✓' : 'NON AUTORISÉE ✗'} (parmi ${allowedLabels.length} options)`);
    return isAllowed;
  };

  // --- Trouver le conteneur Select2 associé à un select ---
  const findSelect2Container = (select) => {
    if (!select) return null;
    
    // Méthode 1: chercher le conteneur Select2 via l'ID
    if (select.id) {
      const containerId = 'select2-' + select.id + '-container';
      const container = document.getElementById(containerId);
      if (container) return container.closest('.select2-container');
    }
    
    // Méthode 2: via data-select2-id
    const select2Id = select.getAttribute('data-select2-id');
    if (select2Id) {
      const container = document.querySelector(`.select2-container[data-select2-id="${select2Id}"]`);
      if (container) return container;
    }
    
    // Méthode 3: chercher dans le parent proche
    const parent = select.parentElement;
    if (parent && parent.classList.contains('select2')) {
      return parent.querySelector('.select2-container') || parent.closest('.select2-container');
    }
    
    // Méthode 4: chercher tous les conteneurs et vérifier la correspondance
    const allContainers = document.querySelectorAll('.select2-container');
    for (const container of allContainers) {
      const labelledBy = container.getAttribute('aria-labelledby');
      if (labelledBy && select.id && labelledBy.includes(select.id)) {
        return container;
      }
      
      // Vérifier si le select est un enfant de ce conteneur
      if (container.contains(select)) {
        return container;
      }
    }
    
    return null;
  };

  // --- APPLIQUER LA SURBRILLANCE ---
  const applyHighlightToField = (field, isInvalid, fieldName) => {
    if (!field) {
      log(`  ${fieldName}: champ non trouvé`);
      return;
    }

    // Trouver le conteneur Select2
    const select2Container = findSelect2Container(field);
    
    log(`  ${fieldName}: SURBRILLANCE = ${isInvalid ? 'ACTIVÉE 🟠' : 'DÉSACTIVÉE'}`);
    log(`  ${fieldName}: conteneur Select2 trouvé = ${!!select2Container}`);
    
    if (isInvalid) {
      // AJOUTER LA CLASSE AU SELECT NATIF
      field.classList.add('koha099-invalid');
      
      if (select2Container) {
        // AJOUTER LA CLASSE AU CONTENEUR SELECT2
        select2Container.classList.add('koha099-invalid');
        select2Container.setAttribute('data-invalid', 'true');
        select2Container.setAttribute('title', '⚠️ Valeur non autorisée');
        log(`  ${fieldName}: classe ajoutée au conteneur Select2`);
        
        // STYLES INLINE SUR LE CONTENEUR (VERSION COMPACTE)
        select2Container.style.border = '1.5px solid #e67e22 !important';
        select2Container.style.borderRadius = '3px !important';
        select2Container.style.backgroundColor = '#fef5e7 !important';
        select2Container.style.boxShadow = '0 0 0 2px rgba(230, 126, 34, 0.15) !important';
        
        // STYLES SUR .select2-selection
        const selection = select2Container.querySelector('.select2-selection');
        if (selection) {
          selection.style.border = '1.5px solid #e67e22 !important';
          selection.style.backgroundColor = '#fef5e7 !important';
          selection.style.borderRadius = '3px !important';
        }
        
        // STYLES SUR .select2-selection__rendered (COMPACT)
        const rendered = select2Container.querySelector('.select2-selection__rendered');
        if (rendered) {
          rendered.style.color = '#9c5a1a !important';
          rendered.style.fontWeight = '600 !important';
          rendered.style.backgroundColor = '#fef5e7 !important';
          rendered.style.padding = '2px 6px !important';
          rendered.style.lineHeight = '1.2 !important';
        }
        
        // STYLES SUR .select2-selection__arrow
        const arrow = select2Container.querySelector('.select2-selection__arrow');
        if (arrow) {
          arrow.style.backgroundColor = '#fef5e7 !important';
          arrow.style.borderLeft = '1px solid #e67e22 !important';
        }
        
        log(`  ${fieldName}: ✅ surbrillance APPLIQUÉE sur Select2`);
      } else {
        log(`  ${fieldName}: ⚠️ conteneur Select2 introuvable, application sur le select natif uniquement`);
      }
      
      field.title = '⚠️ Valeur non autorisée';
    } else {
      // RETIRER LA SURBRILLANCE
      field.classList.remove('koha099-invalid');
      field.title = '';
      
      if (select2Container) {
        select2Container.classList.remove('koha099-invalid');
        select2Container.removeAttribute('data-invalid');
        select2Container.removeAttribute('title');
        
        select2Container.style.border = '';
        select2Container.style.borderRadius = '';
        select2Container.style.backgroundColor = '';
        select2Container.style.boxShadow = '';
        
        const selection = select2Container.querySelector('.select2-selection');
        if (selection) {
          selection.style.border = '';
          selection.style.backgroundColor = '';
          selection.style.borderRadius = '';
        }
        
        const rendered = select2Container.querySelector('.select2-selection__rendered');
        if (rendered) {
          rendered.style.color = '';
          rendered.style.fontWeight = '';
          rendered.style.backgroundColor = '';
          rendered.style.padding = '';
          rendered.style.lineHeight = '';
        }
        
        const arrow = select2Container.querySelector('.select2-selection__arrow');
        if (arrow) {
          arrow.style.backgroundColor = '';
          arrow.style.borderLeft = '';
        }
      }
      log(`  ${fieldName}: surbrillance retirée`);
    }
  };

  // --- Filtrer les options SELECT natif ---
  const filterSelectOptions = (select, allowedLabels, forceHideAll, currentValue, fieldName) => {
    if (!select || !select.options) {
      log(`  ${fieldName}: select non trouvé`);
      return;
    }

    log(`  ${fieldName}: filtrage avec ${allowedLabels.length} labels autorisés`);

    const allowedSet = new Set(allowedLabels.map(norm));
    let hasVisibleOption = false;

    for (let i = 0; i < select.options.length; i++) {
      const opt = select.options[i];
      const optLabel = norm(opt.textContent);

      if (opt.value === "") {
        opt.style.display = "";
        opt.disabled = false;
        opt.removeAttribute('hidden');
        continue;
      }

      if (forceHideAll || allowedLabels.length === 0) {
        opt.style.display = "none";
        opt.disabled = true;
        opt.setAttribute('hidden', 'hidden');
        continue;
      }

      if (allowedSet.has(optLabel)) {
        opt.style.display = "";
        opt.disabled = false;
        opt.removeAttribute('hidden');
        if (opt.value !== "") hasVisibleOption = true;
      } else {
        opt.style.display = "none";
        opt.disabled = true;
        opt.setAttribute('hidden', 'hidden');
      }
    }

    if (!hasVisibleOption && allowedLabels.length > 0) {
      for (let i = 0; i < select.options.length; i++) {
        const opt = select.options[i];
        if (opt.value !== "") {
          opt.style.display = "none";
          opt.disabled = true;
          opt.setAttribute('hidden', 'hidden');
        }
      }
    }

    // Appliquer la surbrillance
    const isCurrentValueAllowed = isValueAllowed(currentValue, allowedLabels, fieldName);
    const isInvalid = !isCurrentValueAllowed && currentValue !== '';
    log(`  ${fieldName}: isInvalid = ${isInvalid}`);
    
    // APPLIQUER LA SURBRILLANCE
    applyHighlightToField(select, isInvalid, fieldName);
  };

  // --- Désactiver ou vider un select ---
  const setSelectDisabled = (select, disabled, reason, fieldName) => {
    if (!select) {
      log(`  ${fieldName}: select non trouvé`);
      return;
    }
    
    if (select.disabled === disabled) {
      return;
    }
    
    select.disabled = disabled;
    
    if (disabled) {
      select.style.opacity = '0.6';
      select.style.cursor = 'not-allowed';
      select.title = reason || 'Sélectionnez d\'abord le niveau supérieur';
      
      const emptyOpt = [...select.options].find(o => o.value === "");
      if (emptyOpt) {
        select.selectedIndex = emptyOpt.index;
      } else if (select.options.length > 0) {
        select.selectedIndex = 0;
      }
      select.value = "";
      
      applyHighlightToField(select, false, fieldName);
    } else {
      select.style.opacity = '1';
      select.style.cursor = 'default';
      select.title = '';
    }
    
    if (window.jQuery) {
      try {
        window.jQuery(select).trigger('change');
      } catch (e) {}
    }
  };

  // --- Appliquer les filtres ---
  let filterTimeout = null;

  const applyFilters = (idx, scope) => {
    if (filterTimeout) {
      clearTimeout(filterTimeout);
      filterTimeout = null;
    }

    filterTimeout = setTimeout(() => {
      log('=== APPLY FILTERS ===');
      
      const values = getCurrentValues(scope);

      const aMatch = idx.a.find(x => norm(x.label) === norm(values.a));
      log('Domaine trouvé:', aMatch ? aMatch.label : 'Aucun');
      
      let bList = [];
      let bMatch = null;
      let bLabels = [];
      
      if (aMatch) {
        bList = idx.bByA.get(aMatch.key) || [];
        bMatch = bList.find(x => norm(x.label) === norm(values.b));
        bLabels = bList.map(x => x.label);
        log('Sous-domaines disponibles:', bList.length);
      }

      let eList = [];
      let eMatch = null;
      let eLabels = [];
      
      if (aMatch && bMatch) {
        const abKey = `${aMatch.key}|||${bMatch.key}`;
        eList = idx.eByAB.get(abKey) || [];
        eMatch = eList.find(x => norm(x.label) === norm(values.e));
        eLabels = eList.map(x => x.label);
        log('Thèmes disponibles:', eList.length);
      }

      let fList = [];
      let fLabels = [];
      
      if (aMatch && bMatch && eMatch) {
        const abeKey = `${aMatch.key}|||${bMatch.key}|||${eMatch.key}`;
        fList = idx.fByABE.get(abeKey) || [];
        fLabels = fList.map(x => x.label);
        log('Sujets disponibles:', fList.length);
      }

      const bField = findFieldInScope(scope, "b");
      const eField = findFieldInScope(scope, "e");
      const fField = findFFieldInScope(scope);

      const processField = (field, allowedLabels, isDisabled, reason, forceHideAll, currentValue, fieldName) => {
        if (!field) {
          log(`  ${fieldName}: champ non trouvé`);
          return;
        }
        
        if (isDisabled) {
          setSelectDisabled(field, true, reason, fieldName);
          filterSelectOptions(field, [], true, currentValue, fieldName);
        } else {
          setSelectDisabled(field, false, null, fieldName);
          filterSelectOptions(field, allowedLabels, false, currentValue, fieldName);
        }
      };

      processField(bField, bLabels, !aMatch, 'Sélectionnez d\'abord un Domaine', true, values.b, '$b (Sous-domaine)');
      processField(eField, eLabels, !(aMatch && bMatch), aMatch ? 'Sélectionnez d\'abord un Sous-domaine' : 'Sélectionnez d\'abord un Domaine', true, values.e, '$e (Thème)');
      processField(fField, fLabels, !(aMatch && bMatch && eMatch), 'Sélectionnez d\'abord un Thème', true, values.f, '$f (Sujet)');

      log('=== FIN APPLY FILTERS ===');
      filterTimeout = null;
    }, 100);
  };

  // --- Réappliquer la surbrillance après délai (Select2 ready) ---
  const reapplyHighlightAfterDelay = (scope, idx) => {
    setTimeout(() => {
      log('=== REAPPLY HIGHLIGHT (Select2 ready) ===');
      const values = getCurrentValues(scope);
      const aMatch = idx.a.find(x => norm(x.label) === norm(values.a));
      
      let bMatch = null;
      let eMatch = null;
      let fMatch = null;
      
      if (aMatch) {
        const bList = idx.bByA.get(aMatch.key) || [];
        bMatch = bList.find(x => norm(x.label) === norm(values.b));
      }
      
      if (aMatch && bMatch) {
        const abKey = `${aMatch.key}|||${bMatch.key}`;
        const eList = idx.eByAB.get(abKey) || [];
        eMatch = eList.find(x => norm(x.label) === norm(values.e));
      }
      
      if (aMatch && bMatch && eMatch) {
        const abeKey = `${aMatch.key}|||${bMatch.key}|||${eMatch.key}`;
        const fList = idx.fByABE.get(abeKey) || [];
        fMatch = fList.find(x => norm(x.label) === norm(values.f));
      }

      const bField = findFieldInScope(scope, "b");
      const eField = findFieldInScope(scope, "e");
      const fField = findFFieldInScope(scope);

      const bLabels = aMatch ? (idx.bByA.get(aMatch.key) || []).map(x => x.label) : [];
      const eLabels = (aMatch && bMatch) ? (idx.eByAB.get(`${aMatch.key}|||${bMatch.key}`) || []).map(x => x.label) : [];
      const fLabels = (aMatch && bMatch && eMatch) ? (idx.fByABE.get(`${aMatch.key}|||${bMatch.key}|||${eMatch.key}`) || []).map(x => x.label) : [];

      const isBInvalid = !isValueAllowed(values.b, bLabels, '$b') && values.b !== '';
      const isEInvalid = !isValueAllowed(values.e, eLabels, '$e') && values.e !== '';
      const isFInvalid = !isValueAllowed(values.f, fLabels, '$f') && values.f !== '';

      log(`Réapplication surbrillance: b=${isBInvalid}, e=${isEInvalid}, f=${isFInvalid}`);
      
      applyHighlightToField(bField, isBInvalid, '$b (retry)');
      applyHighlightToField(eField, isEInvalid, '$e (retry)');
      applyHighlightToField(fField, isFInvalid, '$f (retry)');
    }, 800);
  };

  // --- Mise en place des écouteurs ---
  const setupListeners = (idx, scope) => {
    const aField = findFieldInScope(scope, "a");
    const bField = findFieldInScope(scope, "b");
    const eField = findFieldInScope(scope, "e");

    const onFieldChange = (e) => {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      log('Changement détecté sur', e.target ? e.target.name : 'inconnu');
      setTimeout(() => applyFilters(idx, scope), 50);
    };

    const attachListener = (field, callback) => {
      if (!field || field._listenerAttached) return;
      field._listenerAttached = true;
      
      field.addEventListener("change", callback);
      
      if (window.jQuery) {
        try {
          window.jQuery(field).on("change.select2", callback);
        } catch (e) {}
      }
    };

    attachListener(aField, onFieldChange);
    attachListener(bField, onFieldChange);
    attachListener(eField, onFieldChange);
  };

  // --- Initialisation d'un scope ---
  const initScope = (idx, scope) => {
    if (scope._initialized) return;
    scope._initialized = true;
    log('=== INIT SCOPE ===');
    
    applyFilters(idx, scope);
    setupListeners(idx, scope);
    
    // NOUVEAU : Réappliquer la surbrillance une fois Select2 initialisé
    reapplyHighlightAfterDelay(scope, idx);
  };

  // --- Ajouter le style ---
  const addStyle = () => {
    if (document.getElementById('koha099_filter_style')) return;
    
    const style = document.createElement('style');
    style.id = 'koha099_filter_style';
    style.textContent = `
      /* Masquer les options désactivées dans le SELECT natif */
      select option[hidden],
      select option[style*="display: none"] {
        display: none !important;
      }
      
      /* Masquer les options désactivées dans Select2 */
      .select2-container--default .select2-results__option[aria-disabled="true"] {
        display: none !important;
      }
      
      /* Style pour les selects désactivés */
      select:disabled {
        opacity: 0.6 !important;
        cursor: not-allowed !important;
      }
      
      /* ===== SURBRILLANCE ORANGE DISCRÈTE ET COMPACTE ===== */
      
      /* Conteneur principal Select2 en surbrillance */
      .select2-container.koha099-invalid {
        border: 1.5px solid #e67e22 !important;
        border-radius: 3px !important;
        background-color: #fef5e7 !important;
        box-shadow: 0 0 0 2px rgba(230, 126, 34, 0.15) !important;
      }
      
      /* L'élément de sélection à l'intérieur */
      .select2-container.koha099-invalid .select2-selection {
        border: 1.5px solid #e67e22 !important;
        background: #fef5e7 !important;
        border-radius: 3px !important;
      }
      
      /* Le texte affiché (rendered) - VERSION COMPACTE */
      .select2-container.koha099-invalid .select2-selection__rendered {
        color: #9c5a1a !important;
        font-weight: 600 !important;
        background-color: #fef5e7 !important;
        padding: 2px 6px !important;
        line-height: 1.2 !important;
      }
      
      /* Ajouter un warning icon */
      .select2-container.koha099-invalid .select2-selection__rendered::after {
        content: " ⚠️" !important;
        color: #e67e22 !important;
        font-size: 13px !important;
        font-weight: 600 !important;
      }
      
      /* La flèche de dropdown */
      .select2-container.koha099-invalid .select2-selection__arrow {
        background-color: #fef5e7 !important;
        border-left: 1px solid #e67e22 !important;
      }
      
      /* Sélecteur natif en surbrillance */
      select.koha099-invalid {
        border: 1.5px solid #e67e22 !important;
        background-color: #fef5e7 !important;
        box-shadow: 0 0 0 2px rgba(230, 126, 34, 0.15) !important;
        color: #9c5a1a !important;
        font-weight: 600 !important;
      }
    `;
    document.head.appendChild(style);
    log('Style CSS ajouté');
  };

  // --- Initialisation ---
  const init = (idx) => {
    let attempts = 0;
    const maxAttempts = 30;

    const checkAndApply = () => {
      const scopes = findTagScopes();
      
      if (scopes.length === 0) {
        attempts++;
        if (attempts < maxAttempts) {
          setTimeout(checkAndApply, 300);
        }
        return;
      }

      log(`${scopes.length} scope(s) trouvé(s)`);
      scopes.forEach(scope => initScope(idx, scope));

      const observer = new MutationObserver(() => {
        const newScopes = findTagScopes();
        newScopes.forEach(scope => {
          if (!scope._initialized) {
            initScope(idx, scope);
          }
        });
      });
      
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    };

    checkAndApply();
  };

  // --- Bootstrap ---
  const boot = async () => {
    try {
      log('=== BOOT START ===');
      addStyle();

      const {collection,getDocs,createDatabase}=window.PMKNativeData;
      const db=createDatabase('taxonomy');
      const treeCollection = collection(db, "treeData");

      log('Récupération des données Koha...');
      const snapshot = await getDocs(treeCollection);
      
      const rows = [];
      snapshot.forEach(doc => rows.push({ id: doc.id, ...doc.data() }));
      
      log(`${rows.length} lignes récupérées de Koha`);
      
      if (rows.length === 0) {
        (function(){})("Aucune donnée treeData trouvée dans Koha");
        return;
      }

      const idx = buildIndex(rows);
      init(idx);
      log('=== BOOT COMPLETE ===');

    } catch (error) {
      (function(){})("Erreur lors de l'initialisation:", error);
    }
  };

  // --- Démarrer ---
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})().catch(error=>console.error("[PMK filtrage]",error));

;window.PMKNonPlugin.loaded.push("122-filtrage_099.js");
} catch (error) { window.PMKNonPlugin.errors.push("122-filtrage_099.js: "+error.message); console.error("[PMK] 122-filtrage_099.js",error); };
try {
(function () {
    'use strict';

    if (window.__PMK123SearchFilterBadgesBootstrap) return;
    window.__PMK123SearchFilterBadgesBootstrap = true;

    const PMK123_MODULE_ID = 'search-filter-badges';
    const PMK123_VERSION = '2.0.0-preplugin';
    const PMK123_DEFAULTS = { enabled: true };
    let pmk123Config = { enabled: true };
    let pmk123Initialized = false;
    let pmk123Unsubscribe = null;

    function pmk123Normalize(raw) {
        return { enabled: !(raw && raw.enabled === false) };
    }

    function pmk123Definition() {
        return {
            id: PMK123_MODULE_ID,
            schemaVersion: 1,
            name: { fr: 'Badges des filtres de recherche', en: 'Search filter badges' },
            description: {
                fr: 'Conserve le rendu historique du 123 : les filtres actifs du catalogue et de la recherche adhérents sont matérialisés par des badges compacts et supprimables.',
                en: 'Keeps the historical 123 behavior: active catalogue and patron-search filters are shown as compact removable badges.'
            },
            category: { fr: 'Recherche / interface', en: 'Search / interface' },
            supportedPages: ['catalogue.search', 'members.search'],
            prerequisites: [],
            dependencies: [],
            defaults: { enabled: true },
            normalize: pmk123Normalize,
            schema: [
                {
                    type: 'section',
                    id: 'settings',
                    label: { fr: 'Réglages', en: 'Settings' },
                    fields: [
                        { key: 'enabled', type: 'boolean', label: { fr: 'Activer les badges de filtres', en: 'Enable filter badges' } }
                    ]
                }
            ]
        };
    }

    function pmk123Register() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function') return false;
        try { window.PMKConfig.registerModule(pmk123Definition()); } catch (_) { return false; }
        if (!pmk123Unsubscribe && typeof window.PMKConfig.subscribe === 'function') {
            try {
                pmk123Unsubscribe = window.PMKConfig.subscribe(PMK123_MODULE_ID, function (cfg) {
                    pmk123Config = pmk123Normalize(cfg);
                    document.documentElement.classList.toggle('pmk123-disabled', pmk123Config.enabled === false);
                    if (pmk123Config.enabled && !pmk123Initialized) {
                        pmk123Initialized = true;
                        initKohaSearchEnhancements();
                    }
                });
            } catch (_) {}
        }
        return true;
    }

    function pmk123EnsureDisableStyle() {
        if (document.getElementById('pmk123-disable-style')) return;
        const style = document.createElement('style');
        style.id = 'pmk123-disable-style';
        style.textContent = '.pmk123-disabled .koha-search-index-indicator,.pmk123-disabled .koha-search-library-indicator,.pmk123-disabled .koha-member-search-filter-indicator{display:none!important}';
        document.head.appendChild(style);
    }


    /*
     * ================================================================
     * INITIALISATION GÉNÉRALE
     * ================================================================
     */

    function initKohaSearchEnhancements() {

        if (pmk123Config.enabled === false) return;


        /*
         * ============================================================
         * CSS AUTONOME
         * ============================================================
         */

        if (
            !document.getElementById(
                'koha-search-enhancements-css'
            )
        ) {

            const style =
                document.createElement('style');

            style.id =
                'koha-search-enhancements-css';


            style.textContent = `

                /*
                 * ====================================================
                 * BADGES CATALOGUE
                 * ====================================================
                 */

                .koha-search-index-indicator,
                .koha-search-library-indicator {

                    display: none;

                    align-self: center !important;

                    align-items: center !important;
                    justify-content: center !important;

                    /*
                     * Espacement très réduit entre les badges.
                     */

                    margin-left: 2px !important;
                    margin-right: 2px !important;

                    padding: 1px 5px 1px 8px !important;

                    width: auto !important;
                    height: 20px !important;

                    min-height: 20px !important;
                    max-height: 20px !important;

                    box-sizing: border-box !important;

                    border-radius: 10px !important;

                    font-size: 10px !important;
                    font-weight: 500 !important;

                    line-height: 18px !important;

                    white-space: nowrap !important;

                    flex: 0 0 auto !important;

                    float: none !important;

                    position: relative !important;
                    top: 0 !important;

                    box-shadow: none !important;
                }


                /*
                 * ====================================================
                 * BADGES CATALOGUE ACTIFS
                 * ====================================================
                 */

                .koha-search-index-indicator.is-active,
                .koha-search-library-indicator.is-active {

                    display: inline-flex !important;

                }


                /*
                 * ====================================================
                 * INDEX CATALOGUE
                 * ====================================================
                 */

                .koha-search-index-indicator {

                    background:
                        rgba(255, 193, 7, 0.15) !important;

                    border:
                        1px solid
                        rgba(255, 193, 7, 0.45) !important;

                    color: #8a6d00 !important;
                }


                /*
                 * ====================================================
                 * BIBLIOTHÈQUE CATALOGUE
                 * ====================================================
                 */

                .koha-search-library-indicator {

                    background:
                        rgba(13, 110, 253, 0.12) !important;

                    border:
                        1px solid
                        rgba(13, 110, 253, 0.35) !important;

                    color: #0a58ca !important;
                }


                /*
                 * ====================================================
                 * BADGES ADHÉRENTS
                 * ====================================================
                 */

                .koha-member-search-filter-indicator {

                    display: none;

                    align-self: center !important;

                    align-items: center !important;
                    justify-content: center !important;

                    /*
                     * Même espacement que les badges catalogue.
                     */

                    margin-left: 2px !important;
                    margin-right: 2px !important;

                    padding: 1px 5px 1px 8px !important;

                    width: auto !important;
                    height: 20px !important;

                    min-height: 20px !important;
                    max-height: 20px !important;

                    box-sizing: border-box !important;

                    border-radius: 10px !important;

                    font-size: 10px !important;
                    font-weight: 500 !important;

                    line-height: 18px !important;

                    white-space: nowrap !important;

                    flex: 0 0 auto !important;

                    float: none !important;

                    position: relative !important;
                    top: 0 !important;

                    box-shadow: none !important;
                }


                /*
                 * ====================================================
                 * BADGES ADHÉRENTS ACTIFS
                 * ====================================================
                 */

                .koha-member-search-filter-indicator.is-active {

                    display: inline-flex !important;

                }


                /*
                 * ====================================================
                 * LABELS
                 * ====================================================
                 */

                .koha-search-index-label,
                .koha-search-library-label,
                .koha-member-search-filter-label {

                    display: inline-flex !important;

                    align-items: center !important;
                    justify-content: center !important;

                    height: 100% !important;

                    margin: 0 !important;
                    padding: 0 !important;

                    line-height: 1 !important;

                    vertical-align: middle !important;

                    white-space: nowrap !important;
                }


                /*
                 * ====================================================
                 * BOUTONS X
                 * ====================================================
                 */

                .koha-search-index-remove,
                .koha-search-library-remove,
                .koha-member-search-filter-remove {

                    display: inline-flex !important;

                    align-items: center !important;
                    justify-content: center !important;

                    width: 15px !important;
                    height: 15px !important;

                    min-width: 15px !important;
                    max-width: 15px !important;

                    min-height: 15px !important;
                    max-height: 15px !important;

                    margin: 0 0 0 5px !important;

                    padding: 0 !important;

                    border: 0 !important;

                    border-radius: 50% !important;

                    background: transparent !important;

                    box-shadow: none !important;

                    font-family: inherit !important;

                    font-size: 13px !important;

                    cursor: pointer !important;

                    flex: 0 0 15px !important;

                    overflow: hidden !important;

                    vertical-align: middle !important;

                    text-align: center !important;

                    line-height: 1 !important;

                    transition:
                        background-color 0.12s ease,
                        color 0.12s ease;
                }


                /*
                 * ====================================================
                 * ICÔNE FONT AWESOME
                 * ====================================================
                 */

                .koha-search-index-remove i,
                .koha-search-library-remove i,
                .koha-member-search-filter-remove i {

                    display: flex !important;

                    align-items: center !important;
                    justify-content: center !important;

                    width: 100% !important;
                    height: 100% !important;

                    margin: 0 !important;
                    padding: 0 !important;

                    line-height: 1 !important;
                }


                /*
                 * ====================================================
                 * SURVOL X INDEX
                 * ====================================================
                 */

                .koha-search-index-remove {

                    color: #8a6d00 !important;
                }


                .koha-search-index-remove:hover {

                    background:
                        rgba(138, 109, 0, 0.18) !important;

                    color: #5f4b00 !important;
                }


                /*
                 * ====================================================
                 * SURVOL X BIBLIOTHÈQUE CATALOGUE
                 * ====================================================
                 */

                .koha-search-library-remove {

                    color: #0a58ca !important;
                }


                .koha-search-library-remove:hover {

                    background:
                        rgba(10, 88, 202, 0.16) !important;

                    color: #084298 !important;
                }


                /*
                 * ====================================================
                 * COULEUR CHAMP DE RECHERCHE
                 * ====================================================
                 */

                .koha-member-search-filter-searchfield {

                    background:
                        rgba(111, 66, 193, 0.12) !important;

                    border:
                        1px solid
                        rgba(111, 66, 193, 0.35) !important;

                    color: #59359a !important;
                }


                .koha-member-search-filter-searchfield
                .koha-member-search-filter-remove {

                    color: #59359a !important;
                }


                .koha-member-search-filter-searchfield
                .koha-member-search-filter-remove:hover {

                    background:
                        rgba(111, 66, 193, 0.16) !important;

                    color: #432874 !important;
                }


                /*
                 * ====================================================
                 * COULEUR TYPE DE RECHERCHE
                 * ====================================================
                 */

                .koha-member-search-filter-searchtype {

                    background:
                        rgba(25, 135, 84, 0.12) !important;

                    border:
                        1px solid
                        rgba(25, 135, 84, 0.35) !important;

                    color: #146c43 !important;
                }


                .koha-member-search-filter-searchtype
                .koha-member-search-filter-remove {

                    color: #146c43 !important;
                }


                .koha-member-search-filter-searchtype
                .koha-member-search-filter-remove:hover {

                    background:
                        rgba(25, 135, 84, 0.16) !important;

                    color: #0f5132 !important;
                }


                /*
                 * ====================================================
                 * COULEUR BIBLIOTHÈQUE ADHÉRENT
                 * ====================================================
                 */

                .koha-member-search-filter-branch {

                    background:
                        rgba(13, 110, 253, 0.12) !important;

                    border:
                        1px solid
                        rgba(13, 110, 253, 0.35) !important;

                    color: #0a58ca !important;
                }


                .koha-member-search-filter-branch
                .koha-member-search-filter-remove {

                    color: #0a58ca !important;
                }


                .koha-member-search-filter-branch
                .koha-member-search-filter-remove:hover {

                    background:
                        rgba(13, 110, 253, 0.16) !important;

                    color: #084298 !important;
                }


                /*
                 * ====================================================
                 * COULEUR CATÉGORIE
                 * ====================================================
                 */

                .koha-member-search-filter-category {

                    background:
                        rgba(253, 126, 20, 0.12) !important;

                    border:
                        1px solid
                        rgba(253, 126, 20, 0.35) !important;

                    color: #c45c00 !important;
                }


                .koha-member-search-filter-category
                .koha-member-search-filter-remove {

                    color: #c45c00 !important;
                }


                .koha-member-search-filter-category
                .koha-member-search-filter-remove:hover {

                    background:
                        rgba(253, 126, 20, 0.16) !important;

                    color: #994700 !important;
                }


                /*
                 * ====================================================
                 * FOCUS CLAVIER
                 * ====================================================
                 */

                .koha-search-index-remove:focus,
                .koha-search-library-remove:focus,
                .koha-member-search-filter-remove:focus {

                    outline: none !important;

                    border-radius: 50% !important;

                    box-shadow:
                        0 0 0 2px
                        rgba(0, 0, 0, 0.20) !important;
                }


                .koha-search-index-indicator,
                .koha-search-library-indicator,
                .koha-member-search-filter-indicator {
                    max-width: min(24rem, calc(100vw - 3rem)) !important;
                    box-sizing: border-box;
                    flex-shrink: 1 !important;
                }
                .koha-search-index-label,
                .koha-search-library-label,
                .koha-member-search-filter-label {
                    min-width: 0;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .koha-search-index-remove:focus-visible,
                .koha-search-library-remove:focus-visible,
                .koha-member-search-filter-remove:focus-visible {

                    outline: none !important;

                    border-radius: 50% !important;

                    box-shadow:
                        0 0 0 2px
                        rgba(0, 0, 0, 0.25) !important;
                }

            `;

            document.head.appendChild(style);
        }


        /*
         * ============================================================
         * OUTIL : CRÉER UN BADGE
         * ============================================================
         */

        function createBadge(options) {

            const {
                select,
                className,
                labelClass,
                buttonClass,
                defaultValue,
                filterName,
                colorClass
            } = options;


            if (!select) return null;


            /*
             * --------------------------------------------------------
             * Recherche du bouton d'options avancées
             * --------------------------------------------------------
             */

            const extraContent =
                select.closest(
                    '.form-extra-content'
                );


            if (!extraContent) return null;


            const toggle =
                extraContent.parentElement &&
                extraContent.parentElement.querySelector(
                    '.form-extra-content-toggle'
                );


            if (!toggle) return null;


            /*
             * --------------------------------------------------------
             * Création du badge
             * --------------------------------------------------------
             */

            let indicator =
                extraContent.parentNode.querySelector(
                    '.' + className
                );


            if (!indicator) {

                indicator =
                    document.createElement('span');

                indicator.className =
                    className +
                    ' ' +
                    colorClass;

                indicator.setAttribute(
                    'aria-live',
                    'polite'
                );


                toggle.parentNode.insertBefore(
                    indicator,
                    toggle
                );
            }


            /*
             * --------------------------------------------------------
             * Label
             * --------------------------------------------------------
             */

            let label =
                indicator.querySelector(
                    '.' + labelClass
                );


            if (!label) {

                label =
                    document.createElement('span');

                label.className =
                    labelClass;

                indicator.appendChild(label);
            }


            /*
             * --------------------------------------------------------
             * Bouton X
             * --------------------------------------------------------
             */

            let removeButton =
                indicator.querySelector(
                    '.' + buttonClass
                );


            if (!removeButton) {

                removeButton =
                    document.createElement('button');

                removeButton.type =
                    'button';

                removeButton.className =
                    buttonClass;

                removeButton.setAttribute(
                    'aria-label',
                    'Retirer le filtre ' +
                    filterName.toLowerCase()
                );

                removeButton.setAttribute(
                    'title',
                    'Retirer le filtre'
                );

                removeButton.innerHTML =
                    '<i class="fa-solid fa-xmark" aria-hidden="true"></i>';

                indicator.appendChild(
                    removeButton
                );
            }


            /*
             * --------------------------------------------------------
             * Mise à jour
             * --------------------------------------------------------
             */

            function update() {

                const value =
                    select.value;


                /*
                 * Valeur par défaut :
                 * aucun badge.
                 */

                if (
                    value === defaultValue
                ) {

                    indicator.classList.remove(
                        'is-active'
                    );

                    label.textContent = '';

                    return;
                }


                const option =
                    select.options[
                        select.selectedIndex
                    ];


                if (!option) {

                    indicator.classList.remove(
                        'is-active'
                    );

                    label.textContent = '';

                    return;
                }


                const text =
                    option.textContent
                        .replace(/\s+/g, ' ')
                        .trim();


                label.textContent = text;
                label.title = text;
                removeButton.setAttribute('aria-label', 'Retirer le filtre ' + filterName.toLowerCase() + ' : ' + text);
                removeButton.title = 'Retirer le filtre : ' + text;


                indicator.classList.add(
                    'is-active'
                );


                indicator.setAttribute(
                    'aria-label',
                    filterName +
                    ' : ' +
                    text
                );
            }


            /*
             * --------------------------------------------------------
             * Suppression
             * --------------------------------------------------------
             */

            removeButton.addEventListener(
                'click',
                function (event) {

                    event.preventDefault();

                    event.stopPropagation();


                    select.value =
                        defaultValue;


                    select.dispatchEvent(
                        new Event(
                            'change',
                            {
                                bubbles: true
                            }
                        )
                    );


                    update();
                    // The removed badge is hidden; retain a useful keyboard position.
                    if (document.activeElement === removeButton) {
                        (select.getClientRects().length ? select : toggle).focus();
                    }
                }
            );


            /*
             * --------------------------------------------------------
             * Changement du select
             * --------------------------------------------------------
             */

            select.addEventListener(
                'change',
                update
            );


            /*
             * --------------------------------------------------------
             * État initial
             * --------------------------------------------------------
             */

            update();


            return {
                update: update,
                indicator: indicator
            };
        }


        /*
         * ============================================================
         * 1. RECHERCHE CATALOGUE — INDEX
         * ============================================================
         */

        const catalogIndex =
            document.getElementById('idx_0');


        createBadge({
            select: catalogIndex,

            className:
                'koha-search-index-indicator',

            labelClass:
                'koha-search-index-label',

            buttonClass:
                'koha-search-index-remove',

            defaultValue:
                'kw',

            filterName:
                'Index de recherche',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * 2. RECHERCHE CATALOGUE — BIBLIOTHÈQUE
         * ============================================================
         */

        const catalogLibrary =
            document.getElementById('select_library');


        createBadge({
            select: catalogLibrary,

            className:
                'koha-search-library-indicator',

            labelClass:
                'koha-search-library-label',

            buttonClass:
                'koha-search-library-remove',

            defaultValue:
                '',

            filterName:
                'Bibliothèque',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * 3. RECHERCHE ADHÉRENTS — CHAMP
         * ============================================================
         */

        const memberSearchField =
            document.getElementById(
                'searchfieldstype'
            );


        createBadge({
            select: memberSearchField,

            className:
                'koha-member-search-filter-indicator ' +
                'koha-member-search-filter-searchfield',

            labelClass:
                'koha-member-search-filter-label',

            buttonClass:
                'koha-member-search-filter-remove',

            defaultValue:
                'standard',

            filterName:
                'Champ de recherche',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * 4. RECHERCHE ADHÉRENTS — TYPE
         * ============================================================
         */

        const memberSearchType =
            document.getElementById(
                'searchtype'
            );


        createBadge({
            select: memberSearchType,

            className:
                'koha-member-search-filter-indicator ' +
                'koha-member-search-filter-searchtype',

            labelClass:
                'koha-member-search-filter-label',

            buttonClass:
                'koha-member-search-filter-remove',

            defaultValue:
                'contains',

            filterName:
                'Type de recherche',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * 5. RECHERCHE ADHÉRENTS — BIBLIOTHÈQUE
         * ============================================================
         */

        const memberBranch =
            document.getElementById(
                'branchcode'
            );


        createBadge({
            select: memberBranch,

            className:
                'koha-member-search-filter-indicator ' +
                'koha-member-search-filter-branch',

            labelClass:
                'koha-member-search-filter-label',

            buttonClass:
                'koha-member-search-filter-remove',

            defaultValue:
                '',

            filterName:
                'Bibliothèque',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * 6. RECHERCHE ADHÉRENTS — CATÉGORIE
         * ============================================================
         */

        const memberCategory =
            document.getElementById(
                'categorycode'
            );


        createBadge({
            select: memberCategory,

            className:
                'koha-member-search-filter-indicator ' +
                'koha-member-search-filter-category',

            labelClass:
                'koha-member-search-filter-label',

            buttonClass:
                'koha-member-search-filter-remove',

            defaultValue:
                '',

            filterName:
                'Catégorie',

            colorClass:
                ''
        });


        /*
         * ============================================================
         * FERMETURE DU MENU PAR CLIC EXTÉRIEUR
         * ============================================================
         *
         * Cette fonction est conservée pour le catalogue ET
         * pour la recherche adhérents.
         */

        const extraContents =
            document.querySelectorAll(
                '.form-extra-content'
            );


        extraContents.forEach(
            function (extraContent) {

                const parent =
                    extraContent.parentElement;


                if (!parent) return;


                const toggle =
                    parent.querySelector(
                        '.form-extra-content-toggle'
                    );


                if (!toggle) return;


                function isMenuOpen() {

                    return (
                        extraContent.offsetParent !== null ||
                        extraContent.classList.contains('show') ||
                        extraContent.classList.contains('open')
                    );
                }


                /*
                 * Évite d'installer plusieurs fois les
                 * événements si le script est chargé plusieurs fois.
                 */

                if (
                    extraContent.dataset
                        .kohaEnhancementsReady === 'true'
                ) {
                    return;
                }


                extraContent.dataset
                    .kohaEnhancementsReady = 'true';


                /*
                 * ----------------------------------------------------
                 * CLIC EXTÉRIEUR
                 * ----------------------------------------------------
                 */

                document.addEventListener(
                    'click',
                    function (event) {

                        if (!isMenuOpen()) {
                            return;
                        }


                        /*
                         * Clic dans le panneau.
                         */

                        if (
                            extraContent.contains(
                                event.target
                            )
                        ) {
                            return;
                        }


                        /*
                         * Clic sur le bouton.
                         */

                        if (
                            toggle.contains(
                                event.target
                            )
                        ) {
                            return;
                        }


                        /*
                         * Tout autre clic ferme.
                         */

                        toggle.click();

                    },
                    false
                );


                /*
                 * ----------------------------------------------------
                 * ESCAPE
                 * ----------------------------------------------------
                 */

                document.addEventListener(
                    'keydown',
                    function (event) {

                        if (
                            event.key !== 'Escape' ||
                            !isMenuOpen()
                        ) {
                            return;
                        }


                        toggle.click();


                        try {

                            toggle.focus();

                        } catch (e) {

                            // Rien à faire.

                        }

                    },
                    false
                );

            }
        );

    }


    /* ================================================================
     * INITIALISATION PMK
     * ================================================================ */
    async function pmk123Start() {
        pmk123EnsureDisableStyle();
        pmk123Register();
        if (window.PMKConfig && typeof window.PMKConfig.getConfig === 'function') {
            try { pmk123Config = pmk123Normalize(await window.PMKConfig.getConfig(PMK123_MODULE_ID)); } catch (_) {}
        }
        document.documentElement.classList.toggle('pmk123-disabled', pmk123Config.enabled === false);
        if (pmk123Config.enabled && !pmk123Initialized) {
            pmk123Initialized = true;
            initKohaSearchEnhancements();
        }
    }

    window.PMK123SearchFilterBadges = {
        moduleId: PMK123_MODULE_ID,
        version: PMK123_VERSION,
        refresh: pmk123Start
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', pmk123Start, { once: true });
    } else {
        pmk123Start();
    }
    if (!window.PMKConfig) window.addEventListener('pmk:config-ready', pmk123Register, { once: true });

})();
;window.PMKNonPlugin.loaded.push("123-badges-index-serch.js");
} catch (error) { window.PMKNonPlugin.errors.push("123-badges-index-serch.js: "+error.message); console.error("[PMK] 123-badges-index-serch.js",error); };
try {
/* ============================================================
   124-csp-enfant.js
   PimpMyKoha — Valeurs par défaut selon la catégorie d'adhérent
   Version : 3.0.0-preplugin
   Date : 2026-09-21

   Historique d’origine conservé : catégorie C -> sort1 = 12
   uniquement si sort1 est vide.

   Extension PMK :
   - plusieurs règles ;
   - catégories d'adhérents proposées depuis l'API Koha ;
   - choix sort1 / sort2 ;
   - catégories et valeurs autorisées proposées dynamiquement ;
   - saisie manuelle de repli si l'API n'est pas accessible.
   ============================================================ */
(function (window, document) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK124PatronCategoryDefaults) return;
    window.__PMK124PatronCategoryDefaults = true;

    const MODULE_ID = "patron-category-defaults";
    const MODULE_VERSION = "3.0.0-preplugin";
    const PAGE_PATH = "/cgi-bin/koha/members/memberentry.pl";
    const PAGE_ID = "members.memberentry";

    const DEFAULT_RULES = [
        {
            id: "legacy-child-csp",
            enabled: true,
            label: "Enfant — CSP 12",
            patronCategory: "C",
            targetField: "sort1",
            authorisedValueCategory: "",
            authorisedValue: "",
            manualValue: "12",
            onlyIfEmpty: true
        }
    ];

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        rules: clone(DEFAULT_RULES)
    });

    const catalogs = {
        patronCategories: [{ value: "C", label: { fr: "C — Enfant (historique)", en: "C — Child (legacy)" } }],
        authorisedCategories: [],
        authorisedValues: new Map(),
        loading: null
    };

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let formObserver = null;
    const automaticValues = new WeakMap();

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function clean(value) { return String(value == null ? "" : value).trim(); }
    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") return window.PMKConfig.getLanguage();
        return String(document.documentElement.lang || navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function makeId() {
        return "patron-default-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
    }

    function normalizeRule(raw, index) {
        const source = raw && typeof raw === "object" ? raw : {};
        return {
            id: clean(source.id) || ("patron-default-" + (index + 1)),
            enabled: source.enabled !== false,
            label: clean(source.label) || ("Règle " + (index + 1)),
            patronCategory: clean(source.patronCategory),
            targetField: source.targetField === "sort2" ? "sort2" : "sort1",
            authorisedValueCategory: clean(source.authorisedValueCategory),
            authorisedValue: clean(source.authorisedValue),
            manualValue: clean(source.manualValue),
            onlyIfEmpty: source.onlyIfEmpty !== false
        };
    }

    function normalizeConfig(raw) {
        const source = raw && typeof raw === "object" ? raw : {};
        const rules = Array.isArray(source.rules) ? source.rules.map(normalizeRule) : clone(DEFAULT_RULES).map(normalizeRule);
        return { enabled: source.enabled !== false, rules: rules };
    }

    async function fetchJson(url, headers) {
        const response = await fetch(url, {
            credentials: "same-origin",
            headers: Object.assign({ "Accept": "application/json" }, headers || {})
        });
        if (!response.ok) {
            const error = new Error("Koha API " + response.status + " — " + url);
            error.status = response.status;
            throw error;
        }
        return response.json();
    }

    async function prefetchCatalogs() {
        if (catalogs.loading) return catalogs.loading;
        catalogs.loading = Promise.allSettled([
            fetchJson("/api/v1/patron_categories?_per_page=500&_order_by=name"),
            fetchJson("/api/v1/authorised_value_categories?_per_page=500&_order_by=category_name", {
                "x-koha-embed": "authorised_values"
            })
        ]).then(function (results) {
            const patronResult = results[0];
            if (patronResult.status === "fulfilled" && Array.isArray(patronResult.value)) {
                const seen = new Set();
                catalogs.patronCategories = patronResult.value.map(function (row) {
                    const value = clean(row && (row.patron_category_id || row.categorycode));
                    const name = clean(row && (row.name || row.description));
                    if (!value || seen.has(value)) return null;
                    seen.add(value);
                    const display = name ? value + " — " + name : value;
                    return { value: value, label: { fr: display, en: display } };
                }).filter(Boolean);
                if (!seen.has("C")) catalogs.patronCategories.unshift({ value: "C", label: { fr: "C — valeur historique", en: "C — legacy value" } });
            }

            const avResult = results[1];
            if (avResult.status === "fulfilled" && Array.isArray(avResult.value)) {
                catalogs.authorisedCategories = [];
                catalogs.authorisedValues.clear();
                avResult.value.forEach(function (row) {
                    const name = clean(row && row.category_name);
                    if (!name) return;
                    catalogs.authorisedCategories.push({ value: name, label: { fr: name, en: name } });
                    const values = Array.isArray(row.authorised_values) ? row.authorised_values : [];
                    catalogs.authorisedValues.set(name, values.map(function (entry) {
                        const value = clean(entry && entry.value);
                        const description = clean(entry && (entry.description || entry.opac_description));
                        return {
                            value: value,
                            label: { fr: description ? value + " — " + description : value, en: description ? value + " — " + description : value }
                        };
                    }).filter(function (entry) { return entry.value; }));
                });
                catalogs.authorisedCategories.sort(function (a, b) { return a.value.localeCompare(b.value, language()); });
            }
            return catalogs;
        }).finally(function () { catalogs.loading = null; });
        return catalogs.loading;
    }

    function ruleFromPath(root, path) {
        if (!root || !Array.isArray(root.rules) || !Array.isArray(path)) return null;
        const pos = path.indexOf("rules");
        if (pos < 0) return null;
        const index = Number(path[pos + 1]);
        return Number.isInteger(index) ? root.rules[index] : null;
    }

    function optionWithCurrent(list, current, emptyLabel) {
        const result = [{ value: "", label: emptyLabel }].concat(list || []);
        if (current && !result.some(function (entry) { return String(entry.value) === String(current); })) {
            result.push({ value: current, label: { fr: current + " — valeur actuelle", en: current + " — current value" } });
        }
        return result;
    }

    function patronCategoryOptions(root, path) {
        const rule = ruleFromPath(root, path);
        return optionWithCurrent(catalogs.patronCategories, rule && rule.patronCategory, { fr: "— Choisir une catégorie —", en: "— Choose a category —" });
    }

    function authorisedCategoryOptions(root, path) {
        const rule = ruleFromPath(root, path);
        return optionWithCurrent(catalogs.authorisedCategories, rule && rule.authorisedValueCategory, { fr: "— Aucune / valeur manuelle —", en: "— None / manual value —" });
    }

    function authorisedValueOptions(root, path) {
        const rule = ruleFromPath(root, path);
        const category = clean(rule && rule.authorisedValueCategory);
        const values = category ? (catalogs.authorisedValues.get(category) || []) : [];
        return optionWithCurrent(values, rule && rule.authorisedValue, { fr: "— Choisir une valeur —", en: "— Choose a value —" });
    }

    function chosenValue(rule) {
        if (clean(rule.authorisedValueCategory)) return clean(rule.authorisedValue);
        return clean(rule.manualValue);
    }

    function dispatchChange(element) {
        element.dispatchEvent(new Event("change", { bubbles: true }));
        if (window.jQuery) {
            try { window.jQuery(element).trigger("change.select2"); } catch (_) {}
        }
    }

    function isEmptyValue(value) {
        const cleaned = clean(value);
        return cleaned === "" || cleaned === "0";
    }

    function ruleDecision(rule, target, current) {
        const value = chosenValue(rule);
        if (!target) return {state:"missing", value};
        if (rule.onlyIfEmpty && !isEmptyValue(current)) return {state:"preserved", value};
        if (!value) return {state:"empty", value};
        if (target.tagName === "SELECT" && !Array.from(target.options).some(option => String(option.value) === value)) {
            return {state:"unavailable", value};
        }
        return {state:String(current) === value ? "unchanged" : "apply", value};
    }

    function inspectRules(config, category) {
        const cfg = normalizeConfig(config || currentConfig);
        const form = document.getElementById("entryform");
        const selected = category === undefined ? clean(form?.querySelector("#categorycode_entry, #categorycode")?.value) : clean(category);
        const simulated = new Map(), rows = [];
        cfg.rules.forEach(rule => {
            if (!rule.enabled || rule.patronCategory !== selected) return;
            const target = form?.querySelector("#" + CSS.escape(rule.targetField));
            const current = simulated.has(rule.targetField) ? simulated.get(rule.targetField) : String(target?.value || "");
            const decision = ruleDecision(rule, target, current);
            const origin = target && automaticValues.get(target);
            rows.push({rule:rule.label, field:rule.targetField, current, proposed:decision.value,
                state:cfg.enabled ? decision.state : "disabled",
                origin:origin && origin.value === String(target.value) ? "automatic" : isEmptyValue(target?.value) ? "empty" : "existing",
                previousRule:origin?.label || "", conflicts:[]});
            if (cfg.enabled && decision.state === "apply") simulated.set(rule.targetField, decision.value);
        });
        rows.forEach(row => { row.conflicts = rows.filter(other => other !== row && other.field === row.field && other.proposed && row.proposed && other.proposed !== row.proposed).map(other => other.rule); });
        return {category:selected, onForm:!!form, rows};
    }

    function renderPreview(context) {
        const box = document.createElement("div"), select = document.createElement("select"), button = document.createElement("button"), output = document.createElement("div");
        const label = document.createElement("label");label.textContent = "Catégorie à simuler : ";label.appendChild(select);
        const native = document.querySelector("#entryform #categorycode_entry, #entryform #categorycode");
        const categories = new Map(Array.from(native?.options || []).map(option => [option.value, option.textContent]));
        (context.rootObject.rules || []).forEach(rule => { if(rule.patronCategory && !categories.has(rule.patronCategory)) categories.set(rule.patronCategory,rule.patronCategory); });
        categories.forEach((text,value) => { const option = document.createElement("option");option.value=value;option.textContent=text;select.appendChild(option); });
        if(native)select.value=native.value;
        button.type="button";button.className="btn btn-default btn-sm";button.textContent="Prévisualiser sans remplir les champs";
        output.setAttribute("aria-live","polite");
        button.addEventListener("click", () => {
            output.replaceChildren();
            const plan=inspectRules(context.rootObject,select.value), intro=document.createElement("p");
            intro.textContent=plan.onForm ? "Simulation dans l’ordre des règles. Les champs de l’adhérent restent inchangés. Une règle autorisant le remplacement peut remplacer la valeur d’une règle précédente." : "Ouvrez une fiche de création ou modification d’adhérent pour vérifier les champs et les valeurs disponibles.";
            output.appendChild(intro);
            const states={missing:"Champ absent",preserved:"Valeur conservée : le champ n’est pas vide",empty:"Valeur proposée vide",unavailable:"Valeur absente de la liste Koha",unchanged:"Valeur déjà présente",apply:"Sera rempli ou remplacé",disabled:"Module désactivé"};
            const origins={automatic:"Valeur proposée par PMK",existing:"Valeur existante ou saisie",empty:"Champ vide"};
            const table=document.createElement("table");table.className="table table-sm";
            const header=table.createTHead().insertRow();["Règle / champ","Valeur actuelle","Valeur proposée","Résultat"].forEach(text=>{const th=document.createElement("th");th.scope="col";th.textContent=text;header.appendChild(th);});
            const body=table.createTBody();plan.rows.forEach(row=>{
                const tr=body.insertRow();[row.rule+" / "+row.field,row.current+" — "+origins[row.origin],row.proposed,states[row.state]+(row.conflicts.length?". Autres valeurs proposées par : "+row.conflicts.join(", "):"")].forEach(text=>{tr.insertCell().textContent=text;});
            });
            if(plan.rows.length)output.appendChild(table);else{const p=document.createElement("p");p.textContent="Aucune règle active pour cette catégorie.";output.appendChild(p);}
        });
        box.append(label,button,output);return box;
    }

    function applyRules() {
        if (window.location.pathname !== PAGE_PATH || currentConfig.enabled === false) return;
        const form = document.getElementById("entryform");
        const categorySelect = form?.querySelector("#categorycode_entry, #categorycode");
        if (!categorySelect) return;
        const category = clean(categorySelect.value);
        currentConfig.rules.forEach(rule => {
            if (!rule || !rule.enabled || rule.patronCategory !== category) return;
            const target = form.querySelector("#" + CSS.escape(rule.targetField));
            const decision = ruleDecision(rule,target,target?.value);
            if(decision.state !== "apply")return;
            target.value=decision.value;
            dispatchChange(target);
            automaticValues.set(target,{value:decision.value,label:rule.label});
        });
    }

    function bindRuntime() {
        if (window.location.pathname !== PAGE_PATH) return;
        const form = document.getElementById("entryform");
        if (!form) return;
        const category = form.querySelector("#categorycode_entry, #categorycode");
        if (category && !category.dataset.pmk124Bound) {
            category.dataset.pmk124Bound = "1";
            category.addEventListener("change", function () { window.setTimeout(applyRules, 0); });
        }
        if (!formObserver && typeof MutationObserver === "function") {
            formObserver = new MutationObserver(function () { window.requestAnimationFrame(applyRules); });
            formObserver.observe(form, { childList: true, subtree: true });
        }
        applyRules();
    }

    function newRule() {
        return {
            id: makeId(),
            enabled: true,
            label: "Nouvelle règle",
            patronCategory: "",
            targetField: "sort1",
            authorisedValueCategory: "",
            authorisedValue: "",
            manualValue: "",
            onlyIfEmpty: true
        };
    }

    function validate(config) {
        const cfg = normalizeConfig(config);
        const ids = new Set();
        for (const rule of cfg.rules) {
            if (ids.has(rule.id)) return { ok: false, message: "Chaque règle doit avoir un identifiant unique." };
            ids.add(rule.id);
            if (rule.enabled && !rule.patronCategory) return { ok: false, message: "Une règle active doit préciser une catégorie d’adhérent." };
            if (rule.enabled && !chosenValue(rule)) return { ok: false, message: "Une règle active doit préciser une valeur à appliquer." };
        }
        return { ok: true };
    }

    function definition() {
        return {
            id: MODULE_ID,
            schemaVersion: 2,
            name: { fr: "Valeurs par défaut selon la catégorie d’adhérent", en: "Defaults by patron category" },
            description: {
                fr: "Renseigne automatiquement une catégorie statistique lors de la création ou de la modification d’un adhérent, selon sa catégorie d’inscription. Choisissez la catégorie concernée, le champ à remplir et la valeur proposée. Par défaut, une valeur déjà saisie est conservée.",
                en: "Automatically fills a statistical category when creating or editing a patron, based on the membership category. Choose the category, target field and proposed value. Existing values are kept by default."
            },
            category: { fr: "Lecteurs / saisie", en: "Patrons / entry" },
            supportedPages: [PAGE_ID],
            prerequisites: [],
            dependencies: [],
            defaults: clone(DEFAULT_CONFIG),
            normalize: normalizeConfig,
            validate: validate,
            schema: [
                {type:"custom",render:renderPreview},
                {
                    type: "section",
                    id: "rules",
                    label: { fr: "Règles de préremplissage", en: "Prefill rules" },
                    description: {
                        fr: "Par défaut : catégorie C → sort1 = 12, uniquement si sort1 est vide. Les listes Koha sont préchargées depuis les API REST ; si les droits ne permettent pas leur lecture, les codes actuels restent utilisables.",
                        en: "Default: category C → sort1 = 12, only when sort1 is empty. Koha lists are preloaded from REST APIs; current codes remain usable if API permissions prevent loading them."
                    },
                    fields: [
                        { key: "enabled", type: "boolean", label: { fr: "Activer le module", en: "Enable module" } },
                        {
                            key: "rules",
                            type: "repeater",
                            label: { fr: "Règles", en: "Rules" },
                            addLabel: { fr: "Ajouter une règle", en: "Add rule" },
                            reorder: true,
                            newItem: newRule,
                            itemTitle: function (item, index) { return clean(item && item.label) || ("Règle " + (index + 1)); },
                            fields: [
                                { key: "enabled", type: "boolean", label: { fr: "Règle active", en: "Rule enabled" } },
                                { key: "label", type: "text", label: { fr: "Nom", en: "Name" } },
                                {
                                    key: "patronCategory",
                                    type: "select",
                                    label: { fr: "Catégorie d’adhérent", en: "Patron category" },
                                    options: patronCategoryOptions
                                },
                                {
                                    key: "targetField",
                                    type: "select",
                                    label: { fr: "Champ à préremplir", en: "Field to prefill" },
                                    options: [
                                        { value: "sort1", label: { fr: "sort1 — catégorie statistique 1", en: "sort1 — statistical category 1" } },
                                        { value: "sort2", label: { fr: "sort2 — catégorie statistique 2", en: "sort2 — statistical category 2" } }
                                    ]
                                },
                                {
                                    key: "authorisedValueCategory",
                                    type: "select",
                                    refreshOnChange: true,
                                    label: { fr: "Catégorie de valeurs autorisées Koha", en: "Koha authorised-value category" },
                                    options: authorisedCategoryOptions,
                                    help: { fr: "Facultatif. Si aucune catégorie n’est choisie, utilisez la valeur manuelle.", en: "Optional. If no category is selected, use the manual value." }
                                },
                                {
                                    key: "authorisedValue",
                                    type: "select",
                                    label: { fr: "Valeur autorisée", en: "Authorised value" },
                                    options: authorisedValueOptions,
                                    help: { fr: "Liste dépendante de la catégorie choisie ci-dessus.", en: "List depends on the category selected above." }
                                },
                                {
                                    key: "manualValue",
                                    type: "text",
                                    label: { fr: "Valeur manuelle de repli", en: "Manual fallback value" },
                                    help: { fr: "Utilisée lorsqu’aucune catégorie de valeurs autorisées n’est sélectionnée. Valeur historique : 12.", en: "Used when no authorised-value category is selected. Historical value: 12." }
                                },
                                { key: "onlyIfEmpty", type: "boolean", label: { fr: "Ne remplir que si le champ est vide", en: "Only fill when the field is empty" } }
                            ]
                        }
                    ]
                }
            ]
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) { return false; }
        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, function (cfg) { currentConfig = normalizeConfig(cfg); applyRules(); }); } catch (_) {}
        }
        return true;
    }

    async function start() {
        registerModule();
        // Les listes dynamiques ne servent qu'à la configuration PMK, réservée
        // au super-administrateur. On évite ainsi des appels API inutiles (et
        // d'éventuels 403) sur les postes des agents ordinaires.
        const mayConfigure = !window.PMKConfig || typeof window.PMKConfig.isKohaSuperlibrarian !== "function"
            ? false
            : window.PMKConfig.isKohaSuperlibrarian();
        if (mayConfigure) {
            prefetchCatalogs().catch(function (error) { console.info("[PMK124] Listes Koha non préchargées", error); });
        }
        if (window.PMKConfig && typeof window.PMKConfig.getConfig === "function") {
            try { currentConfig = normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID)); } catch (_) {}
        }
        bindRuntime();
    }

    window.PMK124PatronCategoryDefaults = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,
        refreshCatalogs: function () { catalogs.loading = null; return prefetchCatalogs(); },
        refresh: applyRules,
        inspectRules: inspectRules
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
    if (!window.PMKConfig) window.addEventListener("pmk:config-ready", registerModule, { once: true });
})(window, document);

;window.PMKNonPlugin.loaded.push("124-csp-enfant.js");
} catch (error) { window.PMKNonPlugin.errors.push("124-csp-enfant.js: "+error.message); console.error("[PMK] 124-csp-enfant.js",error); };
try {
/* ============================================================
   125-double_clic_resrvation.js
   PimpMyKoha — Protection double validation des réservations
   Version : 2.0.0-preplugin
   ============================================================ */
(function (window, document, $) {
    "use strict";

    if (!window || !document) return;
    if (window.__PMK125HoldSubmitGuard) return;
    window.__PMK125HoldSubmitGuard = true;

    const MODULE_ID = "hold-submit-guard";
    const MODULE_VERSION = "2.0.0-preplugin";
    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,
        buttonSelector: "#hold_grp_btn",
        pendingTextFr: "Réservation en cours…",
        pendingTextEn: "Placing hold…",
        submissionMode: "navigation"
    });

    let currentConfig = clone(DEFAULT_CONFIG);
    let unsubscribe = null;
    let nativeBound = false;
    const pending = new Map();

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function lang() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") return window.PMKConfig.getLanguage();
        return String(document.documentElement.lang || navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }
    function normalizeConfig(raw) {
        const source = raw && typeof raw === "object" ? raw : {};
        return {
            enabled: source.enabled !== false,
            buttonSelector: String(source.buttonSelector || DEFAULT_CONFIG.buttonSelector),
            pendingTextFr: String(source.pendingTextFr || DEFAULT_CONFIG.pendingTextFr),
            pendingTextEn: String(source.pendingTextEn || DEFAULT_CONFIG.pendingTextEn),
            submissionMode: source.submissionMode === 'ajax' ? 'ajax' : 'navigation'
        };
    }

    function showPending(button) {
        const text = lang() === "en" ? currentConfig.pendingTextEn : currentConfig.pendingTextFr;
        const icon=document.createElement('i');icon.className='fa fa-spinner fa-spin';icon.setAttribute('aria-hidden','true');
        button.replaceChildren(icon,document.createTextNode(' '+text));
    }

    function release(form) {
        const saved=pending.get(form);if(!saved)return false;
        pending.delete(form);delete form.dataset.pmk125Submitting;
        saved.button.disabled=saved.disabled;
        if(saved.aria===null)saved.button.removeAttribute('aria-disabled');else saved.button.setAttribute('aria-disabled',saved.aria);
        saved.button.replaceChildren(...saved.children);
        return true;
    }

    function applyConfig(config) {
        currentConfig=normalizeConfig(config);
        if(!currentConfig.enabled)for(const form of pending.keys())release(form);
    }

    function findButton(form) {
        try { return form.querySelector(currentConfig.buttonSelector); } catch (_) { return null; }
    }

    function guardSubmit(event) {
        if (currentConfig.enabled === false) return;
        const form = event.target && event.target.closest ? event.target.closest("form") : null;
        if (!form) return;
        const button = findButton(form);
        if (!button) return;
        if(event.defaultPrevented)return;

        if (form.dataset.pmk125Submitting === "true") {
            event.preventDefault();
            event.stopImmediatePropagation();
            return false;
        }

        form.dataset.pmk125Submitting = "true";
        pending.set(form,{button,disabled:button.disabled,aria:button.getAttribute('aria-disabled'),children:[...button.childNodes]});
        button.disabled = true;
        button.setAttribute("aria-disabled", "true");
        showPending(button);
        // Attend la fin des validations synchrones de Koha. Une requête AJAX
        // annule aussi l'événement : elle doit libérer explicitement sa garde.
        if(currentConfig.submissionMode==='navigation')setTimeout(()=>{if(event.defaultPrevented)release(form);},0);
        return true;
    }

    function bindRuntime() {
        if (nativeBound) return;
        nativeBound = true;
        // Capture : la protection s'exécute avant les gestionnaires applicatifs
        // sans empêcher la première soumission légitime.
        document.addEventListener("submit", guardSubmit, true);
        window.addEventListener('pageshow',event=>{if(event.persisted)for(const form of pending.keys())release(form);});
        document.addEventListener('pmk:hold-submit-failed',event=>release(event.target.closest?.('form')));
        document.addEventListener('pmk:hold-submit-complete',event=>release(event.target.closest?.('form')));
    }

    function definition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: { fr: "Protection double validation — réservations", en: "Hold double-submit protection" },
            description: { fr: "Empêche un double clic ou une double soumission lors de la validation d’une réservation.", en: "Prevents double-clicks and duplicate submissions when placing a hold." },
            category: { fr: "Circulation / réservations", en: "Circulation / holds" },
            supportedPages: ["reserve.request"],
            defaults: clone(DEFAULT_CONFIG),
            schema: [
                { type: "section", id: "settings", label: { fr: "Réglages", en: "Settings" }, fields: [
                    { key: "enabled", type: "boolean", label: { fr: "Activer la protection", en: "Enable protection" } },
                    { key: "pendingTextFr", type: "text", label: { fr: "Texte pendant l’enregistrement — français", en: "Pending text — French" } },
                    { key: "pendingTextEn", type: "text", label: { fr: "Texte pendant l’enregistrement — anglais", en: "Pending text — English" } },
                    { key: "buttonSelector", type: "text", advanced: true, label: { fr: "Sélecteur du bouton Koha", en: "Koha button selector" } },
                    { key: "submissionMode", type: "select", advanced: true, label: {fr:"Envoi du formulaire",en:"Form submission"}, options:[{value:'navigation',label:{fr:'Navigation Koha native',en:'Native Koha navigation'}},{value:'ajax',label:{fr:'Requête AJAX personnalisée',en:'Custom AJAX request'}}],help:{fr:'Le mode natif débloque une validation annulée par Koha. En AJAX, l’intégration doit signaler explicitement la fin ou l’échec avec PMK125HoldSubmitGuard.release(form). Aucun délai ne relance automatiquement une réservation.',en:'Native mode releases a submission cancelled by Koha. AJAX integrations must explicitly call PMK125HoldSubmitGuard.release(form) on completion or failure. No timeout automatically retries a hold.'}}
                ]}
            ]
        };
    }

    function registerModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;
        try { window.PMKConfig.registerModule(definition()); } catch (_) { return false; }
        if (!unsubscribe && typeof window.PMKConfig.subscribe === "function") {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
        return true;
    }

    async function start() {
        registerModule();
        if (window.PMKConfig && typeof window.PMKConfig.getConfig === "function") {
            try { currentConfig = normalizeConfig(await window.PMKConfig.getConfig(MODULE_ID)); } catch (_) {}
        }
        bindRuntime();
    }

    window.PMK125HoldSubmitGuard = { moduleId: MODULE_ID, version: MODULE_VERSION, release };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
    if (!window.PMKConfig) window.addEventListener("pmk:config-ready", registerModule, { once: true });
})(window, document, window.jQuery);

;window.PMKNonPlugin.loaded.push("125-double_clic_resrvation.js");
} catch (error) { window.PMKNonPlugin.errors.push("125-double_clic_resrvation.js: "+error.message); console.error("[PMK] 125-double_clic_resrvation.js",error); };
try {
(async function(){
'use strict';
const pmkLegacy=await window.PMKLegacyOptions.ready;
const options=pmkLegacy.hideSuggestion;
if(pmkLegacy.enabled===false || options.enabled===false)return;
$(document).ready(function () {
    if (window.location.pathname === "/cgi-bin/koha/suggestion/suggestion.pl") {
        $("#newsuggestion").remove();
    }
});
})().catch(error=>console.error('[PMK options historiques]',error));

;window.PMKNonPlugin.loaded.push("126-masquer-btn-suggestion.js");
} catch (error) { window.PMKNonPlugin.errors.push("126-masquer-btn-suggestion.js: "+error.message); console.error("[PMK] 126-masquer-btn-suggestion.js",error); };
try {
/******************************************************************************/
/*Travail sur les données exemplaires page resultats de recherche*/
/**********************************************************************************/
(() => {
    "use strict";

    /* ============================================================
       129-mise-en-forme-exemplaire.js — V8.2.1 PMK — correction résumés / mots-clés
       Koha 25.11

       PAGE :
       /cgi-bin/koha/catalogue/search.pl UNIQUEMENT

       Fonctionnalités :
       - cloisonnement strict à la page de résultats
       - titre vert Koha
       - suppression numéro avant titre
       - présentation bibliographique compacte
       - suppression lignes réellement vides
       - suppression notice-details vide
       - acquisition intégrée au fond blanc
       - suppression fonds orange sujets / mots-clés
       - contraste renforcé
       - actions notice en bas à droite
       - actions mobiles par icônes
       - Afficher plus / Afficher moins fonctionnel sur mobile
       - respect des éléments initialement masqués
       - cartes exemplaires via API REST
       - appels API sérialisés par pool limité
       - site local en priorité
       - statut / cote / localisation / collection
       - icônes natives Koha
       - recherche progressive par cote
       - statistiques rapport 4537
       - détails exemplaire
       - bouton global Afficher tous les exemplaires
       ============================================================ */


    /* ============================================================
       GARDE ABSOLUE
       ============================================================ */

    const SEARCH_PATH =
        "/cgi-bin/koha/catalogue/search.pl";

    const MOBILE_QUERY =
        "(max-width: 767px)";

    const MODULE_ID =
        "search-results-master";

    const MODULE_VERSION =
        "8.2.0-preplugin";

    const MODULE_BASE_VERSION =
        "V8.1";

    const LOCAL_CONFIG_KEY =
        "PimpMyKoha.search-results-master.runtime.v2";

    const PMK_CONFIG_EVENT =
        "pmk129:config-changed";


    /* ============================================================
       CONFIGURATION PMK — valeurs par défaut = V8.1 actuel
       ============================================================ */

    const STATISTICS_REPORT_SQL = "SELECT\n    i.itemnumber AS \"Numero exemplaire\",\n    i.barcode AS \"Code-barres\",\n    b.title AS \"Titre\",\n    COALESCE(i.issues, 0) AS \"Compteur Koha de prets\",\n    (SELECT COUNT(*) FROM issues c WHERE c.itemnumber = i.itemnumber)\n      AS \"Prets en cours\",\n    (SELECT COUNT(*) FROM old_issues h WHERE h.itemnumber = i.itemnumber)\n      AS \"Prets termines conserves\",\n    (SELECT COUNT(*) FROM issues c WHERE c.itemnumber = i.itemnumber)\n      + (SELECT COUNT(*) FROM old_issues h WHERE h.itemnumber = i.itemnumber)\n      AS \"Total des prets conserves\",\n    COALESCE((SELECT SUM(c.renewals_count) FROM issues c WHERE c.itemnumber = i.itemnumber), 0)\n      + COALESCE((SELECT SUM(h.renewals_count) FROM old_issues h WHERE h.itemnumber = i.itemnumber), 0)\n      AS \"Renouvellements conserves\",\n    (SELECT MIN(h.issuedate) FROM old_issues h WHERE h.itemnumber = i.itemnumber)\n      AS \"Premier pret termine conserve\",\n    (SELECT MAX(h.issuedate) FROM old_issues h WHERE h.itemnumber = i.itemnumber)\n      AS \"Dernier pret termine conserve\",\n    (SELECT MAX(c.issuedate) FROM issues c WHERE c.itemnumber = i.itemnumber)\n      AS \"Pret en cours depuis\",\n    (SELECT MAX(h.returndate) FROM old_issues h WHERE h.itemnumber = i.itemnumber)\n      AS \"Dernier retour conserve\"\nFROM items i\nLEFT JOIN biblio b ON b.biblionumber = i.biblionumber\nWHERE i.itemnumber = <<Numéro exemplaire>>";

    const DEFAULT_CONFIG = {
        enabled: true,

        notice: {
            layoutEnabled: true,
            removeResultNumber: true,
            removeEmptyLines: true,
            mobileCollapseEnabled: true,
            mobileActionIconsEnabled: true
        },

        items: {
            cardsEnabled: true,
            prioritizeCurrentSite: true,
            prioritizeStatus: true,
            summaryEnabled: true,
            nativeItemTypeIcons: true,
            progressiveCallnumberSearch: true,
            collectionLinkEnabled: true,
            barcodeVisible: true,
            barcodeCopyEnabled: true,
            quickStatsEnabled: true,
            ownerVisible: true,
            itemTypeVisible: true,
            dueDateVisible: true,
            detailsEnabled: true,
            globalToggleEnabled: true,
            actions: {
                edit: true,
                statistics: true,
                movements: true,
                loanHistory: true
            }
        },

        reports: {
            statisticsReportId: 4537,
            statisticsReportFormat: 'legacy-default',
            statisticsParameterName: 'Numéro exemplaire',
            statisticsReportSql: STATISTICS_REPORT_SQL
        },

        performance: {
            apiPerPage: 100,
            maxPages: 20,
            concurrentRequests: 1
        },

        appearance: {
            titleColor: "#4f772d",
            titleHoverColor: "#365314",
            localBadgeVisible: true,
            localBadgeBackground: "#e1edf9",
            localBadgeTextColor: "#28649a",
            cardRadius: 7,
            availableAccent: "#3b9858",
            loanAccent: "#d89614",
            transferAccent: "#417db3",
            holdAccent: "#7558a6",
            unavailableAccent: "#a15b5b"
        },

        labels: {
            mySiteFr: "MON SITE",
            mySiteEn: "MY LIBRARY",
            unknownSiteFr: "Site inconnu",
            unknownSiteEn: "Unknown library",
            copyFr: "Copier",
            copyEn: "Copy",
            copiedFr: "Copié ✓",
            copiedEn: "Copied ✓",
            detailsFr: "Détails",
            detailsEn: "Details",
            reduceFr: "Réduire",
            reduceEn: "Collapse",
            showAllFr: "Afficher tous les exemplaires",
            showAllEn: "Show all items",
            hideAllFr: "Masquer tous les exemplaires",
            hideAllEn: "Hide all items",
            loanHistoryFr: "Historique de prêt",
            loanHistoryEn: "Loan history"
        }
    };

    function pmkClone(value) {
        if (value === undefined) return undefined;
        try { return JSON.parse(JSON.stringify(value)); }
        catch (_) { return value; }
    }

    function pmkIsObject(value) {
        return !!value && typeof value === "object" && !Array.isArray(value);
    }

    function pmkMerge(base, extra) {
        const out = pmkClone(base);
        if (!pmkIsObject(extra)) return out;
        Object.keys(extra).forEach(key => {
            const value = extra[key];
            if (pmkIsObject(value) && pmkIsObject(out[key])) out[key] = pmkMerge(out[key], value);
            else if (value !== undefined) out[key] = pmkClone(value);
        });
        return out;
    }

    function pmkClamp(value, min, max, fallback) {
        const n = Number(value);
        if (!Number.isFinite(n)) return fallback;
        return Math.min(max, Math.max(min, n));
    }

    function normalizePmkConfig(input) {
        const incoming = pmkIsObject(input) ? input : {};
        const result = pmkMerge(DEFAULT_CONFIG, incoming);

        /* Migration de l'ancienne tentative PMK v4 si une config existe déjà. */
        if (incoming.statisticsReportId !== undefined &&
            !(incoming.reports && incoming.reports.statisticsReportId !== undefined)) {
            result.reports.statisticsReportId = incoming.statisticsReportId;
        }

        result.enabled = result.enabled !== false;

        result.notice.layoutEnabled = result.notice.layoutEnabled !== false;
        result.notice.removeResultNumber = result.notice.removeResultNumber !== false;
        result.notice.removeEmptyLines = result.notice.removeEmptyLines !== false;
        result.notice.mobileCollapseEnabled = result.notice.mobileCollapseEnabled !== false;
        result.notice.mobileActionIconsEnabled = result.notice.mobileActionIconsEnabled !== false;

        result.items.cardsEnabled = result.items.cardsEnabled !== false;
        result.items.prioritizeCurrentSite = result.items.prioritizeCurrentSite !== false;
        result.items.prioritizeStatus = result.items.prioritizeStatus !== false;
        result.items.summaryEnabled = result.items.summaryEnabled !== false;
        result.items.nativeItemTypeIcons = result.items.nativeItemTypeIcons !== false;
        result.items.progressiveCallnumberSearch = result.items.progressiveCallnumberSearch !== false;
        result.items.collectionLinkEnabled = result.items.collectionLinkEnabled !== false;
        result.items.barcodeVisible = result.items.barcodeVisible !== false;
        result.items.barcodeCopyEnabled = result.items.barcodeCopyEnabled !== false;
        result.items.quickStatsEnabled = result.items.quickStatsEnabled !== false;
        result.items.ownerVisible = result.items.ownerVisible !== false;
        result.items.itemTypeVisible = result.items.itemTypeVisible !== false;
        result.items.dueDateVisible = result.items.dueDateVisible !== false;
        result.items.detailsEnabled = result.items.detailsEnabled !== false;
        result.items.globalToggleEnabled = result.items.globalToggleEnabled !== false;
        result.items.actions.edit = result.items.actions.edit !== false;
        result.items.actions.statistics = result.items.actions.statistics !== false;
        result.items.actions.movements = result.items.actions.movements !== false;
        result.items.actions.loanHistory = result.items.actions.loanHistory !== false;

        result.reports.statisticsReportId = Math.max(0, Number(result.reports.statisticsReportId) || 0);
        result.reports.statisticsReportFormat = result.reports.statisticsReportFormat==='standard'?'standard':'legacy-default';
        result.reports.statisticsParameterName = String(result.reports.statisticsParameterName || 'Numéro exemplaire').trim() || 'Numéro exemplaire';
        result.performance.apiPerPage = pmkClamp(result.performance.apiPerPage, 1, 500, 100);
        result.performance.maxPages = pmkClamp(result.performance.maxPages, 1, 100, 20);
        result.performance.concurrentRequests = pmkClamp(result.performance.concurrentRequests, 1, 5, 1);

        result.appearance.cardRadius = pmkClamp(result.appearance.cardRadius, 0, 24, 7);
        [
            "titleColor", "titleHoverColor", "localBadgeBackground", "localBadgeTextColor",
            "availableAccent", "loanAccent", "transferAccent", "holdAccent", "unavailableAccent"
        ].forEach(key => {
            if (typeof result.appearance[key] !== "string" || !result.appearance[key].trim()) {
                result.appearance[key] = DEFAULT_CONFIG.appearance[key];
            }
        });
        result.appearance.localBadgeVisible = result.appearance.localBadgeVisible !== false;

        Object.keys(DEFAULT_CONFIG.labels).forEach(key => {
            if (typeof result.labels[key] !== "string" || !result.labels[key].trim()) {
                result.labels[key] = DEFAULT_CONFIG.labels[key];
            }
        });

        return result;
    }

    function readLocalPmkConfig() {
        try {
            const raw = window.localStorage.getItem(LOCAL_CONFIG_KEY);
            return raw ? normalizePmkConfig(JSON.parse(raw)) : null;
        }
        catch (_) {
            return null;
        }
    }

    function writeLocalPmkConfig(config) {
        try {
            window.localStorage.setItem(LOCAL_CONFIG_KEY, JSON.stringify(normalizePmkConfig(config)));
        }
        catch (_) {}
    }

    let currentPmkConfig =
        readLocalPmkConfig()
        ||
        normalizePmkConfig(DEFAULT_CONFIG);

    let runtimeInitialized = false;
    let runtimeNeedsReload = false;
    let pmkSubscribed = false;

    const CONFIG = {
        reportId: currentPmkConfig.reports.statisticsReportId,
        apiPerPage: currentPmkConfig.performance.apiPerPage,
        maxPages: currentPmkConfig.performance.maxPages,
        concurrentRequests: currentPmkConfig.performance.concurrentRequests
    };

    function syncLegacyRuntimeConfig() {
        CONFIG.reportId = currentPmkConfig.reports.statisticsReportId;
        CONFIG.apiPerPage = currentPmkConfig.performance.apiPerPage;
        CONFIG.maxPages = currentPmkConfig.performance.maxPages;
        CONFIG.concurrentRequests = currentPmkConfig.performance.concurrentRequests;
    }

    function pmkLanguage() {
        try {
            if (window.PMKConfig && typeof window.PMKConfig.getLanguage === "function") {
                return window.PMKConfig.getLanguage() === "en" ? "en" : "fr";
            }
        }
        catch (_) {}
        return String(document.documentElement.lang || navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
    }

    function pmkLabel(frKey, enKey) {
        return pmkLanguage() === "en"
            ? currentPmkConfig.labels[enKey]
            : currentPmkConfig.labels[frKey];
    }

    function pmkFeature(path) {
        if (!currentPmkConfig.enabled) return false;
        const parts = String(path || "").split(".").filter(Boolean);
        let value = currentPmkConfig;
        for (const part of parts) {
            if (!value || typeof value !== "object") return false;
            value = value[part];
        }
        return value !== false;
    }

    function structuralFingerprint(config) {
        return JSON.stringify({
            enabled: config.enabled,
            notice: config.notice,
            items: config.items,
            reports: config.reports,
            performance: config.performance,
            labels: config.labels
        });
    }

    function applyPmkAppearance() {
        if (window.location.pathname !== SEARCH_PATH) return;
        let style = document.getElementById("pmk129-runtime-config-style");
        if (!style) {
            style = document.createElement("style");
            style.id = "pmk129-runtime-config-style";
            document.head.appendChild(style);
        }

        const a = currentPmkConfig.appearance;
        const r = Number(a.cardRadius) || 0;
        style.textContent = `
body.kx-search-results-page .kx-notice-head .titlebibresult a { color:${a.titleColor} !important; }
body.kx-search-results-page .kx-notice-head .titlebibresult a:hover { color:${a.titleHoverColor} !important; }
body.kx-search-results-page .kxri-local-badge { background:${a.localBadgeBackground} !important; color:${a.localBadgeTextColor} !important; ${a.localBadgeVisible ? "" : "display:none !important;"} }
body.kx-search-results-page .kx-notice-card,
body.kx-search-results-page .kxri-item { border-radius:${r}px !important; }
body.kx-search-results-page .kx-notice-cell.kx-has-external-biblio > .kx-notice-card { border-radius:${r}px ${r}px 0 0 !important; }
body.kx-search-results-page .kxri-item.is-available { border-left-color:${a.availableAccent} !important; }
body.kx-search-results-page .kxri-item.is-loan { border-left-color:${a.loanAccent} !important; }
body.kx-search-results-page .kxri-item.is-transfer { border-left-color:${a.transferAccent} !important; }
body.kx-search-results-page .kxri-item.is-hold { border-left-color:${a.holdAccent} !important; }
body.kx-search-results-page .kxri-item.is-unavailable { border-left-color:${a.unavailableAccent} !important; }
        `;
    }

    function applyPmkConfig(nextConfig) {
        const previousFingerprint = structuralFingerprint(currentPmkConfig);
        currentPmkConfig = normalizePmkConfig(nextConfig || DEFAULT_CONFIG);
        syncLegacyRuntimeConfig();
        writeLocalPmkConfig(currentPmkConfig);
        applyPmkAppearance();

        if (runtimeInitialized && previousFingerprint !== structuralFingerprint(currentPmkConfig)) {
            runtimeNeedsReload = true;
        }

        try {
            window.dispatchEvent(new CustomEvent(PMK_CONFIG_EVENT, { detail: pmkClone(currentPmkConfig) }));
        }
        catch (_) {}
    }

    function validatePmkConfig(config) {
        const c = normalizePmkConfig(config);
        if (c.items.actions.statistics && c.reports.statisticsReportId <= 0) {
            return {
                ok: false,
                message: "Le bouton Statistiques est actif mais aucun identifiant de rapport n'est renseigné."
            };
        }
        return { ok: true };
    }

    function registerPmkModule() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== "function") return false;

        try {
            window.PMKConfig.registerModule({
                id: MODULE_ID,
                schemaVersion: 3,
                name: {
                    fr: "Résultats catalogue — présentation et exemplaires",
                    en: "Catalog results — layout and items"
                },
                description: {
                    fr: "Améliore et organise l’affichage des résultats du catalogue : présentation des notices, exemplaires, disponibilités, actions, tri et chargement des données, tout en conservant le rendu configuré par défaut.",
                    en: "Improves and organizes catalogue search results: record layout, item availability, actions, sorting and on-demand data loading while preserving the configured default rendering."
                },
                category: {
                    fr: "Catalogue / résultats",
                    en: "Catalog / results"
                },
                supportedPages: ["catalogue.search"],
                prerequisites: [],
                dependencies: [],
                defaults: pmkClone(DEFAULT_CONFIG),
                normalize: normalizePmkConfig,
                validate: validatePmkConfig,
                schema: [
                    {
                        type: "section",
                        id: "activation",
                        label: { fr: "Activation", en: "Activation" },
                        fields: [
                            { key: "enabled", type: "boolean", label: { fr: "Activer le module 129", en: "Enable module 129" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "notice",
                        label: { fr: "Présentation des notices", en: "Record layout" },
                        fields: [
                            { key: "notice.layoutEnabled", type: "boolean", label: { fr: "Utiliser la présentation enrichie des notices", en: "Use enhanced record layout" } },
                            { key: "notice.removeResultNumber", type: "boolean", label: { fr: "Masquer le numéro placé avant le titre", en: "Hide result number before title" } },
                            { key: "notice.removeEmptyLines", type: "boolean", label: { fr: "Supprimer les lignes bibliographiques réellement vides", en: "Remove truly empty bibliographic lines" } },
                            { key: "notice.mobileCollapseEnabled", type: "boolean", label: { fr: "Afficher plus / moins sur mobile", en: "Show more / less on mobile" } },
                            { key: "notice.mobileActionIconsEnabled", type: "boolean", label: { fr: "Actions notice compactes sur mobile", en: "Compact record actions on mobile" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "items",
                        label: { fr: "Cartes exemplaires", en: "Item cards" },
                        description: {
                            fr: "Choisissez les informations et les commandes à afficher dans les cartes d’exemplaires.",
                            en: "Choose the information and controls displayed in item cards."
                        },
                        fields: [
                            { key: "items.cardsEnabled", type: "boolean", label: { fr: "Remplacer l'affichage natif par les cartes exemplaires", en: "Replace native display with item cards" } },
                            { key: "items.summaryEnabled", type: "boolean", label: { fr: "Afficher le résumé des exemplaires", en: "Show item summary" } },
                            { key: "items.nativeItemTypeIcons", type: "boolean", label: { fr: "Réutiliser les icônes natives des types de document", en: "Reuse native item type icons" } },
                            { key: "items.progressiveCallnumberSearch", type: "boolean", label: { fr: "Recherches progressives depuis la cote", en: "Progressive call-number searches" } },
                            { key: "items.collectionLinkEnabled", type: "boolean", label: { fr: "Code collection cliquable", en: "Clickable collection code" } },
                            { key: "items.barcodeVisible", type: "boolean", label: { fr: "Afficher le code-barres", en: "Show barcode" } },
                            { key: "items.barcodeCopyEnabled", type: "boolean", label: { fr: "Bouton Copier sur le code-barres", en: "Copy button for barcode" } },
                            { key: "items.quickStatsEnabled", type: "boolean", label: { fr: "Indicateurs rapides prêts / échéance", en: "Quick checkout / due-date indicators" } },
                            { key: "items.ownerVisible", type: "boolean", label: { fr: "Afficher le site propriétaire s'il diffère", en: "Show home library when different" } },
                            { key: "items.itemTypeVisible", type: "boolean", label: { fr: "Afficher le type de document", en: "Show item type" } },
                            { key: "items.dueDateVisible", type: "boolean", label: { fr: "Afficher le retour prévu", en: "Show due date" } },
                            { key: "items.detailsEnabled", type: "boolean", label: { fr: "Détails exemplaire repliables", en: "Expandable item details" } },
                            { key: "items.globalToggleEnabled", type: "boolean", label: { fr: "Bouton global Afficher / masquer tous les exemplaires", en: "Global show / hide all items button" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "sorting",
                        label: { fr: "Ordre des exemplaires", en: "Item ordering" },
                        fields: [
                            { key: "items.prioritizeCurrentSite", type: "boolean", label: { fr: "Placer mon site en premier", en: "Put current library first" } },
                            { key: "items.prioritizeStatus", type: "boolean", label: { fr: "Puis trier par disponibilité / statut", en: "Then sort by availability / status" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "actions",
                        label: { fr: "Actions sur les exemplaires", en: "Item actions" },
                        fields: [
                            { key: "items.actions.edit", type: "boolean", label: { fr: "Modifier l’exemplaire", en: "Edit item" } },
                            { key: "items.actions.statistics", type: "boolean", label: { fr: "Statistiques de prêt", en: "Checkout statistics" } },
                            { key: "items.actions.movements", type: "boolean", label: { fr: "Mouvements de l’exemplaire", en: "Item movements" } },
                            { key: "items.actions.loanHistory", type: "boolean", label: { fr: "Historique de prêt", en: "Loan history" } },
                            {
                                key: "reports.statisticsReportId",
                                type: "number",
                                min: 0,
                                step: 1,
                                label: { fr: "Numéro du rapport de statistiques de prêt", en: "Checkout statistics report ID" },
                                help: { fr: "Configuration initiale : 4537, conservé par défaut. Sur un autre Koha, créez le rapport SQL ci-dessous puis indiquez son numéro et choisissez le format « Rapport standard fourni ci-dessous ».", en: "Original installation defaults to 4537. On another Koha, create the SQL report below, enter its ID and choose the supplied standard-report format." }
                            },
                            {key:'reports.statisticsReportFormat',type:'select',label:{fr:'Rapport utilisé',en:'Report format'},options:[{value:'legacy-default',label:{fr:'Rapport existant préconfiguré (filtres historiques)',en:'Existing preconfigured report (historical filters)'}},{value:'standard',label:{fr:'Rapport standard fourni ci-dessous',en:'Supplied standard report'}}]},
                            {key:'reports.statisticsParameterName',type:'text',advanced:true,label:{fr:'Nom du paramètre exemplaire',en:'Item parameter name'},help:{fr:'Conserver « Numéro exemplaire » pour le SQL fourni.',en:'Keep “Numéro exemplaire” for the supplied SQL.'}},
                            {type:'section',id:'statistics-sql',label:{fr:'Créer le rapport sur un autre Koha',en:'Create the report on another Koha'},description:{fr:'Dans Rapports, choisissez « Créer à partir de SQL », copiez le SQL et enregistrez. Reportez le numéro du nouveau rapport ci-dessus et choisissez le rapport standard. Le résultat concerne l’exemplaire cliqué ; les compteurs d’historique portent sur les prêts encore conservés dans Koha.',en:'Create a SQL report in Koha, paste this query and save it. Enter the new report ID above and select the standard format. History counts cover records still retained in Koha.'},fields:[
                                {key:'reports.statisticsReportSql',type:'textarea',readOnly:true,rows:15,label:{fr:'SQL à copier',en:'SQL to copy'}},
                                {type:'action',buttonLabel:{fr:'Copier le SQL du rapport',en:'Copy report SQL'},action:async function(ctx){const value=String(ctx.rootObject.reports.statisticsReportSql || STATISTICS_REPORT_SQL);if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(value);return {message:'SQL copié.',level:'success'}}catch(_){}}const area=document.createElement('textarea');area.value=value;area.readOnly=true;document.body.appendChild(area);area.select();const copied=document.execCommand('copy');area.remove();return {message:copied?'SQL copié.':'Sélectionnez puis copiez le SQL affiché.',level:copied?'success':'info'};}}
                            ]}
                        ]
                    },
                    {
                        type: "section",
                        id: "appearance",
                        label: { fr: "Apparence", en: "Appearance" },
                        fields: [
                            { key: "appearance.titleColor", type: "color", label: { fr: "Couleur du titre", en: "Title color" } },
                            { key: "appearance.titleHoverColor", type: "color", label: { fr: "Couleur du titre au survol", en: "Title hover color" } },
                            { key: "appearance.localBadgeVisible", type: "boolean", label: { fr: "Afficher le badge MON SITE", en: "Show MY LIBRARY badge" } },
                            { key: "appearance.localBadgeBackground", type: "color", label: { fr: "Fond du badge MON SITE", en: "MY LIBRARY badge background" } },
                            { key: "appearance.localBadgeTextColor", type: "color", label: { fr: "Texte du badge MON SITE", en: "MY LIBRARY badge text" } },
                            { key: "appearance.cardRadius", type: "number", min: 0, max: 24, step: 1, advanced: true, label: { fr: "Arrondi des cartes (px)", en: "Card radius (px)" } },
                            { key: "appearance.availableAccent", type: "color", advanced: true, label: { fr: "Accent Disponible", en: "Available accent" } },
                            { key: "appearance.loanAccent", type: "color", advanced: true, label: { fr: "Accent En prêt", en: "On-loan accent" } },
                            { key: "appearance.transferAccent", type: "color", advanced: true, label: { fr: "Accent En transfert", en: "Transfer accent" } },
                            { key: "appearance.holdAccent", type: "color", advanced: true, label: { fr: "Accent Réservé", en: "Hold accent" } },
                            { key: "appearance.unavailableAccent", type: "color", advanced: true, label: { fr: "Accent Indisponible", en: "Unavailable accent" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "labels",
                        label: { fr: "Libellés", en: "Labels" },
                        fields: [
                            { key: "labels.mySiteFr", type: "text", label: { fr: "Badge mon site — FR", en: "My library badge — FR" } },
                            { key: "labels.mySiteEn", type: "text", label: { fr: "Badge mon site — EN", en: "My library badge — EN" } },
                            { key: "labels.showAllFr", type: "text", advanced: true, label: { fr: "Afficher tous — FR", en: "Show all — FR" } },
                            { key: "labels.showAllEn", type: "text", advanced: true, label: { fr: "Afficher tous — EN", en: "Show all — EN" } },
                            { key: "labels.hideAllFr", type: "text", advanced: true, label: { fr: "Masquer tous — FR", en: "Hide all — FR" } },
                            { key: "labels.hideAllEn", type: "text", advanced: true, label: { fr: "Masquer tous — EN", en: "Hide all — EN" } }
                        ]
                    },
                    {
                        type: "section",
                        id: "performance",
                        fields: [
                            { key: "performance.apiPerPage", type: "number", min: 1, max: 500, step: 1, advanced: true, label: { fr: "Exemplaires par page API", en: "Items per API page" } },
                            { key: "performance.maxPages", type: "number", min: 1, max: 100, step: 1, advanced: true, label: { fr: "Pages API maximum", en: "Maximum API pages" } },
                            { key: "performance.concurrentRequests", type: "number", min: 1, max: 5, step: 1, advanced: true, label: { fr: "Requêtes simultanées", en: "Concurrent requests" } }
                        ]
                    }
                ]
            });
        }
        catch (_) {
            return false;
        }

        if (typeof window.PMKConfig.getConfig === "function") {
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(config => applyPmkConfig(config || DEFAULT_CONFIG))
                .catch(() => {});
        }

        if (!pmkSubscribed && typeof window.PMKConfig.subscribe === "function") {
            pmkSubscribed = true;
            try {
                window.PMKConfig.subscribe(MODULE_ID, config => applyPmkConfig(config || DEFAULT_CONFIG));
            }
            catch (_) {}
        }

        return true;
    }

    function mountPmkContextButton() {
        if (window.location.pathname !== SEARCH_PATH) return;
        if (!window.PMKConfig || typeof window.PMKConfig.mountContextButton !== "function") return;
        const anchor =
            document.getElementById("toggle-all-exemplaires")
            || document.querySelector("#searchheader")
            || document.querySelector("#searchresults h1")
            || document.querySelector("h1");
        if (!anchor) return;
        try {
            window.PMKConfig.mountContextButton({
                moduleId: MODULE_ID,
                anchor,
                position: "after",
                contextKey: "catalogue-search-results",
                context: { sectionId: "items" }
            });
        }
        catch (_) {}
    }

    function connectPmk() {
        if (registerPmkModule()) return;
        window.addEventListener("pmk:config-ready", registerPmkModule, { once: true });
    }

    window.PMK129SearchResults = {
        id: MODULE_ID,
        version: MODULE_VERSION,
        baseVersion: MODULE_BASE_VERSION,
        getConfig: () => pmkClone(currentPmkConfig),
        featureEnabled: pmkFeature,
        getStatisticsUrl: getStatsUrl,
        needsReload: () => runtimeNeedsReload,
        diagnostic: () => ({
            version: MODULE_VERSION,
            baseVersion: MODULE_BASE_VERSION,
            enabled: currentPmkConfig.enabled,
            loadedOnSearchPage: window.location.pathname === SEARCH_PATH,
            runtimeInitialized,
            needsReload: runtimeNeedsReload,
            cards: document.querySelectorAll(".kxri-item").length,
            notices: document.querySelectorAll(".kx-notice-card").length,
            config: pmkClone(currentPmkConfig)
        })
    };

    connectPmk();


    if (
        window.location.pathname !==
        SEARCH_PATH
    ) {
        return;
    }


    if (
        window.__KX_SEARCH_RESULTS_V8__
    ) {
        return;
    }


    window.__KX_SEARCH_RESULTS_V8__ =
        true;


    const mobileMedia =
        window.matchMedia(
            MOBILE_QUERY
        );


    const originalShowMoreState =
        new WeakMap();

    let allExemplairesExpanded =
        false;


    let loggedBranchName =
        "";


    /* ============================================================
       CONTRÔLE DE PAGE
       ============================================================ */

    function isKohaSearchResultsPage() {

        return (
            window.location.pathname ===
                SEARCH_PATH

            &&

            !!document.getElementById(
                "bookbag_form"
            )

            &&

            !!document.querySelector(
                '#bookbag_form tbody tr[id^="row"]'
            )
        );
    }


    function isMobile() {

        return mobileMedia.matches;
    }


    /* ============================================================
       CSS
       ============================================================ */

    function installStyles() {

        if (
            !isKohaSearchResultsPage()
            ||
            document.getElementById(
                "kx-search-results-v8-style"
            )
        ) {
            return;
        }


        const style =
            document.createElement(
                "style"
            );


        style.id =
            "kx-search-results-v8-style";


        style.textContent = `


/* ============================================================
   PORTÉE STRICTE
   ============================================================ */

body.kx-search-results-page
#bookbag_form > table {
    width: 100%;
}


body.kx-search-results-page
#bookbag_form tbody > tr > td {
    vertical-align: top;
}


/* ============================================================
   COLONNE NOTICE
   ============================================================ */

body.kx-search-results-page
#bookbag_form tbody tr
> td.kx-notice-cell {

    position: relative;

    padding:
        7px
        10px
        54px
        10px !important;

    vertical-align:
        top !important;
}


/* ============================================================
   CARTE NOTICE
   ============================================================ */

body.kx-search-results-page
.kx-notice-card {

    position: static;

    box-sizing:
        border-box;

    background:
        #fff;

    border:
        1px solid
        #d9dfe3;

    border-radius:
        7px;

    box-shadow:
        0 1px 2px
        rgba(0,0,0,.025);

    overflow:
        visible;
}


/*
 * Lorsque les lignes bibliographiques sont
 * directement placées après la carte titre,
 * elles constituent la suite du même bloc.
 */

body.kx-search-results-page
.kx-notice-cell.kx-has-external-biblio
> .kx-notice-card {

    border-bottom:
        0;

    border-radius:
        7px
        7px
        0
        0;
}


/* ============================================================
   NOTICE-DETAILS VIDE
   ============================================================ */

body.kx-search-results-page
.kx-notice-details-empty {

    display:
        none !important;

    margin:
        0 !important;

    padding:
        0 !important;

    width:
        0 !important;

    height:
        0 !important;

    min-height:
        0 !important;

    border:
        0 !important;

    overflow:
        hidden !important;
}


/* ============================================================
   EN-TÊTE NOTICE
   ============================================================ */

body.kx-search-results-page
.kx-notice-head {

    display:
        flex;

    align-items:
        flex-start;

    justify-content:
        space-between;

    gap:
        10px;

    padding:
        8px
        11px;

    background:
        #f3f5f6;

    border-radius:
        7px
        7px
        0
        0;
}


body.kx-search-results-page
.kx-notice-head-main {

    min-width:
        0;

    flex:
        1;
}


/* ============================================================
   TITRE — VERT KOHA
   ============================================================ */

body.kx-search-results-page
.kx-notice-head
.firstresult {

    margin:
        0 !important;

    padding:
        0 !important;

    color:
        #26343b;

    line-height:
        1.35;
}


body.kx-search-results-page
.kx-notice-head
.titlemikaresult {

    color:
        #26343b;

    line-height:
        1.35;
}


body.kx-search-results-page
.kx-notice-head
.titlebibresult {

    font-size:
        17px;

    line-height:
        1.3;
}


body.kx-search-results-page
.kx-notice-head
.titlebibresult a {

    color:
        #4f772d !important;

    text-decoration:
        none;

    font-weight:
        700;
}


body.kx-search-results-page
.kx-notice-head
.titlebibresult a:hover {

    color:
        #365314 !important;

    text-decoration:
        underline;
}


/* Copier le titre */

body.kx-search-results-page
.kx-notice-head
.copy-title-result {

    width:
        15px !important;

    height:
        15px !important;

    margin-left:
        6px;

    opacity:
        .66;

    vertical-align:
        -2px;

    cursor:
        pointer;
}


body.kx-search-results-page
.kx-notice-head
.copy-title-result:hover {

    opacity:
        1;
}


/* ============================================================
   OUTILS DE L'ENTÊTE
   ============================================================ */

body.kx-search-results-page
.kx-notice-head-tools {

    display:
        flex;

    align-items:
        center;

    gap:
        5px;

    flex:
        0 0 auto;
}


/* ============================================================
   AFFICHER PLUS
   ============================================================ */

body.kx-search-results-page
.kx-notice-head
.btn-show-more {

    margin:
        0 !important;

    padding:
        4px
        8px !important;

    border:
        1px solid
        #c7d0d5 !important;

    border-radius:
        5px !important;

    background:
        #fff !important;

    color:
        #304b59 !important;

    font-size:
        11px !important;

    font-weight:
        600;

    box-shadow:
        none !important;

    outline:
        none !important;
}


body.kx-search-results-page
.kx-notice-head
.btn-show-more:hover {

    background:
        #eaf0f3 !important;

    border-color:
        #aebdc5 !important;

    color:
        #183d52 !important;
}


/* ============================================================
   PARTAGE
   ============================================================ */

body.kx-search-results-page
.kx-notice-head
.liens_externes {

    position:
        relative !important;

    width:
        auto !important;

    height:
        auto !important;

    margin:
        0 !important;

    padding:
        0 !important;
}


body.kx-search-results-page
.kx-notice-head
.liens_externes > br {

    display:
        none !important;
}


body.kx-search-results-page
.kx-notice-head
.share-button {

    width:
        29px !important;

    height:
        29px !important;

    margin:
        0 !important;

    padding:
        5px !important;

    border:
        1px solid
        #c7d0d5 !important;

    border-radius:
        5px !important;

    background:
        #fff !important;

    box-shadow:
        none !important;

    outline:
        none !important;
}


body.kx-search-results-page
.kx-notice-head
.share-button:hover {

    background:
        #eaf0f3 !important;
}


body.kx-search-results-page
.kx-notice-head
.share-button img {

    width:
        16px !important;

    height:
        16px !important;

    margin:
        0 !important;

    object-fit:
        contain;
}


body.kx-search-results-page
.kx-notice-head
.share-menu {

    z-index:
        5000 !important;

    top:
        calc(100% + 4px) !important;

    right:
        0 !important;

    left:
        auto !important;

    min-width:
        175px;

    padding:
        8px !important;

    background:
        #fff;

    border:
        1px solid
        #c9d2d7;

    border-radius:
        7px;

    box-shadow:
        0 5px 14px
        rgba(0,0,0,.18);
}


/* ============================================================
   DONNÉES DANS NOTICE-DETAILS
   ============================================================ */

body.kx-search-results-page
.kx-notice-card
.notice-details {

    margin:
        0 !important;

    padding:
        4px
        11px
        8px !important;

    background:
        #fff;

    color:
        #29373f;
}


body.kx-search-results-page
.kx-notice-card
.notice-details
> li.kx-biblio-line {

    margin:
        0;

    padding:
        4px
        5px;

    border:
        0 !important;

    line-height:
        1.42;

    color:
        #29373f !important;
}


/* ============================================================
   MÉTADONNÉES DIRECTEMENT DANS LE TD
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
> li.kx-biblio-line {

    box-sizing:
        border-box;

    margin:
        0 !important;

    padding:
        4px
        11px !important;

    list-style:
        none;

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;

    border-left:
        1px solid
        #d9dfe3;

    border-right:
        1px solid
        #d9dfe3;

    line-height:
        1.42;

    color:
        #29373f !important;
}


/* ============================================================
   CONTRASTE TEXTE
   ============================================================ */

body.kx-search-results-page
.kx-biblio-line {

    color:
        #29373f !important;
}


body.kx-search-results-page
.kx-biblio-line
> strong:first-child {

    color:
        #344a55 !important;

    font-weight:
        700;
}


body.kx-search-results-page
.kx-biblio-line a {

    color:
        #155b83;

    text-decoration-thickness:
        1px;

    text-underline-offset:
        2px;
}


body.kx-search-results-page
.kx-biblio-line a:hover {

    color:
        #073f60;
}


body.kx-search-results-page
.kx-biblio-line span,

body.kx-search-results-page
.kx-biblio-line p {

    color:
        inherit;
}


/* ============================================================
   COLLECTION / SÉRIE / CONTIENT
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
> li.kx-notice-meta-series {

    margin:
        0 !important;

    padding:
        4px
        11px !important;

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;

    border-left:
        1px solid
        #d9dfe3 !important;

    border-right:
        1px solid
        #d9dfe3 !important;

    border-radius:
        0 !important;
}


body.kx-search-results-page
.kx-notice-card
.kx-notice-meta-series {

    background:
        transparent !important;

    border:
        0 !important;
}


body.kx-search-results-page
.kx-notice-meta-series
> strong:first-child {

    color:
        #344a55 !important;
}


/* ============================================================
   AUTEUR / DONNÉES CLASSIQUES
   ============================================================ */

body.kx-search-results-page
.kx-notice-meta-basic,

body.kx-search-results-page
.kx-notice-meta-author {

    background:
        #fff !important;
}


body.kx-search-results-page
.kx-notice-meta-author a {

    font-weight:
        500;
}


/* ============================================================
   SUJETS / INDEXATION
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
> li.kx-notice-meta-subject {

    margin:
        0 !important;

    padding:
        4px
        11px !important;

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;

    border-left:
        1px solid
        #d9dfe3 !important;

    border-right:
        1px solid
        #d9dfe3 !important;

    border-radius:
        0 !important;
}


body.kx-search-results-page
.kx-notice-card
.kx-notice-meta-subject {

    background:
        transparent !important;

    border:
        0 !important;
}


/* ============================================================
   ACQUISITION 099
   Intégrée au même bloc blanc.
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
> li.kx-notice-meta-acquisition {

    margin:
        0 !important;

    padding:
        4px
        11px !important;

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;

    border-left:
        1px solid
        #d9dfe3 !important;

    border-right:
        1px solid
        #d9dfe3 !important;

    border-radius:
        0 !important;

    box-shadow:
        none !important;

    line-height:
        1.55 !important;

    color:
        #29373f !important;
}


body.kx-search-results-page
.kx-notice-card
.kx-notice-meta-acquisition {

    margin:
        0 !important;

    padding:
        4px
        5px !important;

    background:
        #fff !important;

    border:
        0 !important;

    border-radius:
        0 !important;

    box-shadow:
        none !important;

    line-height:
        1.55 !important;

    color:
        #29373f !important;
}


body.kx-search-results-page
.kx-notice-meta-acquisition
> strong:first-child {

    color:
        #344a55 !important;

    font-weight:
        700;
}


body.kx-search-results-page
.kx-notice-meta-acquisition u {

    text-decoration:
        none;

    color:
        #344a55 !important;

    font-size:
        10px;

    font-weight:
        700;

    text-transform:
        uppercase;

    letter-spacing:
        .025em;
}


body.kx-search-results-page
.kx-notice-meta-acquisition
img.acq-domaine,

body.kx-search-results-page
.kx-notice-meta-acquisition
img.acq-sous-domaine {

    max-width:
        18px !important;

    max-height:
        18px !important;

    vertical-align:
        -4px;

    opacity:
        .78;
}


body.kx-search-results-page
.kx-notice-meta-acquisition
img:hover {

    opacity:
        1;
}


/* ============================================================
   RÉSUMÉ / MOTS-CLÉS
   ============================================================ */

body.kx-search-results-page
.kx-notice-meta-fold {

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;
}


body.kx-search-results-page
.kx-notice-meta-subject.kx-notice-meta-fold {

    background:
        #fff !important;
}


body.kx-search-results-page
.kx-notice-meta-fold p {

    margin:
        0 !important;
}


body.kx-search-results-page
.kx-notice-meta-fold
.bouton {

    padding:
        3px
        8px;

    background:
        #edf1f3 !important;

    border:
        1px solid
        #cbd4d9 !important;

    border-radius:
        5px;

    color:
        #294553 !important;

    font-size:
        11px;

    font-weight:
        700;

    cursor:
        pointer;

    box-shadow:
        none !important;

    outline:
        none !important;
}


body.kx-search-results-page
.kx-notice-meta-fold
.bouton:hover {

    background:
        #e2e9ed !important;

    border-color:
        #aebcc4 !important;

    color:
        #153a4e !important;
}


/*
 * IMPORTANT :
 * aucun display n'est imposé ici.
 *
 * Si Koha ou ton ancien script masque une section,
 * elle reste masquée.
 */

body.kx-search-results-page
.kx-notice-meta-fold
.sectionz {

    margin-top:
        6px !important;

    padding:
        8px
        9px !important;

    background:
        #fff !important;

    border:
        1px solid
        #d5dde1 !important;

    border-radius:
        5px;

    color:
        #27363e !important;

    line-height:
        1.5;

    box-shadow:
        none !important;
}


body.kx-search-results-page
.kx-notice-meta-fold
.sectionz p,

body.kx-search-results-page
.kx-notice-meta-fold
.sectionz strong {

    color:
        #27363e;
}


/* ============================================================
   OUTILS ISBN / EAN / EFFICACITÉ
   ============================================================ */

body.kx-search-results-page
.kx-notice-meta-tools {

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;

    color:
        #29373f !important;
}


body.kx-search-results-page
.kx-notice-cell
> li.kx-notice-meta-tools {

    padding:
        6px
        10px !important;

    background:
        #fff !important;

    border-top:
        0 !important;

    border-bottom:
        0 !important;
}


body.kx-search-results-page
.kx-notice-meta-tools
> a,

body.kx-search-results-page
.kx-notice-meta-tools
> span,

body.kx-search-results-page
.kx-notice-meta-tools
> div {

    margin-right:
        6px;
}


body.kx-search-results-page
.kx-notice-meta-tools
> a > img {

    max-width:
        20px;

    max-height:
        20px;

    vertical-align:
        middle;
}


body.kx-search-results-page
.kx-notice-meta-tools
span.copy-isbn-result,

body.kx-search-results-page
.kx-notice-meta-tools
span.copy-ean-result {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        4px;

    min-height:
        22px;

    box-sizing:
        border-box;

    padding:
        2px
        6px;

    background:
        #f4f6f7 !important;

    border:
        1px solid
        #ced6da !important;

    border-radius:
        4px;

    color:
        #344a55 !important;

    font-size:
        10px;

    line-height:
        1.2;

    vertical-align:
        middle;

    cursor:
        pointer;
}


body.kx-search-results-page
.kx-notice-meta-tools
span.copy-isbn-result:hover,

body.kx-search-results-page
.kx-notice-meta-tools
span.copy-ean-result:hover {

    background:
        #eaf0f3 !important;

    border-color:
        #aebdc5 !important;

    color:
        #183d52 !important;
}


body.kx-search-results-page
.kx-notice-meta-tools
span.copy-isbn-result > img.copy-isbn-result,

body.kx-search-results-page
.kx-notice-meta-tools
span.copy-ean-result > img.copy-ean-result {

    display:
        inline-block !important;

    flex:
        0 0 auto;

    width:
        13px !important;

    height:
        13px !important;

    min-width:
        13px !important;

    max-width:
        13px !important;

    min-height:
        13px !important;

    max-height:
        13px !important;

    margin:
        0 !important;

    padding:
        0 !important;

    border:
        0 !important;

    border-radius:
        0 !important;

    background:
        transparent !important;

    box-shadow:
        none !important;

    object-fit:
        contain;

    vertical-align:
        middle;

    opacity:
        .78;
}


body.kx-search-results-page
.kx-notice-meta-tools
span.copy-isbn-result:hover > img.copy-isbn-result,

body.kx-search-results-page
.kx-notice-meta-tools
span.copy-ean-result:hover > img.copy-ean-result {

    opacity:
        1;
}


body.kx-search-results-page
.kx-notice-meta-tools
.global-efficiency-indicator {

    margin:
        2px !important;

    padding:
        3px
        6px !important;

    font-size:
        11px !important;

    border-radius:
        5px !important;
}


/* ============================================================
   DERNIÈRE LIGNE DU BLOC BIBLIO
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
> li.kx-biblio-last {

    border-bottom:
        1px solid
        #d9dfe3 !important;

    border-radius:
        0 0 7px 7px;
}


/* ============================================================
   ACTIONS NOTICE — DESKTOP
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
p.hold {

    position:
        absolute;

    right:
        10px;

    bottom:
        8px;

    margin:
        0 !important;

    padding:
        0 !important;

    text-align:
        right;

    line-height:
        29px !important;

    white-space:
        normal;
}


body.kx-search-results-page
.kx-notice-cell
p.hold > a {

    margin-left:
        4px;

    padding:
        4px
        7px;

    background:
        #f4f6f7;

    border:
        1px solid
        #cfd7db;

    border-radius:
        5px;

    color:
        #294a5d;

    text-decoration:
        none;

    font-size:
        11px;

    white-space:
        nowrap;

    outline:
        none !important;

    outline-offset:
        0 !important;

    box-shadow:
        none !important;
}


body.kx-search-results-page
.kx-notice-cell
p.hold > a:hover {

    background:
        #e6eef2;

    border-color:
        #aebdc5;

    color:
        #123e58;

    text-decoration:
        none;

    outline:
        none !important;

    box-shadow:
        none !important;
}


body.kx-search-results-page
.kx-notice-cell
p.hold > a:focus,

body.kx-search-results-page
.kx-notice-cell
p.hold > a:active,

body.kx-search-results-page
.kx-notice-cell
p.hold > a:focus-visible {

    outline:
        none !important;

    outline-offset:
        0 !important;

    box-shadow:
        none !important;

    text-decoration:
        none !important;
}


body.kx-search-results-page
.kx-notice-cell
p.hold > a::-moz-focus-inner {

    border:
        0 !important;
}


body.kx-search-results-page
.kx-notice-cell
p.hold
> a[id^="reserve_"] {

    background:
        #eef4f8;

    border-color:
        #c5d5df;

    color:
        #24546f;
}


body.kx-search-results-page
.kx-notice-cell
p.hold
> a[href*="/cataloguing/"] {

    background:
        #f6f4ed;

    border-color:
        #d9d2bd;

    color:
        #554f36;
}


/* ============================================================
   ÉLÉMENTS TECHNIQUES VIDES
   ============================================================ */

body.kx-search-results-page
.kx-notice-cell
.result-item:empty {

    display:
        none !important;
}


/* ============================================================
   COLONNE EXEMPLAIRES
   ============================================================ */

body.kx-search-results-page
td.kxri-cell {

    min-width:
        370px;

    vertical-align:
        top !important;
}


body.kx-search-results-page
.kxri-panel {

    width:
        100%;

    box-sizing:
        border-box;

    font-size:
        13px;
}


/*
 * Masqué uniquement après réussite API.
 */

body.kx-search-results-page
.kxri-native-hidden {

    display:
        none !important;
}


/* ============================================================
   RÉSUMÉ EXEMPLAIRES
   ============================================================ */

body.kx-search-results-page
.kxri-summary {

    display:
        flex;

    flex-wrap:
        wrap;

    align-items:
        center;

    gap:
        5px;

    margin:
        0
        0
        8px
        0;

    padding:
        6px
        8px;

    background:
        #f7f8fa;

    border:
        1px solid
        #dfe3e7;

    border-radius:
        6px;
}


body.kx-search-results-page
.kxri-summary-total {

    font-weight:
        700;

    color:
        #263a47;

    margin-right:
        3px;
}


body.kx-search-results-page
.kxri-summary-badge {

    display:
        inline-flex;

    align-items:
        center;

    padding:
        2px
        7px;

    border-radius:
        12px;

    font-size:
        11px;

    font-weight:
        600;

    white-space:
        nowrap;
}


body.kx-search-results-page
.kxri-summary-badge.is-available {

    background:
        #dff1e4;

    color:
        #1c6534;
}


body.kx-search-results-page
.kxri-summary-badge.is-loan {

    background:
        #ffedbf;

    color:
        #704900;
}


body.kx-search-results-page
.kxri-summary-badge.is-unavailable {

    background:
        #f2dddd;

    color:
        #713f3f;
}


/* ============================================================
   LISTE EXEMPLAIRES
   ============================================================ */

body.kx-search-results-page
.kxri-items {

    display:
        flex;

    flex-direction:
        column;

    gap:
        8px;
}


/* ============================================================
   CARTE EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-item {

    position:
        relative;

    box-sizing:
        border-box;

    border:
        1px solid
        #d8dde2;

    border-left:
        4px solid
        #9aa5ae;

    border-radius:
        7px;

    background:
        #fff;

    overflow:
        visible;

    transition:
        box-shadow .15s ease,
        border-color .15s ease;
}


body.kx-search-results-page
.kxri-item:hover {

    box-shadow:
        0 2px 7px
        rgba(0,0,0,.10);
}


/* Statuts */

body.kx-search-results-page
.kxri-item.is-available {

    border-left-color:
        #3b9858;
}


body.kx-search-results-page
.kxri-item.is-loan {

    border-left-color:
        #d89614;
}


body.kx-search-results-page
.kxri-item.is-transfer {

    border-left-color:
        #417db3;
}


body.kx-search-results-page
.kxri-item.is-hold {

    border-left-color:
        #7558a6;
}


body.kx-search-results-page
.kxri-item.is-unavailable {

    border-left-color:
        #a15b5b;
}


/* Fonds */

body.kx-search-results-page
.kxri-item.is-available
.kxri-main {

    background:
        #f0f8f2;
}


body.kx-search-results-page
.kxri-item.is-loan
.kxri-main {

    background:
        #fff8e7;
}


body.kx-search-results-page
.kxri-item.is-transfer
.kxri-main {

    background:
        #eef6fc;
}


body.kx-search-results-page
.kxri-item.is-hold
.kxri-main {

    background:
        #f5f1fa;
}


body.kx-search-results-page
.kxri-item.is-unavailable
.kxri-main {

    background:
        #fbefef;
}


body.kx-search-results-page
.kxri-item.is-local {

    box-shadow:
        inset
        0
        0
        0
        1px
        rgba(58,123,213,.25);
}


/* ============================================================
   CORPS EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-main {

    padding:
        8px
        9px;

    border-radius:
        6px
        6px
        0
        0;
}


body.kx-search-results-page
.kxri-topline {

    display:
        flex;

    align-items:
        flex-start;

    justify-content:
        space-between;

    gap:
        8px;
}


body.kx-search-results-page
.kxri-library-wrap {

    display:
        flex;

    align-items:
        center;

    gap:
        7px;

    min-width:
        0;

    flex:
        1;
}


body.kx-search-results-page
.kxri-itemtype-icon {

    flex:
        0 0 auto;

    width:
        28px;

    height:
        28px;

    object-fit:
        contain;
}


body.kx-search-results-page
.kxri-library-text {

    min-width:
        0;
}


body.kx-search-results-page
.kxri-library {

    font-size:
        14px;

    font-weight:
        700;

    line-height:
        1.2;

    color:
        #253746;
}


body.kx-search-results-page
.kxri-local-badge {

    display:
        inline-block;

    margin-left:
        5px;

    padding:
        1px
        5px;

    font-size:
        9px;

    border-radius:
        8px;

    background:
        #e1edf9;

    color:
        #28649a;
}


/* ============================================================
   STATUT EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-status {

    flex:
        0 0 auto;

    padding:
        3px
        7px;

    border-radius:
        11px;

    font-size:
        10px;

    line-height:
        15px;

    font-weight:
        700;

    white-space:
        nowrap;
}


body.kx-search-results-page
.kxri-status.is-available {

    background:
        #d7ecde;

    color:
        #226638;
}


body.kx-search-results-page
.kxri-status.is-loan {

    background:
        #ffe6ad;

    color:
        #744d00;
}


body.kx-search-results-page
.kxri-status.is-transfer {

    background:
        #dcebf7;

    color:
        #315f88;
}


body.kx-search-results-page
.kxri-status.is-hold {

    background:
        #e9e0f4;

    color:
        #604589;
}


body.kx-search-results-page
.kxri-status.is-unavailable {

    background:
        #efd8d8;

    color:
        #754343;
}


/* ============================================================
   LOCALISATION / COTE
   ============================================================ */

body.kx-search-results-page
.kxri-location-line {

    display:
        flex;

    flex-wrap:
        wrap;

    align-items:
        center;

    gap:
        5px
        8px;

    margin-top:
        6px;
}


body.kx-search-results-page
.kxri-location {

    color:
        #3f515c;
}


body.kx-search-results-page
.kxri-callnumber-wrap {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        3px;

    position:
        relative;
}


body.kx-search-results-page
.kxri-callnumber {

    font-weight:
        700;

    font-size:
        13px;
}


body.kx-search-results-page
.kxri-callnumber > a {

    color:
        #195e84;

    text-decoration:
        none;
}


body.kx-search-results-page
.kxri-callnumber > a:hover {

    text-decoration:
        underline;
}


/* ============================================================
   MENU COTE
   ============================================================ */

body.kx-search-results-page
.kxri-callnumber-menu {

    position:
        relative;

    display:
        inline-block;
}


body.kx-search-results-page
.kxri-callnumber-menu
> summary {

    list-style:
        none;

    cursor:
        pointer;

    padding:
        1px
        5px;

    border-radius:
        4px;

    background:
        rgba(255,255,255,.75);

    color:
        #3e5867;

    font-size:
        11px;

    user-select:
        none;
}


body.kx-search-results-page
.kxri-callnumber-menu
> summary::-webkit-details-marker {

    display:
        none;
}


body.kx-search-results-page
.kxri-callnumber-menu
> summary:hover {

    background:
        #fff;
}


body.kx-search-results-page
.kxri-callnumber-options {

    position:
        absolute;

    z-index:
        5000;

    top:
        calc(100% + 3px);

    left:
        0;

    min-width:
        210px;

    max-width:
        320px;

    padding:
        5px;

    background:
        #fff;

    border:
        1px solid
        #cfd6dc;

    border-radius:
        6px;

    box-shadow:
        0 4px 12px
        rgba(0,0,0,.18);
}


body.kx-search-results-page
.kxri-callnumber-options-title {

    padding:
        3px
        6px
        5px;

    font-size:
        10px;

    font-weight:
        700;

    text-transform:
        uppercase;

    color:
        #596d78;
}


body.kx-search-results-page
.kxri-callnumber-option {

    display:
        block;

    padding:
        5px
        7px;

    border-radius:
        4px;

    color:
        #245b79;

    text-decoration:
        none;

    font-size:
        12px;
}


body.kx-search-results-page
.kxri-callnumber-option:hover {

    background:
        #edf4f8;

    text-decoration:
        none;
}


/* ============================================================
   COLLECTION EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-collection {

    margin-top:
        5px;

    font-size:
        11px;

    color:
        #465b67;
}


body.kx-search-results-page
.kxri-collection a {

    display:
        inline-block;

    padding:
        1px
        6px;

    border-radius:
        9px;

    background:
        rgba(255,255,255,.75);

    color:
        #385769;

    text-decoration:
        none;

    font-weight:
        600;
}


body.kx-search-results-page
.kxri-collection a:hover {

    background:
        #fff;

    color:
        #195e84;

    text-decoration:
        underline;
}


/* ============================================================
   CODE-BARRES
   ============================================================ */

body.kx-search-results-page
.kxri-barcode-line {

    display:
        flex;

    align-items:
        center;

    flex-wrap:
        wrap;

    gap:
        5px;

    margin-top:
        6px;
}


body.kx-search-results-page
.kxri-barcode {

    padding:
        2px
        5px;

    background:
        rgba(255,255,255,.78);

    border-radius:
        4px;

    color:
        #2f414b;

    font-family:
        Consolas,
        "Courier New",
        monospace;

    font-size:
        12px;
}


body.kx-search-results-page
.kxri-copy {

    padding:
        2px
        4px;

    border:
        0;

    background:
        transparent;

    color:
        #405d6e;

    cursor:
        pointer;

    font-size:
        11px;

    outline:
        none !important;

    box-shadow:
        none !important;
}


body.kx-search-results-page
.kxri-copy:hover {

    color:
        #195e84;

    text-decoration:
        underline;
}


/* ============================================================
   INFOS EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-secondary {

    margin-top:
        5px;

    color:
        #445863;

    font-size:
        11px;

    line-height:
        1.4;
}


body.kx-search-results-page
.kxri-due {

    margin-top:
        5px;

    color:
        #795300;

    font-size:
        11px;

    font-weight:
        700;
}


body.kx-search-results-page
.kxri-quickstats {

    display:
        flex;

    flex-wrap:
        wrap;

    align-items:
        center;

    gap:
        5px;

    margin-top:
        6px;
}


body.kx-search-results-page
.kxri-quickstat {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        4px;

    padding:
        2px
        6px;

    border:
        1px solid
        rgba(0,0,0,.10);

    border-radius:
        10px;

    background:
        rgba(255,255,255,.76);

    color:
        #3d505b;

    font-size:
        10px;

    font-weight:
        700;

    line-height:
        1.35;

    white-space:
        nowrap;
}


body.kx-search-results-page
.kxri-quickstat.is-loans {

    color:
        #315b72;

    border-color:
        #c7d9e4;

    background:
        #eef6fa;
}


body.kx-search-results-page
.kxri-quickstat.is-due-future {

    color:
        #5e5200;

    border-color:
        #e2d596;

    background:
        #fff8d9;
}


body.kx-search-results-page
.kxri-quickstat.is-due-today {

    color:
        #704900;

    border-color:
        #dfbd6e;

    background:
        #ffedbf;
}


body.kx-search-results-page
.kxri-quickstat.is-overdue {

    color:
        #8a2f2f;

    border-color:
        #e2b2b2;

    background:
        #fbe2e2;
}


body.kx-search-results-page
.kxri-quickstat.is-not-for-loan {
    background: #f4e4e4;
    border-color: #ddbcbc;
    color: #7a3838;
}

body.kx-search-results-page
.kxri-date-age {
    margin-left: 5px;
    color: #6f7d85;
    font-size: 10px;
    font-weight: 500;
    white-space: nowrap;
}

body.kx-search-results-page
.kxri-date-age.is-overdue {
    color: #a13f38;
    font-weight: 700;
}

body.kx-search-results-page
.kxri-date-age.is-future {
    color: #6d5500;
    font-weight: 700;
}


/* ============================================================
   ACTIONS EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-actions {

    display:
        flex;

    flex-wrap:
        wrap;

    align-items:
        center;

    gap:
        4px;

    padding:
        5px
        8px;

    background:
        #fafbfc;

    border-top:
        1px solid
        #e1e6e9;
}


body.kx-search-results-page
.kxri-action {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        4px;

    padding:
        3px
        5px;

    border:
        0;

    border-radius:
        4px;

    background:
        transparent;

    color:
        #315a70;

    text-decoration:
        none;

    font-size:
        11px;

    cursor:
        pointer;

    outline:
        none !important;

    box-shadow:
        none !important;
}


body.kx-search-results-page
.kxri-action:hover {

    background:
        #edf3f7;

    color:
        #174d6d;

    text-decoration:
        none;
}


body.kx-search-results-page
.kxri-action:disabled {

    opacity:
        .55;

    cursor:
        wait;
}


/* ============================================================
   DÉTAILS EXEMPLAIRE
   ============================================================ */

body.kx-search-results-page
.kxri-details {

    display:
        none;

    padding:
        7px
        9px
        9px;

    background:
        #fff;

    border-top:
        1px solid
        #edf0f2;

    border-radius:
        0
        0
        6px
        6px;
}


body.kx-search-results-page
.kxri-item.is-expanded
.kxri-details {

    display:
        block;
}


body.kx-search-results-page
.kxri-detail-grid {

    display:
        grid;

    grid-template-columns:
        max-content
        1fr;

    gap:
        3px
        8px;

    font-size:
        11px;
}


body.kx-search-results-page
.kxri-detail-label {

    font-weight:
        700;

    color:
        #415762;
}


body.kx-search-results-page
.kxri-detail-value {

    min-width:
        0;

    color:
        #273940;

    overflow-wrap:
        anywhere;
}


body.kx-search-results-page
.kxri-detail-value a {

    color:
        #195e84;
}


/* ============================================================
   CHARGEMENT
   ============================================================ */

body.kx-search-results-page
.kxri-loading {

    padding:
        8px;

    color:
        #435966;

    font-size:
        11px;

    font-style:
        italic;
}


/* ============================================================
   BOUTON GLOBAL
   ============================================================ */

body.kx-search-results-page
#toggle-all-exemplaires.kx-all-open {

    background:
        #eef4f7 !important;

    border-color:
        #b9c9d2 !important;

    color:
        #315c73 !important;
}


/* ============================================================
   TABLETTE
   ============================================================ */

@media (max-width: 1200px) {

    body.kx-search-results-page
    td.kxri-cell {

        min-width:
            290px;
    }
}


/* ============================================================
   MOBILE
   ============================================================ */

@media (max-width: 767px) {


    /* --------------------------------------------------------
       CELLULE NOTICE
       -------------------------------------------------------- */

    body.kx-search-results-page
    #bookbag_form tbody tr
    > td.kx-notice-cell {

        padding-bottom:
            58px !important;
    }


    /* --------------------------------------------------------
       HEADER
       -------------------------------------------------------- */

    body.kx-search-results-page
    .kx-notice-head {

        display:
            grid;

        grid-template-columns:
            minmax(0,1fr)
            auto;

        align-items:
            start;

        gap:
            7px;

        padding:
            8px
            9px;
    }


    body.kx-search-results-page
    .kx-notice-head-tools {

        display:
            flex;

        align-items:
            center;

        justify-content:
            flex-end;

        gap:
            5px;
    }


    body.kx-search-results-page
    .kx-notice-head
    .titlebibresult {

        font-size:
            15px;
    }


    /* --------------------------------------------------------
       AFFICHER PLUS / MOINS
       -------------------------------------------------------- */

    body.kx-search-results-page
    .kx-notice-head
    .btn-show-more {

        min-height:
            29px;

        padding:
            4px
            8px !important;

        background:
            #fff !important;

        border:
            1px solid
            #bfcbd1 !important;

        color:
            #294553 !important;

        font-size:
            10px !important;

        font-weight:
            700;

        white-space:
            nowrap;
    }


    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-collapsed
    .btn-show-more::after {

        content:
            "  ▾";
    }


    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-expanded
    .btn-show-more::after {

        content:
            "  ▴";
    }


    /*
     * Repli :
     * on masque uniquement les lignes que notre script
     * a identifiées comme données bibliographiques.
     */

    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-collapsed
    > li.kx-biblio-line {

        display:
            none !important;
    }


    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-collapsed
    .notice-details
    > li.kx-biblio-line {

        display:
            none !important;
    }


    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-collapsed
    .notice-details {

        padding-top:
            0 !important;

        padding-bottom:
            0 !important;
    }


    /*
     * Quand replié, la carte titre se referme visuellement.
     */

    body.kx-search-results-page
    .kx-notice-cell.kx-mobile-collapsed
    > .kx-notice-card {

        border-bottom:
            1px solid
            #d9dfe3 !important;

        border-radius:
            7px !important;
    }


    /* --------------------------------------------------------
       ACTIONS NOTICE MOBILE
       -------------------------------------------------------- */

    body.kx-search-results-page
    .kx-notice-cell
    p.hold {

        display:
            flex;

        align-items:
            center;

        justify-content:
            flex-end;

        gap:
            5px;

        right:
            8px;

        bottom:
            8px;

        line-height:
            normal !important;
    }


    /*
     * Boutons carrés cohérents.
     */

    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action {

        display:
            inline-flex !important;

        align-items:
            center;

        justify-content:
            center;

        width:
            34px;

        height:
            34px;

        box-sizing:
            border-box;

        margin:
            0 !important;

        padding:
            0 !important;

        background:
            #f7f9f8 !important;

        border:
            1px solid
            #cbd5cf !important;

        border-radius:
            7px !important;

        color:
            #45682f !important;

        /*
         * Le libellé reste dans le DOM
         * mais n'est plus affiché visuellement.
         */
        font-size:
            0 !important;

        text-decoration:
            none !important;

        outline:
            none !important;

        box-shadow:
            none !important;
    }


    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action:hover,

    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action:focus {

        background:
            #edf3ea !important;

        border-color:
            #9eb292 !important;

        color:
            #365622 !important;

        outline:
            none !important;

        box-shadow:
            none !important;
    }


    /*
     * Une seule famille graphique :
     * on neutralise d'éventuelles anciennes icônes.
     */

    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action
    > i,

    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action
    > img {

        display:
            none !important;
    }


    /*
     * Koha charge déjà Font Awesome.
     */

    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-mobile-action::before {

        display:
            inline-block;

        font-family:
            FontAwesome;

        font-size:
            15px;

        font-style:
            normal;

        font-weight:
            normal;

        line-height:
            1;

        text-rendering:
            auto;

        -webkit-font-smoothing:
            antialiased;
    }


    /*
     * Réserver
     * bookmark
     */
    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-action-reserve::before {

        content:
            "\\f02e";
    }


    /*
     * Ajouter au panier
     * cart-plus
     */
    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-action-cart::before {

        content:
            "\\f217";
    }


    /*
     * Modifier notice
     * pencil-square
     */
    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-action-edit-biblio::before {

        content:
            "\\f044";
    }


    /*
     * Modifier exemplaires
     * list-alt
     */
    body.kx-search-results-page
    .kx-notice-cell
    p.hold
    > a.kx-action-edit-items::before {

        content:
            "\\f022";
    }


    /* --------------------------------------------------------
       EXEMPLAIRES MOBILE
       -------------------------------------------------------- */

    body.kx-search-results-page
    td.kxri-cell {

        min-width:
            280px;
    }


    body.kx-search-results-page
    .kxri-topline {

        flex-direction:
            column;
    }


    body.kx-search-results-page
    .kxri-status {

        align-self:
            flex-start;
    }

}

        `;


        document.head.appendChild(
            style
        );
    }


    /* ============================================================
       HELPERS
       ============================================================ */

    function normalize(value) {

        return String(
            value || ""
        )
            .normalize("NFD")
            .replace(
                /[\u0300-\u036f]/g,
                ""
            )
            .replace(
                /\s+/g,
                " "
            )
            .trim()
            .toLowerCase();
    }


    function escapeHtml(value) {

        return String(
            value ?? ""
        )
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );
    }


    function normalizedText(element) {

        return String(
            element?.textContent || ""
        )
            .replace(
                /\u00a0/g,
                " "
            )
            .replace(
                /[\u200B-\u200D\uFEFF]/g,
                ""
            )
            .replace(
                /\s+/g,
                " "
            )
            .trim();
    }


    function hasMeaningfulContent(
        element
    ) {

        if (!element) {
            return false;
        }


        if (
            normalizedText(
                element
            )
        ) {
            return true;
        }


        return !!element.querySelector(
            [
                "a",
                "button",
                "img",
                "input",
                "select",
                "textarea",
                "svg",
                ".global-efficiency-indicator"
            ].join(",")
        );
    }


    function getString(
        item,
        key
    ) {

        const value =
            item?._strings?.[key];


        if (
            value == null
        ) {
            return "";
        }


        if (
            typeof value ===
            "string"
        ) {
            return value;
        }


        return (
            value.str
            ||
            value.description
            ||
            value.name
            ||
            ""
        );
    }


    function formatDate(value) {

        if (!value) {
            return "";
        }


        const date =
            new Date(value);


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return String(value);
        }


        return new Intl.DateTimeFormat(
            "fr-FR",
            {
                day:
                    "2-digit",

                month:
                    "2-digit",

                year:
                    "numeric"
            }
        ).format(date);
    }


    function getBiblioNumber(row) {

        const match =
            row.id?.match(
                /^row(\d+)$/
            );


        if (match) {
            return match[1];
        }


        return (
            row
                .querySelector(
                    "[data-biblionumber]"
                )
                ?.dataset
                ?.biblionumber
            ||
            ""
        );
    }


    function getLoggedBranchName() {

        const selectors = [
            ".logged-in-branch-name",
            "#logged-in-info .branch-name",
            "#logged-in-info .logged-in-branch",
            "[data-branch-name]"
        ];


        for (
            const selector
            of selectors
        ) {

            const element =
                document.querySelector(
                    selector
                );


            if (!element) {
                continue;
            }


            const value =
                normalize(
                    element.textContent
                    ||
                    element.dataset
                        ?.branchName
                );


            if (value) {
                return value;
            }
        }


        return "";
    }


    /* ============================================================
       NOTICE-DETAILS VIDE
       ============================================================ */

    function syncNoticeDetailsState(
        cell
    ) {

        if (!cell) {
            return;
        }


        cell
            .querySelectorAll(
                ".notice-details"
            )
            .forEach(
                details => {

                    details.classList.toggle(
                        "kx-notice-details-empty",

                        !hasMeaningfulContent(
                            details
                        )
                    );
                }
            );
    }


    /* ============================================================
       SUPPRESSION LIGNES RÉELLEMENT VIDES
       ============================================================ */

    function removeEmptyBibliographicLines(
        cell
    ) {

        if (!pmkFeature("notice.removeEmptyLines")) {
            return;
        }

        if (!cell) {
            return;
        }


        /*
         * LI directement sous le TD.
         */

        Array
            .from(
                cell.children
            )
            .forEach(
                element => {

                    if (
                        element.tagName !==
                        "LI"
                    ) {
                        return;
                    }


                    if (
                        element.closest(
                            ".share-menu"
                        )
                        ||
                        element.closest(
                            ".availability"
                        )
                    ) {
                        return;
                    }


                    if (
                        !hasMeaningfulContent(
                            element
                        )
                    ) {

                        element.remove();
                    }
                }
            );


        /*
         * LI dans notice-details.
         */

        cell
            .querySelectorAll(
                ".notice-details > li"
            )
            .forEach(
                element => {

                    if (
                        !hasMeaningfulContent(
                            element
                        )
                    ) {

                        element.remove();
                    }
                }
            );


        /*
         * &nbsp; ou espaces seuls
         * directement dans le TD.
         */

        Array
            .from(
                cell.childNodes
            )
            .forEach(
                node => {

                    if (
                        node.nodeType !==
                        Node.TEXT_NODE
                    ) {
                        return;
                    }


                    const text =
                        String(
                            node.textContent
                            ||
                            ""
                        )
                            .replace(
                                /\u00a0/g,
                                " "
                            )
                            .replace(
                                /[\u200B-\u200D\uFEFF]/g,
                                ""
                            )
                            .trim();


                    if (!text) {
                        node.remove();
                    }
                }
            );
    }


    /* ============================================================
       NUMÉRO AVANT TITRE
       ============================================================ */

    function removeResultNumber(
        cell
    ) {

        if (!pmkFeature("notice.removeResultNumber")) {
            return;
        }

        if (!cell) {
            return;
        }


        Array
            .from(
                cell.childNodes
            )
            .forEach(
                node => {

                    if (
                        node.nodeType !==
                        Node.TEXT_NODE
                    ) {
                        return;
                    }


                    const text =
                        String(
                            node.textContent
                            ||
                            ""
                        )
                            .replace(
                                /\u00a0/g,
                                " "
                            )
                            .trim();


                    if (
                        /^\d+\.$/.test(
                            text
                        )
                    ) {

                        node.remove();
                    }
                }
            );
    }


    /* ============================================================
       CLASSIFICATION BIBLIO
       ============================================================ */

    function classifyBibliographicLine(
        element
    ) {

        if (
            !element
            ||
            element.nodeType !==
            Node.ELEMENT_NODE
            ||
            element.tagName !==
            "LI"
        ) {
            return;
        }


        if (
            element.closest(
                ".share-menu"
            )
            ||
            element.classList.contains(
                "liste-tech-site"
            )
        ) {
            return;
        }


        if (
            element.closest(
                ".availability"
            )
            ||
            element.classList.contains(
                "result_itype_image"
            )
        ) {
            return;
        }


        if (
            !hasMeaningfulContent(
                element
            )
        ) {

            element.remove();

            return;
        }


        element.classList.add(
            "kx-biblio-line"
        );


        const zone =
            element.getAttribute(
                "title"
            )
            ||
            "";


        const text =
            normalizedText(
                element
            );


        /* Collection / série / contient */

        if (
            /Zone\s*:\s*(225|461|464)/i
                .test(zone)
            ||
            /^(Collection|Série|Contient)\s*:/i
                .test(text)
        ) {

            element.classList.add(
                "kx-notice-meta-series"
            );
        }


        /* Auteurs */

        if (
            /Zone\s*:\s*(700|701|702|710|711|712)/i
                .test(zone)
            ||
            /^Auteur/i
                .test(text)
        ) {

            element.classList.add(
                "kx-notice-meta-author"
            );
        }


        /* Données classiques */

        if (
            /Zone\s*:\s*(101|200|205|210|214|215|333)/i
                .test(zone)
            ||
            /^(Edition|Édition|Description|Langue|Public|Type document bibliographique)\s*:/i
                .test(text)
        ) {

            element.classList.add(
                "kx-notice-meta-basic"
            );
        }


        /* Acquisition */

        if (
            /Zone\s*:\s*099/i
                .test(zone)
            ||
            /^Acquisition\s*:/i
                .test(text)
        ) {

            element.classList.add(
                "kx-notice-meta-acquisition"
            );
        }


        /* Sujet */

        if (
            /Zone\s*:\s*(6xx|600|601|602|606|607|608|610|903)/i
                .test(zone)
            ||
            /Sujet\s*-\s*(Indexation|Genre)/i
                .test(text)
        ) {

            element.classList.add(
                "kx-notice-meta-subject"
            );
        }


        /* Résumé / mots clés */

        if (
            element.querySelector(
                ".bouton"
            )
            ||
            element.querySelector(
                ".sectionz"
            )
        ) {

            element.classList.add(
                "kx-notice-meta-fold"
            );
        }


        /* Outils */

        if (
            element.querySelector(
                ".global-efficiency-indicator"
            )
            ||
            element.querySelector(
                ".copy-isbn-result"
            )
            ||
            element.querySelector(
                ".copy-ean-result"
            )
            ||
            element.querySelector(
                'a[href*="guided_reports.pl"][href*="id='+Number(CONFIG.reportId)+'"]'
            )
        ) {

            element.classList.add(
                "kx-notice-meta-tools"
            );
        }
    }


    /* ============================================================
       DERNIÈRE LIGNE BIBLIO
       ============================================================ */

    function updateExternalBibliographicLines(
        cell
    ) {

        if (!cell) {
            return;
        }


        const lines =
            Array
                .from(
                    cell.children
                )
                .filter(
                    element =>
                        element.matches(
                            "li.kx-biblio-line"
                        )
                );


        lines.forEach(
            line =>
                line.classList.remove(
                    "kx-biblio-last"
                )
        );


        if (
            lines.length
        ) {

            lines[
                lines.length - 1
            ].classList.add(
                "kx-biblio-last"
            );


            cell.classList.add(
                "kx-has-external-biblio"
            );

        }
        else {

            cell.classList.remove(
                "kx-has-external-biblio"
            );
        }
    }


    /* ============================================================
       MOBILE : AFFICHER PLUS / MOINS
       ============================================================ */

    function syncMobileNoticeControl(
        cell
    ) {

        if (!cell) {
            return;
        }


        const button =
            cell.querySelector(
                ".btn-show-more"
            );


        if (!button) {
            return;
        }


        /*
         * On mémorise l'état originel du bouton
         * pour le restaurer sur desktop.
         */

        if (
            !originalShowMoreState.has(
                button
            )
        ) {

            originalShowMoreState.set(
                button,
                {
                    html:
                        button.innerHTML,

                    ariaExpanded:
                        button.getAttribute(
                            "aria-expanded"
                        )
                }
            );
        }


        /*
         * DESKTOP :
         * notre système mobile est désactivé.
         */

        if (!isMobile() || !pmkFeature("notice.mobileCollapseEnabled")) {

            cell.classList.remove(
                "kx-mobile-collapsed",
                "kx-mobile-expanded"
            );


            const original =
                originalShowMoreState.get(
                    button
                );


            if (original) {

                button.innerHTML =
                    original.html;


                if (
                    original.ariaExpanded ===
                    null
                ) {

                    button.removeAttribute(
                        "aria-expanded"
                    );

                }
                else {

                    button.setAttribute(
                        "aria-expanded",
                        original.ariaExpanded
                    );
                }
            }


            return;
        }


        /*
         * Première initialisation mobile :
         * fermé par défaut sauf si l'ancien bouton
         * était explicitement ouvert.
         */

        if (
            cell.dataset
                .kxMobileExpanded ===
                undefined
        ) {

            cell.dataset
                .kxMobileExpanded =

                button.getAttribute(
                    "aria-expanded"
                ) === "true"

                    ? "1"

                    : "0";
        }


        const expanded =
            cell.dataset
                .kxMobileExpanded ===
                "1";


        cell.classList.toggle(
            "kx-mobile-expanded",
            expanded
        );


        cell.classList.toggle(
            "kx-mobile-collapsed",
            !expanded
        );


        button.textContent =
            expanded

                ? "Afficher moins"

                : "Afficher plus";


        button.setAttribute(
            "aria-expanded",
            String(expanded)
        );
    }


    function syncAllMobileNoticeControls(
        form
    ) {

        if (!form) {
            return;
        }


        form
            .querySelectorAll(
                "td.kx-notice-cell"
            )
            .forEach(
                syncMobileNoticeControl
            );
    }


    function toggleMobileNotice(
        button
    ) {

        const cell =
            button.closest(
                "td.kx-notice-cell"
            );


        if (!cell) {
            return;
        }


        const currentlyExpanded =
            cell.dataset
                .kxMobileExpanded ===
                "1";


        cell.dataset
            .kxMobileExpanded =

            currentlyExpanded

                ? "0"

                : "1";


        syncMobileNoticeControl(
            cell
        );
    }


    /* ============================================================
       ACTIONS MOBILE NOTICE
       ============================================================ */

    function prepareHoldActions(
        hold
    ) {

        if (!hold) {
            return;
        }


        hold
            .querySelectorAll(
                ":scope > a"
            )
            .forEach(
                link => {

                    /*
                     * Ne pas toucher au lien Supprimer du panier
                     * dont Koha gère lui-même la visibilité.
                     */

                    if (
                        link.classList.contains(
                            "cartRemove"
                        )
                    ) {
                        return;
                    }


                    const label =
                        normalizedText(
                            link
                        );


                    /*
                     * Info accessible + infobulle.
                     */

                    if (
                        label
                        &&
                        !link.getAttribute(
                            "title"
                        )
                    ) {

                        link.setAttribute(
                            "title",
                            label
                        );
                    }


                    if (
                        label
                        &&
                        !link.getAttribute(
                            "aria-label"
                        )
                    ) {

                        link.setAttribute(
                            "aria-label",
                            label
                        );
                    }


                    /* Réservation */

                    if (
                        /^reserve_/i.test(
                            link.id || ""
                        )
                    ) {

                        if (!pmkFeature("notice.mobileActionIconsEnabled")) return;

                        link.classList.add(
                            "kx-mobile-action",
                            "kx-action-reserve"
                        );

                        return;
                    }


                    /* Panier */

                    if (
                        link.classList.contains(
                            "addtocart"
                        )
                    ) {

                        if (!pmkFeature("notice.mobileActionIconsEnabled")) return;

                        link.classList.add(
                            "kx-mobile-action",
                            "kx-action-cart"
                        );

                        return;
                    }


                    const href =
                        link.getAttribute(
                            "href"
                        )
                        ||
                        "";


                    /* Modifier notice */

                    if (
                        /\/cataloguing\/addbiblio\.pl/i
                            .test(href)
                    ) {

                        if (!pmkFeature("notice.mobileActionIconsEnabled")) return;

                        link.classList.add(
                            "kx-mobile-action",
                            "kx-action-edit-biblio"
                        );

                        return;
                    }


                    /* Modifier exemplaires */

                    if (
                        /\/cataloguing\/additem\.pl/i
                            .test(href)
                    ) {

                        if (!pmkFeature("notice.mobileActionIconsEnabled")) return;

                        link.classList.add(
                            "kx-mobile-action",
                            "kx-action-edit-items"
                        );
                    }
                }
            );
    }


    /* ============================================================
       NETTOYAGE ACTIONS
       ============================================================ */

    function cleanActionSeparators(
        hold
    ) {

        if (!hold) {
            return;
        }


        Array
            .from(
                hold.childNodes
            )
            .forEach(
                node => {

                    if (
                        node.nodeType !==
                        Node.TEXT_NODE
                    ) {
                        return;
                    }


                    if (
                        /^[\s|\u00a0]*$/.test(
                            node.textContent
                            ||
                            ""
                        )
                    ) {

                        node.remove();
                    }
                }
            );


        prepareHoldActions(
            hold
        );
    }


    /* ============================================================
       TRAITEMENT CELLULE BIBLIO
       ============================================================ */

    function processBibliographicCell(
        cell
    ) {

        if (!pmkFeature("notice.layoutEnabled")) {
            return;
        }

        if (
            !cell
            ||
            !isKohaSearchResultsPage()
        ) {
            return;
        }


        removeResultNumber(
            cell
        );


        removeEmptyBibliographicLines(
            cell
        );


        /*
         * LI directs.
         */

        Array
            .from(
                cell.children
            )
            .forEach(
                element => {

                    if (
                        element.tagName ===
                        "LI"
                    ) {

                        classifyBibliographicLine(
                            element
                        );
                    }
                }
            );


        /*
         * LI dans notice-details.
         */

        cell
            .querySelectorAll(
                ".notice-details > li"
            )
            .forEach(
                classifyBibliographicLine
            );


        removeEmptyBibliographicLines(
            cell
        );


        syncNoticeDetailsState(
            cell
        );


        updateExternalBibliographicLines(
            cell
        );


        syncMobileNoticeControl(
            cell
        );
    }


    /* ============================================================
       OBSERVATEUR CELLULE BIBLIO
       ============================================================ */

    function observeBibliographicCell(
        cell
    ) {

        if (
            !cell
            ||
            cell.dataset
                .kxBiblioObserver ===
                "1"
        ) {
            return;
        }


        cell.dataset
            .kxBiblioObserver =
            "1";


        let scheduled =
            false;


        const observer =
            new MutationObserver(
                mutations => {

                    if (
                        !isKohaSearchResultsPage()
                    ) {

                        observer.disconnect();

                        return;
                    }


                    const changed =
                        mutations.some(
                            mutation =>
                                mutation
                                    .addedNodes
                                    .length
                                ||
                                mutation
                                    .removedNodes
                                    .length
                        );


                    if (
                        !changed
                        ||
                        scheduled
                    ) {
                        return;
                    }


                    scheduled =
                        true;


                    requestAnimationFrame(
                        () => {

                            scheduled =
                                false;


                            processBibliographicCell(
                                cell
                            );
                        }
                    );
                }
            );


        observer.observe(
            cell,
            {
                childList:
                    true,

                subtree:
                    true
            }
        );
    }


    /* ============================================================
       PRÉSENTATION NOTICE
       ============================================================ */

    function enhanceNoticeRow(
        row
    ) {

        if (!pmkFeature("notice.layoutEnabled")) {
            return;
        }

        if (
            !isKohaSearchResultsPage()
            ||
            row.dataset
                .kxNoticeDone ===
                "1"
        ) {
            return;
        }


        const cells =
            Array
                .from(
                    row.children
                )
                .filter(
                    element =>
                        element.tagName ===
                        "TD"
                );


        if (
            cells.length < 4
        ) {
            return;
        }


        const cell =
            cells[2];


        if (!cell) {
            return;
        }


        cell.classList.add(
            "kx-notice-cell"
        );


        removeResultNumber(
            cell
        );


        const firstResult =
            cell.querySelector(
                ":scope > .firstresult"
            );


        const share =
            cell.querySelector(
                ":scope > .liens_externes"
            );


        const showMore =
            cell.querySelector(
                ":scope > .btn-show-more"
            );


        const details =
            cell.querySelector(
                ":scope > .notice-details"
            );


        /*
         * D'autres scripts peuvent injecter
         * ces éléments après notre initialisation.
         */

        if (
            !firstResult
            &&
            !details
        ) {

            observeBibliographicCell(
                cell
            );

            return;
        }


        /* ========================================================
           CARTE
           ======================================================== */

        const card =
            document.createElement(
                "div"
            );


        card.className =
            "kx-notice-card";


        cell.insertBefore(
            card,
            cell.firstChild
        );


        /* ========================================================
           HEADER
           ======================================================== */

        const head =
            document.createElement(
                "div"
            );


        head.className =
            "kx-notice-head";


        const main =
            document.createElement(
                "div"
            );


        main.className =
            "kx-notice-head-main";


        if (firstResult) {

            main.appendChild(
                firstResult
            );
        }


        head.appendChild(
            main
        );


        /* ========================================================
           OUTILS
           ======================================================== */

        const tools =
            document.createElement(
                "div"
            );


        tools.className =
            "kx-notice-head-tools";


        if (showMore) {

            tools.appendChild(
                showMore
            );
        }


        if (share) {

            share
                .querySelectorAll(
                    ":scope > br"
                )
                .forEach(
                    br =>
                        br.remove()
                );


            tools.appendChild(
                share
            );
        }


        /*
         * Compatibilité avec le module Mouvements :
         *
         * - si le bouton a déjà été injecté dans .hold avant que
         *   cette mise en page ne soit construite, on le déplace
         *   dans les outils du titre ;
         * - le conteneur .kx-notice-head-tools est toujours ajouté,
         *   même vide, afin que le module Mouvements puisse y
         *   injecter son bouton s'il démarre après ce script.
         *
         * Le résultat est indépendant de l'ordre de chargement
         * des deux scripts.
         */

        const existingMovementButton =
            (
                cell.closest("tr")
                ||
                cell
            ).querySelector(
                ".kxmv-notice-btn"
            );


        if (
            existingMovementButton
            &&
            !tools.contains(
                existingMovementButton
            )
        ) {

            tools.appendChild(
                existingMovementButton
            );
        }


        head.appendChild(
            tools
        );


        card.appendChild(
            head
        );


        /* ========================================================
           NOTICE DETAILS
           ======================================================== */

        if (details) {

            details
                .querySelectorAll(
                    ":scope > li"
                )
                .forEach(
                    classifyBibliographicLine
                );


            const hold =
                details.querySelector(
                    ":scope > p.hold"
                );


            if (hold) {

                cleanActionSeparators(
                    hold
                );
            }


            card.appendChild(
                details
            );
        }


        /* ========================================================
           ACTIONS DIRECTES
           ======================================================== */

        const externalHold =
            cell.querySelector(
                ":scope > p.hold"
            );


        if (externalHold) {

            cleanActionSeparators(
                externalHold
            );


            card.appendChild(
                externalHold
            );
        }


        /*
         * BR directement sous TD uniquement.
         */

        Array
            .from(
                cell.children
            )
            .filter(
                element =>
                    element.tagName ===
                    "BR"
            )
            .forEach(
                br =>
                    br.remove()
            );


        observeBibliographicCell(
            cell
        );


        processBibliographicCell(
            cell
        );


        row.dataset
            .kxNoticeDone =
            "1";
    }


    /* ============================================================
       ICÔNES NATIVES EXEMPLAIRES
       ============================================================ */

    function buildNativeIconMap(
        row
    ) {

        const map =
            new Map();


        row
            .querySelectorAll(
                ".availability li.result_itype_image"
            )
            .forEach(
                li => {

                    const image =
                        li.querySelector(
                            ".itemtype-image"
                        );


                    const type =
                        li.querySelector(
                            ".item-itype-desc"
                        );


                    if (
                        !image
                        ||
                        !type
                    ) {
                        return;
                    }


                    const key =
                        normalize(
                            type.textContent
                        );


                    const src =
                        image.getAttribute(
                            "src"
                        );


                    if (
                        key
                        &&
                        src
                        &&
                        !map.has(key)
                    ) {

                        map.set(
                            key,
                            src
                        );
                    }
                }
            );


        return map;
    }


    /* ============================================================
       API KOHA
       ============================================================ */

    async function apiRequest(
        url,
        withEmbeds = true
    ) {

        const headers = {
            Accept:
                "application/json"
        };


        headers[
            "x-koha-embed"
        ] =
            withEmbeds

                ? "+strings,checkout,transfer,first_hold"

                : "+strings";


        const response =
            await fetch(
                url,
                {
                    method:
                        "GET",

                    credentials:
                        "same-origin",

                    headers,
                    signal:AbortSignal.timeout(15000)
                }
            );


        if (!response.ok) {

            throw new Error(
                `API Koha ${response.status} ${response.statusText}`
            );
        }


        return response;
    }


    async function fetchItemsPage(
        biblioNumber,
        page,
        withEmbeds
    ) {

        const url =
            `/api/v1/biblios/${encodeURIComponent(biblioNumber)}/items`
            +
            `?_page=${page}`
            +
            `&_per_page=${CONFIG.apiPerPage}`;


        const response =
            await apiRequest(
                url,
                withEmbeds
            );


        return {
            items:
                await response.json(),

            total:
                Number(
                    response.headers.get(
                        "x-total-count"
                    )
                    ||
                    0
                )
        };
    }


    async function fetchAllItems(biblioNumber) {
        async function load(withEmbeds) {
            const result=[];let total=null;
            for(let page=1;page<=CONFIG.maxPages;page++) {
                let response;
                try {
                    response=await fetchItemsPage(biblioNumber,page,withEmbeds);
                    if(!Array.isArray(response.items))throw new Error('Réponse exemplaires invalide.');
                } catch(error){if(!result.length)throw error;return {items:result,complete:false,total,reason:error.message};}
                const items=response.items;result.push(...items);
                if(Number.isFinite(response.total)&&response.total>0)total=response.total;
                if(!items.length && total!==null && result.length<total)return {items:result,complete:false,total,reason:'La réponse ne contient pas tous les exemplaires annoncés.'};
                if((total!==null&&result.length>=total) || (total===null&&items.length<CONFIG.apiPerPage))return {items:result,complete:true,total:total??result.length};
            }
            return {items:result,complete:false,total,reason:'Limite de pages configurée atteinte.'};
        }
        try{return await load(true);}catch(error){return await load(false);}
    }

    function appendItemsRetry(panel,row,message) {
        const notice=document.createElement('div');notice.className='kxri-load-notice';notice.setAttribute('role','status');
        const text=document.createElement('p');text.textContent=message;
        const retry=document.createElement('button');retry.type='button';retry.className='btn btn-default btn-sm kxri-retry';retry.textContent='Réessayer cette notice';
        retry.addEventListener('click',async()=>{if(retry.disabled)return;retry.disabled=true;panel.remove();delete row.dataset.kxriDone;delete row.dataset.kxriPartial;await processExemplairesRow(row);});
        notice.append(text,retry);panel.prepend(notice);
    }

    /* ============================================================
       STATUT EXEMPLAIRE
       ============================================================ */

    function getStatus(item) {

        const lost =
            Number(
                item.lost_status
                ||
                0
            );


        const withdrawn =
            Number(
                item.withdrawn_status
                ??
                item.withdrawn
                ??
                0
            );


        const damaged =
            Number(
                item.damaged_status
                ||
                0
            );


        const notForLoan =
            Number(
                item.effective_not_for_loan_status
                ??
                item.not_for_loan_status
                ??
                0
            );


        if (lost) {

            return {
                key:
                    "unavailable",

                label:
                    getString(
                        item,
                        "lost_status"
                    )
                    ||
                    "Perdu"
            };
        }


        if (withdrawn) {

            return {
                key:
                    "unavailable",

                label:
                    getString(
                        item,
                        "withdrawn_status"
                    )
                    ||
                    getString(
                        item,
                        "withdrawn"
                    )
                    ||
                    "Retiré"
            };
        }


        if (damaged) {

            return {
                key:
                    "unavailable",

                label:
                    getString(
                        item,
                        "damaged_status"
                    )
                    ||
                    "Endommagé"
            };
        }


        if (item.checkout) {

            return {
                key:
                    "loan",

                label:
                    "En prêt"
            };
        }


        if (item.transfer) {

            return {
                key:
                    "transfer",

                label:
                    "En transit"
            };
        }


        if (item.first_hold) {

            return {
                key:
                    "hold",

                label:
                    "Réservé"
            };
        }


        if (notForLoan) {

            return {
                key:
                    "unavailable",

                label:
                    getString(
                        item,
                        "effective_not_for_loan_status"
                    )
                    ||
                    getString(
                        item,
                        "not_for_loan_status"
                    )
                    ||
                    "Indisponible"
            };
        }


        return {
            key:
                "available",

            label:
                "Disponible"
        };
    }


    /* ============================================================
       DONNÉES EXEMPLAIRE
       ============================================================ */

    function getItemTypeCode(item) {

        return (
            item.effective_item_type_id
            ||
            item.item_type_id
            ||
            ""
        );
    }


    function getItemTypeLabel(item) {

        return (
            getString(
                item,
                "effective_item_type_id"
            )
            ||
            getString(
                item,
                "item_type_id"
            )
            ||
            getItemTypeCode(item)
            ||
            ""
        );
    }


    function getHoldingLibrary(item) {

        return (
            getString(
                item,
                "holding_library_id"
            )
            ||
            item.holding_library?.name
            ||
            item.holding_library_id
            ||
            ""
        );
    }


    function getHomeLibrary(item) {

        return (
            getString(
                item,
                "home_library_id"
            )
            ||
            item.home_library?.name
            ||
            item.home_library_id
            ||
            ""
        );
    }


    function getLocation(item) {

        return (
            getString(
                item,
                "location"
            )
            ||
            item.location
            ||
            ""
        );
    }


    function getCollectionCode(item) {

        return (
            item.collection_code
            ||
            ""
        );
    }


    function getCollectionLabel(item) {

        return (
            getString(
                item,
                "collection_code"
            )
            ||
            getCollectionCode(item)
            ||
            ""
        );
    }


    /* ============================================================
       URLS
       ============================================================ */

    function getCallnumberUrl(
        callnumber
    ) {

        return (
            "/cgi-bin/koha/catalogue/search.pl"
            +
            "?idx=callnum&q="
            +
            encodeURIComponent(
                `"${callnumber}"`
            )
        );
    }


    function getCollectionUrl(
        collectionCode
    ) {

        return (
            "/cgi-bin/koha/catalogue/search.pl?q="
            +
            encodeURIComponent(
                `ccode:"${collectionCode}"`
            )
        );
    }


    function getEditUrl(
        itemId
    ) {

        return (
            "/cgi-bin/koha/cataloguing/additem.pl"
            +
            "?op=edititem"
            +
            "&itemnumber="
            +
            encodeURIComponent(
                itemId
            )
        );
    }


    /* ============================================================
       RAPPORT STATISTIQUES 4537
       ============================================================ */

    function getStatsUrl(
        itemId
    ) {

        const params =
            new URLSearchParams();


        params.set(
            "id",
            CONFIG.reportId
        );


        function add(
            name,
            value
        ) {

            params.append(
                "param_name",
                name
            );


            params.append(
                "sql_params",
                value
            );
        }


        if(currentPmkConfig.reports.statisticsReportFormat==='standard'){
            add(currentPmkConfig.reports.statisticsParameterName,itemId);
            params.set('op','run');
            return '/cgi-bin/koha/reports/guided_reports.pl?'+params.toString();
        }

        add(
            "Site|branches:all",
            "%"
        );


        add(
            "Public|public:all",
            "%"
        );


        add(
            "Localisation|LOC:all",
            "%"
        );


        add(
            "Limiter par cote|YES_NO",
            "0"
        );


        add(
            "Cote de début (incluse)",
            ""
        );


        add(
            "Cote de fin (incluse)",
            ""
        );


        add(
            "Type de document|itemtypes:all",
            "%"
        );


        add(
            "Limiter par 610a|YES_NO",
            "0"
        );


        add(
            "610|610a:all",
            "%"
        );


        add(
            "Limiter par numero exemplaire|YES_NO",
            "1"
        );


        add(
            "Numéro exemplaire",
            itemId
        );


        add(
            "Limiter par numero de notice|YES_NO",
            "0"
        );


        add(
            "Numéri de notice",
            ""
        );


        params.set(
            "op",
            "run"
        );


        return (
            "/cgi-bin/koha/reports/guided_reports.pl?"
            +
            params.toString()
        );
    }


    /* ============================================================
       RECHERCHES PROGRESSIVES COTE
       ============================================================ */

    function buildCallnumberSearches(
        callnumber
    ) {

        const cleaned =
            String(
                callnumber || ""
            )
                .replace(
                    /\s+/g,
                    " "
                )
                .trim();


        if (!cleaned) {
            return [];
        }


        const values =
            [];


        function add(value) {

            value =
                String(
                    value || ""
                )
                    .replace(
                        /\s+/g,
                        " "
                    )
                    .trim();


            if (
                value
                &&
                !values.includes(
                    value
                )
            ) {

                values.push(
                    value
                );
            }
        }


        const parts =
            cleaned.split(" ");


        for (
            let length =
                parts.length;

            length >= 1;

            length--
        ) {

            add(
                parts
                    .slice(
                        0,
                        length
                    )
                    .join(" ")
            );
        }


        /*
         * Exemple :
         * 641.5944 DUR
         * → 641.5944 DUR
         * → 641.5944
         * → 641
         */

        const decimal =
            parts[0].match(
                /^(\d+)\.(\d+)$/
            );


        if (decimal) {

            add(
                decimal[1]
            );
        }


        return values;
    }


    function buildCallnumberHtml(
        callnumber
    ) {

        if (!callnumber) {
            return "";
        }


        const searches =
            pmkFeature("items.progressiveCallnumberSearch")
                ? buildCallnumberSearches(callnumber)
                : [String(callnumber).trim()].filter(Boolean);


        let menu =
            "";


        if (
            searches.length >
            1
        ) {

            const links =
                searches
                    .map(
                        (
                            value,
                            index
                        ) => `

<a
    class="kxri-callnumber-option"
    href="${getCallnumberUrl(value)}"
    title="Rechercher la cote ${escapeHtml(value)}"
>
    ${
        index === 0
            ? `<strong>${escapeHtml(value)}</strong>`
            : escapeHtml(value)
    }
</a>

                        `
                    )
                    .join("");


            menu = `

<details class="kxri-callnumber-menu">

    <summary
        title="Autres recherches à partir de cette cote"
    >
        ▾
    </summary>

    <div class="kxri-callnumber-options">

        <div class="kxri-callnumber-options-title">
            Rechercher par cote
        </div>

        ${links}

    </div>

</details>

            `;
        }


        return `

<span class="kxri-callnumber-wrap">

    <span class="kxri-callnumber">

        <a
            href="${getCallnumberUrl(callnumber)}"
            title="Rechercher exactement cette cote"
        >
            ${escapeHtml(callnumber)}
        </a>

    </span>

    ${menu}

</span>

        `;
    }


    /* ============================================================
       OUVERTURE DÉTAILS EXEMPLAIRE
       ============================================================ */

    function setCardExpanded(
        card,
        expanded
    ) {

        if (!card) {
            return;
        }


        card.classList.toggle(
            "is-expanded",
            expanded
        );


        const button =
            card.querySelector(
                ".kxri-toggle-details"
            );


        if (button) {

            button.textContent =
                expanded

                    ? "▴ " + pmkLabel("reduceFr", "reduceEn")

                    : "⋯ " + pmkLabel("detailsFr", "detailsEn");
        }
    }


    /* ============================================================
       COMPTEUR DE PRÊTS + ÉCHÉANCE VISIBLE
       ============================================================ */

    function getCheckoutCount(
        item
    ) {

        const value =
            item?.checkouts_count;

        if (
            value ===
                undefined
            ||
            value ===
                null
            ||
            value ===
                ""
        ) {
            return null;
        }


        const number =
            Number(
                value
            );


        return Number.isFinite(
            number
        )
            ? number
            : null;
    }


    function parseKohaCalendarDate(
        value
    ) {

        const text =
            String(
                value || ""
            )
                .trim();


        if (!text) {
            return null;
        }


        const match =
            text.match(
                /^(\d{4})-(\d{2})-(\d{2})/
            );


        if (match) {

            const date =
                new Date(
                    Number(match[1]),
                    Number(match[2]) - 1,
                    Number(match[3])
                );


            return Number.isNaN(
                date.getTime()
            )
                ? null
                : date;
        }


        const parsed =
            new Date(
                text
            );


        if (
            Number.isNaN(
                parsed.getTime()
            )
        ) {
            return null;
        }


        return new Date(
            parsed.getFullYear(),
            parsed.getMonth(),
            parsed.getDate()
        );
    }


    function getDueStatus(
        dueDate
    ) {

        const due =
            parseKohaCalendarDate(
                dueDate
            );


        if (!due) {
            return null;
        }


        const now =
            new Date();


        const today =
            new Date(
                now.getFullYear(),
                now.getMonth(),
                now.getDate()
            );


        const millisecondsPerDay =
            24
            *
            60
            *
            60
            *
            1000;


        const days =
            Math.round(
                (
                    due.getTime()
                    -
                    today.getTime()
                )
                /
                millisecondsPerDay
            );


        if (days < 0) {

            const lateDays =
                Math.abs(
                    days
                );


            return {
                key:
                    "overdue",

                days:
                    lateDays,

                label:
                    `En retard de ${lateDays} jour${lateDays > 1 ? "s" : ""}`
            };
        }


        if (days === 0) {

            return {
                key:
                    "today",

                days:
                    0,

                label:
                    "À rendre aujourd’hui"
            };
        }


        return {
            key:
                "future",

            days:
                days,

            label:
                `${days} jour${days > 1 ? "s" : ""} restant${days > 1 ? "s" : ""}`
        };
    }


    function buildQuickStatsHtml(
        item,
        dueDate
    ) {

        const parts =
            [];


        const checkoutCount =
            getCheckoutCount(
                item
            );


        if (
            checkoutCount !==
                null
        ) {

            parts.push(
                `
<span
    class="kxri-quickstat is-loans"
    title="Nombre total de prêts enregistré sur cet exemplaire"
>
    ↻
    ${checkoutCount}
    prêt${checkoutCount > 1 ? "s" : ""}
</span>
                `
            );
        }


        const notForLoanReason =
            getNotForLoanReason(
                item
            );


        if (notForLoanReason) {

            parts.push(
                `
<span
    class="kxri-quickstat is-not-for-loan"
    title="Cet exemplaire est exclu du prêt"
>
    ⛔
    Exclu du prêt :
    ${escapeHtml(notForLoanReason)}
</span>
                `
            );
        }


        const due =
            getDueStatus(
                dueDate
            );


        if (due) {

            const className =
                due.key ===
                    "overdue"

                    ? "is-overdue"

                    : due.key ===
                        "today"

                        ? "is-due-today"

                        : "is-due-future";


            parts.push(
                `
<span
    class="kxri-quickstat ${className}"
    title="Retour prévu le ${escapeHtml(formatDate(dueDate))}"
>
    ${due.key === "overdue" ? "⚠" : "⌛"}
    ${escapeHtml(due.label)}
</span>
                `
            );
        }


        if (!parts.length) {
            return "";
        }


        return `
<div class="kxri-quickstats">
    ${parts.join("")}
</div>
        `;
    }


    /* ============================================================
       EXCLUSION DU PRÊT + DURÉES RELATIVES
       ============================================================ */

    function getNotForLoanReason(
        item
    ) {

        const value =
            Number(
                item?.effective_not_for_loan_status
                ??
                item?.not_for_loan_status
                ??
                0
            );


        if (!value) {
            return "";
        }


        return (
            getString(
                item,
                "effective_not_for_loan_status"
            )
            ||
            getString(
                item,
                "not_for_loan_status"
            )
            ||
            "Exclu du prêt"
        );
    }


    function getCalendarParts(
        value
    ) {

        const date =
            parseKohaCalendarDate(
                value
            );


        if (!date) {
            return null;
        }


        const now =
            new Date();


        const today =
            new Date(
                now.getFullYear(),
                now.getMonth(),
                now.getDate()
            );


        return {
            date,
            today
        };
    }


    function relativeDateLabel(
        value
    ) {

        const parts =
            getCalendarParts(
                value
            );


        if (!parts) {
            return "";
        }


        const { date, today } =
            parts;


        const direction =
            date.getTime() <=
                today.getTime()

                ? "past"
                : "future";


        const start =
            direction === "past"
                ? date
                : today;


        const end =
            direction === "past"
                ? today
                : date;


        let years =
            end.getFullYear()
            -
            start.getFullYear();


        let months =
            end.getMonth()
            -
            start.getMonth();


        let days =
            end.getDate()
            -
            start.getDate();


        if (days < 0) {

            const previousMonthDays =
                new Date(
                    end.getFullYear(),
                    end.getMonth(),
                    0
                ).getDate();


            days +=
                previousMonthDays;


            months--;
        }


        if (months < 0) {
            years--;
            months += 12;
        }


        if (
            years === 0
            &&
            months === 0
            &&
            days === 0
        ) {
            return "aujourd’hui";
        }


        const values =
            [];


        if (years > 0) {

            values.push(
                `${years} an${years > 1 ? "s" : ""}`
            );


            if (months > 0) {
                values.push(
                    `${months} mois`
                );
            }
        }
        else if (months > 0) {

            values.push(
                `${months} mois`
            );


            if (
                days > 0
                &&
                months < 3
            ) {
                values.push(
                    `${days} jour${days > 1 ? "s" : ""}`
                );
            }
        }
        else {

            values.push(
                `${days} jour${days > 1 ? "s" : ""}`
            );
        }


        const duration =
            values.join(" et ");


        return direction === "past"
            ? `il y a ${duration}`
            : `dans ${duration}`;
    }


    function buildDateWithRelativeHtml(
        value,
        options = {}
    ) {

        const formatted =
            formatDate(
                value
            );


        if (!formatted) {
            return "—";
        }


        let relative =
            relativeDateLabel(
                value
            );


        let className =
            "kxri-date-age";


        if (
            options.due === true
        ) {

            const due =
                getDueStatus(
                    value
                );


            if (due) {
                relative =
                    due.label;


                if (
                    due.key ===
                    "overdue"
                ) {
                    className +=
                        " is-overdue";
                }
                else if (
                    due.key ===
                    "future"
                ) {
                    className +=
                        " is-future";
                }
            }
        }


        return (
            `${escapeHtml(formatted)}`
            +
            (
                relative
                    ? ` <span class="${className}">(${escapeHtml(relative)})</span>`
                    : ""
            )
        );
    }


    /* ============================================================
       ACCÈS DIRECT AUX MOUVEMENTS DANS LA COLONNE NOTICE
       ============================================================ */

    function waitForElement(
        root,
        finder,
        timeout = 12000
    ) {

        return new Promise(
            resolve => {

                const immediate =
                    finder();

                if (immediate) {
                    resolve(
                        immediate
                    );
                    return;
                }


                let finished =
                    false;


                const finish =
                    value => {

                        if (finished) {
                            return;
                        }


                        finished =
                            true;


                        observer.disconnect();

                        clearTimeout(
                            timer
                        );


                        resolve(
                            value
                        );
                    };


                const observer =
                    new MutationObserver(
                        () => {

                            const found =
                                finder();


                            if (found) {
                                finish(
                                    found
                                );
                            }
                        }
                    );


                observer.observe(
                    root,
                    {
                        childList:
                            true,

                        subtree:
                            true
                    }
                );


                const timer =
                    setTimeout(
                        () => finish(
                            null
                        ),
                        timeout
                    );
            }
        );
    }


    function findMovementItemDetailButton(
        panel,
        itemId
    ) {

        if (!panel) {
            return null;
        }


        return (
            Array
                .from(
                    panel.querySelectorAll(
                        "[data-kxmv-open-item]"
                    )
                )
                .find(
                    button =>
                        String(
                            button.dataset
                                .kxmvOpenItem
                            ||
                            ""
                        )
                        ===
                        String(
                            itemId
                        )
                )
            ||
            null
        );
    }


    function findMovementItemDetailHolder(
        panel,
        itemId
    ) {

        if (!panel) {
            return null;
        }


        return (
            Array
                .from(
                    panel.querySelectorAll(
                        "[data-kxmv-inline-detail]"
                    )
                )
                .find(
                    holder =>
                        String(
                            holder.dataset
                                .kxmvInlineDetail
                            ||
                            ""
                        )
                        ===
                        String(
                            itemId
                        )
                )
            ||
            null
        );
    }


    async function openItemInCentralMovements(
        card
    ) {

        if (
            !card
            ||
            !isKohaSearchResultsPage()
        ) {
            return;
        }


        const itemId =
            String(
                card.dataset.itemId
                ||
                ""
            );


        if (!itemId) {
            return;
        }


        const resultRow =
            card.closest(
                'tr[id^="row"]'
            );


        if (!resultRow) {
            return;
        }


        /*
         * Le module Mouvements est un script indépendant.
         * On attend son bouton si son initialisation DOM n'est
         * pas encore terminée. Aucun appel Koha n'est fait ici.
         */

        let noticeButton =
            resultRow.querySelector(
                ".kxmv-notice-btn"
            );


        if (!noticeButton) {

            noticeButton =
                await waitForElement(
                    resultRow,
                    () =>
                        resultRow.querySelector(
                            ".kxmv-notice-btn"
                        ),
                    5000
                );
        }


        if (!noticeButton) {

            (function(){})(
                "[KXRI] Module Mouvements introuvable pour cette notice."
            );

            return;
        }


        const targetCell =
            resultRow.querySelector(
                ".kx-notice-cell"
            )
            ||
            resultRow.cells?.[2]
            ||
            resultRow;


        let movementPanel =
            targetCell.querySelector(
                ":scope > .kxmv-panel"
            );


        /*
         * Équivalent au premier clic :
         * "Mouvements" au niveau du titre.
         *
         * Si le panneau existe déjà et est ouvert,
         * surtout ne pas recliquer : cela le refermerait.
         */

        if (
            !movementPanel
            ||
            movementPanel.hidden
        ) {

            noticeButton.click();
        }


        if (!movementPanel) {

            movementPanel =
                await waitForElement(
                    targetCell,
                    () =>
                        targetCell.querySelector(
                            ":scope > .kxmv-panel"
                        ),
                    12000
                );
        }


        if (!movementPanel) {

            (function(){})(
                "[KXRI] Panneau central Mouvements introuvable."
            );

            return;
        }


        /*
         * Le panneau apparaît avant la fin de son chargement.
         * On attend donc que le bouton "Voir le détail" de
         * l'exemplaire ciblé soit réellement rendu.
         */

        let itemDetailButton =
            findMovementItemDetailButton(
                movementPanel,
                itemId
            );


        if (!itemDetailButton) {

            itemDetailButton =
                await waitForElement(
                    movementPanel,
                    () =>
                        findMovementItemDetailButton(
                            movementPanel,
                            itemId
                        ),
                    12000
                );
        }


        if (!itemDetailButton) {

            (function(){})(
                `[KXRI] Exemplaire ${itemId} introuvable dans le panneau Mouvements.`
            );

            return;
        }


        const holder =
            findMovementItemDetailHolder(
                movementPanel,
                itemId
            );


        /*
         * Équivalent au second clic :
         * "Voir le détail" pour CE seul exemplaire.
         *
         * Si le détail est déjà ouvert, on le laisse ouvert.
         */

        if (
            !holder
            ||
            holder.hidden
        ) {

            itemDetailButton.click();
        }
    }


    /* ============================================================
       RENDU EXEMPLAIRE
       ============================================================ */

    function renderItem(
        item,
        iconMap
    ) {

        const status =
            getStatus(item);


        const itemId =
            item.item_id
            ||
            "";


        const barcode =
            item.external_id
            ||
            "";


        const holding =
            getHoldingLibrary(
                item
            );


        const home =
            getHomeLibrary(
                item
            );


        const location =
            getLocation(
                item
            );


        const callnumber =
            item.callnumber
            ||
            "";


        const itemTypeLabel =
            getItemTypeLabel(
                item
            );


        const collectionCode =
            getCollectionCode(
                item
            );


        const collectionLabel =
            getCollectionLabel(
                item
            );


        const dueDate =
            item.checkout?.due_date
            ||
            "";


        const quickStatsHtml =
            pmkFeature("items.quickStatsEnabled")
                ? buildQuickStatsHtml(item, dueDate)
                : "";


        const local =
            loggedBranchName
            &&
            normalize(holding)
            ===
            loggedBranchName;


        /* ========================================================
           ICÔNE TYPE DOCUMENT
           ======================================================== */

        let iconSrc =
            pmkFeature("items.nativeItemTypeIcons")
                ? iconMap.get(
                normalize(
                    itemTypeLabel
                )
            )
            ||
            ""
                : "";


        /*
         * Une seule icône native trouvée sur la notice :
         * elle peut servir de fallback.
         */

        if (
            pmkFeature("items.nativeItemTypeIcons")
            &&
            !iconSrc
            &&
            iconMap.size ===
            1
        ) {

            iconSrc =
                Array
                    .from(
                        iconMap.values()
                    )[0];
        }


        const iconHtml =
            iconSrc

                ? `
<img
    class="kxri-itemtype-icon"
    src="${escapeHtml(iconSrc)}"
    alt=""
    title="${escapeHtml(itemTypeLabel)}"
>
                  `

                : "";


        /* ========================================================
           LOCALISATION
           ======================================================== */

        const locationParts =
            [];


        if (location) {

            locationParts.push(
                `
<span class="kxri-location">
    ${escapeHtml(location)}
</span>
                `
            );
        }


        if (callnumber) {

            locationParts.push(
                buildCallnumberHtml(
                    callnumber
                )
            );
        }


        /* ========================================================
           PROPRIÉTAIRE
           ======================================================== */

        const ownerHtml =
            pmkFeature("items.ownerVisible")
            &&
            home
            &&
            normalize(home) !==
            normalize(holding)

                ? `
<div class="kxri-secondary">
    Propriétaire :
    <strong>
        ${escapeHtml(home)}
    </strong>
</div>
                  `

                : "";


        /* ========================================================
           COLLECTION
           ======================================================== */

        const collectionHtml =
            collectionCode

                ? `
<div class="kxri-collection">

    Code collection :

    ${
        pmkFeature("items.collectionLinkEnabled")
            ? `<a href="${getCollectionUrl(collectionCode)}">${escapeHtml(collectionLabel)}</a>`
            : `<strong>${escapeHtml(collectionLabel)}</strong>`
    }

</div>
                  `

                : "";


        /* ========================================================
           CARTE
           ======================================================== */

        const card =
            document.createElement(
                "div"
            );


        card.className =
            `kxri-item is-${status.key}`
            +
            (
                local
                    ? " is-local"
                    : ""
            );


        card.dataset.itemId =
            itemId;


        card.dataset.barcode =
            barcode;


        card.innerHTML = `

<div class="kxri-main">

    <div class="kxri-topline">

        <div class="kxri-library-wrap">

            ${iconHtml}

            <div class="kxri-library-text">

                <div class="kxri-library">

                    ${escapeHtml(
                        holding
                        ||
                        pmkLabel("unknownSiteFr", "unknownSiteEn")
                    )}

                    ${
                        local
                            ? `
<span class="kxri-local-badge">
    ${escapeHtml(pmkLabel("mySiteFr", "mySiteEn"))}
</span>
                              `
                            : ""
                    }

                </div>

            </div>

        </div>


        <span
            class="kxri-status is-${status.key}"
        >
            ${escapeHtml(status.label)}
        </span>

    </div>


    ${
        locationParts.length

            ? `
<div class="kxri-location-line">
    ${locationParts.join("")}
</div>
              `

            : ""
    }


    ${collectionHtml}


    ${
        pmkFeature("items.barcodeVisible")
            ? `
    <div class="kxri-barcode-line">

        ${
            barcode

                ? `
<span class="kxri-barcode">
    ${escapeHtml(barcode)}
</span>

${
    pmkFeature("items.barcodeCopyEnabled")
        ? `<button type="button" class="kxri-copy" data-copy="${escapeHtml(barcode)}">${escapeHtml(pmkLabel("copyFr", "copyEn"))}</button>`
        : ""
}
                  `

                : `
<span class="kxri-barcode">
    Exemplaire #${escapeHtml(itemId)}
</span>
                  `
        }

    </div>
              `
            : ""
    }


    ${quickStatsHtml}


    ${ownerHtml}


    ${
        pmkFeature("items.itemTypeVisible") && itemTypeLabel

            ? `
<div class="kxri-secondary">
    ${escapeHtml(itemTypeLabel)}
</div>
              `

            : ""
    }


    ${
        pmkFeature("items.dueDateVisible") && dueDate

            ? `
<div class="kxri-due">
    Retour prévu :
    ${escapeHtml(
        formatDate(
            dueDate
        )
    )}
</div>
              `

            : ""
    }

</div>


<div class="kxri-actions">

    ${pmkFeature("items.actions.edit") ? `
    <a
        class="kxri-action"
        href="${getEditUrl(itemId)}"
        target="_blank"
        rel="noopener"
        title="Modifier cet exemplaire"
    >
        ✎ Modifier l’exemplaire
    </a>` : ""}


    ${pmkFeature("items.actions.statistics") && CONFIG.reportId > 0 ? `
    <a
        class="kxri-action"
        href="${getStatsUrl(itemId)}"
        target="_blank"
        rel="noopener"
        title="Consulter les statistiques de cet exemplaire"
    >
        ▥ Statistiques de prêt
    </a>` : ""}


    ${pmkFeature("items.actions.movements") ? `
    <button
        type="button"
        class="kxri-action kxri-open-central-movements"
        title="Ouvrir directement cet exemplaire dans les mouvements de la notice"
    >
        <i class="fa-solid fa-route"></i>
        Mouvements de l’exemplaire
    </button>` : ""}


    ${pmkFeature("items.detailsEnabled") ? `
    <button
        type="button"
        class="kxri-action kxri-toggle-details"
    >
        ⋯ ${escapeHtml(pmkLabel("detailsFr", "detailsEn"))}
    </button>` : ""}

</div>


${pmkFeature("items.detailsEnabled") ? `
<div class="kxri-details">

    <div class="kxri-detail-grid">

        <div class="kxri-detail-label">
            N° exemplaire
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(itemId)}
        </div>


        <div class="kxri-detail-label">
            Site propriétaire
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(home || "—")}
        </div>


        <div class="kxri-detail-label">
            Site actuel
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(holding || "—")}
        </div>


        <div class="kxri-detail-label">
            Localisation
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(location || "—")}
        </div>


        <div class="kxri-detail-label">
            Cote
        </div>

        <div class="kxri-detail-value">

            ${
                callnumber

                    ? `
<a href="${getCallnumberUrl(callnumber)}">
    ${escapeHtml(callnumber)}
</a>
                      `

                    : "—"
            }

        </div>


        <div class="kxri-detail-label">
            Code-barres
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(barcode || "—")}
        </div>


        <div class="kxri-detail-label">
            Type
        </div>

        <div class="kxri-detail-value">
            ${escapeHtml(itemTypeLabel || "—")}
        </div>


        <div class="kxri-detail-label">
            Code collection
        </div>

        <div class="kxri-detail-value">

            ${
                collectionCode

                    ? (
                        pmkFeature("items.collectionLinkEnabled")
                            ? `<a href="${getCollectionUrl(collectionCode)}">${escapeHtml(collectionLabel)}</a>`
                            : escapeHtml(collectionLabel)
                      )

                    : "—"
            }

        </div>


        ${
            getNotForLoanReason(
                item
            )

                ? `
<div class="kxri-detail-label">
    Exclusion du prêt
</div>

<div class="kxri-detail-value">
    <strong>
        ${escapeHtml(
            getNotForLoanReason(
                item
            )
        )}
    </strong>
</div>
                  `

                : ""
        }


        <div class="kxri-detail-label">
            Création
        </div>

        <div class="kxri-detail-value">
            ${
                buildDateWithRelativeHtml(
                    item.acquisition_date
                )
            }
        </div>


        <div class="kxri-detail-label">
            Vu dernièrement
        </div>

        <div class="kxri-detail-value">
            ${
                buildDateWithRelativeHtml(
                    item.last_seen_date
                )
            }
        </div>


        <div class="kxri-detail-label">
            Dernier emprunt
        </div>

        <div class="kxri-detail-value">
            ${
                buildDateWithRelativeHtml(
                    item.last_checkout_date
                )
            }
        </div>


        ${
            dueDate

                ? `
<div class="kxri-detail-label">
    Retour prévu
</div>

<div class="kxri-detail-value">
    ${buildDateWithRelativeHtml(
        dueDate,
        { due: true }
    )}
</div>
                  `

                : ""
        }


        <div class="kxri-detail-label">
            Nombre de prêts
        </div>

        <div class="kxri-detail-value">
            ${
                item.checkouts_count !==
                    undefined
                &&
                item.checkouts_count !==
                    null

                    ? escapeHtml(
                        item.checkouts_count
                    )

                    : "—"
            }
        </div>


        ${
            item.inventory_number

                ? `
<div class="kxri-detail-label">
    Inventaire
</div>

<div class="kxri-detail-value">
    ${escapeHtml(item.inventory_number)}
</div>
                  `

                : ""
        }


        ${
            item.internal_notes

                ? `
<div class="kxri-detail-label">
    Note interne
</div>

<div class="kxri-detail-value">
    ${escapeHtml(item.internal_notes)}
</div>
                  `

                : ""
        }

    </div>

</div>
` : ""}

        `;


        if (
            pmkFeature("items.detailsEnabled")
            &&
            allExemplairesExpanded
        ) {

            setCardExpanded(
                card,
                true
            );
        }


        return card;
    }


    /* ============================================================
       RÉSUMÉ EXEMPLAIRES
       ============================================================ */

    function buildSummary(
        items
    ) {

        const counts = {
            available:
                0,

            loan:
                0,

            unavailable:
                0
        };


        items.forEach(
            item => {

                const key =
                    getStatus(
                        item
                    ).key;


                if (
                    key ===
                    "available"
                ) {

                    counts.available++;

                }
                else if (
                    key ===
                    "loan"
                ) {

                    counts.loan++;

                }
                else {

                    counts.unavailable++;
                }
            }
        );


        const summary =
            document.createElement(
                "div"
            );


        summary.className =
            "kxri-summary";


        summary.innerHTML = `

<span class="kxri-summary-total">
    ${items.length}
    exemplaire${items.length > 1 ? "s" : ""}
</span>


${
    counts.available

        ? `
<span class="kxri-summary-badge is-available">
    ${counts.available}
    disponible${counts.available > 1 ? "s" : ""}
</span>
          `

        : ""
}


${
    counts.loan

        ? `
<span class="kxri-summary-badge is-loan">
    ${counts.loan}
    en prêt
</span>
          `

        : ""
}


${
    counts.unavailable

        ? `
<span class="kxri-summary-badge is-unavailable">
    ${counts.unavailable}
    indisponible${counts.unavailable > 1 ? "s" : ""}
</span>
          `

        : ""
}

        `;


        return summary;
    }


    /* ============================================================
       TRI EXEMPLAIRES
       ============================================================ */

    function sortItems(
        items
    ) {

        const priority = {
            available:
                0,

            hold:
                1,

            transfer:
                2,

            loan:
                3,

            unavailable:
                4
        };


        return [
            ...items
        ].sort(
            (
                a,
                b
            ) => {

                const holdingA =
                    normalize(
                        getHoldingLibrary(
                            a
                        )
                    );


                const holdingB =
                    normalize(
                        getHoldingLibrary(
                            b
                        )
                    );


                const localA =
                    loggedBranchName
                    &&
                    holdingA ===
                    loggedBranchName;


                const localB =
                    loggedBranchName
                    &&
                    holdingB ===
                    loggedBranchName;


                if (
                    pmkFeature("items.prioritizeCurrentSite")
                    &&
                    localA !==
                    localB
                ) {

                    return localA
                        ? -1
                        : 1;
                }


                const statusA =
                    priority[
                        getStatus(
                            a
                        ).key
                    ]
                    ??
                    9;


                const statusB =
                    priority[
                        getStatus(
                            b
                        ).key
                    ]
                    ??
                    9;


                if (
                    pmkFeature("items.prioritizeStatus")
                    &&
                    statusA !==
                    statusB
                ) {

                    return (
                        statusA -
                        statusB
                    );
                }


                return holdingA.localeCompare(
                    holdingB,
                    "fr",
                    {
                        sensitivity:
                            "base"
                    }
                );
            }
        );
    }


    /* ============================================================
       TRAITEMENT EXEMPLAIRES
       ============================================================ */

    async function processExemplairesRow(
        row
    ) {

        if (
            !isKohaSearchResultsPage()
            ||
            row.dataset.kxriDone ===
                "1"
            ||
            row.dataset.kxriDone ===
                "loading"
        ) {
            return;
        }


        const biblioNumber =
            getBiblioNumber(
                row
            );


        if (!biblioNumber) {
            return;
        }


        const nativeAvailability =
            row.querySelector(
                ".availability"
            );


        if (!nativeAvailability) {
            return;
        }


        const cell =
            nativeAvailability.closest(
                "td"
            );


        if (!cell) {
            return;
        }


        row.dataset.kxriDone =
            "loading";


        const iconMap =
            buildNativeIconMap(
                row
            );


        cell.classList.add(
            "kxri-cell"
        );


        const panel =
            document.createElement(
                "div"
            );


        panel.className =
            "kxri-panel";


        panel.innerHTML = `

<div class="kxri-loading">
    Chargement des exemplaires…
</div>

        `;


        cell.insertBefore(
            panel,
            nativeAvailability
        );


        try {

            const loaded=await fetchAllItems(biblioNumber);
            const items=loaded.items;


            /*
             * Vérification post-API.
             */

            if (
                !isKohaSearchResultsPage()
            ) {

                panel.remove();

                return;
            }


            if (
                !items.length
            ) {

                throw new Error(
                    "Aucun exemplaire retourné."
                );
            }


            const sorted =
                sortItems(
                    items
                );


            panel.replaceChildren();


            if (pmkFeature("items.summaryEnabled")) {
                panel.appendChild(
                    buildSummary(
                        sorted
                    )
                );
            }


            const list =
                document.createElement(
                    "div"
                );


            list.className =
                "kxri-items";


            sorted.forEach(
                item => {

                    list.appendChild(
                        renderItem(
                            item,
                            iconMap
                        )
                    );
                }
            );


            panel.appendChild(
                list
            );


            /*
             * Le natif Koha n'est masqué
             * qu'après succès complet.
             */

            nativeAvailability.classList.toggle('kxri-native-hidden',loaded.complete);
            if(!loaded.complete){
                row.dataset.kxriPartial='1';
                appendItemsRetry(panel,row,'Affichage partiel : '+items.length+(loaded.total?' / '+loaded.total:'')+' exemplaire(s) chargé(s). '+loaded.reason+' Les disponibilités Koha restent affichées.');
            }


            row.dataset.kxriDone =
                "1";


            syncGlobalToggleButton();

        }
        catch (error) {

            (function(){})(
                `[KXRI] Notice ${biblioNumber}`,
                error
            );


            panel.replaceChildren();
            nativeAvailability.classList.remove('kxri-native-hidden');
            appendItemsRetry(panel,row,'Exemplaires non chargés : '+error.message+' Les disponibilités Koha restent affichées.');
            row.dataset.kxriDone='1';
            row.dataset.kxriPartial='1';
        }
    }


    /* ============================================================
       BOUTON GLOBAL EXEMPLAIRES
       ============================================================ */

    function syncGlobalToggleButton() {

        if (!pmkFeature("items.globalToggleEnabled") || !pmkFeature("items.detailsEnabled")) {
            return;
        }

        if (
            !isKohaSearchResultsPage()
        ) {
            return;
        }


        const button =
            document.getElementById(
                "toggle-all-exemplaires"
            );


        if (!button) {
            return;
        }


        button.classList.toggle(
            "kx-all-open",
            allExemplairesExpanded
        );


        button.setAttribute(
            "aria-pressed",
            String(
                allExemplairesExpanded
            )
        );


        button.innerHTML =
            allExemplairesExpanded

                ? `
<i class="fa fa-list-alt"></i>
${escapeHtml(pmkLabel("hideAllFr", "hideAllEn"))}
                  `

                : `
<i class="fa fa-list-alt"></i>
${escapeHtml(pmkLabel("showAllFr", "showAllEn"))}
                  `;
    }


    function toggleAllExemplaires() {

        if (
            !isKohaSearchResultsPage()
        ) {
            return;
        }


        const cards =
            Array.from(
                document.querySelectorAll(
                    "#bookbag_form .kxri-item"
                )
            );


        if (
            !cards.length
        ) {
            return;
        }


        const allCurrentlyExpanded =
            cards.every(
                card =>
                    card.classList.contains(
                        "is-expanded"
                    )
            );


        allExemplairesExpanded =
            !allCurrentlyExpanded;


        cards.forEach(
            card =>
                setCardExpanded(
                    card,
                    allExemplairesExpanded
                )
        );


        syncGlobalToggleButton();
    }


    /* ============================================================
       ÉVÉNEMENTS
       ============================================================ */

    function installEvents(
        form
    ) {

        if (
            !form
            ||
            form.dataset.kxV8Events ===
                "1"
        ) {
            return;
        }


        form.dataset.kxV8Events =
            "1";


        /* Résumés / mots-clés XSLT : délégation, y compris après un ajout dynamique.
         * La section suit le <p> contenant le bouton, et non le <span>.
         * Capture pour éviter une double bascule avec l'ancien module 112.
         */
        form.addEventListener("click", event => {
            if (!isKohaSearchResultsPage() || !pmkFeature("enabled")) return;
            const origin = event.target instanceof Element ? event.target : event.target.parentElement;
            const button = origin && origin.closest(".bouton");
            if (!button || !form.contains(button)) return;

            let section = button.nextElementSibling;
            if (!section || !section.classList.contains("sectionz")) {
                const paragraph = button.closest("p");
                section = paragraph && paragraph.nextElementSibling;
            }
            if (!section || !section.classList.contains("sectionz") || !form.contains(section)) return;

            event.preventDefault();
            event.stopImmediatePropagation();
            const opening = section.hidden || getComputedStyle(section).display === "none";
            section.hidden = !opening;
            section.style.setProperty("display", opening ? "block" : "none", "important");
            button.setAttribute("aria-expanded", String(opening));
        }, true);


        /* ========================================================
           AFFICHER PLUS MOBILE

           Capture volontaire :
           notre script prend la main avant l'ancien
           listener sur mobile uniquement.
           ======================================================== */

        form.addEventListener(
            "click",

            event => {

                if (
                    !isKohaSearchResultsPage()
                    ||
                    !isMobile()
                    ||
                    !pmkFeature("notice.mobileCollapseEnabled")
                ) {
                    return;
                }


                const button =
                    event.target.closest(
                        ".btn-show-more"
                    );


                if (
                    !button
                    ||
                    !form.contains(
                        button
                    )
                ) {
                    return;
                }


                event.preventDefault();

                event.stopPropagation();

                event.stopImmediatePropagation();


                toggleMobileNotice(
                    button
                );
            },

            true
        );


        /* ========================================================
           AUTRES INTERACTIONS
           ======================================================== */

        form.addEventListener(
            "click",

            async event => {

                if (
                    !isKohaSearchResultsPage()
                ) {
                    return;
                }


                /* Copier code-barres */

                const copy =
                    pmkFeature("items.barcodeCopyEnabled")
                        ? event.target.closest(
                        ".kxri-copy"
                    )
                        : null;


                if (
                    copy
                    &&
                    form.contains(
                        copy
                    )
                ) {

                    event.preventDefault();


                    const value =
                        copy.dataset.copy
                        ||
                        "";


                    try {

                        await navigator
                            .clipboard
                            .writeText(
                                value
                            );


                        const original =
                            copy.textContent;


                        copy.textContent =
                            pmkLabel("copiedFr", "copiedEn");


                        setTimeout(
                            () => {

                                copy.textContent =
                                    original;

                            },
                            1200
                        );

                    }
                    catch (error) {

                        (function(){})(
                            "[KXRI] Copie impossible",
                            error
                        );
                    }


                    return;
                }


                /* Accès direct aux mouvements dans la colonne notice */

                const centralMovements =
                    pmkFeature("items.actions.movements")
                        ? event.target.closest(
                        ".kxri-open-central-movements"
                    )
                        : null;


                if (
                    centralMovements
                    &&
                    form.contains(
                        centralMovements
                    )
                ) {

                    event.preventDefault();

                    event.stopPropagation();


                    const card =
                        centralMovements.closest(
                            ".kxri-item"
                        );


                    if (!card) {
                        return;
                    }


                    centralMovements.disabled =
                        true;


                    try {

                        await openItemInCentralMovements(
                            card
                        );

                    }
                    catch (error) {

                        (function(){})(
                            "[KXRI] Ouverture directe Mouvements impossible",
                            error
                        );

                    }
                    finally {

                        centralMovements.disabled =
                            false;
                    }


                    return;
                }


                /* Détails exemplaire */

                const toggle =
                    pmkFeature("items.detailsEnabled")
                        ? event.target.closest(
                        ".kxri-toggle-details"
                    )
                        : null;


                if (
                    toggle
                    &&
                    form.contains(
                        toggle
                    )
                ) {

                    event.preventDefault();


                    const card =
                        toggle.closest(
                            ".kxri-item"
                        );


                    if (!card) {
                        return;
                    }


                    const expanded =
                        !card.classList.contains(
                            "is-expanded"
                        );


                    setCardExpanded(
                        card,
                        expanded
                    );


                    const cards =
                        Array.from(
                            form.querySelectorAll(
                                ".kxri-item"
                            )
                        );


                    allExemplairesExpanded =
                        cards.length > 0
                        &&
                        cards.every(
                            current =>
                                current
                                    .classList
                                    .contains(
                                        "is-expanded"
                                    )
                        );


                    syncGlobalToggleButton();


                    return;
                }


                /* Fermer menus cote */

                form
                    .querySelectorAll(
                        ".kxri-callnumber-menu[open]"
                    )
                    .forEach(
                        menu => {

                            if (
                                !menu.contains(
                                    event.target
                                )
                            ) {

                                menu.removeAttribute(
                                    "open"
                                );
                            }
                        }
                    );
            }
        );


        /* ========================================================
           BOUTON GLOBAL
           ======================================================== */

        const globalButton =
            document.getElementById(
                "toggle-all-exemplaires"
            );


        if (
            pmkFeature("items.globalToggleEnabled")
            &&
            pmkFeature("items.detailsEnabled")
            &&
            globalButton
            &&
            globalButton.dataset
                .kxV8Listener !==
                "1"
        ) {

            globalButton.dataset
                .kxV8Listener =
                "1";


            globalButton.addEventListener(
                "click",

                event => {

                    if (
                        !isKohaSearchResultsPage()
                    ) {
                        return;
                    }


                    event.preventDefault();

                    event.stopImmediatePropagation();


                    toggleAllExemplaires();
                },

                true
            );
        }
    }


    /* ============================================================
       POOL API
       ============================================================ */

    async function runPool(
        rows
    ) {

        let index =
            0;


        async function worker() {

            while (
                index <
                rows.length
            ) {

                if (
                    !isKohaSearchResultsPage()
                ) {
                    return;
                }


                const current =
                    index++;


                await processExemplairesRow(
                    rows[current]
                );
            }
        }


        const workers =
            Array.from(
                {
                    length:
                        Math.min(
                            CONFIG.concurrentRequests,
                            rows.length
                        )
                },

                worker
            );


        await Promise.all(
            workers
        );
    }


    /* ============================================================
       OBSERVATEUR GLOBAL
       ============================================================ */

    function installGlobalObserver(
        form
    ) {

        if (
            !form
            ||
            form.dataset
                .kxV8Observer ===
                "1"
        ) {
            return;
        }


        form.dataset
            .kxV8Observer =
            "1";


        let scheduled =
            false;


        const observer =
            new MutationObserver(
                () => {

                    if (
                        !isKohaSearchResultsPage()
                    ) {

                        observer.disconnect();

                        return;
                    }


                    if (scheduled) {
                        return;
                    }


                    scheduled =
                        true;


                    requestAnimationFrame(
                        () => {

                            scheduled =
                                false;


                            if (
                                !isKohaSearchResultsPage()
                            ) {
                                return;
                            }


                            const rows =
                                Array.from(
                                    form.querySelectorAll(
                                        'tbody tr[id^="row"]'
                                    )
                                );


                            rows.forEach(
                                row => {

                                    if (
                                        row.dataset
                                            .kxNoticeDone !==
                                            "1"
                                    ) {

                                        enhanceNoticeRow(
                                            row
                                        );
                                    }


                                    const cells =
                                        Array
                                            .from(
                                                row.children
                                            )
                                            .filter(
                                                element =>
                                                    element.tagName ===
                                                    "TD"
                                            );


                                    if (
                                        cells.length >=
                                        3
                                    ) {

                                        processBibliographicCell(
                                            cells[2]
                                        );
                                    }
                                }
                            );
                        }
                    );
                }
            );


        observer.observe(
            form,
            {
                childList:
                    true,

                subtree:
                    true
            }
        );
    }


    /* ============================================================
       INIT
       ============================================================ */

    function init() {

        /*
         * Deuxième verrou.
         */

        if (!currentPmkConfig.enabled) {
            mountPmkContextButton();
            return;
        }

        if (
            !isKohaSearchResultsPage()
        ) {
            return;
        }


        const form =
            document.getElementById(
                "bookbag_form"
            );


        if (!form) {
            return;
        }


        const rows =
            Array.from(
                form.querySelectorAll(
                    'tbody tr[id^="row"]'
                )
            );


        if (
            !rows.length
        ) {
            return;
        }


        /*
         * Marqueur CSS ajouté uniquement
         * sur la vraie page de résultats.
         */

        document.body.classList.add(
            "kx-search-results-page"
        );


        loggedBranchName =
            getLoggedBranchName();


        installStyles();
        applyPmkAppearance();


        /* Notices */

        if (pmkFeature("notice.layoutEnabled")) {
            rows.forEach(
                enhanceNoticeRow
            );
        }


        /* Interactions */

        installEvents(
            form
        );


        /* Injections tardives */

        installGlobalObserver(
            form
        );


        /* Mobile */

        const onMediaChange =
            () => {

                if (
                    !isKohaSearchResultsPage()
                ) {
                    return;
                }


                if (pmkFeature("notice.layoutEnabled") && pmkFeature("notice.mobileCollapseEnabled")) {
                    syncAllMobileNoticeControls(
                        form
                    );
                }
            };


        if (
            typeof mobileMedia.addEventListener ===
            "function"
        ) {

            mobileMedia.addEventListener(
                "change",
                onMediaChange
            );

        }
        else if (
            typeof mobileMedia.addListener ===
            "function"
        ) {

            /*
             * Compatibilité navigateurs plus anciens.
             */

            mobileMedia.addListener(
                onMediaChange
            );
        }


        if (pmkFeature("notice.layoutEnabled") && pmkFeature("notice.mobileCollapseEnabled")) {
            syncAllMobileNoticeControls(
                form
            );
        }


        /* Exemplaires */

        if (pmkFeature("items.cardsEnabled")) {
            runPool(
                rows
            );
        }


        runtimeInitialized = true;
        syncGlobalToggleButton();
        mountPmkContextButton();
    }


    /* ============================================================
       DÉMARRAGE
       ============================================================ */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",

            () => {

                if (
                    window.location.pathname ===
                    SEARCH_PATH
                ) {

                    init();
                }
            },

            {
                once:
                    true
            }
        );

    }
    else {

        init();
    }

})();


/*******************************************************************************
 * PATCH AUTONOME — HISTORIQUE DE PRÊT DANS LES CARTES EXEMPLAIRES
 *
 * IMPORTANT : volontairement placé HORS du gros IIFE précédent.
 * Il ne dépend ni de renderItem(), ni du verrou __KX_SEARCH_RESULTS_V8__,
 * ni du module Mouvements. Il travaille uniquement sur le DOM effectivement
 * rendu dans la page.
 *******************************************************************************/
(() => {
    "use strict";

    const SEARCH_PATH = "/cgi-bin/koha/catalogue/search.pl";

    if (window.location.pathname !== SEARCH_PATH) {
        return;
    }

    if (window.__KX_LOAN_HISTORY_STANDALONE_V1__) {
        return;
    }
    window.__KX_LOAN_HISTORY_STANDALONE_V1__ = true;

    function loanHistoryEnabled() {
        try {
            return !window.PMK129SearchResults
                || window.PMK129SearchResults.featureEnabled("items.actions.loanHistory") !== false;
        }
        catch (_) {
            return true;
        }
    }

    function getBiblioNumber(card) {
        const row = card.closest('tr[id^="row"]');

        if (row) {
            const match = String(row.id || "").match(/^row(\d+)$/);
            if (match) {
                return match[1];
            }

            const candidate = row.querySelector(
                'a[href*="biblionumber="], a[href*="/catalogue/detail.pl?"]'
            );

            if (candidate?.href) {
                try {
                    const url = new URL(candidate.href, window.location.origin);
                    const value = url.searchParams.get("biblionumber");
                    if (value) {
                        return value;
                    }
                }
                catch (_) {}
            }
        }

        return "";
    }

    function getBarcode(card) {
        const fromDataset = String(card.dataset.barcode || "").trim();
        if (fromDataset) {
            return fromDataset;
        }

        const node = card.querySelector(".kxri-barcode");
        if (!node) {
            return "";
        }

        const value = String(node.textContent || "").trim();

        // Ne pas confondre le fallback « Exemplaire #123 » avec un code-barres.
        if (/^Exemplaire\s*#/i.test(value)) {
            return "";
        }

        return value;
    }

    function getItemNumber(card) {
        const fromDataset = String(card.dataset.itemId || "").trim();
        if (fromDataset) {
            return fromDataset;
        }

        const editLink = card.querySelector(
            '.kxri-actions a[href*="itemnumber="]'
        );

        if (editLink?.href) {
            try {
                return new URL(
                    editLink.href,
                    window.location.origin
                ).searchParams.get("itemnumber") || "";
            }
            catch (_) {}
        }

        return "";
    }

    function openLoanHistory(card) {
        const biblioNumber = getBiblioNumber(card);
        const barcode = getBarcode(card);
        const itemNumber = getItemNumber(card);

        if (!biblioNumber || !barcode) {
            (function(){})("[KX historique prêt] Données manquantes", {
                biblioNumber,
                barcode,
                itemNumber,
                card
            });

            window.alert(
                "Impossible d’ouvrir l’historique : numéro de notice ou code-barres introuvable."
            );
            return;
        }

        const url = new URL(
            "/cgi-bin/koha/catalogue/issuehistory.pl",
            window.location.origin
        );

        url.searchParams.set("biblionumber", biblioNumber);
        url.searchParams.set("krt_barcode", barcode);

        if (itemNumber) {
            url.searchParams.set("krt_itemnumber", itemNumber);
        }

        url.hash = "krt-biblio-timeline";

        window.location.assign(url.toString());
    }

    function injectIntoCard(card) {
        if (!(card instanceof Element)) {
            return;
        }

        const existingButton = card.querySelector(".kxri-loan-history-standalone");
        if (!loanHistoryEnabled()) {
            if (existingButton) existingButton.remove();
            return;
        }

        const actions = card.querySelector(".kxri-actions");
        if (!actions) {
            return;
        }

        if (existingButton || actions.querySelector(".kxri-loan-history-standalone")) {
            return;
        }

        const button = document.createElement("button");
        button.type = "button";
        button.className = "kxri-action kxri-loan-history-standalone";
        button.title = "Historique de prêt préfiltré sur le code-barres de cet exemplaire";
        const loanLabel = (() => {
            try {
                const cfg = window.PMK129SearchResults && window.PMK129SearchResults.getConfig();
                const lang = String(document.documentElement.lang || navigator.language || "fr").toLowerCase().startsWith("en") ? "en" : "fr";
                return lang === "en" ? (cfg?.labels?.loanHistoryEn || "Loan history") : (cfg?.labels?.loanHistoryFr || "Historique de prêt");
            }
            catch (_) { return "Historique de prêt"; }
        })();
        button.innerHTML =
            '<i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i> ' + loanLabel;

        button.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            openLoanHistory(card);
        });

        const movements = actions.querySelector(
            ".kxri-open-central-movements, .kxmv-item-btn"
        );

        const details = actions.querySelector(".kxri-toggle-details");

        if (movements) {
            movements.insertAdjacentElement("afterend", button);
        }
        else if (details) {
            actions.insertBefore(button, details);
        }
        else {
            actions.appendChild(button);
        }
    }

    function scan() {
        if (!loanHistoryEnabled()) {
            document.querySelectorAll(".kxri-loan-history-standalone").forEach(button => button.remove());
            return;
        }

        document
            .querySelectorAll(".kxri-item")
            .forEach(injectIntoCard);
    }

    let scheduled = false;

    function scheduleScan() {
        if (scheduled) {
            return;
        }

        scheduled = true;
        window.requestAnimationFrame(() => {
            scheduled = false;
            scan();
        });
    }

    function installPatchStyle() {
        if (document.getElementById("kx-loan-history-standalone-style")) {
            return;
        }

        const style = document.createElement("style");
        style.id = "kx-loan-history-standalone-style";
        style.textContent = `
body.kx-search-results-page .kxri-actions > .kxri-loan-history-standalone,
.kxri-actions > .kxri-loan-history-standalone {
    display: inline-flex !important;
    visibility: visible !important;
    opacity: 1 !important;
}
`;
        document.head.appendChild(style);
    }

    function start() {
        installPatchStyle();
        scan();

        window.addEventListener("pmk129:config-changed", scheduleScan);

        const observer = new MutationObserver(scheduleScan);
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });

        // Filet de sécurité pour les cartes construites tardivement.
        window.setTimeout(scan, 500);
        window.setTimeout(scan, 1500);
        window.setTimeout(scan, 3000);

        (function(){})(
            "[KX historique prêt] patch autonome chargé — scan DOM actif."
        );
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start, { once: true });
    }
    else {
        start();
    }
})();

;window.PMKNonPlugin.loaded.push("129-mise-en-forme-exemplaire.js");
} catch (error) { window.PMKNonPlugin.errors.push("129-mise-en-forme-exemplaire.js: "+error.message); console.error("[PMK] 129-mise-en-forme-exemplaire.js",error); };
try {
/* PMK — Mouvements des documents — correctif 2026-10-09 */
(function(){
 const MODULE_ID="document-movements";
 const DEFAULT_SQL="SELECT bt.branchtransfer_id AS Transfer_ID, bt.itemnumber AS Item_ID,\n bt.frombranch AS From_Site, bt.tobranch AS To_Site,\n bt.daterequested AS Demande_le, bt.datesent AS Envoye_le,\n bt.datearrived AS Arrive_le, bt.datecancelled AS Annule_le,\n bt.reason AS Raison, bt.cancellation_reason AS Raison_annulation,\n bt.comments AS Commentaire\nFROM branchtransfers bt JOIN items i ON i.itemnumber = bt.itemnumber\nWHERE i.biblionumber = <<Biblionumber>> AND bt.branchtransfer_id > <<Après ID>>\nORDER BY bt.branchtransfer_id LIMIT 500";
 const REPORT_CONTRACT=['Transfer_ID','Item_ID','From_Site','To_Site','Demande_le','Envoye_le','Arrive_le','Annule_le','Raison','Raison_annulation','Commentaire'];
 const defaults={enabled:true,reportId:5254,sqlTemplate:DEFAULT_SQL,maxTransferBatches:20,
  dataSources:"Transferts : rapport SQL Koha configuré. Exemplaires, bibliothèques et prêts : API REST de cette installation Koha.",
  reportContract:REPORT_CONTRACT.join(', ')};
 let currentConfig={...defaults};
 let registered=false;
 let subscribed=false;
 let resolveReady;
 window.PMK130ConfigReady=new Promise(resolve=>{resolveReady=resolve});
 function applyConfig(cfg){currentConfig={...defaults,...(cfg || {})};resolveReady(currentConfig);}
 window.PMK130GetReportId=function(){const id=Number(currentConfig.reportId);return currentConfig.enabled!==false && Number.isInteger(id) && id>=0?id:0;};
 window.PMK130GetSettings=function(){return {reportId:window.PMK130GetReportId(),maxTransferBatches:Math.max(1,Math.min(200,Number(currentConfig.maxTransferBatches)||20)),batchSize:500};};
 window.PMK130ValidateReportRows=function(rows){
  if(!Array.isArray(rows))return {ok:false,missing:REPORT_CONTRACT.slice(),columns:[]};
  if(!rows.length)return {ok:true,missing:[],columns:[]};
  const aliases={Transfer_ID:['Transfer_ID','transfer_id'],Item_ID:['Item_ID','itemnumber'],From_Site:['From_Site','frombranch'],To_Site:['To_Site','tobranch'],Demande_le:['Demande_le','daterequested'],Envoye_le:['Envoye_le','datesent'],Arrive_le:['Arrive_le','datearrived'],Annule_le:['Annule_le','datecancelled'],Raison:['Raison','reason'],Raison_annulation:['Raison_annulation','cancellation_reason'],Commentaire:['Commentaire','comments']};
  const columns=Object.keys(rows[0]||{}),missing=REPORT_CONTRACT.filter(name=>!aliases[name].some(alias=>columns.includes(alias)));
  return {ok:missing.length===0,missing,columns};
 };
 function register(){
  if(registered)return true;
  if(!window.PMKConfig?.registerModule)return false;
  registered=true;
  window.PMKConfig.registerModule({id:MODULE_ID,schemaVersion:2,
   name:{fr:"Mouvements des documents",en:"Document movements"},
   description:{fr:"Mouvements, transferts et lieux de prêt, chargés à la demande.",en:"Item movements and loan locations, loaded on demand."},
   category:{fr:"Catalogue / exemplaires",en:"Catalog / items"},
   supportedPages:["catalogue.detail","catalogue.search"],prerequisites:[],dependencies:[],defaults,
   schema:[{type:"section",id:"report",label:{fr:"Rapport SQL Koha",en:"Koha SQL report"},fields:[
    {key:"sqlTemplate",type:"textarea",rows:20,readOnly:true,label:{fr:"SQL à créer dans Koha",en:"SQL to create in Koha"},help:{fr:"Conserver les paramètres <<Biblionumber>> et <<Après ID>>.",en:"Keep both SQL parameters unchanged."}},
    {key:"reportId",type:"number",label:{fr:"ID de votre rapport Koha",en:"Your Koha report ID"}},
    {key:"dataSources",type:"textarea",readOnly:true,label:{fr:"Provenance des données",en:"Data sources"}},
    {key:"reportContract",type:"textarea",readOnly:true,label:{fr:"Colonnes attendues du rapport",en:"Expected report columns"}},
    {key:"maxTransferBatches",type:"number",min:1,max:200,label:{fr:"Nombre maximal de lots de 500 transferts",en:"Maximum number of 500-transfer batches"},help:{fr:"La valeur par défaut limite une ouverture à 10 000 transferts. Le chargement s’arrête plus tôt dès que le rapport renvoie moins de 500 lignes.",en:"The default limits one opening to 10,000 transfers. Loading stops earlier when the report returns fewer than 500 rows."}}
   ]}]});
  window.PMKConfig.getConfig(MODULE_ID).then(applyConfig).catch(()=>applyConfig(defaults));
  if(!subscribed && window.PMKConfig.subscribe){window.PMKConfig.subscribe(MODULE_ID,applyConfig);subscribed=true;}
  return true;
 }
 if(!register()){
  window.addEventListener('pmk:config-ready',register,{once:true});
  document.addEventListener('pmk:ready',register,{once:true});
  (function (callback) {
        if (document.readyState === 'complete') callback.call(window);
        else window.addEventListener('load', callback, { once: true });
    })(()=>{if(!register())applyConfig(defaults)});
  if(document.readyState==='complete')applyConfig(defaults);
 }

})();
/******************************************************************
 * KOHA 25.11 — MOUVEMENTS DOCUMENTS
 * SCRIPT UNIQUE POUR INTRANETUSERJS
 * Correctif 2026-09-19 : détection robuste du code-barres pour le bouton Historique de prêt.
 *
 * Pages prises en charge :
 * - /cgi-bin/koha/catalogue/detail.pl
 * - /cgi-bin/koha/catalogue/search.pl
 *
 * Chaque module reste strictement limité à sa page.
 ******************************************************************/

(() => {
"use strict";

/*
 * KOHA 25.11 — MOUVEMENTS DES EXEMPLAIRES — detail.pl
 * Version intégrée visuellement à la fiche notice.
 *
 * - Bouton global "Mouvements de la notice" dans la barre d'outils Koha.
 * - Bouton "Mouvements" dans les actions de CHAQUE exemplaire.
 * - Dépliage visuel sous la ligne de l'exemplaire.
 * - Vue globale de la notice dans un panneau intégré au bloc Exemplaires.
 * - Chargement à la demande uniquement.
 * - 1 seule requête Koha active à la fois.
 */

const PATH = window.location.pathname;
if (PATH !== "/cgi-bin/koha/catalogue/detail.pl") return;
if (window.__dracItemMovementsIntegratedLoaded) return;
window.__dracItemMovementsIntegratedLoaded = true;

// ID du rapport "Historique transferts par notice".
function transferReportId(){return window.PMK130GetReportId();}

function getKohaSerialQueue() {
    if (window.DracKohaSerialQueue) return window.DracKohaSerialQueue;
    let tail = Promise.resolve();
    let lastEnd = 0;
    const MIN_GAP = 300;

    const run = (task) => {
        const job = tail.catch(() => {}).then(async () => {
            const wait = Math.max(0, MIN_GAP - (Date.now() - lastEnd));
            if (wait) await new Promise((resolve) => setTimeout(resolve, wait));
            try {
                return await task();
            } finally {
                lastEnd = Date.now();
            }
        });
        tail = job.catch(() => {});
        return job;
    };

    window.DracKohaSerialQueue = {
        run,
        fetch: (url, options) => run(() => fetch(url, options)),
        get pending() { return tail; }
    };
    return window.DracKohaSerialQueue;
}

const KOHA_QUEUE = getKohaSerialQueue();

const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (m) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[m]));

const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

function parseDate(value) {
    if (!value) return null;
    const raw = String(value).trim();
    if (!raw) return null;

    if (/^\d{2}\/\d{2}\/\d{4}/.test(raw)) {
        const [d, m, y] = raw.slice(0, 10).split("/").map(Number);
        const time = raw.match(/(\d{2}):(\d{2})/);
        return new Date(y, m - 1, d, time ? Number(time[1]) : 0, time ? Number(time[2]) : 0);
    }

    const d = new Date(raw.replace(" ", "T"));
    return Number.isNaN(d.getTime()) ? null : d;
}

function fmtDate(value) {
    const d = value instanceof Date ? value : parseDate(value);
    if (!d) return "—";
    return new Intl.DateTimeFormat("fr-FR", {
        day: "2-digit", month: "2-digit", year: "numeric"
    }).format(d);
}

function fmtDateTime(value) {
    const d = value instanceof Date ? value : parseDate(value);
    if (!d) return "—";
    return new Intl.DateTimeFormat("fr-FR", {
        day: "2-digit", month: "2-digit", year: "numeric",
        hour: "2-digit", minute: "2-digit"
    }).format(d);
}

const css = document.createElement("style");
css.textContent = `
/* Boutons intégrés */
.dim-notice-btn,
.dim-item-btn {
    white-space: nowrap;
}
.dim-item-btn {
    display: block !important;
    width: max-content;
    max-width: 100%;
    margin-top: 8px !important;
    margin-left: 0 !important;
    clear: both;
    border-color: #b9c9aa !important;
    color: #526d22 !important;
    background: #f8fbf4 !important;
}
.dim-item-btn:hover {
    background: #edf5e5 !important;
    border-color: #9db58a !important;
}
.dim-history-btn {
    display: block !important;
    width: max-content;
    max-width: 100%;
    margin-top: 5px !important;
    margin-left: 0 !important;
    clear: both;
    white-space: nowrap;
    border-color: #c8d3dc !important;
    color: #425b6d !important;
    background: #f7f9fb !important;
}
.dim-history-btn:hover {
    background: #eef3f6 !important;
    border-color: #aebdca !important;
}
.dim-notice-btn i,
.dim-item-btn i {
    margin-right: 4px;
}


#holdings_table td.actions .dim-item-btn {
    white-space: nowrap;
}
#holdings_table td.actions {
    min-width: 0 !important;
}

/* Ligne dépliée exemplaire */
tr.dim-detail-row > td {
    padding: 0 !important;
    background: #fbfcfa !important;
    border-top: 0 !important;
}
.dim-item-card {
    margin: 0;
    padding: 14px 16px 16px;
    border-left: 4px solid #6f8f32;
    background:
      linear-gradient(135deg, rgba(111,143,50,.055), rgba(75,120,160,.03)),
      #fff;
}
.dim-item-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 14px;
    margin-bottom: 12px;
}
.dim-item-title {
    font-size: 15px;
    font-weight: 800;
    color: #34444f;
}
.dim-item-sub {
    margin-top: 3px;
    color: #77838b;
    font-size: 11px;
}
.dim-current-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 9px;
    border: 1px solid #c9d8bb;
    border-radius: 999px;
    background: #f7fbf3;
    color: #526d22;
    font-weight: 800;
    font-size: 11px;
    white-space: nowrap;
}
.dim-item-kpis {
    display: grid;
    grid-template-columns: repeat(5, minmax(95px, 1fr));
    gap: 8px;
    margin-bottom: 14px;
}
.dim-item-kpi {
    border: 1px solid #e1e6e9;
    border-radius: 8px;
    background: rgba(255,255,255,.94);
    padding: 8px 9px;
}
.dim-item-kpi span {
    display: block;
    color: #7a8790;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .04em;
}
.dim-item-kpi strong {
    display: block;
    margin-top: 4px;
    color: #35444e;
    font-size: 14px;
}

/* Parcours graphique */
.dim-journey {
    --dim-gap-x: 10px;
    --dim-gap-y: 14px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
    gap: var(--dim-gap-y) var(--dim-gap-x);
    width: 100%;
    overflow: visible;
    padding: 8px 2px 4px;
}
.dim-step {
    position: relative;
    min-width: 0;
    max-width: none;
    width: 100%;
    text-align: center;
    padding: 0 6px 8px;
}

/* Liaison horizontale : du centre du point jusqu'au bord droit de la cellule,
   plus le gap vers la cellule suivante. */
.dim-step::after {
    content: "";
    position: absolute;
    z-index: 0;
    top: 12px;
    left: calc(50% + 13px);
    width: calc(50% + var(--dim-gap-x));
    height: 2px;
    background: #cbd7df;
}

/* Petit segment à gauche : il complète la ligne qui arrive depuis l'étape précédente. */
.dim-step::before {
    content: "";
    position: absolute;
    z-index: 0;
    top: 12px;
    right: calc(50% + 13px);
    width: calc(50% + var(--dim-gap-x));
    height: 2px;
    background: #cbd7df;
}

/* Première étape : aucune liaison entrante. */
.dim-step:first-child::before {
    display: none;
}

/* Dernière étape : aucune liaison sortante. */
.dim-step:last-child::after {
    display: none;
}

/* Quand une étape démarre une nouvelle ligne de grille, JS lui ajoute cette classe :
   on masque la ligne entrante horizontale et on dessine une continuité verticale
   depuis la rangée précédente. */
.dim-step.dim-row-start::before {
    display: none;
}
.dim-step.dim-row-start:not(:first-child) .dim-step-dot::before {
    content: "";
    position: absolute;
    left: 50%;
    bottom: calc(100% + 1px);
    width: 2px;
    height: var(--dim-gap-y);
    transform: translateX(-50%);
    background: #cbd7df;
    z-index: -1;
}

/* L'étape qui termine une rangée ne doit pas tendre une ligne vers le vide. */
.dim-step.dim-row-end::after {
    display: none;
}
.dim-step-dot {
    position: relative;
    z-index: 2;
    display: inline-flex;
    width: 26px;
    height: 26px;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    border: 2px solid #fff;
    background: #4b78a0;
    color: #fff;
    box-shadow: 0 0 0 1px #aabac6;
    font-size: 11px;
}
.dim-step.is-current .dim-step-dot {
    background: #6f8f32;
    box-shadow: 0 0 0 1px #9fb187;
}
.dim-step.is-cancelled .dim-step-dot {
    background: #a34f48;
    box-shadow: 0 0 0 1px #c28f8a;
}
.dim-step-date {
    margin-top: 6px;
    color: #78848c;
    font-size: 10px;
}
.dim-step-site {
    margin-top: 2px;
    color: #35444e;
    font-size: 11px;
    font-weight: 800;
}
.dim-step-label {
    margin-top: 2px;
    color: #68757e;
    font-size: 10px;
    line-height: 1.25;
}

/* Vue notice intégrée */
.dim-notice-panel {
    margin: 10px 0 16px;
    border: 1px solid #d7dee3;
    border-radius: 9px;
    background: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,.05);
    overflow: hidden;
}
.dim-notice-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 14px;
    padding: 12px 14px;
    background: linear-gradient(135deg, #f8fbf4, #f5f8fa);
    border-bottom: 1px solid #e1e7ea;
}
.dim-notice-title {
    color: #526d22;
    font-size: 15px;
    font-weight: 800;
}
.dim-notice-sub {
    margin-top: 3px;
    color: #73808a;
    font-size: 11px;
}
.dim-notice-body {
    padding: 12px 14px 14px;
}
.dim-notice-kpis {
    display: grid;
    grid-template-columns: repeat(4, minmax(110px,1fr));
    gap: 8px;
    margin-bottom: 12px;
}
.dim-notice-kpi {
    padding: 9px 10px;
    border: 1px solid #e1e6e9;
    border-radius: 8px;
    background: #fff;
}
.dim-notice-kpi span {
    display: block;
    color: #7a8790;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
}
.dim-notice-kpi strong {
    display: block;
    margin-top: 4px;
    color: #35444e;
    font-size: 17px;
}
.dim-notice-list {
    display: grid;
    gap: 8px;
}
.dim-notice-item {
    display: grid;
    grid-template-columns: minmax(145px, .8fr) 1fr 1fr auto;
    gap: 12px;
    align-items: center;
    padding: 9px 10px;
    border: 1px solid #e1e6e9;
    border-radius: 8px;
}
.dim-notice-item-code {
    font-weight: 800;
    color: #34444e;
}
.dim-notice-item-route {
    color: #4b78a0;
    font-weight: 700;
    font-size: 11px;
}
.dim-notice-item-meta {
    color: #6d7982;
    font-size: 11px;
}
.dim-notice-open {
    white-space: nowrap;
}
.dim-empty,
.dim-error {
    padding: 12px;
    color: #68757e;
}
.dim-error {
    border: 1px solid #efc9c5;
    border-radius: 7px;
    background: #fff2f0;
    color: #963f38;
}


.dim-direction {
    margin-top: 7px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    padding: 4px 8px;
    border-radius: 7px;
    background: #f5f8fa;
    border: 1px solid #dde5ea;
    color: #41525e;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
}
.dim-direction.is-out {
    background: #eef5fb;
    border-color: #c7dbe9;
    color: #356b91;
}
.dim-direction.is-home {
    background: #f2f8ed;
    border-color: #cfdfc1;
    color: #55752d;
}
.dim-direction.is-network {
    background: #f7f5fb;
    border-color: #ddd4ea;
    color: #6b5686;
}
.dim-direction.is-cancelled {
    background: #fff1ef;
    border-color: #e8c4c0;
    color: #9c453f;
    text-decoration: line-through;
}
.dim-arrow {
    font-size: 17px;
    line-height: 1;
    letter-spacing: -2px;
}
.dim-reason {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    margin-top: 5px;
    padding: 2px 7px;
    border-radius: 999px;
    background: #eef1f3;
    color: #5f6d77;
    font-size: 10px;
    font-weight: 700;
}
.dim-reason i {
    opacity: .8;
}
.dim-step.is-pending .dim-step-dot {
    background: #d18a2b;
    box-shadow: 0 0 0 1px #d9ad6e;
}
.dim-step.is-pending::after,
.dim-step.is-pending::before {
    background: repeating-linear-gradient(90deg,#d18a2b 0 7px,transparent 7px 11px);
}
.dim-step.is-pending.dim-row-start .dim-step-dot::before {
    background: repeating-linear-gradient(180deg,#d18a2b 0 7px,transparent 7px 11px);
}


/* Lieux de prêt */
.dim-loans {
    margin-top: 14px;
    padding-top: 12px;
    border-top: 1px solid #e1e7ea;
}
.dim-loans-title {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
    color: #43535e;
    font-size: 12px;
    font-weight: 800;
}
.dim-loan-kpis {
    display: grid;
    grid-template-columns: repeat(4, minmax(100px, 1fr));
    gap: 7px;
    margin-bottom: 9px;
}
.dim-loan-kpi {
    padding: 7px 8px;
    border: 1px solid #e1e6e9;
    border-radius: 7px;
    background: #fff;
}
.dim-loan-kpi span {
    display: block;
    color: #7c8790;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
}
.dim-loan-kpi strong {
    display: block;
    margin-top: 3px;
    color: #35444e;
    font-size: 14px;
}
.dim-loan-sites {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px,1fr));
    gap: 7px;
}
.dim-loan-site {
    padding: 7px 8px;
    border: 1px solid #e1e6e9;
    border-radius: 7px;
    background: #fff;
}
.dim-loan-site.is-home {
    border-color: #cdddbf;
    background: #f8fbf4;
}
.dim-loan-site.is-away {
    border-color: #d5e0e8;
    background: #f8fafc;
}
.dim-loan-site-top {
    display: flex;
    justify-content: space-between;
    gap: 7px;
    align-items: center;
    font-size: 10px;
}
.dim-loan-site-name {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: 700;
    color: #455660;
}
.dim-loan-bar {
    height: 4px;
    margin-top: 5px;
    border-radius: 4px;
    background: #e9eef1;
    overflow: hidden;
}
.dim-loan-bar span {
    display: block;
    height: 100%;
    background: currentColor;
    color: #6f8f32;
}
.dim-loan-site.is-away .dim-loan-bar span {
    color: #4b78a0;
}
.dim-loan-site-foot {
    margin-top: 3px;
    color: #7a858d;
    font-size: 9px;
}
.dim-loan-empty {
    color: #78848d;
    font-size: 10px;
    padding: 5px 0;
}

@media (max-width: 1000px) {
    .dim-journey {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .dim-item-kpis {
        grid-template-columns: repeat(2, minmax(105px,1fr));
    }
    .dim-notice-kpis {
        grid-template-columns: repeat(2, minmax(105px,1fr));
    }
    .dim-notice-item {
        grid-template-columns: 1fr;
        gap: 4px;
    }
    .dim-item-head {
        display: block;
    }
    .dim-current-badge {
        margin-top: 7px;
    }
}
@media (max-width: 620px) {
    .dim-journey {
        grid-template-columns: 1fr;
    }
    .dim-step::before,
    .dim-step::after {
        display: none !important;
    }
    .dim-step:not(:first-child) .dim-step-dot::before {
        content: "";
        position: absolute;
        left: 50%;
        bottom: calc(100% + 1px);
        width: 2px;
        height: var(--dim-gap-y);
        transform: translateX(-50%);
        background: #cbd7df;
        z-index: -1;
    }
}
`;
document.head.appendChild(css);

async function getJson(url) {
    const response = await KOHA_QUEUE.fetch(url, {
        credentials: "same-origin",
        cache: "no-store",
        headers: { Accept: "application/json" }
    });
    if (!response.ok) {
        const err = new Error(`Koha HTTP ${response.status}`);
        err.status = response.status;
        throw err;
    }
    return { data: await response.json(), response };
}

async function getPaged(url, perPage = 100) {
    const all = [];
    let page = 1;

    while (page <= 100) {
        const u = new URL(url, location.origin);
        u.searchParams.set("_page", String(page));
        u.searchParams.set("_per_page", String(perPage));

        const { data, response } = await getJson(u.toString());
        if (!Array.isArray(data)) break;

        all.push(...data);

        const total = Number(response.headers.get("X-Total-Count") || 0);
        if ((total && all.length >= total) || data.length < perPage) break;

        page += 1;
    }

    return all;
}

async function loadTransfers(biblioId) {
    await window.PMK130ConfigReady;
    const reportId=transferReportId();
    if (!reportId) return [];

    const all = [];
    let cursor = 0;
    let lots = 0;
    const maxBatches=window.PMK130GetSettings?.().maxTransferBatches || 20;

    while (lots < maxBatches) {
        lots += 1;

        const u = new URL("/cgi-bin/koha/svc/report", location.origin);
        u.searchParams.set("id", String(reportId));
        u.searchParams.set("annotated", "1");
        u.searchParams.append("param_names", "Biblionumber");
        u.searchParams.append("sql_params", String(biblioId));
        u.searchParams.append("param_names", "Après ID");
        u.searchParams.append("sql_params", String(cursor));

        const { data } = await getJson(u.toString());
        if (!Array.isArray(data) || !data.length) break;
        const contract=window.PMK130ValidateReportRows?.(data);
        if(contract && !contract.ok)throw new Error("Rapport mouvements incompatible — colonnes manquantes : "+contract.missing.join(", "));

        all.push(...data);

        const last = Number(
            data[data.length - 1].Transfer_ID ??
            data[data.length - 1].transfer_id ??
            0
        );

        if (!Number.isFinite(last) || last <= cursor) break;
        cursor = last;

        if (data.length < 500) break;
    }

    return all;
}

async function loadLibraries() {
    try {
        const { data } = await getJson("/api/v1/public/libraries");
        const map = new Map();
        (Array.isArray(data) ? data : []).forEach((l) => {
            map.set(String(l.library_id), l.name || l.library_id);
        });
        return map;
    } catch (_) {
        return new Map();
    }
}

function itemVal(obj, ...keys) {
    for (const key of keys) {
        if (obj?.[key] !== undefined && obj[key] !== null && obj[key] !== "") {
            return obj[key];
        }
    }
    return null;
}

function getBiblioId() {
    return new URLSearchParams(location.search).get("biblionumber");
}

function getItemIdFromRow(row) {
    const checkbox = row.querySelector('input[name="itemnumber"]');
    if (checkbox?.value) return String(checkbox.value);

    const link = row.querySelector('a[href*="itemnumber="]');
    if (link) {
        try {
            return new URL(link.getAttribute("href"), location.origin).searchParams.get("itemnumber");
        } catch (_) {}
    }
    return null;
}

function getBarcodeFromRow(row) {
    if (!row) return "";

    // 1) Structure Koha / DataTables classique.
    const labelledCell = row.querySelector('[data-label="barcode"]');
    if (labelledCell) {
        const value = clean(labelledCell.textContent || "");
        if (value) return value;
    }

    // 2) Attributs explicites éventuels ajoutés par Koha ou un autre module.
    const explicitBarcodeNode = row.querySelector('[data-barcode], [data-item-barcode]');
    if (explicitBarcodeNode) {
        const value = clean(
            explicitBarcodeNode.dataset?.barcode ||
            explicitBarcodeNode.dataset?.itemBarcode ||
            explicitBarcodeNode.getAttribute('data-barcode') ||
            explicitBarcodeNode.getAttribute('data-item-barcode') ||
            explicitBarcodeNode.textContent ||
            ""
        );
        if (value) return value;
    }

    // 3) Fallback robuste pour detail.pl : dans le tableau des exemplaires,
    // le code-barres est le texte du lien vers moredetail.pl contenant itemnumber.
    // Cela couvre notamment les tableaux reconstruits/stylés où data-label="barcode"
    // n'est plus présent.
    const moreDetailLink = row.querySelector(
        'a[href*="/cgi-bin/koha/catalogue/moredetail.pl"][href*="itemnumber="]'
    );
    if (moreDetailLink) {
        const value = clean(moreDetailLink.textContent || "");
        if (value) return value;
    }

    // 4) Dernier fallback : repérer dynamiquement la colonne Code-barres / Barcode
    // depuis l'en-tête du tableau, sans dépendre de data-label.
    const table = row.closest('table');
    if (table) {
        const headers = Array.from(table.querySelectorAll('thead th'));
        const barcodeIndex = headers.findIndex((th) => {
            const text = clean(th.textContent || "").toLowerCase();
            return (
                text === "code-barres" ||
                text === "code barre" ||
                text === "code-barres exemplaire" ||
                text === "barcode" ||
                text.includes("code-barres") ||
                text.includes("barcode")
            );
        });

        if (barcodeIndex >= 0 && row.cells?.[barcodeIndex]) {
            const value = clean(row.cells[barcodeIndex].textContent || "");
            if (value) return value;
        }
    }

    return "";
}

function getCellText(row, label) {
    return clean(row.querySelector(`[data-label="${label}"]`)?.textContent || "");
}

function transferDate(t) {
    const values = [t.Arrive_le, t.datearrived, t.Envoye_le, t.datesent,
        t.Demande_le, t.daterequested, t.Annule_le, t.datecancelled];
    return values.filter(v => parseDate(v)).sort((a,b) => parseDate(b)-parseDate(a))[0] || "";
}

function getTransferState(t) {
    if (parseDate(t.Annule_le || t.datecancelled)) return "cancelled";
    if (parseDate(t.Arrive_le || t.datearrived)) return "arrived";
    if (parseDate(t.Envoye_le || t.datesent)) return "sent";
    if (parseDate(t.Demande_le || t.daterequested)) return "requested";
    return "unknown";
}
function transferStatus(t, transfers = []) {
    const state = getTransferState(t);
    if(state === "cancelled") return (t.Envoye_le || t.datesent) ? "Annulé après envoi" : "Annulé avant envoi";
    if(state === "arrived") return "Arrivé";
    if(state === "sent") return "En transit";
    if(state !== "requested") return "État non renseigné";
    const active = transfers.filter(x => ["requested","sent"].includes(getTransferState(x)));
    const sent = active.some(x => getTransferState(x) === "sent");
    const requests = active.filter(x => getTransferState(x) === "requested").sort((a,b) =>
        (parseDate(a.Demande_le || a.daterequested)?.getTime() || 0) - (parseDate(b.Demande_le || b.daterequested)?.getTime() || 0)
        || Number(a.Transfer_ID || a.transfer_id || 0)-Number(b.Transfer_ID || b.transfer_id || 0));
    return sent || (requests.length > 1 && requests[0] !== t) ? "Demandé · en file d’attente présumée" : "Demandé, non envoyé";
}

function latestTransfer(transfers) {
    return [...transfers].sort((a,b) => {
        const da = parseDate(transferDate(a))?.getTime() || 0;
        const db = parseDate(transferDate(b))?.getTime() || 0;
        return db - da;
    })[0] || null;
}

function uniqueSitesForItem(item, transfers) {
    const set = new Set();
    const home = itemVal(item, "home_library_id", "homebranch");
    const holding = itemVal(item, "holding_library_id", "holdingbranch");

    if (home) set.add(String(home));
    if (holding) set.add(String(holding));

    transfers.forEach((t) => {
        const from = t.From_Site ?? t.frombranch;
        const to = t.To_Site ?? t.tobranch;
        if (from) set.add(String(from));
        if (to) set.add(String(to));
    });

    return set;
}


const TRANSFER_REASON_LABELS = {
    Manual: ["Transfert manuel", "fa-hand"],
    StockrotationAdvance: ["Rotation de stock", "fa-rotate"],
    StockrotationRepatriation: ["Retour de rotation", "fa-rotate-left"],
    ReturnToHome: ["Retour au site de rattachement", "fa-house"],
    ReturnToHolding: ["Retour au site de détention", "fa-location-dot"],
    RotatingCollection: ["Collection tournante", "fa-arrows-rotate"],
    Reserve: ["Réservation", "fa-bookmark"],
    LostReserve: ["Réservation sur document perdu", "fa-triangle-exclamation"],
    CancelReserve: ["Suite à une annulation de réservation", "fa-bookmark"],
    TransferCancellation: ["Suite à une annulation de transfert", "fa-xmark"],
    Recall: ["Rappel", "fa-bell"],
    RecallCancellation: ["Suite à une annulation de rappel", "fa-bell-slash"],
    LibraryFloatLimit: ["Limite de flottement", "fa-water"]
};

const CANCELLATION_REASON_LABELS = {
    Manual: ["Annulation manuelle", "fa-hand"],
    StockrotationAdvance: ["Rotation de stock", "fa-rotate"],
    StockrotationRepatriation: ["Retour de rotation", "fa-rotate-left"],
    ReturnToHome: ["Retour au rattachement", "fa-house"],
    ReturnToHolding: ["Retour à la détention", "fa-location-dot"],
    RotatingCollection: ["Collection tournante", "fa-arrows-rotate"],
    Reserve: ["Réservation", "fa-bookmark"],
    LostReserve: ["Réservation sur document perdu", "fa-triangle-exclamation"],
    CancelReserve: ["Réservation annulée", "fa-bookmark"],
    ItemLost: ["Document perdu", "fa-triangle-exclamation"],
    WrongTransfer: ["Mauvais transfert", "fa-shuffle"],
    RecallCancellation: ["Rappel annulé", "fa-bell-slash"]
};

function reasonInfo(t) {
    const raw = String(t.Raison || t.reason || "").trim();
    const entry = TRANSFER_REASON_LABELS[raw];
    let label = entry ? entry[0] : (raw ? "Motif inconnu : " + raw : "Motif non renseigné");
    const cancelled = getTransferState(t) === "cancelled";
    const cancel = String(t.Raison_annulation || t.cancellation_reason || "").trim();
    if(cancelled) label += " · Annulation : " + (CANCELLATION_REASON_LABELS[cancel]?.[0] || cancel || "motif non renseigné");
    const from = t.From_Site || t.frombranch, to = t.To_Site || t.tobranch;
    if(!from || !to) label += " · Trajet incomplet";
    else if(from === to) label += " · Origine et destination identiques";
    const comment = String(t.Commentaire || t.comments || "").trim();
    if(comment) label += " · Commentaire : " + comment;
    return {raw: raw + (cancelled ? " / annulation : " + (cancel || "non renseigné") : ""),
        label, icon:entry?.[1] || "fa-circle-question", known:!!entry};
}

function movementDirection(homeCode, fromCode, toCode, cancelled=false) {
    const home = String(homeCode || "");
    const from = String(fromCode || "");
    const to = String(toCode || "");

    if (home && from === home && to && to !== home) {
        return { kind: cancelled ? "cancelled" : "out", arrow:"==>", semantic:"Départ du site de rattachement" };
    }
    if (home && to === home && from && from !== home) {
        // Affichage volontairement centré sur le site propriétaire à gauche :
        // DRA <== VID signifie mouvement réel VID → DRA.
        return { kind: cancelled ? "cancelled" : "home", arrow:"<==", semantic:"Retour vers le site de rattachement" };
    }
    if (from && to && from !== to) {
        return { kind: cancelled ? "cancelled" : "network", arrow:"==>", semantic:"Déplacement entre sites du réseau" };
    }
    return { kind: cancelled ? "cancelled" : "network", arrow:"→", semantic:"Transfert" };
}

function routeVisual(homeCode, t, libs) {
    const fromCode = String(t.From_Site ?? t.frombranch ?? "");
    const toCode = String(t.To_Site ?? t.tobranch ?? "");
    const from = libs.get(fromCode) || fromCode || "?";
    const to = libs.get(toCode) || toCode || "?";
    const cancelled = Boolean(t.Annule_le || t.datecancelled);
    const dir = movementDirection(homeCode, fromCode, toCode, cancelled);

    if (homeCode && toCode === String(homeCode) && fromCode !== String(homeCode)) {
        const homeName = libs.get(String(homeCode)) || String(homeCode);
        return { ...dir, left:homeName, right:from, real:`${from} → ${homeName}` };
    }
    return { ...dir, left:from, right:to, real:`${from} → ${to}` };
}

function buildJourney(item, transfers, libs) {
    const points = [];

    const home = String(itemVal(item, "home_library_id", "homebranch") || "");
    const holding = String(itemVal(item, "holding_library_id", "holdingbranch") || "");

    transfers.forEach((t) => {
        const from = String(t.From_Site ?? t.frombranch ?? "");
        const to = String(t.To_Site ?? t.tobranch ?? "");
        const state = getTransferState(t);
        const route = routeVisual(home, t, libs);
        const reason = reasonInfo(t);
        const pending = state === "requested" || state === "sent";

        points.push({
            date: parseDate(transferDate(t)),
            site: to || from,
            label: transferStatus(t, transfers),
            state: state === "cancelled" ? "cancelled" : (pending ? "pending" : state),
            route,
            reason
        });
    });

    if (holding) {
        points.push({
            date: null,
            site: holding,
            label: "Site détenteur enregistré",
            state: "current"
        });
    }

    return points
        .filter((p) => p.site)
        .sort((a,b) => (a.state === "current" ? Infinity : a.date?.getTime() || 0) - (b.state === "current" ? Infinity : b.date?.getTime() || 0));
}


function checkoutSiteCode(checkout) {
    return String(
        checkout?.library_id ??
        checkout?.checkout_library_id ??
        checkout?.branchcode ??
        ""
    );
}

function checkoutItemId(checkout) {
    return String(
        checkout?.item_id ??
        checkout?.itemnumber ??
        ""
    );
}

function buildLoanStatsForItem(item, checkouts, libs) {
    const homeCode = String(itemVal(item, "home_library_id", "homebranch") || "");
    const itemId = String(itemVal(item, "item_id", "itemnumber") || "");

    const relevant = (checkouts || []).filter((c) => checkoutItemId(c) === itemId);
    const bySite = new Map();

    relevant.forEach((checkout) => {
        const code = checkoutSiteCode(checkout);
        if (!code) return;
        bySite.set(code, (bySite.get(code) || 0) + 1);
    });

    const total = Array.from(bySite.values()).reduce((sum, n) => sum + n, 0);
    const atHome = homeCode ? (bySite.get(homeCode) || 0) : 0;
    const outside = Math.max(0, total - atHome);

    const sites = [...bySite.entries()]
        .map(([code, count]) => ({
            code,
            name: libs.get(code) || code,
            count,
            isHome: Boolean(homeCode && code === homeCode),
            pct: total ? Math.round((count / total) * 100) : 0
        }))
        .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "fr"));

    return { total, atHome, outside, sites, homeCode };
}

function buildNoticeLoanStats(byItem, checkouts, libs) {
    let total = 0;
    let atHome = 0;
    let outside = 0;
    const loanSites = new Set();

    byItem.forEach((record) => {
        const stats = buildLoanStatsForItem(record.item || {}, checkouts, libs);
        total += stats.total;
        atHome += stats.atHome;
        outside += stats.outside;
        stats.sites.forEach((s) => loanSites.add(s.code));
    });

    return { total, atHome, outside, loanSites: loanSites.size };
}

function loanSitesHtml(stats) {
    if (!stats || !stats.total) {
        return '<div class="dim-loan-empty">Aucun lieu de prêt historique exploitable.</div>';
    }

    return `<div class="dim-loan-sites">
        ${stats.sites.map((site) => `
            <div class="dim-loan-site ${site.isHome ? "is-home" : "is-away"}">
                <div class="dim-loan-site-top">
                    <span class="dim-loan-site-name">${site.isHome ? '<i class="fa-solid fa-house"></i> ' : '<i class="fa-solid fa-building"></i> '}${esc(site.name)}</span>
                    <strong>${site.count}</strong>
                </div>
                <div class="dim-loan-bar"><span style="width:${Math.max(3, site.pct)}%"></span></div>
                <div class="dim-loan-site-foot">${site.pct}% ${site.isHome ? "· site propriétaire" : "· hors site propriétaire"}</div>
            </div>
        `).join("")}
    </div>`;
}

let cachePromise = null;

async function loadData() {
    if (cachePromise) return cachePromise;

    cachePromise = (async () => {
        const biblioId = getBiblioId();
        if (!biblioId) throw new Error("Numéro de notice introuvable.");

        const libs = await loadLibraries();
        const items = await getPaged(`/api/v1/public/biblios/${encodeURIComponent(biblioId)}/items`, 100);
        const transfers = await loadTransfers(biblioId);
        const checkouts = await getPaged(`/api/v1/biblios/${encodeURIComponent(biblioId)}/checkouts?checked_in=true`, 100);

        const byItem = new Map();

        items.forEach((item) => {
            const id = String(itemVal(item, "item_id", "itemnumber") || "");
            if (!id) return;
            byItem.set(id, { item, transfers: [] });
        });

        transfers.forEach((t) => {
            const id = String(t.Item_ID ?? t.item_id ?? t.itemnumber ?? "");
            if (!id) return;
            if (!byItem.has(id)) byItem.set(id, { item: null, transfers: [] });
            byItem.get(id).transfers.push(t);
        });

        return { biblioId, libs, items, transfers, checkouts, byItem };
    })();

    return cachePromise.catch(error => { cachePromise = null; throw error; });
}


function markJourneyRows(journey) {
    if (!journey) return;

    const steps = Array.from(journey.querySelectorAll(".dim-step"));
    steps.forEach((step) => step.classList.remove("dim-row-start", "dim-row-end"));
    if (!steps.length) return;

    let currentTop = null;
    let previous = null;

    steps.forEach((step) => {
        const top = step.offsetTop;

        if (currentTop === null || Math.abs(top - currentTop) > 2) {
            if (previous) previous.classList.add("dim-row-end");
            step.classList.add("dim-row-start");
            currentTop = top;
        }

        previous = step;
    });

    if (previous) previous.classList.add("dim-row-end");

    // La première étape n'a jamais besoin du trait vertical d'entrée.
    steps[0].classList.remove("dim-row-start");
}

function renderItemContent(container, itemId, row, data) {
    const record = data.byItem.get(String(itemId));
    const item = record?.item || {};
    const transfers = record?.transfers || [];

    const barcode =
        itemVal(item, "external_id", "barcode") ||
        getBarcodeFromRow(row) ||
        `Exemplaire ${itemId}`;

    const homeCode = String(itemVal(item, "home_library_id", "homebranch") || "");
    const holdingCode = String(itemVal(item, "holding_library_id", "holdingbranch") || "");

    const home = data.libs.get(homeCode) || homeCode || getCellText(row, "homebranch") || "—";
    const holding = data.libs.get(holdingCode) || holdingCode || getCellText(row, "holdingbranch") || "—";

    const last = latestTransfer(transfers);
    const sites = uniqueSitesForItem(item, transfers);
    const journey = buildJourney(item, transfers, data.libs);
    const loanStats = buildLoanStatsForItem(item, data.checkouts || [], data.libs);

    const journeyHtml = journey.length
        ? `<div class="dim-journey">${journey.map((p) => {
            const icon = p.state === "current" ? "fa-location-dot"
                       : p.state === "cancelled" ? "fa-xmark"
                       : p.state === "pending" ? "fa-truck-fast"
                       : p.state === "acquisition" ? "fa-book"
                       : "fa-arrow-right";
            const routeHtml = p.route
                ? `<div class="dim-direction is-${esc(p.route.kind)}" title="${esc(p.route.semantic)} · trajet enregistré : ${esc(p.route.real)}">
                    <span>${esc(p.route.left)}</span>
                    <span class="dim-arrow">${esc(p.route.arrow)}</span>
                    <span>${esc(p.route.right)}</span>
                   </div>`
                : "";
            const reasonHtml = p.reason
                ? `<div class="dim-reason" title="Code Koha : ${esc(p.reason.raw || "non renseigné")}">
                    <i class="fa-solid ${esc(p.reason.icon)}"></i> ${esc(p.reason.label)}
                   </div>`
                : "";
            return `<div class="dim-step ${p.state === "current" ? "is-current" : ""} ${p.state === "cancelled" ? "is-cancelled" : ""} ${p.state === "pending" ? "is-pending" : ""}">
                <span class="dim-step-dot"><i class="fa-solid ${icon}"></i></span>
                <div class="dim-step-date">${esc(fmtDate(p.date))}</div>
                <div class="dim-step-site">${esc(data.libs.get(p.site) || p.site)}</div>
                <div class="dim-step-label">${esc(p.label)}</div>
                ${routeHtml}
                ${reasonHtml}
            </div>`;
        }).join("")}</div>`
        : `<div class="dim-empty">Aucun déplacement historique enregistré pour cet exemplaire.</div>`;

    container.innerHTML = `
      <div class="dim-item-card">
        <div class="dim-item-head">
          <div>
            <div class="dim-item-title"><i class="fa-solid fa-route"></i> Parcours de ${esc(barcode)}</div>
            <div class="dim-item-sub">Historique synthétique des changements de site connus.</div>
          </div>
          <div class="dim-current-badge"><i class="fa-solid fa-location-dot"></i> ${esc(holding)}</div>
        </div>

        <div class="dim-item-kpis">
          <div class="dim-item-kpi"><span>Rattachement</span><strong>${esc(home)}</strong></div>
          <div class="dim-item-kpi"><span>Site détenteur enregistré</span><strong>${esc(holding)}</strong></div>
          <div class="dim-item-kpi"><span>Transferts</span><strong>${transfers.length}</strong></div>
          <div class="dim-item-kpi"><span>Sites mentionnés</span><strong>${sites.size}</strong></div>
          <div class="dim-item-kpi"><span>Dernier événement</span><strong>${esc(fmtDate(last ? transferDate(last) : null))}</strong></div>
        </div>

        ${journeyHtml}

        <div class="dim-loans">
          <div class="dim-loans-title"><i class="fa-solid fa-building-columns"></i> Lieux de prêt par rapport au site propriétaire</div>
          <div class="dim-loan-kpis">
            <div class="dim-loan-kpi"><span>Prêts connus</span><strong>${loanStats.total}</strong></div>
            <div class="dim-loan-kpi"><span>Sur site propriétaire</span><strong>${loanStats.atHome}</strong></div>
            <div class="dim-loan-kpi"><span>Hors site propriétaire</span><strong>${loanStats.outside}</strong></div>
            <div class="dim-loan-kpi"><span>Sites de prêt</span><strong>${loanStats.sites.length}</strong></div>
          </div>
          ${loanSitesHtml(loanStats)}
        </div>
      </div>`;

    const journeyEl = container.querySelector(".dim-journey");
    if (journeyEl) {
        markJourneyRows(journeyEl);

        // Recalcul en cas de changement de largeur du tableau / fenêtre.
        if (!journeyEl.__dimResizeObserver && window.ResizeObserver) {
            const ro = new ResizeObserver(() => markJourneyRows(journeyEl));
            ro.observe(journeyEl);
            journeyEl.__dimResizeObserver = ro;
        }
    }
}

async function openItemMovement(row, itemId) {
    let detailRow = row.nextElementSibling?.classList.contains("dim-detail-row")
        ? row.nextElementSibling
        : null;

    if (detailRow) {
        const opening = detailRow.hidden;
        detailRow.hidden = !opening;
        return;
    }

    detailRow = document.createElement("tr");
    detailRow.className = "dim-detail-row";

    const td = document.createElement("td");
    td.colSpan = row.cells.length;

    const content = document.createElement("div");
    content.className = "dim-empty";
    content.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Chargement du parcours…';

    td.appendChild(content);
    detailRow.appendChild(td);
    row.insertAdjacentElement("afterend", detailRow);

    try {
        const data = await loadData();
        renderItemContent(content, itemId, row, data);

        window.setTimeout(() => {
            detailRow.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }, 60);
    } catch (error) {
        console.error("[Mouvements exemplaire]", error);
        content.className = "dim-error";
        content.innerHTML = `<strong>Impossible de charger les mouvements.</strong><br>${esc(error.message || error)}`;
    }
}

function injectItemButtons(table) {
    table.querySelectorAll("tbody tr").forEach((row) => {
        if (row.dataset.dimMovementReady === "1") return;
        if (row.classList.contains("dim-detail-row")) return;

        const itemId = getItemIdFromRow(row);
        if (!itemId) return;

        const actionCell = row.querySelector('td[data-label="actions"], td.actions');
        if (!actionCell) return;

        if (actionCell.querySelector(".dim-item-btn") && actionCell.querySelector(".dim-history-btn")) {
            row.dataset.dimMovementReady = "1";
            return;
        }
        actionCell.querySelectorAll(".dim-item-btn, .dim-history-btn").forEach((el) => el.remove());

        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "btn btn-default btn-xs dim-item-btn";
        btn.innerHTML = '<i class="fa-solid fa-route"></i> Mouvements';
        btn.title = "Afficher le parcours de cet exemplaire";

        btn.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            openItemMovement(row, itemId);
        });

        // Le bouton est volontairement ajouté APRÈS le groupe d’actions natif :
        // il reste sur sa propre ligne et n’élargit pas la colonne.
        actionCell.appendChild(btn);

        const historyBtn = document.createElement("a");
        historyBtn.className = "btn btn-default btn-xs dim-history-btn";
        historyBtn.innerHTML = '<i class="fa-solid fa-clock-rotate-left"></i> Historique de prêt';
        historyBtn.title = "Ouvrir l’historique de prêt préfiltré sur cet exemplaire";

        const barcode = getBarcodeFromRow(row);
        const biblioId = getBiblioId();

        if (biblioId && barcode) {
            const historyUrl = new URL("/cgi-bin/koha/catalogue/issuehistory.pl", location.origin);
            historyUrl.searchParams.set("biblionumber", biblioId);
            historyUrl.searchParams.set("krt_barcode", barcode);
            historyUrl.searchParams.set("krt_itemnumber", itemId);
            historyUrl.hash = "krt-biblio-timeline";
            historyBtn.href = historyUrl.toString();
        } else {
            historyBtn.href = "#";
            historyBtn.classList.add("disabled");
            historyBtn.setAttribute("aria-disabled", "true");
        }

        actionCell.appendChild(historyBtn);
        row.dataset.dimMovementReady = "1";
    });
}

function renderNoticePanel(panel, data) {
    const allSites = new Set();
    let lastMove = null;

    data.byItem.forEach((record) => {
        const item = record.item || {};
        const home = itemVal(item, "home_library_id", "homebranch");
        const holding = itemVal(item, "holding_library_id", "holdingbranch");
        if (home) allSites.add(String(home));
        if (holding) allSites.add(String(holding));

        record.transfers.forEach((t) => {
            const from = t.From_Site ?? t.frombranch;
            const to = t.To_Site ?? t.tobranch;
            if (from) allSites.add(String(from));
            if (to) allSites.add(String(to));

            const d = parseDate(transferDate(t));
            if (d && (!lastMove || d > lastMove)) lastMove = d;
        });
    });

    const noticeLoanStats = buildNoticeLoanStats(data.byItem, data.checkouts || [], data.libs);

    const rows = [...data.byItem.entries()].map(([itemId, record]) => {
        const item = record.item || {};
        const transfers = record.transfers || [];
        const barcode = itemVal(item, "external_id", "barcode") || `Exemplaire ${itemId}`;

        const homeCode = String(itemVal(item, "home_library_id", "homebranch") || "");
        const holdingCode = String(itemVal(item, "holding_library_id", "holdingbranch") || "");
        const home = data.libs.get(homeCode) || homeCode || "—";
        const holding = data.libs.get(holdingCode) || holdingCode || "—";

        const last = latestTransfer(transfers);
        const loanStats = buildLoanStatsForItem(item, data.checkouts || [], data.libs);
        const lastVisual = last ? routeVisual(homeCode, last, data.libs) : null;
        const lastReason = last ? reasonInfo(last) : null;
        const lastRoute = lastVisual
            ? `${lastVisual.left} ${lastVisual.arrow} ${lastVisual.right}`
            : "Aucun transfert";

        return `<div class="dim-notice-item" data-item-id="${esc(itemId)}">
            <div class="dim-notice-item-code">${esc(barcode)}</div>
            <div class="dim-notice-item-route"><i class="fa-solid fa-location-dot"></i> ${esc(home)} → ${esc(holding)}</div>
            <div class="dim-notice-item-meta">${transfers.length} transfert(s) · dernier : ${esc(fmtDate(last ? transferDate(last) : null))}<br><strong>${esc(lastRoute)}</strong>${lastReason ? ` · ${esc(lastReason.label)} · ${esc(transferStatus(last, transfers))}` : ""}<br>${loanStats.total} prêt(s) connu(s) · ${loanStats.atHome} propriétaire · ${loanStats.outside} hors site</div>
            <button type="button" class="btn btn-default btn-xs dim-notice-open" data-open-item="${esc(itemId)}"><i class="fa-solid fa-route"></i> Voir</button>
        </div>`;
    }).join("");

    panel.innerHTML = `
      <div class="dim-notice-head">
        <div>
          <div class="dim-notice-title"><i class="fa-solid fa-route"></i> Mouvements de la notice</div>
          <div class="dim-notice-sub">Vue réseau synthétique de tous les exemplaires rattachés à cette notice.</div>
        </div>
      </div>
      <div class="dim-notice-body">
        <div class="dim-notice-kpis">
          <div class="dim-notice-kpi"><span>Exemplaires</span><strong>${data.byItem.size}</strong></div>
          <div class="dim-notice-kpi"><span>Transferts</span><strong>${data.transfers.length}</strong></div>
          <div class="dim-notice-kpi"><span>Sites mentionnés</span><strong>${allSites.size}</strong></div>
          <div class="dim-notice-kpi"><span>Dernier événement</span><strong>${esc(fmtDate(lastMove))}</strong></div>
          <div class="dim-notice-kpi"><span>Prêts connus</span><strong>${noticeLoanStats.total}</strong></div>
          <div class="dim-notice-kpi"><span>Prêts propriétaire</span><strong>${noticeLoanStats.atHome}</strong></div>
          <div class="dim-notice-kpi"><span>Prêts hors propriétaire</span><strong>${noticeLoanStats.outside}</strong></div>
          <div class="dim-notice-kpi"><span>Sites de prêt</span><strong>${noticeLoanStats.loanSites}</strong></div>
        </div>

        ${!transferReportId() ? `<div class="dim-error"><strong>Rapport transferts non configuré.</strong> Renseigne l’ID dans les réglages PMK de Mouvements des documents pour obtenir l’historique complet.</div>` : ""}

        <div class="dim-notice-list">${rows || '<div class="dim-empty">Aucun exemplaire.</div>'}</div>
      </div>`;

    panel.querySelectorAll("[data-open-item]").forEach((btn) => {
        btn.addEventListener("click", () => {
            const itemId = btn.dataset.openItem;
            const row = [...document.querySelectorAll("#holdings_table tbody tr")].find((tr) => getItemIdFromRow(tr) === itemId);
            if (!row) return;

            row.scrollIntoView({ behavior: "smooth", block: "center" });
            const itemBtn = row.querySelector(".dim-item-btn");
            if (itemBtn) itemBtn.click();
        });
    });
}

function getNoticePanelHost(table) {
    return document.querySelector("#holdings_panel .holdings_table_table_controls")
        || table.closest(".dt-container")
        || table.parentElement;
}

async function toggleNoticePanel(table, btn) {
    let panel = document.getElementById("dim-notice-panel");

    if (panel) {
        const opening = panel.hidden;
        panel.hidden = !opening;
        btn.classList.toggle("active", opening);
        btn.innerHTML = opening
            ? '<i class="fa-solid fa-route"></i> Masquer les mouvements'
            : '<i class="fa-solid fa-route"></i> Mouvements de la notice';

        if (opening) {
            window.setTimeout(() => {
                panel.scrollIntoView({ behavior: "smooth", block: "start" });
            }, 50);
        }
        return;
    }

    panel = document.createElement("section");
    panel.id = "dim-notice-panel";
    panel.className = "dim-notice-panel";
    panel.innerHTML = '<div class="dim-empty"><i class="fa fa-spinner fa-spin"></i> Chargement des mouvements de la notice…</div>';

    const host = getNoticePanelHost(table);
    host.insertAdjacentElement("afterend", panel);

    btn.classList.add("active");
    btn.innerHTML = '<i class="fa-solid fa-route"></i> Masquer les mouvements';

    try {
        const data = await loadData();
        renderNoticePanel(panel, data);

        window.setTimeout(() => {
            panel.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 80);
    } catch (error) {
        console.error("[Mouvements notice]", error);
        panel.innerHTML = `<div class="dim-error"><strong>Impossible de charger les mouvements de la notice.</strong><br>${esc(error.message || error)}</div>`;
    }
}

function injectNoticeButton(table) {
    if (document.getElementById("dim-notice-toolbar-btn")) return;

    const toolbar = document.querySelector("#toolbar");
    if (!toolbar) return;

    const group = document.createElement("div");
    group.className = "btn-group";

    const btn = document.createElement("button");
    btn.id = "dim-notice-toolbar-btn";
    btn.type = "button";
    btn.className = "btn btn-default dim-notice-btn";
    btn.innerHTML = '<i class="fa-solid fa-route"></i> Mouvements de la notice';
    btn.title = "Afficher les déplacements des exemplaires de cette notice";

    btn.addEventListener("click", (e) => {
        e.preventDefault();
        toggleNoticePanel(table, btn);
    });

    group.appendChild(btn);
    toolbar.appendChild(group);
}

function bindDataTableRedraw(table) {
    if (!(window.jQuery && window.jQuery.fn && window.jQuery.fn.dataTable)) return;

    window.jQuery(table)
        .off("draw.dt.dimMovements")
        .on("draw.dt.dimMovements", () => {
            window.setTimeout(() => injectItemButtons(table), 0);
        });
}

function init() {
    const table = document.querySelector("#holdings_table");
    if (!table) {
        console.warn("[Mouvements detail.pl] Tableau #holdings_table introuvable.");
        return;
    }

    injectNoticeButton(table);
    injectItemButtons(table);
    bindDataTableRedraw(table);

    console.info("[Mouvements detail.pl] Module intégré actif.");
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(init, 350), { once:true });
} else {
    setTimeout(init, 350);
}

})();


(() => {
"use strict";

/*
 * KOHA 25.11 — MOUVEMENTS DANS LES RÉSULTATS DE RECHERCHE
 * Page exacte :
 *   /cgi-bin/koha/catalogue/search.pl
 *
 * Principes de charge :
 * - ZÉRO requête Koha à l'initialisation.
 * - Requêtes uniquement après clic explicite sur "Mouvements".
 * - Une seule requête Koha à la fois.
 * - Pas de localStorage / sessionStorage / IndexedDB.
 * - Petit cache RAM LRU limité à 6 notices.
 * - cache:"no-store" pour les fetch.
 * - le cache disparaît dès que la page est quittée/rechargée.
 */

const PATH = window.location.pathname;
if (PATH !== "/cgi-bin/koha/catalogue/search.pl") return;
if (window.__dracSearchMovementsLoaded) return;
window.__dracSearchMovementsLoaded = true;

// Même rapport SQL que pour detail.pl.
function transferReportId(){return window.PMK130GetReportId();}

// Limite volontairement petite : impossible de grossir au fil des recherches.
const MAX_NOTICE_CACHE = 6;
const MIN_REQUEST_GAP = 300;

/* ============================================================
 * FILE DE REQUÊTES KOHA — STRICTEMENT SÉQUENTIELLE
 * ============================================================ */

function getKohaSerialQueue() {
    if (window.DracKohaSerialQueue) return window.DracKohaSerialQueue;

    let tail = Promise.resolve();
    let lastEnd = 0;

    const run = (task) => {
        const job = tail.catch(() => {}).then(async () => {
            const wait = Math.max(0, MIN_REQUEST_GAP - (Date.now() - lastEnd));
            if (wait) await new Promise((resolve) => setTimeout(resolve, wait));

            try {
                return await task();
            } finally {
                lastEnd = Date.now();
            }
        });

        tail = job.catch(() => {});
        return job;
    };

    window.DracKohaSerialQueue = {
        run,
        fetch: (url, options) => run(() => fetch(url, options)),
        get pending() { return tail; }
    };

    return window.DracKohaSerialQueue;
}

const KOHA_QUEUE = getKohaSerialQueue();

/* ============================================================
 * PETIT CACHE RAM LRU — AUCUNE PERSISTANCE
 * ============================================================ */

const noticeCache = new Map();
let librariesPromise = null;

function cacheGet(biblioId) {
    const key = String(biblioId);
    if (!noticeCache.has(key)) return null;

    const value = noticeCache.get(key);
    // touche LRU : on replace l'entrée en fin
    noticeCache.delete(key);
    noticeCache.set(key, value);
    return value;
}

function cacheSet(biblioId, value) {
    const key = String(biblioId);

    if (noticeCache.has(key)) noticeCache.delete(key);
    noticeCache.set(key, value);

    while (noticeCache.size > MAX_NOTICE_CACHE) {
        const oldestKey = noticeCache.keys().next().value;
        noticeCache.delete(oldestKey);
    }
}

window.addEventListener("pagehide", () => {
    noticeCache.clear();
    librariesPromise = null;
}, { once: true });

/* ============================================================
 * UTILITAIRES
 * ============================================================ */

const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (m) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[m]));

const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

function parseDate(value) {
    if (!value) return null;
    const raw = String(value).trim();
    if (!raw) return null;

    if (/^\d{2}\/\d{2}\/\d{4}/.test(raw)) {
        const [d, m, y] = raw.slice(0, 10).split("/").map(Number);
        const time = raw.match(/(\d{2}):(\d{2})/);
        return new Date(y, m - 1, d, time ? Number(time[1]) : 0, time ? Number(time[2]) : 0);
    }

    const d = new Date(raw.replace(" ", "T"));
    return Number.isNaN(d.getTime()) ? null : d;
}

function fmtDate(value) {
    const d = value instanceof Date ? value : parseDate(value);
    if (!d) return "—";

    return new Intl.DateTimeFormat("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    }).format(d);
}

function itemVal(obj, ...keys) {
    for (const key of keys) {
        if (obj?.[key] !== undefined && obj[key] !== null && obj[key] !== "") {
            return obj[key];
        }
    }
    return null;
}

function getBiblioIdFromResult(row) {
    const direct = row?.id?.match(/^row(\d+)$/)?.[1];
    if (direct) return direct;

    const cover = row?.querySelector("[data-biblionumber]");
    if (cover?.dataset?.biblionumber) return cover.dataset.biblionumber;

    const link = row?.querySelector('a[href*="/catalogue/detail.pl?biblionumber="]');
    if (link) {
        try {
            return new URL(link.getAttribute("href"), location.origin).searchParams.get("biblionumber");
        } catch (_) {}
    }

    return null;
}

function getItemInfo(itemNode) {
    return {
        itemId: String(itemNode?.dataset?.itemId || ""),
        barcode: clean(itemNode?.dataset?.barcode || itemNode?.querySelector(".kxri-barcode")?.textContent || "")
    };
}

function transferDate(t) {
    const values = [t.Arrive_le, t.datearrived, t.Envoye_le, t.datesent,
        t.Demande_le, t.daterequested, t.Annule_le, t.datecancelled];
    return values.filter(v => parseDate(v)).sort((a,b) => parseDate(b)-parseDate(a))[0] || "";
}

function getTransferState(t) {
    if (parseDate(t.Annule_le || t.datecancelled)) return "cancelled";
    if (parseDate(t.Arrive_le || t.datearrived)) return "arrived";
    if (parseDate(t.Envoye_le || t.datesent)) return "sent";
    if (parseDate(t.Demande_le || t.daterequested)) return "requested";
    return "unknown";
}
function transferStatus(t, transfers = []) {
    const state = getTransferState(t);
    if(state === "cancelled") return (t.Envoye_le || t.datesent) ? "Annulé après envoi" : "Annulé avant envoi";
    if(state === "arrived") return "Arrivé";
    if(state === "sent") return "En transit";
    if(state !== "requested") return "État non renseigné";
    const active = transfers.filter(x => ["requested","sent"].includes(getTransferState(x)));
    const sent = active.some(x => getTransferState(x) === "sent");
    const requests = active.filter(x => getTransferState(x) === "requested").sort((a,b) =>
        (parseDate(a.Demande_le || a.daterequested)?.getTime() || 0) - (parseDate(b.Demande_le || b.daterequested)?.getTime() || 0)
        || Number(a.Transfer_ID || a.transfer_id || 0)-Number(b.Transfer_ID || b.transfer_id || 0));
    return sent || (requests.length > 1 && requests[0] !== t) ? "Demandé · en file d’attente présumée" : "Demandé, non envoyé";
}

/* ============================================================
 * MOTIFS / SENS
 * ============================================================ */

const TRANSFER_REASON_LABELS = {
    Manual: ["Transfert manuel", "fa-hand"],
    StockrotationAdvance: ["Rotation de stock", "fa-rotate"],
    StockrotationRepatriation: ["Retour de rotation", "fa-rotate-left"],
    ReturnToHome: ["Retour au site de rattachement", "fa-house"],
    ReturnToHolding: ["Retour au site de détention", "fa-location-dot"],
    RotatingCollection: ["Collection tournante", "fa-arrows-rotate"],
    Reserve: ["Réservation", "fa-bookmark"],
    LostReserve: ["Réservation sur document perdu", "fa-triangle-exclamation"],
    CancelReserve: ["Suite à une annulation de réservation", "fa-bookmark"],
    TransferCancellation: ["Suite à une annulation de transfert", "fa-xmark"],
    Recall: ["Rappel", "fa-bell"],
    RecallCancellation: ["Suite à une annulation de rappel", "fa-bell-slash"],
    LibraryFloatLimit: ["Limite de flottement", "fa-water"]
};

const CANCELLATION_REASON_LABELS = {
    Manual: ["Annulation manuelle", "fa-hand"],
    StockrotationAdvance: ["Rotation de stock", "fa-rotate"],
    StockrotationRepatriation: ["Retour de rotation", "fa-rotate-left"],
    ReturnToHome: ["Retour au rattachement", "fa-house"],
    ReturnToHolding: ["Retour à la détention", "fa-location-dot"],
    RotatingCollection: ["Collection tournante", "fa-arrows-rotate"],
    Reserve: ["Réservation", "fa-bookmark"],
    LostReserve: ["Réservation sur document perdu", "fa-triangle-exclamation"],
    CancelReserve: ["Réservation annulée", "fa-bookmark"],
    ItemLost: ["Document perdu", "fa-triangle-exclamation"],
    WrongTransfer: ["Mauvais transfert", "fa-shuffle"],
    RecallCancellation: ["Rappel annulé", "fa-bell-slash"]
};

function reasonInfo(t) {
    const raw = String(t.Raison || t.reason || "").trim();
    const entry = TRANSFER_REASON_LABELS[raw];
    let label = entry ? entry[0] : (raw ? "Motif inconnu : " + raw : "Motif non renseigné");
    const cancelled = getTransferState(t) === "cancelled";
    const cancel = String(t.Raison_annulation || t.cancellation_reason || "").trim();
    if(cancelled) label += " · Annulation : " + (CANCELLATION_REASON_LABELS[cancel]?.[0] || cancel || "motif non renseigné");
    const from = t.From_Site || t.frombranch, to = t.To_Site || t.tobranch;
    if(!from || !to) label += " · Trajet incomplet";
    else if(from === to) label += " · Origine et destination identiques";
    const comment = String(t.Commentaire || t.comments || "").trim();
    if(comment) label += " · Commentaire : " + comment;
    return {raw: raw + (cancelled ? " / annulation : " + (cancel || "non renseigné") : ""),
        label, icon:entry?.[1] || "fa-circle-question", known:!!entry};
}

function movementDirection(homeCode, fromCode, toCode, cancelled = false) {
    const home = String(homeCode || "");
    const from = String(fromCode || "");
    const to = String(toCode || "");

    if (home && from === home && to && to !== home) {
        return {
            kind: cancelled ? "cancelled" : "out",
            arrow: "==>",
            semantic: "Départ du site de rattachement"
        };
    }

    if (home && to === home && from && from !== home) {
        return {
            kind: cancelled ? "cancelled" : "home",
            arrow: "<==",
            semantic: "Retour vers le site de rattachement"
        };
    }

    return {
        kind: cancelled ? "cancelled" : "network",
        arrow: "==>",
        semantic: "Déplacement entre sites du réseau"
    };
}

function routeVisual(homeCode, t, libs) {
    const fromCode = String(t.From_Site ?? t.frombranch ?? "");
    const toCode = String(t.To_Site ?? t.tobranch ?? "");

    const from = libs.get(fromCode) || fromCode || "?";
    const to = libs.get(toCode) || toCode || "?";
    const cancelled = Boolean(t.Annule_le || t.datecancelled);
    const dir = movementDirection(homeCode, fromCode, toCode, cancelled);

    if (homeCode && toCode === String(homeCode) && fromCode !== String(homeCode)) {
        const homeName = libs.get(String(homeCode)) || String(homeCode);

        return {
            ...dir,
            left: homeName,
            right: from,
            real: `${from} → ${homeName}`
        };
    }

    return {
        ...dir,
        left: from,
        right: to,
        real: `${from} → ${to}`
    };
}


function checkoutSiteCode(checkout) {
    return String(
        checkout?.library_id ??
        checkout?.checkout_library_id ??
        checkout?.branchcode ??
        ""
    );
}

function checkoutItemId(checkout) {
    return String(
        checkout?.item_id ??
        checkout?.itemnumber ??
        ""
    );
}

function buildLoanStatsForItem(item, checkouts, libs) {
    const homeCode = String(itemVal(item, "home_library_id", "homebranch") || "");
    const itemId = String(itemVal(item, "item_id", "itemnumber") || "");

    const relevant = (checkouts || []).filter((c) => checkoutItemId(c) === itemId);
    const bySite = new Map();

    relevant.forEach((checkout) => {
        const code = checkoutSiteCode(checkout);
        if (!code) return;
        bySite.set(code, (bySite.get(code) || 0) + 1);
    });

    const total = Array.from(bySite.values()).reduce((sum, n) => sum + n, 0);
    const atHome = homeCode ? (bySite.get(homeCode) || 0) : 0;
    const outside = Math.max(0, total - atHome);

    const sites = [...bySite.entries()]
        .map(([code, count]) => ({
            code,
            name: libs.get(code) || code,
            count,
            isHome: Boolean(homeCode && code === homeCode),
            pct: total ? Math.round((count / total) * 100) : 0
        }))
        .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "fr"));

    return { total, atHome, outside, sites, homeCode };
}

function buildNoticeLoanStats(byItem, checkouts, libs) {
    let total = 0;
    let atHome = 0;
    let outside = 0;
    const loanSites = new Set();

    byItem.forEach((record) => {
        const stats = buildLoanStatsForItem(record.item || {}, checkouts, libs);
        total += stats.total;
        atHome += stats.atHome;
        outside += stats.outside;
        stats.sites.forEach((s) => loanSites.add(s.code));
    });

    return { total, atHome, outside, loanSites: loanSites.size };
}

function loanSitesHtml(stats) {
    if (!stats || !stats.total) {
        return '<div class="kxmv-loan-empty">Aucun lieu de prêt historique exploitable.</div>';
    }

    return `<div class="kxmv-loan-sites">
        ${stats.sites.map((site) => `
            <div class="kxmv-loan-site ${site.isHome ? "is-home" : "is-away"}">
                <div class="kxmv-loan-site-top">
                    <span class="kxmv-loan-site-name">${site.isHome ? '<i class="fa-solid fa-house"></i> ' : '<i class="fa-solid fa-building"></i> '}${esc(site.name)}</span>
                    <strong>${site.count}</strong>
                </div>
                <div class="kxmv-loan-bar"><span style="width:${Math.max(3, site.pct)}%"></span></div>
                <div class="kxmv-loan-site-foot">${site.pct}% ${site.isHome ? "· site propriétaire" : "· hors site propriétaire"}</div>
            </div>
        `).join("")}
    </div>`;
}


/* ============================================================
 * API / RAPPORT — UNIQUEMENT APRÈS CLIC
 * ============================================================ */

async function getJson(url) {
    const response = await KOHA_QUEUE.fetch(url, {
        credentials: "same-origin",
        cache: "no-store",
        headers: { Accept: "application/json" }
    });

    if (!response.ok) {
        const error = new Error(`Koha HTTP ${response.status}`);
        error.status = response.status;
        throw error;
    }

    return {
        data: await response.json(),
        response
    };
}

async function getPaged(url, perPage = 100) {
    const all = [];
    let page = 1;

    while (page <= 100) {
        const u = new URL(url, location.origin);
        u.searchParams.set("_page", String(page));
        u.searchParams.set("_per_page", String(perPage));

        const { data, response } = await getJson(u.toString());

        if (!Array.isArray(data)) break;
        all.push(...data);

        const total = Number(response.headers.get("X-Total-Count") || 0);

        if ((total && all.length >= total) || data.length < perPage) break;

        page += 1;
    }

    return all;
}

async function loadLibraries() {
    if (librariesPromise) return librariesPromise;

    librariesPromise = (async () => {
        try {
            const { data } = await getJson("/api/v1/public/libraries");
            const map = new Map();

            (Array.isArray(data) ? data : []).forEach((library) => {
                map.set(String(library.library_id), library.name || library.library_id);
            });

            return map;
        } catch (_) {
            return new Map();
        }
    })();

    return librariesPromise;
}

async function loadTransfers(biblioId) {
    await window.PMK130ConfigReady;
    const reportId=transferReportId();
    if (!reportId) return [];

    const all = [];
    let cursor = 0;
    let lots = 0;
    const maxBatches=window.PMK130GetSettings?.().maxTransferBatches || 20;

    while (lots < maxBatches) {
        lots += 1;

        const u = new URL("/cgi-bin/koha/svc/report", location.origin);
        u.searchParams.set("id", String(reportId));
        u.searchParams.set("annotated", "1");
        u.searchParams.append("param_names", "Biblionumber");
        u.searchParams.append("sql_params", String(biblioId));
        u.searchParams.append("param_names", "Après ID");
        u.searchParams.append("sql_params", String(cursor));

        const { data } = await getJson(u.toString());

        if (!Array.isArray(data) || !data.length) break;
        const contract=window.PMK130ValidateReportRows?.(data);
        if(contract && !contract.ok)throw new Error("Rapport mouvements incompatible — colonnes manquantes : "+contract.missing.join(", "));

        all.push(...data);

        const last = Number(
            data[data.length - 1].Transfer_ID ??
            data[data.length - 1].transfer_id ??
            0
        );

        if (!Number.isFinite(last) || last <= cursor) break;

        cursor = last;

        if (data.length < 500) break;
    }

    return all;
}

async function loadNoticeData(biblioId) {
    const cached = cacheGet(biblioId);
    if (cached) return cached;

    // Important : cette fonction n'est appelée QUE depuis un gestionnaire de clic.
    const libs = await loadLibraries();
    const items = await getPaged(
        `/api/v1/public/biblios/${encodeURIComponent(biblioId)}/items`,
        100
    );
    const transfers = await loadTransfers(biblioId);
    const checkouts = await getPaged(
        `/api/v1/biblios/${encodeURIComponent(biblioId)}/checkouts?checked_in=true`,
        100
    );

    const byItem = new Map();

    items.forEach((item) => {
        const id = String(itemVal(item, "item_id", "itemnumber") || "");
        if (!id) return;

        byItem.set(id, {
            item,
            transfers: []
        });
    });

    transfers.forEach((transfer) => {
        const id = String(
            transfer.Item_ID ??
            transfer.item_id ??
            transfer.itemnumber ??
            ""
        );

        if (!id) return;

        if (!byItem.has(id)) {
            byItem.set(id, {
                item: null,
                transfers: []
            });
        }

        byItem.get(id).transfers.push(transfer);
    });

    const data = {
        biblioId: String(biblioId),
        libs,
        items,
        transfers,
        checkouts,
        byItem
    };

    cacheSet(biblioId, data);
    return data;
}

/* ============================================================
 * STYLE COMPACT
 * ============================================================ */

const style = document.createElement("style");
style.textContent = `
.kxmv-notice-btn {
    display:inline-flex;
    align-items:center;
    gap:4px;
    margin-left:6px;
    padding:3px 7px;
    border:1px solid #c7d5bc;
    border-radius:6px;
    background:#f7fbf4;
    color:#526d22;
    font-size:11px;
    font-weight:700;
    cursor:pointer;
}
.kxmv-item-btn,
.kxmv-notice-item-detail-btn,
.kxmv-history-link {
    display:inline-flex;
    align-items:center;
    gap:3px;
}
.kxmv-panel {
    margin-top:8px;
    padding:8px 9px;
    border:1px solid #dfe6ea;
    border-left:3px solid #6f8f32;
    border-radius:7px;
    background:#fbfcfa;
}
.kxmv-notice-summary {
    display:flex;
    flex-wrap:wrap;
    gap:6px;
    margin-bottom:7px;
}
.kxmv-chip {
    padding:3px 7px;
    border:1px solid #dfe5e9;
    border-radius:999px;
    background:#fff;
    color:#596872;
    font-size:10px;
}
.kxmv-chip strong {
    color:#34444e;
}
.kxmv-items {
    display:grid;
    gap:5px;
}
.kxmv-notice-item {
    display:grid;
    grid-template-columns:minmax(110px,.7fr) 1fr auto;
    gap:7px;
    align-items:center;
    padding:5px 7px;
    border:1px solid #e4e9ec;
    border-radius:6px;
    background:#fff;
    font-size:10px;
}
.kxmv-code {
    font-weight:800;
    color:#34444e;
}
.kxmv-route {
    color:#566875;
}
.kxmv-route strong {
    color:#4b78a0;
}
.kxmv-small-btn {
    border:1px solid #cbd6dd;
    border-radius:5px;
    background:#f7f9fa;
    color:#455d6d;
    padding:2px 6px;
    font-size:10px;
    cursor:pointer;
}
.kxmv-item-panel {
    margin:6px 0 0;
    padding:7px 8px;
    border-top:1px solid #dfe5e8;
    background:#fafcf8;
}
.kxmv-item-head {
    display:flex;
    flex-wrap:wrap;
    align-items:center;
    gap:6px;
    margin-bottom:6px;
}
.kxmv-item-head strong {
    color:#34444e;
}
.kxmv-steps {
    display:flex;
    flex-wrap:wrap;
    gap:5px 6px;
}
.kxmv-step {
    display:inline-flex;
    flex-wrap:wrap;
    align-items:center;
    gap:4px;
    padding:3px 6px;
    border:1px solid #dfe5e9;
    border-radius:6px;
    background:#fff;
    font-size:10px;
}
.kxmv-direction {
    font-weight:800;
}
.kxmv-direction.is-out {
    color:#356b91;
}
.kxmv-direction.is-home {
    color:#55752d;
}
.kxmv-direction.is-network {
    color:#6b5686;
}
.kxmv-direction.is-cancelled {
    color:#9c453f;
    text-decoration:line-through;
}
.kxmv-reason {
    color:#6b7780;
}
.kxmv-loading,
.kxmv-error,
.kxmv-empty {
    padding:6px 4px;
    color:#6c7881;
    font-size:10px;
}
.kxmv-error {
    color:#98433c;
}

/* Version enrichie des mouvements en résultats */
.kxmv-panel {
    padding: 10px 11px;
}
.kxmv-notice-summary {
    display: grid;
    grid-template-columns: repeat(4, minmax(105px,1fr));
    gap: 7px;
}
.kxmv-summary-card {
    padding: 7px 8px;
    border: 1px solid #e0e6e9;
    border-radius: 7px;
    background: #fff;
}
.kxmv-summary-card span {
    display:block;
    color:#7a8790;
    font-size:9px;
    font-weight:800;
    text-transform:uppercase;
}
.kxmv-summary-card strong {
    display:block;
    margin-top:3px;
    color:#35444e;
    font-size:14px;
}
.kxmv-notice-item {
    grid-template-columns: minmax(125px,.65fr) minmax(160px,1fr) minmax(170px,1.1fr) auto;
}
.kxmv-notice-item-detail {
    grid-column: 1 / -1;
    padding: 8px 9px;
    margin-top: 3px;
    border-top: 1px solid #e3e8eb;
    background: #fafcf8;
}
.kxmv-section-title {
    display:flex;
    align-items:center;
    gap:5px;
    margin:7px 0 5px;
    color:#43545f;
    font-size:10px;
    font-weight:800;
}
.kxmv-loan-kpis {
    display:grid;
    grid-template-columns:repeat(4,minmax(90px,1fr));
    gap:5px;
    margin:6px 0;
}
.kxmv-loan-kpi {
    padding:5px 6px;
    border:1px solid #e2e7ea;
    border-radius:6px;
    background:#fff;
}
.kxmv-loan-kpi span {
    display:block;
    color:#7a8790;
    font-size:8px;
    font-weight:800;
    text-transform:uppercase;
}
.kxmv-loan-kpi strong {
    display:block;
    margin-top:2px;
    color:#35444e;
    font-size:12px;
}
.kxmv-loan-sites {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(145px,1fr));
    gap:5px;
}
.kxmv-loan-site {
    padding:5px 6px;
    border:1px solid #dfe5e9;
    border-radius:6px;
    background:#fff;
    font-size:9px;
}
.kxmv-loan-site.is-home {
    background:#f7fbf4;
    border-color:#cfdfc1;
}
.kxmv-loan-site.is-away {
    background:#f8fafc;
    border-color:#d5e0e8;
}
.kxmv-loan-site-top {
    display:flex;
    justify-content:space-between;
    gap:5px;
    align-items:center;
}
.kxmv-loan-site-name {
    font-weight:700;
    color:#455660;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.kxmv-loan-bar {
    height:3px;
    margin-top:4px;
    border-radius:4px;
    background:#e9eef1;
    overflow:hidden;
}
.kxmv-loan-bar span {
    display:block;
    height:100%;
    background:#6f8f32;
}
.kxmv-loan-site.is-away .kxmv-loan-bar span {
    background:#4b78a0;
}
.kxmv-loan-site-foot {
    margin-top:2px;
    color:#7a858d;
    font-size:8px;
}
@media(max-width:1000px) {
    .kxmv-notice-summary,
    .kxmv-loan-kpis {
        grid-template-columns:repeat(2,minmax(90px,1fr));
    }
    .kxmv-notice-item {
        grid-template-columns:1fr;
    }
}

@media(max-width:850px) {
    .kxmv-notice-item {
        grid-template-columns:1fr;
    }
}
`;
document.head.appendChild(style);

/* ============================================================
 * RENDU EXEMPLAIRE
 * ============================================================ */

function latestTransfer(transfers) {
    return [...transfers].sort((a,b) => {
        const da = parseDate(transferDate(a))?.getTime() || 0;
        const db = parseDate(transferDate(b))?.getTime() || 0;
        return db - da;
    })[0] || null;
}

function renderItemPanel(panel, record, itemNode, data) {
    const item = record?.item || {};
    const transfers = record?.transfers || [];

    const homeCode = String(
        itemVal(item, "home_library_id", "homebranch") || ""
    );

    const holdingCode = String(
        itemVal(item, "holding_library_id", "holdingbranch") || ""
    );

    const info = getItemInfo(itemNode);

    const home = data.libs.get(homeCode) || homeCode || "—";
    const holding = data.libs.get(holdingCode) || holdingCode || "—";
    const loanStats = buildLoanStatsForItem(item, data.checkouts || [], data.libs);

    const steps = [...transfers]
        .sort((a,b) => {
            const da = parseDate(transferDate(a))?.getTime() || 0;
            const db = parseDate(transferDate(b))?.getTime() || 0;
            return da - db;
        })
        .map((t) => {
            const route = routeVisual(homeCode, t, data.libs);
            const reason = reasonInfo(t);
            const state = getTransferState(t);
            const status = transferStatus(t, transfers);

            return `<span class="kxmv-step">
                <span>${esc(fmtDate(transferDate(t)))}</span>
                <span class="kxmv-direction is-${esc(route.kind)}" title="${esc(route.semantic)} · trajet enregistré : ${esc(route.real)}">${esc(route.left)} ${esc(route.arrow)} ${esc(route.right)}</span>
                <span class="kxmv-reason"><i class="fa-solid ${esc(reason.icon)}"></i> ${esc(reason.label)} · ${esc(status)}</span>
            </span>`;
        })
        .join("");

    panel.innerHTML = `
        <div class="kxmv-item-head">
            <strong><i class="fa-solid fa-route"></i> ${esc(info.barcode || "Exemplaire")}</strong>
            <span class="kxmv-chip">Rattachement <strong>${esc(home)}</strong></span>
            <span class="kxmv-chip">Détenteur enregistré <strong>${esc(holding)}</strong></span>
            <span class="kxmv-chip">Transferts <strong>${transfers.length}</strong></span>
        </div>
        <div class="kxmv-section-title"><i class="fa-solid fa-route"></i> Parcours des transferts</div>
        <div class="kxmv-steps">
            ${steps || '<span class="kxmv-empty">Aucun transfert historique enregistré.</span>'}
        </div>

        <div class="kxmv-section-title"><i class="fa-solid fa-building-columns"></i> Lieux de prêt par rapport au site propriétaire</div>
        <div class="kxmv-loan-kpis">
            <div class="kxmv-loan-kpi"><span>Prêts connus</span><strong>${loanStats.total}</strong></div>
            <div class="kxmv-loan-kpi"><span>Propriétaire</span><strong>${loanStats.atHome}</strong></div>
            <div class="kxmv-loan-kpi"><span>Hors site</span><strong>${loanStats.outside}</strong></div>
            <div class="kxmv-loan-kpi"><span>Sites de prêt</span><strong>${loanStats.sites.length}</strong></div>
        </div>
        ${loanSitesHtml(loanStats)}
    `;
}

/* ============================================================
 * RENDU NOTICE
 * ============================================================ */

function renderNoticePanel(panel, data) {
    const sites = new Set();
    let lastMove = null;

    data.byItem.forEach((record) => {
        const item = record.item || {};

        const home = itemVal(item, "home_library_id", "homebranch");
        const holding = itemVal(item, "holding_library_id", "holdingbranch");

        if (home) sites.add(String(home));
        if (holding) sites.add(String(holding));

        record.transfers.forEach((t) => {
            const from = t.From_Site ?? t.frombranch;
            const to = t.To_Site ?? t.tobranch;

            if (from) sites.add(String(from));
            if (to) sites.add(String(to));

            const d = parseDate(transferDate(t));
            if (d && (!lastMove || d > lastMove)) lastMove = d;
        });
    });

    const noticeLoanStats = buildNoticeLoanStats(data.byItem, data.checkouts || [], data.libs);

    const itemsHtml = [...data.byItem.entries()].map(([itemId, record]) => {
        const item = record.item || {};
        const transfers = record.transfers || [];

        const barcode =
            itemVal(item, "external_id", "barcode") ||
            `Exemplaire ${itemId}`;

        const homeCode = String(
            itemVal(item, "home_library_id", "homebranch") || ""
        );

        const holdingCode = String(
            itemVal(item, "holding_library_id", "holdingbranch") || ""
        );

        const home = data.libs.get(homeCode) || homeCode || "—";
        const holding = data.libs.get(holdingCode) || holdingCode || "—";

        const last = latestTransfer(transfers);
        const loanStats = buildLoanStatsForItem(item, data.checkouts || [], data.libs);
        const lastVisual = last ? routeVisual(homeCode, last, data.libs) : null;
        const lastReason = last ? reasonInfo(last) : null;

        return `<div class="kxmv-notice-item" data-kxmv-notice-item="${esc(itemId)}">
            <div class="kxmv-code">${esc(barcode)}</div>
            <div class="kxmv-route">
                <strong>${esc(home)}</strong> → ${esc(holding)}<br>
                ${transfers.length} transfert(s)
                ${lastVisual ? ` · ${esc(lastVisual.left)} ${esc(lastVisual.arrow)} ${esc(lastVisual.right)}` : ""}
            </div>
            <div class="kxmv-route">
                ${loanStats.total} prêt(s) connu(s) · ${loanStats.atHome} propriétaire · ${loanStats.outside} hors site
                ${lastReason ? `<br>${esc(lastReason.label)} · ${esc(transferStatus(last, transfers))}` : ""}
            </div>
            <button type="button" class="kxmv-small-btn" data-kxmv-open-item="${esc(itemId)}">Voir le détail</button>
            <div class="kxmv-notice-item-detail" data-kxmv-inline-detail="${esc(itemId)}" hidden></div>
        </div>`;
    }).join("");

    panel.innerHTML = `
        <div class="kxmv-notice-summary">
            <div class="kxmv-summary-card"><span>Exemplaires</span><strong>${data.byItem.size}</strong></div>
            <div class="kxmv-summary-card"><span>Transferts</span><strong>${data.transfers.length}</strong></div>
            <div class="kxmv-summary-card"><span>Sites mentionnés</span><strong>${sites.size}</strong></div>
            <div class="kxmv-summary-card"><span>Dernier événement</span><strong>${esc(fmtDate(lastMove))}</strong></div>
            <div class="kxmv-summary-card"><span>Prêts connus</span><strong>${noticeLoanStats.total}</strong></div>
            <div class="kxmv-summary-card"><span>Prêts propriétaire</span><strong>${noticeLoanStats.atHome}</strong></div>
            <div class="kxmv-summary-card"><span>Prêts hors propriétaire</span><strong>${noticeLoanStats.outside}</strong></div>
            <div class="kxmv-summary-card"><span>Sites de prêt</span><strong>${noticeLoanStats.loanSites}</strong></div>
        </div>

        ${!transferReportId() ? '<div class="kxmv-error">Rapport transferts non configuré : renseigner son ID dans les réglages PMK de Mouvements des documents.</div>' : ""}

        <div class="kxmv-items">
            ${itemsHtml || '<div class="kxmv-empty">Aucun exemplaire.</div>'}
        </div>
    `;
}

/* ============================================================
 * OUVERTURE — TOUJOURS SUR CLIC
 * ============================================================ */

async function toggleItemMovements(itemNode, resultRow) {
    let panel = itemNode.querySelector(":scope > .kxmv-item-panel");

    if (panel) {
        panel.hidden = !panel.hidden;
        return;
    }

    const { itemId } = getItemInfo(itemNode);
    const biblioId = getBiblioIdFromResult(resultRow);

    if (!itemId || !biblioId) return;

    panel = document.createElement("div");
    panel.className = "kxmv-item-panel";
    panel.innerHTML = '<div class="kxmv-loading"><i class="fa fa-spinner fa-spin"></i> Chargement…</div>';
    itemNode.appendChild(panel);

    try {
        const data = await loadNoticeData(biblioId);
        const record = data.byItem.get(String(itemId));
        renderItemPanel(panel, record, itemNode, data);
    } catch (error) {
        console.error("[Mouvements recherche / exemplaire]", error);
        panel.innerHTML = `<div class="kxmv-error">Impossible de charger les mouvements : ${esc(error.message || error)}</div>`;
    }
}

function setNoticeInlineItemOpen(panel, resultRow, itemId, open) {
    if (!panel || !itemId) return null;

    itemId = String(itemId);

    const openBtn =
        panel.querySelector(
            `[data-kxmv-open-item="${CSS.escape(itemId)}"]`
        );

    const holder =
        panel.querySelector(
            `[data-kxmv-inline-detail="${CSS.escape(itemId)}"]`
        );

    if (!holder) return null;

    holder.hidden = !open;

    if (openBtn) {
        openBtn.textContent =
            open
                ? "Masquer le détail"
                : "Voir le détail";
    }

    if (
        open
        &&
        holder.dataset.rendered !== "1"
    ) {
        const data = panel._kxmvData;
        if (!data) return holder;

        const itemNode =
            resultRow.querySelector(
                `.kxri-item[data-item-id="${CSS.escape(itemId)}"]`
            );

        const record =
            data.byItem.get(
                String(itemId)
            );

        const fakeNode =
            itemNode ||
            document.createElement("div");

        if (!itemNode) {
            fakeNode.dataset.itemId =
                itemId;

            fakeNode.dataset.barcode =
                itemVal(
                    record?.item || {},
                    "external_id",
                    "barcode"
                ) || "";
        }

        renderItemPanel(
            holder,
            record,
            fakeNode,
            data
        );

        holder.dataset.rendered =
            "1";
    }

    return holder;
}


function installNoticeInlineItemHandlers(
    panel,
    resultRow
) {
    panel
        .querySelectorAll(
            "[data-kxmv-open-item]"
        )
        .forEach(
            openBtn => {

                if (
                    openBtn.dataset
                        .kxmvInlineBound ===
                    "1"
                ) {
                    return;
                }

                openBtn.dataset
                    .kxmvInlineBound =
                    "1";

                openBtn.addEventListener(
                    "click",
                    () => {

                        const itemId =
                            openBtn.dataset
                                .kxmvOpenItem;

                        const holder =
                            panel.querySelector(
                                `[data-kxmv-inline-detail="${CSS.escape(itemId)}"]`
                            );

                        if (!holder) {
                            return;
                        }

                        setNoticeInlineItemOpen(
                            panel,
                            resultRow,
                            itemId,
                            holder.hidden
                        );
                    }
                );
            }
        );
}


async function toggleNoticeMovements(
    resultRow,
    button
) {
    const biblioId =
        getBiblioIdFromResult(
            resultRow
        );

    if (!biblioId) return;

    const targetCell =
        resultRow.querySelector(
            ".kx-notice-cell"
        )
        ||
        resultRow.cells?.[2]
        ||
        resultRow;

    let panel =
        targetCell.querySelector(
            ":scope > .kxmv-panel"
        );

    if (panel) {
        panel.hidden =
            !panel.hidden;

        button?.classList.toggle(
            "is-open",
            !panel.hidden
        );

        return;
    }

    panel =
        document.createElement(
            "div"
        );

    panel.className =
        "kxmv-panel";

    panel.innerHTML =
        '<div class="kxmv-loading"><i class="fa fa-spinner fa-spin"></i> Chargement…</div>';

    targetCell.appendChild(
        panel
    );

    button?.classList.add(
        "is-open"
    );

    panel._kxmvLoadPromise =
        (async () => {

            try {
                const data =
                    await loadNoticeData(
                        biblioId
                    );

                panel._kxmvData =
                    data;

                renderNoticePanel(
                    panel,
                    data
                );

                installNoticeInlineItemHandlers(
                    panel,
                    resultRow
                );
            }
            catch (error) {
                console.error(
                    "[Mouvements recherche / notice]",
                    error
                );

                panel.innerHTML =
                    `<div class="kxmv-error">Impossible de charger les mouvements : ${esc(error.message || error)}</div>`;
            }
        })();

    try {
        await panel._kxmvLoadPromise;
    }
    finally {
        panel._kxmvLoadPromise =
            null;
    }
}


/*
 * Ouvre directement, dans la colonne notice,
 * le détail Mouvements d'un exemplaire précis.
 *
 * Equivalent fonctionnel à :
 *   1. clic sur "Mouvements" de la notice ;
 *   2. clic sur "Voir le détail" de cet exemplaire.
 *
 * Aucun scroll forcé et aucun appel Koha supplémentaire :
 * on réutilise loadNoticeData() et son cache RAM borné.
 */
async function openNoticeMovementItemDetail(
    resultRow,
    itemId
) {
    if (!resultRow || !itemId) {
        return;
    }

    itemId =
        String(itemId);

    const noticeBtn =
        resultRow.querySelector(
            ".kxmv-notice-btn"
        );

    const targetCell =
        resultRow.querySelector(
            ".kx-notice-cell"
        )
        ||
        resultRow.cells?.[2]
        ||
        resultRow;

    let panel =
        targetCell.querySelector(
            ":scope > .kxmv-panel"
        );

    if (!panel) {
        await toggleNoticeMovements(
            resultRow,
            noticeBtn
        );

        panel =
            targetCell.querySelector(
                ":scope > .kxmv-panel"
            );
    }
    else {
        /*
         * Le bouton direct ne doit jamais refermer
         * le panneau notice déjà ouvert.
         */
        panel.hidden =
            false;

        noticeBtn?.classList.add(
            "is-open"
        );

        if (
            panel._kxmvLoadPromise
        ) {
            await panel._kxmvLoadPromise;
        }
    }

    if (!panel) {
        return;
    }

    if (
        panel._kxmvLoadPromise
    ) {
        await panel._kxmvLoadPromise;
    }

    setNoticeInlineItemOpen(
        panel,
        resultRow,
        itemId,
        true
    );
}

/* ============================================================
 * INJECTION DES BOUTONS — AUCUN APPEL KOHA ICI
 * ============================================================ */

function injectResult(resultRow) {
    if (!resultRow || resultRow.dataset.kxmvReady === "1") return;

    const biblioId = getBiblioIdFromResult(resultRow);
    if (!biblioId) return;

    // Bouton notice
    const noticeTools =
        resultRow.querySelector(".kx-notice-head-tools") ||
        resultRow.querySelector(".hold");

    if (noticeTools && !noticeTools.querySelector(".kxmv-notice-btn")) {
        const noticeBtn = document.createElement("button");
        noticeBtn.type = "button";
        noticeBtn.className = "kxmv-notice-btn";
        noticeBtn.innerHTML = '<i class="fa-solid fa-route"></i> Mouvements';
        noticeBtn.title = "Afficher les mouvements des exemplaires de cette notice";

        noticeBtn.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            toggleNoticeMovements(resultRow, noticeBtn);
        });

        noticeTools.appendChild(noticeBtn);
    }

    // Boutons exemplaires
    resultRow.querySelectorAll(".kxri-item[data-item-id]").forEach((itemNode) => {
        if (itemNode.dataset.kxmvReady === "1") return;

        const actions = itemNode.querySelector(".kxri-actions");
        if (!actions) return;

        const info = getItemInfo(itemNode);

        if (!actions.querySelector(".kxmv-item-btn")) {
            const moveBtn = document.createElement("button");
            moveBtn.type = "button";
            moveBtn.className = "kxri-action kxmv-item-btn";
            moveBtn.innerHTML = '<i class="fa-solid fa-route"></i> Mouvements';
            moveBtn.title = "Afficher les mouvements de cet exemplaire";

            moveBtn.addEventListener("click", (event) => {
                event.preventDefault();
                event.stopPropagation();
                toggleItemMovements(itemNode, resultRow);
            });

            actions.appendChild(moveBtn);
        }

        if (
            !actions.querySelector(
                ".kxmv-notice-item-detail-btn"
            )
        ) {
            const noticeDetailBtn =
                document.createElement(
                    "button"
                );

            noticeDetailBtn.type =
                "button";

            noticeDetailBtn.className =
                "kxri-action kxmv-notice-item-detail-btn";

            noticeDetailBtn.innerHTML =
                '<i class="fa-solid fa-eye"></i> Voir dans mouvements';

            noticeDetailBtn.title =
                "Ouvrir directement cet exemplaire dans Mouvements de la notice";

            noticeDetailBtn.addEventListener(
                "click",
                async event => {

                    event.preventDefault();
                    event.stopPropagation();

                    try {
                        await openNoticeMovementItemDetail(
                            resultRow,
                            info.itemId
                        );
                    }
                    catch (error) {
                        console.error(
                            "[Mouvements recherche / accès direct exemplaire]",
                            error
                        );
                    }
                }
            );

            actions.appendChild(
                noticeDetailBtn
            );
        }


        if (
            info.barcode &&
            !actions.querySelector(".kxmv-history-link")
        ) {
            const history = document.createElement("a");
            history.className = "kxri-action kxmv-history-link";
            history.innerHTML = '<i class="fa-solid fa-clock-rotate-left"></i> Historique';
            history.title = "Historique de prêt préfiltré sur cet exemplaire";

            const u = new URL("/cgi-bin/koha/catalogue/issuehistory.pl", location.origin);
            u.searchParams.set("biblionumber", biblioId);
            u.searchParams.set("krt_barcode", info.barcode);
            u.searchParams.set("krt_itemnumber", info.itemId);
            u.hash = "krt-biblio-timeline";

            history.href = u.toString();
            actions.appendChild(history);
        }

        itemNode.dataset.kxmvReady = "1";
    });

    resultRow.dataset.kxmvReady = "1";
}

function scanVisibleResults() {
    document.querySelectorAll('tr[id^="row"]').forEach(injectResult);
}

function init() {
    // IMPORTANT : seulement injection DOM, aucune donnée Koha chargée.
    scanVisibleResults();

    // Les scripts existants peuvent reconstruire les cartes de résultats.
    // MutationObserver = uniquement DOM local, aucune requête Koha.
    const tbody = document.querySelector("table tbody");
    if (tbody) {
        const observer = new MutationObserver(() => {
            window.requestAnimationFrame(scanVisibleResults);
        });

        observer.observe(tbody, {
            childList: true,
            subtree: true
        });
    }

    console.info(
        `[Mouvements recherche] Module prêt. 0 requête au chargement. Cache RAM limité à ${MAX_NOTICE_CACHE} notices.`
    );
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
} else {
    init();
}

})();


;window.PMKNonPlugin.loaded.push("130-mouvements-documents.js");
} catch (error) { window.PMKNonPlugin.errors.push("130-mouvements-documents.js: "+error.message); console.error("[PMK] 130-mouvements-documents.js",error); };
try {
/* ============================================================
   132-suggestions.js
   PimpMyKoha — Lecteur obligatoire pour une suggestion d'achat
   Version : 2.1.0-universal

   Correction 2.0.1 :
   - suppression de la boucle infinie MutationObserver ;
   - l'observer ne sert plus qu'à attendre l'apparition du formulaire ;
   - updateState() est désormais idempotent ;
   - l'avertissement n'est plus supprimé/recréé à chaque contrôle ;
   - contrôle lors du retour de focus après sélection d'un lecteur ;
   - conservation du blocage au submit.
   ============================================================ */

(function (window, document) {
    "use strict";

    if (!window || !document) return;

    if (window.__PMK132SuggestionSuggester) return;
    window.__PMK132SuggestionSuggester = true;

    const MODULE_ID = "suggestion-required-suggester";
    const MODULE_VERSION = "2.1.0-universal";

    const PAGE_PATH = "/cgi-bin/koha/suggestion/suggestion.pl";

    const WARNING_ID = "pmk132-suggester-warning";
    const STYLE_ID = "pmk132-suggester-style";

    const DEFAULT_CONFIG = Object.freeze({
        enabled: true,

        warningFr:
            "Lecteur obligatoire : associez un lecteur à cette suggestion avant de l’enregistrer.",

        warningEn:
            "Patron required: associate a patron with this suggestion before saving it.",

        alertFr:
            "Impossible d’enregistrer cette suggestion.\n\n" +
            "Aucun lecteur n’est associé à la suggestion.\n\n" +
            "Cliquez sur « Attribuer à l’adhérent » et sélectionnez le lecteur concerné.",

        alertEn:
            "This suggestion cannot be saved.\n\n" +
            "No patron is associated with it.\n\n" +
            "Choose a patron before saving."
    });


    /* =========================================================
       État
       ========================================================= */

    let currentConfig = clone(DEFAULT_CONFIG);

    let unsubscribe = null;
    let observer = null;
    let formBound = null;

    let listenersInstalled = false;
    let configRevision = 0;
    let destroyed = false;
    let focusTimer = null;


    /* =========================================================
       Utilitaires
       ========================================================= */

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }


    function isSuggestionPage() {
        return window.location.pathname === PAGE_PATH;
    }


    function lang() {
        if (
            window.PMKConfig &&
            typeof window.PMKConfig.getLanguage === "function"
        ) {
            return window.PMKConfig.getLanguage();
        }

        const value = String(
            document.documentElement.lang ||
            navigator.language ||
            "fr"
        ).toLowerCase();

        return value.startsWith("en") ? "en" : "fr";
    }


    function normalizeConfig(raw) {
        const s = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
        // Keep unknown keys for forward/backward-compatible configuration migrations.
        // Do not replace user-entered empty strings with defaults.
        const result = Object.assign({}, s);
        result.enabled = s.enabled !== false;
        for (const key of ["warningFr", "warningEn", "alertFr", "alertEn"]) {
            result[key] = s[key] === undefined || s[key] === null
                ? DEFAULT_CONFIG[key] : String(s[key]);
        }
        return result;
    }


    function escapeHtml(value) {
        return String(
            value == null ? "" : value
        ).replace(
            /[&<>"']/g,
            function (char) {
                return {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#039;"
                }[char];
            }
        );
    }


    /* =========================================================
       Éléments Koha
       ========================================================= */

    function getForm() {
        return document.querySelector("form#add_edit");
    }


    function getSuggestedBy() {
        return document.querySelector("#suggestedby");
    }


    function getCell() {
        return document.querySelector("#tdsuggestedby");
    }


    function getButton() {
        return document.querySelector("#edit_suggester");
    }


    function patronId() {
        const input = getSuggestedBy();

        return input
            ? String(input.value || "").trim()
            : "";
    }


    /* =========================================================
       CSS
       ========================================================= */

    function installStyle() {
        if (document.getElementById(STYLE_ID)) return;

        const style = document.createElement("style");

        style.id = STYLE_ID;

        style.textContent = `
            #tdsuggestedby.pmk132-suggester-required {
                background-color: #fff3cd;
                outline: 2px solid #d39e00;
                outline-offset: -2px;
            }

            #${WARNING_ID} {
                margin-top: 8px;
                margin-bottom: 0;
            }
        `;

        document.head.appendChild(style);
    }


    /* =========================================================
       Avertissement
       ========================================================= */

    function clearWarning() {
        const button = getButton();
        if (button) {
            const ids = (button.getAttribute('aria-describedby') || '').split(/\s+/).filter(id => id && id !== WARNING_ID);
            if (ids.length) button.setAttribute('aria-describedby', ids.join(' '));
            else button.removeAttribute('aria-describedby');
        }
        const warning =
            document.getElementById(WARNING_ID);

        if (warning) {
            warning.remove();
        }

        const cell = getCell();

        if (cell) {
            cell.classList.remove(
                "pmk132-suggester-required"
            );
        }
    }


    function warningText() {
        return lang() === "en"
            ? currentConfig.warningEn
            : currentConfig.warningFr;
    }


    function updateExistingWarning(warning) {
        if (!warning) return;

        const strong =
            warning.querySelector(
                ".pmk132-warning-text"
            );

        if (strong) {
            const expected = warningText();

            if (strong.textContent !== expected) {
                strong.textContent = expected;
            }
        }
    }


    function createWarning(cell) {
        if (!cell) return null;

        const warning =
            document.createElement("div");

        warning.id = WARNING_ID;
        warning.setAttribute('role', 'alert');

        warning.className =
            "alert alert-warning";

        warning.innerHTML =
            '<i class="fa fa-exclamation-triangle" ' +
            'aria-hidden="true"></i> ' +
            '<strong class="pmk132-warning-text">' +
            escapeHtml(warningText()) +
            "</strong>";

        cell.appendChild(warning);
        const button = getButton();
        if (button) {
            const ids = new Set((button.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean));
            ids.add(WARNING_ID);
            button.setAttribute('aria-describedby', Array.from(ids).join(' '));
        }

        /*
         * Bouton de configuration PMK.
         *
         * Il n'est monté qu'au moment de la création
         * du bloc, et non à chaque updateState().
         */
        if (
            window.PMKConfig &&
            typeof window.PMKConfig.mountContextButton ===
                "function"
        ) {
            try {
                window.PMKConfig.mountContextButton({
                    moduleId: MODULE_ID,
                    anchor: warning,
                    position: "append",
                    contextKey:
                        "pmk132-suggester"
                });
            } catch (_) {
                /* Ne pas bloquer le module */
            }
        }

        return warning;
    }


    function updateState() {
        if (!isSuggestionPage()) return;

        const cell = getCell();

        if (!cell) return;


        /*
         * Module désactivé :
         * aucun avertissement.
         */
        if (currentConfig.enabled === false) {
            clearWarning();
            return;
        }


        /*
         * Un lecteur est présent :
         * aucun avertissement.
         */
        if (patronId()) {
            clearWarning();
            return;
        }


        /*
         * Lecteur absent.
         */
        cell.classList.add(
            "pmk132-suggester-required"
        );


        /*
         * IMPORTANT :
         * ne surtout pas supprimer/recréer
         * l'avertissement s'il existe déjà.
         */
        let warning =
            document.getElementById(WARNING_ID);

        if (warning) {
            updateExistingWarning(warning);
            return;
        }


        warning = createWarning(cell);
    }


    /* =========================================================
       Blocage de l'enregistrement
       ========================================================= */

    function submitHandler(event) {
        if (currentConfig.enabled === false) {
            return;
        }

        if (patronId()) {
            return;
        }


        event.preventDefault();

        event.stopImmediatePropagation();


        updateState();


        const cell = getCell();

        if (
            cell &&
            typeof cell.scrollIntoView ===
                "function"
        ) {
            cell.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });
        }


        window.alert(
            lang() === "en"
                ? currentConfig.alertEn
                : currentConfig.alertFr
        );


        const button = getButton();

        if (button) {
            button.focus();
        }


        return false;
    }


    /* =========================================================
       Liaison du formulaire
       ========================================================= */

    function bindForm() {
        if (!isSuggestionPage()) {
            return false;
        }

        const form = getForm();

        if (!form) {
            return false;
        }


        /*
         * Si c'est déjà le formulaire lié,
         * on ne refait rien.
         */
        if (formBound === form) {
            updateState();
            return true;
        }


        /*
         * Nettoyage de l'ancien formulaire
         * si Koha l'avait remplacé.
         */
        if (formBound) {
            formBound.removeEventListener(
                "submit",
                submitHandler,
                true
            );
        }


        form.addEventListener(
            "submit",
            submitHandler,
            true
        );

        formBound = form;


        updateState();

        return true;
    }


    /* =========================================================
       Événements
       ========================================================= */

    function fieldEventHandler(event) {
        if (!event.target) return;

        if (
            event.target.matches &&
            event.target.matches("#suggestedby")
        ) {
            updateState();
        }
    }


    function windowFocusHandler() {
        if (!isSuggestionPage()) return;

        /*
         * Utile notamment lorsque le choix du lecteur
         * passe par une fenêtre/pop-up Koha.
         */
        if (focusTimer !== null) window.clearTimeout(focusTimer);
        focusTimer = window.setTimeout(function () {
            focusTimer = null;
            if (!destroyed) updateState();
        }, 50);
    }


    function installListeners() {
        if (listenersInstalled) return;

        listenersInstalled = true;


        document.addEventListener(
            "change",
            fieldEventHandler,
            true
        );


        document.addEventListener(
            "input",
            fieldEventHandler,
            true
        );


        window.addEventListener(
            "focus",
            windowFocusHandler
        );
    }


    /* =========================================================
       MutationObserver
       ========================================================= */

    function waitForForm() {
        if (!isSuggestionPage()) return;
        bindForm();
        if (observer || typeof MutationObserver !== 'function') return;
        const targets = 'form#add_edit, #suggestedby, #tdsuggestedby, #edit_suggester';
        // Observe only structural changes to the native form controls. Our own
        // warning text/icons are ignored, preventing the former observer loop.
        observer = new MutationObserver(function (mutations) {
            const relevant = mutations.some(function (mutation) {
                return Array.from(mutation.addedNodes).concat(Array.from(mutation.removedNodes)).some(function (node) {
                    return node.nodeType === 1 && (node.matches(targets) || node.querySelector(targets));
                });
            });
            if (!relevant || destroyed) return;
            if (formBound && !formBound.isConnected) {
                formBound.removeEventListener('submit', submitHandler, true);
                formBound = null;
            }
            bindForm();
        });
        observer.observe(document.body || document.documentElement, {childList:true, subtree:true});
    }


    /* =========================================================
       Définition PMK
       ========================================================= */

    function definition() {
        return {
            id: MODULE_ID,

            schemaVersion: 1,

            name: {
                fr:
                    "Suggestions — lecteur obligatoire",

                en:
                    "Suggestions — patron required"
            },

            description: {
                fr:
                    "Empêche l’enregistrement d’une suggestion d’achat sans lecteur dans « Suggéré par ».",

                en:
                    "Prevents saving a purchase suggestion without a patron in the suggester field."
            },

            category: {
                fr:
                    "Acquisitions / suggestions",

                en:
                    "Acquisitions / suggestions"
            },

            supportedPages: [
                "suggestions.edit"
            ],

            defaults:
                clone(DEFAULT_CONFIG),

            schema: [
                {
                    type: "section",

                    id: "settings",

                    label: {
                        fr: "Réglages",
                        en: "Settings"
                    },

                    fields: [
                        {
                            key: "enabled",

                            type: "boolean",

                            label: {
                                fr:
                                    "Rendre le lecteur obligatoire",

                                en:
                                    "Require a patron"
                            }
                        },

                        {
                            key: "warningFr",

                            type: "text",

                            label: {
                                fr:
                                    "Avertissement — français",

                                en:
                                    "Warning — French"
                            }
                        },

                        {
                            key: "warningEn",

                            type: "text",

                            label: {
                                fr:
                                    "Avertissement — anglais",

                                en:
                                    "Warning — English"
                            }
                        },

                        {
                            key: "alertFr",

                            type: "textarea",

                            rows: 4,

                            label: {
                                fr:
                                    "Message bloquant — français",

                                en:
                                    "Blocking message — French"
                            }
                        },

                        {
                            key: "alertEn",

                            type: "textarea",

                            rows: 4,

                            label: {
                                fr:
                                    "Message bloquant — anglais",

                                en:
                                    "Blocking message — English"
                            }
                        }
                    ]
                }
            ]
        };
    }


    /* =========================================================
       Enregistrement PMK
       ========================================================= */

    function registerModule() {
        if (
            !window.PMKConfig ||
            typeof window.PMKConfig.registerModule !==
                "function"
        ) {
            return false;
        }


        try {
            window.PMKConfig.registerModule(
                definition()
            );
        } catch (_) {
            return false;
        }


        if (
            !unsubscribe &&
            typeof window.PMKConfig.subscribe ===
                "function"
        ) {
            try {
                unsubscribe =
                    window.PMKConfig.subscribe(
                        MODULE_ID,
                        function (cfg) {
                            configRevision += 1;
                            currentConfig = normalizeConfig(cfg);
                            if (!destroyed) updateState();
                        }
                    );
            } catch (_) {
                /* Ne pas bloquer */
            }
        }


        return true;
    }


    /* =========================================================
       Initialisation
       ========================================================= */

    async function start() {
        if (destroyed) return;
        registerModule();
        const requestedRevision = configRevision;


        if (
            window.PMKConfig &&
            typeof window.PMKConfig.getConfig ===
                "function"
        ) {
            try {
                const cfg = await window.PMKConfig.getConfig(MODULE_ID);
                if (!destroyed && requestedRevision === configRevision) {
                    currentConfig = normalizeConfig(cfg);
                }
            } catch (_) {
                // Keep the last known configuration on transient storage errors.
            }
        }


        /*
         * Le module est enregistré dans PMK partout,
         * mais son comportement ne s'exécute que
         * sur suggestion.pl.
         */
        if (destroyed || !isSuggestionPage()) {
            return;
        }


        installStyle();

        installListeners();

        waitForForm();
    }


    function destroy() {
        if (destroyed) return;
        destroyed = true;
        if (observer) { observer.disconnect(); observer = null; }
        if (formBound) { formBound.removeEventListener("submit", submitHandler, true); formBound = null; }
        if (listenersInstalled) {
            document.removeEventListener("change", fieldEventHandler, true);
            document.removeEventListener("input", fieldEventHandler, true);
            window.removeEventListener("focus", windowFocusHandler);
            listenersInstalled = false;
        }
        if (focusTimer !== null) { window.clearTimeout(focusTimer); focusTimer = null; }
        if (typeof unsubscribe === "function") { try { unsubscribe(); } catch (_) {} }
        unsubscribe = null;
        clearWarning();
        const style = document.getElementById(STYLE_ID);
        if (style) style.remove();
        if (window.__PMK132SuggestionSuggester) window.__PMK132SuggestionSuggester = false;
    }

    /* =========================================================
       API publique
       ========================================================= */

    window.PMK132SuggestionSuggester = {
        moduleId: MODULE_ID,
        version: MODULE_VERSION,

        refresh: updateState,
        destroy: destroy
    };


    /* =========================================================
       Démarrage
       ========================================================= */

    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            start,
            {
                once: true
            }
        );
    } else {
        start();
    }


    /*
     * PMK peut arriver après ce module.
     */
    if (!window.PMKConfig) {
        window.addEventListener(
            "pmk:config-ready",
            function () {
                if (destroyed) return;
                registerModule();

                if (isSuggestionPage()) {
                    updateState();
                }
            },
            {
                once: true
            }
        );
    }

})(window, document);
;window.PMKNonPlugin.loaded.push("132-suggestions.js");
} catch (error) { window.PMKNonPlugin.errors.push("132-suggestions.js: "+error.message); console.error("[PMK] 132-suggestions.js",error); };
try {
/*
 Nom du fichier : 134-intranetnav-menu.js
 Version : 1.6.0
 Date : 2026-09-25

 Module PimpMyKoha : Menu IntranetNav

 Objectifs :
 - injecter autant de menus principaux que nécessaire dans #toplevelmenu ;
 - créer autant d'entrées, groupes et sous-menus que nécessaire ;
 - profondeur de sous-menus non limitée par le moteur ;
 - choisir une icône Font Awesome ;
 - choisir l'accès : tous / superlibrarian / hérité du parent ;
 - gérer des liens et des actions PMK ;
 - intégrer l'accès aux modules autonomes 066-067, 071, 075 et 135 sans modifier leur logique métier ;
 - proposer des sous-menus latéraux, déroulés ou méga-menu ;
 - fournir un accès direct aux guides, parcours de formation et mode accompagnement ;
 - intégrer le compteur fréquentation Médiabus (139) comme action PMK uniquement sur MEDIABUS ;
 - masquer les anciens boutons de la barre basse seulement lorsque l'action correspondante
   est réellement disponible dans le nouveau menu ;
 - supprimer le menu Outils historique #custom-tools-menu pour éviter les doublons.
*/
(function () {
    'use strict';

    if (window.__PMK_INTRAnET_NAV_MENU__) return;
    window.__PMK_INTRAnET_NAV_MENU__ = true;

    const MODULE_ID = 'intranet-nav-menu';
    const STYLE_ID = 'pmk-intranet-nav-menu-styles';
    const LEGACY_LISTS_CLASS = 'pmk-hide-legacy-lists-entry';
    const LEGACY_HISTORY_CLASS = 'pmk-hide-legacy-history-entry';
    const LEGACY_ADVANCED_CLASS = 'pmk-hide-legacy-advanced-search-entry';
    const LEGACY_GUIDES_CLASS = 'pmk-hide-legacy-guides-entry';
    const OWN_CLASS = 'pmk-intranet-nav-menu';

    let currentConfig = null;
    let registered = false;
    let unsubscribe = null;
    let observer = null;
    let renderQueued = false;
    let rendering = false;

    const ICON_OPTIONS = [
        ['', { fr: 'Aucune icône', en: 'No icon' }],
        ['fa-wrench', { fr: 'Outils', en: 'Tools' }],
        ['fa-bookmark', { fr: 'Marque-page / listes', en: 'Bookmark / lists' }],
        ['fa-list', { fr: 'Liste', en: 'List' }],
        ['fa-folder-open', { fr: 'Dossier', en: 'Folder' }],
        ['fa-sitemap', { fr: 'Arborescence', en: 'Tree' }],
        ['fa-dashboard', { fr: 'Tableau de bord', en: 'Dashboard' }],
        ['fa-search', { fr: 'Recherche', en: 'Search' }],
        ['fa-search-plus', { fr: 'Recherche avancée', en: 'Advanced search' }],
        ['fa-clock-o', { fr: 'Historique', en: 'History' }],
        ['fa-graduation-cap', { fr: 'Formation', en: 'Training' }],
        ['fa-question-circle', { fr: 'Aide', en: 'Help' }],
        ['fa-compass', { fr: 'Guide', en: 'Guide' }],
        ['fa-life-ring', { fr: 'Accompagnement', en: 'Assistance' }],
        ['fa-calendar', { fr: 'Calendrier', en: 'Calendar' }],
        ['fa-check-circle', { fr: 'Contrôle / qualité', en: 'Check / quality' }],
        ['fa-home', { fr: 'Accueil', en: 'Home' }],
        ['fa-book', { fr: 'Notice / livre', en: 'Record / book' }],
        ['fa-barcode', { fr: 'Code-barres / exemplaire', en: 'Barcode / item' }],
        ['fa-user-circle', { fr: 'Utilisateur / autorité', en: 'User / authority' }],
        ['fa-users', { fr: 'Usagers', en: 'Patrons' }],
        ['fa-hand-paper-o', { fr: 'Réservation', en: 'Hold' }],
        ['fa-exchange', { fr: 'Transfert', en: 'Transfer' }],
        ['fa-retweet', { fr: 'Prêt / retour', en: 'Loan / return' }],
        ['fa-clipboard', { fr: 'Inventaire', en: 'Inventory' }],
        ['fa-trash', { fr: 'Suppression', en: 'Delete' }],
        ['fa-medkit', { fr: 'Restauration', en: 'Repair' }],
        ['fa-map-marker', { fr: 'Localisation', en: 'Location' }],
        ['fa-newspaper-o', { fr: 'Périodiques', en: 'Serials' }],
        ['fa-flask', { fr: 'Test / laboratoire', en: 'Test / lab' }],
        ['fa-cog', { fr: 'Configuration', en: 'Settings' }],
        ['fa-link', { fr: 'Lien', en: 'Link' }]
    ];

    function uid(prefix) {
        const p = String(prefix || 'nav').replace(/[^a-z0-9_-]/gi, '-');
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return p + '-' + window.crypto.randomUUID();
        }
        return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9);
    }

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function language() {
        if (window.PMKConfig && typeof window.PMKConfig.getLanguage === 'function') {
            return window.PMKConfig.getLanguage();
        }
        const value = String(document.documentElement.lang || navigator.language || 'fr').toLowerCase();
        return value.startsWith('en') ? 'en' : 'fr';
    }

    function tr(fr, en) {
        return language() === 'en' ? en : fr;
    }

    function labelOf(entry) {
        if (!entry) return '';
        const lang = language();
        const primary = lang === 'en' ? entry.labelEn : entry.labelFr;
        const fallback = lang === 'en' ? entry.labelFr : entry.labelEn;
        return String(primary || fallback || '').trim();
    }

    function effectiveIcon(entry) {
        const custom = String(entry && entry.iconCustom || '').trim();
        if (custom) return custom;
        return String(entry && entry.icon || '').trim();
    }

    function iconClass(value) {
        const raw = String(value || '').trim();
        if (!raw) return '';
        const parts = raw.split(/\s+/).filter(Boolean);
        const hasStyle = parts.some(function (part) {
            return part === 'fa' || /^fa-(?:solid|regular|brands|light|thin|duotone)$/.test(part);
        });
        if (!hasStyle) parts.unshift('fa');
        if (!parts.includes('fa-fw')) parts.push('fa-fw');
        return parts.join(' ');
    }

    function appendIcon(target, entry) {
        const cls = iconClass(effectiveIcon(entry));
        if (!cls) return;
        const i = document.createElement('i');
        i.className = cls;
        i.setAttribute('aria-hidden', 'true');
        target.appendChild(i);
    }

    function isSuperlibrarian() {
        if (window.PMKConfig && typeof window.PMKConfig.isKohaSuperlibrarian === 'function') {
            try { return !!window.PMKConfig.isKohaSuperlibrarian(); } catch (_) {}
        }

        const userEl = document.querySelector(
            '#logged-in-info-full .loggedinusername[data-loggedinusername], ' +
            '.loggedinusername[data-loggedinusername]'
        );
        if (!userEl) return false;
        return userEl.dataset.isSuperlibrarian === 'is_superlibrarian' ||
            userEl.classList.contains('is_superlibrarian');
    }

    function canSee(audience, parentAudience) {
        const requested = audience === 'all' || audience === 'superlibrarian'
            ? audience
            : (parentAudience || 'all');
        if (requested === 'superlibrarian') return isSuperlibrarian();
        return true;
    }

    function inheritedAudience(audience, parentAudience) {
        const own = audience === 'all' || audience === 'superlibrarian'
            ? audience
            : (parentAudience || 'all');
        if (parentAudience === 'superlibrarian') return 'superlibrarian';
        return own;
    }

    function menuAtPath(root, path) {
        const menuIndex = Array.isArray(path) && path[0] === 'menus' ? Number(path[1]) : NaN;
        return Number.isInteger(menuIndex) && root && Array.isArray(root.menus)
            ? root.menus[menuIndex]
            : null;
    }

    function itemAtPath(root, path) {
        const menu = menuAtPath(root, path);
        const itemsIndex = Array.isArray(path) ? path.indexOf('items') : -1;
        if (!menu || itemsIndex < 0) return null;
        const itemIndex = Number(path[itemsIndex + 1]);
        return Number.isInteger(itemIndex) && Array.isArray(menu.items)
            ? menu.items[itemIndex]
            : null;
    }

    function descendantsOf(items, id) {
        const result = new Set();
        let changed = true;
        while (changed) {
            changed = false;
            (items || []).forEach(function (candidate) {
                if (!candidate || !candidate.id || result.has(candidate.id)) return;
                if (candidate.parentId === id || result.has(candidate.parentId)) {
                    result.add(candidate.id);
                    changed = true;
                }
            });
        }
        return result;
    }

    function parentOptions(root, fieldPath) {
        const menu = menuAtPath(root, fieldPath);
        const current = itemAtPath(root, fieldPath);
        const items = menu && Array.isArray(menu.items) ? menu.items : [];
        const forbidden = current ? descendantsOf(items, current.id) : new Set();
        if (current && current.id) forbidden.add(current.id);

        const options = [{
            value: '',
            label: { fr: 'Racine du menu', en: 'Menu root' }
        }];

        items.forEach(function (item) {
            if (!item || !item.id || forbidden.has(item.id)) return;
            if (item.kind !== 'submenu' && item.kind !== 'group') return;
            const kind = item.kind === 'submenu'
                ? { fr: 'Sous-menu', en: 'Submenu' }
                : { fr: 'Groupe', en: 'Group' };
            const frLabel = String(item.labelFr || item.labelEn || item.id);
            const enLabel = String(item.labelEn || item.labelFr || item.id);
            options.push({
                value: item.id,
                label: {
                    fr: kind.fr + ' — ' + frLabel,
                    en: kind.en + ' — ' + enLabel
                }
            });
        });

        return options;
    }

    function itemKind(root, path) {
        const item = itemAtPath(root, path);
        return item ? item.kind : '';
    }

    function makeItem(kind, values) {
        return Object.assign({
            id: uid('item'),
            enabled: true,
            kind: kind || 'link',
            parentId: '',
            labelFr: '',
            labelEn: '',
            icon: '',
            iconCustom: '',
            audience: 'inherit',
            url: '',
            target: 'same',
            actionId: '',
            presentation: 'side',
            megaColumns: 3
        }, values || {});
    }

    function defaultItems() {
        return [
            makeItem('group', {
                id: 'tools-group',
                labelFr: 'Outils',
                labelEn: 'Tools',
                audience: 'all'
            }),
            makeItem('link', {
                id: 'collections-tree', parentId: 'tools-group',
                labelFr: 'Arborescence des collections', labelEn: 'Collections tree',
                icon: 'fa-sitemap', url: '/cgi-bin/koha/tools/page.pl?page_id=114', target: 'new'
            }),
            makeItem('action', {
                id: 'dashboard', parentId: 'tools-group',
                labelFr: 'Tableau de bord', labelEn: 'Dashboard',
                icon: 'fa-dashboard', actionId: 'dashboard',
                url: '/cgi-bin/koha/circ/circulation.pl#', target: 'same'
            }),
            makeItem('link', {
                id: 'item-search', parentId: 'tools-group',
                labelFr: "Recherche d'exemplaires", labelEn: 'Item search',
                icon: 'fa-search', url: '/cgi-bin/koha/reports/guided_reports.pl?id=4323&op=run', target: 'same'
            }),
            makeItem('link', {
                id: 'appointments', parentId: 'tools-group',
                labelFr: 'RDV et sondages', labelEn: 'Appointments and surveys',
                icon: 'fa-calendar', url: '/cgi-bin/koha/mainpage.pl?pmk_page=appointments', target: 'new'
            }),

            makeItem('separator', { id: 'sep-my-tools', audience: 'all' }),
            makeItem('group', {
                id: 'my-tools-group',
                labelFr: 'Mes outils', labelEn: 'My tools', audience: 'all'
            }),
            makeItem('action', {
                id: 'personal-lists', parentId: 'my-tools-group',
                labelFr: 'Listes personnelles', labelEn: 'Personal lists',
                icon: 'fa-bookmark', actionId: 'personal-lists', audience: 'inherit'
            }),
            makeItem('action', {
                id: 'recent-history', parentId: 'my-tools-group',
                labelFr: 'Historique récent', labelEn: 'Recent history',
                icon: 'fa-clock-o', actionId: 'recent-history', audience: 'inherit'
            }),
            makeItem('action', {
                id: 'advanced-search', parentId: 'my-tools-group',
                labelFr: 'Recherche avancée', labelEn: 'Advanced search',
                icon: 'fa-search-plus', actionId: 'advanced-search', audience: 'inherit'
            }),
            makeItem('action', {
                id: 'attendance-mediabus', parentId: 'my-tools-group',
                labelFr: 'Compteur de fréquentation', labelEn: 'Attendance counter',
                icon: 'fa-plus-square', actionId: 'attendance-mediabus', audience: 'inherit'
            }),
            makeItem('submenu', {
                id: 'guides-training-menu', parentId: 'my-tools-group',
                labelFr: 'Aide & formation', labelEn: 'Help & training',
                icon: 'fa-graduation-cap', audience: 'inherit',
                presentation: 'side'
            }),
            makeItem('action', {
                id: 'guides-current', parentId: 'guides-training-menu',
                labelFr: 'Guide de cet écran', labelEn: 'Guide for this screen',
                icon: 'fa-compass', actionId: 'guides-current', audience: 'inherit'
            }),
            makeItem('action', {
                id: 'guides-catalogue', parentId: 'guides-training-menu',
                labelFr: 'Parcours de formation', labelEn: 'Training paths',
                icon: 'fa-graduation-cap', actionId: 'guides-catalogue', audience: 'inherit'
            }),
            makeItem('action', {
                id: 'guides-assist-toggle', parentId: 'guides-training-menu',
                labelFr: 'Mode accompagnement', labelEn: 'Contextual assistance',
                icon: 'fa-life-ring', actionId: 'guides-assist-toggle', audience: 'inherit'
            }),

            makeItem('separator', { id: 'sep-admin', audience: 'superlibrarian' }),
            makeItem('group', {
                id: 'admin-group',
                labelFr: 'Administration', labelEn: 'Administration', audience: 'superlibrarian'
            }),
            makeItem('link', {
                id: 'internal-pages-hub', parentId: 'admin-group',
                labelFr: 'Pages & outils internes', labelEn: 'Internal pages & tools',
                icon: 'fa-th-large', url: '/cgi-bin/koha/mainpage.pl?pmk_page=hub', target: 'new'
            }),
            makeItem('link', {
                id: 'attendance-report', parentId: 'admin-group',
                labelFr: 'Fréquentation — rapports', labelEn: 'Attendance — reports',
                icon: 'fa-bar-chart', url: '/cgi-bin/koha/mainpage.pl?pmk_page=attendance-counter', target: 'new'
            }),
            makeItem('submenu', {
                id: 'quality-center', parentId: 'admin-group',
                labelFr: 'Centre qualité', labelEn: 'Quality center',
                icon: 'fa-check-circle', audience: 'inherit'
            }),
            makeItem('link', {
                id: 'quality-home', parentId: 'quality-center',
                labelFr: 'Ouvrir le Centre qualité', labelEn: 'Open Quality center',
                icon: 'fa-home', url: '/cgi-bin/koha/mainpage.pl?pmk_page=quality-center', target: 'new'
            }),
            makeItem('separator', { id: 'quality-sep', parentId: 'quality-center' }),
            makeItem('link', {
                id: 'quality-notices', parentId: 'quality-center',
                labelFr: 'Notices', labelEn: 'Records', icon: 'fa-book',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=biblios', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-items', parentId: 'quality-center',
                labelFr: 'Exemplaires', labelEn: 'Items', icon: 'fa-barcode',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=items', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-authorities', parentId: 'quality-center',
                labelFr: 'Autorités', labelEn: 'Authorities', icon: 'fa-user-circle',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=authorities', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-holds', parentId: 'quality-center',
                labelFr: 'Réservations', labelEn: 'Holds', icon: 'fa-hand-paper-o',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=reservations', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-transfers', parentId: 'quality-center',
                labelFr: 'Transferts', labelEn: 'Transfers', icon: 'fa-exchange',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=transfers', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-loans', parentId: 'quality-center',
                labelFr: 'Prêts & litiges', labelEn: 'Loans & disputes', icon: 'fa-retweet',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=loans', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-patrons', parentId: 'quality-center',
                labelFr: 'Comptes lecteurs', labelEn: 'Patron accounts', icon: 'fa-users',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=patrons', target: 'new'
            }),
            makeItem('link', {
                id: 'quality-serials', parentId: 'quality-center',
                labelFr: 'Périodiques', labelEn: 'Serials', icon: 'fa-newspaper-o',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=serials', target: 'new'
            }),
            makeItem('link', {
                id: 'inventory', parentId: 'admin-group',
                labelFr: 'Inventaire', labelEn: 'Inventory', icon: 'fa-clipboard',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=inventory', target: 'new'
            }),
            makeItem('link', {
                id: 'weeding', parentId: 'admin-group',
                labelFr: 'Désherbage', labelEn: 'Weeding', icon: 'fa-trash',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=weeding', target: 'new'
            }),
            makeItem('link', {
                id: 'restoration', parentId: 'admin-group',
                labelFr: 'Restauration', labelEn: 'Restoration', icon: 'fa-medkit',
                url: '/cgi-bin/koha/mainpage.pl?pmk_page=restore-deleted-items', target: 'new'
            }),
            makeItem('link', {
                id: 'patron-map', parentId: 'admin-group',
                labelFr: 'Carto adhérents', labelEn: 'Patron map', icon: 'fa-map-marker',
                url: '/cgi-bin/koha/tools/page.pl?page_id=130', target: 'new'
            }),
            makeItem('link', {
                id: 'heritage-funds', parentId: 'admin-group',
                labelFr: 'Suivi Fonds Pat.', labelEn: 'Heritage funds follow-up', icon: 'fa-book',
                url: '/cgi-bin/koha/tools/page.pl?page_id=119', target: 'new'
            }),
            makeItem('link', {
                id: 'serials-delete', parentId: 'admin-group',
                labelFr: 'Périodiques à supprimer', labelEn: 'Serials to delete', icon: 'fa-newspaper-o',
                url: '/cgi-bin/koha/reports/guided_reports.pl?id=5056&param_name=Site%7Cbranches%3Aall&sql_params=%25&op=run', target: 'new'
            })
        ];
    }

    function makeMenu(values) {
        return Object.assign({
            id: uid('menu'),
            enabled: true,
            labelFr: 'Nouveau menu',
            labelEn: 'New menu',
            icon: 'fa-wrench',
            iconCustom: '',
            audience: 'all',
            items: []
        }, values || {});
    }

    const DEFAULTS = {
        enabled: true,
        migrationVersion: 7,
        removeLegacyHardcodedMenu: true,
        hideLegacyListsButton: true,
        hideLegacyHistoryButton: true,
        hideLegacyAdvancedSearchButton: true,
        hideLegacyGuidesButton: true,
        collapseLabelsOnSmallScreens: true,
        menus: [
            makeMenu({
                id: 'tools',
                labelFr: 'Outils',
                labelEn: 'Tools',
                icon: 'fa-wrench',
                audience: 'all',
                items: defaultItems()
            })
        ]
    };

    function newMenu() {
        return makeMenu();
    }

    function newItem() {
        return makeItem('link', {
            labelFr: 'Nouvel élément',
            labelEn: 'New item',
            icon: 'fa-link'
        });
    }

    function iconOptions() {
        return ICON_OPTIONS.map(function (entry) {
            return { value: entry[0], label: entry[1] };
        });
    }

    function renderIntranetNavBuilder(context) {
        return window.PMKMenuEngine.renderEditor(context);
    }

    function moduleSchema() {
        return [
            {
                key: 'removeLegacyHardcodedMenu',
                type: 'boolean',
                label: {
                    fr: 'Remplacer le menu Outils historique de IntranetNav',
                    en: 'Replace the historical IntranetNav Tools menu'
                },
                help: {
                    fr: 'Supprime #custom-tools-menu pour éviter les doublons pendant la migration. Activé par défaut.',
                    en: 'Removes #custom-tools-menu to avoid duplicates during migration. Enabled by default.'
                }
            },
            {
                key: 'hideLegacyListsButton',
                type: 'boolean',
                label: {
                    fr: 'Masquer l’ancien bouton « Listes » de la barre basse',
                    en: 'Hide the old Lists button from the bottom bar'
                },
                help: {
                    fr: 'Le bouton #sidebar5 n’est masqué que si une action « Listes personnelles » active existe dans un menu visible.',
                    en: 'The #sidebar5 button is hidden only when an active Personal lists action exists in a visible menu.'
                }
            },
            {
                key: 'hideLegacyHistoryButton',
                type: 'boolean',
                label: {
                    fr: 'Masquer l’ancien bouton « Historique » de la barre basse',
                    en: 'Hide the old History button from the bottom bar'
                },
                help: {
                    fr: 'Le bouton #historique n’est masqué que si une action « Historique récent » active existe dans un menu visible et que le module 071 est disponible.',
                    en: 'The #historique button is hidden only when a visible Recent history action exists and module 071 is available.'
                }
            },
            {
                key: 'hideLegacyAdvancedSearchButton',
                type: 'boolean',
                label: {
                    fr: 'Masquer l’ancien bouton « Recherche avancée » de la barre basse',
                    en: 'Hide the old Advanced search button from the bottom bar'
                },
                help: {
                    fr: 'Le bouton #advancedSearch n’est masqué que si une action « Recherche avancée » active existe dans un menu visible et que le module 075 est disponible.',
                    en: 'The #advancedSearch button is hidden only when a visible Advanced search action exists and module 075 is available.'
                }
            },
            {
                key: 'hideLegacyGuidesButton',
                type: 'boolean',
                label: {
                    fr: 'Masquer l’ancien bouton « Aide & formation » de la barre basse',
                    en: 'Hide the old Help & training button from the bottom bar'
                },
                help: {
                    fr: 'Le bouton #tutoriel n’est masqué que si au moins un accès Guides & formation actif existe dans un menu visible et que le module 135 est disponible.',
                    en: 'The #tutoriel button is hidden only when at least one visible Guides & training action exists and module 135 is available.'
                }
            },
            {
                key: 'collapseLabelsOnSmallScreens',
                type: 'boolean',
                label: {
                    fr: 'N’afficher que les icônes des menus principaux sur petit écran',
                    en: 'Show only top-level menu icons on small screens'
                }
            },
            {
                key: '_builderSignal',
                type: 'text',
                label: { fr: 'Signal interne du constructeur', en: 'Builder internal signal' }
            },
            {
                type: 'custom',
                label: { fr: 'Composition visuelle du menu', en: 'Visual menu builder' },
                render: renderIntranetNavBuilder,
                help: {
                    fr: 'Cette vue représente les niveaux, séparateurs, groupes, sous-menus et l’ordre réellement utilisés dans IntranetNav. Glisse-dépose les éléments pour les réordonner ou changer de niveau. Les réglages techniques complets restent disponibles dans Réglages avancés.',
                    en: 'This view represents the actual levels, separators, groups, submenus and order used in IntranetNav. Drag and drop items to reorder or move them between levels. Full technical settings remain available in Advanced settings.'
                }
            },
            {
                key: 'menus',
                type: 'repeater',
                advanced: true,
                label: { fr: 'Menus IntranetNav', en: 'IntranetNav menus' },
                addLabel: { fr: 'Ajouter un menu', en: 'Add menu' },
                reorder: true,
                newItem: newMenu,
                liveTitleKey: 'labelFr',
                itemTitle: function (item, index, lang) {
                    const value = lang === 'en'
                        ? String(item && (item.labelEn || item.labelFr) || '')
                        : String(item && (item.labelFr || item.labelEn) || '');
                    return value.trim() || (lang === 'en' ? 'Menu ' : 'Menu ') + (index + 1);
                },
                fields: [
                    { key: 'enabled', type: 'boolean', label: { fr: 'Menu actif', en: 'Menu enabled' } },
                    { key: 'labelFr', type: 'text', label: { fr: 'Nom — français', en: 'Name — French' } },
                    { key: 'labelEn', type: 'text', label: { fr: 'Nom — anglais', en: 'Name — English' } },
                    {
                        key: 'icon', type: 'select', label: { fr: 'Icône', en: 'Icon' }, options: iconOptions
                    },
                    {
                        key: 'iconCustom', type: 'text', label: { fr: 'Icône personnalisée', en: 'Custom icon' },
                        advanced: true,
                        placeholder: { fr: 'Ex. fa-solid fa-star', en: 'E.g. fa-solid fa-star' },
                        help: {
                            fr: 'Optionnel. Si renseigné, remplace l’icône choisie ci-dessus.',
                            en: 'Optional. When filled, overrides the icon selected above.'
                        }
                    },
                    {
                        key: 'audience', type: 'select', label: { fr: 'Accès', en: 'Access' },
                        options: [
                            { value: 'all', label: { fr: 'Tous les agents', en: 'All staff' } },
                            { value: 'superlibrarian', label: { fr: 'Superlibrarian uniquement', en: 'Superlibrarian only' } }
                        ]
                    },
                    { key: 'id', type: 'text', readOnly: true, advanced: true, label: { fr: 'Identifiant technique', en: 'Technical ID' } },
                    {
                        key: 'items',
                        type: 'repeater',
                        label: { fr: 'Éléments du menu', en: 'Menu items' },
                        addLabel: { fr: 'Ajouter un élément', en: 'Add item' },
                        reorder: true,
                        newItem: newItem,
                        liveTitleKey: 'labelFr',
                        itemTitle: function (item, index, lang) {
                            if (item && item.kind === 'separator') return lang === 'en' ? 'Separator' : 'Séparateur';
                            const value = lang === 'en'
                                ? String(item && (item.labelEn || item.labelFr) || '')
                                : String(item && (item.labelFr || item.labelEn) || '');
                            return value.trim() || (lang === 'en' ? 'Item ' : 'Élément ') + (index + 1);
                        },
                        fields: [
                            { key: 'enabled', type: 'boolean', label: { fr: 'Élément actif', en: 'Item enabled' } },
                            {
                                key: 'kind', type: 'select', refreshOnChange: true,
                                label: { fr: 'Type', en: 'Type' },
                                options: [
                                    { value: 'link', label: { fr: 'Lien', en: 'Link' } },
                                    { value: 'submenu', label: { fr: 'Sous-menu', en: 'Submenu' } },
                                    { value: 'group', label: { fr: 'Groupe / titre', en: 'Group / heading' } },
                                    { value: 'separator', label: { fr: 'Séparateur', en: 'Separator' } },
                                    { value: 'action', label: { fr: 'Action PMK', en: 'PMK action' } }
                                ]
                            },
                            {
                                key: 'parentId', type: 'select',
                                label: { fr: 'Placer dans', en: 'Place inside' },
                                options: parentOptions,
                                help: {
                                    fr: 'Choisis la racine, un groupe ou n’importe quel sous-menu. Cette relation permet une profondeur de sous-menus libre.',
                                    en: 'Choose the root, a group, or any submenu. This relation allows unrestricted submenu depth.'
                                }
                            },
                            {
                                key: 'labelFr', type: 'text', label: { fr: 'Libellé — français', en: 'Label — French' },
                                when: function (root, path) { return itemKind(root, path) !== 'separator'; }
                            },
                            {
                                key: 'labelEn', type: 'text', label: { fr: 'Libellé — anglais', en: 'Label — English' },
                                when: function (root, path) { return itemKind(root, path) !== 'separator'; }
                            },
                            {
                                key: 'icon', type: 'select', label: { fr: 'Icône', en: 'Icon' }, options: iconOptions,
                                when: function (root, path) {
                                    const kind = itemKind(root, path);
                                    return kind !== 'separator' && kind !== 'group';
                                }
                            },
                            {
                                key: 'iconCustom', type: 'text', label: { fr: 'Icône personnalisée', en: 'Custom icon' },
                                advanced: true,
                                placeholder: { fr: 'Ex. fa-solid fa-star', en: 'E.g. fa-solid fa-star' },
                                when: function (root, path) {
                                    const kind = itemKind(root, path);
                                    return kind !== 'separator' && kind !== 'group';
                                }
                            },
                            {
                                key: 'presentation', type: 'select', refreshOnChange: true,
                                label: { fr: 'Présentation du sous-menu', en: 'Submenu presentation' },
                                when: function (root, path) { return itemKind(root, path) === 'submenu'; },
                                options: [
                                    { value: 'side', label: { fr: 'Latéral', en: 'Side' } },
                                    { value: 'dropdown', label: { fr: 'Déroulé vertical', en: 'Vertical dropdown' } },
                                    { value: 'mega', label: { fr: 'Méga-menu', en: 'Mega menu' } }
                                ],
                                help: {
                                    fr: 'Latéral conserve le comportement historique. Déroulé développe le contenu dans le menu courant. Méga-menu ouvre un panneau large en colonnes.',
                                    en: 'Side preserves the historical behavior. Vertical dropdown expands inside the current menu. Mega menu opens a wide multi-column panel.'
                                }
                            },
                            {
                                key: 'megaColumns', type: 'select',
                                label: { fr: 'Colonnes du méga-menu', en: 'Mega menu columns' },
                                when: function (root, path) {
                                    const item = itemAtPath(root, path);
                                    return itemKind(root, path) === 'submenu' && item && item.presentation === 'mega';
                                },
                                options: [
                                    { value: 2, label: { fr: '2 colonnes', en: '2 columns' } },
                                    { value: 3, label: { fr: '3 colonnes', en: '3 columns' } },
                                    { value: 4, label: { fr: '4 colonnes', en: '4 columns' } }
                                ]
                            },
                            {
                                key: 'audience', type: 'select', label: { fr: 'Accès', en: 'Access' },
                                options: [
                                    { value: 'inherit', label: { fr: 'Hériter du parent', en: 'Inherit from parent' } },
                                    { value: 'all', label: { fr: 'Tous les agents', en: 'All staff' } },
                                    { value: 'superlibrarian', label: { fr: 'Superlibrarian uniquement', en: 'Superlibrarian only' } }
                                ]
                            },
                            {
                                key: 'url', type: 'text', label: { fr: 'URL', en: 'URL' },
                                when: function (root, path) {
                                    const kind = itemKind(root, path);
                                    if (kind === 'link') return true;
                                    const item = itemAtPath(root, path);
                                    return kind === 'action' && item && item.actionId === 'dashboard';
                                }
                            },
                            {
                                key: 'target', type: 'select', label: { fr: 'Ouverture', en: 'Open in' },
                                when: function (root, path) {
                                    const kind = itemKind(root, path);
                                    if (kind === 'link') return true;
                                    const item = itemAtPath(root, path);
                                    return kind === 'action' && item && item.actionId === 'dashboard';
                                },
                                options: [
                                    { value: 'same', label: { fr: 'Même onglet', en: 'Same tab' } },
                                    { value: 'new', label: { fr: 'Nouvel onglet', en: 'New tab' } }
                                ]
                            },
                            {
                                key: 'actionId', type: 'select', refreshOnChange: true,
                                label: { fr: 'Action', en: 'Action' },
                                when: function (root, path) { return itemKind(root, path) === 'action'; },
                                options: [
                                    { value: '', label: { fr: 'Choisir une action', en: 'Choose an action' } },
                                    { value: 'personal-lists', label: { fr: 'Ouvrir les listes personnelles (066-067)', en: 'Open personal lists (066-067)' } },
                                    { value: 'recent-history', label: { fr: 'Ouvrir l’historique récent (071)', en: 'Open recent history (071)' } },
                                    { value: 'advanced-search', label: { fr: 'Ouvrir la recherche avancée (075)', en: 'Open advanced search (075)' } },
                                    { value: 'attendance-mediabus', label: { fr: 'Afficher le compteur de fréquentation', en: 'Show attendance counter' } },
                                    { value: 'guides-current', label: { fr: 'Lancer le guide de cet écran (135)', en: 'Start guide for this screen (135)' } },
                                    { value: 'guides-catalogue', label: { fr: 'Ouvrir les parcours de formation (135)', en: 'Open training paths (135)' } },
                                    { value: 'guides-assist-toggle', label: { fr: 'Activer / désactiver le mode accompagnement (135)', en: 'Toggle contextual assistance (135)' } },
                                    { value: 'dashboard', label: { fr: 'Ouvrir le tableau de bord', en: 'Open dashboard' } }
                                ]
                            },
                            { key: 'id', type: 'text', readOnly: true, advanced: true, label: { fr: 'Identifiant technique', en: 'Technical ID' } }
                        ]
                    }
                ]
            }
        ];
    }

    function validateConfig(config) {
        const lang = language();
        const menus = Array.isArray(config && config.menus) ? config.menus : [];
        const menuIds = new Set();

        for (const menu of menus) {
            const menuId = String(menu && menu.id || '').trim();
            if (!menuId || menuIds.has(menuId)) {
                return { ok: false, message: lang === 'en' ? 'Each main menu must have a unique technical ID.' : 'Chaque menu principal doit avoir un identifiant technique unique.' };
            }
            menuIds.add(menuId);

            const items = Array.isArray(menu.items) ? menu.items : [];
            const byId = new Map();
            for (const item of items) {
                const id = String(item && item.id || '').trim();
                if (!id || byId.has(id)) {
                    return { ok: false, message: lang === 'en' ? 'Each menu item must have a unique technical ID.' : 'Chaque élément de menu doit avoir un identifiant technique unique.' };
                }
                byId.set(id, item);
            }

            for (const item of items) {
                const parentId = String(item.parentId || '').trim();
                if (!parentId) continue;
                const parent = byId.get(parentId);
                if (!parent || (parent.kind !== 'submenu' && parent.kind !== 'group')) {
                    return { ok: false, message: lang === 'en' ? 'A menu item references an invalid parent.' : 'Un élément de menu référence un parent invalide.' };
                }

                const visited = new Set([item.id]);
                let cursor = parent;
                while (cursor) {
                    if (visited.has(cursor.id)) {
                        return { ok: false, message: lang === 'en' ? 'A cycle was detected in the menu hierarchy.' : 'Une boucle a été détectée dans l’arborescence du menu.' };
                    }
                    visited.add(cursor.id);
                    cursor = cursor.parentId ? byId.get(cursor.parentId) : null;
                }
            }
        }

        return { ok: true };
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            .${OWN_CLASS} .dropdown-menu {
                background-color: #fff;
                color: #212529;
                border: 1px solid rgba(0,0,0,.15);
                box-shadow: 0 .25rem .75rem rgba(0,0,0,.12);
            }
            .${OWN_CLASS} .dropdown-item {
                color: #212529;
            }
            .${OWN_CLASS} .dropdown-item:hover,
            .${OWN_CLASS} .dropdown-item:focus {
                color: #16181b;
                background-color: #f1f3f5;
            }
            .${OWN_CLASS} .dropdown-header {
                color: #6c757d;
                font-weight: 600;
            }
            .${OWN_CLASS} .dropdown-divider {
                border-color: #dee2e6;
            }
            .${OWN_CLASS} .pmk-nav-submenu {
                position: relative;
            }
            .${OWN_CLASS} .pmk-nav-submenu > .pmk-submenu-toggle {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: .75rem;
                width: 100%;
                border: 0;
                background: transparent;
                text-align: left;
            }
            .${OWN_CLASS} .pmk-submenu-label {
                display: inline-flex;
                align-items: center;
                gap: .25rem;
                min-width: 0;
            }
            .${OWN_CLASS} .pmk-submenu-caret {
                margin-left: auto;
                transition: transform .15s ease;
            }
            .${OWN_CLASS} .pmk-nav-submenu.show > .pmk-submenu-toggle .pmk-submenu-caret {
                transform: rotate(90deg);
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-side > .dropdown-menu {
                top: 0;
                left: 100%;
                margin-top: -.35rem;
                margin-left: .15rem;
                min-width: 250px;
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-dropdown > .dropdown-menu {
                position: static !important;
                float: none !important;
                transform: none !important;
                margin: .15rem .4rem .35rem 1rem;
                border: 0;
                border-left: 2px solid #dee2e6;
                border-radius: 0;
                box-shadow: none;
                min-width: 0;
                padding-top: .15rem;
                padding-bottom: .15rem;
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-dropdown > .pmk-submenu-toggle .pmk-submenu-caret {
                transform: rotate(90deg);
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-dropdown.show > .pmk-submenu-toggle .pmk-submenu-caret {
                transform: rotate(270deg);
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu {
                top: 0;
                left: 100%;
                margin-top: -.35rem;
                margin-left: .15rem;
                width: min(760px, 72vw);
                min-width: 520px;
                padding: .65rem;
                display: none;
                grid-template-columns: repeat(var(--pmk-mega-columns, 3), minmax(0,1fr));
                gap: .2rem .65rem;
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu.show {
                display: grid;
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu > li {
                min-width: 0;
            }
            .${OWN_CLASS} .pmk-nav-submenu > .dropdown-menu.show {
                display: block;
            }
            .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu.show {
                display: grid;
            }
            .${OWN_CLASS} .pmk-nav-group-children > .dropdown-item {
                padding-left: 1.55rem;
            }
            html.${LEGACY_LISTS_CLASS} #bottomActionBar #sidebar5 {
                display: none !important;
            }
            html.${LEGACY_HISTORY_CLASS} #bottomActionBar #historique {
                display: none !important;
            }
            html.${LEGACY_ADVANCED_CLASS} #bottomActionBar #advancedSearch {
                display: none !important;
            }
            html.${LEGACY_GUIDES_CLASS} #bottomActionBar #tutoriel {
                display: none !important;
            }
            @media (max-width: 991.98px) {
                .${OWN_CLASS} .pmk-nav-submenu > .dropdown-menu {
                    position: static !important;
                    float: none;
                    transform: none !important;
                    margin: .15rem .4rem .35rem 1rem;
                    border: 0;
                    border-left: 2px solid #dee2e6;
                    border-radius: 0;
                    box-shadow: none;
                    min-width: 0;
                }
                .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu,
                .${OWN_CLASS} .pmk-nav-submenu.pmk-submenu-mega > .dropdown-menu.show {
                    width: auto;
                    min-width: 0;
                    display: block;
                    grid-template-columns: 1fr;
                }
                .${OWN_CLASS}.pmk-collapse-label .nav-label {
                    display: none !important;
                }
                .${OWN_CLASS}.pmk-collapse-label > .nav-link i {
                    margin-right: 0 !important;
                }
                .${OWN_CLASS}.pmk-collapse-label > .nav-link {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding-left: .65rem;
                    padding-right: .65rem;
                }
                .${OWN_CLASS}.pmk-collapse-label > .dropdown-toggle::after {
                    display: none;
                }
            }
        `;
        document.head.appendChild(style);
    }

    function removeOwnMenus() {
        document.querySelectorAll('.' + OWN_CLASS).forEach(function (node) { node.remove(); });
    }

    function removeLegacyMenu() {
        const legacy = document.getElementById('custom-tools-menu');
        if (legacy) legacy.remove();
    }

    function topLevelMenu() {
        return document.getElementById('toplevelmenu');
    }

    function moreMenuItem(ul) {
        return Array.from((ul && ul.children) || []).find(function (item) {
            return !!item.querySelector('a.nav-link i.fa-bars, a.nav-link i.fa-solid.fa-bars');
        }) || null;
    }

    function listActionAvailable() {
        if (window.PMKPersonalLists) return window.PMKPersonalLists.enabled !== false;
        return true;
    }

    function historyActionAvailable() {
        if (window.PMKHistory071) return window.PMKHistory071.enabled !== false;
        if (window.PMKRecentHistory) return window.PMKRecentHistory.enabled !== false;
        if (window.PMKHistory) return window.PMKHistory.enabled !== false;
        return !!((window.KOHA_HISTORY && typeof window.KOHA_HISTORY.open === 'function') || typeof window.openNav === 'function');
    }

    function advancedSearchActionAvailable() {
        if (window.PMKAdvancedSearch) return window.PMKAdvancedSearch.enabled !== false;
        return !!(window.__kohaAdvancedSearchSidebarV2 || typeof window.openAdvancedSearchSidebar === 'function' || typeof window.toggleAdvancedSearchSidebar === 'function');
    }

    function attendanceMediabusActionAvailable() {
        const bridge = window.PMKAttendanceMediabus;
        return !!(bridge && bridge.available === true && bridge.enabled !== false && typeof bridge.open === 'function');
    }

    function guidesModuleAvailable() {
        if (window.PMKGuidesTraining) return window.PMKGuidesTraining.enabled !== false;
        return !!window.KOHA_GUIDES;
    }

    function guidesCurrentActionAvailable() {
        if (!guidesModuleAvailable()) return false;
        if (window.PMKGuidesTraining && typeof window.PMKGuidesTraining.canStartCurrent === 'function') {
            try { return !!window.PMKGuidesTraining.canStartCurrent(); } catch (_) { return false; }
        }
        try {
            return !!(window.KOHA_GUIDES && typeof window.KOHA_GUIDES.currentGuide === 'function' && window.KOHA_GUIDES.currentGuide());
        } catch (_) { return false; }
    }

    function guidesCatalogueActionAvailable() {
        if (!guidesModuleAvailable()) return false;
        if (window.PMKGuidesTraining && typeof window.PMKGuidesTraining.canOpenCatalogue === 'function') {
            try { return !!window.PMKGuidesTraining.canOpenCatalogue(); } catch (_) { return false; }
        }
        return !!(window.KOHA_GUIDES && typeof window.KOHA_GUIDES.openCatalogue === 'function');
    }

    function guidesAssistActionAvailable() {
        if (!guidesModuleAvailable()) return false;
        if (window.PMKGuidesTraining && typeof window.PMKGuidesTraining.canUseAssist === 'function') {
            try { return !!window.PMKGuidesTraining.canUseAssist(); } catch (_) { return false; }
        }
        return !!(window.KOHA_GUIDES && window.KOHA_GUIDES.assist && typeof window.KOHA_GUIDES.assist.setEnabled === 'function');
    }

    function hasVisibleAction(config, actionId, availableFn) {
        if (!config || config.enabled === false) return false;
        if (typeof availableFn === 'function' && !availableFn()) return false;

        return (config.menus || []).some(function (menu) {
            if (!menu || menu.enabled === false || !canSee(menu.audience, 'all')) return false;
            const byId = new Map((menu.items || []).map(function (item) { return [item.id, item]; }));

            function visibleThroughParents(item) {
                let audience = menu.audience || 'all';
                let cursor = item;
                const visited = new Set();
                const chain = [];
                while (cursor) {
                    if (visited.has(cursor.id)) return false;
                    visited.add(cursor.id);
                    chain.unshift(cursor);
                    cursor = cursor.parentId ? byId.get(cursor.parentId) : null;
                }
                for (const node of chain) {
                    if (!node || node.enabled === false) return false;
                    audience = inheritedAudience(node.audience, audience);
                    if (!canSee(audience, audience)) return false;
                }
                return true;
            }

            return (menu.items || []).some(function (item) {
                return item && item.kind === 'action' && item.actionId === actionId && visibleThroughParents(item);
            });
        });
    }

    function syncLegacyButtons(config) {
        const enabled = !!(config && config.enabled !== false);

        const hideLists = !!(
            enabled &&
            config.hideLegacyListsButton !== false &&
            hasVisibleAction(config, 'personal-lists', listActionAvailable)
        );
        const hideHistory = !!(
            enabled &&
            config.hideLegacyHistoryButton !== false &&
            hasVisibleAction(config, 'recent-history', historyActionAvailable)
        );
        const hideAdvanced = !!(
            enabled &&
            config.hideLegacyAdvancedSearchButton !== false &&
            hasVisibleAction(config, 'advanced-search', advancedSearchActionAvailable)
        );
        const hideGuides = !!(
            enabled &&
            config.hideLegacyGuidesButton !== false &&
            (
                hasVisibleAction(config, 'guides-current', guidesCurrentActionAvailable) ||
                hasVisibleAction(config, 'guides-catalogue', guidesCatalogueActionAvailable) ||
                hasVisibleAction(config, 'guides-assist-toggle', guidesAssistActionAvailable)
            )
        );

        document.documentElement.classList.toggle(LEGACY_LISTS_CLASS, hideLists);
        document.documentElement.classList.toggle(LEGACY_HISTORY_CLASS, hideHistory);
        document.documentElement.classList.toggle(LEGACY_ADVANCED_CLASS, hideAdvanced);
        document.documentElement.classList.toggle(LEGACY_GUIDES_CLASS, hideGuides);
    }

    function childrenOf(items, parentId) {
        const wanted = String(parentId || '');
        return (items || []).filter(function (item) {
            return item && String(item.parentId || '') === wanted;
        });
    }

    function closeSiblingSubmenus(li) {
        const parent = li && li.parentElement;
        if (!parent) return;
        Array.from(parent.children).forEach(function (sibling) {
            if (sibling === li || !sibling.classList) return;
            if (sibling.classList.contains('pmk-nav-submenu')) {
                sibling.classList.remove('show');
                const menu = sibling.querySelector(':scope > .dropdown-menu');
                const toggle = sibling.querySelector(':scope > .pmk-submenu-toggle');
                if (menu) menu.classList.remove('show');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    function closeAllSubmenus(root) {
        if (!root) return;
        root.querySelectorAll('.pmk-nav-submenu.show').forEach(function (li) {
            li.classList.remove('show');
            const menu = li.querySelector(':scope > .dropdown-menu');
            const toggle = li.querySelector(':scope > .pmk-submenu-toggle');
            if (menu) menu.classList.remove('show');
            if (toggle) toggle.setAttribute('aria-expanded', 'false');
        });
    }

    function closeTopDropdown(node) {
        const root = node && node.closest ? node.closest('.' + OWN_CLASS) : null;
        const toggle = root && root.querySelector(':scope > .nav-link.dropdown-toggle');
        if (!toggle) return;
        try {
            if (window.bootstrap && window.bootstrap.Dropdown) {
                window.bootstrap.Dropdown.getOrCreateInstance(toggle).hide();
            }
        } catch (_) {}
    }

    function runAction(item, event) {
        const actionId = String(item.actionId || '');
        if (actionId === 'personal-lists') {
            if (event) event.preventDefault();
            const bridge = window.PMKPersonalLists;
            if (bridge && typeof bridge.open === 'function') {
                bridge.open();
            } else if (typeof window.toggleSidebar5 === 'function') {
                window.toggleSidebar5();
            } else {
                try { document.dispatchEvent(new CustomEvent('pmk:open-personal-lists')); } catch (_) {}
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'recent-history') {
            if (event) event.preventDefault();

            const bridges = [
                window.PMKHistory071,
                window.PMKRecentHistory,
                window.PMKHistory
            ].filter(Boolean);
            const bridge = bridges.find(function (candidate) {
                return candidate && candidate.enabled !== false && typeof candidate.open === 'function';
            });

            if (bridge) {
                bridge.open();
            } else if (window.KOHA_HISTORY && typeof window.KOHA_HISTORY.open === 'function') {
                window.KOHA_HISTORY.open();
            } else if (typeof window.openNav === 'function') {
                window.openNav();
            } else {
                try { document.dispatchEvent(new CustomEvent('koha:requestOpenHistory')); } catch (_) {}
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'advanced-search') {
            if (event) event.preventDefault();

            const bridge = window.PMKAdvancedSearch;
            if (bridge && bridge.enabled !== false && typeof bridge.open === 'function') {
                bridge.open();
            } else if (typeof window.openAdvancedSearchSidebar === 'function') {
                window.openAdvancedSearchSidebar();
            } else if (typeof window.toggleAdvancedSearchSidebar === 'function') {
                window.toggleAdvancedSearchSidebar();
            } else {
                try { document.dispatchEvent(new CustomEvent('koha:toggleAdvancedSearch')); } catch (_) {}
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'attendance-mediabus') {
            if (event) event.preventDefault();
            const bridge = window.PMKAttendanceMediabus;
            if (bridge && bridge.available === true && bridge.enabled !== false && typeof bridge.open === 'function') {
                Promise.resolve(bridge.open()).finally(queueRender);
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'guides-current') {
            if (event) event.preventDefault();
            const bridge = window.PMKGuidesTraining;
            if (bridge && bridge.enabled !== false && typeof bridge.startCurrent === 'function') {
                bridge.startCurrent();
            } else if (window.KOHA_GUIDES && typeof window.KOHA_GUIDES.start === 'function') {
                window.KOHA_GUIDES.start();
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'guides-catalogue') {
            if (event) event.preventDefault();
            const bridge = window.PMKGuidesTraining;
            if (bridge && bridge.enabled !== false && typeof bridge.openCatalogue === 'function') {
                bridge.openCatalogue();
            } else if (window.KOHA_GUIDES && typeof window.KOHA_GUIDES.openCatalogue === 'function') {
                window.KOHA_GUIDES.openCatalogue();
            } else {
                try { document.dispatchEvent(new CustomEvent('koha:openGuideCatalogue')); } catch (_) {}
            }
            closeTopDropdown(event && event.currentTarget);
            return;
        }

        if (actionId === 'guides-assist-toggle') {
            if (event) event.preventDefault();
            const bridge = window.PMKGuidesTraining;
            if (bridge && bridge.enabled !== false && typeof bridge.toggleAssist === 'function') {
                Promise.resolve(bridge.toggleAssist()).finally(queueRender);
            } else if (window.KOHA_GUIDES && window.KOHA_GUIDES.assist) {
                try {
                    const on = typeof window.KOHA_GUIDES.assist.enabled === 'function' && window.KOHA_GUIDES.assist.enabled();
                    window.KOHA_GUIDES.assist.setEnabled(!on);
                    if (typeof window.KOHA_GUIDES.assist.refresh === 'function') window.KOHA_GUIDES.assist.refresh();
                } catch (_) {}
                queueRender();
            }
            return;
        }

        if (actionId === 'dashboard') {
            if (event) event.preventDefault();
            if (typeof window.loadDashboardKoha === 'function') {
                window.loadDashboardKoha();
                closeTopDropdown(event && event.currentTarget);
                return;
            }
            const url = String(item.url || '/cgi-bin/koha/circ/circulation.pl#');
            if (item.target === 'new') window.open(url, '_blank', 'noopener');
            else window.location.href = url;
            closeTopDropdown(event && event.currentTarget);
        }
    }

    function actionAvailable(id) {
        const checks = {'personal-lists':listActionAvailable,'recent-history':historyActionAvailable,
            'advanced-search':advancedSearchActionAvailable,'attendance-mediabus':attendanceMediabusActionAvailable,
            'guides-current':guidesCurrentActionAvailable,'guides-catalogue':guidesCatalogueActionAvailable,'guides-assist-toggle':guidesAssistActionAvailable};
        return !checks[id] || checks[id]();
    }

    function registerMenuActions() {
        const entries = {};
        ['personal-lists','recent-history','advanced-search','attendance-mediabus','guides-current','guides-catalogue','guides-assist-toggle','dashboard'].forEach(id => {
            entries[id]={available:()=>actionAvailable(id),run:runAction};
        });
        window.PMKMenuEngine.registerActions(entries);
    }

    function buildTopMenu(menuConfig) {
        const li = document.createElement('li');
        li.className = 'nav-item dropdown ' + OWN_CLASS;
        if (currentConfig && currentConfig.collapseLabelsOnSmallScreens !== false) {
            li.classList.add('pmk-collapse-label');
        }
        li.dataset.pmkMenuId = menuConfig.id;

        const toggle = document.createElement('a');
        toggle.className = 'nav-link dropdown-toggle';
        toggle.href = '#';
        toggle.role = 'button';
        toggle.setAttribute('data-bs-toggle', 'dropdown');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.title = labelOf(menuConfig);
        appendIcon(toggle, menuConfig);

        const label = document.createElement('span');
        label.className = 'nav-label';
        label.textContent = labelOf(menuConfig);
        toggle.appendChild(label);

        const dropdown = document.createElement('div');
        dropdown.className = 'dropdown-menu';
        dropdown.appendChild(window.PMKMenuEngine.renderPanel({title:labelOf(menuConfig),items:menuConfig.items || [],audience:menuConfig.audience || 'all',actionAvailable,onAction:runAction,onClose:function(){closeTopDropdown(toggle);}}));

        li.append(toggle, dropdown);
        li.addEventListener('hidden.bs.dropdown', function () { window.PMKMenuEngine.closeAll(li); });
        return li;
    }

    function normalizeOrphans(menu) {
        if (!menu || !Array.isArray(menu.items)) return menu;
        const ids = new Set(menu.items.map(function (item) { return item && item.id; }).filter(Boolean));
        menu.items.forEach(function (item) {
            if (item && item.parentId && !ids.has(item.parentId)) item.parentId = '';
        });
        return menu;
    }

    function render() {
        if (rendering) return;
        rendering = true;
        try {
            injectStyles();
            removeOwnMenus();

            const config = currentConfig || clone(DEFAULTS);
            if (config.removeLegacyHardcodedMenu !== false) removeLegacyMenu();

            syncLegacyButtons(config);

            if (config.enabled === false) return;

            const ul = topLevelMenu();
            if (!ul) return;
            const more = moreMenuItem(ul);

            (config.menus || []).forEach(function (sourceMenu) {
                if (!sourceMenu || sourceMenu.enabled === false) return;
                if (!canSee(sourceMenu.audience, 'all')) return;
                const menu = normalizeOrphans(sourceMenu);
                const node = buildTopMenu(menu);
                if (more) more.before(node);
                else ul.appendChild(node);
            });
        } finally {
            rendering = false;
        }
    }

    function queueRender() {
        if (renderQueued) return;
        renderQueued = true;
        window.requestAnimationFrame(function () {
            renderQueued = false;
            render();
        });
    }

    function watchDom() {
        if (observer) return;
        const root = document.documentElement;
        if (!root) return;
        observer = new MutationObserver(function (mutations) {
            if (rendering) return;
            let relevant = false;
            for (const mutation of mutations) {
                if (!mutation.addedNodes || !mutation.addedNodes.length) continue;
                for (const node of mutation.addedNodes) {
                    if (!node || node.nodeType !== 1) continue;
                    if (
                        node.id === 'custom-tools-menu' ||
                        node.id === 'toplevelmenu' ||
                        node.id === 'sidebar5' ||
                        node.id === 'historique' ||
                        node.id === 'advancedSearch' ||
                        node.id === 'tutoriel' ||
                        (node.querySelector && (
                            node.querySelector('#custom-tools-menu') ||
                            node.querySelector('#toplevelmenu') ||
                            node.querySelector('#sidebar5') ||
                            node.querySelector('#historique') ||
                            node.querySelector('#advancedSearch') ||
                            node.querySelector('#tutoriel')
                        ))
                    ) {
                        relevant = true;
                        break;
                    }
                }
                if (relevant) break;
            }
            if (relevant) queueRender();
        });
        observer.observe(root, { childList: true, subtree: true });
    }

    function hasAction(config, actionId) {
        return (config.menus || []).some(function (menu) {
            return Array.isArray(menu && menu.items) && menu.items.some(function (item) {
                return item && item.kind === 'action' && item.actionId === actionId;
            });
        });
    }

    function defaultActionItem(actionId) {
        const items = defaultItems();
        return items.find(function (item) {
            return item && item.kind === 'action' && item.actionId === actionId;
        }) || null;
    }

    function insertMigratedAction(config, actionId) {
        if (hasAction(config, actionId)) return false;

        const menus = Array.isArray(config.menus) ? config.menus : [];
        let menu = menus.find(function (entry) { return entry && entry.id === 'tools'; }) || menus[0];
        if (!menu) {
            menu = clone(DEFAULTS.menus[0]);
            config.menus = [menu];
        }
        if (!Array.isArray(menu.items)) menu.items = [];

        const source = defaultActionItem(actionId);
        if (!source) return false;

        const hasMyTools = menu.items.some(function (item) {
            return item && item.id === 'my-tools-group';
        });
        const migrated = clone(source);
        if (!hasMyTools) migrated.parentId = '';
        menu.items.push(migrated);
        return true;
    }

    function ensureSubmenuPresentation(config) {
        let changed = false;
        (config.menus || []).forEach(function (menu) {
            (menu && Array.isArray(menu.items) ? menu.items : []).forEach(function (item) {
                if (!item || item.kind !== 'submenu') return;
                if (!['side', 'dropdown', 'mega'].includes(String(item.presentation || ''))) {
                    item.presentation = 'side';
                    changed = true;
                }
                if (!item.megaColumns) {
                    item.megaColumns = 3;
                    changed = true;
                }
            });
        });
        return changed;
    }

    function insertGuidesTrainingBundle(config) {
        const menus = Array.isArray(config.menus) ? config.menus : [];
        let menu = menus.find(function (entry) { return entry && entry.id === 'tools'; }) || menus[0];
        if (!menu) {
            menu = clone(DEFAULTS.menus[0]);
            config.menus = [menu];
            return true;
        }
        if (!Array.isArray(menu.items)) menu.items = [];

        const alreadyHasGuides = menu.items.some(function (item) {
            return item && item.kind === 'action' && ['guides-current', 'guides-catalogue', 'guides-assist-toggle'].includes(item.actionId);
        });
        if (alreadyHasGuides) return false;

        const defaults = defaultItems();
        const ids = new Set(['guides-training-menu', 'guides-current', 'guides-catalogue', 'guides-assist-toggle']);
        const additions = defaults.filter(function (item) { return item && ids.has(item.id); }).map(clone);
        const hasMyTools = menu.items.some(function (item) { return item && item.id === 'my-tools-group'; });
        if (!hasMyTools) {
            additions.forEach(function (item) {
                if (item.id === 'guides-training-menu') item.parentId = '';
            });
        }
        menu.items.push.apply(menu.items, additions);
        return additions.length > 0;
    }


    function migrateGuidesSubmenuToSide(config) {
        let changed = false;

        (config.menus || []).forEach(function (menu) {
            (menu.items || []).forEach(function (item) {
                if (!item || item.id !== 'guides-training-menu') return;

                /*
                 * La présentation historique attendue pour Aide & formation
                 * est latérale : le sous-menu s'ouvre à droite du menu parent,
                 * pas à l'intérieur de celui-ci.
                 */
                if (item.presentation !== 'side') {
                    item.presentation = 'side';
                    changed = true;
                }
            });
        });

        return changed;
    }


    function migratePmk138VirtualPages(config) {
        let changed = false;
        const byId = {
            'appointments':'/cgi-bin/koha/mainpage.pl?pmk_page=appointments',
            'quality-home':'/cgi-bin/koha/mainpage.pl?pmk_page=quality-center',
            'quality-notices':'/cgi-bin/koha/mainpage.pl?pmk_page=biblios',
            'quality-items':'/cgi-bin/koha/mainpage.pl?pmk_page=items',
            'quality-authorities':'/cgi-bin/koha/mainpage.pl?pmk_page=authorities',
            'quality-holds':'/cgi-bin/koha/mainpage.pl?pmk_page=reservations',
            'quality-transfers':'/cgi-bin/koha/mainpage.pl?pmk_page=transfers',
            'quality-loans':'/cgi-bin/koha/mainpage.pl?pmk_page=loans',
            'quality-patrons':'/cgi-bin/koha/mainpage.pl?pmk_page=patrons',
            'quality-rules':'/cgi-bin/koha/mainpage.pl?pmk_page=quality-center',
            'inventory':'/cgi-bin/koha/mainpage.pl?pmk_page=inventory',
            'weeding':'/cgi-bin/koha/mainpage.pl?pmk_page=weeding',
            'restoration':'/cgi-bin/koha/mainpage.pl?pmk_page=restore-deleted-items'
        };
        (config.menus || []).forEach(function(menu){
            const items = Array.isArray(menu.items) ? menu.items : [];
            items.forEach(function(item){
                if (!item || !byId[item.id]) return;
                if (item.url !== byId[item.id]) { item.url = byId[item.id]; changed = true; }
            });
            const admin = items.find(function(item){ return item && item.id === 'admin-group'; });
            if (admin && !items.some(function(item){ return item && item.id === 'internal-pages-hub'; })) {
                items.push(makeItem('link', {
                    id:'internal-pages-hub', parentId:'admin-group',
                    labelFr:'Pages & outils internes', labelEn:'Internal pages & tools',
                    icon:'fa-th-large', url:'/cgi-bin/koha/mainpage.pl?pmk_page=hub', target:'new', audience:'inherit'
                }));
                changed = true;
            }
            const quality = items.find(function(item){ return item && item.id === 'quality-center'; });
            if (quality && !items.some(function(item){ return item && item.id === 'quality-serials'; })) {
                items.push(makeItem('link', {
                    id:'quality-serials', parentId:'quality-center',
                    labelFr:'Périodiques', labelEn:'Serials', icon:'fa-newspaper-o',
                    url:'/cgi-bin/koha/mainpage.pl?pmk_page=serials', target:'new', audience:'inherit'
                }));
                changed = true;
            }
        });
        return changed;
    }

    function insertAttendanceReportLink(config) {
        const menus = Array.isArray(config.menus) ? config.menus : [];
        let menu = menus.find(function(entry){ return entry && entry.id === 'tools'; }) || menus[0];
        if (!menu) {
            menu = clone(DEFAULTS.menus[0]);
            config.menus = [menu];
            return true;
        }
        if (!Array.isArray(menu.items)) menu.items = [];
        if (menu.items.some(function(item){ return item && (item.id === 'attendance-report' || String(item.url || '').includes('pmk_page=attendance-counter')); })) return false;
        const source = defaultItems().find(function(item){ return item && item.id === 'attendance-report'; });
        if (!source) return false;
        const migrated = clone(source);
        if (!menu.items.some(function(item){ return item && item.id === 'admin-group'; })) migrated.parentId = '';
        menu.items.push(migrated);
        return true;
    }

    function migrateConfig(config) {
        const supplied = config && typeof config === 'object' ? clone(config) : {};
        const cfg = Object.assign(clone(DEFAULTS), supplied);
        if (!Array.isArray(cfg.menus)) cfg.menus = clone(DEFAULTS.menus);

        let version = Number(supplied.migrationVersion || 0);
        let changed = false;

        if (version < 1) {
            changed = insertMigratedAction(cfg, 'recent-history') || changed;
            version = 1;
        }
        if (version < 2) {
            changed = insertMigratedAction(cfg, 'advanced-search') || changed;
            version = 2;
        }
        if (version < 3) {
            changed = ensureSubmenuPresentation(cfg) || changed;
            version = 3;
        }
        if (version < 4) {
            changed = insertGuidesTrainingBundle(cfg) || changed;
            version = 4;
        }

        /*
         * v5 : le sous-menu « Aide & formation » passe en présentation
         * latérale. Cette migration s'applique aussi aux configurations
         * 134 v1.4.0 déjà enregistrées avec presentation = "dropdown".
         */
        if (version < 5) {
            changed = migrateGuidesSubmenuToSide(cfg) || changed;
            version = 5;
        }
        if (version < 6) {
            changed = migratePmk138VirtualPages(cfg) || changed;
            version = 6;
        }

        if (version < 7) {
            changed = insertMigratedAction(cfg, 'attendance-mediabus') || changed;
            changed = insertAttendanceReportLink(cfg) || changed;
            version = 7;
        }

        if (cfg.migrationVersion !== version) {
            cfg.migrationVersion = version;
            changed = true;
        }

        return { config: cfg, changed: changed };
    }

    let migrationSaveInFlight = false;

    function applyConfig(config) {
        const migrated = migrateConfig(config);
        currentConfig = migrated.config;
        queueRender();


    }

    function registerWithPMK() {
        if (!window.PMKConfig || registered) return false;
        registered = true;
        registerMenuActions();

        window.PMKConfig.registerModule({
            id: MODULE_ID,
            schemaVersion: 8,
            name: {
                fr: 'Menu IntranetNav',
                en: 'IntranetNav menu'
            },
            description: {
                fr: 'Construit des menus Koha configurables dans IntranetNav avec un éditeur visuel fidèle au menu réel : liens, groupes, séparateurs, niveaux, sous-menus latéraux/déroulés/méga-menu, glisser-déposer, icônes, actions PMK et accès réservé aux superlibrarians. Intègre directement Listes, Historique, Recherche avancée, Guides & formation et le compteur de fréquentation.',
                en: 'Builds configurable Koha IntranetNav menus with a visual editor matching the real menu structure: links, groups, separators, levels, side/dropdown/mega submenus, drag and drop, icons, PMK actions and superlibrarian-only access. Directly integrates Lists, History, Advanced search, Guides & training and the attendance counter.'
            },
            category: {
                fr: 'Navigation et interface',
                en: 'Navigation and interface'
            },
            defaults: clone(DEFAULTS),
            schema: moduleSchema(),
            validate: validateConfig
        });

        window.PMKConfig.getConfig(MODULE_ID)
            .then(applyConfig)
            .catch(function () { applyConfig(clone(DEFAULTS)); });

        if (typeof window.PMKConfig.subscribe === 'function') {
            unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig);
        }

        return true;
    }

    function bootstrap() {
        watchDom();

        if (!registerWithPMK()) {
            window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });
            let tries = 0;
            const timer = window.setInterval(function () {
                tries += 1;
                if (registerWithPMK() || tries >= 100) {
                    window.clearInterval(timer);
                    if (!registered) applyConfig(clone(DEFAULTS));
                }
            }, 50);
        }

        window.addEventListener('pmk:personal-lists-state', queueRender);
        window.addEventListener('pmk:history-state', queueRender);
        window.addEventListener('pmk:advanced-search-state', queueRender);
        window.addEventListener('pmk:guides-training-state', queueRender);
        document.addEventListener('pmk:attendance-mediabus-state', queueRender);
        document.addEventListener('koha-guides-assist-toggle', queueRender);
        queueRender();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    } else {
        bootstrap();
    }

    window.addEventListener('beforeunload', function () {
        if (observer) {
            try { observer.disconnect(); } catch (_) {}
            observer = null;
        }
        if (typeof unsubscribe === 'function') {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });
})();

;window.PMKNonPlugin.loaded.push("134-intranetnav-menu.js");
} catch (error) { window.PMKNonPlugin.errors.push("134-intranetnav-menu.js: "+error.message); console.error("[PMK] 134-intranetnav-menu.js",error); };
try {
/*
 Nom du fichier : 135-guides-training-pmk-loader.js
 Version : 1.1.1-preplugin
 Date : 2026-09-22

 Module PimpMyKoha : Guides & formation
 PMK id : guides-training

 Rôle :
 - rend le dispositif de guides totalement autonome de 066-067 ;
 - enregistre « Guides & formation » dans PimpMyKoha ;
 - charge séquentiellement les runtimes historiques de guides ;
 - expose une API stable à IntranetNav 134 ;
 - permet de lancer directement le guide de l'écran courant, le catalogue
   des parcours et le mode accompagnement ;
 - masque le lanceur de secours généré par le core pour éviter les doublons ;
 - ne modifie pas les guides métier existants.
*/
(function (window, document) {
    'use strict';

    if (window.__PMK135_GUIDES_TRAINING_LOADER__) return;
    window.__PMK135_GUIDES_TRAINING_LOADER__ = true;

    const MODULE_ID = 'guides-training';
    const VERSION = '1.1.1-preplugin';
    const SCRIPT_ID_PREFIX = 'pmk-135-guide-runtime-';
    const STYLE_ID = 'pmk-135-guides-training-style';
    const DISABLED_CLASS = 'pmk-guides-training-disabled';
    const MANAGED_CLASS = 'pmk-guides-training-managed';
    const ASSIST_KEY = 'kohaGuideAssistEnabled';

    const GUIDE_FILES = [
        '000-guides-core.js',
        '000b-guide-bibliotheconomie.js',
        '001-guide-search.js',
        '002-guide-detail.js',
        '003-guide-guided-reports.js',
        '004-guide-home.js',
        '005-guide-circulation-home.js',
        '006-guide-stage-marc-import.js',
        '007-guide-extended.js',
        '000c-guide-parcours.js',
        '000d-guide-accompagnement.js'
    ];

    const DEFAULTS = {
        enabled: true,
        currentGuideEnabled: true,
        catalogueEnabled: true,
        assistFeatureEnabled: true,
        assistDefault: false,
        customTours: []
    };

    let currentConfig = Object.assign({}, DEFAULTS);
    let loadingPromise = null;
    let registered = false;
    let unsubscribe = null;
    let lastError = null;

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function currentScriptElement() {
        if (document.currentScript && /135-guides-training-pmk-loader\.js/i.test(document.currentScript.src || '')) {
            return document.currentScript;
        }
        return Array.from(document.scripts || []).reverse().find(function (script) {
            return /135-guides-training-pmk-loader\.js/i.test(script.src || '');
        }) || null;
    }

    function resolveRuntimeBase() {
        if (window.PMKPlugin?.assetUrl) return new URL('./',window.PMKPlugin.assetUrl('guides/000-guides-core.js')).href;
        const script = currentScriptElement();
        if (script && script.src) {
            try {
                const url = new URL(script.src, window.location.href);
                url.pathname = url.pathname.replace(/135-guides-training-pmk-loader\.js$/i, 'guides/');
                url.search = '';
                url.hash = '';
                return url.href;
            } catch (_) {}
        }
        return '/public/koha-scripts/guides/';
    }

    function cacheSuffix() {
        if (window.PMKPlugin?.build) return '?v='+encodeURIComponent(window.PMKPlugin.build);
        const script = currentScriptElement();
        if (!script || !script.src) return '';
        try {
            const url = new URL(script.src, window.location.href);
            const v = url.searchParams.get('v');
            if (v) return '?v=' + encodeURIComponent(v);
            const rel = url.searchParams.get('rel');
            if (rel) return '?rel=' + encodeURIComponent(rel);
        } catch (_) {}
        return '';
    }

    const RUNTIME_BASE = resolveRuntimeBase();
    const CACHE_SUFFIX = cacheSuffix();

    function guideUrl(file) {
        return RUNTIME_BASE + file + CACHE_SUFFIX;
    }


    /*
     * Compatibilité avec les guides historiques d’origine.
     *
     * Les guides 000b / 001..007 utilisent l'ancien contrat KOHA_GUIDES :
     *   - register(function(ctx){ return [steps...]; })
     *   - registerFirst(function(ctx){ return [steps...]; })
     *   - stepAny(...)
     *   - compactSteps(...)
     *   - firstVisible(...)
     *
     * Le core v2.0.4 ne fournit plus directement ce contrat. Sans cette
     * couche, les fonctions sont enregistrées comme des définitions vides :
     * currentGuide() trouve bien "quelque chose", mais aucune étape ne peut
     * être lancée.
     *
     * On rétablit ici ce contrat sans modifier les fichiers guides métier.
     * Tous les fournisseurs historiques sont agrégés dans UNE définition
     * dynamique compatible avec le core v2.
     */
    function installLegacyGuideCompatibility() {
        const k = window.KOHA_GUIDES;
        if (!k || k.__pmkLegacyProvidersCompatV1) return !!k;
        k.__pmkLegacyProvidersCompatV1 = true;

        const coreVisible = k.helpers && typeof k.helpers.visible === 'function'
            ? k.helpers.visible
            : function (el) {
                if (!el || !(el instanceof Element)) return false;
                const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
                if (style && (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')) {
                    return false;
                }
                return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
            };

        function selectorsList(selectors) {
            if (Array.isArray(selectors)) return selectors;
            if (selectors == null) return [];
            return [selectors];
        }

        function firstVisible(selectors) {
            for (const candidate of selectorsList(selectors)) {
                if (!candidate) continue;

                if (candidate instanceof Element) {
                    if (coreVisible(candidate)) return candidate;
                    continue;
                }

                if (typeof candidate === 'function') {
                    try {
                        const el = candidate();
                        if (el && coreVisible(el)) return el;
                    } catch (_) {}
                    continue;
                }

                if (typeof candidate === 'string') {
                    let nodes = [];
                    try { nodes = Array.from(document.querySelectorAll(candidate)); } catch (_) {}
                    const visibleNode = nodes.find(coreVisible);
                    if (visibleNode) return visibleNode;
                }
            }
            return null;
        }

        function compactSteps(steps) {
            return (Array.isArray(steps) ? steps : []).filter(Boolean);
        }

        function stepElement(target, title, intro, position, note, warning) {
            if (!target) return null;
            return {
                element: target,
                title: title || '',
                intro: String(intro || '') + (note ? '<div class="kg-success"><strong>À retenir :</strong> ' + note + '</div>' : '') + (warning ? '<div class="kg-danger"><strong>Attention :</strong> ' + warning + '</div>' : ''),
                position: position || 'bottom'
            };
        }

        function stepAny(selectors, title, intro, position, note, warning) {
            const target = firstVisible(selectors);
            if (!target) return null;

            let body = String(intro == null ? '' : intro);

            if (note) {
                body += '<div class="kg-success"><strong>À retenir :</strong> ' +
                    String(note) +
                    '</div>';
            }

            if (warning) {
                body += '<div class="kg-danger"><strong>Attention :</strong> ' +
                    String(warning) +
                    '</div>';
            }

            return stepElement(target, title, body, position);
        }

        if (typeof k.isVisible !== 'function') k.isVisible = coreVisible;
        if (typeof k.firstVisible !== 'function') k.firstVisible = firstVisible;
        if (typeof k.compactSteps !== 'function') k.compactSteps = compactSteps;
        if (typeof k.stepElement !== 'function') k.stepElement = stepElement;
        if (typeof k.stepAny !== 'function') k.stepAny = stepAny;

        const originalRegister = typeof k.register === 'function'
            ? k.register.bind(k)
            : null;

        if (!originalRegister) return false;

        const providersFirst = [];
        const providersNormal = [];
        let syntheticDefinition = null;

        function context() {
            if (k.helpers && typeof k.helpers.buildContext === 'function') {
                try { return k.helpers.buildContext(); } catch (_) {}
            }
            return {
                api: k,
                path: window.location.pathname,
                search: window.location.search,
                url: window.location.href,
                bodyId: document.body ? document.body.id : '',
                qs: function (selector, root) {
                    try { return (root || document).querySelector(selector); } catch (_) { return null; }
                },
                qsa: function (selector, root) {
                    try { return Array.from((root || document).querySelectorAll(selector)); } catch (_) { return []; }
                },
                visible: coreVisible
            };
        }

        function safeProviderSteps(provider, ctx) {
            try {
                const result = provider(ctx || context());
                return compactSteps(result);
            } catch (error) {
                console.error('[PMK 135] Fournisseur de guide en erreur :', error);
                return [];
            }
        }

        function aggregateSteps(ctx) {
            const c = ctx || context();
            let steps = [];

            providersFirst.forEach(function (provider) {
                steps = steps.concat(safeProviderSteps(provider, c));
            });

            providersNormal.forEach(function (provider) {
                steps = steps.concat(safeProviderSteps(provider, c));
            });

            const custom = (currentConfig.customTours || []).find(tour => tour.enabled !== false && tour.pagePath === window.location.pathname);
            if (custom && !protectedImportPage(custom.pagePath)) {
                return (custom.steps || []).filter(step => step.enabled !== false).map(step => {
                    const element = firstVisible(step.selector);
                    return element ? {element, title: step.title || '', intro: escapeTourText(step.text || ''), position: step.position || 'bottom'} : null;
                }).filter(Boolean);
            }
            return compactSteps(steps);
        }

        function aggregateMatches(ctx) {
            return aggregateSteps(ctx).length > 0;
        }

        function ensureSyntheticDefinition() {
            if (syntheticDefinition) return syntheticDefinition;

            syntheticDefinition = originalRegister({
                id: 'pmk-guides-legacy',
                title: 'Guide interactif',
                priority: 10,
                match: aggregateMatches,
                steps: aggregateSteps
            });

            return syntheticDefinition;
        }

        function registerProvider(provider, first) {
            const list = first ? providersFirst : providersNormal;
            if (!list.includes(provider)) list.push(provider);
            ensureSyntheticDefinition();
            return syntheticDefinition;
        }

        function compatibleRegister(arg1, arg2) {
            /*
             * Ancien format :
             * KOHA_GUIDES.register(function(ctx){ return steps; })
             */
            if (typeof arg1 === 'function' && typeof arg2 === 'undefined') {
                return registerProvider(arg1, false);
            }

            /*
             * Formats natifs du core v2 : inchangés.
             */
            return originalRegister(arg1, arg2);
        }

        k.register = compatibleRegister;
        k.registerGuide = compatibleRegister;
        k.addGuide = compatibleRegister;

        k.registerFirst = function (provider) {
            if (typeof provider !== 'function') return null;
            return registerProvider(provider, true);
        };

        /*
         * Utile pour 000c et pour le diagnostic console.
         */
        k.__pmkLegacyProviders = {
            first: providersFirst,
            normal: providersNormal,
            aggregateSteps: aggregateSteps
        };

        return true;
    }

    function runtimeCoreReady() {
        return !!(window.KOHA_GUIDES && typeof window.KOHA_GUIDES.start === 'function');
    }

    function catalogueReady() {
        return !!(window.KOHA_GUIDES && typeof window.KOHA_GUIDES.openCatalogue === 'function');
    }

    function assistReady() {
        return !!(
            window.KOHA_GUIDES &&
            window.KOHA_GUIDES.assist &&
            typeof window.KOHA_GUIDES.assist.enabled === 'function' &&
            typeof window.KOHA_GUIDES.assist.setEnabled === 'function'
        );
    }

    function currentGuide() {
        if (!runtimeCoreReady() || typeof window.KOHA_GUIDES.currentGuide !== 'function') return null;
        try { return window.KOHA_GUIDES.currentGuide() || null; } catch (_) { return null; }
    }

    function assistEnabled() {
        if (assistReady()) {
            try { return !!window.KOHA_GUIDES.assist.enabled(); } catch (_) {}
        }
        try { return window.localStorage.getItem(ASSIST_KEY) === '1'; } catch (_) { return false; }
    }

    function canStartCurrent() {
        return currentConfig.enabled !== false &&
            currentConfig.currentGuideEnabled !== false &&
            !!currentGuide();
    }

    function canOpenCatalogue() {
        return currentConfig.enabled !== false &&
            currentConfig.catalogueEnabled !== false &&
            catalogueReady();
    }

    function canUseAssist() {
        return currentConfig.enabled !== false &&
            currentConfig.assistFeatureEnabled !== false &&
            assistReady();
    }

    function dispatchState(extra) {
        const detail = Object.assign({
            moduleId: MODULE_ID,
            version: VERSION,
            enabled: currentConfig.enabled !== false,
            loaded: runtimeCoreReady(),
            currentGuideAvailable: canStartCurrent(),
            currentGuideId: currentGuide() && currentGuide().id ? String(currentGuide().id) : '',
            catalogueAvailable: canOpenCatalogue(),
            assistAvailable: canUseAssist(),
            assistEnabled: assistEnabled(),
            error: lastError ? String(lastError.message || lastError) : ''
        }, extra || {});

        try {
            window.dispatchEvent(new CustomEvent('pmk:guides-training-state', { detail: detail }));
        } catch (_) {}
    }

    function notify(message, kind) {
        let box = document.getElementById('pmk-guides-training-notice');
        if (box) box.remove();
        box = document.createElement('div');
        box.id = 'pmk-guides-training-notice';
        box.className = 'alert ' + (kind === 'error' ? 'alert-danger' : 'alert-info');
        box.setAttribute('role', 'status');
        box.textContent = String(message || '');
        box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483001;max-width:min(430px,calc(100vw - 32px));box-shadow:0 .25rem 1rem rgba(0,0,0,.18);margin:0;';
        document.body.appendChild(box);
        window.setTimeout(function () {
            if (box && box.isConnected) box.remove();
        }, 4500);
    }

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) return;
        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            html.${MANAGED_CLASS} .koha-guide-launcher {
                display: none !important;
            }
            html.${DISABLED_CLASS} #bottomActionBar #tutoriel,
            html.${DISABLED_CLASS} .koha-guide-launcher,
            html.${DISABLED_CLASS} [data-koha-guide-launcher] {
                display: none !important;
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function removeCoreFallbackLauncher() {
        document.querySelectorAll('.koha-guide-launcher[data-koha-guide-launcher], .koha-guide-launcher').forEach(function (node) {
            if (node && node.id !== 'tutoriel') node.remove();
        });
    }

    function setDisabledMask(disabled) {
        document.documentElement.classList.add(MANAGED_CLASS);
        document.documentElement.classList.toggle(DISABLED_CLASS, !!disabled);
        if (disabled) removeCoreFallbackLauncher();
    }

    function scriptAlreadyPresent(file) {
        const wanted = '/' + file.replace(/^\/+/, '');
        return Array.from(document.scripts || []).some(function (script) {
            try {
                const url = new URL(script.src || '', window.location.href);
                return url.pathname.endsWith('/guides' + wanted) || url.pathname.endsWith(wanted);
            } catch (_) {
                return String(script.src || '').includes('/guides/' + file);
            }
        });
    }

    function loadOne(file, index) {
        if (scriptAlreadyPresent(file)) return Promise.resolve();

        return new Promise(function (resolve, reject) {
            const script = document.createElement('script');
            script.id = SCRIPT_ID_PREFIX + String(index).padStart(2, '0');
            script.src = guideUrl(file);
            script.async = false;
            script.dataset.pmkGuidesRuntime = file;
            script.onload = function () { resolve(); };
            script.onerror = function () {
                try { script.remove(); } catch (_) {}
                reject(new Error('Impossible de charger guides/' + file));
            };
            (document.head || document.documentElement).appendChild(script);
        });
    }

    function initialiseAssistDefault() {
        try {
            if (window.localStorage.getItem(ASSIST_KEY) === null) {
                window.localStorage.setItem(ASSIST_KEY, currentConfig.assistDefault === true ? '1' : '0');
            }
        } catch (_) {}
    }

    function loadRuntime() {
        if (loadingPromise) return loadingPromise;
        if (currentConfig.enabled === false) return Promise.resolve(false);

        initialiseAssistDefault();
        lastError = null;

        /*
         * Le core doit être chargé seul en premier. On installe ensuite la
         * compatibilité historique AVANT 000b / 001..007.
         */
        loadingPromise = loadOne(GUIDE_FILES[0], 0)
            .then(function () {
                if (!runtimeCoreReady()) {
                    throw new Error('Le noyau KOHA_GUIDES ne s’est pas initialisé.');
                }
                installLegacyGuideCompatibility();
                return GUIDE_FILES.slice(1).reduce(function (promise, file, offset) {
                    return promise.then(function () {
                        return loadOne(file, offset + 1);
                    });
                }, Promise.resolve());
            })
            .then(function () {
                removeCoreFallbackLauncher();
                if (currentConfig.assistFeatureEnabled === false && assistReady()) {
                    try { window.KOHA_GUIDES.assist.setEnabled(false); } catch (_) {}
                }
                dispatchState({ reason: 'runtime-loaded' });
                return runtimeCoreReady();
            })
            .catch(function (error) {
                lastError = error;
                console.error('[PMK 135] Guides & formation :', error);
                dispatchState({ reason: 'runtime-error' });
                loadingPromise = null;
                return false;
            });

        return loadingPromise;
    }

    function ensureLoaded() {
        if (runtimeCoreReady() && catalogueReady() && assistReady()) {
            return Promise.resolve(true);
        }
        return loadRuntime();
    }

    async function startCurrentGuide() {
        if (currentConfig.enabled === false || currentConfig.currentGuideEnabled === false) return false;
        await ensureLoaded();
        const guide = currentGuide();
        if (!guide) {
            notify('Aucun guide interactif n’est disponible pour cet écran.', 'info');
            dispatchState({ reason: 'no-current-guide' });
            return false;
        }
        try {
            const result = await Promise.resolve(
                window.KOHA_GUIDES.start(guide.id || undefined)
            );

            if (result === false) {
                notify('Le guide de cet écran ne contient actuellement aucune étape visible.', 'info');
                dispatchState({ reason: 'current-guide-empty' });
                return false;
            }

            dispatchState({ reason: 'current-guide-started' });
            return true;
        } catch (error) {
            lastError = error;
            console.error('[PMK 135] Démarrage du guide impossible :', error);
            notify('Impossible de démarrer le guide interactif sur cet écran.', 'error');
            dispatchState({ reason: 'current-guide-error' });
            return false;
        }
    }

    async function openCatalogue() {
        if (currentConfig.enabled === false || currentConfig.catalogueEnabled === false) return false;
        await ensureLoaded();
        if (!catalogueReady()) {
            notify('Le catalogue des parcours de formation n’est pas disponible.', 'error');
            return false;
        }
        try {
            window.KOHA_GUIDES.openCatalogue();
            dispatchState({ reason: 'catalogue-opened' });
            return true;
        } catch (error) {
            lastError = error;
            console.error('[PMK 135] Ouverture du catalogue impossible :', error);
            notify('Impossible d’ouvrir les parcours de formation.', 'error');
            dispatchState({ reason: 'catalogue-error' });
            return false;
        }
    }

    async function setAssistEnabled(value) {
        if (currentConfig.enabled === false || currentConfig.assistFeatureEnabled === false) return false;
        await ensureLoaded();
        if (!assistReady()) return false;
        try {
            window.KOHA_GUIDES.assist.setEnabled(!!value);
            if (typeof window.KOHA_GUIDES.assist.refresh === 'function') {
                window.KOHA_GUIDES.assist.refresh();
            }
            dispatchState({ reason: 'assist-changed', assistEnabled: !!value });
            return true;
        } catch (error) {
            lastError = error;
            console.error('[PMK 135] Mode accompagnement :', error);
            dispatchState({ reason: 'assist-error' });
            return false;
        }
    }

    async function toggleAssist() {
        return setAssistEnabled(!assistEnabled());
    }

    async function openHub() {
        /* Point d'entrée générique : le catalogue présente déjà le sommaire,
           les niveaux et le mode accompagnement. */
        return openCatalogue();
    }

    function stopWhenDisabled() {
        if (runtimeCoreReady()) {
            try {
                if (typeof window.KOHA_GUIDES.stopPractice === 'function') {
                    window.KOHA_GUIDES.stopPractice(true);
                }
            } catch (_) {}
        }
        if (assistReady()) {
            try { window.KOHA_GUIDES.assist.setEnabled(false); } catch (_) {}
        }
        removeCoreFallbackLauncher();
    }

    function applyConfig(config) {
        currentConfig = Object.assign({}, DEFAULTS, config || {});
        const disabled = currentConfig.enabled === false;
        setDisabledMask(disabled);

        if (disabled) {
            stopWhenDisabled();
            dispatchState({ reason: 'disabled' });
            return;
        }

        if (currentConfig.assistFeatureEnabled === false && assistReady()) {
            try { window.KOHA_GUIDES.assist.setEnabled(false); } catch (_) {}
        }

        loadRuntime().then(function () {
            dispatchState({ reason: 'config' });
        });
    }

    function protectedImportPage(path) {
        return /\/(?:stage-marc-import|manage-marc-import)\.pl$/i.test(path || '');
    }
    function escapeTourText(value) {
        return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])).replace(/\n/g, '<br>');
    }
    function pickTourElement(ctx) {
        const tour = ctx.rootObject.customTours[Number(ctx.fieldPath[1])];
        return window.PMKConfig.elementPicker.pickForConfig({moduleId: MODULE_ID, targetUrl: tour.pagePath,
            rootObject: ctx.rootObject, fieldPath: ctx.fieldPath, persistAfterPick: false});
    }

    async function copyCurrentTour(ctx) {
        const path = window.location.pathname;
        if (protectedImportPage(path)) return {level: 'warning', message: 'Les guides des imports de notices restent inchangés.'};
        if ((ctx.rootObject.customTours || []).some(tour => tour.pagePath === path)) return {level: 'info', message: 'Cette page possède déjà un guide dans le brouillon.'};
        await loadRuntime();
        const steps = window.KOHA_GUIDES?.__pmkLegacyProviders?.aggregateSteps() || [];
        const copied = steps.map(step => {
            const element = typeof step.element === 'string' ? document.querySelector(step.element) : step.element;
            if (!element) return null;
            const selector = window.PMKConfig.elementPicker.stableSelector(element);
            if (!selector) return null;
            const content = document.createElement('div'); content.innerHTML = step.intro || '';
            return {enabled: true, selector, title: step.title || '', text: content.textContent || '', position: step.position || 'bottom'};
        }).filter(Boolean);
        if (!copied.length) return {level: 'info', message: 'Aucune étape disponible sur cette page. Vous pouvez créer les étapes manuellement.'};
        ctx.rootObject.customTours = (ctx.rootObject.customTours || []).concat({enabled: true, version: 1, pagePath: path, steps: copied});
        return {changed: true, refresh: true};
    }

    function renderGuideDiagnostics(context) {
        const root = context && context.rootObject || DEFAULTS;
        const host = document.createElement('div');
        const coreVersion = window.KOHA_GUIDES && window.KOHA_GUIDES.version ? String(window.KOHA_GUIDES.version) : 'non chargé';
        const loaded = GUIDE_FILES.filter(file => scriptAlreadyPresent(file));
        let resume = null;
        try { resume = JSON.parse(sessionStorage.getItem('koha.guides.practice.v2') || 'null'); } catch (_) {}
        const currentTours = (root.customTours || []).filter(tour => tour && tour.enabled !== false && tour.pagePath === window.location.pathname);
        const activeSteps = currentTours.flatMap(tour => (tour.steps || []).filter(step => step && step.enabled !== false).map(step => ({tour,step})));
        const missing = activeSteps.filter(entry => {
            try { return !entry.step.selector || !document.querySelector(entry.step.selector); } catch (_) { return true; }
        });
        const summary = document.createElement('p');
        summary.textContent = 'Chargeur PMK ' + VERSION + ' · moteur ' + coreVersion + ' · ' + loaded.length + '/' + GUIDE_FILES.length + ' fichiers chargés.';
        host.appendChild(summary);
        const state = document.createElement('p');
        state.textContent = resume ? 'Reprise disponible : guide ' + String(resume.guideId || '?') + ', étape ' + (Number(resume.stepIndex || 0) + 1) + '.' : 'Aucune reprise de parcours enregistrée dans cet onglet.';
        host.appendChild(state);
        const coverage = document.createElement('p');
        coverage.textContent = currentTours.length ? activeSteps.length + ' étape(s) personnalisée(s) active(s) sur cette page · ' + missing.length + ' cible(s) introuvable(s).' : 'Aucun guide personnalisé pour cette page ; les guides fournis restent disponibles.';
        host.appendChild(coverage);
        if (missing.length) {
            const list = document.createElement('ul');
            missing.forEach(entry => { const li = document.createElement('li'); li.textContent = (entry.step.title || 'Étape sans titre') + ' — ' + (entry.step.selector || 'cible absente') + ' — guide v' + Number(entry.tour.version || 1); list.appendChild(li); });
            host.appendChild(list);
        }
        return host;
    }

    function moduleDefinition() {
        return {
            id: MODULE_ID,
            schemaVersion: 1,
            name: {
                fr: 'Guides & formation',
                en: 'Guides & training'
            },
            description: {
                fr: 'Pilote les guides interactifs Koha, les parcours de formation et le mode accompagnement. Le module est autonome du gestionnaire de listes et peut être exposé directement dans Menu IntranetNav.',
                en: 'Controls Koha interactive guides, training paths and contextual assistance. This module is independent from the lists manager and can be exposed directly in IntranetNav Menu.'
            },
            category: {
                fr: 'Aide et formation',
                en: 'Help and training'
            },
            defaults: clone(DEFAULTS),
            validate: function (cfg) {
                for (const tour of cfg.customTours || []) {
                    if (protectedImportPage(tour.pagePath)) return {ok: false, message: 'Les guides des imports de notices restent inchangés.'};
                    if (!/^\/cgi-bin\/koha\/[^?#]+\.pl$/.test(tour.pagePath || '')) return {ok: false, message: 'Indiquez le chemin d’une page Koha.'};
                    for (const step of tour.steps || []) {
                        if (step.enabled !== false && !String(step.selector || '').trim()) return {ok: false, message: 'Choisissez la cible de chaque étape active.'};
                        try { if (step.selector) document.querySelector(step.selector); } catch (_) { return {ok: false, message: 'Sélecteur d’étape invalide.'}; }
                    }
                }
                return {ok: true};
            },
            schema: [
                {type: 'section', id: 'custom-tours', label: {fr: 'Guides personnalisés par page', en: 'Custom guides by page'}, fields: [
                    {type: 'custom', label: {fr: 'État du moteur, reprise et cibles', en: 'Engine, resume and target status'}, render: renderGuideDiagnostics},
                    {type: 'action', buttonLabel: {fr: 'Copier les étapes actuelles de cette page', en: 'Copy the current steps for this page'}, action: copyCurrentTour},
                    {key: 'customTours', type: 'repeater', reorder: true, label: {fr: 'Pages', en: 'Pages'},
                    newItem: () => ({enabled: true, version: 1, pagePath: window.location.pathname, steps: []}),
                    itemTitle: item => item.pagePath || 'Page Koha', fields: [
                        {key: 'enabled', type: 'boolean', label: {fr: 'Guide actif', en: 'Enabled'}},
                        {key: 'version', type: 'number', min: 1, label: {fr: 'Version du guide', en: 'Guide version'}, help: {fr: 'Incrémentez cette version lorsque le parcours change afin d’identifier clairement la définition testée.', en: 'Increase this version when the tour changes to identify the tested definition.'}},
                        {key: 'pagePath', type: 'text', label: {fr: 'Page Koha', en: 'Koha page'}},
                        {key: 'steps', type: 'repeater', reorder: true, label: {fr: 'Étapes', en: 'Steps'},
                        newItem: () => ({enabled: true, title: '', text: '', selector: '', position: 'bottom'}),
                        itemTitle: (item, i) => item.title || ('Étape ' + (i + 1)), fields: [
                            {key: 'enabled', type: 'boolean', label: {fr: 'Étape active', en: 'Enabled'}},
                            {key: 'title', type: 'text', label: {fr: 'Titre', en: 'Title'}},
                            {key: 'text', type: 'textarea', label: {fr: 'Texte', en: 'Text'}},
                            {key: 'selector', type: 'elementPicker', allowManual: true, manualAlways: true, pick: pickTourElement, label: {fr: 'Cible', en: 'Target'}},
                            {key: 'position', type: 'select', label: {fr: 'Position', en: 'Position'}, options: ['top','bottom','left','right'].map(value => ({value,label:value}))}
                        ]}
                    ]}
                ]},
                {
                    key: 'currentGuideEnabled',
                    type: 'boolean',
                    label: { fr: 'Autoriser le guide de l’écran courant', en: 'Enable current-screen guide' },
                    help: { fr: 'Permet de lancer le guide correspondant automatiquement à la page Koha affichée.', en: 'Allows launching the guide matching the current Koha page.' }
                },
                {
                    key: 'catalogueEnabled',
                    type: 'boolean',
                    label: { fr: 'Autoriser les parcours de formation', en: 'Enable training catalogue' },
                    help: { fr: 'Donne accès au sommaire complet des parcours et niveaux de formation.', en: 'Provides access to the complete catalogue of training paths and levels.' }
                },
                {
                    key: 'assistFeatureEnabled',
                    type: 'boolean',
                    label: { fr: 'Autoriser le mode accompagnement', en: 'Enable contextual assistance mode' },
                    help: { fr: 'Permet d’afficher des points d’aide contextuelle sur les écrans Koha.', en: 'Allows contextual help points to be displayed on Koha screens.' }
                },
                {
                    key: 'assistDefault',
                    type: 'boolean',
                    label: { fr: 'Mode accompagnement actif par défaut au premier usage', en: 'Contextual assistance enabled by default on first use' },
                    help: { fr: 'Désactivé par défaut. Ce réglage initialise uniquement les postes qui n’ont encore aucun choix enregistré.', en: 'Disabled by default. This only initializes browsers that do not yet have a saved choice.' }
                }
            ]
        };
    }

    function registerWithPMK() {
        if (!window.PMKConfig || typeof window.PMKConfig.registerModule !== 'function' || registered) return false;
        registered = true;

        try { window.PMKConfig.elementPicker?.register(MODULE_ID, {}); window.PMKConfig.registerModule(moduleDefinition()); } catch (error) {
            console.error('[PMK 135] Enregistrement PMK impossible :', error);
        }

        if (typeof window.PMKConfig.getConfig === 'function') {
            Promise.resolve(window.PMKConfig.getConfig(MODULE_ID))
                .then(applyConfig)
                .catch(function () { applyConfig(clone(DEFAULTS)); });
        } else {
            applyConfig(clone(DEFAULTS));
        }

        if (typeof window.PMKConfig.subscribe === 'function') {
            try { unsubscribe = window.PMKConfig.subscribe(MODULE_ID, applyConfig); } catch (_) {}
        }
        return true;
    }

    window.PMKGuidesTraining = {
        moduleId: MODULE_ID,
        version: VERSION,
        guideFiles: GUIDE_FILES.slice(),
        get enabled() { return currentConfig.enabled !== false; },
        get loaded() { return runtimeCoreReady(); },
        get assistEnabled() { return assistEnabled(); },
        ensureLoaded: ensureLoaded,
        load: loadRuntime,
        open: openHub,
        startCurrent: startCurrentGuide,
        openCatalogue: openCatalogue,
        toggleAssist: toggleAssist,
        setAssistEnabled: setAssistEnabled,
        canStartCurrent: canStartCurrent,
        canOpenCatalogue: canOpenCatalogue,
        canUseAssist: canUseAssist,
        currentGuide: currentGuide,
        refreshState: function () { dispatchState({ reason: 'manual-refresh' }); },
        diagnostics: function () {
            const k = window.KOHA_GUIDES;
            let steps = [];
            try {
                if (k && k.__pmkLegacyProviders && typeof k.__pmkLegacyProviders.aggregateSteps === 'function') {
                    steps = k.__pmkLegacyProviders.aggregateSteps();
                }
            } catch (_) {}
            return {
                moduleVersion: VERSION,
                enabled: currentConfig.enabled !== false,
                coreReady: runtimeCoreReady(),
                registryCount: k && Array.isArray(k.registry) ? k.registry.length : 0,
                legacyFirstProviders: k && k.__pmkLegacyProviders ? k.__pmkLegacyProviders.first.length : 0,
                legacyNormalProviders: k && k.__pmkLegacyProviders ? k.__pmkLegacyProviders.normal.length : 0,
                currentGuide: currentGuide() && currentGuide().id ? currentGuide().id : null,
                currentSteps: Array.isArray(steps) ? steps.length : 0,
                catalogueReady: catalogueReady(),
                assistReady: assistReady(),
                lastError: lastError ? String(lastError.message || lastError) : ''
            };
        }
    };

    function bootstrap() {
        injectStyles();
        document.documentElement.classList.add(MANAGED_CLASS);

        if (registerWithPMK()) return;

        window.addEventListener('pmk:config-ready', registerWithPMK, { once: true });

        let tries = 0;
        const timer = window.setInterval(function () {
            tries += 1;
            if (registerWithPMK() || tries >= 100) {
                window.clearInterval(timer);
                if (!registered) applyConfig(clone(DEFAULTS));
            }
        }, 50);
    }

    document.addEventListener('koha-guides-assist-toggle', function () {
        dispatchState({ reason: 'assist-event' });
    });

    window.addEventListener('storage', function (event) {
        if (event.key === ASSIST_KEY) dispatchState({ reason: 'assist-storage' });
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootstrap, { once: true });
    } else {
        bootstrap();
    }

    window.addEventListener('beforeunload', function () {
        if (typeof unsubscribe === 'function') {
            try { unsubscribe(); } catch (_) {}
        }
    }, { once: true });
})(window, document);

;window.PMKNonPlugin.loaded.push("135-guides-training-pmk-loader.js");
} catch (error) { window.PMKNonPlugin.errors.push("135-guides-training-pmk-loader.js: "+error.message); console.error("[PMK] 135-guides-training-pmk-loader.js",error); };
